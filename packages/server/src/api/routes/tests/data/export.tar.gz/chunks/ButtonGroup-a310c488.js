import { S as SvelteComponent, i as init, s as safe_not_equal, K as Block, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component, u as getContext, v as component_subscribe, M as BlockComponent, y as empty, f as insert, z as group_outros, A as check_outros, o as detach, N as ensure_array_like, O as destroy_each } from "./index-8b9900f1.js";
import { C as CollapsedButtonGroup } from "./CollapsedButtonGroup-d8de26c5.js";
import "./Item-43bbcac6.js";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[12] = list[i].text;
  child_ctx[13] = list[i].type;
  child_ctx[14] = list[i].quiet;
  child_ctx[15] = list[i].disabled;
  child_ctx[16] = list[i].onClick;
  child_ctx[17] = list[i].size;
  child_ctx[18] = list[i].icon;
  child_ctx[6] = list[i].gap;
  return child_ctx;
}
function create_else_block(ctx) {
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(
    /*buttons*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*buttons*/
      1) {
        each_value = ensure_array_like(
          /*buttons*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_if_block(ctx) {
  let collapsedbuttongroup;
  let current;
  collapsedbuttongroup = new CollapsedButtonGroup({
    props: {
      text: (
        /*collapsedText*/
        ctx[5] || "Action"
      ),
      buttons: (
        /*collapsedButtons*/
        ctx[7]
      )
    }
  });
  return {
    c() {
      create_component(collapsedbuttongroup.$$.fragment);
    },
    m(target, anchor) {
      mount_component(collapsedbuttongroup, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const collapsedbuttongroup_changes = {};
      if (dirty & /*collapsedText*/
      32)
        collapsedbuttongroup_changes.text = /*collapsedText*/
        ctx2[5] || "Action";
      if (dirty & /*collapsedButtons*/
      128)
        collapsedbuttongroup_changes.buttons = /*collapsedButtons*/
        ctx2[7];
      collapsedbuttongroup.$set(collapsedbuttongroup_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(collapsedbuttongroup.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(collapsedbuttongroup.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(collapsedbuttongroup, detaching);
    }
  };
}
function create_each_block(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "button",
      props: {
        text: (
          /*text*/
          ctx[12] || "Button"
        ),
        onClick: (
          /*onClick*/
          ctx[16]
        ),
        type: (
          /*type*/
          ctx[13]
        ),
        quiet: (
          /*quiet*/
          ctx[14]
        ),
        disabled: (
          /*disabled*/
          ctx[15]
        ),
        icon: (
          /*icon*/
          ctx[18]
        ),
        gap: (
          /*gap*/
          ctx[6]
        ),
        size: (
          /*size*/
          ctx[17] || "M"
        )
      }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*buttons*/
      1)
        blockcomponent_changes.props = {
          text: (
            /*text*/
            ctx2[12] || "Button"
          ),
          onClick: (
            /*onClick*/
            ctx2[16]
          ),
          type: (
            /*type*/
            ctx2[13]
          ),
          quiet: (
            /*quiet*/
            ctx2[14]
          ),
          disabled: (
            /*disabled*/
            ctx2[15]
          ),
          icon: (
            /*icon*/
            ctx2[18]
          ),
          gap: (
            /*gap*/
            ctx2[6]
          ),
          size: (
            /*size*/
            ctx2[17] || "M"
          )
        };
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*collapsed*/
      ctx2[4]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_default_slot(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "container",
      props: {
        direction: (
          /*direction*/
          ctx[1]
        ),
        hAlign: (
          /*hAlign*/
          ctx[2]
        ),
        vAlign: (
          /*vAlign*/
          ctx[3]
        ),
        gap: (
          /*gap*/
          ctx[6]
        ),
        wrap: true
      },
      styles: { normal: { height: "100%" } },
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*direction, hAlign, vAlign, gap*/
      78)
        blockcomponent_changes.props = {
          direction: (
            /*direction*/
            ctx2[1]
          ),
          hAlign: (
            /*hAlign*/
            ctx2[2]
          ),
          vAlign: (
            /*vAlign*/
            ctx2[3]
          ),
          gap: (
            /*gap*/
            ctx2[6]
          ),
          wrap: true
        };
      if (dirty & /*$$scope, collapsedText, collapsedButtons, collapsed, buttons*/
      2097329) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_fragment(ctx) {
  let block;
  let current;
  block = new Block({
    props: {
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(block.$$.fragment);
    },
    m(target, anchor) {
      mount_component(block, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const block_changes = {};
      if (dirty & /*$$scope, direction, hAlign, vAlign, gap, collapsedText, collapsedButtons, collapsed, buttons*/
      2097407) {
        block_changes.$$scope = { dirty, ctx: ctx2 };
      }
      block.$set(block_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(block.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(block.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(block, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let collapsedButtons;
  let $context;
  let { buttons = [] } = $$props;
  let { direction = "row" } = $$props;
  let { hAlign = "left" } = $$props;
  let { vAlign = "top" } = $$props;
  let { gap = "S" } = $$props;
  let { collapsed = false } = $$props;
  let { collapsedText = "Action" } = $$props;
  const { enrichButtonActions } = getContext("sdk");
  const context = getContext("context");
  component_subscribe($$self, context, (value) => $$invalidate(9, $context = value));
  const makeCollapsed = (buttons2) => {
    return buttons2.map((button) => ({
      ...button,
      onClick: async () => {
        const fn = enrichButtonActions(button.onClick, $context);
        await (fn == null ? void 0 : fn());
      }
    }));
  };
  $$self.$$set = ($$props2) => {
    if ("buttons" in $$props2)
      $$invalidate(0, buttons = $$props2.buttons);
    if ("direction" in $$props2)
      $$invalidate(1, direction = $$props2.direction);
    if ("hAlign" in $$props2)
      $$invalidate(2, hAlign = $$props2.hAlign);
    if ("vAlign" in $$props2)
      $$invalidate(3, vAlign = $$props2.vAlign);
    if ("gap" in $$props2)
      $$invalidate(6, gap = $$props2.gap);
    if ("collapsed" in $$props2)
      $$invalidate(4, collapsed = $$props2.collapsed);
    if ("collapsedText" in $$props2)
      $$invalidate(5, collapsedText = $$props2.collapsedText);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*collapsed, buttons*/
    17) {
      $$invalidate(7, collapsedButtons = collapsed ? makeCollapsed(buttons) : null);
    }
  };
  return [
    buttons,
    direction,
    hAlign,
    vAlign,
    collapsed,
    collapsedText,
    gap,
    collapsedButtons,
    context
  ];
}
class ButtonGroup extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      buttons: 0,
      direction: 1,
      hAlign: 2,
      vAlign: 3,
      gap: 6,
      collapsed: 4,
      collapsedText: 5
    });
  }
}
export {
  ButtonGroup as default
};
