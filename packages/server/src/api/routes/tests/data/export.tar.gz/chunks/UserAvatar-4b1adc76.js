import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, k as transition_in, z as group_outros, n as transition_out, A as check_outros, o as detach, bx as TooltipPosition, av as AbsTooltip, aT as getUserLabel, aS as getUserColor, c as create_component, m as mount_component, p as destroy_component, by as Avatar, bz as getUserInitials } from "./index-8b9900f1.js";
function create_if_block(ctx) {
  let abstooltip;
  let current;
  abstooltip = new AbsTooltip({
    props: {
      text: (
        /*showTooltip*/
        ctx[3] ? getUserLabel(
          /*user*/
          ctx[0]
        ) : ""
      ),
      position: (
        /*tooltipPosition*/
        ctx[2]
      ),
      color: getUserColor(
        /*user*/
        ctx[0]
      ),
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(abstooltip.$$.fragment);
    },
    m(target, anchor) {
      mount_component(abstooltip, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const abstooltip_changes = {};
      if (dirty & /*showTooltip, user*/
      9)
        abstooltip_changes.text = /*showTooltip*/
        ctx2[3] ? getUserLabel(
          /*user*/
          ctx2[0]
        ) : "";
      if (dirty & /*tooltipPosition*/
      4)
        abstooltip_changes.position = /*tooltipPosition*/
        ctx2[2];
      if (dirty & /*user*/
      1)
        abstooltip_changes.color = getUserColor(
          /*user*/
          ctx2[0]
        );
      if (dirty & /*$$scope, size, user*/
      19) {
        abstooltip_changes.$$scope = { dirty, ctx: ctx2 };
      }
      abstooltip.$set(abstooltip_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(abstooltip.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(abstooltip.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(abstooltip, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let avatar;
  let current;
  avatar = new Avatar({
    props: {
      size: (
        /*size*/
        ctx[1]
      ),
      initials: getUserInitials(
        /*user*/
        ctx[0]
      ),
      color: getUserColor(
        /*user*/
        ctx[0]
      )
    }
  });
  return {
    c() {
      create_component(avatar.$$.fragment);
    },
    m(target, anchor) {
      mount_component(avatar, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const avatar_changes = {};
      if (dirty & /*size*/
      2)
        avatar_changes.size = /*size*/
        ctx2[1];
      if (dirty & /*user*/
      1)
        avatar_changes.initials = getUserInitials(
          /*user*/
          ctx2[0]
        );
      if (dirty & /*user*/
      1)
        avatar_changes.color = getUserColor(
          /*user*/
          ctx2[0]
        );
      avatar.$set(avatar_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(avatar.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(avatar.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(avatar, detaching);
    }
  };
}
function create_fragment(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*user*/
    ctx[0] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (
        /*user*/
        ctx2[0]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*user*/
          1) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { user } = $$props;
  let { size = "S" } = $$props;
  let { tooltipPosition = TooltipPosition.Top } = $$props;
  let { showTooltip = true } = $$props;
  $$self.$$set = ($$props2) => {
    if ("user" in $$props2)
      $$invalidate(0, user = $$props2.user);
    if ("size" in $$props2)
      $$invalidate(1, size = $$props2.size);
    if ("tooltipPosition" in $$props2)
      $$invalidate(2, tooltipPosition = $$props2.tooltipPosition);
    if ("showTooltip" in $$props2)
      $$invalidate(3, showTooltip = $$props2.showTooltip);
  };
  return [user, size, tooltipPosition, showTooltip];
}
class UserAvatar extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      user: 0,
      size: 1,
      tooltipPosition: 2,
      showTooltip: 3
    });
  }
}
export {
  UserAvatar as U
};
