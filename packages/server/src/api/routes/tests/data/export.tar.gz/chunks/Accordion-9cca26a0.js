import { S as SvelteComponent, i as init, s as safe_not_equal, I as Icon, F as create_slot, e as element, c as create_component, a as space, t as text, b as attr, am as null_to_empty, al as set_style, d as toggle_class, f as insert, g as append, m as mount_component, l as listen, j as set_data, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, k as transition_in, n as transition_out, o as detach, p as destroy_component } from "./index-8b9900f1.js";
function create_fragment$1(ctx) {
  let div2;
  let div1;
  let h3;
  let button;
  let icon;
  let t0;
  let t1;
  let button_class_value;
  let h3_style_value;
  let t2;
  let div0;
  let div0_style_value;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({
    props: {
      name: (
        /*isOpen*/
        ctx[5] ? "caret-down" : "caret-right"
      ),
      size: "S"
    }
  });
  const default_slot_template = (
    /*#slots*/
    ctx[10].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[9],
    null
  );
  return {
    c() {
      div2 = element("div");
      div1 = element("div");
      h3 = element("h3");
      button = element("button");
      create_component(icon.$$.fragment);
      t0 = space();
      t1 = text(
        /*header*/
        ctx[1]
      );
      t2 = space();
      div0 = element("div");
      if (default_slot)
        default_slot.c();
      attr(button, "class", button_class_value = null_to_empty(`spectrum-Accordion-itemHeader ${headerSizeClass(
        /*headerSize*/
        ctx[2]
      )}`) + " svelte-1h85agu");
      attr(button, "type", "button");
      set_style(
        button,
        "--font-weight",
        /*bold*/
        ctx[3] ? "bold" : "normal"
      );
      attr(h3, "class", "spectrum-Accordion-itemHeading");
      attr(h3, "style", h3_style_value = /*noPadding*/
      ctx[4] ? "margin-bottom: -10px;" : "");
      attr(div0, "class", "spectrum-Accordion-itemContent svelte-1h85agu");
      attr(
        div0,
        "role",
        /*itemName*/
        ctx[0]
      );
      attr(div0, "style", div0_style_value = /*noPadding*/
      ctx[4] ? "padding-left: 0; padding-bottom: 0;" : "padding-left: 30px;");
      attr(div1, "class", "spectrum-Accordion-item svelte-1h85agu");
      toggle_class(
        div1,
        "is-open",
        /*isOpen*/
        ctx[5]
      );
      attr(div2, "class", "spectrum-Accordion");
      attr(
        div2,
        "role",
        /*itemName*/
        ctx[0]
      );
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, div1);
      append(div1, h3);
      append(h3, button);
      mount_component(icon, button, null);
      append(button, t0);
      append(button, t1);
      append(div1, t2);
      append(div1, div0);
      if (default_slot) {
        default_slot.m(div0, null);
      }
      current = true;
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*click_handler*/
          ctx[11]
        );
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      const icon_changes = {};
      if (dirty & /*isOpen*/
      32)
        icon_changes.name = /*isOpen*/
        ctx2[5] ? "caret-down" : "caret-right";
      icon.$set(icon_changes);
      if (!current || dirty & /*header*/
      2)
        set_data(
          t1,
          /*header*/
          ctx2[1]
        );
      if (!current || dirty & /*headerSize*/
      4 && button_class_value !== (button_class_value = null_to_empty(`spectrum-Accordion-itemHeader ${headerSizeClass(
        /*headerSize*/
        ctx2[2]
      )}`) + " svelte-1h85agu")) {
        attr(button, "class", button_class_value);
      }
      if (!current || dirty & /*bold*/
      8) {
        set_style(
          button,
          "--font-weight",
          /*bold*/
          ctx2[3] ? "bold" : "normal"
        );
      }
      if (!current || dirty & /*noPadding*/
      16 && h3_style_value !== (h3_style_value = /*noPadding*/
      ctx2[4] ? "margin-bottom: -10px;" : "")) {
        attr(h3, "style", h3_style_value);
      }
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        512)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[9],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[9]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[9],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*itemName*/
      1) {
        attr(
          div0,
          "role",
          /*itemName*/
          ctx2[0]
        );
      }
      if (!current || dirty & /*noPadding*/
      16 && div0_style_value !== (div0_style_value = /*noPadding*/
      ctx2[4] ? "padding-left: 0; padding-bottom: 0;" : "padding-left: 30px;")) {
        attr(div0, "style", div0_style_value);
      }
      if (!current || dirty & /*isOpen*/
      32) {
        toggle_class(
          div1,
          "is-open",
          /*isOpen*/
          ctx2[5]
        );
      }
      if (!current || dirty & /*itemName*/
      1) {
        attr(
          div2,
          "role",
          /*itemName*/
          ctx2[0]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div2);
      }
      destroy_component(icon);
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function headerSizeClass(size) {
  return size === "S" ? "spectrum-Accordion-itemHeaderS" : size === "M" ? "spectrum-Accordion-itemHeaderM" : "spectrum-Accordion-itemHeaderL";
}
function instance$1($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { itemName = void 0 } = $$props;
  let { initialOpen = false } = $$props;
  let { header } = $$props;
  let { headerSize = "S" } = $$props;
  let { bold = true } = $$props;
  let { noPadding = false } = $$props;
  let isOpen = initialOpen;
  function open() {
    $$invalidate(5, isOpen = true);
  }
  function close() {
    $$invalidate(5, isOpen = false);
  }
  const click_handler = () => $$invalidate(5, isOpen = !isOpen);
  $$self.$$set = ($$props2) => {
    if ("itemName" in $$props2)
      $$invalidate(0, itemName = $$props2.itemName);
    if ("initialOpen" in $$props2)
      $$invalidate(6, initialOpen = $$props2.initialOpen);
    if ("header" in $$props2)
      $$invalidate(1, header = $$props2.header);
    if ("headerSize" in $$props2)
      $$invalidate(2, headerSize = $$props2.headerSize);
    if ("bold" in $$props2)
      $$invalidate(3, bold = $$props2.bold);
    if ("noPadding" in $$props2)
      $$invalidate(4, noPadding = $$props2.noPadding);
    if ("$$scope" in $$props2)
      $$invalidate(9, $$scope = $$props2.$$scope);
  };
  return [
    itemName,
    header,
    headerSize,
    bold,
    noPadding,
    isOpen,
    initialOpen,
    open,
    close,
    $$scope,
    slots,
    click_handler
  ];
}
class Accordion extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, {
      itemName: 0,
      initialOpen: 6,
      header: 1,
      headerSize: 2,
      bold: 3,
      noPadding: 4,
      open: 7,
      close: 8
    });
  }
  get open() {
    return this.$$.ctx[7];
  }
  get close() {
    return this.$$.ctx[8];
  }
}
function create_default_slot(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[3].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[4],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        16)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[4],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[4]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[4],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let accordion;
  let current;
  accordion = new Accordion({
    props: {
      header: (
        /*label*/
        ctx[2] || ""
      ),
      bold: (
        /*bold*/
        ctx[0]
      ),
      initialOpen: (
        /*initialOpen*/
        ctx[1]
      ),
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(accordion.$$.fragment);
    },
    m(target, anchor) {
      mount_component(accordion, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const accordion_changes = {};
      if (dirty & /*label*/
      4)
        accordion_changes.header = /*label*/
        ctx2[2] || "";
      if (dirty & /*bold*/
      1)
        accordion_changes.bold = /*bold*/
        ctx2[0];
      if (dirty & /*initialOpen*/
      2)
        accordion_changes.initialOpen = /*initialOpen*/
        ctx2[1];
      if (dirty & /*$$scope*/
      16) {
        accordion_changes.$$scope = { dirty, ctx: ctx2 };
      }
      accordion.$set(accordion_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(accordion.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(accordion.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(accordion, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { bold } = $$props;
  let { initialOpen } = $$props;
  let { label } = $$props;
  $$self.$$set = ($$props2) => {
    if ("bold" in $$props2)
      $$invalidate(0, bold = $$props2.bold);
    if ("initialOpen" in $$props2)
      $$invalidate(1, initialOpen = $$props2.initialOpen);
    if ("label" in $$props2)
      $$invalidate(2, label = $$props2.label);
    if ("$$scope" in $$props2)
      $$invalidate(4, $$scope = $$props2.$$scope);
  };
  return [bold, initialOpen, label, slots, $$scope];
}
class Accordion_1 extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { bold: 0, initialOpen: 1, label: 2 });
  }
}
export {
  Accordion_1 as default
};
