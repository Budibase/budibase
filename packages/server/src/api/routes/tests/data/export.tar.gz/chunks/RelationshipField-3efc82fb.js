import { S as SvelteComponent, i as init, s as safe_not_equal, W as binding_callbacks, a0 as bind, c as create_component, m as mount_component, a1 as add_flush_callback, k as transition_in, n as transition_out, p as destroy_component, aK as FieldType, u as getContext, Y as createEventDispatcher, y as empty, f as insert, z as group_outros, A as check_outros, o as detach, B as noop, C as subscribe, bN as InternalTable, D as fetchData, b$ as processSearchFilters, bf as debounce, c0 as Select, b9 as construct_svelte_component, aZ as UILogicalOperator, a_ as BasicOperator, E as EmptyFilterOption } from "./index-8b9900f1.js";
import { M as Multiselect } from "./Multiselect-cb208362.js";
import { F as Field } from "./Field-a0270b82.js";
import "./Placeholder-4dedd9c4.js";
import "./InnerForm-0042fa8f.js";
function create_if_block(ctx) {
  let switch_instance;
  let updating_searchTerm;
  let updating_open;
  let switch_instance_anchor;
  let current;
  function switch_instance_searchTerm_binding(value) {
    ctx[42](value);
  }
  function switch_instance_open_binding(value) {
    ctx[43](value);
  }
  var switch_value = (
    /*multiselect*/
    ctx[14] ? Multiselect : Select
  );
  function switch_props(ctx2, dirty) {
    var _a, _b, _c, _d;
    let switch_instance_props = {
      value: (
        /*displayValue*/
        ctx2[19]
      ),
      id: (
        /*fieldState*/
        (_a = ctx2[10]) == null ? void 0 : _a.fieldId
      ),
      disabled: (
        /*fieldState*/
        (_b = ctx2[10]) == null ? void 0 : _b.disabled
      ),
      readonly: (
        /*fieldState*/
        (_c = ctx2[10]) == null ? void 0 : _c.readonly
      ),
      loading: !!/*$fetch*/
      ((_d = ctx2[15]) == null ? void 0 : _d.loading),
      getOptionLabel: func,
      getOptionValue: func_1,
      options: (
        /*options*/
        ctx2[17]
      ),
      placeholder: (
        /*placeholder*/
        ctx2[2]
      ),
      autocomplete: (
        /*autocomplete*/
        ctx2[6]
      )
    };
    if (
      /*searchTerm*/
      ctx2[12] !== void 0
    ) {
      switch_instance_props.searchTerm = /*searchTerm*/
      ctx2[12];
    }
    if (
      /*open*/
      ctx2[13] !== void 0
    ) {
      switch_instance_props.open = /*open*/
      ctx2[13];
    }
    return { props: switch_instance_props };
  }
  if (switch_value) {
    switch_instance = construct_svelte_component(switch_value, switch_props(ctx));
    binding_callbacks.push(() => bind(switch_instance, "searchTerm", switch_instance_searchTerm_binding));
    binding_callbacks.push(() => bind(switch_instance, "open", switch_instance_open_binding));
    switch_instance.$on(
      "change",
      /*handleChange*/
      ctx[21]
    );
  }
  return {
    c() {
      if (switch_instance)
        create_component(switch_instance.$$.fragment);
      switch_instance_anchor = empty();
    },
    m(target, anchor) {
      if (switch_instance)
        mount_component(switch_instance, target, anchor);
      insert(target, switch_instance_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a, _b, _c, _d;
      if (dirty[0] & /*multiselect*/
      16384 && switch_value !== (switch_value = /*multiselect*/
      ctx2[14] ? Multiselect : Select)) {
        if (switch_instance) {
          group_outros();
          const old_component = switch_instance;
          transition_out(old_component.$$.fragment, 1, 0, () => {
            destroy_component(old_component, 1);
          });
          check_outros();
        }
        if (switch_value) {
          switch_instance = construct_svelte_component(switch_value, switch_props(ctx2));
          binding_callbacks.push(() => bind(switch_instance, "searchTerm", switch_instance_searchTerm_binding));
          binding_callbacks.push(() => bind(switch_instance, "open", switch_instance_open_binding));
          switch_instance.$on(
            "change",
            /*handleChange*/
            ctx2[21]
          );
          create_component(switch_instance.$$.fragment);
          transition_in(switch_instance.$$.fragment, 1);
          mount_component(switch_instance, switch_instance_anchor.parentNode, switch_instance_anchor);
        } else {
          switch_instance = null;
        }
      } else if (switch_value) {
        const switch_instance_changes = {};
        if (dirty[0] & /*displayValue*/
        524288)
          switch_instance_changes.value = /*displayValue*/
          ctx2[19];
        if (dirty[0] & /*fieldState*/
        1024)
          switch_instance_changes.id = /*fieldState*/
          (_a = ctx2[10]) == null ? void 0 : _a.fieldId;
        if (dirty[0] & /*fieldState*/
        1024)
          switch_instance_changes.disabled = /*fieldState*/
          (_b = ctx2[10]) == null ? void 0 : _b.disabled;
        if (dirty[0] & /*fieldState*/
        1024)
          switch_instance_changes.readonly = /*fieldState*/
          (_c = ctx2[10]) == null ? void 0 : _c.readonly;
        if (dirty[0] & /*$fetch*/
        32768)
          switch_instance_changes.loading = !!/*$fetch*/
          ((_d = ctx2[15]) == null ? void 0 : _d.loading);
        if (dirty[0] & /*options*/
        131072)
          switch_instance_changes.options = /*options*/
          ctx2[17];
        if (dirty[0] & /*placeholder*/
        4)
          switch_instance_changes.placeholder = /*placeholder*/
          ctx2[2];
        if (dirty[0] & /*autocomplete*/
        64)
          switch_instance_changes.autocomplete = /*autocomplete*/
          ctx2[6];
        if (!updating_searchTerm && dirty[0] & /*searchTerm*/
        4096) {
          updating_searchTerm = true;
          switch_instance_changes.searchTerm = /*searchTerm*/
          ctx2[12];
          add_flush_callback(() => updating_searchTerm = false);
        }
        if (!updating_open && dirty[0] & /*open*/
        8192) {
          updating_open = true;
          switch_instance_changes.open = /*open*/
          ctx2[13];
          add_flush_callback(() => updating_open = false);
        }
        switch_instance.$set(switch_instance_changes);
      }
    },
    i(local) {
      if (current)
        return;
      if (switch_instance)
        transition_in(switch_instance.$$.fragment, local);
      current = true;
    },
    o(local) {
      if (switch_instance)
        transition_out(switch_instance.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(switch_instance_anchor);
      }
      if (switch_instance)
        destroy_component(switch_instance, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*fieldState*/
    ctx[10] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*fieldState*/
        ctx2[10]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*fieldState*/
          1024) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let updating_fieldSchema;
  let current;
  function field_1_fieldState_binding(value) {
    ctx[44](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[45](value);
  }
  function field_1_fieldSchema_binding(value) {
    ctx[46](value);
  }
  let field_1_props = {
    label: (
      /*label*/
      ctx[1]
    ),
    field: (
      /*field*/
      ctx[0]
    ),
    disabled: (
      /*disabled*/
      ctx[3]
    ),
    readonly: (
      /*readonly*/
      ctx[4]
    ),
    validation: (
      /*validation*/
      ctx[5]
    ),
    type: (
      /*type*/
      ctx[9]
    ),
    span: (
      /*span*/
      ctx[7]
    ),
    helpText: (
      /*helpText*/
      ctx[8]
    ),
    defaultValue: (
      /*enrichedDefaultValue*/
      ctx[20]
    ),
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*fieldState*/
    ctx[10] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[10];
  }
  if (
    /*fieldApi*/
    ctx[16] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[16];
  }
  if (
    /*fieldSchema*/
    ctx[11] !== void 0
  ) {
    field_1_props.fieldSchema = /*fieldSchema*/
    ctx[11];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  binding_callbacks.push(() => bind(field_1, "fieldSchema", field_1_fieldSchema_binding));
  return {
    c() {
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const field_1_changes = {};
      if (dirty[0] & /*label*/
      2)
        field_1_changes.label = /*label*/
        ctx2[1];
      if (dirty[0] & /*field*/
      1)
        field_1_changes.field = /*field*/
        ctx2[0];
      if (dirty[0] & /*disabled*/
      8)
        field_1_changes.disabled = /*disabled*/
        ctx2[3];
      if (dirty[0] & /*readonly*/
      16)
        field_1_changes.readonly = /*readonly*/
        ctx2[4];
      if (dirty[0] & /*validation*/
      32)
        field_1_changes.validation = /*validation*/
        ctx2[5];
      if (dirty[0] & /*type*/
      512)
        field_1_changes.type = /*type*/
        ctx2[9];
      if (dirty[0] & /*span*/
      128)
        field_1_changes.span = /*span*/
        ctx2[7];
      if (dirty[0] & /*helpText*/
      256)
        field_1_changes.helpText = /*helpText*/
        ctx2[8];
      if (dirty[0] & /*enrichedDefaultValue*/
      1048576)
        field_1_changes.defaultValue = /*enrichedDefaultValue*/
        ctx2[20];
      if (dirty[0] & /*multiselect, displayValue, fieldState, $fetch, options, placeholder, autocomplete, searchTerm, open*/
      717892 | dirty[2] & /*$$scope*/
      4) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty[0] & /*fieldState*/
      1024) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[10];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty[0] & /*fieldApi*/
      65536) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[16];
        add_flush_callback(() => updating_fieldApi = false);
      }
      if (!updating_fieldSchema && dirty[0] & /*fieldSchema*/
      2048) {
        updating_fieldSchema = true;
        field_1_changes.fieldSchema = /*fieldSchema*/
        ctx2[11];
        add_flush_callback(() => updating_fieldSchema = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field_1, detaching);
    }
  };
}
const func = (option) => option.primaryDisplay;
const func_1 = (option) => option._id;
function instance($$self, $$props, $$invalidate) {
  let multiselect;
  let realValue;
  let selectedValue;
  let selectedIDs;
  let linkedTableId;
  let writable;
  let migratedFilter;
  let fetch;
  let tableDefinition;
  let primaryDisplayField;
  let rows;
  let missingIDs;
  let enrichedDefaultValue;
  let emptyValue;
  let displayValue;
  let $fetch, $$unsubscribe_fetch = noop, $$subscribe_fetch = () => ($$unsubscribe_fetch(), $$unsubscribe_fetch = subscribe(fetch, ($$value) => $$invalidate(15, $fetch = $$value)), fetch);
  $$self.$$.on_destroy.push(() => $$unsubscribe_fetch());
  let { field = void 0 } = $$props;
  let { label = void 0 } = $$props;
  let { placeholder = void 0 } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { validation = void 0 } = $$props;
  let { autocomplete = true } = $$props;
  let { defaultValue = void 0 } = $$props;
  let { onChange } = $$props;
  let { filter = void 0 } = $$props;
  let { datasourceType = "table" } = $$props;
  let { primaryDisplay = void 0 } = $$props;
  let { span = void 0 } = $$props;
  let { helpText = void 0 } = $$props;
  let { type = FieldType.LINK } = $$props;
  let { multi = void 0 } = $$props;
  let { tableId = void 0 } = $$props;
  let { defaultRows = [] } = $$props;
  const { API } = getContext("sdk");
  const dispatch = createEventDispatcher();
  let fieldState;
  let fieldApi;
  let fieldSchema;
  let searchTerm;
  let open = false;
  let options = [];
  let optionsMap = {};
  let loadingMissingOptions = false;
  const parseSelectedValue = (value, multiselect2) => {
    return multiselect2 ? flatten(value) : flatten(value)[0];
  };
  const createFetch = (writable2, dsType, filter2, linkedTableId2) => {
    const datasource = dsType === "table" ? { type: dsType, tableId: linkedTableId2 } : {
      type: dsType,
      tableId: InternalTable.USER_METADATA
    };
    return fetchData({
      API,
      datasource,
      options: {
        filter: filter2,
        limit: writable2 ? 100 : 1
      }
    });
  };
  const getSelectedIDs = (selectedValue2) => {
    if (!selectedValue2) {
      return [];
    }
    return Array.isArray(selectedValue2) ? selectedValue2 : [selectedValue2];
  };
  const processOptions = (realValue2, rows2, primaryDisplay2) => {
    if (realValue2) {
      const valueArray = Array.isArray(realValue2) ? realValue2 : [realValue2];
      for (let val of valueArray) {
        const option = parseOption(val, primaryDisplay2);
        if (option) {
          $$invalidate(30, optionsMap[option._id] = option, optionsMap);
        }
      }
    }
    for (let row of rows2) {
      const option = parseOption(row, primaryDisplay2);
      if (option) {
        $$invalidate(30, optionsMap[option._id] = option, optionsMap);
      }
    }
    $$invalidate(30, optionsMap), $$invalidate(24, filter);
  };
  const parseOption = (option, primaryDisplay2) => {
    if (typeof option === "string" && optionsMap[option]) {
      return optionsMap[option];
    }
    if (!option || typeof option !== "object" || !(option == null ? void 0 : option._id)) {
      return null;
    }
    if (Object.keys(option).length === 2 && "primaryDisplay" in option) {
      return {
        _id: option._id,
        primaryDisplay: ensureString(option.primaryDisplay)
      };
    }
    if (primaryDisplay2) {
      return {
        _id: option._id,
        primaryDisplay: ensureString(option[primaryDisplay2])
      };
    } else {
      return {
        _id: option._id,
        primaryDisplay: option._id
      };
    }
  };
  const loadMissingOptions = async (missingIDs2, linkedTableId2, primaryDisplay2) => {
    if (loadingMissingOptions || !missingIDs2.length || !linkedTableId2 || !primaryDisplay2) {
      return;
    }
    loadingMissingOptions = true;
    try {
      const res = await API.searchTable(linkedTableId2, { query: { oneOf: { _id: missingIDs2 } } });
      for (let row of res.rows) {
        const option = parseOption(row, primaryDisplay2);
        if (option) {
          $$invalidate(30, optionsMap[option._id] = option, optionsMap);
        }
      }
      $$invalidate(30, optionsMap), $$invalidate(24, filter);
      updateOptions(optionsMap);
    } catch (error) {
      console.error("Error loading missing row IDs", error);
    } finally {
      for (let id of missingIDs2) {
        if (!optionsMap[id]) {
          $$invalidate(30, optionsMap[id] = { _id: id, primaryDisplay: id }, optionsMap);
        }
      }
      loadingMissingOptions = false;
    }
  };
  const updateOptions = (optionsMap2) => {
    let newOptions = Object.values(optionsMap2);
    if (newOptions.length !== options.length) {
      $$invalidate(17, options = newOptions);
      sortOptions();
    }
  };
  const sortOptions = () => {
    const selectedMap = selectedIDs.reduce((map, id) => ({ ...map, [id]: true }), {});
    options.sort((a, b) => {
      const aSelected = !!selectedMap[a._id];
      const bSelected = !!selectedMap[b._id];
      if (aSelected === bSelected) {
        return a.primaryDisplay < b.primaryDisplay ? -1 : 1;
      } else {
        return aSelected ? -1 : 1;
      }
    });
  };
  const ensureString = (val) => {
    return typeof val === "string" ? val : JSON.stringify(val);
  };
  const enrichDefaultValue = (val) => {
    if (!val || typeof val !== "string") {
      return val;
    }
    return val.includes(",") ? val.split(",") : val;
  };
  const migrateFilter = (filter2) => {
    if (Array.isArray(filter2)) {
      return processSearchFilters(filter2);
    }
    return filter2;
  };
  async function searchOptions(searchTerm2, primaryDisplay2) {
    if (!primaryDisplay2) {
      return;
    }
    let newFilter = void 0;
    let searchFilter = {
      logicalOperator: UILogicalOperator.ALL,
      filters: [
        {
          field: primaryDisplay2,
          operator: BasicOperator.STRING,
          value: searchTerm2
        }
      ]
    };
    if (searchTerm2 && migratedFilter) {
      newFilter = {
        logicalOperator: UILogicalOperator.ALL,
        groups: [searchFilter, migratedFilter],
        onEmptyFilter: EmptyFilterOption.RETURN_NONE
      };
    } else if (searchTerm2) {
      newFilter = {
        logicalOperator: UILogicalOperator.ALL,
        groups: [searchFilter],
        onEmptyFilter: EmptyFilterOption.RETURN_NONE
      };
    } else {
      newFilter = migratedFilter;
    }
    await (fetch == null ? void 0 : fetch.update({ filter: newFilter }));
  }
  const debouncedSearchOptions = debounce(searchOptions, 250);
  const flatten = (values) => {
    if (!values) {
      return [];
    }
    if (!Array.isArray(values)) {
      values = [values];
    }
    values = values.map((value) => typeof value === "object" ? value._id : value);
    return values;
  };
  const handleChange = (e) => {
    let value = e.detail;
    if (!multiselect) {
      value = value == null ? [] : [value];
    }
    if (type === FieldType.BB_REFERENCE_SINGLE && value && Array.isArray(value)) {
      value = value[0] || null;
    }
    const changed = fieldApi.setValue(value);
    if (onChange && changed) {
      onChange({ value });
    }
  };
  function switch_instance_searchTerm_binding(value) {
    searchTerm = value;
    $$invalidate(12, searchTerm);
  }
  function switch_instance_open_binding(value) {
    open = value;
    $$invalidate(13, open);
  }
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(10, fieldState);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(16, fieldApi);
  }
  function field_1_fieldSchema_binding(value) {
    fieldSchema = value;
    $$invalidate(11, fieldSchema);
  }
  $$self.$$set = ($$props2) => {
    if ("field" in $$props2)
      $$invalidate(0, field = $$props2.field);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("placeholder" in $$props2)
      $$invalidate(2, placeholder = $$props2.placeholder);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(4, readonly = $$props2.readonly);
    if ("validation" in $$props2)
      $$invalidate(5, validation = $$props2.validation);
    if ("autocomplete" in $$props2)
      $$invalidate(6, autocomplete = $$props2.autocomplete);
    if ("defaultValue" in $$props2)
      $$invalidate(22, defaultValue = $$props2.defaultValue);
    if ("onChange" in $$props2)
      $$invalidate(23, onChange = $$props2.onChange);
    if ("filter" in $$props2)
      $$invalidate(24, filter = $$props2.filter);
    if ("datasourceType" in $$props2)
      $$invalidate(25, datasourceType = $$props2.datasourceType);
    if ("primaryDisplay" in $$props2)
      $$invalidate(26, primaryDisplay = $$props2.primaryDisplay);
    if ("span" in $$props2)
      $$invalidate(7, span = $$props2.span);
    if ("helpText" in $$props2)
      $$invalidate(8, helpText = $$props2.helpText);
    if ("type" in $$props2)
      $$invalidate(9, type = $$props2.type);
    if ("multi" in $$props2)
      $$invalidate(27, multi = $$props2.multi);
    if ("tableId" in $$props2)
      $$invalidate(28, tableId = $$props2.tableId);
    if ("defaultRows" in $$props2)
      $$invalidate(29, defaultRows = $$props2.defaultRows);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*filter*/
    16777216) {
      $$invalidate(30, optionsMap = {});
    }
    if ($$self.$$.dirty[0] & /*multi, type, fieldSchema*/
    134220288) {
      $$invalidate(14, multiselect = multi ?? ([FieldType.LINK, FieldType.BB_REFERENCE].includes(type) && (fieldSchema == null ? void 0 : fieldSchema.relationshipType) !== "one-to-many"));
    }
    if ($$self.$$.dirty[0] & /*fieldState*/
    1024) {
      $$invalidate(39, realValue = fieldState == null ? void 0 : fieldState.value);
    }
    if ($$self.$$.dirty[0] & /*multiselect*/
    16384 | $$self.$$.dirty[1] & /*realValue*/
    256) {
      $$invalidate(33, selectedValue = parseSelectedValue(realValue, multiselect));
    }
    if ($$self.$$.dirty[1] & /*selectedValue*/
    4) {
      $$invalidate(32, selectedIDs = getSelectedIDs(selectedValue));
    }
    if ($$self.$$.dirty[0] & /*tableId, fieldSchema*/
    268437504) {
      $$invalidate(37, linkedTableId = tableId ?? (fieldSchema == null ? void 0 : fieldSchema.tableId));
    }
    if ($$self.$$.dirty[0] & /*disabled, readonly*/
    24) {
      $$invalidate(41, writable = !disabled && !readonly);
    }
    if ($$self.$$.dirty[0] & /*filter*/
    16777216) {
      $$invalidate(31, migratedFilter = migrateFilter(filter));
    }
    if ($$self.$$.dirty[0] & /*datasourceType*/
    33554432 | $$self.$$.dirty[1] & /*writable, migratedFilter, linkedTableId*/
    1089) {
      $$subscribe_fetch($$invalidate(18, fetch = createFetch(writable, datasourceType, migratedFilter, linkedTableId)));
    }
    if ($$self.$$.dirty[0] & /*$fetch*/
    32768) {
      $$invalidate(40, tableDefinition = $fetch == null ? void 0 : $fetch.definition);
    }
    if ($$self.$$.dirty[0] & /*primaryDisplay*/
    67108864 | $$self.$$.dirty[1] & /*tableDefinition*/
    512) {
      $$invalidate(36, primaryDisplayField = primaryDisplay || (tableDefinition == null ? void 0 : tableDefinition.primaryDisplay));
    }
    if ($$self.$$.dirty[0] & /*$fetch*/
    32768) {
      $$invalidate(38, rows = ($fetch == null ? void 0 : $fetch.rows) || []);
    }
    if ($$self.$$.dirty[1] & /*rows*/
    128) {
      rows && dispatch("rows", rows);
    }
    if ($$self.$$.dirty[0] & /*defaultRows*/
    536870912 | $$self.$$.dirty[1] & /*realValue, rows, primaryDisplayField*/
    416) {
      processOptions(realValue, [...rows, ...defaultRows || []], primaryDisplayField);
    }
    if ($$self.$$.dirty[0] & /*optionsMap*/
    1073741824 | $$self.$$.dirty[1] & /*selectedIDs*/
    2) {
      $$invalidate(35, missingIDs = selectedIDs.filter((id) => !optionsMap[id]));
    }
    if ($$self.$$.dirty[1] & /*missingIDs, linkedTableId, primaryDisplayField*/
    112) {
      loadMissingOptions(missingIDs, linkedTableId, primaryDisplayField);
    }
    if ($$self.$$.dirty[0] & /*optionsMap*/
    1073741824) {
      updateOptions(optionsMap);
    }
    if ($$self.$$.dirty[0] & /*open*/
    8192) {
      !open && sortOptions();
    }
    if ($$self.$$.dirty[0] & /*searchTerm*/
    4096 | $$self.$$.dirty[1] & /*primaryDisplayField*/
    32) {
      debouncedSearchOptions(searchTerm || "", primaryDisplayField);
    }
    if ($$self.$$.dirty[0] & /*defaultValue*/
    4194304) {
      $$invalidate(20, enrichedDefaultValue = enrichDefaultValue(defaultValue));
    }
    if ($$self.$$.dirty[0] & /*multiselect*/
    16384) {
      $$invalidate(34, emptyValue = multiselect ? [] : void 0);
    }
    if ($$self.$$.dirty[1] & /*missingIDs, emptyValue, selectedValue*/
    28) {
      $$invalidate(19, displayValue = missingIDs.length ? emptyValue : selectedValue);
    }
  };
  return [
    field,
    label,
    placeholder,
    disabled,
    readonly,
    validation,
    autocomplete,
    span,
    helpText,
    type,
    fieldState,
    fieldSchema,
    searchTerm,
    open,
    multiselect,
    $fetch,
    fieldApi,
    options,
    fetch,
    displayValue,
    enrichedDefaultValue,
    handleChange,
    defaultValue,
    onChange,
    filter,
    datasourceType,
    primaryDisplay,
    multi,
    tableId,
    defaultRows,
    optionsMap,
    migratedFilter,
    selectedIDs,
    selectedValue,
    emptyValue,
    missingIDs,
    primaryDisplayField,
    linkedTableId,
    rows,
    realValue,
    tableDefinition,
    writable,
    switch_instance_searchTerm_binding,
    switch_instance_open_binding,
    field_1_fieldState_binding,
    field_1_fieldApi_binding,
    field_1_fieldSchema_binding
  ];
}
class RelationshipField extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        field: 0,
        label: 1,
        placeholder: 2,
        disabled: 3,
        readonly: 4,
        validation: 5,
        autocomplete: 6,
        defaultValue: 22,
        onChange: 23,
        filter: 24,
        datasourceType: 25,
        primaryDisplay: 26,
        span: 7,
        helpText: 8,
        type: 9,
        multi: 27,
        tableId: 28,
        defaultRows: 29
      },
      null,
      [-1, -1, -1]
    );
  }
}
export {
  RelationshipField as default
};
