import { S as SvelteComponent, i as init, s as safe_not_equal, W as binding_callbacks, a0 as bind, c as create_component, m as mount_component, a1 as add_flush_callback, k as transition_in, n as transition_out, p as destroy_component, y as empty, f as insert, z as group_outros, A as check_outros, o as detach } from "./index-8b9900f1.js";
import { D as DatePicker } from "./DatePicker-35c5ed8a.js";
import { F as Field } from "./Field-a0270b82.js";
import "./Placeholder-4dedd9c4.js";
import "./InnerForm-0042fa8f.js";
function create_if_block(ctx) {
  let coredatepicker;
  let current;
  coredatepicker = new DatePicker({
    props: {
      value: (
        /*fieldState*/
        ctx[13].value
      ),
      disabled: (
        /*fieldState*/
        ctx[13].disabled
      ),
      readonly: (
        /*fieldState*/
        ctx[13].readonly
      ),
      error: (
        /*fieldState*/
        ctx[13].error
      ),
      id: (
        /*fieldState*/
        ctx[13].fieldId
      ),
      enableTime: (
        /*enableTime*/
        ctx[5]
      ),
      timeOnly: (
        /*timeOnly*/
        ctx[6]
      ),
      time24hr: (
        /*time24hr*/
        ctx[7]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        ctx[8]
      ),
      placeholder: (
        /*placeholder*/
        ctx[2]
      )
    }
  });
  coredatepicker.$on(
    "change",
    /*handleChange*/
    ctx[15]
  );
  return {
    c() {
      create_component(coredatepicker.$$.fragment);
    },
    m(target, anchor) {
      mount_component(coredatepicker, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const coredatepicker_changes = {};
      if (dirty & /*fieldState*/
      8192)
        coredatepicker_changes.value = /*fieldState*/
        ctx2[13].value;
      if (dirty & /*fieldState*/
      8192)
        coredatepicker_changes.disabled = /*fieldState*/
        ctx2[13].disabled;
      if (dirty & /*fieldState*/
      8192)
        coredatepicker_changes.readonly = /*fieldState*/
        ctx2[13].readonly;
      if (dirty & /*fieldState*/
      8192)
        coredatepicker_changes.error = /*fieldState*/
        ctx2[13].error;
      if (dirty & /*fieldState*/
      8192)
        coredatepicker_changes.id = /*fieldState*/
        ctx2[13].fieldId;
      if (dirty & /*enableTime*/
      32)
        coredatepicker_changes.enableTime = /*enableTime*/
        ctx2[5];
      if (dirty & /*timeOnly*/
      64)
        coredatepicker_changes.timeOnly = /*timeOnly*/
        ctx2[6];
      if (dirty & /*time24hr*/
      128)
        coredatepicker_changes.time24hr = /*time24hr*/
        ctx2[7];
      if (dirty & /*ignoreTimezones*/
      256)
        coredatepicker_changes.ignoreTimezones = /*ignoreTimezones*/
        ctx2[8];
      if (dirty & /*placeholder*/
      4)
        coredatepicker_changes.placeholder = /*placeholder*/
        ctx2[2];
      coredatepicker.$set(coredatepicker_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(coredatepicker.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(coredatepicker.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(coredatepicker, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*fieldState*/
    ctx[13] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*fieldState*/
        ctx2[13]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*fieldState*/
          8192) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let current;
  function field_1_fieldState_binding(value) {
    ctx[18](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[19](value);
  }
  let field_1_props = {
    label: (
      /*label*/
      ctx[1]
    ),
    field: (
      /*field*/
      ctx[0]
    ),
    disabled: (
      /*disabled*/
      ctx[3]
    ),
    readonly: (
      /*readonly*/
      ctx[4]
    ),
    validation: (
      /*validation*/
      ctx[9]
    ),
    defaultValue: (
      /*defaultValue*/
      ctx[10]
    ),
    span: (
      /*span*/
      ctx[11]
    ),
    helpText: (
      /*helpText*/
      ctx[12]
    ),
    type: "datetime",
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*fieldState*/
    ctx[13] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[13];
  }
  if (
    /*fieldApi*/
    ctx[14] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[14];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  return {
    c() {
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const field_1_changes = {};
      if (dirty & /*label*/
      2)
        field_1_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*field*/
      1)
        field_1_changes.field = /*field*/
        ctx2[0];
      if (dirty & /*disabled*/
      8)
        field_1_changes.disabled = /*disabled*/
        ctx2[3];
      if (dirty & /*readonly*/
      16)
        field_1_changes.readonly = /*readonly*/
        ctx2[4];
      if (dirty & /*validation*/
      512)
        field_1_changes.validation = /*validation*/
        ctx2[9];
      if (dirty & /*defaultValue*/
      1024)
        field_1_changes.defaultValue = /*defaultValue*/
        ctx2[10];
      if (dirty & /*span*/
      2048)
        field_1_changes.span = /*span*/
        ctx2[11];
      if (dirty & /*helpText*/
      4096)
        field_1_changes.helpText = /*helpText*/
        ctx2[12];
      if (dirty & /*$$scope, fieldState, enableTime, timeOnly, time24hr, ignoreTimezones, placeholder*/
      4202980) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty & /*fieldState*/
      8192) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[13];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty & /*fieldApi*/
      16384) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[14];
        add_flush_callback(() => updating_fieldApi = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field_1, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { field } = $$props;
  let { label } = $$props;
  let { placeholder } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { enableTime = true } = $$props;
  let { timeOnly = false } = $$props;
  let { time24hr = false } = $$props;
  let { ignoreTimezones = false } = $$props;
  let { validation } = $$props;
  let { defaultValue } = $$props;
  let { onChange } = $$props;
  let { span } = $$props;
  let { helpText = null } = $$props;
  let { valueAsTimestamp = false } = $$props;
  let fieldState;
  let fieldApi;
  const handleChange = (e) => {
    let value = e.detail;
    if (timeOnly && valueAsTimestamp) {
      if (!isValidDate(value)) {
        value = timeToDateISOString(value);
      }
    }
    const changed = fieldApi.setValue(value);
    if (onChange && changed) {
      onChange({ value });
    }
  };
  const isValidDate = (value) => !isNaN(new Date(value));
  const timeToDateISOString = (value) => {
    let [hours, minutes] = value.split(":").map(Number);
    const date = /* @__PURE__ */ new Date();
    date.setHours(hours);
    date.setMinutes(minutes);
    date.setSeconds(0);
    date.setMilliseconds(0);
    return date.toISOString();
  };
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(13, fieldState);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(14, fieldApi);
  }
  $$self.$$set = ($$props2) => {
    if ("field" in $$props2)
      $$invalidate(0, field = $$props2.field);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("placeholder" in $$props2)
      $$invalidate(2, placeholder = $$props2.placeholder);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(4, readonly = $$props2.readonly);
    if ("enableTime" in $$props2)
      $$invalidate(5, enableTime = $$props2.enableTime);
    if ("timeOnly" in $$props2)
      $$invalidate(6, timeOnly = $$props2.timeOnly);
    if ("time24hr" in $$props2)
      $$invalidate(7, time24hr = $$props2.time24hr);
    if ("ignoreTimezones" in $$props2)
      $$invalidate(8, ignoreTimezones = $$props2.ignoreTimezones);
    if ("validation" in $$props2)
      $$invalidate(9, validation = $$props2.validation);
    if ("defaultValue" in $$props2)
      $$invalidate(10, defaultValue = $$props2.defaultValue);
    if ("onChange" in $$props2)
      $$invalidate(16, onChange = $$props2.onChange);
    if ("span" in $$props2)
      $$invalidate(11, span = $$props2.span);
    if ("helpText" in $$props2)
      $$invalidate(12, helpText = $$props2.helpText);
    if ("valueAsTimestamp" in $$props2)
      $$invalidate(17, valueAsTimestamp = $$props2.valueAsTimestamp);
  };
  return [
    field,
    label,
    placeholder,
    disabled,
    readonly,
    enableTime,
    timeOnly,
    time24hr,
    ignoreTimezones,
    validation,
    defaultValue,
    span,
    helpText,
    fieldState,
    fieldApi,
    handleChange,
    onChange,
    valueAsTimestamp,
    field_1_fieldState_binding,
    field_1_fieldApi_binding
  ];
}
class DateTimeField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      field: 0,
      label: 1,
      placeholder: 2,
      disabled: 3,
      readonly: 4,
      enableTime: 5,
      timeOnly: 6,
      time24hr: 7,
      ignoreTimezones: 8,
      validation: 9,
      defaultValue: 10,
      onChange: 16,
      span: 11,
      helpText: 12,
      valueAsTimestamp: 17
    });
  }
}
export {
  DateTimeField as default
};
