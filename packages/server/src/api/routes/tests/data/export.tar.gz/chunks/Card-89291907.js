import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, a as space, t as text, b as attr, al as set_style, f as insert, g as append, q as action_destroyer, j as set_data, h as is_function, B as noop, o as detach, r as run_all, u as getContext, v as component_subscribe, ae as src_url_equal } from "./index-8b9900f1.js";
const Card_svelte_svelte_type_style_lang = "";
function create_if_block(ctx) {
  let img;
  let img_src_value;
  return {
    c() {
      img = element("img");
      set_style(
        img,
        "--imageHeight",
        /*imageHeight*/
        ctx[7]
      );
      attr(img, "class", "image svelte-9mr74r");
      if (!src_url_equal(img.src, img_src_value = /*imageUrl*/
      ctx[0]))
        attr(img, "src", img_src_value);
      attr(img, "alt", "");
    },
    m(target, anchor) {
      insert(target, img, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*imageHeight*/
      128) {
        set_style(
          img,
          "--imageHeight",
          /*imageHeight*/
          ctx2[7]
        );
      }
      if (dirty & /*imageUrl*/
      1 && !src_url_equal(img.src, img_src_value = /*imageUrl*/
      ctx2[0])) {
        attr(img, "src", img_src_value);
      }
    },
    d(detaching) {
      if (detaching) {
        detach(img);
      }
    }
  };
}
function create_fragment(ctx) {
  let div1;
  let t0;
  let div0;
  let h2;
  let t1;
  let t2;
  let h4;
  let t3;
  let t4;
  let a;
  let t5;
  let a_href_value;
  let styleable_action;
  let mounted;
  let dispose;
  let if_block = (
    /*showImage*/
    ctx[8] && create_if_block(ctx)
  );
  return {
    c() {
      div1 = element("div");
      if (if_block)
        if_block.c();
      t0 = space();
      div0 = element("div");
      h2 = element("h2");
      t1 = text(
        /*heading*/
        ctx[1]
      );
      t2 = space();
      h4 = element("h4");
      t3 = text(
        /*description*/
        ctx[2]
      );
      t4 = space();
      a = element("a");
      t5 = text(
        /*linkText*/
        ctx[3]
      );
      attr(h2, "class", "heading svelte-9mr74r");
      attr(h4, "class", "text svelte-9mr74r");
      set_style(
        a,
        "--linkColor",
        /*linkColor*/
        ctx[5]
      );
      set_style(
        a,
        "--linkHoverColor",
        /*linkHoverColor*/
        ctx[6]
      );
      attr(a, "href", a_href_value = /*linkUrl*/
      ctx[4] || "/");
      attr(a, "class", "svelte-9mr74r");
      attr(div0, "class", "content svelte-9mr74r");
      attr(div1, "class", "container svelte-9mr74r");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      if (if_block)
        if_block.m(div1, null);
      append(div1, t0);
      append(div1, div0);
      append(div0, h2);
      append(h2, t1);
      append(div0, t2);
      append(div0, h4);
      append(h4, t3);
      append(div0, t4);
      append(div0, a);
      append(a, t5);
      if (!mounted) {
        dispose = [
          action_destroyer(
            /*linkable*/
            ctx[11].call(null, a)
          ),
          action_destroyer(styleable_action = /*styleable*/
          ctx[10].call(
            null,
            div1,
            /*cardStyles*/
            ctx[9]
          ))
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (
        /*showImage*/
        ctx2[8]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          if_block.m(div1, t0);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (dirty & /*heading*/
      2)
        set_data(
          t1,
          /*heading*/
          ctx2[1]
        );
      if (dirty & /*description*/
      4)
        set_data(
          t3,
          /*description*/
          ctx2[2]
        );
      if (dirty & /*linkText*/
      8)
        set_data(
          t5,
          /*linkText*/
          ctx2[3]
        );
      if (dirty & /*linkColor*/
      32) {
        set_style(
          a,
          "--linkColor",
          /*linkColor*/
          ctx2[5]
        );
      }
      if (dirty & /*linkHoverColor*/
      64) {
        set_style(
          a,
          "--linkHoverColor",
          /*linkHoverColor*/
          ctx2[6]
        );
      }
      if (dirty & /*linkUrl*/
      16 && a_href_value !== (a_href_value = /*linkUrl*/
      ctx2[4] || "/")) {
        attr(a, "href", a_href_value);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*cardStyles*/
      512)
        styleable_action.update.call(
          null,
          /*cardStyles*/
          ctx2[9]
        );
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if (if_block)
        if_block.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let cardStyles;
  let showImage;
  let $component;
  const { styleable, linkable } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(15, $component = value));
  const className = "";
  let { imageUrl = "" } = $$props;
  let { heading = "" } = $$props;
  let { description = "" } = $$props;
  let { linkText = "" } = $$props;
  let { linkUrl } = $$props;
  let { linkColor } = $$props;
  let { linkHoverColor } = $$props;
  let { imageHeight } = $$props;
  let { cardWidth } = $$props;
  $$self.$$set = ($$props2) => {
    if ("imageUrl" in $$props2)
      $$invalidate(0, imageUrl = $$props2.imageUrl);
    if ("heading" in $$props2)
      $$invalidate(1, heading = $$props2.heading);
    if ("description" in $$props2)
      $$invalidate(2, description = $$props2.description);
    if ("linkText" in $$props2)
      $$invalidate(3, linkText = $$props2.linkText);
    if ("linkUrl" in $$props2)
      $$invalidate(4, linkUrl = $$props2.linkUrl);
    if ("linkColor" in $$props2)
      $$invalidate(5, linkColor = $$props2.linkColor);
    if ("linkHoverColor" in $$props2)
      $$invalidate(6, linkHoverColor = $$props2.linkHoverColor);
    if ("imageHeight" in $$props2)
      $$invalidate(7, imageHeight = $$props2.imageHeight);
    if ("cardWidth" in $$props2)
      $$invalidate(14, cardWidth = $$props2.cardWidth);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$component, cardWidth*/
    49152) {
      $$invalidate(9, cardStyles = {
        ...$component.styles,
        normal: {
          ...$component.styles.normal,
          width: cardWidth
        }
      });
    }
    if ($$self.$$.dirty & /*imageUrl*/
    1) {
      $$invalidate(8, showImage = !!imageUrl);
    }
  };
  return [
    imageUrl,
    heading,
    description,
    linkText,
    linkUrl,
    linkColor,
    linkHoverColor,
    imageHeight,
    showImage,
    cardStyles,
    styleable,
    linkable,
    component,
    className,
    cardWidth,
    $component
  ];
}
class Card extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      className: 13,
      imageUrl: 0,
      heading: 1,
      description: 2,
      linkText: 3,
      linkUrl: 4,
      linkColor: 5,
      linkHoverColor: 6,
      imageHeight: 7,
      cardWidth: 14
    });
  }
  get className() {
    return this.$$.ctx[13];
  }
}
export {
  Card as default
};
