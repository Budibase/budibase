import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, t as text, b as attr, f as insert, g as append, j as set_data, Q as add_render_callback, R as create_bidirectional_transition, T as slide, o as detach, F as create_slot, a as space, d as toggle_class, l as listen, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, k as transition_in, z as group_outros, n as transition_out, A as check_outros, u as getContext, U as onMount, I as Icon, c as create_component, m as mount_component, p as destroy_component, V as bubble, W as binding_callbacks, X as setContext, Y as createEventDispatcher, y as empty, r as run_all, Z as create_in_transition, _ as fade, B as noop, $ as Popover, a0 as bind, h as is_function, q as action_destroyer, a1 as add_flush_callback, a2 as derived, a3 as writable, v as component_subscribe, a4 as ModalContent, a5 as Body, a6 as notifications, a7 as Input, a8 as loc, a9 as parse, aa as screenStore, ab as builderStore, C as subscribe, N as ensure_array_like, O as destroy_each, ac as Modal, ad as API, ae as src_url_equal, af as clickOutside, ag as Heading, ah as Roles, ai as getActiveConditions, aj as reduceConditionActions } from "./index-8b9900f1.js";
import { M as Menu, I as Item } from "./Item-43bbcac6.js";
import { U as UserAvatar } from "./UserAvatar-4b1adc76.js";
import { h as hasBuilderPermissions } from "./users-bee20df5.js";
function isSSOUser(user) {
  return !!user.providerType;
}
function create_fragment$c(ctx) {
  let div;
  let t;
  let div_transition;
  let current;
  return {
    c() {
      div = element("div");
      t = text(
        /*error*/
        ctx[0]
      );
      attr(div, "class", "error-message svelte-wciay3");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (!current || dirty & /*error*/
      1)
        set_data(
          t,
          /*error*/
          ctx2[0]
        );
    },
    i(local) {
      if (current)
        return;
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div_transition)
            div_transition = create_bidirectional_transition(div, slide, { duration: 130 }, true);
          div_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      if (local) {
        if (!div_transition)
          div_transition = create_bidirectional_transition(div, slide, { duration: 130 }, false);
        div_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (detaching && div_transition)
        div_transition.end();
    }
  };
}
function instance$c($$self, $$props, $$invalidate) {
  let { error = null } = $$props;
  $$self.$$set = ($$props2) => {
    if ("error" in $$props2)
      $$invalidate(0, error = $$props2.error);
  };
  return [error];
}
class ErrorMessage extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$c, create_fragment$c, safe_not_equal, { error: 0 });
  }
}
function create_if_block_1$5(ctx) {
  let div;
  let icon;
  let current;
  icon = new Icon({ props: { name: "warning" } });
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      attr(div, "class", "error-icon svelte-1nk7anx");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
    }
  };
}
function create_if_block$5(ctx) {
  let errormessage;
  let current;
  errormessage = new ErrorMessage({ props: { error: (
    /*error*/
    ctx[0]
  ) } });
  return {
    c() {
      create_component(errormessage.$$.fragment);
    },
    m(target, anchor) {
      mount_component(errormessage, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const errormessage_changes = {};
      if (dirty & /*error*/
      1)
        errormessage_changes.error = /*error*/
        ctx2[0];
      errormessage.$set(errormessage_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(errormessage.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(errormessage.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(errormessage, detaching);
    }
  };
}
function create_fragment$b(ctx) {
  let div2;
  let div1;
  let div0;
  let t0;
  let t1;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[10].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[9],
    null
  );
  let if_block0 = (
    /*error*/
    ctx[0] && create_if_block_1$5()
  );
  let if_block1 = (
    /*error*/
    ctx[0] && create_if_block$5(ctx)
  );
  return {
    c() {
      div2 = element("div");
      div1 = element("div");
      div0 = element("div");
      if (default_slot)
        default_slot.c();
      t0 = space();
      if (if_block0)
        if_block0.c();
      t1 = space();
      if (if_block1)
        if_block1.c();
      attr(div0, "class", "field svelte-1nk7anx");
      attr(div1, "class", "content svelte-1nk7anx");
      attr(div2, "class", "fancy-field svelte-1nk7anx");
      toggle_class(
        div2,
        "error",
        /*error*/
        ctx[0]
      );
      toggle_class(
        div2,
        "disabled",
        /*disabled*/
        ctx[2]
      );
      toggle_class(
        div2,
        "focused",
        /*focused*/
        ctx[3]
      );
      toggle_class(
        div2,
        "clickable",
        /*clickable*/
        ctx[4]
      );
      toggle_class(
        div2,
        "compact",
        /*compact*/
        ctx[6]
      );
      toggle_class(
        div2,
        "auto-height",
        /*autoHeight*/
        ctx[5]
      );
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, div1);
      append(div1, div0);
      if (default_slot) {
        default_slot.m(div0, null);
      }
      append(div1, t0);
      if (if_block0)
        if_block0.m(div1, null);
      append(div2, t1);
      if (if_block1)
        if_block1.m(div2, null);
      ctx[12](div2);
      current = true;
      if (!mounted) {
        dispose = listen(
          div1,
          "click",
          /*click_handler*/
          ctx[11]
        );
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        512)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[9],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[9]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[9],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (
        /*error*/
        ctx2[0]
      ) {
        if (if_block0) {
          if (dirty & /*error*/
          1) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_1$5();
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(div1, null);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (
        /*error*/
        ctx2[0]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty & /*error*/
          1) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block$5(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div2, null);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if (!current || dirty & /*error*/
      1) {
        toggle_class(
          div2,
          "error",
          /*error*/
          ctx2[0]
        );
      }
      if (!current || dirty & /*disabled*/
      4) {
        toggle_class(
          div2,
          "disabled",
          /*disabled*/
          ctx2[2]
        );
      }
      if (!current || dirty & /*focused*/
      8) {
        toggle_class(
          div2,
          "focused",
          /*focused*/
          ctx2[3]
        );
      }
      if (!current || dirty & /*clickable*/
      16) {
        toggle_class(
          div2,
          "clickable",
          /*clickable*/
          ctx2[4]
        );
      }
      if (!current || dirty & /*compact*/
      64) {
        toggle_class(
          div2,
          "compact",
          /*compact*/
          ctx2[6]
        );
      }
      if (!current || dirty & /*autoHeight*/
      32) {
        toggle_class(
          div2,
          "auto-height",
          /*autoHeight*/
          ctx2[5]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div2);
      }
      if (default_slot)
        default_slot.d(detaching);
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
      ctx[12](null);
      mounted = false;
      dispose();
    }
  };
}
function instance$b($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { disabled = false } = $$props;
  let { error = null } = $$props;
  let { focused = false } = $$props;
  let { clickable = false } = $$props;
  let { validate: validate2 } = $$props;
  let { value } = $$props;
  let { ref = void 0 } = $$props;
  let { autoHeight = void 0 } = $$props;
  let { compact = false } = $$props;
  const formContext = getContext("fancy-form");
  const id = Math.random().toString();
  const API2 = {
    validate: () => {
      if (validate2) {
        $$invalidate(0, error = validate2(value));
      }
      return !error;
    }
  };
  onMount(() => {
    if (formContext) {
      formContext.registerField(id, API2);
    }
    return () => {
      if (formContext) {
        formContext.unregisterField(id);
      }
    };
  });
  function click_handler(event) {
    bubble.call(this, $$self, event);
  }
  function div2_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      ref = $$value;
      $$invalidate(1, ref);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("disabled" in $$props2)
      $$invalidate(2, disabled = $$props2.disabled);
    if ("error" in $$props2)
      $$invalidate(0, error = $$props2.error);
    if ("focused" in $$props2)
      $$invalidate(3, focused = $$props2.focused);
    if ("clickable" in $$props2)
      $$invalidate(4, clickable = $$props2.clickable);
    if ("validate" in $$props2)
      $$invalidate(7, validate2 = $$props2.validate);
    if ("value" in $$props2)
      $$invalidate(8, value = $$props2.value);
    if ("ref" in $$props2)
      $$invalidate(1, ref = $$props2.ref);
    if ("autoHeight" in $$props2)
      $$invalidate(5, autoHeight = $$props2.autoHeight);
    if ("compact" in $$props2)
      $$invalidate(6, compact = $$props2.compact);
    if ("$$scope" in $$props2)
      $$invalidate(9, $$scope = $$props2.$$scope);
  };
  return [
    error,
    ref,
    disabled,
    focused,
    clickable,
    autoHeight,
    compact,
    validate2,
    value,
    $$scope,
    slots,
    click_handler,
    div2_binding
  ];
}
class FancyField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$b, create_fragment$b, safe_not_equal, {
      disabled: 2,
      error: 0,
      focused: 3,
      clickable: 4,
      validate: 7,
      value: 8,
      ref: 1,
      autoHeight: 5,
      compact: 6
    });
  }
}
function create_fragment$a(ctx) {
  let div;
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[2].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[1],
    null
  );
  return {
    c() {
      div = element("div");
      if (default_slot)
        default_slot.c();
      attr(div, "class", "svelte-wcobo1");
      toggle_class(
        div,
        "placeholder",
        /*placeholder*/
        ctx[0]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (default_slot) {
        default_slot.m(div, null);
      }
      current = true;
    },
    p(ctx2, [dirty]) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        2)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[1],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[1]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[1],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*placeholder*/
      1) {
        toggle_class(
          div,
          "placeholder",
          /*placeholder*/
          ctx2[0]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function instance$a($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { placeholder = true } = $$props;
  $$self.$$set = ($$props2) => {
    if ("placeholder" in $$props2)
      $$invalidate(0, placeholder = $$props2.placeholder);
    if ("$$scope" in $$props2)
      $$invalidate(1, $$scope = $$props2.$$scope);
  };
  return [placeholder, $$scope, slots];
}
class FancyFieldLabel extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$a, create_fragment$a, safe_not_equal, { placeholder: 0 });
  }
}
function create_fragment$9(ctx) {
  let div;
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[2].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[1],
    null
  );
  return {
    c() {
      div = element("div");
      if (default_slot)
        default_slot.c();
      attr(div, "class", "fancy-form svelte-1wjd4hl");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (default_slot) {
        default_slot.m(div, null);
      }
      current = true;
    },
    p(ctx2, [dirty]) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        2)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[1],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[1]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[1],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function instance$9($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let fields = {};
  setContext("fancy-form", {
    registerField: (id, api) => {
      fields = { ...fields, [id]: api };
    },
    unregisterField: (id) => {
      delete fields[id];
      fields = fields;
    }
  });
  const validate2 = () => {
    let valid = true;
    Object.values(fields).forEach((api) => {
      if (!api.validate()) {
        valid = false;
      }
    });
    return valid;
  };
  $$self.$$set = ($$props2) => {
    if ("$$scope" in $$props2)
      $$invalidate(1, $$scope = $$props2.$$scope);
  };
  return [validate2, $$scope, slots];
}
class FancyForm extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$9, create_fragment$9, safe_not_equal, { validate: 0 });
  }
  get validate() {
    return this.$$.ctx[0];
  }
}
function create_if_block_1$4(ctx) {
  let fancyfieldlabel;
  let current;
  fancyfieldlabel = new FancyFieldLabel({
    props: {
      placeholder: (
        /*placeholder*/
        ctx[9]
      ),
      $$slots: { default: [create_default_slot_1$4] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(fancyfieldlabel.$$.fragment);
    },
    m(target, anchor) {
      mount_component(fancyfieldlabel, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const fancyfieldlabel_changes = {};
      if (dirty & /*placeholder*/
      512)
        fancyfieldlabel_changes.placeholder = /*placeholder*/
        ctx2[9];
      if (dirty & /*$$scope, label*/
      131076) {
        fancyfieldlabel_changes.$$scope = { dirty, ctx: ctx2 };
      }
      fancyfieldlabel.$set(fancyfieldlabel_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(fancyfieldlabel.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(fancyfieldlabel.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(fancyfieldlabel, detaching);
    }
  };
}
function create_default_slot_1$4(ctx) {
  let t;
  return {
    c() {
      t = text(
        /*label*/
        ctx[2]
      );
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*label*/
      4)
        set_data(
          t,
          /*label*/
          ctx2[2]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block$4(ctx) {
  let div;
  let t;
  let div_intro;
  return {
    c() {
      div = element("div");
      t = text(
        /*suffix*/
        ctx[6]
      );
      attr(div, "class", "suffix svelte-2823mm");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*suffix*/
      64)
        set_data(
          t,
          /*suffix*/
          ctx2[6]
        );
    },
    i(local) {
      if (local) {
        if (!div_intro) {
          add_render_callback(() => {
            div_intro = create_in_transition(div, fade, { duration: 130 });
            div_intro.start();
          });
        }
      }
    },
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_default_slot$6(ctx) {
  let t0;
  let input;
  let input_value_value;
  let input_type_value;
  let t1;
  let if_block1_anchor;
  let current;
  let mounted;
  let dispose;
  let if_block0 = (
    /*label*/
    ctx[2] && create_if_block_1$4(ctx)
  );
  let if_block1 = (
    /*suffix*/
    ctx[6] && !/*placeholder*/
    ctx[9] && create_if_block$4(ctx)
  );
  return {
    c() {
      if (if_block0)
        if_block0.c();
      t0 = space();
      input = element("input");
      t1 = space();
      if (if_block1)
        if_block1.c();
      if_block1_anchor = empty();
      input.disabled = /*disabled*/
      ctx[4];
      input.value = input_value_value = /*value*/
      ctx[0] || "";
      attr(input, "type", input_type_value = /*type*/
      ctx[3] || "text");
      attr(input, "class", "svelte-2823mm");
      toggle_class(
        input,
        "placeholder",
        /*placeholder*/
        ctx[9]
      );
    },
    m(target, anchor) {
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t0, anchor);
      insert(target, input, anchor);
      ctx[15](input);
      insert(target, t1, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, if_block1_anchor, anchor);
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            input,
            "input",
            /*onChange*/
            ctx[10]
          ),
          listen(
            input,
            "focus",
            /*focus_handler*/
            ctx[14]
          ),
          listen(
            input,
            "blur",
            /*onBlur*/
            ctx[11]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (
        /*label*/
        ctx2[2]
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty & /*label*/
          4) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_1$4(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(t0.parentNode, t0);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (!current || dirty & /*disabled*/
      16) {
        input.disabled = /*disabled*/
        ctx2[4];
      }
      if (!current || dirty & /*value*/
      1 && input_value_value !== (input_value_value = /*value*/
      ctx2[0] || "") && input.value !== input_value_value) {
        input.value = input_value_value;
      }
      if (!current || dirty & /*type*/
      8 && input_type_value !== (input_type_value = /*type*/
      ctx2[3] || "text")) {
        attr(input, "type", input_type_value);
      }
      if (!current || dirty & /*placeholder*/
      512) {
        toggle_class(
          input,
          "placeholder",
          /*placeholder*/
          ctx2[9]
        );
      }
      if (
        /*suffix*/
        ctx2[6] && !/*placeholder*/
        ctx2[9]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty & /*suffix, placeholder*/
          576) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block$4(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(if_block1_anchor.parentNode, if_block1_anchor);
        }
      } else if (if_block1) {
        if_block1.d(1);
        if_block1 = null;
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(input);
        detach(t1);
        detach(if_block1_anchor);
      }
      if (if_block0)
        if_block0.d(detaching);
      ctx[15](null);
      if (if_block1)
        if_block1.d(detaching);
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_fragment$8(ctx) {
  let fancyfield;
  let current;
  fancyfield = new FancyField({
    props: {
      error: (
        /*error*/
        ctx[1]
      ),
      value: (
        /*value*/
        ctx[0]
      ),
      validate: (
        /*validate*/
        ctx[5]
      ),
      disabled: (
        /*disabled*/
        ctx[4]
      ),
      focused: (
        /*focused*/
        ctx[7]
      ),
      $$slots: { default: [create_default_slot$6] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(fancyfield.$$.fragment);
    },
    m(target, anchor) {
      mount_component(fancyfield, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const fancyfield_changes = {};
      if (dirty & /*error*/
      2)
        fancyfield_changes.error = /*error*/
        ctx2[1];
      if (dirty & /*value*/
      1)
        fancyfield_changes.value = /*value*/
        ctx2[0];
      if (dirty & /*validate*/
      32)
        fancyfield_changes.validate = /*validate*/
        ctx2[5];
      if (dirty & /*disabled*/
      16)
        fancyfield_changes.disabled = /*disabled*/
        ctx2[4];
      if (dirty & /*focused*/
      128)
        fancyfield_changes.focused = /*focused*/
        ctx2[7];
      if (dirty & /*$$scope, suffix, placeholder, disabled, value, type, ref, focused, label*/
      132061) {
        fancyfield_changes.$$scope = { dirty, ctx: ctx2 };
      }
      fancyfield.$set(fancyfield_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(fancyfield.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(fancyfield.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(fancyfield, detaching);
    }
  };
}
function instance$8($$self, $$props, $$invalidate) {
  let placeholder;
  let { label } = $$props;
  let { value } = $$props;
  let { type = "text" } = $$props;
  let { disabled = false } = $$props;
  let { error = null } = $$props;
  let { validate: validate2 = null } = $$props;
  let { suffix = null } = $$props;
  let { validateOn = "change" } = $$props;
  const dispatch = createEventDispatcher();
  let ref;
  let focused = false;
  let autofilled = false;
  const onChange = (e) => {
    const newValue = e.target.value;
    dispatch("change", newValue);
    $$invalidate(0, value = newValue);
    if (validate2 && (error || validateOn === "change")) {
      $$invalidate(1, error = validate2(newValue));
    }
  };
  const onBlur = (e) => {
    $$invalidate(7, focused = false);
    const newValue = e.target.value;
    dispatch("blur", newValue);
    if (validate2 && validateOn === "blur") {
      $$invalidate(1, error = validate2(newValue));
    }
  };
  onMount(() => {
    const interval = setInterval(
      () => {
        $$invalidate(13, autofilled = ref == null ? void 0 : ref.matches(":-webkit-autofill"));
        if (autofilled) {
          clearInterval(interval);
        }
      },
      100
    );
    const timeout = setTimeout(
      () => {
        clearInterval(interval);
      },
      2e3
    );
    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  });
  const focus_handler = () => $$invalidate(7, focused = true);
  function input_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      ref = $$value;
      $$invalidate(8, ref);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("label" in $$props2)
      $$invalidate(2, label = $$props2.label);
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("type" in $$props2)
      $$invalidate(3, type = $$props2.type);
    if ("disabled" in $$props2)
      $$invalidate(4, disabled = $$props2.disabled);
    if ("error" in $$props2)
      $$invalidate(1, error = $$props2.error);
    if ("validate" in $$props2)
      $$invalidate(5, validate2 = $$props2.validate);
    if ("suffix" in $$props2)
      $$invalidate(6, suffix = $$props2.suffix);
    if ("validateOn" in $$props2)
      $$invalidate(12, validateOn = $$props2.validateOn);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*autofilled, focused, value*/
    8321) {
      $$invalidate(9, placeholder = !autofilled && !focused && !value);
    }
  };
  return [
    value,
    error,
    label,
    type,
    disabled,
    validate2,
    suffix,
    focused,
    ref,
    placeholder,
    onChange,
    onBlur,
    validateOn,
    autofilled,
    focus_handler,
    input_binding
  ];
}
class FancyInput extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$8, create_fragment$8, safe_not_equal, {
      label: 2,
      value: 0,
      type: 3,
      disabled: 4,
      error: 1,
      validate: 5,
      suffix: 6,
      validateOn: 12
    });
  }
}
const get_control_slot_changes = (dirty) => ({ open: dirty & /*open*/
1024 });
const get_control_slot_context = (ctx) => ({ open: (
  /*open*/
  ctx[10]
) });
function create_default_slot_1$3(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[17].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[22],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        4194304)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[22],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[22]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[22],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_default_slot$5(ctx) {
  let menu;
  let current;
  menu = new Menu({
    props: {
      $$slots: { default: [create_default_slot_1$3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(menu.$$.fragment);
    },
    m(target, anchor) {
      mount_component(menu, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const menu_changes = {};
      if (dirty & /*$$scope*/
      4194304) {
        menu_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menu.$set(menu_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(menu.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(menu.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(menu, detaching);
    }
  };
}
function create_fragment$7(ctx) {
  let div;
  let t;
  let popover;
  let updating_open;
  let current;
  let mounted;
  let dispose;
  const control_slot_template = (
    /*#slots*/
    ctx[17].control
  );
  const control_slot = create_slot(
    control_slot_template,
    ctx,
    /*$$scope*/
    ctx[22],
    get_control_slot_context
  );
  function popover_open_binding(value) {
    ctx[19](value);
  }
  let popover_props = {
    anchor: (
      /*anchor*/
      ctx[8]
    ),
    align: (
      /*align*/
      ctx[0]
    ),
    portalTarget: (
      /*portalTarget*/
      ctx[1]
    ),
    animate: (
      /*animate*/
      ctx[3]
    ),
    offset: (
      /*offset*/
      ctx[4]
    ),
    useAnchorWidth: (
      /*useAnchorWidth*/
      ctx[5]
    ),
    resizable: false,
    borderRadius: (
      /*roundedPopover*/
      ctx[6] ? "12px" : void 0
    ),
    $$slots: { default: [create_default_slot$5] },
    $$scope: { ctx }
  };
  if (
    /*open*/
    ctx[10] !== void 0
  ) {
    popover_props.open = /*open*/
    ctx[10];
  }
  popover = new Popover({ props: popover_props });
  ctx[18](popover);
  binding_callbacks.push(() => bind(popover, "open", popover_open_binding));
  popover.$on(
    "open",
    /*open_handler*/
    ctx[20]
  );
  popover.$on(
    "close",
    /*close_handler*/
    ctx[21]
  );
  popover.$on("mouseenter", function() {
    if (is_function(
      /*openOnHover*/
      ctx[2] ? (
        /*cancelHide*/
        ctx[14]
      ) : null
    ))
      /*openOnHover*/
      (ctx[2] ? (
        /*cancelHide*/
        ctx[14]
      ) : null).apply(this, arguments);
  });
  popover.$on("mouseleave", function() {
    if (is_function(
      /*openOnHover*/
      ctx[2] ? (
        /*queueHide*/
        ctx[13]
      ) : null
    ))
      /*openOnHover*/
      (ctx[2] ? (
        /*queueHide*/
        ctx[13]
      ) : null).apply(this, arguments);
  });
  return {
    c() {
      div = element("div");
      if (control_slot)
        control_slot.c();
      t = space();
      create_component(popover.$$.fragment);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (control_slot) {
        control_slot.m(div, null);
      }
      insert(target, t, anchor);
      mount_component(popover, target, anchor);
      current = true;
      if (!mounted) {
        dispose = [
          action_destroyer(
            /*getAnchor*/
            ctx[11].call(null, div)
          ),
          listen(div, "click", function() {
            if (is_function(
              /*openOnHover*/
              ctx[2] ? null : (
                /*openMenu*/
                ctx[12]
              )
            ))
              /*openOnHover*/
              (ctx[2] ? null : (
                /*openMenu*/
                ctx[12]
              )).apply(this, arguments);
          }),
          listen(div, "mouseenter", function() {
            if (is_function(
              /*openOnHover*/
              ctx[2] ? (
                /*show*/
                ctx[7]
              ) : null
            ))
              /*openOnHover*/
              (ctx[2] ? (
                /*show*/
                ctx[7]
              ) : null).apply(this, arguments);
          }),
          listen(div, "mouseleave", function() {
            if (is_function(
              /*openOnHover*/
              ctx[2] ? (
                /*queueHide*/
                ctx[13]
              ) : null
            ))
              /*openOnHover*/
              (ctx[2] ? (
                /*queueHide*/
                ctx[13]
              ) : null).apply(this, arguments);
          })
        ];
        mounted = true;
      }
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      if (control_slot) {
        if (control_slot.p && (!current || dirty & /*$$scope, open*/
        4195328)) {
          update_slot_base(
            control_slot,
            control_slot_template,
            ctx,
            /*$$scope*/
            ctx[22],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx[22]
            ) : get_slot_changes(
              control_slot_template,
              /*$$scope*/
              ctx[22],
              dirty,
              get_control_slot_changes
            ),
            get_control_slot_context
          );
        }
      }
      const popover_changes = {};
      if (dirty & /*anchor*/
      256)
        popover_changes.anchor = /*anchor*/
        ctx[8];
      if (dirty & /*align*/
      1)
        popover_changes.align = /*align*/
        ctx[0];
      if (dirty & /*portalTarget*/
      2)
        popover_changes.portalTarget = /*portalTarget*/
        ctx[1];
      if (dirty & /*animate*/
      8)
        popover_changes.animate = /*animate*/
        ctx[3];
      if (dirty & /*offset*/
      16)
        popover_changes.offset = /*offset*/
        ctx[4];
      if (dirty & /*useAnchorWidth*/
      32)
        popover_changes.useAnchorWidth = /*useAnchorWidth*/
        ctx[5];
      if (dirty & /*roundedPopover*/
      64)
        popover_changes.borderRadius = /*roundedPopover*/
        ctx[6] ? "12px" : void 0;
      if (dirty & /*$$scope*/
      4194304) {
        popover_changes.$$scope = { dirty, ctx };
      }
      if (!updating_open && dirty & /*open*/
      1024) {
        updating_open = true;
        popover_changes.open = /*open*/
        ctx[10];
        add_flush_callback(() => updating_open = false);
      }
      popover.$set(popover_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(control_slot, local);
      transition_in(popover.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(control_slot, local);
      transition_out(popover.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
        detach(t);
      }
      if (control_slot)
        control_slot.d(detaching);
      ctx[18](null);
      destroy_component(popover, detaching);
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance$7($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { disabled = false } = $$props;
  let { align = "left" } = $$props;
  let { portalTarget = void 0 } = $$props;
  let { openOnHover = false } = $$props;
  let { animate = true } = $$props;
  let { offset = void 0 } = $$props;
  let { useAnchorWidth = false } = $$props;
  let { roundedPopover = false } = $$props;
  const actionMenuContext = getContext("actionMenu");
  let anchor;
  let dropdown;
  let timeout;
  let open = false;
  function getAnchor(node) {
    $$invalidate(8, anchor = node.firstChild ?? void 0);
  }
  const show = () => {
    cancelHide();
    dropdown.show();
  };
  const hide = () => {
    dropdown.hide();
  };
  const hideAll = () => {
    hide();
    actionMenuContext == null ? void 0 : actionMenuContext.hide();
  };
  const openMenu = (event) => {
    if (!disabled) {
      event.stopPropagation();
      show();
    }
  };
  const queueHide = () => {
    timeout = setTimeout(hide, 10);
  };
  const cancelHide = () => {
    clearTimeout(timeout);
  };
  setContext("actionMenu", { show, hide, hideAll });
  function popover_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      dropdown = $$value;
      $$invalidate(9, dropdown);
    });
  }
  function popover_open_binding(value) {
    open = value;
    $$invalidate(10, open);
  }
  function open_handler(event) {
    bubble.call(this, $$self, event);
  }
  function close_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("disabled" in $$props2)
      $$invalidate(15, disabled = $$props2.disabled);
    if ("align" in $$props2)
      $$invalidate(0, align = $$props2.align);
    if ("portalTarget" in $$props2)
      $$invalidate(1, portalTarget = $$props2.portalTarget);
    if ("openOnHover" in $$props2)
      $$invalidate(2, openOnHover = $$props2.openOnHover);
    if ("animate" in $$props2)
      $$invalidate(3, animate = $$props2.animate);
    if ("offset" in $$props2)
      $$invalidate(4, offset = $$props2.offset);
    if ("useAnchorWidth" in $$props2)
      $$invalidate(5, useAnchorWidth = $$props2.useAnchorWidth);
    if ("roundedPopover" in $$props2)
      $$invalidate(6, roundedPopover = $$props2.roundedPopover);
    if ("$$scope" in $$props2)
      $$invalidate(22, $$scope = $$props2.$$scope);
  };
  return [
    align,
    portalTarget,
    openOnHover,
    animate,
    offset,
    useAnchorWidth,
    roundedPopover,
    show,
    anchor,
    dropdown,
    open,
    getAnchor,
    openMenu,
    queueHide,
    cancelHide,
    disabled,
    hide,
    slots,
    popover_binding,
    popover_open_binding,
    open_handler,
    close_handler,
    $$scope
  ];
}
class ActionMenu extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$7, create_fragment$7, safe_not_equal, {
      disabled: 15,
      align: 0,
      portalTarget: 1,
      openOnHover: 2,
      animate: 3,
      offset: 4,
      useAnchorWidth: 5,
      roundedPopover: 6,
      show: 7,
      hide: 16
    });
  }
  get show() {
    return this.$$.ctx[7];
  }
  get hide() {
    return this.$$.ctx[16];
  }
}
function requiredValidator(value) {
  return value !== void 0 && value !== null && value !== "" || "This field is required";
}
function createValidationStore(initialValue, ...validators) {
  let touched = false;
  const value = writable(initialValue || "");
  const touchedStore = derived(value, () => {
    if (!touched) {
      touched = true;
      return false;
    }
    return touched;
  });
  const error = derived(
    [value, touchedStore],
    ([$v, $t]) => $t && validate($v, validators)
  );
  return [value, error, touchedStore];
}
function validate(value, validators) {
  const failing = validators.find((v) => v(value) !== true);
  return failing && failing(value);
}
function create_default_slot$4(ctx) {
  let fancyinput0;
  let updating_value;
  let t;
  let fancyinput1;
  let updating_value_1;
  let current;
  function fancyinput0_value_binding(value) {
    ctx[15](value);
  }
  let fancyinput0_props = {
    label: "Password",
    type: "password",
    error: (
      /*firstPasswordError*/
      ctx[1]
    )
  };
  if (
    /*$firstPassword*/
    ctx[3] !== void 0
  ) {
    fancyinput0_props.value = /*$firstPassword*/
    ctx[3];
  }
  fancyinput0 = new FancyInput({ props: fancyinput0_props });
  binding_callbacks.push(() => bind(fancyinput0, "value", fancyinput0_value_binding));
  function fancyinput1_value_binding(value) {
    ctx[16](value);
  }
  let fancyinput1_props = {
    label: "Repeat password",
    type: "password",
    error: (
      /*$repeatTouched*/
      ctx[4] && /*$firstPassword*/
      ctx[3] !== /*$repeatPassword*/
      ctx[2] && "Passwords must match"
    )
  };
  if (
    /*$repeatPassword*/
    ctx[2] !== void 0
  ) {
    fancyinput1_props.value = /*$repeatPassword*/
    ctx[2];
  }
  fancyinput1 = new FancyInput({ props: fancyinput1_props });
  binding_callbacks.push(() => bind(fancyinput1, "value", fancyinput1_value_binding));
  return {
    c() {
      create_component(fancyinput0.$$.fragment);
      t = space();
      create_component(fancyinput1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(fancyinput0, target, anchor);
      insert(target, t, anchor);
      mount_component(fancyinput1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const fancyinput0_changes = {};
      if (dirty & /*firstPasswordError*/
      2)
        fancyinput0_changes.error = /*firstPasswordError*/
        ctx2[1];
      if (!updating_value && dirty & /*$firstPassword*/
      8) {
        updating_value = true;
        fancyinput0_changes.value = /*$firstPassword*/
        ctx2[3];
        add_flush_callback(() => updating_value = false);
      }
      fancyinput0.$set(fancyinput0_changes);
      const fancyinput1_changes = {};
      if (dirty & /*$repeatTouched, $firstPassword, $repeatPassword*/
      28)
        fancyinput1_changes.error = /*$repeatTouched*/
        ctx2[4] && /*$firstPassword*/
        ctx2[3] !== /*$repeatPassword*/
        ctx2[2] && "Passwords must match";
      if (!updating_value_1 && dirty & /*$repeatPassword*/
      4) {
        updating_value_1 = true;
        fancyinput1_changes.value = /*$repeatPassword*/
        ctx2[2];
        add_flush_callback(() => updating_value_1 = false);
      }
      fancyinput1.$set(fancyinput1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(fancyinput0.$$.fragment, local);
      transition_in(fancyinput1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(fancyinput0.$$.fragment, local);
      transition_out(fancyinput1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(fancyinput0, detaching);
      destroy_component(fancyinput1, detaching);
    }
  };
}
function create_fragment$6(ctx) {
  let fancyform;
  let current;
  let fancyform_props = {
    $$slots: { default: [create_default_slot$4] },
    $$scope: { ctx }
  };
  fancyform = new FancyForm({ props: fancyform_props });
  ctx[17](fancyform);
  return {
    c() {
      create_component(fancyform.$$.fragment);
    },
    m(target, anchor) {
      mount_component(fancyform, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const fancyform_changes = {};
      if (dirty & /*$$scope, $repeatTouched, $firstPassword, $repeatPassword, firstPasswordError*/
      1048606) {
        fancyform_changes.$$scope = { dirty, ctx: ctx2 };
      }
      fancyform.$set(fancyform_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(fancyform.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(fancyform.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      ctx[17](null);
      destroy_component(fancyform, detaching);
    }
  };
}
function instance$6($$self, $$props, $$invalidate) {
  let firstPasswordError;
  let $repeatPassword;
  let $firstPassword;
  let $repeatTouched;
  let $firstTouched;
  let $passwordError;
  let { passwordForm = void 0 } = $$props;
  let { password } = $$props;
  let { error } = $$props;
  let { minLength = "12" } = $$props;
  const validatePassword = (value) => {
    if (!value || value.length < parseInt(minLength)) {
      return `Please enter at least ${minLength} characters. We recommend using machine generated or random passwords.`;
    }
    return null;
  };
  const [firstPassword, passwordError, firstTouched] = createValidationStore("", requiredValidator);
  component_subscribe($$self, firstPassword, (value) => $$invalidate(3, $firstPassword = value));
  component_subscribe($$self, passwordError, (value) => $$invalidate(14, $passwordError = value));
  component_subscribe($$self, firstTouched, (value) => $$invalidate(13, $firstTouched = value));
  const [repeatPassword, _, repeatTouched] = createValidationStore("", requiredValidator, validatePassword);
  component_subscribe($$self, repeatPassword, (value) => $$invalidate(2, $repeatPassword = value));
  component_subscribe($$self, repeatTouched, (value) => $$invalidate(4, $repeatTouched = value));
  function fancyinput0_value_binding(value) {
    $firstPassword = value;
    firstPassword.set($firstPassword);
  }
  function fancyinput1_value_binding(value) {
    $repeatPassword = value;
    repeatPassword.set($repeatPassword);
  }
  function fancyform_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      passwordForm = $$value;
      $$invalidate(0, passwordForm);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("passwordForm" in $$props2)
      $$invalidate(0, passwordForm = $$props2.passwordForm);
    if ("password" in $$props2)
      $$invalidate(10, password = $$props2.password);
    if ("error" in $$props2)
      $$invalidate(11, error = $$props2.error);
    if ("minLength" in $$props2)
      $$invalidate(12, minLength = $$props2.minLength);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$firstPassword*/
    8) {
      $$invalidate(10, password = $firstPassword);
    }
    if ($$self.$$.dirty & /*$firstTouched, $passwordError, $repeatTouched, password*/
    25616) {
      $$invalidate(1, firstPasswordError = $firstTouched && $passwordError || $repeatTouched && validatePassword(password));
    }
    if ($$self.$$.dirty & /*$firstPassword, $firstTouched, $repeatTouched, $repeatPassword, firstPasswordError*/
    8222) {
      $$invalidate(11, error = !$firstPassword || !$firstTouched || !$repeatTouched || $firstPassword !== $repeatPassword || firstPasswordError);
    }
  };
  return [
    passwordForm,
    firstPasswordError,
    $repeatPassword,
    $firstPassword,
    $repeatTouched,
    firstPassword,
    passwordError,
    firstTouched,
    repeatPassword,
    repeatTouched,
    password,
    error,
    minLength,
    $firstTouched,
    $passwordError,
    fancyinput0_value_binding,
    fancyinput1_value_binding,
    fancyform_binding
  ];
}
class PasswordRepeatInput extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$6, create_fragment$6, safe_not_equal, {
      passwordForm: 0,
      password: 10,
      error: 11,
      minLength: 12
    });
  }
}
function create_default_slot_1$2(ctx) {
  let t;
  return {
    c() {
      t = text("Enter your new password below.");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot$3(ctx) {
  let body;
  let t;
  let passwordrepeatinput;
  let updating_password;
  let updating_error;
  let current;
  body = new Body({
    props: {
      size: "S",
      $$slots: { default: [create_default_slot_1$2] },
      $$scope: { ctx }
    }
  });
  function passwordrepeatinput_password_binding(value) {
    ctx[8](value);
  }
  function passwordrepeatinput_error_binding(value) {
    ctx[9](value);
  }
  let passwordrepeatinput_props = { minLength: (
    /*passwordMinLength*/
    ctx[0]
  ) };
  if (
    /*password*/
    ctx[1] !== void 0
  ) {
    passwordrepeatinput_props.password = /*password*/
    ctx[1];
  }
  if (
    /*error*/
    ctx[2] !== void 0
  ) {
    passwordrepeatinput_props.error = /*error*/
    ctx[2];
  }
  passwordrepeatinput = new PasswordRepeatInput({ props: passwordrepeatinput_props });
  binding_callbacks.push(() => bind(passwordrepeatinput, "password", passwordrepeatinput_password_binding));
  binding_callbacks.push(() => bind(passwordrepeatinput, "error", passwordrepeatinput_error_binding));
  return {
    c() {
      create_component(body.$$.fragment);
      t = space();
      create_component(passwordrepeatinput.$$.fragment);
    },
    m(target, anchor) {
      mount_component(body, target, anchor);
      insert(target, t, anchor);
      mount_component(passwordrepeatinput, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const body_changes = {};
      if (dirty & /*$$scope*/
      2048) {
        body_changes.$$scope = { dirty, ctx: ctx2 };
      }
      body.$set(body_changes);
      const passwordrepeatinput_changes = {};
      if (dirty & /*passwordMinLength*/
      1)
        passwordrepeatinput_changes.minLength = /*passwordMinLength*/
        ctx2[0];
      if (!updating_password && dirty & /*password*/
      2) {
        updating_password = true;
        passwordrepeatinput_changes.password = /*password*/
        ctx2[1];
        add_flush_callback(() => updating_password = false);
      }
      if (!updating_error && dirty & /*error*/
      4) {
        updating_error = true;
        passwordrepeatinput_changes.error = /*error*/
        ctx2[2];
        add_flush_callback(() => updating_error = false);
      }
      passwordrepeatinput.$set(passwordrepeatinput_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(body.$$.fragment, local);
      transition_in(passwordrepeatinput.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(body.$$.fragment, local);
      transition_out(passwordrepeatinput.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(body, detaching);
      destroy_component(passwordrepeatinput, detaching);
    }
  };
}
function create_fragment$5(ctx) {
  let modalcontent;
  let current;
  let mounted;
  let dispose;
  modalcontent = new ModalContent({
    props: {
      title: "Update password",
      confirmText: "Update password",
      onConfirm: (
        /*updatePassword*/
        ctx[3]
      ),
      disabled: !!/*error*/
      ctx[2] || !/*password*/
      ctx[1],
      $$slots: { default: [create_default_slot$3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(modalcontent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(modalcontent, target, anchor);
      current = true;
      if (!mounted) {
        dispose = listen(
          window,
          "keydown",
          /*handleKeydown*/
          ctx[4]
        );
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      const modalcontent_changes = {};
      if (dirty & /*error, password*/
      6)
        modalcontent_changes.disabled = !!/*error*/
        ctx2[2] || !/*password*/
        ctx2[1];
      if (dirty & /*$$scope, passwordMinLength, password, error*/
      2055) {
        modalcontent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modalcontent.$set(modalcontent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(modalcontent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(modalcontent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(modalcontent, detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance$5($$self, $$props, $$invalidate) {
  let { API: API2 } = $$props;
  let { passwordMinLength = void 0 } = $$props;
  let { notifySuccess = notifications.success } = $$props;
  let { notifyError = notifications.error } = $$props;
  const dispatch = createEventDispatcher();
  let password = "";
  let error = "";
  const updatePassword = async () => {
    try {
      await API2.updateSelf({ password });
      notifySuccess("Password changed successfully");
      dispatch("save");
    } catch (error2) {
      notifyError("Failed to update password");
    }
  };
  const handleKeydown = (evt) => {
    if (evt.key === "Enter" && !error && password) {
      updatePassword();
    }
  };
  function passwordrepeatinput_password_binding(value) {
    password = value;
    $$invalidate(1, password);
  }
  function passwordrepeatinput_error_binding(value) {
    error = value;
    $$invalidate(2, error);
  }
  $$self.$$set = ($$props2) => {
    if ("API" in $$props2)
      $$invalidate(5, API2 = $$props2.API);
    if ("passwordMinLength" in $$props2)
      $$invalidate(0, passwordMinLength = $$props2.passwordMinLength);
    if ("notifySuccess" in $$props2)
      $$invalidate(6, notifySuccess = $$props2.notifySuccess);
    if ("notifyError" in $$props2)
      $$invalidate(7, notifyError = $$props2.notifyError);
  };
  return [
    passwordMinLength,
    password,
    error,
    updatePassword,
    handleKeydown,
    API2,
    notifySuccess,
    notifyError,
    passwordrepeatinput_password_binding,
    passwordrepeatinput_error_binding
  ];
}
class ChangePasswordModal extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$5, create_fragment$5, safe_not_equal, {
      API: 5,
      passwordMinLength: 0,
      notifySuccess: 6,
      notifyError: 7
    });
  }
}
function create_default_slot_1$1(ctx) {
  let t;
  return {
    c() {
      t = text("Personalise the platform by adding your first name and last name.");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot$2(ctx) {
  var _a;
  let body;
  let t0;
  let input0;
  let t1;
  let input1;
  let updating_value;
  let t2;
  let input2;
  let updating_value_1;
  let current;
  body = new Body({
    props: {
      size: "S",
      $$slots: { default: [create_default_slot_1$1] },
      $$scope: { ctx }
    }
  });
  input0 = new Input({
    props: {
      disabled: true,
      value: (
        /*user*/
        ((_a = ctx[0]) == null ? void 0 : _a.email) || ""
      ),
      label: "Email"
    }
  });
  function input1_value_binding(value) {
    ctx[7](value);
  }
  let input1_props = { label: "First name" };
  if (
    /*$values*/
    ctx[1].firstName !== void 0
  ) {
    input1_props.value = /*$values*/
    ctx[1].firstName;
  }
  input1 = new Input({ props: input1_props });
  binding_callbacks.push(() => bind(input1, "value", input1_value_binding));
  function input2_value_binding(value) {
    ctx[8](value);
  }
  let input2_props = { label: "Last name" };
  if (
    /*$values*/
    ctx[1].lastName !== void 0
  ) {
    input2_props.value = /*$values*/
    ctx[1].lastName;
  }
  input2 = new Input({ props: input2_props });
  binding_callbacks.push(() => bind(input2, "value", input2_value_binding));
  return {
    c() {
      create_component(body.$$.fragment);
      t0 = space();
      create_component(input0.$$.fragment);
      t1 = space();
      create_component(input1.$$.fragment);
      t2 = space();
      create_component(input2.$$.fragment);
    },
    m(target, anchor) {
      mount_component(body, target, anchor);
      insert(target, t0, anchor);
      mount_component(input0, target, anchor);
      insert(target, t1, anchor);
      mount_component(input1, target, anchor);
      insert(target, t2, anchor);
      mount_component(input2, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      const body_changes = {};
      if (dirty & /*$$scope*/
      1024) {
        body_changes.$$scope = { dirty, ctx: ctx2 };
      }
      body.$set(body_changes);
      const input0_changes = {};
      if (dirty & /*user*/
      1)
        input0_changes.value = /*user*/
        ((_a2 = ctx2[0]) == null ? void 0 : _a2.email) || "";
      input0.$set(input0_changes);
      const input1_changes = {};
      if (!updating_value && dirty & /*$values*/
      2) {
        updating_value = true;
        input1_changes.value = /*$values*/
        ctx2[1].firstName;
        add_flush_callback(() => updating_value = false);
      }
      input1.$set(input1_changes);
      const input2_changes = {};
      if (!updating_value_1 && dirty & /*$values*/
      2) {
        updating_value_1 = true;
        input2_changes.value = /*$values*/
        ctx2[1].lastName;
        add_flush_callback(() => updating_value_1 = false);
      }
      input2.$set(input2_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(body.$$.fragment, local);
      transition_in(input0.$$.fragment, local);
      transition_in(input1.$$.fragment, local);
      transition_in(input2.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(body.$$.fragment, local);
      transition_out(input0.$$.fragment, local);
      transition_out(input1.$$.fragment, local);
      transition_out(input2.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
      }
      destroy_component(body, detaching);
      destroy_component(input0, detaching);
      destroy_component(input1, detaching);
      destroy_component(input2, detaching);
    }
  };
}
function create_fragment$4(ctx) {
  let modalcontent;
  let current;
  modalcontent = new ModalContent({
    props: {
      title: "My profile",
      confirmText: "Save",
      onConfirm: (
        /*updateInfo*/
        ctx[3]
      ),
      $$slots: { default: [create_default_slot$2] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(modalcontent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(modalcontent, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const modalcontent_changes = {};
      if (dirty & /*$$scope, $values, user*/
      1027) {
        modalcontent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modalcontent.$set(modalcontent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(modalcontent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(modalcontent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(modalcontent, detaching);
    }
  };
}
function instance$4($$self, $$props, $$invalidate) {
  let $values;
  let { user = void 0 } = $$props;
  let { API: API2 } = $$props;
  let { notifySuccess = notifications.success } = $$props;
  let { notifyError = notifications.error } = $$props;
  const dispatch = createEventDispatcher();
  const values = writable({
    firstName: user == null ? void 0 : user.firstName,
    lastName: user == null ? void 0 : user.lastName
  });
  component_subscribe($$self, values, (value) => $$invalidate(1, $values = value));
  const updateInfo = async () => {
    try {
      await API2.updateSelf($values);
      notifySuccess("Information updated successfully");
      dispatch("save");
    } catch (error) {
      console.error(error);
      notifyError("Failed to update information");
    }
  };
  function input1_value_binding(value) {
    if ($$self.$$.not_equal($values.firstName, value)) {
      $values.firstName = value;
      values.set($values);
    }
  }
  function input2_value_binding(value) {
    if ($$self.$$.not_equal($values.lastName, value)) {
      $values.lastName = value;
      values.set($values);
    }
  }
  $$self.$$set = ($$props2) => {
    if ("user" in $$props2)
      $$invalidate(0, user = $$props2.user);
    if ("API" in $$props2)
      $$invalidate(4, API2 = $$props2.API);
    if ("notifySuccess" in $$props2)
      $$invalidate(5, notifySuccess = $$props2.notifySuccess);
    if ("notifyError" in $$props2)
      $$invalidate(6, notifyError = $$props2.notifyError);
  };
  return [
    user,
    $values,
    values,
    updateInfo,
    API2,
    notifySuccess,
    notifyError,
    input1_value_binding,
    input2_value_binding
  ];
}
class ProfileModal extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$4, create_fragment$4, safe_not_equal, {
      user: 0,
      API: 4,
      notifySuccess: 5,
      notifyError: 6
    });
  }
}
const nodes = [];
let location;
function checkActive(el) {
  const matchesLocation = el.pattern.test(location);
  toggleClasses(el, el.className, matchesLocation);
  toggleClasses(el, el.inactiveClassName, !matchesLocation);
}
function toggleClasses(el, className, shouldAdd) {
  (className || "").split(" ").forEach((cls) => {
    if (!cls) {
      return;
    }
    el.node.classList.remove(cls);
    if (shouldAdd) {
      el.node.classList.add(cls);
    }
  });
}
loc.subscribe((value) => {
  location = value.location + (value.querystring ? "?" + value.querystring : "");
  nodes.map(checkActive);
});
function active(node, opts) {
  if (opts && (typeof opts == "string" || typeof opts == "object" && opts instanceof RegExp)) {
    opts = {
      path: opts
    };
  } else {
    opts = opts || {};
  }
  if (!opts.path && node.hasAttribute("href")) {
    opts.path = node.getAttribute("href");
    if (opts.path && opts.path.length > 1 && opts.path.charAt(0) == "#") {
      opts.path = opts.path.substring(1);
    }
  }
  if (!opts.className) {
    opts.className = "active";
  }
  if (!opts.path || typeof opts.path == "string" && (opts.path.length < 1 || opts.path.charAt(0) != "/" && opts.path.charAt(0) != "*")) {
    throw Error('Invalid value for "path" argument');
  }
  const { pattern } = typeof opts.path == "string" ? parse(opts.path) : { pattern: opts.path };
  const el = {
    node,
    className: opts.className,
    inactiveClassName: opts.inactiveClassName,
    pattern
  };
  nodes.push(el);
  checkActive(el);
  return {
    // When the element is destroyed, remove it from the list
    destroy() {
      nodes.splice(nodes.indexOf(el), 1);
    }
  };
}
const NavItem_svelte_svelte_type_style_lang = "";
function get_each_context$1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[23] = list[i];
  return child_ctx;
}
function create_else_block_1(ctx) {
  let previous_key = (
    /*renderKey*/
    ctx[11]
  );
  let key_block_anchor;
  let current;
  let key_block = create_key_block(ctx);
  return {
    c() {
      key_block.c();
      key_block_anchor = empty();
    },
    m(target, anchor) {
      key_block.m(target, anchor);
      insert(target, key_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*renderKey*/
      2048 && safe_not_equal(previous_key, previous_key = /*renderKey*/
      ctx2[11])) {
        group_outros();
        transition_out(key_block, 1, 1, noop);
        check_outros();
        key_block = create_key_block(ctx2);
        key_block.c();
        transition_in(key_block, 1);
        key_block.m(key_block_anchor.parentNode, key_block_anchor);
      } else {
        key_block.p(ctx2, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(key_block);
      current = true;
    },
    o(local) {
      transition_out(key_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(key_block_anchor);
      }
      key_block.d(detaching);
    }
  };
}
function create_if_block$3(ctx) {
  let div;
  let current_block_type_index;
  let if_block;
  let current;
  const if_block_creators = [create_if_block_1$3, create_else_block$1];
  const if_blocks = [];
  function select_block_type_1(ctx2, dirty) {
    if (
      /*internalLink*/
      ctx2[5]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type_1(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      div = element("div");
      if_block.c();
      attr(div, "class", "link");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_1(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div, null);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
    }
  };
}
function create_if_block_5$1(ctx) {
  let icon_1;
  let current;
  icon_1 = new Icon({
    props: {
      name: (
        /*icon*/
        ctx[4]
      ),
      color: "var(--navTextColor)",
      size: "S"
    }
  });
  return {
    c() {
      create_component(icon_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(icon_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const icon_1_changes = {};
      if (dirty & /*icon*/
      16)
        icon_1_changes.name = /*icon*/
        ctx2[4];
      icon_1.$set(icon_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(icon_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(icon_1, detaching);
    }
  };
}
function create_else_block_2(ctx) {
  let a;
  let t0_value = (
    /*subLink*/
    ctx[23].text + ""
  );
  let t0;
  let t1;
  let a_href_value;
  let mounted;
  let dispose;
  return {
    c() {
      a = element("a");
      t0 = text(t0_value);
      t1 = space();
      attr(a, "href", a_href_value = /*subLink*/
      ctx[23].url);
      attr(a, "class", "svelte-xz09vf");
    },
    m(target, anchor) {
      insert(target, a, anchor);
      append(a, t0);
      append(a, t1);
      if (!mounted) {
        dispose = listen(
          a,
          "click",
          /*onClickLink*/
          ctx[14]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty & /*subLinks*/
      8 && t0_value !== (t0_value = /*subLink*/
      ctx2[23].text + ""))
        set_data(t0, t0_value);
      if (dirty & /*subLinks*/
      8 && a_href_value !== (a_href_value = /*subLink*/
      ctx2[23].url)) {
        attr(a, "href", a_href_value);
      }
    },
    d(detaching) {
      if (detaching) {
        detach(a);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_if_block_4$1(ctx) {
  let a;
  let t0_value = (
    /*subLink*/
    ctx[23].text + ""
  );
  let t0;
  let t1;
  let a_href_value;
  let active_action;
  let mounted;
  let dispose;
  return {
    c() {
      a = element("a");
      t0 = text(t0_value);
      t1 = space();
      attr(a, "href", a_href_value = "#" + /*subLink*/
      ctx[23].url);
      attr(a, "class", "sublink svelte-xz09vf");
      toggle_class(a, "active", false);
      toggle_class(
        a,
        "builderActive",
        /*isBuilderActive*/
        ctx[10](
          /*subLink*/
          ctx[23].url
        )
      );
    },
    m(target, anchor) {
      insert(target, a, anchor);
      append(a, t0);
      append(a, t1);
      if (!mounted) {
        dispose = [
          listen(
            a,
            "click",
            /*onClickLink*/
            ctx[14]
          ),
          action_destroyer(active_action = active.call(
            null,
            a,
            /*subLink*/
            ctx[23].url
          ))
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*subLinks*/
      8 && t0_value !== (t0_value = /*subLink*/
      ctx[23].text + ""))
        set_data(t0, t0_value);
      if (dirty & /*subLinks*/
      8 && a_href_value !== (a_href_value = "#" + /*subLink*/
      ctx[23].url)) {
        attr(a, "href", a_href_value);
      }
      if (active_action && is_function(active_action.update) && dirty & /*subLinks*/
      8)
        active_action.update.call(
          null,
          /*subLink*/
          ctx[23].url
        );
      if (dirty & /*isBuilderActive, subLinks*/
      1032) {
        toggle_class(
          a,
          "builderActive",
          /*isBuilderActive*/
          ctx[10](
            /*subLink*/
            ctx[23].url
          )
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(a);
      }
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_each_block$1(ctx) {
  let if_block_anchor;
  function select_block_type_2(ctx2, dirty) {
    if (
      /*subLink*/
      ctx2[23].internalLink
    )
      return create_if_block_4$1;
    return create_else_block_2;
  }
  let current_block_type = select_block_type_2(ctx);
  let if_block = current_block_type(ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (current_block_type === (current_block_type = select_block_type_2(ctx2)) && if_block) {
        if_block.p(ctx2, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx2);
        if (if_block) {
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      }
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_block.d(detaching);
    }
  };
}
function create_key_block(ctx) {
  let div3;
  let div0;
  let t0;
  let span;
  let t1;
  let t2;
  let icon_1;
  let t3;
  let div2;
  let div1;
  let current;
  let mounted;
  let dispose;
  let if_block = (
    /*icon*/
    ctx[4] && create_if_block_5$1(ctx)
  );
  icon_1 = new Icon({
    props: {
      name: (
        /*caret*/
        ctx[12]
      ),
      color: "var(--navTextColor)",
      size: "S"
    }
  });
  let each_value = ensure_array_like(
    /*subLinks*/
    ctx[3] || []
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$1(get_each_context$1(ctx, each_value, i));
  }
  return {
    c() {
      div3 = element("div");
      div0 = element("div");
      if (if_block)
        if_block.c();
      t0 = space();
      span = element("span");
      t1 = text(
        /*text*/
        ctx[2]
      );
      t2 = space();
      create_component(icon_1.$$.fragment);
      t3 = space();
      div2 = element("div");
      div1 = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(span, "class", "svelte-xz09vf");
      attr(div0, "class", "text svelte-xz09vf");
      attr(div1, "class", "sublinks svelte-xz09vf");
      attr(div2, "class", "sublinks-wrapper svelte-xz09vf");
      attr(div3, "class", "dropdown svelte-xz09vf");
      toggle_class(
        div3,
        "left",
        /*renderLeftNav*/
        ctx[8]
      );
      toggle_class(
        div3,
        "expanded",
        /*expanded*/
        ctx[9]
      );
    },
    m(target, anchor) {
      insert(target, div3, anchor);
      append(div3, div0);
      if (if_block)
        if_block.m(div0, null);
      append(div0, t0);
      append(div0, span);
      append(span, t1);
      append(div0, t2);
      mount_component(icon_1, div0, null);
      append(div3, t3);
      append(div3, div2);
      append(div2, div1);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div1, null);
        }
      }
      current = true;
      if (!mounted) {
        dispose = listen(
          div0,
          "click",
          /*onClickDropdown*/
          ctx[15]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (
        /*icon*/
        ctx2[4]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*icon*/
          16) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_5$1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div0, t0);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (!current || dirty & /*text*/
      4)
        set_data(
          t1,
          /*text*/
          ctx2[2]
        );
      const icon_1_changes = {};
      if (dirty & /*caret*/
      4096)
        icon_1_changes.name = /*caret*/
        ctx2[12];
      icon_1.$set(icon_1_changes);
      if (dirty & /*subLinks, isBuilderActive, onClickLink*/
      17416) {
        each_value = ensure_array_like(
          /*subLinks*/
          ctx2[3] || []
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$1(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$1(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div1, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
      if (!current || dirty & /*renderLeftNav*/
      256) {
        toggle_class(
          div3,
          "left",
          /*renderLeftNav*/
          ctx2[8]
        );
      }
      if (!current || dirty & /*expanded*/
      512) {
        toggle_class(
          div3,
          "expanded",
          /*expanded*/
          ctx2[9]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      transition_in(icon_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      transition_out(icon_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div3);
      }
      if (if_block)
        if_block.d();
      destroy_component(icon_1);
      destroy_each(each_blocks, detaching);
      mounted = false;
      dispose();
    }
  };
}
function create_else_block$1(ctx) {
  let a;
  let t0;
  let t1;
  let current;
  let mounted;
  let dispose;
  let if_block = (
    /*icon*/
    ctx[4] && create_if_block_3$1(ctx)
  );
  return {
    c() {
      a = element("a");
      if (if_block)
        if_block.c();
      t0 = space();
      t1 = text(
        /*text*/
        ctx[2]
      );
      attr(
        a,
        "href",
        /*url*/
        ctx[1]
      );
      attr(a, "class", "svelte-xz09vf");
    },
    m(target, anchor) {
      insert(target, a, anchor);
      if (if_block)
        if_block.m(a, null);
      append(a, t0);
      append(a, t1);
      current = true;
      if (!mounted) {
        dispose = listen(
          a,
          "click",
          /*onClickLink*/
          ctx[14]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (
        /*icon*/
        ctx2[4]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*icon*/
          16) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_3$1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(a, t0);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (!current || dirty & /*text*/
      4)
        set_data(
          t1,
          /*text*/
          ctx2[2]
        );
      if (!current || dirty & /*url*/
      2) {
        attr(
          a,
          "href",
          /*url*/
          ctx2[1]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(a);
      }
      if (if_block)
        if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function create_if_block_1$3(ctx) {
  let a;
  let t0;
  let t1;
  let a_href_value;
  let active_action;
  let current;
  let mounted;
  let dispose;
  let if_block = (
    /*icon*/
    ctx[4] && create_if_block_2$3(ctx)
  );
  return {
    c() {
      a = element("a");
      if (if_block)
        if_block.c();
      t0 = space();
      t1 = text(
        /*text*/
        ctx[2]
      );
      attr(a, "href", a_href_value = "#" + /*url*/
      ctx[1]);
      attr(
        a,
        "style",
        /*customStyles*/
        ctx[6]
      );
      attr(a, "class", "svelte-xz09vf");
      toggle_class(
        a,
        "builderActive",
        /*builderActive*/
        ctx[13]
      );
    },
    m(target, anchor) {
      insert(target, a, anchor);
      if (if_block)
        if_block.m(a, null);
      append(a, t0);
      append(a, t1);
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            a,
            "click",
            /*onClickLink*/
            ctx[14]
          ),
          action_destroyer(active_action = active.call(
            null,
            a,
            /*url*/
            ctx[1]
          ))
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (
        /*icon*/
        ctx2[4]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*icon*/
          16) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_2$3(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(a, t0);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (!current || dirty & /*text*/
      4)
        set_data(
          t1,
          /*text*/
          ctx2[2]
        );
      if (!current || dirty & /*url*/
      2 && a_href_value !== (a_href_value = "#" + /*url*/
      ctx2[1])) {
        attr(a, "href", a_href_value);
      }
      if (!current || dirty & /*customStyles*/
      64) {
        attr(
          a,
          "style",
          /*customStyles*/
          ctx2[6]
        );
      }
      if (active_action && is_function(active_action.update) && dirty & /*url*/
      2)
        active_action.update.call(
          null,
          /*url*/
          ctx2[1]
        );
      if (!current || dirty & /*builderActive*/
      8192) {
        toggle_class(
          a,
          "builderActive",
          /*builderActive*/
          ctx2[13]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(a);
      }
      if (if_block)
        if_block.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_if_block_3$1(ctx) {
  let icon_1;
  let current;
  icon_1 = new Icon({
    props: {
      name: (
        /*icon*/
        ctx[4]
      ),
      color: "var(--navTextColor)",
      size: "S"
    }
  });
  return {
    c() {
      create_component(icon_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(icon_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const icon_1_changes = {};
      if (dirty & /*icon*/
      16)
        icon_1_changes.name = /*icon*/
        ctx2[4];
      icon_1.$set(icon_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(icon_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(icon_1, detaching);
    }
  };
}
function create_if_block_2$3(ctx) {
  let icon_1;
  let current;
  icon_1 = new Icon({
    props: {
      name: (
        /*icon*/
        ctx[4]
      ),
      color: "var(--navTextColor)",
      size: "S"
    }
  });
  return {
    c() {
      create_component(icon_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(icon_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const icon_1_changes = {};
      if (dirty & /*icon*/
      16)
        icon_1_changes.name = /*icon*/
        ctx2[4];
      icon_1.$set(icon_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(icon_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(icon_1, detaching);
    }
  };
}
function create_fragment$3(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block$3, create_else_block_1];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (!/*type*/
    ctx2[0] || /*type*/
    ctx2[0] === "link")
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function instance$3($$self, $$props, $$invalidate) {
  let isBuilderActive;
  let builderActive;
  let containsActiveLink;
  let expanded;
  let renderLeftNav;
  let caret;
  let $navStateStore, $$unsubscribe_navStateStore = noop, $$subscribe_navStateStore = () => ($$unsubscribe_navStateStore(), $$unsubscribe_navStateStore = subscribe(navStateStore, ($$value) => $$invalidate(19, $navStateStore = $$value)), navStateStore);
  let $screenStore;
  let $builderStore;
  component_subscribe($$self, screenStore, ($$value) => $$invalidate(20, $screenStore = $$value));
  component_subscribe($$self, builderStore, ($$value) => $$invalidate(21, $builderStore = $$value));
  $$self.$$.on_destroy.push(() => $$unsubscribe_navStateStore());
  let { type } = $$props;
  let { url } = $$props;
  let { text: text2 } = $$props;
  let { subLinks } = $$props;
  let { icon } = $$props;
  let { internalLink } = $$props;
  let { customStyles } = $$props;
  let { leftNav = false } = $$props;
  let { mobile = false } = $$props;
  let { navStateStore } = $$props;
  $$subscribe_navStateStore();
  const dispatch = createEventDispatcher();
  let renderKey;
  const onClickLink = () => {
    dispatch("clickLink");
    $$invalidate(11, renderKey = Math.random());
  };
  const onClickDropdown = () => {
    if (!renderLeftNav) {
      return;
    }
    navStateStore.update((state) => ({ ...state, [text2]: !state[text2] }));
  };
  $$self.$$set = ($$props2) => {
    if ("type" in $$props2)
      $$invalidate(0, type = $$props2.type);
    if ("url" in $$props2)
      $$invalidate(1, url = $$props2.url);
    if ("text" in $$props2)
      $$invalidate(2, text2 = $$props2.text);
    if ("subLinks" in $$props2)
      $$invalidate(3, subLinks = $$props2.subLinks);
    if ("icon" in $$props2)
      $$invalidate(4, icon = $$props2.icon);
    if ("internalLink" in $$props2)
      $$invalidate(5, internalLink = $$props2.internalLink);
    if ("customStyles" in $$props2)
      $$invalidate(6, customStyles = $$props2.customStyles);
    if ("leftNav" in $$props2)
      $$invalidate(16, leftNav = $$props2.leftNav);
    if ("mobile" in $$props2)
      $$invalidate(17, mobile = $$props2.mobile);
    if ("navStateStore" in $$props2)
      $$subscribe_navStateStore($$invalidate(7, navStateStore = $$props2.navStateStore));
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$builderStore, $screenStore*/
    3145728) {
      $$invalidate(10, isBuilderActive = (testUrl) => {
        var _a, _b;
        return $builderStore.inBuilder && testUrl && testUrl === ((_b = (_a = $screenStore.activeScreen) == null ? void 0 : _a.routing) == null ? void 0 : _b.route);
      });
    }
    if ($$self.$$.dirty & /*isBuilderActive, url*/
    1026) {
      $$invalidate(13, builderActive = isBuilderActive(url));
    }
    if ($$self.$$.dirty & /*subLinks, isBuilderActive*/
    1032) {
      $$invalidate(18, containsActiveLink = (subLinks || []).some((x) => isBuilderActive(x.url)));
    }
    if ($$self.$$.dirty & /*$navStateStore, text, containsActiveLink*/
    786436) {
      $$invalidate(9, expanded = !!$navStateStore[text2] || containsActiveLink);
    }
    if ($$self.$$.dirty & /*leftNav, mobile*/
    196608) {
      $$invalidate(8, renderLeftNav = leftNav || mobile);
    }
    if ($$self.$$.dirty & /*renderLeftNav, expanded*/
    768) {
      $$invalidate(12, caret = !renderLeftNav || expanded ? "caret-down" : "caret-right");
    }
  };
  return [
    type,
    url,
    text2,
    subLinks,
    icon,
    internalLink,
    customStyles,
    navStateStore,
    renderLeftNav,
    expanded,
    isBuilderActive,
    renderKey,
    caret,
    builderActive,
    onClickLink,
    onClickDropdown,
    leftNav,
    mobile,
    containsActiveLink,
    $navStateStore,
    $screenStore,
    $builderStore
  ];
}
class NavItem extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$3, create_fragment$3, safe_not_equal, {
      type: 0,
      url: 1,
      text: 2,
      subLinks: 3,
      icon: 4,
      internalLink: 5,
      customStyles: 6,
      leftNav: 16,
      mobile: 17,
      navStateStore: 7
    });
  }
}
const UserMenu_svelte_svelte_type_style_lang = "";
function create_if_block$2(ctx) {
  let actionmenu;
  let t0;
  let modal0;
  let t1;
  let modal1;
  let current;
  actionmenu = new ActionMenu({
    props: {
      align: (
        /*compact*/
        ctx[0] ? "right" : "left"
      ),
      $$slots: {
        control: [create_control_slot],
        default: [create_default_slot_2]
      },
      $$scope: { ctx }
    }
  });
  let modal0_props = {
    $$slots: { default: [create_default_slot_1] },
    $$scope: { ctx }
  };
  modal0 = new Modal({ props: modal0_props });
  ctx[19](modal0);
  let modal1_props = {
    $$slots: { default: [create_default_slot$1] },
    $$scope: { ctx }
  };
  modal1 = new Modal({ props: modal1_props });
  ctx[21](modal1);
  return {
    c() {
      create_component(actionmenu.$$.fragment);
      t0 = space();
      create_component(modal0.$$.fragment);
      t1 = space();
      create_component(modal1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(actionmenu, target, anchor);
      insert(target, t0, anchor);
      mount_component(modal0, target, anchor);
      insert(target, t1, anchor);
      mount_component(modal1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const actionmenu_changes = {};
      if (dirty & /*compact*/
      1)
        actionmenu_changes.align = /*compact*/
        ctx2[0] ? "right" : "left";
      if (dirty & /*$$scope, text, compact, user, embedded, isOwner, $environmentStore, changePasswordModal, isSSO, profileModal*/
      16778237) {
        actionmenu_changes.$$scope = { dirty, ctx: ctx2 };
      }
      actionmenu.$set(actionmenu_changes);
      const modal0_changes = {};
      if (dirty & /*$$scope, $authStore*/
      16777218) {
        modal0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modal0.$set(modal0_changes);
      const modal1_changes = {};
      if (dirty & /*$$scope, $environmentStore*/
      16777220) {
        modal1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modal1.$set(modal1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(actionmenu.$$.fragment, local);
      transition_in(modal0.$$.fragment, local);
      transition_in(modal1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(actionmenu.$$.fragment, local);
      transition_out(modal0.$$.fragment, local);
      transition_out(modal1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
      destroy_component(actionmenu, detaching);
      ctx[19](null);
      destroy_component(modal0, detaching);
      ctx[21](null);
      destroy_component(modal1, detaching);
    }
  };
}
function create_default_slot_6(ctx) {
  let t;
  return {
    c() {
      t = text("My profile");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_2$2(ctx) {
  let menuitem;
  let current;
  menuitem = new Item({
    props: {
      icon: "lock",
      $$slots: { default: [create_default_slot_5] },
      $$scope: { ctx }
    }
  });
  menuitem.$on(
    "click",
    /*click_handler_1*/
    ctx[17]
  );
  return {
    c() {
      create_component(menuitem.$$.fragment);
    },
    m(target, anchor) {
      mount_component(menuitem, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const menuitem_changes = {};
      if (dirty & /*$$scope*/
      16777216) {
        menuitem_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem.$set(menuitem_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(menuitem.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(menuitem.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(menuitem, detaching);
    }
  };
}
function create_default_slot_5(ctx) {
  let t;
  return {
    c() {
      t = text("Update password");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_4(ctx) {
  let t;
  return {
    c() {
      t = text("Go to portal");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_3(ctx) {
  let t;
  return {
    c() {
      t = text("Log out");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_2(ctx) {
  let menuitem0;
  let t0;
  let t1;
  let menuitem1;
  let t2;
  let menuitem2;
  let current;
  menuitem0 = new Item({
    props: {
      icon: "user-gear",
      $$slots: { default: [create_default_slot_6] },
      $$scope: { ctx }
    }
  });
  menuitem0.$on(
    "click",
    /*click_handler*/
    ctx[16]
  );
  let if_block = !/*isSSO*/
  ctx[8] && create_if_block_2$2(ctx);
  menuitem1 = new Item({
    props: {
      icon: "squares-four",
      disabled: (
        /*embedded*/
        ctx[6]
      ),
      $$slots: { default: [create_default_slot_4] },
      $$scope: { ctx }
    }
  });
  menuitem1.$on(
    "click",
    /*goToPortal*/
    ctx[14]
  );
  menuitem2 = new Item({
    props: {
      icon: "sign-out",
      disabled: (
        /*embedded*/
        ctx[6]
      ),
      $$slots: { default: [create_default_slot_3] },
      $$scope: { ctx }
    }
  });
  menuitem2.$on(
    "click",
    /*authStore*/
    ctx[10].actions.logOut
  );
  return {
    c() {
      create_component(menuitem0.$$.fragment);
      t0 = space();
      if (if_block)
        if_block.c();
      t1 = space();
      create_component(menuitem1.$$.fragment);
      t2 = space();
      create_component(menuitem2.$$.fragment);
    },
    m(target, anchor) {
      mount_component(menuitem0, target, anchor);
      insert(target, t0, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, t1, anchor);
      mount_component(menuitem1, target, anchor);
      insert(target, t2, anchor);
      mount_component(menuitem2, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const menuitem0_changes = {};
      if (dirty & /*$$scope*/
      16777216) {
        menuitem0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem0.$set(menuitem0_changes);
      if (!/*isSSO*/
      ctx2[8]) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*isSSO*/
          256) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_2$2(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(t1.parentNode, t1);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      const menuitem1_changes = {};
      if (dirty & /*embedded*/
      64)
        menuitem1_changes.disabled = /*embedded*/
        ctx2[6];
      if (dirty & /*$$scope*/
      16777216) {
        menuitem1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem1.$set(menuitem1_changes);
      const menuitem2_changes = {};
      if (dirty & /*embedded*/
      64)
        menuitem2_changes.disabled = /*embedded*/
        ctx2[6];
      if (dirty & /*$$scope*/
      16777216) {
        menuitem2_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem2.$set(menuitem2_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(menuitem0.$$.fragment, local);
      transition_in(if_block);
      transition_in(menuitem1.$$.fragment, local);
      transition_in(menuitem2.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(menuitem0.$$.fragment, local);
      transition_out(if_block);
      transition_out(menuitem1.$$.fragment, local);
      transition_out(menuitem2.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
      }
      destroy_component(menuitem0, detaching);
      if (if_block)
        if_block.d(detaching);
      destroy_component(menuitem1, detaching);
      destroy_component(menuitem2, detaching);
    }
  };
}
function create_if_block_1$2(ctx) {
  let div1;
  let div0;
  let t;
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      t = text(
        /*text*/
        ctx[9]
      );
      attr(div0, "class", "name svelte-1f32c0v");
      attr(div1, "class", "text svelte-1f32c0v");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      append(div0, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*text*/
      512)
        set_data(
          t,
          /*text*/
          ctx2[9]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
    }
  };
}
function create_control_slot(ctx) {
  let div;
  let useravatar;
  let t0;
  let t1;
  let icon;
  let current;
  useravatar = new UserAvatar({
    props: {
      user: (
        /*user*/
        ctx[5]
      ),
      size: "M",
      showTooltip: false
    }
  });
  let if_block = !/*compact*/
  ctx[0] && create_if_block_1$2(ctx);
  icon = new Icon({
    props: {
      size: "S",
      name: "caret-down",
      color: "var(--navTextColor)"
    }
  });
  return {
    c() {
      div = element("div");
      create_component(useravatar.$$.fragment);
      t0 = space();
      if (if_block)
        if_block.c();
      t1 = space();
      create_component(icon.$$.fragment);
      attr(div, "class", "container svelte-1f32c0v");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(useravatar, div, null);
      append(div, t0);
      if (if_block)
        if_block.m(div, null);
      append(div, t1);
      mount_component(icon, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const useravatar_changes = {};
      if (dirty & /*user*/
      32)
        useravatar_changes.user = /*user*/
        ctx2[5];
      useravatar.$set(useravatar_changes);
      if (!/*compact*/
      ctx2[0]) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block_1$2(ctx2);
          if_block.c();
          if_block.m(div, t1);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(useravatar.$$.fragment, local);
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(useravatar.$$.fragment, local);
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(useravatar);
      if (if_block)
        if_block.d();
      destroy_component(icon);
    }
  };
}
function create_default_slot_1(ctx) {
  let profilemodal;
  let current;
  profilemodal = new ProfileModal({
    props: {
      API,
      user: (
        /*$authStore*/
        ctx[1]
      ),
      notifySuccess: (
        /*notificationStore*/
        ctx[12].actions.success
      ),
      notifyError: (
        /*notificationStore*/
        ctx[12].actions.error
      )
    }
  });
  profilemodal.$on(
    "save",
    /*save_handler*/
    ctx[18]
  );
  return {
    c() {
      create_component(profilemodal.$$.fragment);
    },
    m(target, anchor) {
      mount_component(profilemodal, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const profilemodal_changes = {};
      if (dirty & /*$authStore*/
      2)
        profilemodal_changes.user = /*$authStore*/
        ctx2[1];
      profilemodal.$set(profilemodal_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(profilemodal.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(profilemodal.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(profilemodal, detaching);
    }
  };
}
function create_default_slot$1(ctx) {
  let changepasswordmodal;
  let current;
  changepasswordmodal = new ChangePasswordModal({
    props: {
      API,
      passwordMinLength: (
        /*$environmentStore*/
        ctx[2].passwordMinLength
      ),
      notifySuccess: (
        /*notificationStore*/
        ctx[12].actions.success
      ),
      notifyError: (
        /*notificationStore*/
        ctx[12].actions.error
      )
    }
  });
  changepasswordmodal.$on(
    "save",
    /*save_handler_1*/
    ctx[20]
  );
  return {
    c() {
      create_component(changepasswordmodal.$$.fragment);
    },
    m(target, anchor) {
      mount_component(changepasswordmodal, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const changepasswordmodal_changes = {};
      if (dirty & /*$environmentStore*/
      4)
        changepasswordmodal_changes.passwordMinLength = /*$environmentStore*/
        ctx2[2].passwordMinLength;
      changepasswordmodal.$set(changepasswordmodal_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(changepasswordmodal.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(changepasswordmodal.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(changepasswordmodal, detaching);
    }
  };
}
function create_fragment$2(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*$authStore*/
    ctx[1] && create_if_block$2(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (
        /*$authStore*/
        ctx2[1]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*$authStore*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$2(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance$2($$self, $$props, $$invalidate) {
  let text2;
  let isBuilder;
  let isSSO;
  let isOwner;
  let embedded;
  let user;
  let $authStore;
  let $appStore;
  let $environmentStore;
  let { compact = false } = $$props;
  const { authStore, environmentStore, notificationStore, appStore } = getContext("sdk");
  component_subscribe($$self, authStore, (value) => $$invalidate(1, $authStore = value));
  component_subscribe($$self, environmentStore, (value) => $$invalidate(2, $environmentStore = value));
  component_subscribe($$self, appStore, (value) => $$invalidate(15, $appStore = value));
  let profileModal;
  let changePasswordModal;
  const getText = (user2) => {
    if (!user2) {
      return "";
    }
    if (user2.firstName) {
      let text22 = user2.firstName;
      if (user2.lastName) {
        text22 += ` ${user2.lastName}`;
      }
      return text22;
    } else {
      return user2.email;
    }
  };
  const goToPortal = () => {
    window.location.href = isBuilder ? "/builder/portal/workspaces" : "/builder/apps";
  };
  const click_handler = () => profileModal == null ? void 0 : profileModal.show();
  const click_handler_1 = () => {
    if (isOwner) {
      window.location.href = `${$environmentStore.accountPortalUrl}/portal/account`;
    } else {
      changePasswordModal == null ? void 0 : changePasswordModal.show();
    }
  };
  const save_handler = () => authStore.actions.fetchUser();
  function modal0_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      profileModal = $$value;
      $$invalidate(3, profileModal);
    });
  }
  const save_handler_1 = () => authStore.actions.logOut();
  function modal1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      changePasswordModal = $$value;
      $$invalidate(4, changePasswordModal);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("compact" in $$props2)
      $$invalidate(0, compact = $$props2.compact);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$authStore*/
    2) {
      $$invalidate(9, text2 = getText($authStore));
    }
    if ($$self.$$.dirty & /*$authStore*/
    2) {
      isBuilder = hasBuilderPermissions($authStore);
    }
    if ($$self.$$.dirty & /*$authStore*/
    2) {
      $$invalidate(8, isSSO = $authStore != null && isSSOUser($authStore));
    }
    if ($$self.$$.dirty & /*$authStore, $environmentStore*/
    6) {
      $$invalidate(7, isOwner = ($authStore == null ? void 0 : $authStore.accountPortalAccess) && $environmentStore.cloud);
    }
    if ($$self.$$.dirty & /*$appStore*/
    32768) {
      $$invalidate(6, embedded = $appStore.embedded || $appStore.inIframe);
    }
    if ($$self.$$.dirty & /*$authStore*/
    2) {
      $$invalidate(5, user = $authStore);
    }
  };
  return [
    compact,
    $authStore,
    $environmentStore,
    profileModal,
    changePasswordModal,
    user,
    embedded,
    isOwner,
    isSSO,
    text2,
    authStore,
    environmentStore,
    notificationStore,
    appStore,
    goToPortal,
    $appStore,
    click_handler,
    click_handler_1,
    save_handler,
    modal0_binding,
    save_handler_1,
    modal1_binding
  ];
}
class UserMenu extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$2, create_fragment$2, safe_not_equal, { compact: 0 });
  }
}
const Logo_svelte_svelte_type_style_lang = "";
function create_if_block$1(ctx) {
  let show_if;
  let if_block_anchor;
  function select_block_type(ctx2, dirty) {
    if (dirty & /*logoLinkUrl, isInternal, openLogoLinkInNewTab*/
    38)
      show_if = null;
    if (show_if == null)
      show_if = !!/*logoLinkUrl*/
      (ctx2[1] && /*isInternal*/
      ctx2[5](
        /*logoLinkUrl*/
        ctx2[1]
      ) && !/*openLogoLinkInNewTab*/
      ctx2[2]);
    if (show_if)
      return create_if_block_1$1;
    if (
      /*logoLinkUrl*/
      ctx2[1]
    )
      return create_if_block_2$1;
    return create_else_block;
  }
  let current_block_type = select_block_type(ctx, -1);
  let if_block = current_block_type(ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (current_block_type === (current_block_type = select_block_type(ctx2, dirty)) && if_block) {
        if_block.p(ctx2, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx2);
        if (if_block) {
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      }
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_block.d(detaching);
    }
  };
}
function create_else_block(ctx) {
  let img;
  let img_src_value;
  return {
    c() {
      img = element("img");
      if (!src_url_equal(img.src, img_src_value = /*logoUrl*/
      ctx[0] || "/builder/bblogo.png"))
        attr(img, "src", img_src_value);
      attr(
        img,
        "alt",
        /*title*/
        ctx[4]
      );
      attr(img, "class", "svelte-17w40j6");
    },
    m(target, anchor) {
      insert(target, img, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*logoUrl*/
      1 && !src_url_equal(img.src, img_src_value = /*logoUrl*/
      ctx2[0] || "/builder/bblogo.png")) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*title*/
      16) {
        attr(
          img,
          "alt",
          /*title*/
          ctx2[4]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(img);
      }
    }
  };
}
function create_if_block_2$1(ctx) {
  let a;
  let img;
  let img_src_value;
  let a_target_value;
  let a_href_value;
  return {
    c() {
      a = element("a");
      img = element("img");
      if (!src_url_equal(img.src, img_src_value = /*logoUrl*/
      ctx[0] || "/builder/bblogo.png"))
        attr(img, "src", img_src_value);
      attr(
        img,
        "alt",
        /*title*/
        ctx[4]
      );
      attr(img, "class", "svelte-17w40j6");
      attr(a, "target", a_target_value = /*openLogoLinkInNewTab*/
      ctx[2] ? "_blank" : "_self");
      attr(a, "href", a_href_value = /*getSanitizedUrl*/
      ctx[6](
        /*logoLinkUrl*/
        ctx[1],
        /*openLogoLinkInNewTab*/
        ctx[2]
      ));
    },
    m(target, anchor) {
      insert(target, a, anchor);
      append(a, img);
    },
    p(ctx2, dirty) {
      if (dirty & /*logoUrl*/
      1 && !src_url_equal(img.src, img_src_value = /*logoUrl*/
      ctx2[0] || "/builder/bblogo.png")) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*title*/
      16) {
        attr(
          img,
          "alt",
          /*title*/
          ctx2[4]
        );
      }
      if (dirty & /*openLogoLinkInNewTab*/
      4 && a_target_value !== (a_target_value = /*openLogoLinkInNewTab*/
      ctx2[2] ? "_blank" : "_self")) {
        attr(a, "target", a_target_value);
      }
      if (dirty & /*getSanitizedUrl, logoLinkUrl, openLogoLinkInNewTab*/
      70 && a_href_value !== (a_href_value = /*getSanitizedUrl*/
      ctx2[6](
        /*logoLinkUrl*/
        ctx2[1],
        /*openLogoLinkInNewTab*/
        ctx2[2]
      ))) {
        attr(a, "href", a_href_value);
      }
    },
    d(detaching) {
      if (detaching) {
        detach(a);
      }
    }
  };
}
function create_if_block_1$1(ctx) {
  let a;
  let img;
  let img_src_value;
  let a_href_value;
  let mounted;
  let dispose;
  return {
    c() {
      a = element("a");
      img = element("img");
      if (!src_url_equal(img.src, img_src_value = /*logoUrl*/
      ctx[0] || "/builder/bblogo.png"))
        attr(img, "src", img_src_value);
      attr(
        img,
        "alt",
        /*title*/
        ctx[4]
      );
      attr(img, "class", "svelte-17w40j6");
      attr(a, "href", a_href_value = /*getSanitizedUrl*/
      ctx[6](
        /*logoLinkUrl*/
        ctx[1],
        /*openLogoLinkInNewTab*/
        ctx[2]
      ));
    },
    m(target, anchor) {
      insert(target, a, anchor);
      append(a, img);
      if (!mounted) {
        dispose = action_destroyer(
          /*linkable*/
          ctx[7].call(null, a)
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty & /*logoUrl*/
      1 && !src_url_equal(img.src, img_src_value = /*logoUrl*/
      ctx2[0] || "/builder/bblogo.png")) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*title*/
      16) {
        attr(
          img,
          "alt",
          /*title*/
          ctx2[4]
        );
      }
      if (dirty & /*getSanitizedUrl, logoLinkUrl, openLogoLinkInNewTab*/
      70 && a_href_value !== (a_href_value = /*getSanitizedUrl*/
      ctx2[6](
        /*logoLinkUrl*/
        ctx2[1],
        /*openLogoLinkInNewTab*/
        ctx2[2]
      ))) {
        attr(a, "href", a_href_value);
      }
    },
    d(detaching) {
      if (detaching) {
        detach(a);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_fragment$1(ctx) {
  let if_block_anchor;
  let if_block = !/*hideLogo*/
  ctx[3] && create_if_block$1(ctx);
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
    },
    p(ctx2, [dirty]) {
      if (!/*hideLogo*/
      ctx2[3]) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block$1(ctx2);
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let { logoUrl } = $$props;
  let { logoLinkUrl } = $$props;
  let { openLogoLinkInNewTab } = $$props;
  let { hideLogo = false } = $$props;
  let { title } = $$props;
  let { isInternal } = $$props;
  let { getSanitizedUrl } = $$props;
  let { linkable } = $$props;
  $$self.$$set = ($$props2) => {
    if ("logoUrl" in $$props2)
      $$invalidate(0, logoUrl = $$props2.logoUrl);
    if ("logoLinkUrl" in $$props2)
      $$invalidate(1, logoLinkUrl = $$props2.logoLinkUrl);
    if ("openLogoLinkInNewTab" in $$props2)
      $$invalidate(2, openLogoLinkInNewTab = $$props2.openLogoLinkInNewTab);
    if ("hideLogo" in $$props2)
      $$invalidate(3, hideLogo = $$props2.hideLogo);
    if ("title" in $$props2)
      $$invalidate(4, title = $$props2.title);
    if ("isInternal" in $$props2)
      $$invalidate(5, isInternal = $$props2.isInternal);
    if ("getSanitizedUrl" in $$props2)
      $$invalidate(6, getSanitizedUrl = $$props2.getSanitizedUrl);
    if ("linkable" in $$props2)
      $$invalidate(7, linkable = $$props2.linkable);
  };
  return [
    logoUrl,
    logoLinkUrl,
    openLogoLinkInNewTab,
    hideLogo,
    title,
    isInternal,
    getSanitizedUrl,
    linkable
  ];
}
class Logo extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, {
      logoUrl: 0,
      logoLinkUrl: 1,
      openLogoLinkInNewTab: 2,
      hideLogo: 3,
      title: 4,
      isInternal: 5,
      getSanitizedUrl: 6,
      linkable: 7
    });
  }
}
const Layout_svelte_svelte_type_style_lang = "";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[63] = list[i];
  return child_ctx;
}
function create_if_block(ctx) {
  let div5;
  let div4;
  let div3;
  let div1;
  let t0;
  let div0;
  let t1;
  let t2;
  let t3;
  let div2;
  let t4;
  let t5;
  let div3_class_value;
  let div4_class_value;
  let div5_class_value;
  let current;
  let mounted;
  let dispose;
  let if_block0 = (
    /*enrichedNavItems*/
    ctx[24].length && create_if_block_8(ctx)
  );
  let if_block1 = (
    /*logoPosition*/
    ctx[10] === "top" && create_if_block_7(ctx)
  );
  let if_block2 = !/*hideTitle*/
  ctx[1] && /*title*/
  ctx[0] && create_if_block_6(ctx);
  let if_block3 = !/*embedded*/
  ctx[9] && create_if_block_5();
  let if_block4 = (
    /*enrichedNavItems*/
    ctx[24].length && create_if_block_3(ctx)
  );
  let if_block5 = !/*embedded*/
  ctx[9] && create_if_block_1(ctx);
  return {
    c() {
      var _a;
      div5 = element("div");
      div4 = element("div");
      div3 = element("div");
      div1 = element("div");
      if (if_block0)
        if_block0.c();
      t0 = space();
      div0 = element("div");
      if (if_block1)
        if_block1.c();
      t1 = space();
      if (if_block2)
        if_block2.c();
      t2 = space();
      if (if_block3)
        if_block3.c();
      t3 = space();
      div2 = element("div");
      t4 = space();
      if (if_block4)
        if_block4.c();
      t5 = space();
      if (if_block5)
        if_block5.c();
      attr(div0, "class", "logo svelte-1r1yuqu");
      attr(div1, "class", "nav-header svelte-1r1yuqu");
      attr(div2, "class", "mobile-click-handler svelte-1r1yuqu");
      toggle_class(
        div2,
        "visible",
        /*mobileOpen*/
        ctx[16]
      );
      attr(div3, "class", div3_class_value = "nav nav--" + /*typeClass*/
      ctx[23] + " size--" + /*navWidthClass*/
      ctx[22] + " svelte-1r1yuqu");
      attr(div4, "class", div4_class_value = "nav-wrapper " + /*navigationId*/
      ctx[17] + "-dom svelte-1r1yuqu");
      attr(
        div4,
        "style",
        /*navStyle*/
        ctx[20]
      );
      toggle_class(
        div4,
        "sticky",
        /*sticky*/
        ctx[5]
      );
      toggle_class(
        div4,
        "hidden",
        /*$routeStore*/
        (_a = ctx[25].queryParams) == null ? void 0 : _a.peek
      );
      toggle_class(
        div4,
        "clickable",
        /*$builderStore*/
        ctx[14].inBuilder
      );
      attr(div5, "class", div5_class_value = "interactive component " + /*navigationId*/
      ctx[17] + " svelte-1r1yuqu");
      attr(
        div5,
        "data-id",
        /*navigationId*/
        ctx[17]
      );
      attr(div5, "data-name", "Navigation");
      attr(div5, "data-icon", "eye");
    },
    m(target, anchor) {
      insert(target, div5, anchor);
      append(div5, div4);
      append(div4, div3);
      append(div3, div1);
      if (if_block0)
        if_block0.m(div1, null);
      append(div1, t0);
      append(div1, div0);
      if (if_block1)
        if_block1.m(div0, null);
      append(div0, t1);
      if (if_block2)
        if_block2.m(div0, null);
      append(div1, t2);
      if (if_block3)
        if_block3.m(div1, null);
      append(div3, t3);
      append(div3, div2);
      append(div3, t4);
      if (if_block4)
        if_block4.m(div3, null);
      append(div3, t5);
      if (if_block5)
        if_block5.m(div3, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            div2,
            "click",
            /*click_handler_1*/
            ctx[49]
          ),
          listen(div4, "click", function() {
            if (is_function(
              /*$builderStore*/
              ctx[14].inBuilder ? (
                /*builderStore*/
                ctx[29].actions.selectComponent(
                  /*navigationId*/
                  ctx[17]
                )
              ) : null
            ))
              /*$builderStore*/
              (ctx[14].inBuilder ? (
                /*builderStore*/
                ctx[29].actions.selectComponent(
                  /*navigationId*/
                  ctx[17]
                )
              ) : null).apply(this, arguments);
          })
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      var _a;
      ctx = new_ctx;
      if (
        /*enrichedNavItems*/
        ctx[24].length
      ) {
        if (if_block0) {
          if_block0.p(ctx, dirty);
          if (dirty[0] & /*enrichedNavItems*/
          16777216) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_8(ctx);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(div1, t0);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (
        /*logoPosition*/
        ctx[10] === "top"
      ) {
        if (if_block1) {
          if_block1.p(ctx, dirty);
          if (dirty[0] & /*logoPosition*/
          1024) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_7(ctx);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div0, t1);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if (!/*hideTitle*/
      ctx[1] && /*title*/
      ctx[0]) {
        if (if_block2) {
          if_block2.p(ctx, dirty);
          if (dirty[0] & /*hideTitle, title*/
          3) {
            transition_in(if_block2, 1);
          }
        } else {
          if_block2 = create_if_block_6(ctx);
          if_block2.c();
          transition_in(if_block2, 1);
          if_block2.m(div0, null);
        }
      } else if (if_block2) {
        group_outros();
        transition_out(if_block2, 1, 1, () => {
          if_block2 = null;
        });
        check_outros();
      }
      if (!/*embedded*/
      ctx[9]) {
        if (if_block3) {
          if (dirty[0] & /*embedded*/
          512) {
            transition_in(if_block3, 1);
          }
        } else {
          if_block3 = create_if_block_5();
          if_block3.c();
          transition_in(if_block3, 1);
          if_block3.m(div1, null);
        }
      } else if (if_block3) {
        group_outros();
        transition_out(if_block3, 1, 1, () => {
          if_block3 = null;
        });
        check_outros();
      }
      if (!current || dirty[0] & /*mobileOpen*/
      65536) {
        toggle_class(
          div2,
          "visible",
          /*mobileOpen*/
          ctx[16]
        );
      }
      if (
        /*enrichedNavItems*/
        ctx[24].length
      ) {
        if (if_block4) {
          if_block4.p(ctx, dirty);
          if (dirty[0] & /*enrichedNavItems*/
          16777216) {
            transition_in(if_block4, 1);
          }
        } else {
          if_block4 = create_if_block_3(ctx);
          if_block4.c();
          transition_in(if_block4, 1);
          if_block4.m(div3, t5);
        }
      } else if (if_block4) {
        group_outros();
        transition_out(if_block4, 1, 1, () => {
          if_block4 = null;
        });
        check_outros();
      }
      if (!/*embedded*/
      ctx[9]) {
        if (if_block5) {
          if_block5.p(ctx, dirty);
          if (dirty[0] & /*embedded*/
          512) {
            transition_in(if_block5, 1);
          }
        } else {
          if_block5 = create_if_block_1(ctx);
          if_block5.c();
          transition_in(if_block5, 1);
          if_block5.m(div3, null);
        }
      } else if (if_block5) {
        group_outros();
        transition_out(if_block5, 1, 1, () => {
          if_block5 = null;
        });
        check_outros();
      }
      if (!current || dirty[0] & /*typeClass, navWidthClass*/
      12582912 && div3_class_value !== (div3_class_value = "nav nav--" + /*typeClass*/
      ctx[23] + " size--" + /*navWidthClass*/
      ctx[22] + " svelte-1r1yuqu")) {
        attr(div3, "class", div3_class_value);
      }
      if (!current || dirty[0] & /*navigationId*/
      131072 && div4_class_value !== (div4_class_value = "nav-wrapper " + /*navigationId*/
      ctx[17] + "-dom svelte-1r1yuqu")) {
        attr(div4, "class", div4_class_value);
      }
      if (!current || dirty[0] & /*navStyle*/
      1048576) {
        attr(
          div4,
          "style",
          /*navStyle*/
          ctx[20]
        );
      }
      if (!current || dirty[0] & /*navigationId, sticky*/
      131104) {
        toggle_class(
          div4,
          "sticky",
          /*sticky*/
          ctx[5]
        );
      }
      if (!current || dirty[0] & /*navigationId, $routeStore*/
      33685504) {
        toggle_class(
          div4,
          "hidden",
          /*$routeStore*/
          (_a = ctx[25].queryParams) == null ? void 0 : _a.peek
        );
      }
      if (!current || dirty[0] & /*navigationId, $builderStore*/
      147456) {
        toggle_class(
          div4,
          "clickable",
          /*$builderStore*/
          ctx[14].inBuilder
        );
      }
      if (!current || dirty[0] & /*navigationId*/
      131072 && div5_class_value !== (div5_class_value = "interactive component " + /*navigationId*/
      ctx[17] + " svelte-1r1yuqu")) {
        attr(div5, "class", div5_class_value);
      }
      if (!current || dirty[0] & /*navigationId*/
      131072) {
        attr(
          div5,
          "data-id",
          /*navigationId*/
          ctx[17]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      transition_in(if_block2);
      transition_in(if_block3);
      transition_in(if_block4);
      transition_in(if_block5);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      transition_out(if_block2);
      transition_out(if_block3);
      transition_out(if_block4);
      transition_out(if_block5);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div5);
      }
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
      if (if_block2)
        if_block2.d();
      if (if_block3)
        if_block3.d();
      if (if_block4)
        if_block4.d();
      if (if_block5)
        if_block5.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_if_block_8(ctx) {
  let div;
  let icon;
  let current;
  icon = new Icon({
    props: {
      hoverable: true,
      name: "list",
      color: "var(--navTextColor)"
    }
  });
  icon.$on(
    "click",
    /*click_handler*/
    ctx[48]
  );
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      attr(div, "class", "burger svelte-1r1yuqu");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
    }
  };
}
function create_if_block_7(ctx) {
  let logo;
  let current;
  logo = new Logo({
    props: {
      logoUrl: (
        /*logoUrl*/
        ctx[2]
      ),
      logoLinkUrl: (
        /*logoLinkUrl*/
        ctx[6]
      ),
      openLogoLinkInNewTab: (
        /*openLogoLinkInNewTab*/
        ctx[7]
      ),
      hideLogo: (
        /*hideLogo*/
        ctx[3]
      ),
      title: (
        /*title*/
        ctx[0]
      ),
      linkable: (
        /*linkable*/
        ctx[28]
      ),
      isInternal: (
        /*isInternal*/
        ctx[34]
      ),
      getSanitizedUrl: (
        /*getSanitizedUrl*/
        ctx[35]
      )
    }
  });
  return {
    c() {
      create_component(logo.$$.fragment);
    },
    m(target, anchor) {
      mount_component(logo, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const logo_changes = {};
      if (dirty[0] & /*logoUrl*/
      4)
        logo_changes.logoUrl = /*logoUrl*/
        ctx2[2];
      if (dirty[0] & /*logoLinkUrl*/
      64)
        logo_changes.logoLinkUrl = /*logoLinkUrl*/
        ctx2[6];
      if (dirty[0] & /*openLogoLinkInNewTab*/
      128)
        logo_changes.openLogoLinkInNewTab = /*openLogoLinkInNewTab*/
        ctx2[7];
      if (dirty[0] & /*hideLogo*/
      8)
        logo_changes.hideLogo = /*hideLogo*/
        ctx2[3];
      if (dirty[0] & /*title*/
      1)
        logo_changes.title = /*title*/
        ctx2[0];
      logo.$set(logo_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(logo.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(logo.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(logo, detaching);
    }
  };
}
function create_if_block_6(ctx) {
  let heading;
  let current;
  heading = new Heading({
    props: {
      size: (
        /*titleSize*/
        ctx[11]
      ),
      textAlign: (
        /*textAlign*/
        ctx[8]
      ),
      color: (
        /*titleColor*/
        ctx[12]
      ),
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(heading.$$.fragment);
    },
    m(target, anchor) {
      mount_component(heading, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const heading_changes = {};
      if (dirty[0] & /*titleSize*/
      2048)
        heading_changes.size = /*titleSize*/
        ctx2[11];
      if (dirty[0] & /*textAlign*/
      256)
        heading_changes.textAlign = /*textAlign*/
        ctx2[8];
      if (dirty[0] & /*titleColor*/
      4096)
        heading_changes.color = /*titleColor*/
        ctx2[12];
      if (dirty[0] & /*title*/
      1 | dirty[1] & /*$$scope*/
      1048576) {
        heading_changes.$$scope = { dirty, ctx: ctx2 };
      }
      heading.$set(heading_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(heading.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(heading.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(heading, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let t;
  return {
    c() {
      t = text(
        /*title*/
        ctx[0]
      );
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*title*/
      1)
        set_data(
          t,
          /*title*/
          ctx2[0]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_5(ctx) {
  let div;
  let usermenu;
  let current;
  usermenu = new UserMenu({ props: { compact: true } });
  return {
    c() {
      div = element("div");
      create_component(usermenu.$$.fragment);
      attr(div, "class", "user top svelte-1r1yuqu");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(usermenu, div, null);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(usermenu.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(usermenu.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(usermenu);
    }
  };
}
function create_if_block_3(ctx) {
  let div;
  let current;
  let each_value = ensure_array_like(
    /*enrichedNavItems*/
    ctx[24]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "links svelte-1r1yuqu");
      toggle_class(
        div,
        "visible",
        /*mobileOpen*/
        ctx[16]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*enrichedNavItems, navigation, mobile*/
      16785424 | dirty[1] & /*navStateStore, handleClickLink, evaluateNavItemConditions*/
      38) {
        each_value = ensure_array_like(
          /*enrichedNavItems*/
          ctx2[24]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div, null);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      if (!current || dirty[0] & /*mobileOpen*/
      65536) {
        toggle_class(
          div,
          "visible",
          /*mobileOpen*/
          ctx2[16]
        );
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_if_block_4(ctx) {
  var _a;
  let navitem;
  let current;
  navitem = new NavItem({
    props: {
      type: (
        /*navItem*/
        ctx[63].type
      ),
      text: (
        /*navItem*/
        ctx[63].text
      ),
      url: (
        /*navItem*/
        ctx[63].url
      ),
      subLinks: (
        /*navItem*/
        ctx[63].subLinks
      ),
      icon: (
        /*navItem*/
        ctx[63].icon
      ),
      internalLink: (
        /*navItem*/
        ctx[63].internalLink
      ),
      customStyles: (
        /*navItem*/
        (_a = ctx[63]._styles) == null ? void 0 : _a.custom
      ),
      leftNav: (
        /*navigation*/
        ctx[4] === "Left"
      ),
      mobile: (
        /*mobile*/
        ctx[13]
      ),
      navStateStore: (
        /*navStateStore*/
        ctx[32]
      )
    }
  });
  navitem.$on(
    "clickLink",
    /*handleClickLink*/
    ctx[36]
  );
  return {
    c() {
      create_component(navitem.$$.fragment);
    },
    m(target, anchor) {
      mount_component(navitem, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      const navitem_changes = {};
      if (dirty[0] & /*enrichedNavItems*/
      16777216)
        navitem_changes.type = /*navItem*/
        ctx2[63].type;
      if (dirty[0] & /*enrichedNavItems*/
      16777216)
        navitem_changes.text = /*navItem*/
        ctx2[63].text;
      if (dirty[0] & /*enrichedNavItems*/
      16777216)
        navitem_changes.url = /*navItem*/
        ctx2[63].url;
      if (dirty[0] & /*enrichedNavItems*/
      16777216)
        navitem_changes.subLinks = /*navItem*/
        ctx2[63].subLinks;
      if (dirty[0] & /*enrichedNavItems*/
      16777216)
        navitem_changes.icon = /*navItem*/
        ctx2[63].icon;
      if (dirty[0] & /*enrichedNavItems*/
      16777216)
        navitem_changes.internalLink = /*navItem*/
        ctx2[63].internalLink;
      if (dirty[0] & /*enrichedNavItems*/
      16777216)
        navitem_changes.customStyles = /*navItem*/
        (_a2 = ctx2[63]._styles) == null ? void 0 : _a2.custom;
      if (dirty[0] & /*navigation*/
      16)
        navitem_changes.leftNav = /*navigation*/
        ctx2[4] === "Left";
      if (dirty[0] & /*mobile*/
      8192)
        navitem_changes.mobile = /*mobile*/
        ctx2[13];
      navitem.$set(navitem_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(navitem.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(navitem.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(navitem, detaching);
    }
  };
}
function create_each_block(ctx) {
  let show_if = (
    /*evaluateNavItemConditions*/
    ctx[33](
      /*navItem*/
      ctx[63]._conditions
    )
  );
  let if_block_anchor;
  let current;
  let if_block = show_if && create_if_block_4(ctx);
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*enrichedNavItems*/
      16777216)
        show_if = /*evaluateNavItemConditions*/
        ctx2[33](
          /*navItem*/
          ctx2[63]._conditions
        );
      if (show_if) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*enrichedNavItems*/
          16777216) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_4(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block_1(ctx) {
  let div;
  let usermenu;
  let t;
  let current;
  usermenu = new UserMenu({});
  let if_block = (
    /*logoPosition*/
    ctx[10] === "bottom" && create_if_block_2(ctx)
  );
  return {
    c() {
      div = element("div");
      create_component(usermenu.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      attr(div, "class", "user left svelte-1r1yuqu");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(usermenu, div, null);
      append(div, t);
      if (if_block)
        if_block.m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*logoPosition*/
        ctx2[10] === "bottom"
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*logoPosition*/
          1024) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_2(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(usermenu.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(usermenu.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(usermenu);
      if (if_block)
        if_block.d();
    }
  };
}
function create_if_block_2(ctx) {
  let div;
  let logo;
  let current;
  logo = new Logo({
    props: {
      logoUrl: (
        /*logoUrl*/
        ctx[2]
      ),
      logoLinkUrl: (
        /*logoLinkUrl*/
        ctx[6]
      ),
      openLogoLinkInNewTab: (
        /*openLogoLinkInNewTab*/
        ctx[7]
      ),
      hideLogo: (
        /*hideLogo*/
        ctx[3]
      ),
      title: (
        /*title*/
        ctx[0]
      ),
      linkable: (
        /*linkable*/
        ctx[28]
      ),
      isInternal: (
        /*isInternal*/
        ctx[34]
      ),
      getSanitizedUrl: (
        /*getSanitizedUrl*/
        ctx[35]
      )
    }
  });
  return {
    c() {
      div = element("div");
      create_component(logo.$$.fragment);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(logo, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const logo_changes = {};
      if (dirty[0] & /*logoUrl*/
      4)
        logo_changes.logoUrl = /*logoUrl*/
        ctx2[2];
      if (dirty[0] & /*logoLinkUrl*/
      64)
        logo_changes.logoLinkUrl = /*logoLinkUrl*/
        ctx2[6];
      if (dirty[0] & /*openLogoLinkInNewTab*/
      128)
        logo_changes.openLogoLinkInNewTab = /*openLogoLinkInNewTab*/
        ctx2[7];
      if (dirty[0] & /*hideLogo*/
      8)
        logo_changes.hideLogo = /*hideLogo*/
        ctx2[3];
      if (dirty[0] & /*title*/
      1)
        logo_changes.title = /*title*/
        ctx2[0];
      logo.$set(logo_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(logo.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(logo.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(logo);
    }
  };
}
function create_fragment(ctx) {
  let div6;
  let div2;
  let t0;
  let div1;
  let div0;
  let div0_class_value;
  let t1;
  let div4;
  let div3;
  let icon;
  let clickOutside_action;
  let t2;
  let div5;
  let div6_class_value;
  let current;
  let mounted;
  let dispose;
  let if_block = (
    /*typeClass*/
    ctx[23] !== "none" && create_if_block(ctx)
  );
  const default_slot_template = (
    /*#slots*/
    ctx[47].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[51],
    null
  );
  icon = new Icon({
    props: {
      color: "var(--spectrum-global-color-gray-600)",
      name: "caret-line-right",
      hoverable: true
    }
  });
  icon.$on(
    "click",
    /*sidePanelStore*/
    ctx[30].actions.close
  );
  return {
    c() {
      div6 = element("div");
      div2 = element("div");
      if (if_block)
        if_block.c();
      t0 = space();
      div1 = element("div");
      div0 = element("div");
      if (default_slot)
        default_slot.c();
      t1 = space();
      div4 = element("div");
      div3 = element("div");
      create_component(icon.$$.fragment);
      t2 = space();
      div5 = element("div");
      attr(div0, "class", div0_class_value = "main size--" + /*pageWidthClass*/
      ctx[21] + " svelte-1r1yuqu");
      attr(div1, "class", "main-wrapper svelte-1r1yuqu");
      attr(div2, "class", "screen-wrapper layout-body svelte-1r1yuqu");
      attr(div3, "class", "side-panel-header svelte-1r1yuqu");
      attr(div4, "id", "side-panel-container");
      attr(div4, "class", "svelte-1r1yuqu");
      toggle_class(
        div4,
        "open",
        /*$sidePanelStore*/
        ctx[15].open
      );
      toggle_class(
        div4,
        "builder",
        /*$builderStore*/
        ctx[14].inBuilder
      );
      attr(div5, "class", "modal-container");
      attr(div6, "class", div6_class_value = "component layout layout--" + /*typeClass*/
      ctx[23] + " svelte-1r1yuqu");
      attr(
        div6,
        "data-id",
        /*screenId*/
        ctx[18]
      );
      attr(div6, "data-name", "Screen");
      attr(div6, "data-icon", "browser");
      toggle_class(div6, "desktop", !/*mobile*/
      ctx[13]);
      toggle_class(div6, "mobile", !!/*mobile*/
      ctx[13]);
    },
    m(target, anchor) {
      insert(target, div6, anchor);
      append(div6, div2);
      if (if_block)
        if_block.m(div2, null);
      append(div2, t0);
      append(div2, div1);
      append(div1, div0);
      if (default_slot) {
        default_slot.m(div0, null);
      }
      append(div6, t1);
      append(div6, div4);
      append(div4, div3);
      mount_component(icon, div3, null);
      append(div6, t2);
      append(div6, div5);
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            div1,
            "click",
            /*click_handler_2*/
            ctx[50]
          ),
          action_destroyer(clickOutside_action = clickOutside.call(
            null,
            div4,
            /*autoCloseSidePanel*/
            ctx[19] ? (
              /*sidePanelStore*/
              ctx[30].actions.close
            ) : null
          ))
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (
        /*typeClass*/
        ctx2[23] !== "none"
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*typeClass*/
          8388608) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div2, t0);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (default_slot) {
        if (default_slot.p && (!current || dirty[1] & /*$$scope*/
        1048576)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[51],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[51]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[51],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty[0] & /*pageWidthClass*/
      2097152 && div0_class_value !== (div0_class_value = "main size--" + /*pageWidthClass*/
      ctx2[21] + " svelte-1r1yuqu")) {
        attr(div0, "class", div0_class_value);
      }
      if (clickOutside_action && is_function(clickOutside_action.update) && dirty[0] & /*autoCloseSidePanel*/
      524288)
        clickOutside_action.update.call(
          null,
          /*autoCloseSidePanel*/
          ctx2[19] ? (
            /*sidePanelStore*/
            ctx2[30].actions.close
          ) : null
        );
      if (!current || dirty[0] & /*$sidePanelStore*/
      32768) {
        toggle_class(
          div4,
          "open",
          /*$sidePanelStore*/
          ctx2[15].open
        );
      }
      if (!current || dirty[0] & /*$builderStore*/
      16384) {
        toggle_class(
          div4,
          "builder",
          /*$builderStore*/
          ctx2[14].inBuilder
        );
      }
      if (!current || dirty[0] & /*typeClass*/
      8388608 && div6_class_value !== (div6_class_value = "component layout layout--" + /*typeClass*/
      ctx2[23] + " svelte-1r1yuqu")) {
        attr(div6, "class", div6_class_value);
      }
      if (!current || dirty[0] & /*screenId*/
      262144) {
        attr(
          div6,
          "data-id",
          /*screenId*/
          ctx2[18]
        );
      }
      if (!current || dirty[0] & /*typeClass, mobile*/
      8396800) {
        toggle_class(div6, "desktop", !/*mobile*/
        ctx2[13]);
      }
      if (!current || dirty[0] & /*typeClass, mobile*/
      8396800) {
        toggle_class(div6, "mobile", !!/*mobile*/
        ctx2[13]);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      transition_in(default_slot, local);
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      transition_out(default_slot, local);
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div6);
      }
      if (if_block)
        if_block.d();
      if (default_slot)
        default_slot.d(detaching);
      destroy_component(icon);
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let mobile;
  let enrichedNavItems;
  let typeClass;
  let navWidthClass;
  let pageWidthClass;
  let navStyle;
  let autoCloseSidePanel;
  let screenId;
  let navigationId;
  let selected;
  let $builderStore;
  let $sidePanelStore;
  let $context;
  let $roleStore;
  let $routeStore;
  let { $$slots: slots = {}, $$scope } = $$props;
  const sdk = getContext("sdk");
  const { routeStore, roleStore, linkable, builderStore: builderStore2, sidePanelStore, modalStore } = sdk;
  component_subscribe($$self, routeStore, (value) => $$invalidate(25, $routeStore = value));
  component_subscribe($$self, roleStore, (value) => $$invalidate(46, $roleStore = value));
  component_subscribe($$self, builderStore2, (value) => $$invalidate(14, $builderStore = value));
  component_subscribe($$self, sidePanelStore, (value) => $$invalidate(15, $sidePanelStore = value));
  const context = getContext("context");
  component_subscribe($$self, context, (value) => $$invalidate(45, $context = value));
  const navStateStore = writable({});
  let { title } = $$props;
  let { hideTitle = false } = $$props;
  let { logoUrl } = $$props;
  let { hideLogo = false } = $$props;
  let { navigation = "Top" } = $$props;
  let { sticky = false } = $$props;
  let { links } = $$props;
  let { width = "Large" } = $$props;
  let { navBackground } = $$props;
  let { navTextColor } = $$props;
  let { navWidth } = $$props;
  let { pageWidth } = $$props;
  let { logoLinkUrl } = $$props;
  let { logoHeight } = $$props;
  let { openLogoLinkInNewTab } = $$props;
  let { textAlign } = $$props;
  let { embedded = false } = $$props;
  const NavigationClasses = { Top: "top", Left: "left", None: "none" };
  const WidthClasses = {
    Max: "max",
    Large: "l",
    Medium: "m",
    Small: "s",
    "Extra small": "xs"
  };
  let { logoPosition = "top" } = $$props;
  let { titleSize = "S" } = $$props;
  let { titleColor } = $$props;
  let mobileOpen = false;
  const store = writable({ headerHeight: 0 });
  setContext("layout", store);
  const enrichNavItem = (navItem) => {
    const internalLink = isInternal(navItem.url);
    return {
      ...navItem,
      internalLink,
      url: internalLink ? navItem.url : ensureExternal(navItem.url)
    };
  };
  const enrichNavItems = (navItems, userRoleHierarchy) => {
    if (!(navItems == null ? void 0 : navItems.length)) {
      return [];
    }
    return navItems.filter((navItem) => {
      if (!navItem.text) {
        return false;
      }
      if (navItem.type !== "sublinks" && !navItem.url) {
        return false;
      }
      const role = navItem.roleId || Roles.BASIC;
      return userRoleHierarchy == null ? void 0 : userRoleHierarchy.find((roleId) => roleId === role);
    }).map((navItem) => {
      var _a;
      const enrichedNavItem = enrichNavItem(navItem);
      if (navItem.type === "sublinks" && ((_a = navItem.subLinks) == null ? void 0 : _a.length)) {
        enrichedNavItem.subLinks = navItem.subLinks.filter((subLink) => subLink.text && subLink.url).map(enrichNavItem);
      }
      return enrichedNavItem;
    });
  };
  function evaluateNavItemConditions(conditions = []) {
    if (!(conditions == null ? void 0 : conditions.length))
      return true;
    const activeConditions = getActiveConditions(conditions);
    const { visible } = reduceConditionActions(activeConditions);
    if (visible == null) {
      const hasShow = conditions.some((cond) => cond.action === "show");
      return hasShow ? false : true;
    }
    return visible;
  }
  const isInternal = (url) => {
    return url == null ? void 0 : url.startsWith("/");
  };
  const ensureExternal = (url) => {
    if (!(url == null ? void 0 : url.length)) {
      return url;
    }
    return !url.startsWith("http") ? `http://${url}` : url;
  };
  const getScreenXOffset = (navigation2, mobile2) => {
    if (navigation2 !== "Left") {
      return 0;
    }
    return mobile2 ? "0px" : "250px";
  };
  const getScreenYOffset = (navigation2, mobile2) => {
    if (mobile2) {
      return !navigation2 || navigation2 === "None" ? 0 : "61px";
    } else {
      return navigation2 === "Top" ? "137px" : "0px";
    }
  };
  const getNavStyle = (backgroundColor, textColor, logoHeight2, width2, height) => {
    let style = `--width:${width2}px; --height:${height}px;`;
    if (backgroundColor) {
      style += `--navBackground:${backgroundColor};`;
    }
    if (textColor) {
      style += `--navTextColor:${textColor};`;
    }
    style += `--logoHeight:${logoHeight2 || 24}px;`;
    return style;
  };
  const getSanitizedUrl = (url, openInNewTab) => {
    if (!isInternal(url)) {
      return ensureExternal(url);
    }
    if (openInNewTab) {
      return `#${url}`;
    }
    return url;
  };
  const handleClickLink = () => {
    $$invalidate(16, mobileOpen = false);
    sidePanelStore.actions.close();
    modalStore.actions.close();
  };
  const click_handler = () => $$invalidate(16, mobileOpen = !mobileOpen);
  const click_handler_1 = () => $$invalidate(16, mobileOpen = false);
  const click_handler_2 = () => {
    if ($builderStore.inBuilder) {
      builderStore2.actions.selectComponent(screenId);
    }
  };
  $$self.$$set = ($$props2) => {
    if ("title" in $$props2)
      $$invalidate(0, title = $$props2.title);
    if ("hideTitle" in $$props2)
      $$invalidate(1, hideTitle = $$props2.hideTitle);
    if ("logoUrl" in $$props2)
      $$invalidate(2, logoUrl = $$props2.logoUrl);
    if ("hideLogo" in $$props2)
      $$invalidate(3, hideLogo = $$props2.hideLogo);
    if ("navigation" in $$props2)
      $$invalidate(4, navigation = $$props2.navigation);
    if ("sticky" in $$props2)
      $$invalidate(5, sticky = $$props2.sticky);
    if ("links" in $$props2)
      $$invalidate(37, links = $$props2.links);
    if ("width" in $$props2)
      $$invalidate(38, width = $$props2.width);
    if ("navBackground" in $$props2)
      $$invalidate(39, navBackground = $$props2.navBackground);
    if ("navTextColor" in $$props2)
      $$invalidate(40, navTextColor = $$props2.navTextColor);
    if ("navWidth" in $$props2)
      $$invalidate(41, navWidth = $$props2.navWidth);
    if ("pageWidth" in $$props2)
      $$invalidate(42, pageWidth = $$props2.pageWidth);
    if ("logoLinkUrl" in $$props2)
      $$invalidate(6, logoLinkUrl = $$props2.logoLinkUrl);
    if ("logoHeight" in $$props2)
      $$invalidate(43, logoHeight = $$props2.logoHeight);
    if ("openLogoLinkInNewTab" in $$props2)
      $$invalidate(7, openLogoLinkInNewTab = $$props2.openLogoLinkInNewTab);
    if ("textAlign" in $$props2)
      $$invalidate(8, textAlign = $$props2.textAlign);
    if ("embedded" in $$props2)
      $$invalidate(9, embedded = $$props2.embedded);
    if ("logoPosition" in $$props2)
      $$invalidate(10, logoPosition = $$props2.logoPosition);
    if ("titleSize" in $$props2)
      $$invalidate(11, titleSize = $$props2.titleSize);
    if ("titleColor" in $$props2)
      $$invalidate(12, titleColor = $$props2.titleColor);
    if ("$$scope" in $$props2)
      $$invalidate(51, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    var _a, _b, _c, _d;
    if ($$self.$$.dirty[1] & /*$context*/
    16384) {
      $$invalidate(13, mobile = $context.device.mobile);
    }
    if ($$self.$$.dirty[0] & /*navigation, mobile*/
    8208) {
      store.set({
        screenXOffset: getScreenXOffset(navigation, mobile),
        screenYOffset: getScreenYOffset(navigation, mobile)
      });
    }
    if ($$self.$$.dirty[1] & /*links, $roleStore*/
    32832) {
      $$invalidate(24, enrichedNavItems = enrichNavItems(links, $roleStore));
    }
    if ($$self.$$.dirty[0] & /*navigation*/
    16) {
      $$invalidate(23, typeClass = NavigationClasses[navigation] || NavigationClasses.None);
    }
    if ($$self.$$.dirty[1] & /*navWidth, width*/
    1152) {
      $$invalidate(22, navWidthClass = WidthClasses[navWidth || width] || WidthClasses.Large);
    }
    if ($$self.$$.dirty[1] & /*pageWidth, width*/
    2176) {
      $$invalidate(21, pageWidthClass = WidthClasses[pageWidth || width] || WidthClasses.Large);
    }
    if ($$self.$$.dirty[1] & /*navBackground, navTextColor, logoHeight, $context*/
    21248) {
      $$invalidate(20, navStyle = getNavStyle(navBackground, navTextColor, logoHeight, $context.device.width, $context.device.height));
    }
    if ($$self.$$.dirty[0] & /*$builderStore, $sidePanelStore*/
    49152) {
      $$invalidate(19, autoCloseSidePanel = !$builderStore.inBuilder && $sidePanelStore.open && !$sidePanelStore.ignoreClicksOutside);
    }
    if ($$self.$$.dirty[0] & /*$builderStore*/
    16384) {
      $$invalidate(18, screenId = $builderStore.inBuilder ? `${(_a = $builderStore.screen) == null ? void 0 : _a._id}-screen` : "screen");
    }
    if ($$self.$$.dirty[0] & /*$builderStore*/
    16384) {
      $$invalidate(17, navigationId = $builderStore.inBuilder ? `${(_b = $builderStore.screen) == null ? void 0 : _b._id}-navigation` : "navigation");
    }
    if ($$self.$$.dirty[0] & /*$builderStore*/
    16384) {
      $$invalidate(44, selected = $builderStore.inBuilder && ((_c = $builderStore.selectedComponentId) == null ? void 0 : _c.endsWith("-navigation")));
    }
    if ($$self.$$.dirty[1] & /*selected*/
    8192) {
      {
        if (selected) {
          const node = (_d = document.getElementsByClassName("nav-wrapper")) == null ? void 0 : _d[0];
          if (node) {
            node.style.scrollMargin = "100px";
            node.scrollIntoView({
              behavior: "smooth",
              block: "nearest",
              inline: "start"
            });
          }
        }
      }
    }
  };
  return [
    title,
    hideTitle,
    logoUrl,
    hideLogo,
    navigation,
    sticky,
    logoLinkUrl,
    openLogoLinkInNewTab,
    textAlign,
    embedded,
    logoPosition,
    titleSize,
    titleColor,
    mobile,
    $builderStore,
    $sidePanelStore,
    mobileOpen,
    navigationId,
    screenId,
    autoCloseSidePanel,
    navStyle,
    pageWidthClass,
    navWidthClass,
    typeClass,
    enrichedNavItems,
    $routeStore,
    routeStore,
    roleStore,
    linkable,
    builderStore2,
    sidePanelStore,
    context,
    navStateStore,
    evaluateNavItemConditions,
    isInternal,
    getSanitizedUrl,
    handleClickLink,
    links,
    width,
    navBackground,
    navTextColor,
    navWidth,
    pageWidth,
    logoHeight,
    selected,
    $context,
    $roleStore,
    slots,
    click_handler,
    click_handler_1,
    click_handler_2,
    $$scope
  ];
}
class Layout extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        title: 0,
        hideTitle: 1,
        logoUrl: 2,
        hideLogo: 3,
        navigation: 4,
        sticky: 5,
        links: 37,
        width: 38,
        navBackground: 39,
        navTextColor: 40,
        navWidth: 41,
        pageWidth: 42,
        logoLinkUrl: 6,
        logoHeight: 43,
        openLogoLinkInNewTab: 7,
        textAlign: 8,
        embedded: 9,
        logoPosition: 10,
        titleSize: 11,
        titleColor: 12
      },
      null,
      [-1, -1, -1]
    );
  }
}
export {
  Layout as default
};
