import { S as SvelteComponent, i as init, s as safe_not_equal, K as Block, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component, u as getContext, v as component_subscribe, ce as makePropSafe, y as empty, f as insert, z as group_outros, A as check_outros, o as detach, M as BlockComponent, F as create_slot, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, aK as FieldType } from "./index-8b9900f1.js";
function create_else_block(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "dataprovider",
      context: "provider",
      props: {
        dataSource: (
          /*dataSource*/
          ctx[1]
        ),
        filter: (
          /*filter*/
          ctx[3]
        ),
        limit: 1,
        paginate: false
      },
      $$slots: { default: [create_default_slot_2] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*dataSource, filter*/
      10)
        blockcomponent_changes.props = {
          dataSource: (
            /*dataSource*/
            ctx2[1]
          ),
          filter: (
            /*filter*/
            ctx2[3]
          ),
          limit: 1,
          paginate: false
        };
      if (dirty & /*$$scope, dataProvider, noRowsMessage*/
      2068) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_if_block$1(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "container",
      props: {
        direction: "column",
        hAlign: "left",
        vAlign: "stretch"
      },
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*$$scope*/
      2048) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_3(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[10].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[11],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        2048)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[11],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[11]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[11],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_default_slot_2(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "repeater",
      context: "repeater",
      props: {
        dataProvider: (
          /*dataProvider*/
          ctx[4]
        ),
        noRowsMessage: (
          /*noRowsMessage*/
          ctx[2] || "We couldn't find a row to display"
        ),
        direction: "column",
        hAlign: "center",
        scope: (
          /*ContextScopes*/
          ctx[6].Global
        )
      },
      $$slots: { default: [create_default_slot_3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*dataProvider, noRowsMessage*/
      20)
        blockcomponent_changes.props = {
          dataProvider: (
            /*dataProvider*/
            ctx2[4]
          ),
          noRowsMessage: (
            /*noRowsMessage*/
            ctx2[2] || "We couldn't find a row to display"
          ),
          direction: "column",
          hAlign: "center",
          scope: (
            /*ContextScopes*/
            ctx2[6].Global
          )
        };
      if (dirty & /*$$scope*/
      2048) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[10].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[11],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        2048)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[11],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[11]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[11],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_default_slot(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block$1, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*actionType*/
      ctx2[0] === "Create"
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_fragment$1(ctx) {
  let block;
  let current;
  block = new Block({
    props: {
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(block.$$.fragment);
    },
    m(target, anchor) {
      mount_component(block, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const block_changes = {};
      if (dirty & /*$$scope, actionType, dataSource, filter, dataProvider, noRowsMessage*/
      2079) {
        block_changes.$$scope = { dirty, ctx: ctx2 };
      }
      block.$set(block_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(block.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(block.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(block, detaching);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let providerId;
  let dataProvider;
  let filter;
  let $component;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { actionType } = $$props;
  let { dataSource } = $$props;
  let { rowId } = $$props;
  let { noRowsMessage } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(9, $component = value));
  const { ContextScopes } = getContext("sdk");
  $$self.$$set = ($$props2) => {
    if ("actionType" in $$props2)
      $$invalidate(0, actionType = $$props2.actionType);
    if ("dataSource" in $$props2)
      $$invalidate(1, dataSource = $$props2.dataSource);
    if ("rowId" in $$props2)
      $$invalidate(7, rowId = $$props2.rowId);
    if ("noRowsMessage" in $$props2)
      $$invalidate(2, noRowsMessage = $$props2.noRowsMessage);
    if ("$$scope" in $$props2)
      $$invalidate(11, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$component*/
    512) {
      $$invalidate(8, providerId = `${$component.id}-provider`);
    }
    if ($$self.$$.dirty & /*providerId*/
    256) {
      $$invalidate(4, dataProvider = `{{ literal ${makePropSafe(providerId)} }}`);
    }
    if ($$self.$$.dirty & /*rowId*/
    128) {
      $$invalidate(3, filter = [
        {
          field: "_id",
          operator: "equal",
          type: "string",
          value: !rowId ? `{{ ${makePropSafe("url")}.${makePropSafe("id")} }}` : rowId,
          valueType: "Binding"
        }
      ]);
    }
  };
  return [
    actionType,
    dataSource,
    noRowsMessage,
    filter,
    dataProvider,
    component,
    ContextScopes,
    rowId,
    providerId,
    $component,
    slots,
    $$scope
  ];
}
class FormBlockWrapper extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, {
      actionType: 0,
      dataSource: 1,
      rowId: 7,
      noRowsMessage: 2
    });
  }
}
function create_if_block(ctx) {
  var _a;
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: (
        /*getComponentForField*/
        ctx[2](
          /*field*/
          ctx[0]
        )
      ),
      props: (
        /*getPropsForField*/
        ctx[3](
          /*field*/
          ctx[0]
        )
      ),
      order: (
        /*order*/
        ctx[1]
      ),
      interactive: true,
      name: (
        /*field*/
        (_a = ctx[0]) == null ? void 0 : _a.field
      )
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      const blockcomponent_changes = {};
      if (dirty & /*field*/
      1)
        blockcomponent_changes.type = /*getComponentForField*/
        ctx2[2](
          /*field*/
          ctx2[0]
        );
      if (dirty & /*field*/
      1)
        blockcomponent_changes.props = /*getPropsForField*/
        ctx2[3](
          /*field*/
          ctx2[0]
        );
      if (dirty & /*order*/
      2)
        blockcomponent_changes.order = /*order*/
        ctx2[1];
      if (dirty & /*field*/
      1)
        blockcomponent_changes.name = /*field*/
        (_a2 = ctx2[0]) == null ? void 0 : _a2.field;
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_fragment(ctx) {
  let show_if = (
    /*getComponentForField*/
    ctx[2](
      /*field*/
      ctx[0]
    ) && /*field*/
    ctx[0].active
  );
  let if_block_anchor;
  let current;
  let if_block = show_if && create_if_block(ctx);
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (dirty & /*field*/
      1)
        show_if = /*getComponentForField*/
        ctx2[2](
          /*field*/
          ctx2[0]
        ) && /*field*/
        ctx2[0].active;
      if (show_if) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*field*/
          1) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { field } = $$props;
  let { schema } = $$props;
  let { order } = $$props;
  const FieldTypeToComponentMap = {
    [FieldType.STRING]: "stringfield",
    [FieldType.NUMBER]: "numberfield",
    [FieldType.BIGINT]: "bigintfield",
    [FieldType.OPTIONS]: "optionsfield",
    [FieldType.ARRAY]: "multifieldselect",
    [FieldType.BOOLEAN]: "booleanfield",
    [FieldType.LONGFORM]: "longformfield",
    [FieldType.DATETIME]: "datetimefield",
    [FieldType.SIGNATURE_SINGLE]: "signaturesinglefield",
    [FieldType.ATTACHMENTS]: "attachmentfield",
    [FieldType.ATTACHMENT_SINGLE]: "attachmentsinglefield",
    [FieldType.LINK]: "relationshipfield",
    [FieldType.JSON]: "jsonfield",
    [FieldType.BARCODEQR]: "codescanner",
    [FieldType.BB_REFERENCE]: "bbreferencefield",
    [FieldType.BB_REFERENCE_SINGLE]: "bbreferencesinglefield"
  };
  const getFieldSchema = (field2) => {
    const fieldSchemaName = field2.field || field2.name;
    if (!fieldSchemaName || !(schema == null ? void 0 : schema[fieldSchemaName])) {
      return null;
    }
    return schema[fieldSchemaName];
  };
  const getComponentForField = (field2) => {
    const fieldSchema = getFieldSchema(field2);
    if (!fieldSchema) {
      return null;
    }
    const { type } = fieldSchema;
    return FieldTypeToComponentMap[type];
  };
  const getPropsForField = (field2) => {
    const fieldSchema = getFieldSchema(field2);
    const displayName = (fieldSchema == null ? void 0 : fieldSchema.displayName) || field2.name;
    let fieldProps = field2._component ? { ...field2 } : {
      field: field2.name,
      label: displayName,
      placeholder: displayName,
      _instanceName: field2.name
    };
    fieldProps = { ...getPropsByType(field2), ...fieldProps };
    return fieldProps;
  };
  function getPropsByType(field2) {
    const propsMapByType = {
      [FieldType.ATTACHMENTS]: (_field, schema2) => {
        var _a, _b;
        return {
          maximum: (_b = (_a = schema2 == null ? void 0 : schema2.constraints) == null ? void 0 : _a.length) == null ? void 0 : _b.maximum
        };
      },
      [FieldType.DATETIME]: (_field, schema2) => {
        const props = { valueAsTimestamp: !(schema2 == null ? void 0 : schema2.timeOnly) };
        if (schema2 == null ? void 0 : schema2.dateOnly) {
          props.enableTime = false;
        }
        return props;
      }
    };
    const fieldSchema = getFieldSchema(field2);
    const mapper = propsMapByType[fieldSchema.type];
    if (mapper) {
      return mapper(field2, fieldSchema);
    }
  }
  $$self.$$set = ($$props2) => {
    if ("field" in $$props2)
      $$invalidate(0, field = $$props2.field);
    if ("schema" in $$props2)
      $$invalidate(4, schema = $$props2.schema);
    if ("order" in $$props2)
      $$invalidate(1, order = $$props2.order);
  };
  return [field, order, getComponentForField, getPropsForField, schema];
}
class FormBlockComponent extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { field: 0, schema: 4, order: 1 });
  }
}
export {
  FormBlockComponent as F,
  FormBlockWrapper as a
};
