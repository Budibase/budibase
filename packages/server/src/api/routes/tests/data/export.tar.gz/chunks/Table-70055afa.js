import { S as SvelteComponent, i as init, s as safe_not_equal, F as create_slot, e as element, b as attr, d as toggle_class, f as insert, l as listen, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, k as transition_in, n as transition_out, o as detach, V as bubble, t as text, g as append, j as set_data, B as noop, I as Icon, a as space, c as create_component, m as mount_component, p as destroy_component, ao as dayjs, N as ensure_array_like, y as empty, z as group_outros, A as check_outros, O as destroy_each, Y as createEventDispatcher, cw as Link, ae as src_url_equal, cx as stop_propagation, aU as copyToClipboard, a6 as notifications, b9 as construct_svelte_component, al as set_style, bv as processStringSync, bj as Checkbox_1, cb as ActionButton, h as is_function, U as onMount, bD as cloneDeep, W as binding_callbacks, P as ProgressCircle, a0 as bind, a1 as add_flush_callback, c4 as deepGet, u as getContext, cy as Provider, am as null_to_empty, q as action_destroyer, v as component_subscribe, w as onDestroy } from "./index-8b9900f1.js";
import { c as canBeSortColumn } from "./table-46a4929b.js";
function create_fragment$c(ctx) {
  let span;
  let span_style_value;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[12].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[11],
    null
  );
  return {
    c() {
      span = element("span");
      if (default_slot)
        default_slot.c();
      attr(span, "class", "spectrum-Label svelte-35zeo5");
      attr(span, "style", span_style_value = /*outlineColor*/
      ctx[10] ? `border: 2px solid ${/*outlineColor*/
      ctx[10]}` : "");
      toggle_class(
        span,
        "hoverable",
        /*hoverable*/
        ctx[9]
      );
      toggle_class(
        span,
        "spectrum-Label--small",
        /*size*/
        ctx[0] === "S"
      );
      toggle_class(
        span,
        "spectrum-Label--large",
        /*size*/
        ctx[0] === "L"
      );
      toggle_class(
        span,
        "spectrum-Label--grey",
        /*grey*/
        ctx[1]
      );
      toggle_class(
        span,
        "spectrum-Label--red",
        /*red*/
        ctx[2]
      );
      toggle_class(
        span,
        "spectrum-Label--green",
        /*green*/
        ctx[6]
      );
      toggle_class(
        span,
        "spectrum-Label--orange",
        /*orange*/
        ctx[3]
      );
      toggle_class(
        span,
        "spectrum-Label--yellow",
        /*yellow*/
        ctx[4]
      );
      toggle_class(
        span,
        "spectrum-Label--seafoam",
        /*seafoam*/
        ctx[5]
      );
      toggle_class(
        span,
        "spectrum-Label--active",
        /*active*/
        ctx[7]
      );
      toggle_class(
        span,
        "spectrum-Label--inactive",
        /*inactive*/
        ctx[8]
      );
    },
    m(target, anchor) {
      insert(target, span, anchor);
      if (default_slot) {
        default_slot.m(span, null);
      }
      current = true;
      if (!mounted) {
        dispose = listen(
          span,
          "click",
          /*click_handler*/
          ctx[13]
        );
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        2048)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[11],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[11]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[11],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*outlineColor*/
      1024 && span_style_value !== (span_style_value = /*outlineColor*/
      ctx2[10] ? `border: 2px solid ${/*outlineColor*/
      ctx2[10]}` : "")) {
        attr(span, "style", span_style_value);
      }
      if (!current || dirty & /*hoverable*/
      512) {
        toggle_class(
          span,
          "hoverable",
          /*hoverable*/
          ctx2[9]
        );
      }
      if (!current || dirty & /*size*/
      1) {
        toggle_class(
          span,
          "spectrum-Label--small",
          /*size*/
          ctx2[0] === "S"
        );
      }
      if (!current || dirty & /*size*/
      1) {
        toggle_class(
          span,
          "spectrum-Label--large",
          /*size*/
          ctx2[0] === "L"
        );
      }
      if (!current || dirty & /*grey*/
      2) {
        toggle_class(
          span,
          "spectrum-Label--grey",
          /*grey*/
          ctx2[1]
        );
      }
      if (!current || dirty & /*red*/
      4) {
        toggle_class(
          span,
          "spectrum-Label--red",
          /*red*/
          ctx2[2]
        );
      }
      if (!current || dirty & /*green*/
      64) {
        toggle_class(
          span,
          "spectrum-Label--green",
          /*green*/
          ctx2[6]
        );
      }
      if (!current || dirty & /*orange*/
      8) {
        toggle_class(
          span,
          "spectrum-Label--orange",
          /*orange*/
          ctx2[3]
        );
      }
      if (!current || dirty & /*yellow*/
      16) {
        toggle_class(
          span,
          "spectrum-Label--yellow",
          /*yellow*/
          ctx2[4]
        );
      }
      if (!current || dirty & /*seafoam*/
      32) {
        toggle_class(
          span,
          "spectrum-Label--seafoam",
          /*seafoam*/
          ctx2[5]
        );
      }
      if (!current || dirty & /*active*/
      128) {
        toggle_class(
          span,
          "spectrum-Label--active",
          /*active*/
          ctx2[7]
        );
      }
      if (!current || dirty & /*inactive*/
      256) {
        toggle_class(
          span,
          "spectrum-Label--inactive",
          /*inactive*/
          ctx2[8]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(span);
      }
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance$c($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { size = "M" } = $$props;
  let { grey = false } = $$props;
  let { red = false } = $$props;
  let { orange = false } = $$props;
  let { yellow = false } = $$props;
  let { seafoam = false } = $$props;
  let { green = false } = $$props;
  let { active = false } = $$props;
  let { inactive = false } = $$props;
  let { hoverable = false } = $$props;
  let { outlineColor = null } = $$props;
  function click_handler2(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("size" in $$props2)
      $$invalidate(0, size = $$props2.size);
    if ("grey" in $$props2)
      $$invalidate(1, grey = $$props2.grey);
    if ("red" in $$props2)
      $$invalidate(2, red = $$props2.red);
    if ("orange" in $$props2)
      $$invalidate(3, orange = $$props2.orange);
    if ("yellow" in $$props2)
      $$invalidate(4, yellow = $$props2.yellow);
    if ("seafoam" in $$props2)
      $$invalidate(5, seafoam = $$props2.seafoam);
    if ("green" in $$props2)
      $$invalidate(6, green = $$props2.green);
    if ("active" in $$props2)
      $$invalidate(7, active = $$props2.active);
    if ("inactive" in $$props2)
      $$invalidate(8, inactive = $$props2.inactive);
    if ("hoverable" in $$props2)
      $$invalidate(9, hoverable = $$props2.hoverable);
    if ("outlineColor" in $$props2)
      $$invalidate(10, outlineColor = $$props2.outlineColor);
    if ("$$scope" in $$props2)
      $$invalidate(11, $$scope = $$props2.$$scope);
  };
  return [
    size,
    grey,
    red,
    orange,
    yellow,
    seafoam,
    green,
    active,
    inactive,
    hoverable,
    outlineColor,
    $$scope,
    slots,
    click_handler2
  ];
}
class Badge extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$c, create_fragment$c, safe_not_equal, {
      size: 0,
      grey: 1,
      red: 2,
      orange: 3,
      yellow: 4,
      seafoam: 5,
      green: 6,
      active: 7,
      inactive: 8,
      hoverable: 9,
      outlineColor: 10
    });
  }
}
function create_fragment$b(ctx) {
  let div;
  let t_value = (typeof /*value*/
  ctx[0] === "object" ? JSON.stringify(
    /*value*/
    ctx[0]
  ) : (
    /*value*/
    ctx[0]
  )) + "";
  let t;
  return {
    c() {
      var _a;
      div = element("div");
      t = text(t_value);
      attr(div, "class", "svelte-1acrdjg");
      toggle_class(
        div,
        "capitalise",
        /*schema*/
        (_a = ctx[1]) == null ? void 0 : _a.capitalise
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
    },
    p(ctx2, [dirty]) {
      var _a;
      if (dirty & /*value*/
      1 && t_value !== (t_value = (typeof /*value*/
      ctx2[0] === "object" ? JSON.stringify(
        /*value*/
        ctx2[0]
      ) : (
        /*value*/
        ctx2[0]
      )) + ""))
        set_data(t, t_value);
      if (dirty & /*schema*/
      2) {
        toggle_class(
          div,
          "capitalise",
          /*schema*/
          (_a = ctx2[1]) == null ? void 0 : _a.capitalise
        );
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function instance$b($$self, $$props, $$invalidate) {
  let { value } = $$props;
  let { schema } = $$props;
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("schema" in $$props2)
      $$invalidate(1, schema = $$props2.schema);
  };
  return [value, schema];
}
class StringRenderer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$b, create_fragment$b, safe_not_equal, { value: 0, schema: 1 });
  }
}
function create_fragment$a(ctx) {
  let label;
  let input;
  let input_checked_value;
  let t0;
  let span;
  let icon0;
  let t1;
  let icon1;
  let current;
  icon0 = new Icon({ props: { name: "check", size: "S" } });
  icon1 = new Icon({ props: { name: "minus", size: "S" } });
  return {
    c() {
      label = element("label");
      input = element("input");
      t0 = space();
      span = element("span");
      create_component(icon0.$$.fragment);
      t1 = space();
      create_component(icon1.$$.fragment);
      attr(input, "type", "checkbox");
      attr(input, "class", "spectrum-Checkbox-input");
      attr(input, "id", "checkbox-1");
      input.disabled = true;
      input.checked = input_checked_value = !!/*value*/
      ctx[0];
      attr(span, "class", "spectrum-Checkbox-box svelte-ww1lnr");
      attr(label, "class", "spectrum-Checkbox spectrum-Checkbox--sizeM spectrum-Checkbox--emphasized svelte-ww1lnr");
    },
    m(target, anchor) {
      insert(target, label, anchor);
      append(label, input);
      append(label, t0);
      append(label, span);
      mount_component(icon0, span, null);
      append(span, t1);
      mount_component(icon1, span, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (!current || dirty & /*value*/
      1 && input_checked_value !== (input_checked_value = !!/*value*/
      ctx2[0])) {
        input.checked = input_checked_value;
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon0.$$.fragment, local);
      transition_in(icon1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon0.$$.fragment, local);
      transition_out(icon1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(label);
      }
      destroy_component(icon0);
      destroy_component(icon1);
    }
  };
}
function instance$a($$self, $$props, $$invalidate) {
  let { value } = $$props;
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
  };
  return [value];
}
class BooleanRenderer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$a, create_fragment$a, safe_not_equal, { value: 0 });
  }
}
function create_fragment$9(ctx) {
  let div;
  let t_value = dayjs(
    /*isTimeOnly*/
    ctx[1] ? (
      /*time*/
      ctx[2]
    ) : (
      /*value*/
      ctx[0]
    )
  ).format(
    /*format*/
    ctx[3]
  ) + "";
  let t;
  return {
    c() {
      div = element("div");
      t = text(t_value);
      attr(div, "class", "svelte-1abuiv5");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
    },
    p(ctx2, [dirty]) {
      if (dirty & /*isTimeOnly, time, value, format*/
      15 && t_value !== (t_value = dayjs(
        /*isTimeOnly*/
        ctx2[1] ? (
          /*time*/
          ctx2[2]
        ) : (
          /*value*/
          ctx2[0]
        )
      ).format(
        /*format*/
        ctx2[3]
      ) + ""))
        set_data(t, t_value);
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function instance$9($$self, $$props, $$invalidate) {
  let time;
  let isTimeOnly;
  let isDateOnly;
  let format;
  let { value } = $$props;
  let { schema } = $$props;
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("schema" in $$props2)
      $$invalidate(4, schema = $$props2.schema);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*value*/
    1) {
      $$invalidate(2, time = /* @__PURE__ */ new Date(`0-${value}`));
    }
    if ($$self.$$.dirty & /*time, schema*/
    20) {
      $$invalidate(1, isTimeOnly = !isNaN(time) || (schema == null ? void 0 : schema.timeOnly));
    }
    if ($$self.$$.dirty & /*schema*/
    16) {
      $$invalidate(5, isDateOnly = schema == null ? void 0 : schema.dateOnly);
    }
    if ($$self.$$.dirty & /*isTimeOnly, isDateOnly*/
    34) {
      $$invalidate(3, format = isTimeOnly ? "HH:mm:ss" : isDateOnly ? "MMMM D YYYY" : "MMMM D YYYY, HH:mm");
    }
  };
  return [value, isTimeOnly, time, format, schema, isDateOnly];
}
class DateTimeRenderer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$9, create_fragment$9, safe_not_equal, { value: 0, schema: 4 });
  }
}
function get_each_context$3(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[7] = list[i];
  return child_ctx;
}
function create_if_block_1$3(ctx) {
  let badge;
  let current;
  badge = new Badge({
    props: {
      hoverable: true,
      grey: true,
      $$slots: { default: [create_default_slot$7] },
      $$scope: { ctx }
    }
  });
  badge.$on(
    "click",
    /*onClick*/
    ctx[2]
  );
  return {
    c() {
      create_component(badge.$$.fragment);
    },
    m(target, anchor) {
      mount_component(badge, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const badge_changes = {};
      if (dirty & /*$$scope, relationships*/
      1025) {
        badge_changes.$$scope = { dirty, ctx: ctx2 };
      }
      badge.$set(badge_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(badge.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(badge.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(badge, detaching);
    }
  };
}
function create_default_slot$7(ctx) {
  let t_value = (
    /*relationship*/
    ctx[7].primaryDisplay + ""
  );
  let t;
  return {
    c() {
      t = text(t_value);
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*relationships*/
      1 && t_value !== (t_value = /*relationship*/
      ctx2[7].primaryDisplay + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_each_block$3(ctx) {
  var _a;
  let if_block_anchor;
  let current;
  let if_block = (
    /*relationship*/
    ((_a = ctx[7]) == null ? void 0 : _a.primaryDisplay) && create_if_block_1$3(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      if (
        /*relationship*/
        (_a2 = ctx2[7]) == null ? void 0 : _a2.primaryDisplay
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*relationships*/
          1) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_1$3(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block$6(ctx) {
  let div;
  let t0;
  let t1;
  let t2;
  return {
    c() {
      div = element("div");
      t0 = text("+");
      t1 = text(
        /*leftover*/
        ctx[1]
      );
      t2 = text(" more");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t0);
      append(div, t1);
      append(div, t2);
    },
    p(ctx2, dirty) {
      if (dirty & /*leftover*/
      2)
        set_data(
          t1,
          /*leftover*/
          ctx2[1]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_fragment$8(ctx) {
  let t;
  let if_block_anchor;
  let current;
  let each_value = ensure_array_like(
    /*relationships*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$3(get_each_context$3(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  let if_block = (
    /*leftover*/
    ctx[1] && create_if_block$6(ctx)
  );
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (dirty & /*onClick, relationships*/
      5) {
        each_value = ensure_array_like(
          /*relationships*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$3(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$3(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(t.parentNode, t);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      if (
        /*leftover*/
        ctx2[1]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block$6(ctx2);
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      destroy_each(each_blocks, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
const displayLimit$2 = 5;
function instance$8($$self, $$props, $$invalidate) {
  let relationships;
  let leftover;
  let { row } = $$props;
  let { value } = $$props;
  let { schema } = $$props;
  const dispatch = createEventDispatcher();
  const onClick = (e) => {
    e.stopPropagation();
    dispatch("clickrelationship", {
      tableId: row.tableId,
      rowId: row._id,
      fieldName: schema == null ? void 0 : schema.name
    });
  };
  $$self.$$set = ($$props2) => {
    if ("row" in $$props2)
      $$invalidate(3, row = $$props2.row);
    if ("value" in $$props2)
      $$invalidate(4, value = $$props2.value);
    if ("schema" in $$props2)
      $$invalidate(5, schema = $$props2.schema);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*value*/
    16) {
      $$invalidate(0, relationships = (value == null ? void 0 : value.slice(0, displayLimit$2)) ?? []);
    }
    if ($$self.$$.dirty & /*value, relationships*/
    17) {
      $$invalidate(1, leftover = ((value == null ? void 0 : value.length) ?? 0) - relationships.length);
    }
  };
  return [relationships, leftover, onClick, row, value, schema];
}
class RelationshipRenderer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$8, create_fragment$8, safe_not_equal, { row: 3, value: 4, schema: 5 });
  }
}
function get_each_context$2(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[5] = list[i];
  return child_ctx;
}
function create_else_block$1(ctx) {
  let div;
  let link;
  let div_title_value;
  let current;
  link = new Link({
    props: {
      quiet: true,
      target: "_blank",
      download: (
        /*attachment*/
        ctx[5].name
      ),
      href: (
        /*attachment*/
        ctx[5].url
      ),
      $$slots: { default: [create_default_slot_1$1] },
      $$scope: { ctx }
    }
  });
  link.$on("click", click_handler_1);
  return {
    c() {
      div = element("div");
      create_component(link.$$.fragment);
      attr(div, "class", "file svelte-1abirxi");
      attr(div, "title", div_title_value = /*attachment*/
      ctx[5].name);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(link, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const link_changes = {};
      if (dirty & /*attachments*/
      1)
        link_changes.download = /*attachment*/
        ctx2[5].name;
      if (dirty & /*attachments*/
      1)
        link_changes.href = /*attachment*/
        ctx2[5].url;
      if (dirty & /*$$scope, attachments*/
      257) {
        link_changes.$$scope = { dirty, ctx: ctx2 };
      }
      link.$set(link_changes);
      if (!current || dirty & /*attachments*/
      1 && div_title_value !== (div_title_value = /*attachment*/
      ctx2[5].name)) {
        attr(div, "title", div_title_value);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(link.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(link.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(link);
    }
  };
}
function create_if_block_1$2(ctx) {
  let link;
  let current;
  link = new Link({
    props: {
      quiet: true,
      target: "_blank",
      download: (
        /*attachment*/
        ctx[5].name
      ),
      href: (
        /*attachment*/
        ctx[5].url
      ),
      $$slots: { default: [create_default_slot$6] },
      $$scope: { ctx }
    }
  });
  link.$on("click", click_handler);
  return {
    c() {
      create_component(link.$$.fragment);
    },
    m(target, anchor) {
      mount_component(link, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const link_changes = {};
      if (dirty & /*attachments*/
      1)
        link_changes.download = /*attachment*/
        ctx2[5].name;
      if (dirty & /*attachments*/
      1)
        link_changes.href = /*attachment*/
        ctx2[5].url;
      if (dirty & /*$$scope, attachments*/
      257) {
        link_changes.$$scope = { dirty, ctx: ctx2 };
      }
      link.$set(link_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(link.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(link.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(link, detaching);
    }
  };
}
function create_default_slot_1$1(ctx) {
  let t_value = (
    /*attachment*/
    ctx[5].extension + ""
  );
  let t;
  return {
    c() {
      t = text(t_value);
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*attachments*/
      1 && t_value !== (t_value = /*attachment*/
      ctx2[5].extension + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot$6(ctx) {
  let div;
  let img;
  let img_src_value;
  let img_alt_value;
  let div_title_value;
  return {
    c() {
      div = element("div");
      img = element("img");
      if (!src_url_equal(img.src, img_src_value = /*attachment*/
      ctx[5].url))
        attr(img, "src", img_src_value);
      attr(img, "alt", img_alt_value = /*attachment*/
      ctx[5].extension);
      attr(img, "class", "svelte-1abirxi");
      attr(div, "class", "center svelte-1abirxi");
      attr(div, "title", div_title_value = /*attachment*/
      ctx[5].name);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, img);
    },
    p(ctx2, dirty) {
      if (dirty & /*attachments*/
      1 && !src_url_equal(img.src, img_src_value = /*attachment*/
      ctx2[5].url)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*attachments*/
      1 && img_alt_value !== (img_alt_value = /*attachment*/
      ctx2[5].extension)) {
        attr(img, "alt", img_alt_value);
      }
      if (dirty & /*attachments*/
      1 && div_title_value !== (div_title_value = /*attachment*/
      ctx2[5].name)) {
        attr(div, "title", div_title_value);
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_each_block$2(ctx) {
  let show_if;
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block_1$2, create_else_block$1];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (dirty & /*attachments*/
    1)
      show_if = null;
    if (show_if == null)
      show_if = !!/*isImage*/
      ctx2[2](
        /*attachment*/
        ctx2[5].extension
      );
    if (show_if)
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx, -1);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2, dirty);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_if_block$5(ctx) {
  let div;
  let t0;
  let t1;
  let t2;
  return {
    c() {
      div = element("div");
      t0 = text("+");
      t1 = text(
        /*leftover*/
        ctx[1]
      );
      t2 = text(" more");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t0);
      append(div, t1);
      append(div, t2);
    },
    p(ctx2, dirty) {
      if (dirty & /*leftover*/
      2)
        set_data(
          t1,
          /*leftover*/
          ctx2[1]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_fragment$7(ctx) {
  let t;
  let if_block_anchor;
  let current;
  let each_value = ensure_array_like(
    /*attachments*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$2(get_each_context$2(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  let if_block = (
    /*leftover*/
    ctx[1] && create_if_block$5(ctx)
  );
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (dirty & /*attachments, isImage*/
      5) {
        each_value = ensure_array_like(
          /*attachments*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$2(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$2(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(t.parentNode, t);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      if (
        /*leftover*/
        ctx2[1]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block$5(ctx2);
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      destroy_each(each_blocks, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
const displayLimit$1 = 5;
const click_handler = (e) => {
  e.stopPropagation();
};
const click_handler_1 = (e) => {
  e.stopPropagation();
};
function instance$7($$self, $$props, $$invalidate) {
  let attachments;
  let leftover;
  let { value } = $$props;
  const imageExtensions = ["png", "tiff", "gif", "raw", "jpg", "jpeg"];
  const isImage = (extension) => {
    return imageExtensions.includes((extension == null ? void 0 : extension.toLowerCase()) ?? "");
  };
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(3, value = $$props2.value);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*value*/
    8) {
      $$invalidate(0, attachments = (value == null ? void 0 : value.slice(0, displayLimit$1)) ?? []);
    }
    if ($$self.$$.dirty & /*value, attachments*/
    9) {
      $$invalidate(1, leftover = ((value == null ? void 0 : value.length) ?? 0) - attachments.length);
    }
  };
  return [attachments, leftover, isImage, value];
}
class AttachmentRenderer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$7, create_fragment$7, safe_not_equal, { value: 3 });
  }
}
function get_each_context$1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[4] = list[i];
  return child_ctx;
}
function create_default_slot$5(ctx) {
  let t_value = (
    /*badge*/
    ctx[4] + ""
  );
  let t;
  return {
    c() {
      t = text(t_value);
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*badges*/
      1 && t_value !== (t_value = /*badge*/
      ctx2[4] + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_each_block$1(ctx) {
  let badge_1;
  let current;
  badge_1 = new Badge({
    props: {
      size: "S",
      grey: true,
      $$slots: { default: [create_default_slot$5] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(badge_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(badge_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const badge_1_changes = {};
      if (dirty & /*$$scope, badges*/
      129) {
        badge_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      badge_1.$set(badge_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(badge_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(badge_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(badge_1, detaching);
    }
  };
}
function create_if_block$4(ctx) {
  let div;
  let t0;
  let t1;
  let t2;
  return {
    c() {
      div = element("div");
      t0 = text("+");
      t1 = text(
        /*leftover*/
        ctx[1]
      );
      t2 = text(" more");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t0);
      append(div, t1);
      append(div, t2);
    },
    p(ctx2, dirty) {
      if (dirty & /*leftover*/
      2)
        set_data(
          t1,
          /*leftover*/
          ctx2[1]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_fragment$6(ctx) {
  let t;
  let if_block_anchor;
  let current;
  let each_value = ensure_array_like(
    /*badges*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$1(get_each_context$1(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  let if_block = (
    /*leftover*/
    ctx[1] && create_if_block$4(ctx)
  );
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (dirty & /*badges*/
      1) {
        each_value = ensure_array_like(
          /*badges*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$1(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$1(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(t.parentNode, t);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      if (
        /*leftover*/
        ctx2[1]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block$4(ctx2);
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      destroy_each(each_blocks, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
const displayLimit = 5;
function instance$6($$self, $$props, $$invalidate) {
  let arrayValue;
  let badges;
  let leftover;
  let { value } = $$props;
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(2, value = $$props2.value);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*value*/
    4) {
      $$invalidate(3, arrayValue = Array.isArray(value) ? value : [value].filter((x) => !!x));
    }
    if ($$self.$$.dirty & /*arrayValue*/
    8) {
      $$invalidate(0, badges = arrayValue.slice(0, displayLimit));
    }
    if ($$self.$$.dirty & /*arrayValue, badges*/
    9) {
      $$invalidate(1, leftover = arrayValue.length - badges.length);
    }
  };
  return [badges, leftover, value, arrayValue];
}
class ArrayRenderer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$6, create_fragment$6, safe_not_equal, { value: 2 });
  }
}
function create_fragment$5(ctx) {
  let div;
  let icon;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({ props: { size: "S", name: "copy" } });
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      current = true;
      if (!mounted) {
        dispose = listen(div, "click", stop_propagation(
          /*onClick*/
          ctx[0]
        ));
        mounted = true;
      }
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
      mounted = false;
      dispose();
    }
  };
}
function instance$5($$self, $$props, $$invalidate) {
  let { value } = $$props;
  const onClick = async (e) => {
    e.stopPropagation();
    try {
      await copyToClipboard(value);
      notifications.success("Copied to clipboard");
    } catch (error) {
      notifications.error("Failed to copy to clipboard. Check the dev console for the value.");
      console.warn("Failed to copy the value", value);
    }
  };
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(1, value = $$props2.value);
  };
  return [onClick, value];
}
class InternalRenderer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$5, create_fragment$5, safe_not_equal, { value: 1 });
  }
}
function create_if_block$3(ctx) {
  let div;
  let switch_instance;
  let current;
  var switch_value = (
    /*renderer*/
    ctx[3]
  );
  function switch_props(ctx2, dirty) {
    return {
      props: {
        row: (
          /*row*/
          ctx2[0]
        ),
        schema: (
          /*schema*/
          ctx2[1]
        ),
        value: (
          /*cellValue*/
          ctx2[4]
        ),
        $$slots: { default: [create_default_slot$4] },
        $$scope: { ctx: ctx2 }
      }
    };
  }
  if (switch_value) {
    switch_instance = construct_svelte_component(switch_value, switch_props(ctx));
    switch_instance.$on(
      "clickrelationship",
      /*clickrelationship_handler*/
      ctx[10]
    );
    switch_instance.$on(
      "buttonclick",
      /*buttonclick_handler*/
      ctx[11]
    );
  }
  return {
    c() {
      div = element("div");
      if (switch_instance)
        create_component(switch_instance.$$.fragment);
      set_style(
        div,
        "--max-cell-width",
        /*schema*/
        ctx[1].width ? "none" : "200px"
      );
      attr(div, "class", "svelte-16j2cvj");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (switch_instance)
        mount_component(switch_instance, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*renderer*/
      8 && switch_value !== (switch_value = /*renderer*/
      ctx2[3])) {
        if (switch_instance) {
          group_outros();
          const old_component = switch_instance;
          transition_out(old_component.$$.fragment, 1, 0, () => {
            destroy_component(old_component, 1);
          });
          check_outros();
        }
        if (switch_value) {
          switch_instance = construct_svelte_component(switch_value, switch_props(ctx2));
          switch_instance.$on(
            "clickrelationship",
            /*clickrelationship_handler*/
            ctx2[10]
          );
          switch_instance.$on(
            "buttonclick",
            /*buttonclick_handler*/
            ctx2[11]
          );
          create_component(switch_instance.$$.fragment);
          transition_in(switch_instance.$$.fragment, 1);
          mount_component(switch_instance, div, null);
        } else {
          switch_instance = null;
        }
      } else if (switch_value) {
        const switch_instance_changes = {};
        if (dirty & /*row*/
        1)
          switch_instance_changes.row = /*row*/
          ctx2[0];
        if (dirty & /*schema*/
        2)
          switch_instance_changes.schema = /*schema*/
          ctx2[1];
        if (dirty & /*cellValue*/
        16)
          switch_instance_changes.value = /*cellValue*/
          ctx2[4];
        if (dirty & /*$$scope*/
        4096) {
          switch_instance_changes.$$scope = { dirty, ctx: ctx2 };
        }
        switch_instance.$set(switch_instance_changes);
      }
      if (!current || dirty & /*schema*/
      2) {
        set_style(
          div,
          "--max-cell-width",
          /*schema*/
          ctx2[1].width ? "none" : "200px"
        );
      }
    },
    i(local) {
      if (current)
        return;
      if (switch_instance)
        transition_in(switch_instance.$$.fragment, local);
      current = true;
    },
    o(local) {
      if (switch_instance)
        transition_out(switch_instance.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (switch_instance)
        destroy_component(switch_instance);
    }
  };
}
function create_default_slot$4(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[9].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[12],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        4096)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[12],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[12]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[12],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_fragment$4(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*renderer*/
    ctx[3] && /*customRenderer*/
    (ctx[2] || /*cellValue*/
    ctx[4] != null && /*cellValue*/
    ctx[4] !== "") && create_if_block$3(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (
        /*renderer*/
        ctx2[3] && /*customRenderer*/
        (ctx2[2] || /*cellValue*/
        ctx2[4] != null && /*cellValue*/
        ctx2[4] !== "")
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*renderer, customRenderer, cellValue*/
          28) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$3(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance$4($$self, $$props, $$invalidate) {
  let type;
  let customRenderer;
  let cellValue;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { row } = $$props;
  let { schema } = $$props;
  let { value } = $$props;
  let { customRenderers = [] } = $$props;
  let { snippets } = $$props;
  let renderer;
  const typeMap = {
    boolean: BooleanRenderer,
    datetime: DateTimeRenderer,
    link: RelationshipRenderer,
    attachment: AttachmentRenderer,
    string: StringRenderer,
    options: StringRenderer,
    number: StringRenderer,
    longform: StringRenderer,
    array: ArrayRenderer,
    internal: InternalRenderer,
    bb_reference: RelationshipRenderer
  };
  const getType = (schema2) => {
    if ((schema2 == null ? void 0 : schema2.type) === "datetime" && (schema2 == null ? void 0 : schema2.template)) {
      return "string";
    }
    return (schema2 == null ? void 0 : schema2.type) || "string";
  };
  const getCellValue = (value2, template) => {
    if (!template) {
      return value2;
    }
    return processStringSync(template, { value: value2, snippets });
  };
  function clickrelationship_handler(event) {
    bubble.call(this, $$self, event);
  }
  function buttonclick_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("row" in $$props2)
      $$invalidate(0, row = $$props2.row);
    if ("schema" in $$props2)
      $$invalidate(1, schema = $$props2.schema);
    if ("value" in $$props2)
      $$invalidate(5, value = $$props2.value);
    if ("customRenderers" in $$props2)
      $$invalidate(6, customRenderers = $$props2.customRenderers);
    if ("snippets" in $$props2)
      $$invalidate(7, snippets = $$props2.snippets);
    if ("$$scope" in $$props2)
      $$invalidate(12, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*schema*/
    2) {
      $$invalidate(8, type = getType(schema));
    }
    if ($$self.$$.dirty & /*customRenderers, schema*/
    66) {
      $$invalidate(2, customRenderer = customRenderers == null ? void 0 : customRenderers.find((x) => x.column === (schema == null ? void 0 : schema.name)));
    }
    if ($$self.$$.dirty & /*customRenderer, type*/
    260) {
      $$invalidate(3, renderer = (customRenderer == null ? void 0 : customRenderer.component) ?? typeMap[type] ?? StringRenderer);
    }
    if ($$self.$$.dirty & /*value, schema*/
    34) {
      $$invalidate(4, cellValue = getCellValue(value, schema.template));
    }
  };
  return [
    row,
    schema,
    customRenderer,
    renderer,
    cellValue,
    value,
    customRenderers,
    snippets,
    type,
    slots,
    clickrelationship_handler,
    buttonclick_handler,
    $$scope
  ];
}
class CellRenderer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$4, create_fragment$4, safe_not_equal, {
      row: 0,
      schema: 1,
      value: 5,
      customRenderers: 6,
      snippets: 7
    });
  }
}
function create_if_block_1$1(ctx) {
  let checkbox;
  let current;
  checkbox = new Checkbox_1({ props: { value: (
    /*selected*/
    ctx[0]
  ) } });
  return {
    c() {
      create_component(checkbox.$$.fragment);
    },
    m(target, anchor) {
      mount_component(checkbox, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const checkbox_changes = {};
      if (dirty & /*selected*/
      1)
        checkbox_changes.value = /*selected*/
        ctx2[0];
      checkbox.$set(checkbox_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(checkbox.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(checkbox.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(checkbox, detaching);
    }
  };
}
function create_if_block$2(ctx) {
  let actionbutton;
  let current;
  actionbutton = new ActionButton({
    props: {
      size: "S",
      $$slots: { default: [create_default_slot$3] },
      $$scope: { ctx }
    }
  });
  actionbutton.$on("click", function() {
    if (is_function(
      /*onEdit*/
      ctx[1]
    ))
      ctx[1].apply(this, arguments);
  });
  return {
    c() {
      create_component(actionbutton.$$.fragment);
    },
    m(target, anchor) {
      mount_component(actionbutton, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const actionbutton_changes = {};
      if (dirty & /*$$scope*/
      32) {
        actionbutton_changes.$$scope = { dirty, ctx };
      }
      actionbutton.$set(actionbutton_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(actionbutton.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(actionbutton.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(actionbutton, detaching);
    }
  };
}
function create_default_slot$3(ctx) {
  let t;
  return {
    c() {
      t = text("Edit");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_fragment$3(ctx) {
  let div;
  let t;
  let current;
  let if_block0 = (
    /*allowSelectRows*/
    ctx[2] && /*data*/
    ctx[4].__selectable !== false && create_if_block_1$1(ctx)
  );
  let if_block1 = (
    /*allowEditRows*/
    ctx[3] && create_if_block$2(ctx)
  );
  return {
    c() {
      div = element("div");
      if (if_block0)
        if_block0.c();
      t = space();
      if (if_block1)
        if_block1.c();
      attr(div, "class", "svelte-1fa8hd3");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block0)
        if_block0.m(div, null);
      append(div, t);
      if (if_block1)
        if_block1.m(div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (
        /*allowSelectRows*/
        ctx2[2] && /*data*/
        ctx2[4].__selectable !== false
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty & /*allowSelectRows, data*/
          20) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_1$1(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(div, t);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (
        /*allowEditRows*/
        ctx2[3]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty & /*allowEditRows*/
          8) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block$2(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div, null);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
    }
  };
}
function instance$3($$self, $$props, $$invalidate) {
  let { selected } = $$props;
  let { onEdit } = $$props;
  let { allowSelectRows = false } = $$props;
  let { allowEditRows = false } = $$props;
  let { data } = $$props;
  $$self.$$set = ($$props2) => {
    if ("selected" in $$props2)
      $$invalidate(0, selected = $$props2.selected);
    if ("onEdit" in $$props2)
      $$invalidate(1, onEdit = $$props2.onEdit);
    if ("allowSelectRows" in $$props2)
      $$invalidate(2, allowSelectRows = $$props2.allowSelectRows);
    if ("allowEditRows" in $$props2)
      $$invalidate(3, allowEditRows = $$props2.allowEditRows);
    if ("data" in $$props2)
      $$invalidate(4, data = $$props2.data);
  };
  return [selected, onEdit, allowSelectRows, allowEditRows, data];
}
class SelectEditRenderer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$3, create_fragment$3, safe_not_equal, {
      selected: 0,
      onEdit: 1,
      allowSelectRows: 2,
      allowEditRows: 3,
      data: 4
    });
  }
}
const get_placeholder_slot_changes = (dirty) => ({});
const get_placeholder_slot_context = (ctx) => ({});
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[64] = list[i];
  return child_ctx;
}
function get_each_context_1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[67] = list[i];
  return child_ctx;
}
function get_each_context_2(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[67] = list[i];
  return child_ctx;
}
const get_loadingIndicator_slot_changes = (dirty) => ({});
const get_loadingIndicator_slot_context = (ctx) => ({});
function create_else_block(ctx) {
  let div;
  let t;
  let current_block_type_index;
  let if_block1;
  let div_style_value;
  let current;
  let if_block0 = (
    /*fields*/
    ctx[18].length && create_if_block_4(ctx)
  );
  const if_block_creators = [create_if_block_1, create_else_block_1];
  const if_blocks = [];
  function select_block_type_2(ctx2, dirty) {
    var _a;
    if (
      /*sortedRows*/
      (_a = ctx2[24]) == null ? void 0 : _a.length
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type_2(ctx);
  if_block1 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      div = element("div");
      if (if_block0)
        if_block0.c();
      t = space();
      if_block1.c();
      attr(div, "class", "spectrum-Table svelte-qx6w80");
      attr(div, "style", div_style_value = `${/*heightStyle*/
      ctx[25]}${/*gridStyle*/
      ctx[23]}`);
      toggle_class(div, "no-scroll", !/*rowCount*/
      ctx[2]);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block0)
        if_block0.m(div, null);
      append(div, t);
      if_blocks[current_block_type_index].m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*fields*/
        ctx2[18].length
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty[0] & /*fields*/
          262144) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_4(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(div, t);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_2(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block1 = if_blocks[current_block_type_index];
        if (!if_block1) {
          if_block1 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block1.c();
        } else {
          if_block1.p(ctx2, dirty);
        }
        transition_in(if_block1, 1);
        if_block1.m(div, null);
      }
      if (!current || dirty[0] & /*heightStyle, gridStyle*/
      41943040 && div_style_value !== (div_style_value = `${/*heightStyle*/
      ctx2[25]}${/*gridStyle*/
      ctx2[23]}`)) {
        attr(div, "style", div_style_value);
      }
      if (!current || dirty[0] & /*rowCount*/
      4) {
        toggle_class(div, "no-scroll", !/*rowCount*/
        ctx2[2]);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block0)
        if_block0.d();
      if_blocks[current_block_type_index].d();
    }
  };
}
function create_if_block$1(ctx) {
  let div;
  let current;
  const loadingIndicator_slot_template = (
    /*#slots*/
    ctx[44].loadingIndicator
  );
  const loadingIndicator_slot = create_slot(
    loadingIndicator_slot_template,
    ctx,
    /*$$scope*/
    ctx[55],
    get_loadingIndicator_slot_context
  );
  const loadingIndicator_slot_or_fallback = loadingIndicator_slot || fallback_block();
  return {
    c() {
      div = element("div");
      if (loadingIndicator_slot_or_fallback)
        loadingIndicator_slot_or_fallback.c();
      attr(div, "class", "loading svelte-qx6w80");
      attr(
        div,
        "style",
        /*heightStyle*/
        ctx[25]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (loadingIndicator_slot_or_fallback) {
        loadingIndicator_slot_or_fallback.m(div, null);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (loadingIndicator_slot) {
        if (loadingIndicator_slot.p && (!current || dirty[1] & /*$$scope*/
        16777216)) {
          update_slot_base(
            loadingIndicator_slot,
            loadingIndicator_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[55],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[55]
            ) : get_slot_changes(
              loadingIndicator_slot_template,
              /*$$scope*/
              ctx2[55],
              dirty,
              get_loadingIndicator_slot_changes
            ),
            get_loadingIndicator_slot_context
          );
        }
      }
      if (!current || dirty[0] & /*heightStyle*/
      33554432) {
        attr(
          div,
          "style",
          /*heightStyle*/
          ctx2[25]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(loadingIndicator_slot_or_fallback, local);
      current = true;
    },
    o(local) {
      transition_out(loadingIndicator_slot_or_fallback, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (loadingIndicator_slot_or_fallback)
        loadingIndicator_slot_or_fallback.d(detaching);
    }
  };
}
function create_if_block_4(ctx) {
  let div;
  let t;
  let current;
  let if_block = (
    /*showEditColumn*/
    ctx[17] && create_if_block_8(ctx)
  );
  let each_value_2 = ensure_array_like(
    /*fields*/
    ctx[18]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value_2.length; i += 1) {
    each_blocks[i] = create_each_block_2(get_each_context_2(ctx, each_value_2, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      div = element("div");
      if (if_block)
        if_block.c();
      t = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "spectrum-Table-head svelte-qx6w80");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block)
        if_block.m(div, null);
      append(div, t);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*showEditColumn*/
        ctx2[17]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*showEditColumn*/
          131072) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_8(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, t);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (dirty[0] & /*showHeaderBorder, schema, fields, sortColumn, sortOrder, sortBy, editColumn, allowEditColumns, getDisplayName*/
      939888769) {
        each_value_2 = ensure_array_like(
          /*fields*/
          ctx2[18]
        );
        let i;
        for (i = 0; i < each_value_2.length; i += 1) {
          const child_ctx = get_each_context_2(ctx2, each_value_2, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block_2(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div, null);
          }
        }
        group_outros();
        for (i = each_value_2.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      for (let i = 0; i < each_value_2.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      transition_out(if_block);
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block)
        if_block.d();
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_if_block_8(ctx) {
  let div;
  let current_block_type_index;
  let if_block;
  let current;
  const if_block_creators = [create_if_block_9, create_else_block_3];
  const if_blocks = [];
  function select_block_type_1(ctx2, dirty) {
    if (
      /*allowSelectRows*/
      ctx2[5]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type_1(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      div = element("div");
      if_block.c();
      attr(div, "class", "spectrum-Table-headCell spectrum-Table-headCell--divider spectrum-Table-headCell--edit svelte-qx6w80");
      toggle_class(div, "noBorderHeader", !/*showHeaderBorder*/
      ctx[12]);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_1(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div, null);
      }
      if (!current || dirty[0] & /*showHeaderBorder*/
      4096) {
        toggle_class(div, "noBorderHeader", !/*showHeaderBorder*/
        ctx2[12]);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
    }
  };
}
function create_else_block_3(ctx) {
  let t;
  return {
    c() {
      t = text("Edit");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_9(ctx) {
  let checkbox;
  let updating_value;
  let current;
  function checkbox_value_binding(value) {
    ctx[45](value);
  }
  let checkbox_props = {};
  if (
    /*checkboxStatus*/
    ctx[21] !== void 0
  ) {
    checkbox_props.value = /*checkboxStatus*/
    ctx[21];
  }
  checkbox = new Checkbox_1({ props: checkbox_props });
  binding_callbacks.push(() => bind(checkbox, "value", checkbox_value_binding));
  checkbox.$on(
    "change",
    /*toggleSelectAll*/
    ctx[32]
  );
  return {
    c() {
      create_component(checkbox.$$.fragment);
    },
    m(target, anchor) {
      mount_component(checkbox, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const checkbox_changes = {};
      if (!updating_value && dirty[0] & /*checkboxStatus*/
      2097152) {
        updating_value = true;
        checkbox_changes.value = /*checkboxStatus*/
        ctx2[21];
        add_flush_callback(() => updating_value = false);
      }
      checkbox.$set(checkbox_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(checkbox.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(checkbox.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(checkbox, detaching);
    }
  };
}
function create_if_block_7(ctx) {
  let icon;
  let current;
  icon = new Icon({
    props: {
      name: "magic-wand",
      size: "S",
      color: "var(--spectrum-global-color-gray-600)"
    }
  });
  return {
    c() {
      create_component(icon.$$.fragment);
    },
    m(target, anchor) {
      mount_component(icon, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(icon, detaching);
    }
  };
}
function create_if_block_6(ctx) {
  let icon;
  let current;
  icon = new Icon({
    props: {
      name: "caret-down",
      size: "S",
      color: "var(--spectrum-global-color-gray-700)"
    }
  });
  return {
    c() {
      create_component(icon.$$.fragment);
    },
    m(target, anchor) {
      mount_component(icon, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(icon, detaching);
    }
  };
}
function create_if_block_5(ctx) {
  let icon;
  let current;
  function click_handler2(...args) {
    return (
      /*click_handler*/
      ctx[46](
        /*field*/
        ctx[67],
        ...args
      )
    );
  }
  icon = new Icon({
    props: {
      name: "pencil",
      size: "S",
      hoverable: true,
      color: "var(--spectrum-global-color-gray-600)",
      hoverColor: "var(--spectrum-global-color-gray-900)"
    }
  });
  icon.$on("click", click_handler2);
  return {
    c() {
      create_component(icon.$$.fragment);
    },
    m(target, anchor) {
      mount_component(icon, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(icon, detaching);
    }
  };
}
function create_each_block_2(ctx) {
  var _a, _b;
  let div1;
  let div0;
  let t0_value = (
    /*getDisplayName*/
    ctx[28](
      /*schema*/
      ctx[0][
        /*field*/
        ctx[67]
      ]
    ) + ""
  );
  let t0;
  let t1;
  let t2;
  let t3;
  let div0_title_value;
  let t4;
  let current;
  let mounted;
  let dispose;
  let if_block0 = (
    /*schema*/
    ((_a = ctx[0][
      /*field*/
      ctx[67]
    ]) == null ? void 0 : _a.autocolumn) && create_if_block_7()
  );
  let if_block1 = (
    /*sortColumn*/
    ctx[15] === /*field*/
    ctx[67] && create_if_block_6()
  );
  let if_block2 = (
    /*allowEditColumns*/
    ctx[7] && /*schema*/
    ((_b = ctx[0][
      /*field*/
      ctx[67]
    ]) == null ? void 0 : _b.editable) !== false && create_if_block_5(ctx)
  );
  function click_handler_12() {
    return (
      /*click_handler_1*/
      ctx[47](
        /*field*/
        ctx[67]
      )
    );
  }
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      t0 = text(t0_value);
      t1 = space();
      if (if_block0)
        if_block0.c();
      t2 = space();
      if (if_block1)
        if_block1.c();
      t3 = space();
      if (if_block2)
        if_block2.c();
      t4 = space();
      attr(div0, "class", "title svelte-qx6w80");
      attr(div0, "title", div0_title_value = /*field*/
      ctx[67]);
      attr(div1, "class", "spectrum-Table-headCell svelte-qx6w80");
      toggle_class(div1, "noBorderHeader", !/*showHeaderBorder*/
      ctx[12]);
      toggle_class(
        div1,
        "spectrum-Table-headCell--alignCenter",
        /*schema*/
        ctx[0][
          /*field*/
          ctx[67]
        ].align === "Center"
      );
      toggle_class(
        div1,
        "spectrum-Table-headCell--alignRight",
        /*schema*/
        ctx[0][
          /*field*/
          ctx[67]
        ].align === "Right"
      );
      toggle_class(
        div1,
        "is-sortable",
        /*schema*/
        ctx[0][
          /*field*/
          ctx[67]
        ].sortable !== false
      );
      toggle_class(
        div1,
        "is-sorted-desc",
        /*sortColumn*/
        ctx[15] === /*field*/
        ctx[67] && /*sortOrder*/
        ctx[16] === "Descending"
      );
      toggle_class(
        div1,
        "is-sorted-asc",
        /*sortColumn*/
        ctx[15] === /*field*/
        ctx[67] && /*sortOrder*/
        ctx[16] === "Ascending"
      );
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      append(div0, t0);
      append(div0, t1);
      if (if_block0)
        if_block0.m(div0, null);
      append(div0, t2);
      if (if_block1)
        if_block1.m(div0, null);
      append(div0, t3);
      if (if_block2)
        if_block2.m(div0, null);
      append(div1, t4);
      current = true;
      if (!mounted) {
        dispose = listen(div1, "click", click_handler_12);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      var _a2, _b2;
      ctx = new_ctx;
      if ((!current || dirty[0] & /*schema, fields*/
      262145) && t0_value !== (t0_value = /*getDisplayName*/
      ctx[28](
        /*schema*/
        ctx[0][
          /*field*/
          ctx[67]
        ]
      ) + ""))
        set_data(t0, t0_value);
      if (
        /*schema*/
        (_a2 = ctx[0][
          /*field*/
          ctx[67]
        ]) == null ? void 0 : _a2.autocolumn
      ) {
        if (if_block0) {
          if (dirty[0] & /*schema, fields*/
          262145) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_7();
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(div0, t2);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (
        /*sortColumn*/
        ctx[15] === /*field*/
        ctx[67]
      ) {
        if (if_block1) {
          if (dirty[0] & /*sortColumn, fields*/
          294912) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_6();
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div0, t3);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if (
        /*allowEditColumns*/
        ctx[7] && /*schema*/
        ((_b2 = ctx[0][
          /*field*/
          ctx[67]
        ]) == null ? void 0 : _b2.editable) !== false
      ) {
        if (if_block2) {
          if_block2.p(ctx, dirty);
          if (dirty[0] & /*allowEditColumns, schema, fields*/
          262273) {
            transition_in(if_block2, 1);
          }
        } else {
          if_block2 = create_if_block_5(ctx);
          if_block2.c();
          transition_in(if_block2, 1);
          if_block2.m(div0, null);
        }
      } else if (if_block2) {
        group_outros();
        transition_out(if_block2, 1, 1, () => {
          if_block2 = null;
        });
        check_outros();
      }
      if (!current || dirty[0] & /*fields*/
      262144 && div0_title_value !== (div0_title_value = /*field*/
      ctx[67])) {
        attr(div0, "title", div0_title_value);
      }
      if (!current || dirty[0] & /*showHeaderBorder*/
      4096) {
        toggle_class(div1, "noBorderHeader", !/*showHeaderBorder*/
        ctx[12]);
      }
      if (!current || dirty[0] & /*schema, fields*/
      262145) {
        toggle_class(
          div1,
          "spectrum-Table-headCell--alignCenter",
          /*schema*/
          ctx[0][
            /*field*/
            ctx[67]
          ].align === "Center"
        );
      }
      if (!current || dirty[0] & /*schema, fields*/
      262145) {
        toggle_class(
          div1,
          "spectrum-Table-headCell--alignRight",
          /*schema*/
          ctx[0][
            /*field*/
            ctx[67]
          ].align === "Right"
        );
      }
      if (!current || dirty[0] & /*schema, fields*/
      262145) {
        toggle_class(
          div1,
          "is-sortable",
          /*schema*/
          ctx[0][
            /*field*/
            ctx[67]
          ].sortable !== false
        );
      }
      if (!current || dirty[0] & /*sortColumn, fields, sortOrder*/
      360448) {
        toggle_class(
          div1,
          "is-sorted-desc",
          /*sortColumn*/
          ctx[15] === /*field*/
          ctx[67] && /*sortOrder*/
          ctx[16] === "Descending"
        );
      }
      if (!current || dirty[0] & /*sortColumn, fields, sortOrder*/
      360448) {
        toggle_class(
          div1,
          "is-sorted-asc",
          /*sortColumn*/
          ctx[15] === /*field*/
          ctx[67] && /*sortOrder*/
          ctx[16] === "Ascending"
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      transition_in(if_block2);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      transition_out(if_block2);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
      if (if_block2)
        if_block2.d();
      mounted = false;
      dispose();
    }
  };
}
function create_else_block_1(ctx) {
  let div;
  let current_block_type_index;
  let if_block;
  let current;
  const if_block_creators = [create_if_block_3, create_else_block_2];
  const if_blocks = [];
  function select_block_type_3(ctx2, dirty) {
    if (
      /*customPlaceholder*/
      ctx2[11]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type_3(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      var _a;
      div = element("div");
      if_block.c();
      attr(div, "class", "placeholder svelte-qx6w80");
      toggle_class(
        div,
        "placeholder--custom",
        /*customPlaceholder*/
        ctx[11]
      );
      toggle_class(div, "placeholder--no-fields", !/*fields*/
      ((_a = ctx[18]) == null ? void 0 : _a.length));
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      var _a;
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_3(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div, null);
      }
      if (!current || dirty[0] & /*customPlaceholder*/
      2048) {
        toggle_class(
          div,
          "placeholder--custom",
          /*customPlaceholder*/
          ctx2[11]
        );
      }
      if (!current || dirty[0] & /*fields*/
      262144) {
        toggle_class(div, "placeholder--no-fields", !/*fields*/
        ((_a = ctx2[18]) == null ? void 0 : _a.length));
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
    }
  };
}
function create_if_block_1(ctx) {
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(
    /*sortedRows*/
    ctx[24]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*allowClickRows, fields, cellStyles, schema, dispatch, sortedRows, customRenderers, snippets, showHeaderBorder, selectedRows, editRow, allowSelectRows, allowEditRows, showEditColumn*/
      1162236771 | dirty[1] & /*toggleSelectRow, $$scope*/
      16777217) {
        each_value = ensure_array_like(
          /*sortedRows*/
          ctx2[24]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_else_block_2(ctx) {
  let div1;
  let icon;
  let t0;
  let div0;
  let t1;
  let current;
  icon = new Icon({
    props: {
      name: "table",
      size: "XXL",
      color: "var(--spectrum-global-color-gray-600)"
    }
  });
  return {
    c() {
      div1 = element("div");
      create_component(icon.$$.fragment);
      t0 = space();
      div0 = element("div");
      t1 = text(
        /*placeholderText*/
        ctx[13]
      );
      attr(div0, "class", "svelte-qx6w80");
      attr(div1, "class", "placeholder-content svelte-qx6w80");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      mount_component(icon, div1, null);
      append(div1, t0);
      append(div1, div0);
      append(div0, t1);
      current = true;
    },
    p(ctx2, dirty) {
      if (!current || dirty[0] & /*placeholderText*/
      8192)
        set_data(
          t1,
          /*placeholderText*/
          ctx2[13]
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      destroy_component(icon);
    }
  };
}
function create_if_block_3(ctx) {
  let current;
  const placeholder_slot_template = (
    /*#slots*/
    ctx[44].placeholder
  );
  const placeholder_slot = create_slot(
    placeholder_slot_template,
    ctx,
    /*$$scope*/
    ctx[55],
    get_placeholder_slot_context
  );
  return {
    c() {
      if (placeholder_slot)
        placeholder_slot.c();
    },
    m(target, anchor) {
      if (placeholder_slot) {
        placeholder_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (placeholder_slot) {
        if (placeholder_slot.p && (!current || dirty[1] & /*$$scope*/
        16777216)) {
          update_slot_base(
            placeholder_slot,
            placeholder_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[55],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[55]
            ) : get_slot_changes(
              placeholder_slot_template,
              /*$$scope*/
              ctx2[55],
              dirty,
              get_placeholder_slot_changes
            ),
            get_placeholder_slot_context
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(placeholder_slot, local);
      current = true;
    },
    o(local) {
      transition_out(placeholder_slot, local);
      current = false;
    },
    d(detaching) {
      if (placeholder_slot)
        placeholder_slot.d(detaching);
    }
  };
}
function create_if_block_2(ctx) {
  let div;
  let selecteditrenderer;
  let current;
  let mounted;
  let dispose;
  function func(...args) {
    return (
      /*func*/
      ctx[48](
        /*row*/
        ctx[64],
        ...args
      )
    );
  }
  function func_1(...args) {
    return (
      /*func_1*/
      ctx[49](
        /*row*/
        ctx[64],
        ...args
      )
    );
  }
  selecteditrenderer = new SelectEditRenderer({
    props: {
      data: (
        /*row*/
        ctx[64]
      ),
      selected: (
        /*selectedRows*/
        ctx[1].findIndex(func) !== -1
      ),
      onEdit: func_1,
      allowSelectRows: (
        /*allowSelectRows*/
        ctx[5]
      ),
      allowEditRows: (
        /*allowEditRows*/
        ctx[6]
      )
    }
  });
  function click_handler_2(...args) {
    return (
      /*click_handler_2*/
      ctx[50](
        /*row*/
        ctx[64],
        ...args
      )
    );
  }
  return {
    c() {
      div = element("div");
      create_component(selecteditrenderer.$$.fragment);
      attr(div, "class", "spectrum-Table-cell spectrum-Table-cell--divider spectrum-Table-cell--edit svelte-qx6w80");
      toggle_class(div, "noBorderCheckbox", !/*showHeaderBorder*/
      ctx[12]);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(selecteditrenderer, div, null);
      current = true;
      if (!mounted) {
        dispose = listen(div, "click", click_handler_2);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const selecteditrenderer_changes = {};
      if (dirty[0] & /*sortedRows*/
      16777216)
        selecteditrenderer_changes.data = /*row*/
        ctx[64];
      if (dirty[0] & /*selectedRows, sortedRows*/
      16777218)
        selecteditrenderer_changes.selected = /*selectedRows*/
        ctx[1].findIndex(func) !== -1;
      if (dirty[0] & /*sortedRows*/
      16777216)
        selecteditrenderer_changes.onEdit = func_1;
      if (dirty[0] & /*allowSelectRows*/
      32)
        selecteditrenderer_changes.allowSelectRows = /*allowSelectRows*/
        ctx[5];
      if (dirty[0] & /*allowEditRows*/
      64)
        selecteditrenderer_changes.allowEditRows = /*allowEditRows*/
        ctx[6];
      selecteditrenderer.$set(selecteditrenderer_changes);
      if (!current || dirty[0] & /*showHeaderBorder*/
      4096) {
        toggle_class(div, "noBorderCheckbox", !/*showHeaderBorder*/
        ctx[12]);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(selecteditrenderer.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(selecteditrenderer.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(selecteditrenderer);
      mounted = false;
      dispose();
    }
  };
}
function create_default_slot$2(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[44].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[55],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty[1] & /*$$scope*/
        16777216)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[55],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[55]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[55],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_each_block_1(ctx) {
  let div;
  let cellrenderer;
  let div_style_value;
  let current;
  let mounted;
  let dispose;
  cellrenderer = new CellRenderer({
    props: {
      customRenderers: (
        /*customRenderers*/
        ctx[9]
      ),
      row: (
        /*row*/
        ctx[64]
      ),
      snippets: (
        /*snippets*/
        ctx[14]
      ),
      schema: (
        /*schema*/
        ctx[0][
          /*field*/
          ctx[67]
        ]
      ),
      value: deepGet(
        /*row*/
        ctx[64],
        /*field*/
        ctx[67]
      ),
      $$slots: { default: [create_default_slot$2] },
      $$scope: { ctx }
    }
  });
  cellrenderer.$on(
    "clickrelationship",
    /*clickrelationship_handler*/
    ctx[51]
  );
  cellrenderer.$on(
    "buttonclick",
    /*buttonclick_handler*/
    ctx[52]
  );
  function click_handler_3() {
    return (
      /*click_handler_3*/
      ctx[53](
        /*field*/
        ctx[67],
        /*row*/
        ctx[64]
      )
    );
  }
  return {
    c() {
      div = element("div");
      create_component(cellrenderer.$$.fragment);
      attr(div, "class", "spectrum-Table-cell svelte-qx6w80");
      attr(div, "style", div_style_value = /*cellStyles*/
      ctx[22][
        /*field*/
        ctx[67]
      ]);
      toggle_class(div, "spectrum-Table-cell--divider", !!/*schema*/
      ctx[0][
        /*field*/
        ctx[67]
      ].divider);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(cellrenderer, div, null);
      current = true;
      if (!mounted) {
        dispose = listen(div, "click", click_handler_3);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const cellrenderer_changes = {};
      if (dirty[0] & /*customRenderers*/
      512)
        cellrenderer_changes.customRenderers = /*customRenderers*/
        ctx[9];
      if (dirty[0] & /*sortedRows*/
      16777216)
        cellrenderer_changes.row = /*row*/
        ctx[64];
      if (dirty[0] & /*snippets*/
      16384)
        cellrenderer_changes.snippets = /*snippets*/
        ctx[14];
      if (dirty[0] & /*schema, fields*/
      262145)
        cellrenderer_changes.schema = /*schema*/
        ctx[0][
          /*field*/
          ctx[67]
        ];
      if (dirty[0] & /*sortedRows, fields*/
      17039360)
        cellrenderer_changes.value = deepGet(
          /*row*/
          ctx[64],
          /*field*/
          ctx[67]
        );
      if (dirty[1] & /*$$scope*/
      16777216) {
        cellrenderer_changes.$$scope = { dirty, ctx };
      }
      cellrenderer.$set(cellrenderer_changes);
      if (!current || dirty[0] & /*cellStyles, fields*/
      4456448 && div_style_value !== (div_style_value = /*cellStyles*/
      ctx[22][
        /*field*/
        ctx[67]
      ])) {
        attr(div, "style", div_style_value);
      }
      if (!current || dirty[0] & /*schema, fields*/
      262145) {
        toggle_class(div, "spectrum-Table-cell--divider", !!/*schema*/
        ctx[0][
          /*field*/
          ctx[67]
        ].divider);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(cellrenderer.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(cellrenderer.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(cellrenderer);
      mounted = false;
      dispose();
    }
  };
}
function create_each_block(ctx) {
  let div;
  let t0;
  let t1;
  let current;
  let if_block = (
    /*showEditColumn*/
    ctx[17] && create_if_block_2(ctx)
  );
  let each_value_1 = ensure_array_like(
    /*fields*/
    ctx[18]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value_1.length; i += 1) {
    each_blocks[i] = create_each_block_1(get_each_context_1(ctx, each_value_1, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      div = element("div");
      if (if_block)
        if_block.c();
      t0 = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t1 = space();
      attr(div, "class", "spectrum-Table-row svelte-qx6w80");
      toggle_class(
        div,
        "clickable",
        /*allowClickRows*/
        ctx[8]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block)
        if_block.m(div, null);
      append(div, t0);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      append(div, t1);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*showEditColumn*/
        ctx2[17]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*showEditColumn*/
          131072) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_2(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, t0);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (dirty[0] & /*cellStyles, fields, schema, dispatch, sortedRows, customRenderers, snippets*/
      88359425 | dirty[1] & /*toggleSelectRow, $$scope*/
      16777217) {
        each_value_1 = ensure_array_like(
          /*fields*/
          ctx2[18]
        );
        let i;
        for (i = 0; i < each_value_1.length; i += 1) {
          const child_ctx = get_each_context_1(ctx2, each_value_1, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block_1(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div, t1);
          }
        }
        group_outros();
        for (i = each_value_1.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      if (!current || dirty[0] & /*allowClickRows*/
      256) {
        toggle_class(
          div,
          "clickable",
          /*allowClickRows*/
          ctx2[8]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      for (let i = 0; i < each_value_1.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      transition_out(if_block);
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block)
        if_block.d();
      destroy_each(each_blocks, detaching);
    }
  };
}
function fallback_block(ctx) {
  let progresscircle;
  let current;
  progresscircle = new ProgressCircle({});
  return {
    c() {
      create_component(progresscircle.$$.fragment);
    },
    m(target, anchor) {
      mount_component(progresscircle, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(progresscircle.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(progresscircle.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(progresscircle, detaching);
    }
  };
}
function create_key_block(ctx) {
  let div;
  let current_block_type_index;
  let if_block;
  let div_style_value;
  let current;
  const if_block_creators = [create_if_block$1, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*loading*/
      ctx2[4]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      div = element("div");
      if_block.c();
      attr(div, "class", "wrapper svelte-qx6w80");
      attr(div, "style", div_style_value = `--row-height: ${/*rowHeight*/
      ctx[19]}px; --header-height: ${headerHeight}px;`);
      toggle_class(
        div,
        "wrapper--quiet",
        /*quiet*/
        ctx[3]
      );
      toggle_class(
        div,
        "wrapper--compact",
        /*compact*/
        ctx[10]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      ctx[54](div);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div, null);
      }
      if (!current || dirty[0] & /*rowHeight*/
      524288 && div_style_value !== (div_style_value = `--row-height: ${/*rowHeight*/
      ctx2[19]}px; --header-height: ${headerHeight}px;`)) {
        attr(div, "style", div_style_value);
      }
      if (!current || dirty[0] & /*quiet*/
      8) {
        toggle_class(
          div,
          "wrapper--quiet",
          /*quiet*/
          ctx2[3]
        );
      }
      if (!current || dirty[0] & /*compact*/
      1024) {
        toggle_class(
          div,
          "wrapper--compact",
          /*compact*/
          ctx2[10]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
      ctx[54](null);
    }
  };
}
function create_fragment$2(ctx) {
  var _a;
  let previous_key = (
    /*fields*/
    (_a = ctx[18]) == null ? void 0 : _a.length
  );
  let key_block_anchor;
  let current;
  let key_block = create_key_block(ctx);
  return {
    c() {
      key_block.c();
      key_block_anchor = empty();
    },
    m(target, anchor) {
      key_block.m(target, anchor);
      insert(target, key_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      if (dirty[0] & /*fields*/
      262144 && safe_not_equal(previous_key, previous_key = /*fields*/
      (_a2 = ctx2[18]) == null ? void 0 : _a2.length)) {
        group_outros();
        transition_out(key_block, 1, 1, noop);
        check_outros();
        key_block = create_key_block(ctx2);
        key_block.c();
        transition_in(key_block, 1);
        key_block.m(key_block_anchor.parentNode, key_block_anchor);
      } else {
        key_block.p(ctx2, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(key_block);
      current = true;
    },
    o(local) {
      transition_out(key_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(key_block_anchor);
      }
      key_block.d(detaching);
    }
  };
}
const headerHeight = 36;
function instance$2($$self, $$props, $$invalidate) {
  let rowHeight;
  let fields;
  let rows;
  let totalRowCount;
  let visibleRowCount;
  let heightStyle;
  let sortedRows;
  let gridStyle;
  let showEditColumn;
  let cellStyles;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { data = [] } = $$props;
  let { schema = {} } = $$props;
  let { showAutoColumns = false } = $$props;
  let { rowCount = 0 } = $$props;
  let { quiet = false } = $$props;
  let { loading = false } = $$props;
  let { allowSelectRows = false } = $$props;
  let { allowEditRows = true } = $$props;
  let { allowEditColumns = true } = $$props;
  let { allowClickRows = true } = $$props;
  let { selectedRows = [] } = $$props;
  let { customRenderers = [] } = $$props;
  let { disableSorting = false } = $$props;
  let { autoSortColumns = true } = $$props;
  let { compact = false } = $$props;
  let { customPlaceholder = false } = $$props;
  let { showHeaderBorder = true } = $$props;
  let { placeholderText = "No rows found" } = $$props;
  let { snippets = [] } = $$props;
  let { defaultSortColumn = void 0 } = $$props;
  let { defaultSortOrder = "Ascending" } = $$props;
  const dispatch = createEventDispatcher();
  let ref;
  let sortColumn;
  let sortOrder;
  let height = 0;
  let loaded = false;
  let checkboxStatus = false;
  const fixSchema = (schema2) => {
    let fixedSchema = {};
    Object.entries(schema2 || {}).forEach(([fieldName, fieldSchema]) => {
      if (typeof fieldSchema === "string") {
        fixedSchema[fieldName] = { type: fieldSchema, name: fieldName };
      } else {
        fixedSchema[fieldName] = { ...fieldSchema, name: fieldName };
      }
      const width = fixedSchema[fieldName].width;
      if (width != null && `${width}`.trim().match(/^[0-9]+$/)) {
        delete fixedSchema[fieldName].width;
      }
    });
    return fixedSchema;
  };
  const getVisibleRowCount = (loaded2, height2, allRows, rowCount2, rowHeight2) => {
    if (!loaded2) {
      return rowCount2 || 0;
    }
    if (rowCount2) {
      return Math.min(allRows, rowCount2);
    }
    return Math.min(allRows, Math.ceil(height2 / rowHeight2));
  };
  const getHeightStyle = (visibleRowCount2, rowCount2, totalRowCount2, rowHeight2, loading2) => {
    if (loading2) {
      return `height: ${headerHeight + visibleRowCount2 * rowHeight2}px;`;
    }
    if (!rowCount2 || !visibleRowCount2 || totalRowCount2 <= rowCount2) {
      return "";
    }
    return `height: ${headerHeight + visibleRowCount2 * rowHeight2}px;`;
  };
  const getGridStyle = (fields2, schema2, showEditColumn2) => {
    let style = "grid-template-columns:";
    if (showEditColumn2) {
      style += " auto";
    }
    fields2 == null ? void 0 : fields2.forEach((field) => {
      const fieldSchema = schema2[field];
      if (fieldSchema.width && typeof fieldSchema.width === "string") {
        style += ` ${fieldSchema.width}`;
      } else {
        style += " minmax(auto, 1fr)";
      }
    });
    style += ";";
    return style;
  };
  const sortRows = (rows2, sortColumn2, sortOrder2) => {
    sortColumn2 = sortColumn2 ?? defaultSortColumn;
    sortOrder2 = sortOrder2 ?? defaultSortOrder;
    if (!sortColumn2 || !sortOrder2 || disableSorting) {
      return rows2;
    }
    return rows2.slice().sort((a, b) => {
      const colA = a[sortColumn2];
      const colB = b[sortColumn2];
      if (sortOrder2 === "Descending") {
        return colA > colB ? -1 : 1;
      } else {
        return colA > colB ? 1 : -1;
      }
    });
  };
  const sortBy = (fieldSchema) => {
    if (fieldSchema.sortable === false) {
      return;
    }
    if (fieldSchema.name === sortColumn) {
      $$invalidate(16, sortOrder = sortOrder === "Descending" ? "Ascending" : "Descending");
    } else {
      $$invalidate(15, sortColumn = fieldSchema.name);
      $$invalidate(16, sortOrder = "Descending");
    }
    dispatch("sort", { column: sortColumn, order: sortOrder });
  };
  const getDisplayName = (schema2) => {
    let name = schema2 == null ? void 0 : schema2.displayName;
    if (schema2 && name === void 0) {
      name = schema2.name;
    }
    return name || "";
  };
  const getFields = (schema2, showAutoColumns2, autoSortColumns2) => {
    let columns = [];
    let autoColumns = [];
    Object.entries(schema2 || {}).forEach(([field, fieldSchema]) => {
      if (!field || !fieldSchema) {
        return;
      }
      if (!autoSortColumns2 || !(fieldSchema == null ? void 0 : fieldSchema.autocolumn)) {
        columns.push(fieldSchema);
      } else if (showAutoColumns2) {
        autoColumns.push(fieldSchema);
      }
    });
    return columns.sort((a, b) => {
      if (a.divider) {
        return a;
      }
      if (b.divider) {
        return b;
      }
      const orderA = a.order || Number.MAX_SAFE_INTEGER;
      const orderB = b.order || Number.MAX_SAFE_INTEGER;
      const nameA = getDisplayName(a);
      const nameB = getDisplayName(b);
      if (orderA !== orderB) {
        return orderA < orderB ? a : b;
      }
      return nameA < nameB ? a : b;
    }).concat(autoColumns).map((column) => column.name);
  };
  const editColumn = (e, field) => {
    e.stopPropagation();
    dispatch("editcolumn", field);
  };
  const editRow = (e, row) => {
    e.stopPropagation();
    dispatch("editrow", cloneDeep(row));
  };
  const toggleSelectRow = (row) => {
    if (!allowSelectRows) {
      return;
    }
    if (selectedRows.some((selectedRow) => selectedRow._id === row._id)) {
      $$invalidate(1, selectedRows = selectedRows.filter((selectedRow) => selectedRow._id !== row._id));
    } else {
      $$invalidate(1, selectedRows = [...selectedRows, row]);
    }
  };
  const toggleSelectAll = (e) => {
    const select = !!e.detail;
    if (select) {
      rows.forEach((row) => {
        if (row.__selectable !== false && selectedRows.findIndex((x) => x._id === row._id) === -1) {
          selectedRows.push(row);
        }
      });
    } else {
      $$invalidate(1, selectedRows = selectedRows.filter((el) => rows.every((f) => f._id !== el._id)));
    }
  };
  const computeCellStyles = (schema2) => {
    let styles = {};
    Object.keys(schema2 || {}).forEach((field) => {
      styles[field] = "";
      if (schema2[field].color) {
        styles[field] += `color: ${schema2[field].color};`;
      }
      if (schema2[field].background) {
        styles[field] += `background-color: ${schema2[field].background};`;
      }
      if (schema2[field].align === "Center") {
        styles[field] += "justify-content: center; text-align: center;";
      }
      if (schema2[field].align === "Right") {
        styles[field] += "justify-content: flex-end; text-align: right;";
      }
      if (schema2[field].borderLeft) {
        styles[field] += "border-left: 1px solid var(--spectrum-global-color-gray-200);";
      }
      if (schema2[field].borderLeft) {
        styles[field] += "border-right: 1px solid var(--spectrum-global-color-gray-200);";
      }
      if (schema2[field].minWidth) {
        styles[field] += `min-width: ${schema2[field].minWidth};`;
      }
    });
    return styles;
  };
  const setupResizeObserver = (element2) => {
    const resizeObserver = new ResizeObserver((entries) => {
      if (!(entries == null ? void 0 : entries[0])) {
        return;
      }
      const bounds = entries[0].target.getBoundingClientRect();
      $$invalidate(39, height = bounds.height);
    });
    resizeObserver.observe(element2);
    return resizeObserver;
  };
  onMount(() => {
    let resizeObserver = setupResizeObserver(ref);
    return () => {
      resizeObserver.disconnect();
    };
  });
  function checkbox_value_binding(value) {
    checkboxStatus = value;
    $$invalidate(21, checkboxStatus), $$invalidate(41, rows), $$invalidate(1, selectedRows), $$invalidate(18, fields), $$invalidate(33, data), $$invalidate(0, schema), $$invalidate(34, showAutoColumns), $$invalidate(36, autoSortColumns);
  }
  const click_handler2 = (field, e) => editColumn(e, field);
  const click_handler_12 = (field) => sortBy(schema[field]);
  const func = (row, selectedRow) => selectedRow._id === row._id;
  const func_1 = (row, e) => editRow(e, row);
  const click_handler_2 = (row, e) => {
    if (row.__selectable === false) {
      return;
    }
    toggleSelectRow(row);
    e.stopPropagation();
  };
  function clickrelationship_handler(event) {
    bubble.call(this, $$self, event);
  }
  function buttonclick_handler(event) {
    bubble.call(this, $$self, event);
  }
  const click_handler_3 = (field, row) => {
    var _a;
    if (!((_a = schema[field]) == null ? void 0 : _a.preventSelectRow)) {
      dispatch("click", row);
      toggleSelectRow(row);
    }
  };
  function div_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      ref = $$value;
      $$invalidate(20, ref);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("data" in $$props2)
      $$invalidate(33, data = $$props2.data);
    if ("schema" in $$props2)
      $$invalidate(0, schema = $$props2.schema);
    if ("showAutoColumns" in $$props2)
      $$invalidate(34, showAutoColumns = $$props2.showAutoColumns);
    if ("rowCount" in $$props2)
      $$invalidate(2, rowCount = $$props2.rowCount);
    if ("quiet" in $$props2)
      $$invalidate(3, quiet = $$props2.quiet);
    if ("loading" in $$props2)
      $$invalidate(4, loading = $$props2.loading);
    if ("allowSelectRows" in $$props2)
      $$invalidate(5, allowSelectRows = $$props2.allowSelectRows);
    if ("allowEditRows" in $$props2)
      $$invalidate(6, allowEditRows = $$props2.allowEditRows);
    if ("allowEditColumns" in $$props2)
      $$invalidate(7, allowEditColumns = $$props2.allowEditColumns);
    if ("allowClickRows" in $$props2)
      $$invalidate(8, allowClickRows = $$props2.allowClickRows);
    if ("selectedRows" in $$props2)
      $$invalidate(1, selectedRows = $$props2.selectedRows);
    if ("customRenderers" in $$props2)
      $$invalidate(9, customRenderers = $$props2.customRenderers);
    if ("disableSorting" in $$props2)
      $$invalidate(35, disableSorting = $$props2.disableSorting);
    if ("autoSortColumns" in $$props2)
      $$invalidate(36, autoSortColumns = $$props2.autoSortColumns);
    if ("compact" in $$props2)
      $$invalidate(10, compact = $$props2.compact);
    if ("customPlaceholder" in $$props2)
      $$invalidate(11, customPlaceholder = $$props2.customPlaceholder);
    if ("showHeaderBorder" in $$props2)
      $$invalidate(12, showHeaderBorder = $$props2.showHeaderBorder);
    if ("placeholderText" in $$props2)
      $$invalidate(13, placeholderText = $$props2.placeholderText);
    if ("snippets" in $$props2)
      $$invalidate(14, snippets = $$props2.snippets);
    if ("defaultSortColumn" in $$props2)
      $$invalidate(37, defaultSortColumn = $$props2.defaultSortColumn);
    if ("defaultSortOrder" in $$props2)
      $$invalidate(38, defaultSortOrder = $$props2.defaultSortOrder);
    if ("$$scope" in $$props2)
      $$invalidate(55, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*compact*/
    1024) {
      $$invalidate(19, rowHeight = compact ? 46 : 55);
    }
    if ($$self.$$.dirty[0] & /*schema*/
    1) {
      $$invalidate(0, schema = fixSchema(schema));
    }
    if ($$self.$$.dirty[0] & /*loading*/
    16) {
      if (!loading)
        $$invalidate(40, loaded = true);
    }
    if ($$self.$$.dirty[0] & /*schema*/
    1 | $$self.$$.dirty[1] & /*showAutoColumns, autoSortColumns*/
    40) {
      $$invalidate(18, fields = getFields(schema, showAutoColumns, autoSortColumns));
    }
    if ($$self.$$.dirty[0] & /*fields*/
    262144 | $$self.$$.dirty[1] & /*data*/
    4) {
      $$invalidate(41, rows = (fields == null ? void 0 : fields.length) ? data || [] : []);
    }
    if ($$self.$$.dirty[1] & /*rows*/
    1024) {
      $$invalidate(42, totalRowCount = (rows == null ? void 0 : rows.length) || 0);
    }
    if ($$self.$$.dirty[0] & /*rowCount, rowHeight*/
    524292 | $$self.$$.dirty[1] & /*loaded, height, rows*/
    1792) {
      $$invalidate(43, visibleRowCount = getVisibleRowCount(loaded, height, rows.length, rowCount, rowHeight));
    }
    if ($$self.$$.dirty[0] & /*rowCount, rowHeight, loading*/
    524308 | $$self.$$.dirty[1] & /*visibleRowCount, totalRowCount*/
    6144) {
      $$invalidate(25, heightStyle = getHeightStyle(visibleRowCount, rowCount, totalRowCount, rowHeight, loading));
    }
    if ($$self.$$.dirty[0] & /*sortColumn, sortOrder*/
    98304 | $$self.$$.dirty[1] & /*rows*/
    1024) {
      $$invalidate(24, sortedRows = sortRows(rows, sortColumn, sortOrder));
    }
    if ($$self.$$.dirty[0] & /*allowEditRows, allowSelectRows*/
    96) {
      $$invalidate(17, showEditColumn = allowEditRows || allowSelectRows);
    }
    if ($$self.$$.dirty[0] & /*fields, schema, showEditColumn*/
    393217) {
      $$invalidate(23, gridStyle = getGridStyle(fields, schema, showEditColumn));
    }
    if ($$self.$$.dirty[0] & /*schema*/
    1) {
      $$invalidate(22, cellStyles = computeCellStyles(schema));
    }
    if ($$self.$$.dirty[0] & /*selectedRows*/
    2 | $$self.$$.dirty[1] & /*rows*/
    1024) {
      {
        let checkRowCount = rows.filter((o1) => selectedRows.some((o2) => o1._id === o2._id));
        if (checkRowCount.length === 0) {
          $$invalidate(21, checkboxStatus = false);
        }
      }
    }
  };
  return [
    schema,
    selectedRows,
    rowCount,
    quiet,
    loading,
    allowSelectRows,
    allowEditRows,
    allowEditColumns,
    allowClickRows,
    customRenderers,
    compact,
    customPlaceholder,
    showHeaderBorder,
    placeholderText,
    snippets,
    sortColumn,
    sortOrder,
    showEditColumn,
    fields,
    rowHeight,
    ref,
    checkboxStatus,
    cellStyles,
    gridStyle,
    sortedRows,
    heightStyle,
    dispatch,
    sortBy,
    getDisplayName,
    editColumn,
    editRow,
    toggleSelectRow,
    toggleSelectAll,
    data,
    showAutoColumns,
    disableSorting,
    autoSortColumns,
    defaultSortColumn,
    defaultSortOrder,
    height,
    loaded,
    rows,
    totalRowCount,
    visibleRowCount,
    slots,
    checkbox_value_binding,
    click_handler2,
    click_handler_12,
    func,
    func_1,
    click_handler_2,
    clickrelationship_handler,
    buttonclick_handler,
    click_handler_3,
    div_binding,
    $$scope
  ];
}
class Table extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance$2,
      create_fragment$2,
      safe_not_equal,
      {
        data: 33,
        schema: 0,
        showAutoColumns: 34,
        rowCount: 2,
        quiet: 3,
        loading: 4,
        allowSelectRows: 5,
        allowEditRows: 6,
        allowEditColumns: 7,
        allowClickRows: 8,
        selectedRows: 1,
        customRenderers: 9,
        disableSorting: 35,
        autoSortColumns: 36,
        compact: 10,
        customPlaceholder: 11,
        showHeaderBorder: 12,
        placeholderText: 13,
        snippets: 14,
        defaultSortColumn: 37,
        defaultSortOrder: 38
      },
      null,
      [-1, -1, -1]
    );
  }
}
function create_default_slot$1(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[3].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[4],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        16)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[4],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[4]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[4],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_fragment$1(ctx) {
  let provider;
  let current;
  provider = new /*Provider*/
  ctx[1]({
    props: {
      data: (
        /*row*/
        ctx[0]
      ),
      scope: (
        /*ContextScopes*/
        ctx[2].Local
      ),
      $$slots: { default: [create_default_slot$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(provider.$$.fragment);
    },
    m(target, anchor) {
      mount_component(provider, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const provider_changes = {};
      if (dirty & /*row*/
      1)
        provider_changes.data = /*row*/
        ctx2[0];
      if (dirty & /*$$scope*/
      16) {
        provider_changes.$$scope = { dirty, ctx: ctx2 };
      }
      provider.$set(provider_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(provider.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(provider.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(provider, detaching);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { row } = $$props;
  const { Provider: Provider2, ContextScopes } = getContext("sdk");
  $$self.$$set = ($$props2) => {
    if ("row" in $$props2)
      $$invalidate(0, row = $$props2.row);
    if ("$$scope" in $$props2)
      $$invalidate(4, $$scope = $$props2.$$scope);
  };
  return [row, Provider2, ContextScopes, slots, $$scope];
}
class SlotRenderer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, { row: 0 });
  }
}
const Table_svelte_svelte_type_style_lang = "";
function create_default_slot_1(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[30].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[32],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty[1] & /*$$scope*/
        2)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[32],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[32]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[32],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_default_slot(ctx) {
  var _a;
  let table_1;
  let updating_selectedRows;
  let current;
  function table_1_selectedRows_binding(value) {
    ctx[31](value);
  }
  let table_1_props = {
    data: (
      /*data*/
      ctx[8]
    ),
    schema: (
      /*schema*/
      ctx[12]
    ),
    loading: (
      /*loading*/
      ctx[13]
    ),
    rowCount: (
      /*rowCount*/
      ctx[1]
    ),
    quiet: (
      /*quiet*/
      ctx[2]
    ),
    compact: (
      /*compact*/
      ctx[5]
    ),
    customRenderers: (
      /*customRenderers*/
      ctx[18]
    ),
    snippets: (
      /*snippets*/
      ctx[14]
    ),
    allowSelectRows: (
      /*allowSelectRows*/
      ctx[4] && /*table*/
      ctx[11]
    ),
    allowEditRows: false,
    allowEditColumns: false,
    showAutoColumns: true,
    disableSorting: true,
    autoSortColumns: !/*columns*/
    ((_a = ctx[0]) == null ? void 0 : _a.length),
    placeholderText: (
      /*noRowsMessage*/
      ctx[6] || "No rows found"
    ),
    $$slots: { default: [create_default_slot_1] },
    $$scope: { ctx }
  };
  if (
    /*selectedRows*/
    ctx[7] !== void 0
  ) {
    table_1_props.selectedRows = /*selectedRows*/
    ctx[7];
  }
  table_1 = new Table({ props: table_1_props });
  binding_callbacks.push(() => bind(table_1, "selectedRows", table_1_selectedRows_binding));
  table_1.$on(
    "sort",
    /*onSort*/
    ctx[19]
  );
  table_1.$on(
    "click",
    /*handleClick*/
    ctx[20]
  );
  return {
    c() {
      create_component(table_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(table_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      const table_1_changes = {};
      if (dirty[0] & /*data*/
      256)
        table_1_changes.data = /*data*/
        ctx2[8];
      if (dirty[0] & /*schema*/
      4096)
        table_1_changes.schema = /*schema*/
        ctx2[12];
      if (dirty[0] & /*loading*/
      8192)
        table_1_changes.loading = /*loading*/
        ctx2[13];
      if (dirty[0] & /*rowCount*/
      2)
        table_1_changes.rowCount = /*rowCount*/
        ctx2[1];
      if (dirty[0] & /*quiet*/
      4)
        table_1_changes.quiet = /*quiet*/
        ctx2[2];
      if (dirty[0] & /*compact*/
      32)
        table_1_changes.compact = /*compact*/
        ctx2[5];
      if (dirty[0] & /*snippets*/
      16384)
        table_1_changes.snippets = /*snippets*/
        ctx2[14];
      if (dirty[0] & /*allowSelectRows, table*/
      2064)
        table_1_changes.allowSelectRows = /*allowSelectRows*/
        ctx2[4] && /*table*/
        ctx2[11];
      if (dirty[0] & /*columns*/
      1)
        table_1_changes.autoSortColumns = !/*columns*/
        ((_a2 = ctx2[0]) == null ? void 0 : _a2.length);
      if (dirty[0] & /*noRowsMessage*/
      64)
        table_1_changes.placeholderText = /*noRowsMessage*/
        ctx2[6] || "No rows found";
      if (dirty[1] & /*$$scope*/
      2) {
        table_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_selectedRows && dirty[0] & /*selectedRows*/
      128) {
        updating_selectedRows = true;
        table_1_changes.selectedRows = /*selectedRows*/
        ctx2[7];
        add_flush_callback(() => updating_selectedRows = false);
      }
      table_1.$set(table_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(table_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(table_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(table_1, detaching);
    }
  };
}
function create_if_block(ctx) {
  let div;
  let t0_value = (
    /*selectedRows*/
    ctx[7].length + ""
  );
  let t0;
  let t1;
  let t2_value = (
    /*selectedRows*/
    ctx[7].length === 1 ? "" : "s"
  );
  let t2;
  let t3;
  return {
    c() {
      div = element("div");
      t0 = text(t0_value);
      t1 = text(" row");
      t2 = text(t2_value);
      t3 = text(" selected");
      attr(div, "class", "row-count svelte-9e4ofs");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t0);
      append(div, t1);
      append(div, t2);
      append(div, t3);
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*selectedRows*/
      128 && t0_value !== (t0_value = /*selectedRows*/
      ctx2[7].length + ""))
        set_data(t0, t0_value);
      if (dirty[0] & /*selectedRows*/
      128 && t2_value !== (t2_value = /*selectedRows*/
      ctx2[7].length === 1 ? "" : "s"))
        set_data(t2, t2_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_fragment(ctx) {
  let div;
  let provider;
  let t;
  let div_class_value;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  provider = new Provider({
    props: {
      actions: (
        /*actions*/
        ctx[21]
      ),
      data: (
        /*dataContext*/
        ctx[10]
      ),
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  let if_block = (
    /*allowSelectRows*/
    ctx[4] && /*selectedRows*/
    ctx[7].length && create_if_block(ctx)
  );
  return {
    c() {
      div = element("div");
      create_component(provider.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      attr(div, "class", div_class_value = null_to_empty(
        /*size*/
        ctx[3]
      ) + " svelte-9e4ofs");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(provider, div, null);
      append(div, t);
      if (if_block)
        if_block.m(div, null);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[17].call(
          null,
          div,
          /*$component*/
          ctx[9].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      const provider_changes = {};
      if (dirty[0] & /*dataContext*/
      1024)
        provider_changes.data = /*dataContext*/
        ctx2[10];
      if (dirty[0] & /*data, schema, loading, rowCount, quiet, compact, snippets, allowSelectRows, table, columns, noRowsMessage, selectedRows*/
      31223 | dirty[1] & /*$$scope*/
      2) {
        provider_changes.$$scope = { dirty, ctx: ctx2 };
      }
      provider.$set(provider_changes);
      if (
        /*allowSelectRows*/
        ctx2[4] && /*selectedRows*/
        ctx2[7].length
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          if_block.m(div, null);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (!current || dirty[0] & /*size*/
      8 && div_class_value !== (div_class_value = null_to_empty(
        /*size*/
        ctx2[3]
      ) + " svelte-9e4ofs")) {
        attr(div, "class", div_class_value);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty[0] & /*$component*/
      512)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[9].styles
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(provider.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(provider.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(provider);
      if (if_block)
        if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let snippets;
  let hasChildren;
  let loading;
  let data;
  let fullSchema;
  let primaryDisplay;
  let fields;
  let schema;
  let setSorting;
  let table;
  let dataContext;
  let $component;
  let $context;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { dataProvider } = $$props;
  let { columns } = $$props;
  let { rowCount } = $$props;
  let { quiet } = $$props;
  let { size } = $$props;
  let { allowSelectRows } = $$props;
  let { compact } = $$props;
  let { onClick } = $$props;
  let { noRowsMessage } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(9, $component = value));
  const context = getContext("context");
  component_subscribe($$self, context, (value) => $$invalidate(29, $context = value));
  const { styleable, getAction, ActionTypes, rowSelectionStore, generateGoldenSample } = getContext("sdk");
  const customColumnKey = `custom-${Math.random()}`;
  const customRenderers = [
    {
      column: customColumnKey,
      component: SlotRenderer
    }
  ];
  let selectedRows = [];
  const getAdditionalDataContext = () => {
    const goldenRow = generateGoldenSample(data);
    return { eventContext: { row: goldenRow } };
  };
  const getFields = (schema2, customColumns, showAutoColumns, primaryDisplay2) => {
    if (customColumns == null ? void 0 : customColumns.length) {
      return customColumns;
    }
    let columns2 = [];
    let autoColumns = [];
    Object.entries(schema2).forEach(([field, fieldSchema]) => {
      if (fieldSchema.visible === false) {
        return;
      }
      if (!(fieldSchema == null ? void 0 : fieldSchema.autocolumn)) {
        columns2.push(field);
      } else if (showAutoColumns) {
        autoColumns.push(field);
      }
    });
    const allCols = columns2.concat(autoColumns);
    return allCols.sort((a, b) => {
      if (a === primaryDisplay2) {
        return -1;
      }
      if (b === primaryDisplay2) {
        return 1;
      }
      const aOrder = schema2[a].order;
      const bOrder = schema2[b].order;
      if (aOrder === bOrder) {
        return 0;
      }
      if (aOrder == null) {
        return 1;
      }
      if (bOrder == null) {
        return -1;
      }
      return aOrder < bOrder ? -1 : 1;
    });
  };
  const getFilteredSchema = (schema2, fields2, hasChildren2) => {
    let newSchema = {};
    if (hasChildren2) {
      newSchema[customColumnKey] = {
        displayName: null,
        order: 0,
        sortable: false,
        divider: true,
        width: "auto",
        preventSelectRow: true
      };
    }
    fields2.forEach((field) => {
      const columnName = typeof field === "string" ? field : field.name;
      if (!schema2[columnName]) {
        return;
      }
      newSchema[columnName] = schema2[columnName];
      if (!canBeSortColumn(schema2[columnName])) {
        newSchema[columnName].sortable = false;
      }
      if (typeof field === "object") {
        newSchema[columnName] = { ...newSchema[columnName], ...field };
      }
    });
    return newSchema;
  };
  const onSort = (e) => {
    setSorting({
      column: e.detail.column,
      order: e.detail.order
    });
  };
  const handleClick = (e) => {
    if (onClick) {
      onClick({ row: e.detail });
    }
  };
  const actions = [
    {
      type: ActionTypes.ClearRowSelection,
      callback: () => $$invalidate(7, selectedRows = [])
    }
  ];
  onDestroy(() => {
    rowSelectionStore.actions.updateSelection($component.id, []);
  });
  function table_1_selectedRows_binding(value) {
    selectedRows = value;
    $$invalidate(7, selectedRows), $$invalidate(8, data), $$invalidate(22, dataProvider);
  }
  $$self.$$set = ($$props2) => {
    if ("dataProvider" in $$props2)
      $$invalidate(22, dataProvider = $$props2.dataProvider);
    if ("columns" in $$props2)
      $$invalidate(0, columns = $$props2.columns);
    if ("rowCount" in $$props2)
      $$invalidate(1, rowCount = $$props2.rowCount);
    if ("quiet" in $$props2)
      $$invalidate(2, quiet = $$props2.quiet);
    if ("size" in $$props2)
      $$invalidate(3, size = $$props2.size);
    if ("allowSelectRows" in $$props2)
      $$invalidate(4, allowSelectRows = $$props2.allowSelectRows);
    if ("compact" in $$props2)
      $$invalidate(5, compact = $$props2.compact);
    if ("onClick" in $$props2)
      $$invalidate(23, onClick = $$props2.onClick);
    if ("noRowsMessage" in $$props2)
      $$invalidate(6, noRowsMessage = $$props2.noRowsMessage);
    if ("$$scope" in $$props2)
      $$invalidate(32, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    var _a;
    if ($$self.$$.dirty[0] & /*$context*/
    536870912) {
      $$invalidate(14, snippets = $context.snippets);
    }
    if ($$self.$$.dirty[0] & /*$component*/
    512) {
      $$invalidate(25, hasChildren = $component.children);
    }
    if ($$self.$$.dirty[0] & /*dataProvider*/
    4194304) {
      $$invalidate(13, loading = (dataProvider == null ? void 0 : dataProvider.loading) ?? false);
    }
    if ($$self.$$.dirty[0] & /*dataProvider*/
    4194304) {
      $$invalidate(8, data = (dataProvider == null ? void 0 : dataProvider.rows) || []);
    }
    if ($$self.$$.dirty[0] & /*dataProvider*/
    4194304) {
      $$invalidate(27, fullSchema = (dataProvider == null ? void 0 : dataProvider.schema) ?? {});
    }
    if ($$self.$$.dirty[0] & /*dataProvider*/
    4194304) {
      $$invalidate(28, primaryDisplay = dataProvider == null ? void 0 : dataProvider.primaryDisplay);
    }
    if ($$self.$$.dirty[0] & /*fullSchema, columns, primaryDisplay*/
    402653185) {
      $$invalidate(26, fields = getFields(fullSchema, columns, false, primaryDisplay));
    }
    if ($$self.$$.dirty[0] & /*fullSchema, fields, hasChildren*/
    234881024) {
      $$invalidate(12, schema = getFilteredSchema(fullSchema, fields, hasChildren));
    }
    if ($$self.$$.dirty[0] & /*dataProvider*/
    4194304) {
      setSorting = getAction(dataProvider == null ? void 0 : dataProvider.id, ActionTypes.SetDataProviderSorting);
    }
    if ($$self.$$.dirty[0] & /*dataProvider*/
    4194304) {
      $$invalidate(11, table = ((_a = dataProvider == null ? void 0 : dataProvider.datasource) == null ? void 0 : _a.type) === "table");
    }
    if ($$self.$$.dirty[0] & /*data, selectedRows*/
    384) {
      if (data) {
        let rowIds = data.map((row) => row._id);
        if (rowIds.length) {
          $$invalidate(7, selectedRows = selectedRows.filter((row) => rowIds.includes(row._id)));
        }
      }
    }
    if ($$self.$$.dirty[0] & /*$component, selectedRows*/
    640) {
      {
        rowSelectionStore.actions.updateSelection($component.id, selectedRows.length ? selectedRows[0].tableId : "", selectedRows.map((row) => row._id));
      }
    }
    if ($$self.$$.dirty[0] & /*selectedRows*/
    128) {
      $$invalidate(10, dataContext = { selectedRows });
    }
  };
  return [
    columns,
    rowCount,
    quiet,
    size,
    allowSelectRows,
    compact,
    noRowsMessage,
    selectedRows,
    data,
    $component,
    dataContext,
    table,
    schema,
    loading,
    snippets,
    component,
    context,
    styleable,
    customRenderers,
    onSort,
    handleClick,
    actions,
    dataProvider,
    onClick,
    getAdditionalDataContext,
    hasChildren,
    fields,
    fullSchema,
    primaryDisplay,
    $context,
    slots,
    table_1_selectedRows_binding,
    $$scope
  ];
}
class Table_1 extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        dataProvider: 22,
        columns: 0,
        rowCount: 1,
        quiet: 2,
        size: 3,
        allowSelectRows: 4,
        compact: 5,
        onClick: 23,
        noRowsMessage: 6,
        getAdditionalDataContext: 24
      },
      null,
      [-1, -1]
    );
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[24];
  }
}
export {
  Table_1 as default
};
