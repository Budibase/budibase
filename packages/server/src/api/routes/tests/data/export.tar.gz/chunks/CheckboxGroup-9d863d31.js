import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, b as attr, am as null_to_empty, f as insert, k as transition_in, z as group_outros, n as transition_out, A as check_outros, o as detach, Y as createEventDispatcher, N as ensure_array_like, y as empty, O as destroy_each, I as Icon, a as space, c as create_component, t as text, d as toggle_class, g as append, m as mount_component, l as listen, j as set_data, p as destroy_component } from "./index-8b9900f1.js";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[10] = list[i];
  const constants_0 = (
    /*getOptionValue*/
    child_ctx[6](
      /*option*/
      child_ctx[10]
    )
  );
  child_ctx[11] = constants_0;
  const constants_1 = (
    /*value*/
    child_ctx[1].includes(
      /*optionValue*/
      child_ctx[11]
    )
  );
  child_ctx[12] = constants_1;
  return child_ctx;
}
function create_if_block(ctx) {
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(
    /*options*/
    ctx[2]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*getOptionLabel, options, readonly, value, getOptionValue, disabled, onChange*/
      254) {
        each_value = ensure_array_like(
          /*options*/
          ctx2[2]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_each_block(ctx) {
  let div;
  let label;
  let input;
  let input_checked_value;
  let t0;
  let span1;
  let span0;
  let icon;
  let t1;
  let span2;
  let t2_value = (
    /*getOptionLabel*/
    ctx[5](
      /*option*/
      ctx[10]
    ) + ""
  );
  let t2;
  let t3;
  let div_title_value;
  let current;
  let mounted;
  let dispose;
  function change_handler() {
    return (
      /*change_handler*/
      ctx[8](
        /*optionValue*/
        ctx[11]
      )
    );
  }
  icon = new Icon({
    props: {
      name: "check",
      weight: "bold",
      color: "var(--spectrum-global-color-gray-50)"
    }
  });
  return {
    c() {
      div = element("div");
      label = element("label");
      input = element("input");
      t0 = space();
      span1 = element("span");
      span0 = element("span");
      create_component(icon.$$.fragment);
      t1 = space();
      span2 = element("span");
      t2 = text(t2_value);
      t3 = space();
      attr(input, "type", "checkbox");
      attr(input, "class", "spectrum-Checkbox-input svelte-109ceu5");
      input.checked = input_checked_value = /*checked*/
      ctx[12];
      input.disabled = /*disabled*/
      ctx[3];
      attr(span0, "class", "icon svelte-109ceu5");
      toggle_class(
        span0,
        "checked",
        /*checked*/
        ctx[12]
      );
      attr(span1, "class", "spectrum-Checkbox-box");
      attr(span2, "class", "spectrum-Checkbox-label");
      attr(label, "class", "spectrum-Checkbox spectrum-Checkbox--sizeM spectrum-FieldGroup-item");
      attr(div, "title", div_title_value = /*getOptionLabel*/
      ctx[5](
        /*option*/
        ctx[10]
      ));
      attr(div, "class", "spectrum-Checkbox spectrum-FieldGroup-item svelte-109ceu5");
      toggle_class(
        div,
        "readonly",
        /*readonly*/
        ctx[4]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, label);
      append(label, input);
      append(label, t0);
      append(label, span1);
      append(span1, span0);
      mount_component(icon, span0, null);
      append(label, t1);
      append(label, span2);
      append(span2, t2);
      append(div, t3);
      current = true;
      if (!mounted) {
        dispose = listen(input, "change", change_handler);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (!current || dirty & /*value, getOptionValue, options*/
      70 && input_checked_value !== (input_checked_value = /*checked*/
      ctx[12])) {
        input.checked = input_checked_value;
      }
      if (!current || dirty & /*disabled*/
      8) {
        input.disabled = /*disabled*/
        ctx[3];
      }
      if (!current || dirty & /*value, getOptionValue, options*/
      70) {
        toggle_class(
          span0,
          "checked",
          /*checked*/
          ctx[12]
        );
      }
      if ((!current || dirty & /*getOptionLabel, options*/
      36) && t2_value !== (t2_value = /*getOptionLabel*/
      ctx[5](
        /*option*/
        ctx[10]
      ) + ""))
        set_data(t2, t2_value);
      if (!current || dirty & /*getOptionLabel, options*/
      36 && div_title_value !== (div_title_value = /*getOptionLabel*/
      ctx[5](
        /*option*/
        ctx[10]
      ))) {
        attr(div, "title", div_title_value);
      }
      if (!current || dirty & /*readonly*/
      16) {
        toggle_class(
          div,
          "readonly",
          /*readonly*/
          ctx[4]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
      mounted = false;
      dispose();
    }
  };
}
function create_fragment(ctx) {
  let div;
  let show_if = (
    /*options*/
    ctx[2] && Array.isArray(
      /*options*/
      ctx[2]
    )
  );
  let div_class_value;
  let current;
  let if_block = show_if && create_if_block(ctx);
  return {
    c() {
      div = element("div");
      if (if_block)
        if_block.c();
      attr(div, "class", div_class_value = null_to_empty(`spectrum-FieldGroup spectrum-FieldGroup--${/*direction*/
      ctx[0]}`) + " svelte-109ceu5");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block)
        if_block.m(div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (dirty & /*options*/
      4)
        show_if = /*options*/
        ctx2[2] && Array.isArray(
          /*options*/
          ctx2[2]
        );
      if (show_if) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*options*/
          4) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (!current || dirty & /*direction*/
      1 && div_class_value !== (div_class_value = null_to_empty(`spectrum-FieldGroup spectrum-FieldGroup--${/*direction*/
      ctx2[0]}`) + " svelte-109ceu5")) {
        attr(div, "class", div_class_value);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block)
        if_block.d();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { direction = "vertical" } = $$props;
  let { value = [] } = $$props;
  let { options = [] } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { getOptionLabel = (option) => `${option}` } = $$props;
  let { getOptionValue = (option) => option } = $$props;
  const dispatch = createEventDispatcher();
  const onChange = (optionValue) => {
    if (!value.includes(optionValue)) {
      dispatch("change", [...value, optionValue]);
    } else {
      dispatch("change", value.filter((x) => x !== optionValue));
    }
  };
  const change_handler = (optionValue) => onChange(optionValue);
  $$self.$$set = ($$props2) => {
    if ("direction" in $$props2)
      $$invalidate(0, direction = $$props2.direction);
    if ("value" in $$props2)
      $$invalidate(1, value = $$props2.value);
    if ("options" in $$props2)
      $$invalidate(2, options = $$props2.options);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(4, readonly = $$props2.readonly);
    if ("getOptionLabel" in $$props2)
      $$invalidate(5, getOptionLabel = $$props2.getOptionLabel);
    if ("getOptionValue" in $$props2)
      $$invalidate(6, getOptionValue = $$props2.getOptionValue);
  };
  return [
    direction,
    value,
    options,
    disabled,
    readonly,
    getOptionLabel,
    getOptionValue,
    onChange,
    change_handler
  ];
}
class CheckboxGroup extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      direction: 0,
      value: 1,
      options: 2,
      disabled: 3,
      readonly: 4,
      getOptionLabel: 5,
      getOptionValue: 6
    });
  }
}
export {
  CheckboxGroup as C
};
