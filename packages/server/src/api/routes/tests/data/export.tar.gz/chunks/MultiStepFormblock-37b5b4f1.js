import { S as SvelteComponent, i as init, s as safe_not_equal, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component, v as component_subscribe, ab as builderStore, u as getContext, X as setContext, M as BlockComponent, a3 as writable, az as get_store_value, ck as buildMultiStepFormBlockDefaultProps, at as uuid, N as ensure_array_like, y as empty, f as insert, z as group_outros, cf as update_keyed_each, cg as outro_and_destroy_block, A as check_outros, o as detach, a as space, e as element, b as attr, d as toggle_class } from "./index-8b9900f1.js";
import { a as FormBlockWrapper, F as FormBlockComponent } from "./FormBlockComponent-ef01f7a7.js";
const MultiStepFormblock_svelte_svelte_type_style_lang = "";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[25] = list[i];
  child_ctx[27] = i;
  return child_ctx;
}
function get_each_context_1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[28] = list[i];
  child_ctx[30] = i;
  return child_ctx;
}
function create_if_block_1(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "buttongroup",
      props: { buttons: (
        /*step*/
        ctx[25].buttons
      ) }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*enrichedSteps*/
      128)
        blockcomponent_changes.props = { buttons: (
          /*step*/
          ctx2[25].buttons
        ) };
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_6(ctx) {
  let blockcomponent;
  let t;
  let if_block_anchor;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "textv2",
      props: { text: `## ${/*step*/
      ctx[25].title}` }
    }
  });
  let if_block = (
    /*buttonPosition*/
    ctx[4] === "top" && create_if_block_1(ctx)
  );
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*enrichedSteps*/
      128)
        blockcomponent_changes.props = { text: `## ${/*step*/
        ctx2[25].title}` };
      blockcomponent.$set(blockcomponent_changes);
      if (
        /*buttonPosition*/
        ctx2[4] === "top"
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*buttonPosition*/
          16) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      destroy_component(blockcomponent, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_default_slot_5(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "container",
      props: {
        direction: "row",
        hAlign: "stretch",
        vAlign: "center",
        gap: "M",
        wrap: true
      },
      order: 0,
      $$slots: { default: [create_default_slot_6] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*enrichedSteps, buttonPosition*/
      144 | dirty[1] & /*$$scope*/
      1) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_each_block_1(key_1, ctx) {
  let first;
  let formblockcomponent;
  let current;
  formblockcomponent = new FormBlockComponent({
    props: {
      field: (
        /*field*/
        ctx[28]
      ),
      schema: (
        /*schema*/
        ctx[6]
      ),
      order: (
        /*fieldIdx*/
        ctx[30]
      )
    }
  });
  return {
    key: key_1,
    first: null,
    c() {
      first = empty();
      create_component(formblockcomponent.$$.fragment);
      this.first = first;
    },
    m(target, anchor) {
      insert(target, first, anchor);
      mount_component(formblockcomponent, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const formblockcomponent_changes = {};
      if (dirty[0] & /*enrichedSteps*/
      128)
        formblockcomponent_changes.field = /*field*/
        ctx[28];
      if (dirty[0] & /*schema*/
      64)
        formblockcomponent_changes.schema = /*schema*/
        ctx[6];
      if (dirty[0] & /*enrichedSteps*/
      128)
        formblockcomponent_changes.order = /*fieldIdx*/
        ctx[30];
      formblockcomponent.$set(formblockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(formblockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(formblockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(first);
      }
      destroy_component(formblockcomponent, detaching);
    }
  };
}
function create_default_slot_4(ctx) {
  let div;
  let each_blocks = [];
  let each_1_lookup = /* @__PURE__ */ new Map();
  let current;
  let each_value_1 = ensure_array_like(
    /*step*/
    ctx[25].fields
  );
  const get_key = (ctx2) => `${/*field*/
  ctx2[28].field || /*field*/
  ctx2[28].name}_${/*fieldIdx*/
  ctx2[30]}`;
  for (let i = 0; i < each_value_1.length; i += 1) {
    let child_ctx = get_each_context_1(ctx, each_value_1, i);
    let key = get_key(child_ctx);
    each_1_lookup.set(key, each_blocks[i] = create_each_block_1(key, child_ctx));
  }
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "form-block fields svelte-1gdgv0g");
      toggle_class(
        div,
        "mobile",
        /*$context*/
        ctx[8].device.mobile
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*enrichedSteps, schema*/
      192) {
        each_value_1 = ensure_array_like(
          /*step*/
          ctx2[25].fields
        );
        group_outros();
        each_blocks = update_keyed_each(each_blocks, dirty, get_key, 1, ctx2, each_value_1, each_1_lookup, div, outro_and_destroy_block, create_each_block_1, null, get_each_context_1);
        check_outros();
      }
      if (!current || dirty[0] & /*$context*/
      256) {
        toggle_class(
          div,
          "mobile",
          /*$context*/
          ctx2[8].device.mobile
        );
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value_1.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].d();
      }
    }
  };
}
function create_if_block(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "buttongroup",
      props: {
        buttons: (
          /*step*/
          ctx[25].buttons
        ),
        collapsed: (
          /*step*/
          ctx[25].buttonsCollapsed
        ),
        collapsedText: (
          /*step*/
          ctx[25].buttonsCollapsedText
        )
      },
      order: 3
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*enrichedSteps*/
      128)
        blockcomponent_changes.props = {
          buttons: (
            /*step*/
            ctx2[25].buttons
          ),
          collapsed: (
            /*step*/
            ctx2[25].buttonsCollapsed
          ),
          collapsedText: (
            /*step*/
            ctx2[25].buttonsCollapsedText
          )
        };
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_3(ctx) {
  let blockcomponent0;
  let t0;
  let blockcomponent1;
  let t1;
  let blockcomponent2;
  let t2;
  let if_block_anchor;
  let current;
  blockcomponent0 = new BlockComponent({
    props: {
      type: "container",
      props: { direction: "column", gap: "S" },
      order: 0,
      $$slots: { default: [create_default_slot_5] },
      $$scope: { ctx }
    }
  });
  blockcomponent1 = new BlockComponent({
    props: {
      type: "textv2",
      props: { text: (
        /*step*/
        ctx[25].desc
      ) },
      order: 1
    }
  });
  blockcomponent2 = new BlockComponent({
    props: {
      type: "container",
      order: 2,
      $$slots: { default: [create_default_slot_4] },
      $$scope: { ctx }
    }
  });
  let if_block = (
    /*buttonPosition*/
    ctx[4] === "bottom" && create_if_block(ctx)
  );
  return {
    c() {
      create_component(blockcomponent0.$$.fragment);
      t0 = space();
      create_component(blockcomponent1.$$.fragment);
      t1 = space();
      create_component(blockcomponent2.$$.fragment);
      t2 = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      mount_component(blockcomponent0, target, anchor);
      insert(target, t0, anchor);
      mount_component(blockcomponent1, target, anchor);
      insert(target, t1, anchor);
      mount_component(blockcomponent2, target, anchor);
      insert(target, t2, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent0_changes = {};
      if (dirty[0] & /*enrichedSteps, buttonPosition*/
      144 | dirty[1] & /*$$scope*/
      1) {
        blockcomponent0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent0.$set(blockcomponent0_changes);
      const blockcomponent1_changes = {};
      if (dirty[0] & /*enrichedSteps*/
      128)
        blockcomponent1_changes.props = { text: (
          /*step*/
          ctx2[25].desc
        ) };
      blockcomponent1.$set(blockcomponent1_changes);
      const blockcomponent2_changes = {};
      if (dirty[0] & /*$context, enrichedSteps, schema*/
      448 | dirty[1] & /*$$scope*/
      1) {
        blockcomponent2_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent2.$set(blockcomponent2_changes);
      if (
        /*buttonPosition*/
        ctx2[4] === "bottom"
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*buttonPosition*/
          16) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent0.$$.fragment, local);
      transition_in(blockcomponent1.$$.fragment, local);
      transition_in(blockcomponent2.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent0.$$.fragment, local);
      transition_out(blockcomponent1.$$.fragment, local);
      transition_out(blockcomponent2.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
        detach(if_block_anchor);
      }
      destroy_component(blockcomponent0, detaching);
      destroy_component(blockcomponent1, detaching);
      destroy_component(blockcomponent2, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_default_slot_2(ctx) {
  let blockcomponent;
  let t;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "container",
      props: {
        gap: "M",
        direction: "column",
        hAlign: "stretch",
        vAlign: "top",
        size: "shrink"
      },
      $$slots: { default: [create_default_slot_3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
      t = space();
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      insert(target, t, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*enrichedSteps, buttonPosition, $context, schema*/
      464 | dirty[1] & /*$$scope*/
      1) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_each_block(key_1, ctx) {
  let first;
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "formstep",
      props: {
        step: (
          /*stepIdx*/
          ctx[27] + 1
        ),
        _instanceName: `Step ${/*stepIdx*/
        ctx[27] + 1}`
      },
      $$slots: { default: [create_default_slot_2] },
      $$scope: { ctx }
    }
  });
  return {
    key: key_1,
    first: null,
    c() {
      first = empty();
      create_component(blockcomponent.$$.fragment);
      this.first = first;
    },
    m(target, anchor) {
      insert(target, first, anchor);
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const blockcomponent_changes = {};
      if (dirty[0] & /*enrichedSteps*/
      128)
        blockcomponent_changes.props = {
          step: (
            /*stepIdx*/
            ctx[27] + 1
          ),
          _instanceName: `Step ${/*stepIdx*/
          ctx[27] + 1}`
        };
      if (dirty[0] & /*enrichedSteps, buttonPosition, $context, schema*/
      464 | dirty[1] & /*$$scope*/
      1) {
        blockcomponent_changes.$$scope = { dirty, ctx };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(first);
      }
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let each_blocks = [];
  let each_1_lookup = /* @__PURE__ */ new Map();
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(
    /*enrichedSteps*/
    ctx[7]
  );
  const get_key = (ctx2) => (
    /*step*/
    ctx2[25]._stepId
  );
  for (let i = 0; i < each_value.length; i += 1) {
    let child_ctx = get_each_context(ctx, each_value, i);
    let key = get_key(child_ctx);
    each_1_lookup.set(key, each_blocks[i] = create_each_block(key, child_ctx));
  }
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*enrichedSteps, buttonPosition, $context, schema*/
      464) {
        each_value = ensure_array_like(
          /*enrichedSteps*/
          ctx2[7]
        );
        group_outros();
        each_blocks = update_keyed_each(each_blocks, dirty, get_key, 1, ctx2, each_value, each_1_lookup, each_1_anchor.parentNode, outro_and_destroy_block, create_each_block, each_1_anchor, get_each_context);
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].d(detaching);
      }
    }
  };
}
function create_default_slot(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "form",
      context: "form",
      props: {
        size: (
          /*size*/
          ctx[5]
        ),
        dataSource: (
          /*dataSource*/
          ctx[3]
        ),
        actionType: (
          /*actionType*/
          ctx[0] === "Create" ? "Create" : "Update"
        ),
        readonly: (
          /*actionType*/
          ctx[0] === "View"
        )
      },
      styles: {
        normal: {
          width: "600px",
          "margin-left": "auto",
          "margin-right": "auto"
        }
      },
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*size, dataSource, actionType*/
      41)
        blockcomponent_changes.props = {
          size: (
            /*size*/
            ctx2[5]
          ),
          dataSource: (
            /*dataSource*/
            ctx2[3]
          ),
          actionType: (
            /*actionType*/
            ctx2[0] === "Create" ? "Create" : "Update"
          ),
          readonly: (
            /*actionType*/
            ctx2[0] === "View"
          )
        };
      if (dirty[0] & /*enrichedSteps, buttonPosition, $context, schema*/
      464 | dirty[1] & /*$$scope*/
      1) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_fragment(ctx) {
  let formblockwrapper;
  let current;
  formblockwrapper = new FormBlockWrapper({
    props: {
      actionType: (
        /*actionType*/
        ctx[0]
      ),
      dataSource: (
        /*dataSource*/
        ctx[3]
      ),
      rowId: (
        /*rowId*/
        ctx[1]
      ),
      noRowsMessage: (
        /*noRowsMessage*/
        ctx[2]
      ),
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(formblockwrapper.$$.fragment);
    },
    m(target, anchor) {
      mount_component(formblockwrapper, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const formblockwrapper_changes = {};
      if (dirty[0] & /*actionType*/
      1)
        formblockwrapper_changes.actionType = /*actionType*/
        ctx2[0];
      if (dirty[0] & /*dataSource*/
      8)
        formblockwrapper_changes.dataSource = /*dataSource*/
        ctx2[3];
      if (dirty[0] & /*rowId*/
      2)
        formblockwrapper_changes.rowId = /*rowId*/
        ctx2[1];
      if (dirty[0] & /*noRowsMessage*/
      4)
        formblockwrapper_changes.noRowsMessage = /*noRowsMessage*/
        ctx2[2];
      if (dirty[0] & /*size, dataSource, actionType, enrichedSteps, buttonPosition, $context, schema*/
      505 | dirty[1] & /*$$scope*/
      1) {
        formblockwrapper_changes.$$scope = { dirty, ctx: ctx2 };
      }
      formblockwrapper.$set(formblockwrapper_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(formblockwrapper.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(formblockwrapper.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(formblockwrapper, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let id;
  let selected;
  let builderStep;
  let enrichedSteps;
  let $builderStore;
  let $component;
  let $context;
  component_subscribe($$self, builderStore, ($$value) => $$invalidate(16, $builderStore = $$value));
  let { actionType } = $$props;
  let { rowId } = $$props;
  let { noRowsMessage } = $$props;
  let { steps } = $$props;
  let { dataSource } = $$props;
  let { buttonPosition = "bottom" } = $$props;
  let { size } = $$props;
  const { fetchDatasourceSchema, generateGoldenSample } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(17, $component = value));
  const context = getContext("context");
  component_subscribe($$self, context, (value) => $$invalidate(8, $context = value));
  const currentStep = writable(1);
  setContext("current-step", currentStep);
  let schema;
  const getAdditionalDataContext = () => {
    var _a;
    const id2 = get_store_value(component).id;
    const rows = ((_a = get_store_value(context)[`${id2}-provider`]) == null ? void 0 : _a.rows) || [];
    const goldenRow = generateGoldenSample(rows);
    return { [`${id2}-repeater`]: goldenRow };
  };
  const updateCurrentStep = (steps2, selected2, builderStep2) => {
    if (!selected2) {
      return;
    }
    let newStep = Math.min(builderStep2 || 0, steps2.length - 1);
    newStep = Math.max(newStep, 0);
    currentStep.set(newStep + 1);
  };
  const fetchSchema = async (dataSource2) => {
    $$invalidate(6, schema = await fetchDatasourceSchema(dataSource2) || {});
  };
  const getDefaultFields = (fields, schema2) => {
    if (fields == null ? void 0 : fields.length) {
      return fields.filter((field) => field.active);
    }
    return Object.values(schema2 || {}).filter((field) => !field.autocolumn).map((field) => ({ name: field.name, active: true }));
  };
  const enrichSteps = (steps2, schema2, id2) => {
    const safeSteps = (steps2 == null ? void 0 : steps2.length) ? steps2 : [{}];
    return safeSteps.map((step, idx) => {
      const { title, fields, buttons } = step;
      const defaultProps = buildMultiStepFormBlockDefaultProps({
        _id: id2,
        stepCount: safeSteps.length,
        currentStep: idx,
        actionType,
        dataSource
      });
      return {
        ...step,
        _stepId: uuid(),
        fields: getDefaultFields(fields || [], schema2),
        title: title ?? defaultProps.title,
        buttons: buttons || defaultProps.buttons
      };
    });
  };
  $$self.$$set = ($$props2) => {
    if ("actionType" in $$props2)
      $$invalidate(0, actionType = $$props2.actionType);
    if ("rowId" in $$props2)
      $$invalidate(1, rowId = $$props2.rowId);
    if ("noRowsMessage" in $$props2)
      $$invalidate(2, noRowsMessage = $$props2.noRowsMessage);
    if ("steps" in $$props2)
      $$invalidate(11, steps = $$props2.steps);
    if ("dataSource" in $$props2)
      $$invalidate(3, dataSource = $$props2.dataSource);
    if ("buttonPosition" in $$props2)
      $$invalidate(4, buttonPosition = $$props2.buttonPosition);
    if ("size" in $$props2)
      $$invalidate(5, size = $$props2.size);
  };
  $$self.$$.update = () => {
    var _a;
    if ($$self.$$.dirty[0] & /*$component*/
    131072) {
      $$invalidate(15, id = $component.id);
    }
    if ($$self.$$.dirty[0] & /*$component*/
    131072) {
      $$invalidate(14, selected = $component.selected);
    }
    if ($$self.$$.dirty[0] & /*$builderStore*/
    65536) {
      $$invalidate(13, builderStep = (_a = $builderStore.metadata) == null ? void 0 : _a.step);
    }
    if ($$self.$$.dirty[0] & /*dataSource*/
    8) {
      fetchSchema(dataSource);
    }
    if ($$self.$$.dirty[0] & /*steps, schema, id*/
    34880) {
      $$invalidate(7, enrichedSteps = enrichSteps(steps, schema, id));
    }
    if ($$self.$$.dirty[0] & /*enrichedSteps, selected, builderStep*/
    24704) {
      updateCurrentStep(enrichedSteps, selected, builderStep);
    }
  };
  return [
    actionType,
    rowId,
    noRowsMessage,
    dataSource,
    buttonPosition,
    size,
    schema,
    enrichedSteps,
    $context,
    component,
    context,
    steps,
    getAdditionalDataContext,
    builderStep,
    selected,
    id,
    $builderStore,
    $component
  ];
}
class MultiStepFormblock extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        actionType: 0,
        rowId: 1,
        noRowsMessage: 2,
        steps: 11,
        dataSource: 3,
        buttonPosition: 4,
        size: 5,
        getAdditionalDataContext: 12
      },
      null,
      [-1, -1]
    );
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[12];
  }
}
export {
  MultiStepFormblock as default
};
