import { S as SvelteComponent, i as init, s as safe_not_equal, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component } from "./index-8b9900f1.js";
import { A as ApexChart, p as parsePalette, f as formatters } from "./ApexChart-5b4a3d9d.js";
function create_fragment(ctx) {
  let apexchart;
  let current;
  apexchart = new ApexChart({ props: { options: (
    /*options*/
    ctx[0]
  ) } });
  return {
    c() {
      create_component(apexchart.$$.fragment);
    },
    m(target, anchor) {
      mount_component(apexchart, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const apexchart_changes = {};
      if (dirty & /*options*/
      1)
        apexchart_changes.options = /*options*/
        ctx2[0];
      apexchart.$set(apexchart_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(apexchart.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(apexchart.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(apexchart, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let series;
  let categories;
  let labelType;
  let xAxisFormatter;
  let yAxisFormatter;
  let options;
  let { dataProvider } = $$props;
  let { labelColumn } = $$props;
  let { valueColumns } = $$props;
  let { title } = $$props;
  let { xAxisLabel } = $$props;
  let { yAxisLabel } = $$props;
  let { height } = $$props;
  let { width } = $$props;
  let { dataLabels } = $$props;
  let { animate } = $$props;
  let { legend } = $$props;
  let { stacked } = $$props;
  let { yAxisUnits } = $$props;
  let { palette } = $$props;
  let { c1, c2, c3, c4, c5 } = $$props;
  let { horizontal } = $$props;
  let { onClick } = $$props;
  function handleBarClick(bar) {
    onClick == null ? void 0 : onClick({ bar });
  }
  const getSeries = (dataProvider2, valueColumns2 = []) => {
    const rows = dataProvider2.rows ?? [];
    return valueColumns2.map((column) => ({
      name: column,
      data: rows.map((row) => {
        var _a, _b;
        const value = row == null ? void 0 : row[column];
        if (((_b = (_a = dataProvider2 == null ? void 0 : dataProvider2.schema) == null ? void 0 : _a[column]) == null ? void 0 : _b.type) === "datetime" && value) {
          return Date.parse(value);
        }
        return value;
      })
    }));
  };
  const getCategories = (dataProvider2, labelColumn2) => {
    const rows = dataProvider2.rows ?? [];
    return rows.map((row) => {
      const value = row == null ? void 0 : row[labelColumn2];
      if (!["string", "number", "boolean"].includes(typeof value)) {
        return "";
      }
      return value;
    });
  };
  const getFormatter = (labelType2, yAxisUnits2, horizontal2, axis) => {
    const isLabelAxis = axis === "y" && horizontal2 || axis === "x" && !horizontal2;
    if (labelType2 === "datetime" && isLabelAxis) {
      return formatters["Datetime"];
    }
    if (isLabelAxis) {
      return formatters["Default"];
    }
    return formatters[yAxisUnits2];
  };
  $$self.$$set = ($$props2) => {
    if ("dataProvider" in $$props2)
      $$invalidate(1, dataProvider = $$props2.dataProvider);
    if ("labelColumn" in $$props2)
      $$invalidate(2, labelColumn = $$props2.labelColumn);
    if ("valueColumns" in $$props2)
      $$invalidate(3, valueColumns = $$props2.valueColumns);
    if ("title" in $$props2)
      $$invalidate(4, title = $$props2.title);
    if ("xAxisLabel" in $$props2)
      $$invalidate(5, xAxisLabel = $$props2.xAxisLabel);
    if ("yAxisLabel" in $$props2)
      $$invalidate(6, yAxisLabel = $$props2.yAxisLabel);
    if ("height" in $$props2)
      $$invalidate(7, height = $$props2.height);
    if ("width" in $$props2)
      $$invalidate(8, width = $$props2.width);
    if ("dataLabels" in $$props2)
      $$invalidate(9, dataLabels = $$props2.dataLabels);
    if ("animate" in $$props2)
      $$invalidate(10, animate = $$props2.animate);
    if ("legend" in $$props2)
      $$invalidate(11, legend = $$props2.legend);
    if ("stacked" in $$props2)
      $$invalidate(12, stacked = $$props2.stacked);
    if ("yAxisUnits" in $$props2)
      $$invalidate(13, yAxisUnits = $$props2.yAxisUnits);
    if ("palette" in $$props2)
      $$invalidate(14, palette = $$props2.palette);
    if ("c1" in $$props2)
      $$invalidate(15, c1 = $$props2.c1);
    if ("c2" in $$props2)
      $$invalidate(16, c2 = $$props2.c2);
    if ("c3" in $$props2)
      $$invalidate(17, c3 = $$props2.c3);
    if ("c4" in $$props2)
      $$invalidate(18, c4 = $$props2.c4);
    if ("c5" in $$props2)
      $$invalidate(19, c5 = $$props2.c5);
    if ("horizontal" in $$props2)
      $$invalidate(20, horizontal = $$props2.horizontal);
    if ("onClick" in $$props2)
      $$invalidate(21, onClick = $$props2.onClick);
  };
  $$self.$$.update = () => {
    var _a, _b;
    if ($$self.$$.dirty & /*dataProvider, valueColumns*/
    10) {
      $$invalidate(25, series = getSeries(dataProvider, valueColumns));
    }
    if ($$self.$$.dirty & /*dataProvider, labelColumn*/
    6) {
      $$invalidate(24, categories = getCategories(dataProvider, labelColumn));
    }
    if ($$self.$$.dirty & /*dataProvider, labelColumn*/
    6) {
      $$invalidate(26, labelType = ((_b = (_a = dataProvider == null ? void 0 : dataProvider.schema) == null ? void 0 : _a[labelColumn]) == null ? void 0 : _b.type) === "datetime" ? "datetime" : "category");
    }
    if ($$self.$$.dirty & /*labelType, yAxisUnits, horizontal*/
    68165632) {
      $$invalidate(23, xAxisFormatter = getFormatter(labelType, yAxisUnits, horizontal, "x"));
    }
    if ($$self.$$.dirty & /*labelType, yAxisUnits, horizontal*/
    68165632) {
      $$invalidate(22, yAxisFormatter = getFormatter(labelType, yAxisUnits, horizontal, "y"));
    }
    if ($$self.$$.dirty & /*series, palette, c1, c2, c3, c4, c5, legend, title, dataLabels, height, width, stacked, animate, dataProvider, horizontal, categories, xAxisFormatter, xAxisLabel, yAxisFormatter, yAxisLabel*/
    65003506) {
      $$invalidate(0, options = {
        series,
        colors: palette === "Custom" ? [c1, c2, c3, c4, c5] : [],
        theme: { palette: parsePalette(palette) },
        legend: {
          show: legend,
          position: "top",
          horizontalAlign: "right",
          showForSingleSeries: true,
          showForNullSeries: true,
          showForZeroSeries: true
        },
        title: { text: title },
        dataLabels: {
          enabled: dataLabels,
          dropShadow: { enabled: true }
        },
        chart: {
          height: height == null || height === "" ? "auto" : height,
          width: width == null || width === "" ? "100%" : width,
          type: "bar",
          stacked,
          animations: { enabled: animate },
          toolbar: { show: false },
          zoom: { enabled: false },
          events: {
            // Clicking on a bar or group of bars
            dataPointSelection(event, chartContext, opts) {
              const barsIndex = opts.dataPointIndex;
              const row = dataProvider.rows[barsIndex];
              handleBarClick(row);
            }
          }
        },
        plotOptions: { bar: { horizontal } },
        // We can just always provide the categories to the xaxis and horizontal mode automatically handles "tranposing" the categories to the yaxis, but certain things like labels need to be manually put on a certain axis based on the selected mode. Titles do not need to be handled this way, they are exposed to the user as "X axis" and Y Axis" so flipping them would be confusing.
        xaxis: {
          categories,
          labels: { formatter: xAxisFormatter },
          title: { text: xAxisLabel }
        },
        // Providing `type: "datetime"` normally makes Apex Charts parse unix time nicely with no additonal config, but bar charts in horizontal mode don't have a default setting for parsing the labels of dates, and will just spit out the unix time value. It also doesn't seem to respect any date based formatting properties passed in. So we'll just manually format the labels, the chart still sorts the dates correctly in any case
        yaxis: {
          labels: { formatter: yAxisFormatter },
          title: { text: yAxisLabel }
        }
      });
    }
  };
  return [
    options,
    dataProvider,
    labelColumn,
    valueColumns,
    title,
    xAxisLabel,
    yAxisLabel,
    height,
    width,
    dataLabels,
    animate,
    legend,
    stacked,
    yAxisUnits,
    palette,
    c1,
    c2,
    c3,
    c4,
    c5,
    horizontal,
    onClick,
    yAxisFormatter,
    xAxisFormatter,
    categories,
    series,
    labelType
  ];
}
class BarChart extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      dataProvider: 1,
      labelColumn: 2,
      valueColumns: 3,
      title: 4,
      xAxisLabel: 5,
      yAxisLabel: 6,
      height: 7,
      width: 8,
      dataLabels: 9,
      animate: 10,
      legend: 11,
      stacked: 12,
      yAxisUnits: 13,
      palette: 14,
      c1: 15,
      c2: 16,
      c3: 17,
      c4: 18,
      c5: 19,
      horizontal: 20,
      onClick: 21
    });
  }
}
export {
  BarChart as default
};
