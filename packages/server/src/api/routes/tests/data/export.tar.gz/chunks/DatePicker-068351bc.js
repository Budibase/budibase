import { S as SvelteComponent, i as init, s as safe_not_equal, bB as Field, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component, Y as createEventDispatcher } from "./index-8b9900f1.js";
import { D as DatePicker } from "./DatePicker-35c5ed8a.js";
function create_default_slot(ctx) {
  let datepicker;
  let current;
  datepicker = new DatePicker({
    props: {
      error: (
        /*error*/
        ctx[5]
      ),
      disabled: (
        /*disabled*/
        ctx[3]
      ),
      readonly: (
        /*readonly*/
        ctx[4]
      ),
      value: (
        /*value*/
        ctx[0]
      ),
      placeholder: (
        /*placeholder*/
        ctx[8]
      ),
      enableTime: (
        /*enableTime*/
        ctx[6]
      ),
      timeOnly: (
        /*timeOnly*/
        ctx[7]
      ),
      appendTo: (
        /*appendTo*/
        ctx[9]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        ctx[10]
      )
    }
  });
  datepicker.$on(
    "change",
    /*onChange*/
    ctx[12]
  );
  return {
    c() {
      create_component(datepicker.$$.fragment);
    },
    m(target, anchor) {
      mount_component(datepicker, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const datepicker_changes = {};
      if (dirty & /*error*/
      32)
        datepicker_changes.error = /*error*/
        ctx2[5];
      if (dirty & /*disabled*/
      8)
        datepicker_changes.disabled = /*disabled*/
        ctx2[3];
      if (dirty & /*readonly*/
      16)
        datepicker_changes.readonly = /*readonly*/
        ctx2[4];
      if (dirty & /*value*/
      1)
        datepicker_changes.value = /*value*/
        ctx2[0];
      if (dirty & /*placeholder*/
      256)
        datepicker_changes.placeholder = /*placeholder*/
        ctx2[8];
      if (dirty & /*enableTime*/
      64)
        datepicker_changes.enableTime = /*enableTime*/
        ctx2[6];
      if (dirty & /*timeOnly*/
      128)
        datepicker_changes.timeOnly = /*timeOnly*/
        ctx2[7];
      if (dirty & /*appendTo*/
      512)
        datepicker_changes.appendTo = /*appendTo*/
        ctx2[9];
      if (dirty & /*ignoreTimezones*/
      1024)
        datepicker_changes.ignoreTimezones = /*ignoreTimezones*/
        ctx2[10];
      datepicker.$set(datepicker_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(datepicker.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(datepicker.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(datepicker, detaching);
    }
  };
}
function create_fragment(ctx) {
  let field;
  let current;
  field = new Field({
    props: {
      helpText: (
        /*helpText*/
        ctx[11]
      ),
      label: (
        /*label*/
        ctx[1]
      ),
      labelPosition: (
        /*labelPosition*/
        ctx[2]
      ),
      error: (
        /*error*/
        ctx[5]
      ),
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(field.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const field_changes = {};
      if (dirty & /*helpText*/
      2048)
        field_changes.helpText = /*helpText*/
        ctx2[11];
      if (dirty & /*label*/
      2)
        field_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*labelPosition*/
      4)
        field_changes.labelPosition = /*labelPosition*/
        ctx2[2];
      if (dirty & /*error*/
      32)
        field_changes.error = /*error*/
        ctx2[5];
      if (dirty & /*$$scope, error, disabled, readonly, value, placeholder, enableTime, timeOnly, appendTo, ignoreTimezones*/
      18425) {
        field_changes.$$scope = { dirty, ctx: ctx2 };
      }
      field.$set(field_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { value = null } = $$props;
  let { label = void 0 } = $$props;
  let { labelPosition = "above" } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { error = void 0 } = $$props;
  let { enableTime = true } = $$props;
  let { timeOnly = false } = $$props;
  let { placeholder = null } = $$props;
  let { appendTo = void 0 } = $$props;
  let { ignoreTimezones = false } = $$props;
  let { helpText = void 0 } = $$props;
  const dispatch = createEventDispatcher();
  const onChange = (e) => {
    $$invalidate(0, value = e.detail);
    dispatch("change", e.detail);
  };
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("labelPosition" in $$props2)
      $$invalidate(2, labelPosition = $$props2.labelPosition);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(4, readonly = $$props2.readonly);
    if ("error" in $$props2)
      $$invalidate(5, error = $$props2.error);
    if ("enableTime" in $$props2)
      $$invalidate(6, enableTime = $$props2.enableTime);
    if ("timeOnly" in $$props2)
      $$invalidate(7, timeOnly = $$props2.timeOnly);
    if ("placeholder" in $$props2)
      $$invalidate(8, placeholder = $$props2.placeholder);
    if ("appendTo" in $$props2)
      $$invalidate(9, appendTo = $$props2.appendTo);
    if ("ignoreTimezones" in $$props2)
      $$invalidate(10, ignoreTimezones = $$props2.ignoreTimezones);
    if ("helpText" in $$props2)
      $$invalidate(11, helpText = $$props2.helpText);
  };
  return [
    value,
    label,
    labelPosition,
    disabled,
    readonly,
    error,
    enableTime,
    timeOnly,
    placeholder,
    appendTo,
    ignoreTimezones,
    helpText,
    onChange
  ];
}
class DatePicker_1 extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      value: 0,
      label: 1,
      labelPosition: 2,
      disabled: 3,
      readonly: 4,
      error: 5,
      enableTime: 6,
      timeOnly: 7,
      placeholder: 8,
      appendTo: 9,
      ignoreTimezones: 10,
      helpText: 11
    });
  }
}
export {
  DatePicker_1 as D
};
