import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, c as create_component, b as attr, f as insert, m as mount_component, q as action_destroyer, h as is_function, k as transition_in, n as transition_out, o as detach, p as destroy_component, u as getContext, v as component_subscribe, F as create_slot, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes } from "./index-8b9900f1.js";
const SingleRowProvider_svelte_svelte_type_style_lang = "";
function create_default_slot(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[9].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[10],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        1024)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[10],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[10]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[10],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let div;
  let provider;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  provider = new /*Provider*/
  ctx[5]({
    props: {
      actions: (
        /*actions*/
        ctx[1]
      ),
      data: (
        /*row*/
        ctx[0] ?? null
      ),
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div = element("div");
      create_component(provider.$$.fragment);
      attr(div, "class", "svelte-1ccs8qd");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(provider, div, null);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[4].call(
          null,
          div,
          /*$component*/
          ctx[2].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      const provider_changes = {};
      if (dirty & /*actions*/
      2)
        provider_changes.actions = /*actions*/
        ctx2[1];
      if (dirty & /*row*/
      1)
        provider_changes.data = /*row*/
        ctx2[0] ?? null;
      if (dirty & /*$$scope*/
      1024) {
        provider_changes.$$scope = { dirty, ctx: ctx2 };
      }
      provider.$set(provider_changes);
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      4)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[2].styles
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(provider.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(provider.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(provider);
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let datasourceId;
  let actions;
  let $component;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { datasource } = $$props;
  let { rowId } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(2, $component = value));
  const { styleable, API, Provider, ActionTypes } = getContext("sdk");
  let row;
  const fetchRow = async (datasourceId2, rowId2) => {
    try {
      $$invalidate(0, row = await API.fetchRow(datasourceId2, rowId2));
    } catch (e) {
      $$invalidate(0, row = void 0);
    }
  };
  $$self.$$set = ($$props2) => {
    if ("datasource" in $$props2)
      $$invalidate(6, datasource = $$props2.datasource);
    if ("rowId" in $$props2)
      $$invalidate(7, rowId = $$props2.rowId);
    if ("$$scope" in $$props2)
      $$invalidate(10, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*datasource*/
    64) {
      $$invalidate(8, datasourceId = datasource.type === "table" ? datasource.tableId : datasource.id);
    }
    if ($$self.$$.dirty & /*datasourceId, rowId*/
    384) {
      fetchRow(datasourceId, rowId);
    }
    if ($$self.$$.dirty & /*datasourceId, rowId, datasource*/
    448) {
      $$invalidate(1, actions = [
        {
          type: ActionTypes.RefreshDatasource,
          callback: () => fetchRow(datasourceId, rowId),
          metadata: { dataSource: datasource }
        }
      ]);
    }
  };
  return [
    row,
    actions,
    $component,
    component,
    styleable,
    Provider,
    datasource,
    rowId,
    datasourceId,
    slots,
    $$scope
  ];
}
class SingleRowProvider extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { datasource: 6, rowId: 7 });
  }
}
export {
  SingleRowProvider as default
};
