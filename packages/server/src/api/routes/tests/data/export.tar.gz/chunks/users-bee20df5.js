import { bV as DocumentType, bW as SEPARATOR, bN as InternalTable } from "./index-8b9900f1.js";
function hasAppBuilderPermissions(user) {
  var _a, _b, _c;
  if (!user) {
    return false;
  }
  const appLength = (_b = (_a = user.builder) == null ? void 0 : _a.apps) == null ? void 0 : _b.length;
  const isGlobalBuilder2 = !!((_c = user.builder) == null ? void 0 : _c.global);
  return !isGlobalBuilder2 && appLength != null && appLength > 0;
}
function hasBuilderPermissions(user) {
  var _a;
  if (!user) {
    return false;
  }
  return ((_a = user.builder) == null ? void 0 : _a.global) || hasAppBuilderPermissions(user) || hasCreatorPermissions(user);
}
function hasCreatorPermissions(user) {
  var _a;
  if (!user) {
    return false;
  }
  return !!((_a = user.builder) == null ? void 0 : _a.creator);
}
function getGlobalUserID(userId) {
  if (typeof userId !== "string") {
    return userId;
  }
  const prefix = `${DocumentType.ROW}${SEPARATOR}${InternalTable.USER_METADATA}${SEPARATOR}`;
  if (!userId.startsWith(prefix)) {
    return userId;
  }
  return userId.split(prefix)[1];
}
function containsUserID(value) {
  if (typeof value !== "string") {
    return false;
  }
  return value.includes(`${DocumentType.USER}${SEPARATOR}`);
}
export {
  containsUserID as c,
  getGlobalUserID as g,
  hasBuilderPermissions as h
};
