import { S as SvelteComponent, i as init, s as safe_not_equal, bs as assign, c as create_component, m as mount_component, bR as get_spread_update, bS as get_spread_object, k as transition_in, n as transition_out, p as destroy_component, bt as exclude_internal_props } from "./index-8b9900f1.js";
import StringField from "./StringField-ac8abf33.js";
import "./Field-a0270b82.js";
import "./Placeholder-4dedd9c4.js";
import "./InnerForm-0042fa8f.js";
function create_fragment(ctx) {
  let stringfield;
  let current;
  const stringfield_spread_levels = [
    /*$$props*/
    ctx[2],
    { type: "number" },
    {
      defaultValue: (
        /*parseNumber*/
        ctx[1](
          /*defaultValue*/
          ctx[0]
        )
      )
    }
  ];
  let stringfield_props = {};
  for (let i = 0; i < stringfield_spread_levels.length; i += 1) {
    stringfield_props = assign(stringfield_props, stringfield_spread_levels[i]);
  }
  stringfield = new StringField({ props: stringfield_props });
  return {
    c() {
      create_component(stringfield.$$.fragment);
    },
    m(target, anchor) {
      mount_component(stringfield, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const stringfield_changes = dirty & /*$$props, parseNumber, defaultValue*/
      7 ? get_spread_update(stringfield_spread_levels, [
        dirty & /*$$props*/
        4 && get_spread_object(
          /*$$props*/
          ctx2[2]
        ),
        stringfield_spread_levels[1],
        dirty & /*parseNumber, defaultValue*/
        3 && {
          defaultValue: (
            /*parseNumber*/
            ctx2[1](
              /*defaultValue*/
              ctx2[0]
            )
          )
        }
      ]) : {};
      stringfield.$set(stringfield_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(stringfield.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(stringfield.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(stringfield, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { defaultValue } = $$props;
  const parseNumber = (val) => {
    if (val == null) {
      return null;
    }
    return isNaN(val) ? null : parseFloat(val);
  };
  $$self.$$set = ($$new_props) => {
    $$invalidate(2, $$props = assign(assign({}, $$props), exclude_internal_props($$new_props)));
    if ("defaultValue" in $$new_props)
      $$invalidate(0, defaultValue = $$new_props.defaultValue);
  };
  $$props = exclude_internal_props($$props);
  return [defaultValue, parseNumber, $$props];
}
class NumberField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { defaultValue: 0 });
  }
}
export {
  NumberField as default
};
