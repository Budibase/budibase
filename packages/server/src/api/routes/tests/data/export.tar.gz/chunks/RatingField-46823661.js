import { S as SvelteComponent, i as init, s as safe_not_equal, aK as FieldType, W as binding_callbacks, a0 as bind, c as create_component, m as mount_component, a1 as add_flush_callback, k as transition_in, n as transition_out, p as destroy_component, N as ensure_array_like, e as element, b as attr, f as insert, z as group_outros, A as check_outros, o as detach, O as destroy_each, I as Icon, a as space, d as toggle_class, al as set_style, g as append, l as listen, h as is_function, r as run_all } from "./index-8b9900f1.js";
import { F as Field } from "./Field-a0270b82.js";
import "./Placeholder-4dedd9c4.js";
import "./InnerForm-0042fa8f.js";
const RatingField_svelte_svelte_type_style_lang = "";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[31] = list[i];
  child_ctx[33] = i;
  return child_ctx;
}
function create_each_block(ctx) {
  var _a;
  let button;
  let div;
  let icon;
  let t;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({
    props: {
      name: (
        /*type*/
        ctx[6]
      ),
      size: (
        /*size*/
        ctx[5]
      ),
      color: (
        /*ratingColour*/
        ctx[14]
      ),
      weight: (
        /*isRated*/
        ctx[16](
          /*hoverRating*/
          ctx[9],
          /*i*/
          ctx[33]
        ) || /*isRated*/
        ctx[16](
          /*fieldState*/
          (_a = ctx[8]) == null ? void 0 : _a.value,
          /*i*/
          ctx[33]
        ) ? "fill" : "regular"
      )
    }
  });
  function mouseover_handler() {
    return (
      /*mouseover_handler*/
      ctx[20](
        /*i*/
        ctx[33]
      )
    );
  }
  function focus_handler() {
    return (
      /*focus_handler*/
      ctx[22](
        /*i*/
        ctx[33]
      )
    );
  }
  function keydown_handler(...args) {
    return (
      /*keydown_handler*/
      ctx[24](
        /*i*/
        ctx[33],
        ...args
      )
    );
  }
  function click_handler() {
    return (
      /*click_handler*/
      ctx[25](
        /*i*/
        ctx[33]
      )
    );
  }
  return {
    c() {
      var _a2, _b;
      button = element("button");
      div = element("div");
      create_component(icon.$$.fragment);
      t = space();
      attr(div, "class", "icon-container svelte-1sxxz0v");
      toggle_class(
        div,
        "hover-preview",
        /*isRated*/
        ctx[16](
          /*hoverRating*/
          ctx[9],
          /*i*/
          ctx[33]
        ) && !/*isRated*/
        ctx[16](
          /*fieldState*/
          (_a2 = ctx[8]) == null ? void 0 : _a2.value,
          /*i*/
          ctx[33]
        )
      );
      attr(button, "type", "button");
      attr(button, "class", "rating-icon-wrapper svelte-1sxxz0v");
      set_style(button, "padding", "0 " + /*spacing*/
      ctx[13] + "px");
      toggle_class(
        button,
        "disabled",
        /*fieldState*/
        (_b = ctx[8]) == null ? void 0 : _b.disabled
      );
    },
    m(target, anchor) {
      insert(target, button, anchor);
      append(button, div);
      mount_component(icon, div, null);
      append(button, t);
      current = true;
      if (!mounted) {
        dispose = [
          listen(button, "mouseover", function() {
            if (is_function(
              /*enabled*/
              ctx[12] ? mouseover_handler : null
            ))
              /*enabled*/
              (ctx[12] ? mouseover_handler : null).apply(this, arguments);
          }),
          listen(button, "mouseleave", function() {
            if (is_function(
              /*enabled*/
              ctx[12] ? (
                /*mouseleave_handler*/
                ctx[21]
              ) : null
            ))
              /*enabled*/
              (ctx[12] ? (
                /*mouseleave_handler*/
                ctx[21]
              ) : null).apply(this, arguments);
          }),
          listen(button, "focus", function() {
            if (is_function(
              /*enabled*/
              ctx[12] ? focus_handler : null
            ))
              /*enabled*/
              (ctx[12] ? focus_handler : null).apply(this, arguments);
          }),
          listen(button, "blur", function() {
            if (is_function(
              /*enabled*/
              ctx[12] ? (
                /*blur_handler*/
                ctx[23]
              ) : null
            ))
              /*enabled*/
              (ctx[12] ? (
                /*blur_handler*/
                ctx[23]
              ) : null).apply(this, arguments);
          }),
          listen(button, "keydown", keydown_handler),
          listen(button, "click", click_handler)
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      var _a2, _b, _c;
      ctx = new_ctx;
      const icon_changes = {};
      if (dirty[0] & /*type*/
      64)
        icon_changes.name = /*type*/
        ctx[6];
      if (dirty[0] & /*size*/
      32)
        icon_changes.size = /*size*/
        ctx[5];
      if (dirty[0] & /*ratingColour*/
      16384)
        icon_changes.color = /*ratingColour*/
        ctx[14];
      if (dirty[0] & /*hoverRating, fieldState*/
      768)
        icon_changes.weight = /*isRated*/
        ctx[16](
          /*hoverRating*/
          ctx[9],
          /*i*/
          ctx[33]
        ) || /*isRated*/
        ctx[16](
          /*fieldState*/
          (_a2 = ctx[8]) == null ? void 0 : _a2.value,
          /*i*/
          ctx[33]
        ) ? "fill" : "regular";
      icon.$set(icon_changes);
      if (!current || dirty[0] & /*isRated, hoverRating, fieldState*/
      66304) {
        toggle_class(
          div,
          "hover-preview",
          /*isRated*/
          ctx[16](
            /*hoverRating*/
            ctx[9],
            /*i*/
            ctx[33]
          ) && !/*isRated*/
          ctx[16](
            /*fieldState*/
            (_b = ctx[8]) == null ? void 0 : _b.value,
            /*i*/
            ctx[33]
          )
        );
      }
      if (!current || dirty[0] & /*spacing*/
      8192) {
        set_style(button, "padding", "0 " + /*spacing*/
        ctx[13] + "px");
      }
      if (!current || dirty[0] & /*fieldState*/
      256) {
        toggle_class(
          button,
          "disabled",
          /*fieldState*/
          (_c = ctx[8]) == null ? void 0 : _c.disabled
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      destroy_component(icon);
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_default_slot(ctx) {
  let div;
  let current;
  let each_value = ensure_array_like({ length: (
    /*numberOfStars*/
    ctx[4]
  ) });
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "rating-container svelte-1sxxz0v");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*spacing, fieldState, enabled, hoverRating, handleClick, isRated, type, size, ratingColour, numberOfStars*/
      127856) {
        each_value = ensure_array_like({ length: (
          /*numberOfStars*/
          ctx2[4]
        ) });
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div, null);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_fragment(ctx) {
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let updating_fieldSchema;
  let current;
  function field_1_fieldState_binding(value) {
    ctx[26](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[27](value);
  }
  function field_1_fieldSchema_binding(value) {
    ctx[28](value);
  }
  let field_1_props = {
    label: (
      /*label*/
      ctx[3]
    ),
    field: (
      /*field*/
      ctx[2]
    ),
    disabled: (
      /*disabled*/
      ctx[0]
    ),
    readonly: (
      /*readonly*/
      ctx[1]
    ),
    validation: (
      /*validation*/
      ctx[7]
    ),
    type: FieldType.NUMBER,
    defaultValue: "0",
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*fieldState*/
    ctx[8] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[8];
  }
  if (
    /*fieldApi*/
    ctx[10] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[10];
  }
  if (
    /*fieldSchema*/
    ctx[11] !== void 0
  ) {
    field_1_props.fieldSchema = /*fieldSchema*/
    ctx[11];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  binding_callbacks.push(() => bind(field_1, "fieldSchema", field_1_fieldSchema_binding));
  return {
    c() {
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const field_1_changes = {};
      if (dirty[0] & /*label*/
      8)
        field_1_changes.label = /*label*/
        ctx2[3];
      if (dirty[0] & /*field*/
      4)
        field_1_changes.field = /*field*/
        ctx2[2];
      if (dirty[0] & /*disabled*/
      1)
        field_1_changes.disabled = /*disabled*/
        ctx2[0];
      if (dirty[0] & /*readonly*/
      2)
        field_1_changes.readonly = /*readonly*/
        ctx2[1];
      if (dirty[0] & /*validation*/
      128)
        field_1_changes.validation = /*validation*/
        ctx2[7];
      if (dirty[0] & /*numberOfStars, spacing, fieldState, enabled, hoverRating, type, size, ratingColour*/
      29552 | dirty[1] & /*$$scope*/
      8) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty[0] & /*fieldState*/
      256) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[8];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty[0] & /*fieldApi*/
      1024) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[10];
        add_flush_callback(() => updating_fieldApi = false);
      }
      if (!updating_fieldSchema && dirty[0] & /*fieldSchema*/
      2048) {
        updating_fieldSchema = true;
        field_1_changes.fieldSchema = /*fieldSchema*/
        ctx2[11];
        add_flush_callback(() => updating_fieldSchema = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field_1, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let ratingColour;
  let spacing;
  let enabled;
  let { colour = "" } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { field } = $$props;
  let { label } = $$props;
  let { numberOfStars = 5 } = $$props;
  let { size = "L" } = $$props;
  let { type = "star" } = $$props;
  let { variant = "Primary" } = $$props;
  let { validation } = $$props;
  let { onChange } = $$props;
  let hoverRating = null;
  let fieldState;
  let fieldApi;
  let fieldSchema;
  const colourVariants = {
    Primary: "var(--primaryColor)",
    Secondary: "var(--primaryColorHover)",
    Mono: "var(--spectrum-global-color-gray-900)",
    Gold: "var(--spectrum-global-color-yellow-500)",
    Red: "var(--spectrum-global-color-red-500)",
    Custom: "var(--primaryColor)"
  };
  const sizeSpacing = { XS: 0.25, S: 0.5, M: 1, L: 1.5, XL: 2 };
  const handleClick = (value) => {
    if (enabled) {
      const changed = fieldApi == null ? void 0 : fieldApi.setValue(value);
      if (onChange && changed) {
        onChange({ value });
      }
    }
  };
  const isRated = (value, index) => {
    return typeof value === "number" && value >= index + 1;
  };
  const mouseover_handler = (i) => $$invalidate(9, hoverRating = i + 1);
  const mouseleave_handler = () => $$invalidate(9, hoverRating = null);
  const focus_handler = (i) => $$invalidate(9, hoverRating = i + 1);
  const blur_handler = () => $$invalidate(9, hoverRating = null);
  const keydown_handler = (i, e) => enabled && e.key === "Enter" && handleClick(i + 1);
  const click_handler = (i) => handleClick(i + 1);
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(8, fieldState);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(10, fieldApi);
  }
  function field_1_fieldSchema_binding(value) {
    fieldSchema = value;
    $$invalidate(11, fieldSchema);
  }
  $$self.$$set = ($$props2) => {
    if ("colour" in $$props2)
      $$invalidate(17, colour = $$props2.colour);
    if ("disabled" in $$props2)
      $$invalidate(0, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(1, readonly = $$props2.readonly);
    if ("field" in $$props2)
      $$invalidate(2, field = $$props2.field);
    if ("label" in $$props2)
      $$invalidate(3, label = $$props2.label);
    if ("numberOfStars" in $$props2)
      $$invalidate(4, numberOfStars = $$props2.numberOfStars);
    if ("size" in $$props2)
      $$invalidate(5, size = $$props2.size);
    if ("type" in $$props2)
      $$invalidate(6, type = $$props2.type);
    if ("variant" in $$props2)
      $$invalidate(18, variant = $$props2.variant);
    if ("validation" in $$props2)
      $$invalidate(7, validation = $$props2.validation);
    if ("onChange" in $$props2)
      $$invalidate(19, onChange = $$props2.onChange);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*variant, colour*/
    393216) {
      $$invalidate(14, ratingColour = variant === "Custom" && colour ? colour : colourVariants[variant] || "var(--primaryColor)");
    }
    if ($$self.$$.dirty[0] & /*size*/
    32) {
      $$invalidate(13, spacing = sizeSpacing[size] || sizeSpacing.M);
    }
    if ($$self.$$.dirty[0] & /*fieldState*/
    256) {
      $$invalidate(12, enabled = !(fieldState == null ? void 0 : fieldState.disabled) && !(fieldState == null ? void 0 : fieldState.readonly));
    }
  };
  return [
    disabled,
    readonly,
    field,
    label,
    numberOfStars,
    size,
    type,
    validation,
    fieldState,
    hoverRating,
    fieldApi,
    fieldSchema,
    enabled,
    spacing,
    ratingColour,
    handleClick,
    isRated,
    colour,
    variant,
    onChange,
    mouseover_handler,
    mouseleave_handler,
    focus_handler,
    blur_handler,
    keydown_handler,
    click_handler,
    field_1_fieldState_binding,
    field_1_fieldApi_binding,
    field_1_fieldSchema_binding
  ];
}
class RatingField extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        colour: 17,
        disabled: 0,
        readonly: 1,
        field: 2,
        label: 3,
        numberOfStars: 4,
        size: 5,
        type: 6,
        variant: 18,
        validation: 7,
        onChange: 19
      },
      null,
      [-1, -1]
    );
  }
}
export {
  RatingField as default
};
