const getOptions = (optionsSource, fieldSchema, dataProvider, labelColumn, valueColumn, customOptions) => {
  var _a, _b;
  if (optionsSource == null || optionsSource === "schema") {
    return ((_a = fieldSchema == null ? void 0 : fieldSchema.constraints) == null ? void 0 : _a.inclusion) ?? [];
  }
  if (optionsSource === "provider" && valueColumn) {
    let valueCache = {};
    let options = [];
    (_b = dataProvider == null ? void 0 : dataProvider.rows) == null ? void 0 : _b.forEach((row) => {
      const value = row == null ? void 0 : row[valueColumn];
      if (value != null && !valueCache[value]) {
        valueCache[value] = true;
        const label = row[labelColumn] || value;
        options.push({ value, label });
      }
    });
    return options;
  }
  if (optionsSource === "custom" && customOptions) {
    customOptions.forEach((option) => {
      if (typeof option.value === "string") {
        if (option.value.toLowerCase() === "true") {
          option.value = true;
        } else if (option.value.toLowerCase() === "false") {
          option.value = false;
        }
      }
    });
    return customOptions;
  }
  return [];
};
export {
  getOptions as g
};
