import { S as SvelteComponent, i as init, s as safe_not_equal, F as create_slot, e as element, b as attr, f as insert, g as append, q as action_destroyer, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, h as is_function, k as transition_in, n as transition_out, o as detach, u as getContext, v as component_subscribe } from "./index-8b9900f1.js";
const BackgroundImage_svelte_svelte_type_style_lang = "";
function create_fragment(ctx) {
  let div1;
  let div0;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[7].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[6],
    null
  );
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      if (default_slot)
        default_slot.c();
      attr(div0, "class", "inner svelte-1ovy8gu");
      attr(
        div0,
        "style",
        /*style*/
        ctx[0]
      );
      attr(div1, "class", "outer svelte-1ovy8gu");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      if (default_slot) {
        default_slot.m(div0, null);
      }
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[2].call(
          null,
          div1,
          /*$component*/
          ctx[1].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        64)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[6],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[6]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[6],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*style*/
      1) {
        attr(
          div0,
          "style",
          /*style*/
          ctx2[0]
        );
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      2)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[1].styles
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $component;
  let { $$slots: slots = {}, $$scope } = $$props;
  const { styleable } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(1, $component = value));
  let { url } = $$props;
  let { position } = $$props;
  let style = "";
  $$self.$$set = ($$props2) => {
    if ("url" in $$props2)
      $$invalidate(4, url = $$props2.url);
    if ("position" in $$props2)
      $$invalidate(5, position = $$props2.position);
    if ("$$scope" in $$props2)
      $$invalidate(6, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*url, style, position*/
    49) {
      {
        if (url) {
          $$invalidate(0, style += `background-image: url("${url}");`);
        }
        if (position) {
          $$invalidate(0, style += `background-position: ${position};`);
        }
      }
    }
  };
  return [style, $component, styleable, component, url, position, $$scope, slots];
}
class BackgroundImage extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { url: 4, position: 5 });
  }
}
export {
  BackgroundImage as default
};
