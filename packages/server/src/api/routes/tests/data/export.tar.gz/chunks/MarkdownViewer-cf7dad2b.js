import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, f as insert, q as action_destroyer, z as group_outros, n as transition_out, A as check_outros, k as transition_in, h as is_function, o as detach, u as getContext, v as component_subscribe, c as create_component, m as mount_component, B as noop, p as destroy_component } from "./index-8b9900f1.js";
import { M as MarkdownViewer } from "./MarkdownViewer-04a414fe.js";
import Placeholder from "./Placeholder-4dedd9c4.js";
function create_if_block_1(ctx) {
  let placeholder;
  let current;
  placeholder = new Placeholder({});
  return {
    c() {
      create_component(placeholder.$$.fragment);
    },
    m(target, anchor) {
      mount_component(placeholder, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(placeholder.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(placeholder.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(placeholder, detaching);
    }
  };
}
function create_if_block(ctx) {
  let markdownviewer;
  let current;
  markdownviewer = new MarkdownViewer({
    props: {
      value: (
        /*value*/
        ctx[0]
      ),
      height: (
        /*height*/
        ctx[6]
      )
    }
  });
  return {
    c() {
      create_component(markdownviewer.$$.fragment);
    },
    m(target, anchor) {
      mount_component(markdownviewer, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const markdownviewer_changes = {};
      if (dirty & /*value*/
      1)
        markdownviewer_changes.value = /*value*/
        ctx2[0];
      markdownviewer.$set(markdownviewer_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(markdownviewer.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(markdownviewer.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(markdownviewer, detaching);
    }
  };
}
function create_fragment(ctx) {
  let div;
  let current_block_type_index;
  let if_block;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  const if_block_creators = [create_if_block, create_if_block_1];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*value*/
      ctx2[0]
    )
      return 0;
    if (
      /*$builderStore*/
      ctx2[2].inBuilder
    )
      return 1;
    return -1;
  }
  if (~(current_block_type_index = select_block_type(ctx))) {
    if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  }
  return {
    c() {
      div = element("div");
      if (if_block)
        if_block.c();
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].m(div, null);
      }
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[5].call(
          null,
          div,
          /*$component*/
          ctx[1].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if (~current_block_type_index) {
          if_blocks[current_block_type_index].p(ctx2, dirty);
        }
      } else {
        if (if_block) {
          group_outros();
          transition_out(if_blocks[previous_block_index], 1, 1, () => {
            if_blocks[previous_block_index] = null;
          });
          check_outros();
        }
        if (~current_block_type_index) {
          if_block = if_blocks[current_block_type_index];
          if (!if_block) {
            if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
            if_block.c();
          } else {
            if_block.p(ctx2, dirty);
          }
          transition_in(if_block, 1);
          if_block.m(div, null);
        } else {
          if_block = null;
        }
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      2)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[1].styles
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].d();
      }
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  var _a, _b;
  let $component;
  let $builderStore;
  let { value } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value2) => $$invalidate(1, $component = value2));
  const { builderStore, styleable } = getContext("sdk");
  component_subscribe($$self, builderStore, (value2) => $$invalidate(2, $builderStore = value2));
  const height = (_b = (_a = $component.styles) == null ? void 0 : _a.normal) == null ? void 0 : _b.height;
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
  };
  return [value, $component, $builderStore, component, builderStore, styleable, height];
}
class MarkdownViewer_1 extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { value: 0 });
  }
}
export {
  MarkdownViewer_1 as default
};
