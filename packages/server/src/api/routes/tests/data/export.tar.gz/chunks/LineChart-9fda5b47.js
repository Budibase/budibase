import { S as SvelteComponent, i as init, s as safe_not_equal, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component } from "./index-8b9900f1.js";
import { A as ApexChart, p as parsePalette, f as formatters } from "./ApexChart-5b4a3d9d.js";
function create_fragment(ctx) {
  let apexchart;
  let current;
  apexchart = new ApexChart({ props: { options: (
    /*options*/
    ctx[0]
  ) } });
  return {
    c() {
      create_component(apexchart.$$.fragment);
    },
    m(target, anchor) {
      mount_component(apexchart, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const apexchart_changes = {};
      if (dirty & /*options*/
      1)
        apexchart_changes.options = /*options*/
        ctx2[0];
      apexchart.$set(apexchart_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(apexchart.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(apexchart.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(apexchart, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let series;
  let categories;
  let labelType;
  let xAxisFormatter;
  let yAxisFormatter;
  let options;
  let { title } = $$props;
  let { dataProvider } = $$props;
  let { labelColumn } = $$props;
  let { valueColumns } = $$props;
  let { xAxisLabel } = $$props;
  let { yAxisLabel } = $$props;
  let { height } = $$props;
  let { width } = $$props;
  let { animate } = $$props;
  let { dataLabels } = $$props;
  let { curve } = $$props;
  let { legend } = $$props;
  let { yAxisUnits } = $$props;
  let { palette } = $$props;
  let { c1, c2, c3, c4, c5 } = $$props;
  let { onClick } = $$props;
  function handleLineClick(marker) {
    onClick == null ? void 0 : onClick({ marker });
  }
  const getSeries = (dataProvider2, valueColumns2 = []) => {
    const rows = dataProvider2.rows ?? [];
    return valueColumns2.map((column) => ({
      name: column,
      data: rows.map((row) => {
        var _a, _b;
        const value = row == null ? void 0 : row[column];
        if (((_b = (_a = dataProvider2 == null ? void 0 : dataProvider2.schema) == null ? void 0 : _a[column]) == null ? void 0 : _b.type) === "datetime" && value) {
          return Date.parse(value);
        }
        return value;
      })
    }));
  };
  const getCategories = (dataProvider2, labelColumn2) => {
    const rows = dataProvider2.rows ?? [];
    return rows.map((row) => {
      const value = row == null ? void 0 : row[labelColumn2];
      if (!["string", "number", "boolean"].includes(typeof value)) {
        return "";
      }
      return value;
    });
  };
  const getFormatter = (labelType2, yAxisUnits2, axis) => {
    const isLabelAxis = axis === "x";
    if (labelType2 === "datetime" && isLabelAxis) {
      return formatters["Datetime"];
    }
    if (isLabelAxis) {
      return formatters["Default"];
    }
    return formatters[yAxisUnits2];
  };
  $$self.$$set = ($$props2) => {
    if ("title" in $$props2)
      $$invalidate(1, title = $$props2.title);
    if ("dataProvider" in $$props2)
      $$invalidate(2, dataProvider = $$props2.dataProvider);
    if ("labelColumn" in $$props2)
      $$invalidate(3, labelColumn = $$props2.labelColumn);
    if ("valueColumns" in $$props2)
      $$invalidate(4, valueColumns = $$props2.valueColumns);
    if ("xAxisLabel" in $$props2)
      $$invalidate(5, xAxisLabel = $$props2.xAxisLabel);
    if ("yAxisLabel" in $$props2)
      $$invalidate(6, yAxisLabel = $$props2.yAxisLabel);
    if ("height" in $$props2)
      $$invalidate(7, height = $$props2.height);
    if ("width" in $$props2)
      $$invalidate(8, width = $$props2.width);
    if ("animate" in $$props2)
      $$invalidate(9, animate = $$props2.animate);
    if ("dataLabels" in $$props2)
      $$invalidate(10, dataLabels = $$props2.dataLabels);
    if ("curve" in $$props2)
      $$invalidate(11, curve = $$props2.curve);
    if ("legend" in $$props2)
      $$invalidate(12, legend = $$props2.legend);
    if ("yAxisUnits" in $$props2)
      $$invalidate(13, yAxisUnits = $$props2.yAxisUnits);
    if ("palette" in $$props2)
      $$invalidate(14, palette = $$props2.palette);
    if ("c1" in $$props2)
      $$invalidate(15, c1 = $$props2.c1);
    if ("c2" in $$props2)
      $$invalidate(16, c2 = $$props2.c2);
    if ("c3" in $$props2)
      $$invalidate(17, c3 = $$props2.c3);
    if ("c4" in $$props2)
      $$invalidate(18, c4 = $$props2.c4);
    if ("c5" in $$props2)
      $$invalidate(19, c5 = $$props2.c5);
    if ("onClick" in $$props2)
      $$invalidate(20, onClick = $$props2.onClick);
  };
  $$self.$$.update = () => {
    var _a, _b;
    if ($$self.$$.dirty & /*dataProvider, valueColumns*/
    20) {
      $$invalidate(24, series = getSeries(dataProvider, valueColumns));
    }
    if ($$self.$$.dirty & /*dataProvider, labelColumn*/
    12) {
      $$invalidate(23, categories = getCategories(dataProvider, labelColumn));
    }
    if ($$self.$$.dirty & /*dataProvider, labelColumn*/
    12) {
      $$invalidate(25, labelType = ((_b = (_a = dataProvider == null ? void 0 : dataProvider.schema) == null ? void 0 : _a[labelColumn]) == null ? void 0 : _b.type) === "datetime" ? "datetime" : "category");
    }
    if ($$self.$$.dirty & /*labelType, yAxisUnits*/
    33562624) {
      $$invalidate(22, xAxisFormatter = getFormatter(labelType, yAxisUnits, "x"));
    }
    if ($$self.$$.dirty & /*labelType, yAxisUnits*/
    33562624) {
      $$invalidate(21, yAxisFormatter = getFormatter(labelType, yAxisUnits, "y"));
    }
    if ($$self.$$.dirty & /*series, curve, palette, c1, c2, c3, c4, c5, legend, title, dataLabels, height, width, animate, dataProvider, categories, xAxisFormatter, xAxisLabel, yAxisFormatter, yAxisLabel*/
    32497638) {
      $$invalidate(0, options = {
        series,
        stroke: { curve: curve.toLowerCase() },
        colors: palette === "Custom" ? [c1, c2, c3, c4, c5] : [],
        theme: { palette: parsePalette(palette) },
        legend: {
          show: legend,
          position: "top",
          horizontalAlign: "right",
          showForSingleSeries: true,
          showForNullSeries: true,
          showForZeroSeries: true
        },
        title: { text: title },
        dataLabels: { enabled: dataLabels },
        chart: {
          height: height == null || height === "" ? "auto" : height,
          width: width == null || width === "" ? "100%" : width,
          type: "line",
          animations: { enabled: animate },
          toolbar: { show: false },
          zoom: { enabled: false },
          events: {
            // Clicking on a line
            markerClick(event, chartContext, opts) {
              const dataPointIndex = opts.dataPointIndex;
              const row = dataProvider.rows[dataPointIndex];
              handleLineClick(row);
            }
          }
        },
        xaxis: {
          categories,
          labels: { formatter: xAxisFormatter },
          title: { text: xAxisLabel }
        },
        yaxis: {
          labels: { formatter: yAxisFormatter },
          title: { text: yAxisLabel }
        }
      });
    }
  };
  return [
    options,
    title,
    dataProvider,
    labelColumn,
    valueColumns,
    xAxisLabel,
    yAxisLabel,
    height,
    width,
    animate,
    dataLabels,
    curve,
    legend,
    yAxisUnits,
    palette,
    c1,
    c2,
    c3,
    c4,
    c5,
    onClick,
    yAxisFormatter,
    xAxisFormatter,
    categories,
    series,
    labelType
  ];
}
class LineChart extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      title: 1,
      dataProvider: 2,
      labelColumn: 3,
      valueColumns: 4,
      xAxisLabel: 5,
      yAxisLabel: 6,
      height: 7,
      width: 8,
      animate: 9,
      dataLabels: 10,
      curve: 11,
      legend: 12,
      yAxisUnits: 13,
      palette: 14,
      c1: 15,
      c2: 16,
      c3: 17,
      c4: 18,
      c5: 19,
      onClick: 20
    });
  }
}
export {
  LineChart as default
};
