import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, b as attr, d as toggle_class, f as insert, q as action_destroyer, z as group_outros, n as transition_out, B as noop, A as check_outros, k as transition_in, h as is_function, o as detach, r as run_all, u as getContext, v as component_subscribe, F as create_slot, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes } from "./index-8b9900f1.js";
const SidePanel_svelte_svelte_type_style_lang = "";
function create_key_block(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[15].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[14],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        16384)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[14],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[14]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[14],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let div;
  let previous_key = (
    /*renderKey*/
    ctx[2]
  );
  let styleable_action;
  let showInSidePanel_action;
  let current;
  let mounted;
  let dispose;
  let key_block = create_key_block(ctx);
  return {
    c() {
      div = element("div");
      key_block.c();
      attr(div, "class", "side-panel svelte-l1y86g");
      toggle_class(
        div,
        "open",
        /*open*/
        ctx[0]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      key_block.m(div, null);
      current = true;
      if (!mounted) {
        dispose = [
          action_destroyer(styleable_action = /*styleable*/
          ctx[4].call(
            null,
            div,
            /*$component*/
            ctx[1].styles
          )),
          action_destroyer(showInSidePanel_action = /*showInSidePanel*/
          ctx[8].call(
            null,
            div,
            /*open*/
            ctx[0]
          ))
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & /*renderKey*/
      4 && safe_not_equal(previous_key, previous_key = /*renderKey*/
      ctx2[2])) {
        group_outros();
        transition_out(key_block, 1, 1, noop);
        check_outros();
        key_block = create_key_block(ctx2);
        key_block.c();
        transition_in(key_block, 1);
        key_block.m(div, null);
      } else {
        key_block.p(ctx2, dirty);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      2)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[1].styles
        );
      if (showInSidePanel_action && is_function(showInSidePanel_action.update) && dirty & /*open*/
      1)
        showInSidePanel_action.update.call(
          null,
          /*open*/
          ctx2[0]
        );
      if (!current || dirty & /*open*/
      1) {
        toggle_class(
          div,
          "open",
          /*open*/
          ctx2[0]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(key_block);
      current = true;
    },
    o(local) {
      transition_out(key_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      key_block.d(detaching);
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let open;
  let $component;
  let $sidePanelStore;
  let $dndIsDragging;
  let $builderStore;
  let { $$slots: slots = {}, $$scope } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(1, $component = value));
  const { styleable, sidePanelStore, builderStore, dndIsDragging } = getContext("sdk");
  component_subscribe($$self, sidePanelStore, (value) => $$invalidate(11, $sidePanelStore = value));
  component_subscribe($$self, builderStore, (value) => $$invalidate(13, $builderStore = value));
  component_subscribe($$self, dndIsDragging, (value) => $$invalidate(12, $dndIsDragging = value));
  let { onClose } = $$props;
  let { ignoreClicksOutside } = $$props;
  let renderKey = null;
  const handleSidePanelClose = async () => {
    if (onClose) {
      await onClose();
    }
  };
  const showInSidePanel = (el, visible) => {
    const update = (visible2) => {
      const target = document.getElementById("side-panel-container");
      const node = el;
      if (visible2) {
        if (!target.contains(node)) {
          target.appendChild(node);
        }
      } else {
        if (target.contains(node)) {
          target.removeChild(node);
          handleSidePanelClose();
        }
      }
    };
    update(visible);
    return { update, destroy: () => update(false) };
  };
  $$self.$$set = ($$props2) => {
    if ("onClose" in $$props2)
      $$invalidate(9, onClose = $$props2.onClose);
    if ("ignoreClicksOutside" in $$props2)
      $$invalidate(10, ignoreClicksOutside = $$props2.ignoreClicksOutside);
    if ("$$scope" in $$props2)
      $$invalidate(14, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$builderStore, $component, $sidePanelStore, $dndIsDragging*/
    14338) {
      {
        if ($builderStore.inBuilder) {
          if ($component.inSelectedPath && $sidePanelStore.contentId !== $component.id) {
            sidePanelStore.actions.open($component.id);
          } else if (!$component.inSelectedPath && $sidePanelStore.contentId === $component.id && !$dndIsDragging) {
            sidePanelStore.actions.close();
          }
        }
      }
    }
    if ($$self.$$.dirty & /*$sidePanelStore, $component*/
    2050) {
      $$invalidate(0, open = $sidePanelStore.contentId === $component.id);
    }
    if ($$self.$$.dirty & /*open, ignoreClicksOutside*/
    1025) {
      {
        if (open) {
          sidePanelStore.actions.setIgnoreClicksOutside(ignoreClicksOutside);
          $$invalidate(2, renderKey = Math.random());
        }
      }
    }
  };
  return [
    open,
    $component,
    renderKey,
    component,
    styleable,
    sidePanelStore,
    builderStore,
    dndIsDragging,
    showInSidePanel,
    onClose,
    ignoreClicksOutside,
    $sidePanelStore,
    $dndIsDragging,
    $builderStore,
    $$scope,
    slots
  ];
}
class SidePanel extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { onClose: 9, ignoreClicksOutside: 10 });
  }
}
export {
  SidePanel as default
};
