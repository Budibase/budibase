import { S as SvelteComponent, i as init, s as safe_not_equal, W as binding_callbacks, a0 as bind, c as create_component, m as mount_component, a1 as add_flush_callback, k as transition_in, n as transition_out, p as destroy_component, y as empty, f as insert, z as group_outros, A as check_outros, o as detach, c6 as TextField, h as is_function } from "./index-8b9900f1.js";
import { F as Field } from "./Field-a0270b82.js";
import "./Placeholder-4dedd9c4.js";
import "./InnerForm-0042fa8f.js";
function create_if_block(ctx) {
  let coretextfield;
  let current;
  coretextfield = new TextField({
    props: {
      updateOnChange: false,
      value: (
        /*fieldState*/
        ctx[12].value
      ),
      disabled: (
        /*fieldState*/
        ctx[12].disabled
      ),
      readonly: (
        /*fieldState*/
        ctx[12].readonly
      ),
      id: (
        /*fieldState*/
        ctx[12].fieldId
      ),
      placeholder: (
        /*placeholder*/
        ctx[2]
      ),
      type: (
        /*type*/
        ctx[3]
      ),
      align: (
        /*align*/
        ctx[8]
      )
    }
  });
  coretextfield.$on(
    "change",
    /*handleChange*/
    ctx[14]
  );
  coretextfield.$on("input", function() {
    if (is_function(
      /*runOnInput*/
      ctx[9] ? (
        /*handleInput*/
        ctx[15]
      ) : void 0
    ))
      /*runOnInput*/
      (ctx[9] ? (
        /*handleInput*/
        ctx[15]
      ) : void 0).apply(this, arguments);
  });
  return {
    c() {
      create_component(coretextfield.$$.fragment);
    },
    m(target, anchor) {
      mount_component(coretextfield, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const coretextfield_changes = {};
      if (dirty & /*fieldState*/
      4096)
        coretextfield_changes.value = /*fieldState*/
        ctx[12].value;
      if (dirty & /*fieldState*/
      4096)
        coretextfield_changes.disabled = /*fieldState*/
        ctx[12].disabled;
      if (dirty & /*fieldState*/
      4096)
        coretextfield_changes.readonly = /*fieldState*/
        ctx[12].readonly;
      if (dirty & /*fieldState*/
      4096)
        coretextfield_changes.id = /*fieldState*/
        ctx[12].fieldId;
      if (dirty & /*placeholder*/
      4)
        coretextfield_changes.placeholder = /*placeholder*/
        ctx[2];
      if (dirty & /*type*/
      8)
        coretextfield_changes.type = /*type*/
        ctx[3];
      if (dirty & /*align*/
      256)
        coretextfield_changes.align = /*align*/
        ctx[8];
      coretextfield.$set(coretextfield_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(coretextfield.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(coretextfield.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(coretextfield, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*fieldState*/
    ctx[12] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*fieldState*/
        ctx2[12]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*fieldState*/
          4096) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let current;
  function field_1_fieldState_binding(value) {
    ctx[17](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[18](value);
  }
  let field_1_props = {
    label: (
      /*label*/
      ctx[1]
    ),
    field: (
      /*field*/
      ctx[0]
    ),
    disabled: (
      /*disabled*/
      ctx[4]
    ),
    readonly: (
      /*readonly*/
      ctx[5]
    ),
    validation: (
      /*validation*/
      ctx[6]
    ),
    defaultValue: (
      /*defaultValue*/
      ctx[7]
    ),
    span: (
      /*span*/
      ctx[10]
    ),
    helpText: (
      /*helpText*/
      ctx[11]
    ),
    type: (
      /*type*/
      ctx[3] === "number" ? "number" : "string"
    ),
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*fieldState*/
    ctx[12] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[12];
  }
  if (
    /*fieldApi*/
    ctx[13] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[13];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  return {
    c() {
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const field_1_changes = {};
      if (dirty & /*label*/
      2)
        field_1_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*field*/
      1)
        field_1_changes.field = /*field*/
        ctx2[0];
      if (dirty & /*disabled*/
      16)
        field_1_changes.disabled = /*disabled*/
        ctx2[4];
      if (dirty & /*readonly*/
      32)
        field_1_changes.readonly = /*readonly*/
        ctx2[5];
      if (dirty & /*validation*/
      64)
        field_1_changes.validation = /*validation*/
        ctx2[6];
      if (dirty & /*defaultValue*/
      128)
        field_1_changes.defaultValue = /*defaultValue*/
        ctx2[7];
      if (dirty & /*span*/
      1024)
        field_1_changes.span = /*span*/
        ctx2[10];
      if (dirty & /*helpText*/
      2048)
        field_1_changes.helpText = /*helpText*/
        ctx2[11];
      if (dirty & /*type*/
      8)
        field_1_changes.type = /*type*/
        ctx2[3] === "number" ? "number" : "string";
      if (dirty & /*$$scope, fieldState, placeholder, type, align, runOnInput*/
      529164) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty & /*fieldState*/
      4096) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[12];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty & /*fieldApi*/
      8192) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[13];
        add_flush_callback(() => updating_fieldApi = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field_1, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { field } = $$props;
  let { label } = $$props;
  let { placeholder } = $$props;
  let { type = "text" } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { validation } = $$props;
  let { defaultValue = "" } = $$props;
  let { align } = $$props;
  let { onChange } = $$props;
  let { runOnInput = false } = $$props;
  let { span } = $$props;
  let { helpText = null } = $$props;
  let fieldState;
  let fieldApi;
  const handleChange = (e) => {
    const changed = fieldApi.setValue(e.detail);
    if (changed) {
      onChange == null ? void 0 : onChange({ value: e.detail });
    }
  };
  const handleInput = (e) => {
    onChange == null ? void 0 : onChange({ value: e.target.value });
  };
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(12, fieldState);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(13, fieldApi);
  }
  $$self.$$set = ($$props2) => {
    if ("field" in $$props2)
      $$invalidate(0, field = $$props2.field);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("placeholder" in $$props2)
      $$invalidate(2, placeholder = $$props2.placeholder);
    if ("type" in $$props2)
      $$invalidate(3, type = $$props2.type);
    if ("disabled" in $$props2)
      $$invalidate(4, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(5, readonly = $$props2.readonly);
    if ("validation" in $$props2)
      $$invalidate(6, validation = $$props2.validation);
    if ("defaultValue" in $$props2)
      $$invalidate(7, defaultValue = $$props2.defaultValue);
    if ("align" in $$props2)
      $$invalidate(8, align = $$props2.align);
    if ("onChange" in $$props2)
      $$invalidate(16, onChange = $$props2.onChange);
    if ("runOnInput" in $$props2)
      $$invalidate(9, runOnInput = $$props2.runOnInput);
    if ("span" in $$props2)
      $$invalidate(10, span = $$props2.span);
    if ("helpText" in $$props2)
      $$invalidate(11, helpText = $$props2.helpText);
  };
  return [
    field,
    label,
    placeholder,
    type,
    disabled,
    readonly,
    validation,
    defaultValue,
    align,
    runOnInput,
    span,
    helpText,
    fieldState,
    fieldApi,
    handleChange,
    handleInput,
    onChange,
    field_1_fieldState_binding,
    field_1_fieldApi_binding
  ];
}
class StringField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      field: 0,
      label: 1,
      placeholder: 2,
      type: 3,
      disabled: 4,
      readonly: 5,
      validation: 6,
      defaultValue: 7,
      align: 8,
      onChange: 16,
      runOnInput: 9,
      span: 10,
      helpText: 11
    });
  }
}
export {
  StringField as default
};
