import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, b as attr, d as toggle_class, f as insert, g as append, q as action_destroyer, z as group_outros, n as transition_out, A as check_outros, k as transition_in, h as is_function, o as detach, u as getContext, v as component_subscribe, X as setContext, F as create_slot, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, c as create_component, m as mount_component, p as destroy_component } from "./index-8b9900f1.js";
import Section from "./Section-52788705.js";
import "./Placeholder-4dedd9c4.js";
const FieldGroup_svelte_svelte_type_style_lang = "";
function create_else_block(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[5].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[6],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        64)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[6],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[6]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[6],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_if_block(ctx) {
  let section;
  let current;
  section = new Section({
    props: {
      type: (
        /*type*/
        ctx[1]
      ),
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(section.$$.fragment);
    },
    m(target, anchor) {
      mount_component(section, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const section_changes = {};
      if (dirty & /*type*/
      2)
        section_changes.type = /*type*/
        ctx2[1];
      if (dirty & /*$$scope*/
      64) {
        section_changes.$$scope = { dirty, ctx: ctx2 };
      }
      section.$set(section_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(section.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(section.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(section, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[5].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[6],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        64)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[6],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[6]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[6],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let div1;
  let div0;
  let current_block_type_index;
  let if_block;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  const if_block_creators = [create_if_block, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*labelPosition*/
      ctx2[0] === "above" && /*type*/
      ctx2[1] !== "oneColumn"
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      if_block.c();
      attr(div0, "class", "spectrum-Form svelte-ct1cyj");
      toggle_class(
        div0,
        "spectrum-Form--labelsAbove",
        /*labelPosition*/
        ctx[0] === "above"
      );
      attr(div1, "class", "wrapper svelte-ct1cyj");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      if_blocks[current_block_type_index].m(div0, null);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[3].call(
          null,
          div1,
          /*$component*/
          ctx[2].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div0, null);
      }
      if (!current || dirty & /*labelPosition*/
      1) {
        toggle_class(
          div0,
          "spectrum-Form--labelsAbove",
          /*labelPosition*/
          ctx2[0] === "above"
        );
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      4)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[2].styles
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if_blocks[current_block_type_index].d();
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $component;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { labelPosition = "above" } = $$props;
  let { type = "oneColumn" } = $$props;
  const { styleable } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(2, $component = value));
  setContext("field-group", { labelPosition });
  $$self.$$set = ($$props2) => {
    if ("labelPosition" in $$props2)
      $$invalidate(0, labelPosition = $$props2.labelPosition);
    if ("type" in $$props2)
      $$invalidate(1, type = $$props2.type);
    if ("$$scope" in $$props2)
      $$invalidate(6, $$scope = $$props2.$$scope);
  };
  return [labelPosition, type, $component, styleable, component, slots, $$scope];
}
class FieldGroup extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { labelPosition: 0, type: 1 });
  }
}
export {
  FieldGroup as default
};
