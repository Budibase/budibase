import { S as SvelteComponent, i as init, s as safe_not_equal, aK as FieldType, bs as assign, c as create_component, m as mount_component, bR as get_spread_update, bS as get_spread_object, k as transition_in, n as transition_out, p as destroy_component, c9 as compute_rest_props, bt as exclude_internal_props } from "./index-8b9900f1.js";
import AttachmentField from "./AttachmentField-a12e4946.js";
import "./Field-a0270b82.js";
import "./Placeholder-4dedd9c4.js";
import "./InnerForm-0042fa8f.js";
function create_fragment(ctx) {
  let attachmentfield;
  let current;
  const attachmentfield_spread_levels = [
    /*$$restProps*/
    ctx[1],
    { type: FieldType.ATTACHMENT_SINGLE },
    { maximum: 1 },
    { defaultValue: null },
    {
      fieldApiMapper: (
        /*fieldApiMapper*/
        ctx[0]
      )
    }
  ];
  let attachmentfield_props = {};
  for (let i = 0; i < attachmentfield_spread_levels.length; i += 1) {
    attachmentfield_props = assign(attachmentfield_props, attachmentfield_spread_levels[i]);
  }
  attachmentfield = new AttachmentField({ props: attachmentfield_props });
  return {
    c() {
      create_component(attachmentfield.$$.fragment);
    },
    m(target, anchor) {
      mount_component(attachmentfield, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const attachmentfield_changes = dirty & /*$$restProps, fieldApiMapper*/
      3 ? get_spread_update(attachmentfield_spread_levels, [
        dirty & /*$$restProps*/
        2 && get_spread_object(
          /*$$restProps*/
          ctx2[1]
        ),
        attachmentfield_spread_levels[1],
        attachmentfield_spread_levels[2],
        attachmentfield_spread_levels[3],
        dirty & /*fieldApiMapper*/
        1 && {
          fieldApiMapper: (
            /*fieldApiMapper*/
            ctx2[0]
          )
        }
      ]) : {};
      attachmentfield.$set(attachmentfield_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(attachmentfield.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(attachmentfield.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(attachmentfield, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  const omit_props_names = [];
  let $$restProps = compute_rest_props($$props, omit_props_names);
  const fieldApiMapper = {
    get: (value) => (!Array.isArray(value) && value ? [value] : value) || [],
    set: (value) => value[0] || null
  };
  $$self.$$set = ($$new_props) => {
    $$props = assign(assign({}, $$props), exclude_internal_props($$new_props));
    $$invalidate(1, $$restProps = compute_rest_props($$props, omit_props_names));
  };
  return [fieldApiMapper, $$restProps];
}
class AttachmentSingleField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {});
  }
}
export {
  AttachmentSingleField as default
};
