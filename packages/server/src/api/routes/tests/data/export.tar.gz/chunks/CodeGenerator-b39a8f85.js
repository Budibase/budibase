import { as as getDefaultExportFromCjs, S as SvelteComponent, i as init, s as safe_not_equal, e as element, b as attr, f as insert, q as action_destroyer, h as is_function, B as noop, o as detach, u as getContext, v as component_subscribe, U as onMount, W as binding_callbacks, t as text, g as append, j as set_data, y as empty, a as space, al as set_style, ae as src_url_equal, bT as svg_element } from "./index-8b9900f1.js";
var barcodes = {};
var CODE39$1 = {};
var Barcode$1 = {};
Object.defineProperty(Barcode$1, "__esModule", {
  value: true
});
function _classCallCheck$u(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
var Barcode = function Barcode2(data, options) {
  _classCallCheck$u(this, Barcode2);
  this.data = data;
  this.text = options.text || data;
  this.options = options;
};
Barcode$1.default = Barcode;
Object.defineProperty(CODE39$1, "__esModule", {
  value: true
});
CODE39$1.CODE39 = void 0;
var _createClass$n = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _Barcode2$c = Barcode$1;
var _Barcode3$c = _interopRequireDefault$A(_Barcode2$c);
function _interopRequireDefault$A(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$t(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$p(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$p(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var CODE39 = function(_Barcode) {
  _inherits$p(CODE392, _Barcode);
  function CODE392(data, options) {
    _classCallCheck$t(this, CODE392);
    data = data.toUpperCase();
    if (options.mod43) {
      data += getCharacter(mod43checksum(data));
    }
    return _possibleConstructorReturn$p(this, (CODE392.__proto__ || Object.getPrototypeOf(CODE392)).call(this, data, options));
  }
  _createClass$n(CODE392, [{
    key: "encode",
    value: function encode3() {
      var result = getEncoding("*");
      for (var i = 0; i < this.data.length; i++) {
        result += getEncoding(this.data[i]) + "0";
      }
      result += getEncoding("*");
      return {
        data: result,
        text: this.text
      };
    }
  }, {
    key: "valid",
    value: function valid2() {
      return this.data.search(/^[0-9A-Z\-\.\ \$\/\+\%]+$/) !== -1;
    }
  }]);
  return CODE392;
}(_Barcode3$c.default);
var characters = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "-", ".", " ", "$", "/", "+", "%", "*"];
var encodings = [20957, 29783, 23639, 30485, 20951, 29813, 23669, 20855, 29789, 23645, 29975, 23831, 30533, 22295, 30149, 24005, 21623, 29981, 23837, 22301, 30023, 23879, 30545, 22343, 30161, 24017, 21959, 30065, 23921, 22385, 29015, 18263, 29141, 17879, 29045, 18293, 17783, 29021, 18269, 17477, 17489, 17681, 20753, 35770];
function getEncoding(character) {
  return getBinary(characterValue(character));
}
function getBinary(characterValue2) {
  return encodings[characterValue2].toString(2);
}
function getCharacter(characterValue2) {
  return characters[characterValue2];
}
function characterValue(character) {
  return characters.indexOf(character);
}
function mod43checksum(data) {
  var checksum6 = 0;
  for (var i = 0; i < data.length; i++) {
    checksum6 += characterValue(data[i]);
  }
  checksum6 = checksum6 % 43;
  return checksum6;
}
CODE39$1.CODE39 = CODE39;
var CODE128$2 = {};
var CODE128_AUTO = {};
var CODE128$1 = {};
var constants$3 = {};
Object.defineProperty(constants$3, "__esModule", {
  value: true
});
var _SET_BY_CODE;
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
  } else {
    obj[key] = value;
  }
  return obj;
}
var SET_A = constants$3.SET_A = 0;
var SET_B = constants$3.SET_B = 1;
var SET_C = constants$3.SET_C = 2;
constants$3.SHIFT = 98;
var START_A = constants$3.START_A = 103;
var START_B = constants$3.START_B = 104;
var START_C = constants$3.START_C = 105;
constants$3.MODULO = 103;
constants$3.STOP = 106;
constants$3.FNC1 = 207;
constants$3.SET_BY_CODE = (_SET_BY_CODE = {}, _defineProperty(_SET_BY_CODE, START_A, SET_A), _defineProperty(_SET_BY_CODE, START_B, SET_B), _defineProperty(_SET_BY_CODE, START_C, SET_C), _SET_BY_CODE);
constants$3.SWAP = {
  101: SET_A,
  100: SET_B,
  99: SET_C
};
constants$3.A_START_CHAR = String.fromCharCode(208);
constants$3.B_START_CHAR = String.fromCharCode(209);
constants$3.C_START_CHAR = String.fromCharCode(210);
constants$3.A_CHARS = "[\0-_È-Ï]";
constants$3.B_CHARS = "[ -È-Ï]";
constants$3.C_CHARS = "(Ï*[0-9]{2}Ï*)";
constants$3.BARS = [11011001100, 11001101100, 11001100110, 10010011e3, 10010001100, 10001001100, 10011001e3, 10011000100, 10001100100, 11001001e3, 11001000100, 11000100100, 10110011100, 10011011100, 10011001110, 10111001100, 10011101100, 10011100110, 11001110010, 11001011100, 11001001110, 11011100100, 11001110100, 11101101110, 11101001100, 11100101100, 11100100110, 11101100100, 11100110100, 11100110010, 11011011e3, 11011000110, 11000110110, 10100011e3, 10001011e3, 10001000110, 10110001e3, 10001101e3, 10001100010, 11010001e3, 11000101e3, 11000100010, 10110111e3, 10110001110, 10001101110, 10111011e3, 10111000110, 10001110110, 11101110110, 11010001110, 11000101110, 11011101e3, 11011100010, 11011101110, 11101011e3, 11101000110, 11100010110, 11101101e3, 11101100010, 11100011010, 11101111010, 11001000010, 11110001010, 1010011e4, 10100001100, 1001011e4, 10010000110, 10000101100, 10000100110, 1011001e4, 10110000100, 1001101e4, 10011000010, 10000110100, 10000110010, 11000010010, 1100101e4, 11110111010, 11000010100, 10001111010, 10100111100, 10010111100, 10010011110, 10111100100, 10011110100, 10011110010, 11110100100, 11110010100, 11110010010, 11011011110, 11011110110, 11110110110, 10101111e3, 10100011110, 10001011110, 10111101e3, 10111100010, 11110101e3, 11110100010, 10111011110, 10111101110, 11101011110, 11110101110, 11010000100, 1101001e4, 11010011100, 1100011101011];
Object.defineProperty(CODE128$1, "__esModule", {
  value: true
});
var _createClass$m = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _Barcode2$b = Barcode$1;
var _Barcode3$b = _interopRequireDefault$z(_Barcode2$b);
var _constants$b = constants$3;
function _interopRequireDefault$z(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$s(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$o(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$o(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var CODE128 = function(_Barcode) {
  _inherits$o(CODE1282, _Barcode);
  function CODE1282(data, options) {
    _classCallCheck$s(this, CODE1282);
    var _this = _possibleConstructorReturn$o(this, (CODE1282.__proto__ || Object.getPrototypeOf(CODE1282)).call(this, data.substring(1), options));
    _this.bytes = data.split("").map(function(char) {
      return char.charCodeAt(0);
    });
    return _this;
  }
  _createClass$m(CODE1282, [{
    key: "valid",
    value: function valid2() {
      return /^[\x00-\x7F\xC8-\xD3]+$/.test(this.data);
    }
    // The public encoding function
  }, {
    key: "encode",
    value: function encode3() {
      var bytes = this.bytes;
      var startIndex = bytes.shift() - 105;
      var startSet = _constants$b.SET_BY_CODE[startIndex];
      if (startSet === void 0) {
        throw new RangeError("The encoding does not start with a start character.");
      }
      if (this.shouldEncodeAsEan128() === true) {
        bytes.unshift(_constants$b.FNC1);
      }
      var encodingResult = CODE1282.next(bytes, 1, startSet);
      return {
        text: this.text === this.data ? this.text.replace(/[^\x20-\x7E]/g, "") : this.text,
        data: (
          // Add the start bits
          CODE1282.getBar(startIndex) + // Add the encoded bits
          encodingResult.result + // Add the checksum
          CODE1282.getBar((encodingResult.checksum + startIndex) % _constants$b.MODULO) + // Add the end bits
          CODE1282.getBar(_constants$b.STOP)
        )
      };
    }
    // GS1-128/EAN-128
  }, {
    key: "shouldEncodeAsEan128",
    value: function shouldEncodeAsEan128() {
      var isEAN128 = this.options.ean128 || false;
      if (typeof isEAN128 === "string") {
        isEAN128 = isEAN128.toLowerCase() === "true";
      }
      return isEAN128;
    }
    // Get a bar symbol by index
  }], [{
    key: "getBar",
    value: function getBar(index) {
      return _constants$b.BARS[index] ? _constants$b.BARS[index].toString() : "";
    }
    // Correct an index by a set and shift it from the bytes array
  }, {
    key: "correctIndex",
    value: function correctIndex(bytes, set) {
      if (set === _constants$b.SET_A) {
        var charCode = bytes.shift();
        return charCode < 32 ? charCode + 64 : charCode - 32;
      } else if (set === _constants$b.SET_B) {
        return bytes.shift() - 32;
      } else {
        return (bytes.shift() - 48) * 10 + bytes.shift() - 48;
      }
    }
  }, {
    key: "next",
    value: function next(bytes, pos, set) {
      if (!bytes.length) {
        return { result: "", checksum: 0 };
      }
      var nextCode = void 0, index = void 0;
      if (bytes[0] >= 200) {
        index = bytes.shift() - 105;
        var nextSet = _constants$b.SWAP[index];
        if (nextSet !== void 0) {
          nextCode = CODE1282.next(bytes, pos + 1, nextSet);
        } else {
          if ((set === _constants$b.SET_A || set === _constants$b.SET_B) && index === _constants$b.SHIFT) {
            bytes[0] = set === _constants$b.SET_A ? bytes[0] > 95 ? bytes[0] - 96 : bytes[0] : bytes[0] < 32 ? bytes[0] + 96 : bytes[0];
          }
          nextCode = CODE1282.next(bytes, pos + 1, set);
        }
      } else {
        index = CODE1282.correctIndex(bytes, set);
        nextCode = CODE1282.next(bytes, pos + 1, set);
      }
      var enc = CODE1282.getBar(index);
      var weight = index * pos;
      return {
        result: enc + nextCode.result,
        checksum: weight + nextCode.checksum
      };
    }
  }]);
  return CODE1282;
}(_Barcode3$b.default);
CODE128$1.default = CODE128;
var auto = {};
Object.defineProperty(auto, "__esModule", {
  value: true
});
var _constants$a = constants$3;
var matchSetALength = function matchSetALength2(string) {
  return string.match(new RegExp("^" + _constants$a.A_CHARS + "*"))[0].length;
};
var matchSetBLength = function matchSetBLength2(string) {
  return string.match(new RegExp("^" + _constants$a.B_CHARS + "*"))[0].length;
};
var matchSetC = function matchSetC2(string) {
  return string.match(new RegExp("^" + _constants$a.C_CHARS + "*"))[0];
};
function autoSelectFromAB(string, isA) {
  var ranges = isA ? _constants$a.A_CHARS : _constants$a.B_CHARS;
  var untilC = string.match(new RegExp("^(" + ranges + "+?)(([0-9]{2}){2,})([^0-9]|$)"));
  if (untilC) {
    return untilC[1] + String.fromCharCode(204) + autoSelectFromC(string.substring(untilC[1].length));
  }
  var chars = string.match(new RegExp("^" + ranges + "+"))[0];
  if (chars.length === string.length) {
    return string;
  }
  return chars + String.fromCharCode(isA ? 205 : 206) + autoSelectFromAB(string.substring(chars.length), !isA);
}
function autoSelectFromC(string) {
  var cMatch = matchSetC(string);
  var length = cMatch.length;
  if (length === string.length) {
    return string;
  }
  string = string.substring(length);
  var isA = matchSetALength(string) >= matchSetBLength(string);
  return cMatch + String.fromCharCode(isA ? 206 : 205) + autoSelectFromAB(string, isA);
}
auto.default = function(string) {
  var newString = void 0;
  var cLength = matchSetC(string).length;
  if (cLength >= 2) {
    newString = _constants$a.C_START_CHAR + autoSelectFromC(string);
  } else {
    var isA = matchSetALength(string) > matchSetBLength(string);
    newString = (isA ? _constants$a.A_START_CHAR : _constants$a.B_START_CHAR) + autoSelectFromAB(string, isA);
  }
  return newString.replace(
    /[\xCD\xCE]([^])[\xCD\xCE]/,
    // Any sequence between 205 and 206 characters
    function(match, char) {
      return String.fromCharCode(203) + char;
    }
  );
};
Object.defineProperty(CODE128_AUTO, "__esModule", {
  value: true
});
var _CODE2$6 = CODE128$1;
var _CODE3$5 = _interopRequireDefault$y(_CODE2$6);
var _auto = auto;
var _auto2 = _interopRequireDefault$y(_auto);
function _interopRequireDefault$y(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$r(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$n(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$n(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var CODE128AUTO = function(_CODE4) {
  _inherits$n(CODE128AUTO2, _CODE4);
  function CODE128AUTO2(data, options) {
    _classCallCheck$r(this, CODE128AUTO2);
    if (/^[\x00-\x7F\xC8-\xD3]+$/.test(data)) {
      var _this = _possibleConstructorReturn$n(this, (CODE128AUTO2.__proto__ || Object.getPrototypeOf(CODE128AUTO2)).call(this, (0, _auto2.default)(data), options));
    } else {
      var _this = _possibleConstructorReturn$n(this, (CODE128AUTO2.__proto__ || Object.getPrototypeOf(CODE128AUTO2)).call(this, data, options));
    }
    return _possibleConstructorReturn$n(_this);
  }
  return CODE128AUTO2;
}(_CODE3$5.default);
CODE128_AUTO.default = CODE128AUTO;
var CODE128A$1 = {};
Object.defineProperty(CODE128A$1, "__esModule", {
  value: true
});
var _createClass$l = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _CODE2$5 = CODE128$1;
var _CODE3$4 = _interopRequireDefault$x(_CODE2$5);
var _constants$9 = constants$3;
function _interopRequireDefault$x(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$q(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$m(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$m(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var CODE128A = function(_CODE4) {
  _inherits$m(CODE128A2, _CODE4);
  function CODE128A2(string, options) {
    _classCallCheck$q(this, CODE128A2);
    return _possibleConstructorReturn$m(this, (CODE128A2.__proto__ || Object.getPrototypeOf(CODE128A2)).call(this, _constants$9.A_START_CHAR + string, options));
  }
  _createClass$l(CODE128A2, [{
    key: "valid",
    value: function valid2() {
      return new RegExp("^" + _constants$9.A_CHARS + "+$").test(this.data);
    }
  }]);
  return CODE128A2;
}(_CODE3$4.default);
CODE128A$1.default = CODE128A;
var CODE128B$1 = {};
Object.defineProperty(CODE128B$1, "__esModule", {
  value: true
});
var _createClass$k = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _CODE2$4 = CODE128$1;
var _CODE3$3 = _interopRequireDefault$w(_CODE2$4);
var _constants$8 = constants$3;
function _interopRequireDefault$w(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$p(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$l(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$l(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var CODE128B = function(_CODE4) {
  _inherits$l(CODE128B2, _CODE4);
  function CODE128B2(string, options) {
    _classCallCheck$p(this, CODE128B2);
    return _possibleConstructorReturn$l(this, (CODE128B2.__proto__ || Object.getPrototypeOf(CODE128B2)).call(this, _constants$8.B_START_CHAR + string, options));
  }
  _createClass$k(CODE128B2, [{
    key: "valid",
    value: function valid2() {
      return new RegExp("^" + _constants$8.B_CHARS + "+$").test(this.data);
    }
  }]);
  return CODE128B2;
}(_CODE3$3.default);
CODE128B$1.default = CODE128B;
var CODE128C$1 = {};
Object.defineProperty(CODE128C$1, "__esModule", {
  value: true
});
var _createClass$j = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _CODE2$3 = CODE128$1;
var _CODE3$2 = _interopRequireDefault$v(_CODE2$3);
var _constants$7 = constants$3;
function _interopRequireDefault$v(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$o(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$k(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$k(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var CODE128C = function(_CODE4) {
  _inherits$k(CODE128C2, _CODE4);
  function CODE128C2(string, options) {
    _classCallCheck$o(this, CODE128C2);
    return _possibleConstructorReturn$k(this, (CODE128C2.__proto__ || Object.getPrototypeOf(CODE128C2)).call(this, _constants$7.C_START_CHAR + string, options));
  }
  _createClass$j(CODE128C2, [{
    key: "valid",
    value: function valid2() {
      return new RegExp("^" + _constants$7.C_CHARS + "+$").test(this.data);
    }
  }]);
  return CODE128C2;
}(_CODE3$2.default);
CODE128C$1.default = CODE128C;
Object.defineProperty(CODE128$2, "__esModule", {
  value: true
});
CODE128$2.CODE128C = CODE128$2.CODE128B = CODE128$2.CODE128A = CODE128$2.CODE128 = void 0;
var _CODE128_AUTO = CODE128_AUTO;
var _CODE128_AUTO2 = _interopRequireDefault$u(_CODE128_AUTO);
var _CODE128A = CODE128A$1;
var _CODE128A2 = _interopRequireDefault$u(_CODE128A);
var _CODE128B = CODE128B$1;
var _CODE128B2 = _interopRequireDefault$u(_CODE128B);
var _CODE128C = CODE128C$1;
var _CODE128C2 = _interopRequireDefault$u(_CODE128C);
function _interopRequireDefault$u(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
CODE128$2.CODE128 = _CODE128_AUTO2.default;
CODE128$2.CODE128A = _CODE128A2.default;
CODE128$2.CODE128B = _CODE128B2.default;
CODE128$2.CODE128C = _CODE128C2.default;
var EAN_UPC = {};
var EAN13$1 = {};
var constants$2 = {};
Object.defineProperty(constants$2, "__esModule", {
  value: true
});
constants$2.SIDE_BIN = "101";
constants$2.MIDDLE_BIN = "01010";
constants$2.BINARIES = {
  "L": [
    // The L (left) type of encoding
    "0001101",
    "0011001",
    "0010011",
    "0111101",
    "0100011",
    "0110001",
    "0101111",
    "0111011",
    "0110111",
    "0001011"
  ],
  "G": [
    // The G type of encoding
    "0100111",
    "0110011",
    "0011011",
    "0100001",
    "0011101",
    "0111001",
    "0000101",
    "0010001",
    "0001001",
    "0010111"
  ],
  "R": [
    // The R (right) type of encoding
    "1110010",
    "1100110",
    "1101100",
    "1000010",
    "1011100",
    "1001110",
    "1010000",
    "1000100",
    "1001000",
    "1110100"
  ],
  "O": [
    // The O (odd) encoding for UPC-E
    "0001101",
    "0011001",
    "0010011",
    "0111101",
    "0100011",
    "0110001",
    "0101111",
    "0111011",
    "0110111",
    "0001011"
  ],
  "E": [
    // The E (even) encoding for UPC-E
    "0100111",
    "0110011",
    "0011011",
    "0100001",
    "0011101",
    "0111001",
    "0000101",
    "0010001",
    "0001001",
    "0010111"
  ]
};
constants$2.EAN2_STRUCTURE = ["LL", "LG", "GL", "GG"];
constants$2.EAN5_STRUCTURE = ["GGLLL", "GLGLL", "GLLGL", "GLLLG", "LGGLL", "LLGGL", "LLLGG", "LGLGL", "LGLLG", "LLGLG"];
constants$2.EAN13_STRUCTURE = ["LLLLLL", "LLGLGG", "LLGGLG", "LLGGGL", "LGLLGG", "LGGLLG", "LGGGLL", "LGLGLG", "LGLGGL", "LGGLGL"];
var EAN$1 = {};
var encoder = {};
Object.defineProperty(encoder, "__esModule", {
  value: true
});
var _constants$6 = constants$2;
var encode$1 = function encode(data, structure, separator) {
  var encoded = data.split("").map(function(val, idx) {
    return _constants$6.BINARIES[structure[idx]];
  }).map(function(val, idx) {
    return val ? val[data[idx]] : "";
  });
  if (separator) {
    var last = data.length - 1;
    encoded = encoded.map(function(val, idx) {
      return idx < last ? val + separator : val;
    });
  }
  return encoded.join("");
};
encoder.default = encode$1;
Object.defineProperty(EAN$1, "__esModule", {
  value: true
});
var _createClass$i = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _constants$5 = constants$2;
var _encoder$4 = encoder;
var _encoder2$4 = _interopRequireDefault$t(_encoder$4);
var _Barcode2$a = Barcode$1;
var _Barcode3$a = _interopRequireDefault$t(_Barcode2$a);
function _interopRequireDefault$t(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$n(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$j(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$j(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var EAN = function(_Barcode) {
  _inherits$j(EAN3, _Barcode);
  function EAN3(data, options) {
    _classCallCheck$n(this, EAN3);
    var _this = _possibleConstructorReturn$j(this, (EAN3.__proto__ || Object.getPrototypeOf(EAN3)).call(this, data, options));
    _this.fontSize = !options.flat && options.fontSize > options.width * 10 ? options.width * 10 : options.fontSize;
    _this.guardHeight = options.height + _this.fontSize / 2 + options.textMargin;
    return _this;
  }
  _createClass$i(EAN3, [{
    key: "encode",
    value: function encode3() {
      return this.options.flat ? this.encodeFlat() : this.encodeGuarded();
    }
  }, {
    key: "leftText",
    value: function leftText(from, to) {
      return this.text.substr(from, to);
    }
  }, {
    key: "leftEncode",
    value: function leftEncode(data, structure) {
      return (0, _encoder2$4.default)(data, structure);
    }
  }, {
    key: "rightText",
    value: function rightText(from, to) {
      return this.text.substr(from, to);
    }
  }, {
    key: "rightEncode",
    value: function rightEncode(data, structure) {
      return (0, _encoder2$4.default)(data, structure);
    }
  }, {
    key: "encodeGuarded",
    value: function encodeGuarded() {
      var textOptions = { fontSize: this.fontSize };
      var guardOptions = { height: this.guardHeight };
      return [{ data: _constants$5.SIDE_BIN, options: guardOptions }, { data: this.leftEncode(), text: this.leftText(), options: textOptions }, { data: _constants$5.MIDDLE_BIN, options: guardOptions }, { data: this.rightEncode(), text: this.rightText(), options: textOptions }, { data: _constants$5.SIDE_BIN, options: guardOptions }];
    }
  }, {
    key: "encodeFlat",
    value: function encodeFlat() {
      var data = [_constants$5.SIDE_BIN, this.leftEncode(), _constants$5.MIDDLE_BIN, this.rightEncode(), _constants$5.SIDE_BIN];
      return {
        data: data.join(""),
        text: this.text
      };
    }
  }]);
  return EAN3;
}(_Barcode3$a.default);
EAN$1.default = EAN;
Object.defineProperty(EAN13$1, "__esModule", {
  value: true
});
var _createClass$h = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _get$1 = function get(object2, property, receiver) {
  if (object2 === null)
    object2 = Function.prototype;
  var desc = Object.getOwnPropertyDescriptor(object2, property);
  if (desc === void 0) {
    var parent = Object.getPrototypeOf(object2);
    if (parent === null) {
      return void 0;
    } else {
      return get(parent, property, receiver);
    }
  } else if ("value" in desc) {
    return desc.value;
  } else {
    var getter = desc.get;
    if (getter === void 0) {
      return void 0;
    }
    return getter.call(receiver);
  }
};
var _constants$4 = constants$2;
var _EAN2$2 = EAN$1;
var _EAN3$2 = _interopRequireDefault$s(_EAN2$2);
function _interopRequireDefault$s(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$m(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$i(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$i(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var checksum$4 = function checksum(number) {
  var res = number.substr(0, 12).split("").map(function(n) {
    return +n;
  }).reduce(function(sum, a, idx) {
    return idx % 2 ? sum + a * 3 : sum + a;
  }, 0);
  return (10 - res % 10) % 10;
};
var EAN13 = function(_EAN9) {
  _inherits$i(EAN132, _EAN9);
  function EAN132(data, options) {
    _classCallCheck$m(this, EAN132);
    if (data.search(/^[0-9]{12}$/) !== -1) {
      data += checksum$4(data);
    }
    var _this = _possibleConstructorReturn$i(this, (EAN132.__proto__ || Object.getPrototypeOf(EAN132)).call(this, data, options));
    _this.lastChar = options.lastChar;
    return _this;
  }
  _createClass$h(EAN132, [{
    key: "valid",
    value: function valid2() {
      return this.data.search(/^[0-9]{13}$/) !== -1 && +this.data[12] === checksum$4(this.data);
    }
  }, {
    key: "leftText",
    value: function leftText() {
      return _get$1(EAN132.prototype.__proto__ || Object.getPrototypeOf(EAN132.prototype), "leftText", this).call(this, 1, 6);
    }
  }, {
    key: "leftEncode",
    value: function leftEncode() {
      var data = this.data.substr(1, 6);
      var structure = _constants$4.EAN13_STRUCTURE[this.data[0]];
      return _get$1(EAN132.prototype.__proto__ || Object.getPrototypeOf(EAN132.prototype), "leftEncode", this).call(this, data, structure);
    }
  }, {
    key: "rightText",
    value: function rightText() {
      return _get$1(EAN132.prototype.__proto__ || Object.getPrototypeOf(EAN132.prototype), "rightText", this).call(this, 7, 6);
    }
  }, {
    key: "rightEncode",
    value: function rightEncode() {
      var data = this.data.substr(7, 6);
      return _get$1(EAN132.prototype.__proto__ || Object.getPrototypeOf(EAN132.prototype), "rightEncode", this).call(this, data, "RRRRRR");
    }
    // The "standard" way of printing EAN13 barcodes with guard bars
  }, {
    key: "encodeGuarded",
    value: function encodeGuarded() {
      var data = _get$1(EAN132.prototype.__proto__ || Object.getPrototypeOf(EAN132.prototype), "encodeGuarded", this).call(this);
      if (this.options.displayValue) {
        data.unshift({
          data: "000000000000",
          text: this.text.substr(0, 1),
          options: { textAlign: "left", fontSize: this.fontSize }
        });
        if (this.options.lastChar) {
          data.push({
            data: "00"
          });
          data.push({
            data: "00000",
            text: this.options.lastChar,
            options: { fontSize: this.fontSize }
          });
        }
      }
      return data;
    }
  }]);
  return EAN132;
}(_EAN3$2.default);
EAN13$1.default = EAN13;
var EAN8$1 = {};
Object.defineProperty(EAN8$1, "__esModule", {
  value: true
});
var _createClass$g = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _get = function get2(object2, property, receiver) {
  if (object2 === null)
    object2 = Function.prototype;
  var desc = Object.getOwnPropertyDescriptor(object2, property);
  if (desc === void 0) {
    var parent = Object.getPrototypeOf(object2);
    if (parent === null) {
      return void 0;
    } else {
      return get2(parent, property, receiver);
    }
  } else if ("value" in desc) {
    return desc.value;
  } else {
    var getter = desc.get;
    if (getter === void 0) {
      return void 0;
    }
    return getter.call(receiver);
  }
};
var _EAN2$1 = EAN$1;
var _EAN3$1 = _interopRequireDefault$r(_EAN2$1);
function _interopRequireDefault$r(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$l(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$h(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$h(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var checksum$3 = function checksum2(number) {
  var res = number.substr(0, 7).split("").map(function(n) {
    return +n;
  }).reduce(function(sum, a, idx) {
    return idx % 2 ? sum + a : sum + a * 3;
  }, 0);
  return (10 - res % 10) % 10;
};
var EAN8 = function(_EAN9) {
  _inherits$h(EAN82, _EAN9);
  function EAN82(data, options) {
    _classCallCheck$l(this, EAN82);
    if (data.search(/^[0-9]{7}$/) !== -1) {
      data += checksum$3(data);
    }
    return _possibleConstructorReturn$h(this, (EAN82.__proto__ || Object.getPrototypeOf(EAN82)).call(this, data, options));
  }
  _createClass$g(EAN82, [{
    key: "valid",
    value: function valid2() {
      return this.data.search(/^[0-9]{8}$/) !== -1 && +this.data[7] === checksum$3(this.data);
    }
  }, {
    key: "leftText",
    value: function leftText() {
      return _get(EAN82.prototype.__proto__ || Object.getPrototypeOf(EAN82.prototype), "leftText", this).call(this, 0, 4);
    }
  }, {
    key: "leftEncode",
    value: function leftEncode() {
      var data = this.data.substr(0, 4);
      return _get(EAN82.prototype.__proto__ || Object.getPrototypeOf(EAN82.prototype), "leftEncode", this).call(this, data, "LLLL");
    }
  }, {
    key: "rightText",
    value: function rightText() {
      return _get(EAN82.prototype.__proto__ || Object.getPrototypeOf(EAN82.prototype), "rightText", this).call(this, 4, 4);
    }
  }, {
    key: "rightEncode",
    value: function rightEncode() {
      var data = this.data.substr(4, 4);
      return _get(EAN82.prototype.__proto__ || Object.getPrototypeOf(EAN82.prototype), "rightEncode", this).call(this, data, "RRRR");
    }
  }]);
  return EAN82;
}(_EAN3$1.default);
EAN8$1.default = EAN8;
var EAN5$1 = {};
Object.defineProperty(EAN5$1, "__esModule", {
  value: true
});
var _createClass$f = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _constants$3 = constants$2;
var _encoder$3 = encoder;
var _encoder2$3 = _interopRequireDefault$q(_encoder$3);
var _Barcode2$9 = Barcode$1;
var _Barcode3$9 = _interopRequireDefault$q(_Barcode2$9);
function _interopRequireDefault$q(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$k(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$g(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$g(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var checksum$2 = function checksum3(data) {
  var result = data.split("").map(function(n) {
    return +n;
  }).reduce(function(sum, a, idx) {
    return idx % 2 ? sum + a * 9 : sum + a * 3;
  }, 0);
  return result % 10;
};
var EAN5 = function(_Barcode) {
  _inherits$g(EAN52, _Barcode);
  function EAN52(data, options) {
    _classCallCheck$k(this, EAN52);
    return _possibleConstructorReturn$g(this, (EAN52.__proto__ || Object.getPrototypeOf(EAN52)).call(this, data, options));
  }
  _createClass$f(EAN52, [{
    key: "valid",
    value: function valid2() {
      return this.data.search(/^[0-9]{5}$/) !== -1;
    }
  }, {
    key: "encode",
    value: function encode3() {
      var structure = _constants$3.EAN5_STRUCTURE[checksum$2(this.data)];
      return {
        data: "1011" + (0, _encoder2$3.default)(this.data, structure, "01"),
        text: this.text
      };
    }
  }]);
  return EAN52;
}(_Barcode3$9.default);
EAN5$1.default = EAN5;
var EAN2$1 = {};
Object.defineProperty(EAN2$1, "__esModule", {
  value: true
});
var _createClass$e = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _constants$2 = constants$2;
var _encoder$2 = encoder;
var _encoder2$2 = _interopRequireDefault$p(_encoder$2);
var _Barcode2$8 = Barcode$1;
var _Barcode3$8 = _interopRequireDefault$p(_Barcode2$8);
function _interopRequireDefault$p(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$j(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$f(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$f(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var EAN2 = function(_Barcode) {
  _inherits$f(EAN22, _Barcode);
  function EAN22(data, options) {
    _classCallCheck$j(this, EAN22);
    return _possibleConstructorReturn$f(this, (EAN22.__proto__ || Object.getPrototypeOf(EAN22)).call(this, data, options));
  }
  _createClass$e(EAN22, [{
    key: "valid",
    value: function valid2() {
      return this.data.search(/^[0-9]{2}$/) !== -1;
    }
  }, {
    key: "encode",
    value: function encode3() {
      var structure = _constants$2.EAN2_STRUCTURE[parseInt(this.data) % 4];
      return {
        // Start bits + Encode the two digits with 01 in between
        data: "1011" + (0, _encoder2$2.default)(this.data, structure, "01"),
        text: this.text
      };
    }
  }]);
  return EAN22;
}(_Barcode3$8.default);
EAN2$1.default = EAN2;
var UPC$1 = {};
Object.defineProperty(UPC$1, "__esModule", {
  value: true
});
var _createClass$d = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
UPC$1.checksum = checksum$1;
var _encoder$1 = encoder;
var _encoder2$1 = _interopRequireDefault$o(_encoder$1);
var _Barcode2$7 = Barcode$1;
var _Barcode3$7 = _interopRequireDefault$o(_Barcode2$7);
function _interopRequireDefault$o(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$i(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$e(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$e(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var UPC = function(_Barcode) {
  _inherits$e(UPC2, _Barcode);
  function UPC2(data, options) {
    _classCallCheck$i(this, UPC2);
    if (data.search(/^[0-9]{11}$/) !== -1) {
      data += checksum$1(data);
    }
    var _this = _possibleConstructorReturn$e(this, (UPC2.__proto__ || Object.getPrototypeOf(UPC2)).call(this, data, options));
    _this.displayValue = options.displayValue;
    if (options.fontSize > options.width * 10) {
      _this.fontSize = options.width * 10;
    } else {
      _this.fontSize = options.fontSize;
    }
    _this.guardHeight = options.height + _this.fontSize / 2 + options.textMargin;
    return _this;
  }
  _createClass$d(UPC2, [{
    key: "valid",
    value: function valid2() {
      return this.data.search(/^[0-9]{12}$/) !== -1 && this.data[11] == checksum$1(this.data);
    }
  }, {
    key: "encode",
    value: function encode3() {
      if (this.options.flat) {
        return this.flatEncoding();
      } else {
        return this.guardedEncoding();
      }
    }
  }, {
    key: "flatEncoding",
    value: function flatEncoding() {
      var result = "";
      result += "101";
      result += (0, _encoder2$1.default)(this.data.substr(0, 6), "LLLLLL");
      result += "01010";
      result += (0, _encoder2$1.default)(this.data.substr(6, 6), "RRRRRR");
      result += "101";
      return {
        data: result,
        text: this.text
      };
    }
  }, {
    key: "guardedEncoding",
    value: function guardedEncoding() {
      var result = [];
      if (this.displayValue) {
        result.push({
          data: "00000000",
          text: this.text.substr(0, 1),
          options: { textAlign: "left", fontSize: this.fontSize }
        });
      }
      result.push({
        data: "101" + (0, _encoder2$1.default)(this.data[0], "L"),
        options: { height: this.guardHeight }
      });
      result.push({
        data: (0, _encoder2$1.default)(this.data.substr(1, 5), "LLLLL"),
        text: this.text.substr(1, 5),
        options: { fontSize: this.fontSize }
      });
      result.push({
        data: "01010",
        options: { height: this.guardHeight }
      });
      result.push({
        data: (0, _encoder2$1.default)(this.data.substr(6, 5), "RRRRR"),
        text: this.text.substr(6, 5),
        options: { fontSize: this.fontSize }
      });
      result.push({
        data: (0, _encoder2$1.default)(this.data[11], "R") + "101",
        options: { height: this.guardHeight }
      });
      if (this.displayValue) {
        result.push({
          data: "00000000",
          text: this.text.substr(11, 1),
          options: { textAlign: "right", fontSize: this.fontSize }
        });
      }
      return result;
    }
  }]);
  return UPC2;
}(_Barcode3$7.default);
function checksum$1(number) {
  var result = 0;
  var i;
  for (i = 1; i < 11; i += 2) {
    result += parseInt(number[i]);
  }
  for (i = 0; i < 11; i += 2) {
    result += parseInt(number[i]) * 3;
  }
  return (10 - result % 10) % 10;
}
UPC$1.default = UPC;
var UPCE$1 = {};
Object.defineProperty(UPCE$1, "__esModule", {
  value: true
});
var _createClass$c = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _encoder = encoder;
var _encoder2 = _interopRequireDefault$n(_encoder);
var _Barcode2$6 = Barcode$1;
var _Barcode3$6 = _interopRequireDefault$n(_Barcode2$6);
var _UPC$1 = UPC$1;
function _interopRequireDefault$n(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$h(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$d(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$d(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var EXPANSIONS = ["XX00000XXX", "XX10000XXX", "XX20000XXX", "XXX00000XX", "XXXX00000X", "XXXXX00005", "XXXXX00006", "XXXXX00007", "XXXXX00008", "XXXXX00009"];
var PARITIES = [["EEEOOO", "OOOEEE"], ["EEOEOO", "OOEOEE"], ["EEOOEO", "OOEEOE"], ["EEOOOE", "OOEEEO"], ["EOEEOO", "OEOOEE"], ["EOOEEO", "OEEOOE"], ["EOOOEE", "OEEEOO"], ["EOEOEO", "OEOEOE"], ["EOEOOE", "OEOEEO"], ["EOOEOE", "OEEOEO"]];
var UPCE = function(_Barcode) {
  _inherits$d(UPCE2, _Barcode);
  function UPCE2(data, options) {
    _classCallCheck$h(this, UPCE2);
    var _this = _possibleConstructorReturn$d(this, (UPCE2.__proto__ || Object.getPrototypeOf(UPCE2)).call(this, data, options));
    _this.isValid = false;
    if (data.search(/^[0-9]{6}$/) !== -1) {
      _this.middleDigits = data;
      _this.upcA = expandToUPCA(data, "0");
      _this.text = options.text || "" + _this.upcA[0] + data + _this.upcA[_this.upcA.length - 1];
      _this.isValid = true;
    } else if (data.search(/^[01][0-9]{7}$/) !== -1) {
      _this.middleDigits = data.substring(1, data.length - 1);
      _this.upcA = expandToUPCA(_this.middleDigits, data[0]);
      if (_this.upcA[_this.upcA.length - 1] === data[data.length - 1]) {
        _this.isValid = true;
      } else {
        return _possibleConstructorReturn$d(_this);
      }
    } else {
      return _possibleConstructorReturn$d(_this);
    }
    _this.displayValue = options.displayValue;
    if (options.fontSize > options.width * 10) {
      _this.fontSize = options.width * 10;
    } else {
      _this.fontSize = options.fontSize;
    }
    _this.guardHeight = options.height + _this.fontSize / 2 + options.textMargin;
    return _this;
  }
  _createClass$c(UPCE2, [{
    key: "valid",
    value: function valid2() {
      return this.isValid;
    }
  }, {
    key: "encode",
    value: function encode3() {
      if (this.options.flat) {
        return this.flatEncoding();
      } else {
        return this.guardedEncoding();
      }
    }
  }, {
    key: "flatEncoding",
    value: function flatEncoding() {
      var result = "";
      result += "101";
      result += this.encodeMiddleDigits();
      result += "010101";
      return {
        data: result,
        text: this.text
      };
    }
  }, {
    key: "guardedEncoding",
    value: function guardedEncoding() {
      var result = [];
      if (this.displayValue) {
        result.push({
          data: "00000000",
          text: this.text[0],
          options: { textAlign: "left", fontSize: this.fontSize }
        });
      }
      result.push({
        data: "101",
        options: { height: this.guardHeight }
      });
      result.push({
        data: this.encodeMiddleDigits(),
        text: this.text.substring(1, 7),
        options: { fontSize: this.fontSize }
      });
      result.push({
        data: "010101",
        options: { height: this.guardHeight }
      });
      if (this.displayValue) {
        result.push({
          data: "00000000",
          text: this.text[7],
          options: { textAlign: "right", fontSize: this.fontSize }
        });
      }
      return result;
    }
  }, {
    key: "encodeMiddleDigits",
    value: function encodeMiddleDigits() {
      var numberSystem = this.upcA[0];
      var checkDigit = this.upcA[this.upcA.length - 1];
      var parity = PARITIES[parseInt(checkDigit)][parseInt(numberSystem)];
      return (0, _encoder2.default)(this.middleDigits, parity);
    }
  }]);
  return UPCE2;
}(_Barcode3$6.default);
function expandToUPCA(middleDigits, numberSystem) {
  var lastUpcE = parseInt(middleDigits[middleDigits.length - 1]);
  var expansion = EXPANSIONS[lastUpcE];
  var result = "";
  var digitIndex = 0;
  for (var i = 0; i < expansion.length; i++) {
    var c = expansion[i];
    if (c === "X") {
      result += middleDigits[digitIndex++];
    } else {
      result += c;
    }
  }
  result = "" + numberSystem + result;
  return "" + result + (0, _UPC$1.checksum)(result);
}
UPCE$1.default = UPCE;
Object.defineProperty(EAN_UPC, "__esModule", {
  value: true
});
EAN_UPC.UPCE = EAN_UPC.UPC = EAN_UPC.EAN2 = EAN_UPC.EAN5 = EAN_UPC.EAN8 = EAN_UPC.EAN13 = void 0;
var _EAN = EAN13$1;
var _EAN2 = _interopRequireDefault$m(_EAN);
var _EAN3 = EAN8$1;
var _EAN4 = _interopRequireDefault$m(_EAN3);
var _EAN5 = EAN5$1;
var _EAN6 = _interopRequireDefault$m(_EAN5);
var _EAN7 = EAN2$1;
var _EAN8 = _interopRequireDefault$m(_EAN7);
var _UPC = UPC$1;
var _UPC2 = _interopRequireDefault$m(_UPC);
var _UPCE = UPCE$1;
var _UPCE2 = _interopRequireDefault$m(_UPCE);
function _interopRequireDefault$m(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
EAN_UPC.EAN13 = _EAN2.default;
EAN_UPC.EAN8 = _EAN4.default;
EAN_UPC.EAN5 = _EAN6.default;
EAN_UPC.EAN2 = _EAN8.default;
EAN_UPC.UPC = _UPC2.default;
EAN_UPC.UPCE = _UPCE2.default;
var ITF$2 = {};
var ITF$1 = {};
var constants$1 = {};
Object.defineProperty(constants$1, "__esModule", {
  value: true
});
constants$1.START_BIN = "1010";
constants$1.END_BIN = "11101";
constants$1.BINARIES = ["00110", "10001", "01001", "11000", "00101", "10100", "01100", "00011", "10010", "01010"];
Object.defineProperty(ITF$1, "__esModule", {
  value: true
});
var _createClass$b = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _constants$1 = constants$1;
var _Barcode2$5 = Barcode$1;
var _Barcode3$5 = _interopRequireDefault$l(_Barcode2$5);
function _interopRequireDefault$l(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$g(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$c(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$c(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var ITF = function(_Barcode) {
  _inherits$c(ITF2, _Barcode);
  function ITF2() {
    _classCallCheck$g(this, ITF2);
    return _possibleConstructorReturn$c(this, (ITF2.__proto__ || Object.getPrototypeOf(ITF2)).apply(this, arguments));
  }
  _createClass$b(ITF2, [{
    key: "valid",
    value: function valid2() {
      return this.data.search(/^([0-9]{2})+$/) !== -1;
    }
  }, {
    key: "encode",
    value: function encode3() {
      var _this2 = this;
      var encoded = this.data.match(/.{2}/g).map(function(pair) {
        return _this2.encodePair(pair);
      }).join("");
      return {
        data: _constants$1.START_BIN + encoded + _constants$1.END_BIN,
        text: this.text
      };
    }
    // Calculate the data of a number pair
  }, {
    key: "encodePair",
    value: function encodePair(pair) {
      var second = _constants$1.BINARIES[pair[1]];
      return _constants$1.BINARIES[pair[0]].split("").map(function(first, idx) {
        return (first === "1" ? "111" : "1") + (second[idx] === "1" ? "000" : "0");
      }).join("");
    }
  }]);
  return ITF2;
}(_Barcode3$5.default);
ITF$1.default = ITF;
var ITF14$1 = {};
Object.defineProperty(ITF14$1, "__esModule", {
  value: true
});
var _createClass$a = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _ITF2$1 = ITF$1;
var _ITF3$1 = _interopRequireDefault$k(_ITF2$1);
function _interopRequireDefault$k(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$f(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$b(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$b(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var checksum4 = function checksum5(data) {
  var res = data.substr(0, 13).split("").map(function(num) {
    return parseInt(num, 10);
  }).reduce(function(sum, n, idx) {
    return sum + n * (3 - idx % 2 * 2);
  }, 0);
  return Math.ceil(res / 10) * 10 - res;
};
var ITF14 = function(_ITF5) {
  _inherits$b(ITF142, _ITF5);
  function ITF142(data, options) {
    _classCallCheck$f(this, ITF142);
    if (data.search(/^[0-9]{13}$/) !== -1) {
      data += checksum4(data);
    }
    return _possibleConstructorReturn$b(this, (ITF142.__proto__ || Object.getPrototypeOf(ITF142)).call(this, data, options));
  }
  _createClass$a(ITF142, [{
    key: "valid",
    value: function valid2() {
      return this.data.search(/^[0-9]{14}$/) !== -1 && +this.data[13] === checksum4(this.data);
    }
  }]);
  return ITF142;
}(_ITF3$1.default);
ITF14$1.default = ITF14;
Object.defineProperty(ITF$2, "__esModule", {
  value: true
});
ITF$2.ITF14 = ITF$2.ITF = void 0;
var _ITF$1 = ITF$1;
var _ITF2 = _interopRequireDefault$j(_ITF$1);
var _ITF3 = ITF14$1;
var _ITF4 = _interopRequireDefault$j(_ITF3);
function _interopRequireDefault$j(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
ITF$2.ITF = _ITF2.default;
ITF$2.ITF14 = _ITF4.default;
var MSI$2 = {};
var MSI$1 = {};
Object.defineProperty(MSI$1, "__esModule", {
  value: true
});
var _createClass$9 = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _Barcode2$4 = Barcode$1;
var _Barcode3$4 = _interopRequireDefault$i(_Barcode2$4);
function _interopRequireDefault$i(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$e(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$a(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$a(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var MSI = function(_Barcode) {
  _inherits$a(MSI2, _Barcode);
  function MSI2(data, options) {
    _classCallCheck$e(this, MSI2);
    return _possibleConstructorReturn$a(this, (MSI2.__proto__ || Object.getPrototypeOf(MSI2)).call(this, data, options));
  }
  _createClass$9(MSI2, [{
    key: "encode",
    value: function encode3() {
      var ret = "110";
      for (var i = 0; i < this.data.length; i++) {
        var digit = parseInt(this.data[i]);
        var bin = digit.toString(2);
        bin = addZeroes(bin, 4 - bin.length);
        for (var b = 0; b < bin.length; b++) {
          ret += bin[b] == "0" ? "100" : "110";
        }
      }
      ret += "1001";
      return {
        data: ret,
        text: this.text
      };
    }
  }, {
    key: "valid",
    value: function valid2() {
      return this.data.search(/^[0-9]+$/) !== -1;
    }
  }]);
  return MSI2;
}(_Barcode3$4.default);
function addZeroes(number, n) {
  for (var i = 0; i < n; i++) {
    number = "0" + number;
  }
  return number;
}
MSI$1.default = MSI;
var MSI10$1 = {};
var checksums = {};
Object.defineProperty(checksums, "__esModule", {
  value: true
});
checksums.mod10 = mod10;
checksums.mod11 = mod11;
function mod10(number) {
  var sum = 0;
  for (var i = 0; i < number.length; i++) {
    var n = parseInt(number[i]);
    if ((i + number.length) % 2 === 0) {
      sum += n;
    } else {
      sum += n * 2 % 10 + Math.floor(n * 2 / 10);
    }
  }
  return (10 - sum % 10) % 10;
}
function mod11(number) {
  var sum = 0;
  var weights = [2, 3, 4, 5, 6, 7];
  for (var i = 0; i < number.length; i++) {
    var n = parseInt(number[number.length - 1 - i]);
    sum += weights[i % weights.length] * n;
  }
  return (11 - sum % 11) % 11;
}
Object.defineProperty(MSI10$1, "__esModule", {
  value: true
});
var _MSI2$4 = MSI$1;
var _MSI3$4 = _interopRequireDefault$h(_MSI2$4);
var _checksums$3 = checksums;
function _interopRequireDefault$h(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$d(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$9(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$9(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var MSI10 = function(_MSI11) {
  _inherits$9(MSI102, _MSI11);
  function MSI102(data, options) {
    _classCallCheck$d(this, MSI102);
    return _possibleConstructorReturn$9(this, (MSI102.__proto__ || Object.getPrototypeOf(MSI102)).call(this, data + (0, _checksums$3.mod10)(data), options));
  }
  return MSI102;
}(_MSI3$4.default);
MSI10$1.default = MSI10;
var MSI11$1 = {};
Object.defineProperty(MSI11$1, "__esModule", {
  value: true
});
var _MSI2$3 = MSI$1;
var _MSI3$3 = _interopRequireDefault$g(_MSI2$3);
var _checksums$2 = checksums;
function _interopRequireDefault$g(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$c(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$8(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$8(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var MSI11 = function(_MSI11) {
  _inherits$8(MSI112, _MSI11);
  function MSI112(data, options) {
    _classCallCheck$c(this, MSI112);
    return _possibleConstructorReturn$8(this, (MSI112.__proto__ || Object.getPrototypeOf(MSI112)).call(this, data + (0, _checksums$2.mod11)(data), options));
  }
  return MSI112;
}(_MSI3$3.default);
MSI11$1.default = MSI11;
var MSI1010$1 = {};
Object.defineProperty(MSI1010$1, "__esModule", {
  value: true
});
var _MSI2$2 = MSI$1;
var _MSI3$2 = _interopRequireDefault$f(_MSI2$2);
var _checksums$1 = checksums;
function _interopRequireDefault$f(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$b(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$7(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$7(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var MSI1010 = function(_MSI11) {
  _inherits$7(MSI10102, _MSI11);
  function MSI10102(data, options) {
    _classCallCheck$b(this, MSI10102);
    data += (0, _checksums$1.mod10)(data);
    data += (0, _checksums$1.mod10)(data);
    return _possibleConstructorReturn$7(this, (MSI10102.__proto__ || Object.getPrototypeOf(MSI10102)).call(this, data, options));
  }
  return MSI10102;
}(_MSI3$2.default);
MSI1010$1.default = MSI1010;
var MSI1110$1 = {};
Object.defineProperty(MSI1110$1, "__esModule", {
  value: true
});
var _MSI2$1 = MSI$1;
var _MSI3$1 = _interopRequireDefault$e(_MSI2$1);
var _checksums = checksums;
function _interopRequireDefault$e(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$a(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$6(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$6(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var MSI1110 = function(_MSI11) {
  _inherits$6(MSI11102, _MSI11);
  function MSI11102(data, options) {
    _classCallCheck$a(this, MSI11102);
    data += (0, _checksums.mod11)(data);
    data += (0, _checksums.mod10)(data);
    return _possibleConstructorReturn$6(this, (MSI11102.__proto__ || Object.getPrototypeOf(MSI11102)).call(this, data, options));
  }
  return MSI11102;
}(_MSI3$1.default);
MSI1110$1.default = MSI1110;
Object.defineProperty(MSI$2, "__esModule", {
  value: true
});
MSI$2.MSI1110 = MSI$2.MSI1010 = MSI$2.MSI11 = MSI$2.MSI10 = MSI$2.MSI = void 0;
var _MSI$1 = MSI$1;
var _MSI2 = _interopRequireDefault$d(_MSI$1);
var _MSI3 = MSI10$1;
var _MSI4 = _interopRequireDefault$d(_MSI3);
var _MSI5 = MSI11$1;
var _MSI6 = _interopRequireDefault$d(_MSI5);
var _MSI7 = MSI1010$1;
var _MSI8 = _interopRequireDefault$d(_MSI7);
var _MSI9 = MSI1110$1;
var _MSI10 = _interopRequireDefault$d(_MSI9);
function _interopRequireDefault$d(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
MSI$2.MSI = _MSI2.default;
MSI$2.MSI10 = _MSI4.default;
MSI$2.MSI11 = _MSI6.default;
MSI$2.MSI1010 = _MSI8.default;
MSI$2.MSI1110 = _MSI10.default;
var pharmacode$1 = {};
Object.defineProperty(pharmacode$1, "__esModule", {
  value: true
});
pharmacode$1.pharmacode = void 0;
var _createClass$8 = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _Barcode2$3 = Barcode$1;
var _Barcode3$3 = _interopRequireDefault$c(_Barcode2$3);
function _interopRequireDefault$c(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$9(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$5(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$5(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var pharmacode = function(_Barcode) {
  _inherits$5(pharmacode2, _Barcode);
  function pharmacode2(data, options) {
    _classCallCheck$9(this, pharmacode2);
    var _this = _possibleConstructorReturn$5(this, (pharmacode2.__proto__ || Object.getPrototypeOf(pharmacode2)).call(this, data, options));
    _this.number = parseInt(data, 10);
    return _this;
  }
  _createClass$8(pharmacode2, [{
    key: "encode",
    value: function encode3() {
      var z = this.number;
      var result = "";
      while (!isNaN(z) && z != 0) {
        if (z % 2 === 0) {
          result = "11100" + result;
          z = (z - 2) / 2;
        } else {
          result = "100" + result;
          z = (z - 1) / 2;
        }
      }
      result = result.slice(0, -2);
      return {
        data: result,
        text: this.text
      };
    }
  }, {
    key: "valid",
    value: function valid2() {
      return this.number >= 3 && this.number <= 131070;
    }
  }]);
  return pharmacode2;
}(_Barcode3$3.default);
pharmacode$1.pharmacode = pharmacode;
var codabar$1 = {};
Object.defineProperty(codabar$1, "__esModule", {
  value: true
});
codabar$1.codabar = void 0;
var _createClass$7 = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _Barcode2$2 = Barcode$1;
var _Barcode3$2 = _interopRequireDefault$b(_Barcode2$2);
function _interopRequireDefault$b(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$8(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$4(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$4(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var codabar = function(_Barcode) {
  _inherits$4(codabar2, _Barcode);
  function codabar2(data, options) {
    _classCallCheck$8(this, codabar2);
    if (data.search(/^[0-9\-\$\:\.\+\/]+$/) === 0) {
      data = "A" + data + "A";
    }
    var _this = _possibleConstructorReturn$4(this, (codabar2.__proto__ || Object.getPrototypeOf(codabar2)).call(this, data.toUpperCase(), options));
    _this.text = _this.options.text || _this.text.replace(/[A-D]/g, "");
    return _this;
  }
  _createClass$7(codabar2, [{
    key: "valid",
    value: function valid2() {
      return this.data.search(/^[A-D][0-9\-\$\:\.\+\/]+[A-D]$/) !== -1;
    }
  }, {
    key: "encode",
    value: function encode3() {
      var result = [];
      var encodings2 = this.getEncodings();
      for (var i = 0; i < this.data.length; i++) {
        result.push(encodings2[this.data.charAt(i)]);
        if (i !== this.data.length - 1) {
          result.push("0");
        }
      }
      return {
        text: this.text,
        data: result.join("")
      };
    }
  }, {
    key: "getEncodings",
    value: function getEncodings() {
      return {
        "0": "101010011",
        "1": "101011001",
        "2": "101001011",
        "3": "110010101",
        "4": "101101001",
        "5": "110101001",
        "6": "100101011",
        "7": "100101101",
        "8": "100110101",
        "9": "110100101",
        "-": "101001101",
        "$": "101100101",
        ":": "1101011011",
        "/": "1101101011",
        ".": "1101101101",
        "+": "1011011011",
        "A": "1011001001",
        "B": "1001001011",
        "C": "1010010011",
        "D": "1010011001"
      };
    }
  }]);
  return codabar2;
}(_Barcode3$2.default);
codabar$1.codabar = codabar;
var CODE93$2 = {};
var CODE93$1 = {};
var constants = {};
Object.defineProperty(constants, "__esModule", {
  value: true
});
constants.SYMBOLS = [
  "0",
  "1",
  "2",
  "3",
  "4",
  "5",
  "6",
  "7",
  "8",
  "9",
  "A",
  "B",
  "C",
  "D",
  "E",
  "F",
  "G",
  "H",
  "I",
  "J",
  "K",
  "L",
  "M",
  "N",
  "O",
  "P",
  "Q",
  "R",
  "S",
  "T",
  "U",
  "V",
  "W",
  "X",
  "Y",
  "Z",
  "-",
  ".",
  " ",
  "$",
  "/",
  "+",
  "%",
  // Only used for csum and multi-symbols character encodings
  "($)",
  "(%)",
  "(/)",
  "(+)",
  // Start/Stop
  "ÿ"
];
constants.BINARIES = ["100010100", "101001000", "101000100", "101000010", "100101000", "100100100", "100100010", "101010000", "100010010", "100001010", "110101000", "110100100", "110100010", "110010100", "110010010", "110001010", "101101000", "101100100", "101100010", "100110100", "100011010", "101011000", "101001100", "101000110", "100101100", "100010110", "110110100", "110110010", "110101100", "110100110", "110010110", "110011010", "101101100", "101100110", "100110110", "100111010", "100101110", "111010100", "111010010", "111001010", "101101110", "101110110", "110101110", "100100110", "111011010", "111010110", "100110010", "101011110"];
constants.MULTI_SYMBOLS = {
  "\0": ["(%)", "U"],
  "": ["($)", "A"],
  "": ["($)", "B"],
  "": ["($)", "C"],
  "": ["($)", "D"],
  "": ["($)", "E"],
  "": ["($)", "F"],
  "\x07": ["($)", "G"],
  "\b": ["($)", "H"],
  "	": ["($)", "I"],
  "\n": ["($)", "J"],
  "\v": ["($)", "K"],
  "\f": ["($)", "L"],
  "\r": ["($)", "M"],
  "": ["($)", "N"],
  "": ["($)", "O"],
  "": ["($)", "P"],
  "": ["($)", "Q"],
  "": ["($)", "R"],
  "": ["($)", "S"],
  "": ["($)", "T"],
  "": ["($)", "U"],
  "": ["($)", "V"],
  "": ["($)", "W"],
  "": ["($)", "X"],
  "": ["($)", "Y"],
  "": ["($)", "Z"],
  "\x1B": ["(%)", "A"],
  "": ["(%)", "B"],
  "": ["(%)", "C"],
  "": ["(%)", "D"],
  "": ["(%)", "E"],
  "!": ["(/)", "A"],
  '"': ["(/)", "B"],
  "#": ["(/)", "C"],
  "&": ["(/)", "F"],
  "'": ["(/)", "G"],
  "(": ["(/)", "H"],
  ")": ["(/)", "I"],
  "*": ["(/)", "J"],
  ",": ["(/)", "L"],
  ":": ["(/)", "Z"],
  ";": ["(%)", "F"],
  "<": ["(%)", "G"],
  "=": ["(%)", "H"],
  ">": ["(%)", "I"],
  "?": ["(%)", "J"],
  "@": ["(%)", "V"],
  "[": ["(%)", "K"],
  "\\": ["(%)", "L"],
  "]": ["(%)", "M"],
  "^": ["(%)", "N"],
  "_": ["(%)", "O"],
  "`": ["(%)", "W"],
  "a": ["(+)", "A"],
  "b": ["(+)", "B"],
  "c": ["(+)", "C"],
  "d": ["(+)", "D"],
  "e": ["(+)", "E"],
  "f": ["(+)", "F"],
  "g": ["(+)", "G"],
  "h": ["(+)", "H"],
  "i": ["(+)", "I"],
  "j": ["(+)", "J"],
  "k": ["(+)", "K"],
  "l": ["(+)", "L"],
  "m": ["(+)", "M"],
  "n": ["(+)", "N"],
  "o": ["(+)", "O"],
  "p": ["(+)", "P"],
  "q": ["(+)", "Q"],
  "r": ["(+)", "R"],
  "s": ["(+)", "S"],
  "t": ["(+)", "T"],
  "u": ["(+)", "U"],
  "v": ["(+)", "V"],
  "w": ["(+)", "W"],
  "x": ["(+)", "X"],
  "y": ["(+)", "Y"],
  "z": ["(+)", "Z"],
  "{": ["(%)", "P"],
  "|": ["(%)", "Q"],
  "}": ["(%)", "R"],
  "~": ["(%)", "S"],
  "": ["(%)", "T"]
};
Object.defineProperty(CODE93$1, "__esModule", {
  value: true
});
var _createClass$6 = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _constants = constants;
var _Barcode2$1 = Barcode$1;
var _Barcode3$1 = _interopRequireDefault$a(_Barcode2$1);
function _interopRequireDefault$a(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$7(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$3(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$3(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var CODE93 = function(_Barcode) {
  _inherits$3(CODE932, _Barcode);
  function CODE932(data, options) {
    _classCallCheck$7(this, CODE932);
    return _possibleConstructorReturn$3(this, (CODE932.__proto__ || Object.getPrototypeOf(CODE932)).call(this, data, options));
  }
  _createClass$6(CODE932, [{
    key: "valid",
    value: function valid2() {
      return /^[0-9A-Z\-. $/+%]+$/.test(this.data);
    }
  }, {
    key: "encode",
    value: function encode3() {
      var symbols = this.data.split("").flatMap(function(c) {
        return _constants.MULTI_SYMBOLS[c] || c;
      });
      var encoded = symbols.map(function(s) {
        return CODE932.getEncoding(s);
      }).join("");
      var csumC = CODE932.checksum(symbols, 20);
      var csumK = CODE932.checksum(symbols.concat(csumC), 15);
      return {
        text: this.text,
        data: (
          // Add the start bits
          CODE932.getEncoding("ÿ") + // Add the encoded bits
          encoded + // Add the checksum
          CODE932.getEncoding(csumC) + CODE932.getEncoding(csumK) + // Add the stop bits
          CODE932.getEncoding("ÿ") + // Add the termination bit
          "1"
        )
      };
    }
    // Get the binary encoding of a symbol
  }], [{
    key: "getEncoding",
    value: function getEncoding2(symbol) {
      return _constants.BINARIES[CODE932.symbolValue(symbol)];
    }
    // Get the symbol for a symbol value
  }, {
    key: "getSymbol",
    value: function getSymbol(symbolValue) {
      return _constants.SYMBOLS[symbolValue];
    }
    // Get the symbol value of a symbol
  }, {
    key: "symbolValue",
    value: function symbolValue(symbol) {
      return _constants.SYMBOLS.indexOf(symbol);
    }
    // Calculate a checksum symbol
  }, {
    key: "checksum",
    value: function checksum6(symbols, maxWeight) {
      var csum = symbols.slice().reverse().reduce(function(sum, symbol, idx) {
        var weight = idx % maxWeight + 1;
        return sum + CODE932.symbolValue(symbol) * weight;
      }, 0);
      return CODE932.getSymbol(csum % 47);
    }
  }]);
  return CODE932;
}(_Barcode3$1.default);
CODE93$1.default = CODE93;
var CODE93FullASCII$1 = {};
Object.defineProperty(CODE93FullASCII$1, "__esModule", {
  value: true
});
var _createClass$5 = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _CODE2$2 = CODE93$1;
var _CODE3$1 = _interopRequireDefault$9(_CODE2$2);
function _interopRequireDefault$9(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$6(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$2(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$2(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var CODE93FullASCII = function(_CODE4) {
  _inherits$2(CODE93FullASCII2, _CODE4);
  function CODE93FullASCII2(data, options) {
    _classCallCheck$6(this, CODE93FullASCII2);
    return _possibleConstructorReturn$2(this, (CODE93FullASCII2.__proto__ || Object.getPrototypeOf(CODE93FullASCII2)).call(this, data, options));
  }
  _createClass$5(CODE93FullASCII2, [{
    key: "valid",
    value: function valid2() {
      return /^[\x00-\x7f]+$/.test(this.data);
    }
  }]);
  return CODE93FullASCII2;
}(_CODE3$1.default);
CODE93FullASCII$1.default = CODE93FullASCII;
Object.defineProperty(CODE93$2, "__esModule", {
  value: true
});
CODE93$2.CODE93FullASCII = CODE93$2.CODE93 = void 0;
var _CODE$1 = CODE93$1;
var _CODE2$1 = _interopRequireDefault$8(_CODE$1);
var _CODE93FullASCII = CODE93FullASCII$1;
var _CODE93FullASCII2 = _interopRequireDefault$8(_CODE93FullASCII);
function _interopRequireDefault$8(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
CODE93$2.CODE93 = _CODE2$1.default;
CODE93$2.CODE93FullASCII = _CODE93FullASCII2.default;
var GenericBarcode$1 = {};
Object.defineProperty(GenericBarcode$1, "__esModule", {
  value: true
});
GenericBarcode$1.GenericBarcode = void 0;
var _createClass$4 = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _Barcode2 = Barcode$1;
var _Barcode3 = _interopRequireDefault$7(_Barcode2);
function _interopRequireDefault$7(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$5(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$1(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits$1(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var GenericBarcode = function(_Barcode) {
  _inherits$1(GenericBarcode2, _Barcode);
  function GenericBarcode2(data, options) {
    _classCallCheck$5(this, GenericBarcode2);
    return _possibleConstructorReturn$1(this, (GenericBarcode2.__proto__ || Object.getPrototypeOf(GenericBarcode2)).call(this, data, options));
  }
  _createClass$4(GenericBarcode2, [{
    key: "encode",
    value: function encode3() {
      return {
        data: "10101010101010101010101010101010101010101",
        text: this.text
      };
    }
    // Resturn true/false if the string provided is valid for this encoder
  }, {
    key: "valid",
    value: function valid2() {
      return true;
    }
  }]);
  return GenericBarcode2;
}(_Barcode3.default);
GenericBarcode$1.GenericBarcode = GenericBarcode;
Object.defineProperty(barcodes, "__esModule", {
  value: true
});
var _CODE = CODE39$1;
var _CODE2 = CODE128$2;
var _EAN_UPC = EAN_UPC;
var _ITF = ITF$2;
var _MSI = MSI$2;
var _pharmacode = pharmacode$1;
var _codabar = codabar$1;
var _CODE3 = CODE93$2;
var _GenericBarcode = GenericBarcode$1;
barcodes.default = {
  CODE39: _CODE.CODE39,
  CODE128: _CODE2.CODE128,
  CODE128A: _CODE2.CODE128A,
  CODE128B: _CODE2.CODE128B,
  CODE128C: _CODE2.CODE128C,
  EAN13: _EAN_UPC.EAN13,
  EAN8: _EAN_UPC.EAN8,
  EAN5: _EAN_UPC.EAN5,
  EAN2: _EAN_UPC.EAN2,
  UPC: _EAN_UPC.UPC,
  UPCE: _EAN_UPC.UPCE,
  ITF14: _ITF.ITF14,
  ITF: _ITF.ITF,
  MSI: _MSI.MSI,
  MSI10: _MSI.MSI10,
  MSI11: _MSI.MSI11,
  MSI1010: _MSI.MSI1010,
  MSI1110: _MSI.MSI1110,
  pharmacode: _pharmacode.pharmacode,
  codabar: _codabar.codabar,
  CODE93: _CODE3.CODE93,
  CODE93FullASCII: _CODE3.CODE93FullASCII,
  GenericBarcode: _GenericBarcode.GenericBarcode
};
var merge = {};
Object.defineProperty(merge, "__esModule", {
  value: true
});
var _extends = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
merge.default = function(old, replaceObj) {
  return _extends({}, old, replaceObj);
};
var linearizeEncodings$1 = {};
Object.defineProperty(linearizeEncodings$1, "__esModule", {
  value: true
});
linearizeEncodings$1.default = linearizeEncodings;
function linearizeEncodings(encodings2) {
  var linearEncodings = [];
  function nextLevel(encoded) {
    if (Array.isArray(encoded)) {
      for (var i = 0; i < encoded.length; i++) {
        nextLevel(encoded[i]);
      }
    } else {
      encoded.text = encoded.text || "";
      encoded.data = encoded.data || "";
      linearEncodings.push(encoded);
    }
  }
  nextLevel(encodings2);
  return linearEncodings;
}
var fixOptions$1 = {};
Object.defineProperty(fixOptions$1, "__esModule", {
  value: true
});
fixOptions$1.default = fixOptions;
function fixOptions(options) {
  options.marginTop = options.marginTop || options.margin;
  options.marginBottom = options.marginBottom || options.margin;
  options.marginRight = options.marginRight || options.margin;
  options.marginLeft = options.marginLeft || options.margin;
  return options;
}
var getRenderProperties$1 = {};
var getOptionsFromElement$1 = {};
var optionsFromStrings$1 = {};
Object.defineProperty(optionsFromStrings$1, "__esModule", {
  value: true
});
optionsFromStrings$1.default = optionsFromStrings;
function optionsFromStrings(options) {
  var intOptions = ["width", "height", "textMargin", "fontSize", "margin", "marginTop", "marginBottom", "marginLeft", "marginRight"];
  for (var intOption in intOptions) {
    if (intOptions.hasOwnProperty(intOption)) {
      intOption = intOptions[intOption];
      if (typeof options[intOption] === "string") {
        options[intOption] = parseInt(options[intOption], 10);
      }
    }
  }
  if (typeof options["displayValue"] === "string") {
    options["displayValue"] = options["displayValue"] != "false";
  }
  return options;
}
var defaults$1 = {};
Object.defineProperty(defaults$1, "__esModule", {
  value: true
});
var defaults = {
  width: 2,
  height: 100,
  format: "auto",
  displayValue: true,
  fontOptions: "",
  font: "monospace",
  text: void 0,
  textAlign: "center",
  textPosition: "bottom",
  textMargin: 2,
  fontSize: 20,
  background: "#ffffff",
  lineColor: "#000000",
  margin: 10,
  marginTop: void 0,
  marginBottom: void 0,
  marginLeft: void 0,
  marginRight: void 0,
  valid: function valid() {
  }
};
defaults$1.default = defaults;
Object.defineProperty(getOptionsFromElement$1, "__esModule", {
  value: true
});
var _optionsFromStrings$1 = optionsFromStrings$1;
var _optionsFromStrings2$1 = _interopRequireDefault$6(_optionsFromStrings$1);
var _defaults$1 = defaults$1;
var _defaults2$1 = _interopRequireDefault$6(_defaults$1);
function _interopRequireDefault$6(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function getOptionsFromElement(element2) {
  var options = {};
  for (var property in _defaults2$1.default) {
    if (_defaults2$1.default.hasOwnProperty(property)) {
      if (element2.hasAttribute("jsbarcode-" + property.toLowerCase())) {
        options[property] = element2.getAttribute("jsbarcode-" + property.toLowerCase());
      }
      if (element2.hasAttribute("data-" + property.toLowerCase())) {
        options[property] = element2.getAttribute("data-" + property.toLowerCase());
      }
    }
  }
  options["value"] = element2.getAttribute("jsbarcode-value") || element2.getAttribute("data-value");
  options = (0, _optionsFromStrings2$1.default)(options);
  return options;
}
getOptionsFromElement$1.default = getOptionsFromElement;
var renderers = {};
var canvas = {};
var shared = {};
Object.defineProperty(shared, "__esModule", {
  value: true
});
shared.getTotalWidthOfEncodings = shared.calculateEncodingAttributes = shared.getBarcodePadding = shared.getEncodingHeight = shared.getMaximumHeightOfEncodings = void 0;
var _merge$3 = merge;
var _merge2$3 = _interopRequireDefault$5(_merge$3);
function _interopRequireDefault$5(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function getEncodingHeight(encoding, options) {
  return options.height + (options.displayValue && encoding.text.length > 0 ? options.fontSize + options.textMargin : 0) + options.marginTop + options.marginBottom;
}
function getBarcodePadding(textWidth, barcodeWidth, options) {
  if (options.displayValue && barcodeWidth < textWidth) {
    if (options.textAlign == "center") {
      return Math.floor((textWidth - barcodeWidth) / 2);
    } else if (options.textAlign == "left") {
      return 0;
    } else if (options.textAlign == "right") {
      return Math.floor(textWidth - barcodeWidth);
    }
  }
  return 0;
}
function calculateEncodingAttributes(encodings2, barcodeOptions, context) {
  for (var i = 0; i < encodings2.length; i++) {
    var encoding = encodings2[i];
    var options = (0, _merge2$3.default)(barcodeOptions, encoding.options);
    var textWidth;
    if (options.displayValue) {
      textWidth = messureText(encoding.text, options, context);
    } else {
      textWidth = 0;
    }
    var barcodeWidth = encoding.data.length * options.width;
    encoding.width = Math.ceil(Math.max(textWidth, barcodeWidth));
    encoding.height = getEncodingHeight(encoding, options);
    encoding.barcodePadding = getBarcodePadding(textWidth, barcodeWidth, options);
  }
}
function getTotalWidthOfEncodings(encodings2) {
  var totalWidth = 0;
  for (var i = 0; i < encodings2.length; i++) {
    totalWidth += encodings2[i].width;
  }
  return totalWidth;
}
function getMaximumHeightOfEncodings(encodings2) {
  var maxHeight = 0;
  for (var i = 0; i < encodings2.length; i++) {
    if (encodings2[i].height > maxHeight) {
      maxHeight = encodings2[i].height;
    }
  }
  return maxHeight;
}
function messureText(string, options, context) {
  var ctx;
  if (context) {
    ctx = context;
  } else if (typeof document !== "undefined") {
    ctx = document.createElement("canvas").getContext("2d");
  } else {
    return 0;
  }
  ctx.font = options.fontOptions + " " + options.fontSize + "px " + options.font;
  var measureTextResult = ctx.measureText(string);
  if (!measureTextResult) {
    return 0;
  }
  var size = measureTextResult.width;
  return size;
}
shared.getMaximumHeightOfEncodings = getMaximumHeightOfEncodings;
shared.getEncodingHeight = getEncodingHeight;
shared.getBarcodePadding = getBarcodePadding;
shared.calculateEncodingAttributes = calculateEncodingAttributes;
shared.getTotalWidthOfEncodings = getTotalWidthOfEncodings;
Object.defineProperty(canvas, "__esModule", {
  value: true
});
var _createClass$3 = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _merge$2 = merge;
var _merge2$2 = _interopRequireDefault$4(_merge$2);
var _shared$1 = shared;
function _interopRequireDefault$4(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$4(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
var CanvasRenderer = function() {
  function CanvasRenderer2(canvas2, encodings2, options) {
    _classCallCheck$4(this, CanvasRenderer2);
    this.canvas = canvas2;
    this.encodings = encodings2;
    this.options = options;
  }
  _createClass$3(CanvasRenderer2, [{
    key: "render",
    value: function render2() {
      if (!this.canvas.getContext) {
        throw new Error("The browser does not support canvas.");
      }
      this.prepareCanvas();
      for (var i = 0; i < this.encodings.length; i++) {
        var encodingOptions = (0, _merge2$2.default)(this.options, this.encodings[i].options);
        this.drawCanvasBarcode(encodingOptions, this.encodings[i]);
        this.drawCanvasText(encodingOptions, this.encodings[i]);
        this.moveCanvasDrawing(this.encodings[i]);
      }
      this.restoreCanvas();
    }
  }, {
    key: "prepareCanvas",
    value: function prepareCanvas() {
      var ctx = this.canvas.getContext("2d");
      ctx.save();
      (0, _shared$1.calculateEncodingAttributes)(this.encodings, this.options, ctx);
      var totalWidth = (0, _shared$1.getTotalWidthOfEncodings)(this.encodings);
      var maxHeight = (0, _shared$1.getMaximumHeightOfEncodings)(this.encodings);
      this.canvas.width = totalWidth + this.options.marginLeft + this.options.marginRight;
      this.canvas.height = maxHeight;
      ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      if (this.options.background) {
        ctx.fillStyle = this.options.background;
        ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
      }
      ctx.translate(this.options.marginLeft, 0);
    }
  }, {
    key: "drawCanvasBarcode",
    value: function drawCanvasBarcode(options, encoding) {
      var ctx = this.canvas.getContext("2d");
      var binary = encoding.data;
      var yFrom;
      if (options.textPosition == "top") {
        yFrom = options.marginTop + options.fontSize + options.textMargin;
      } else {
        yFrom = options.marginTop;
      }
      ctx.fillStyle = options.lineColor;
      for (var b = 0; b < binary.length; b++) {
        var x = b * options.width + encoding.barcodePadding;
        if (binary[b] === "1") {
          ctx.fillRect(x, yFrom, options.width, options.height);
        } else if (binary[b]) {
          ctx.fillRect(x, yFrom, options.width, options.height * binary[b]);
        }
      }
    }
  }, {
    key: "drawCanvasText",
    value: function drawCanvasText(options, encoding) {
      var ctx = this.canvas.getContext("2d");
      var font = options.fontOptions + " " + options.fontSize + "px " + options.font;
      if (options.displayValue) {
        var x, y;
        if (options.textPosition == "top") {
          y = options.marginTop + options.fontSize - options.textMargin;
        } else {
          y = options.height + options.textMargin + options.marginTop + options.fontSize;
        }
        ctx.font = font;
        if (options.textAlign == "left" || encoding.barcodePadding > 0) {
          x = 0;
          ctx.textAlign = "left";
        } else if (options.textAlign == "right") {
          x = encoding.width - 1;
          ctx.textAlign = "right";
        } else {
          x = encoding.width / 2;
          ctx.textAlign = "center";
        }
        ctx.fillText(encoding.text, x, y);
      }
    }
  }, {
    key: "moveCanvasDrawing",
    value: function moveCanvasDrawing(encoding) {
      var ctx = this.canvas.getContext("2d");
      ctx.translate(encoding.width, 0);
    }
  }, {
    key: "restoreCanvas",
    value: function restoreCanvas() {
      var ctx = this.canvas.getContext("2d");
      ctx.restore();
    }
  }]);
  return CanvasRenderer2;
}();
canvas.default = CanvasRenderer;
var svg = {};
Object.defineProperty(svg, "__esModule", {
  value: true
});
var _createClass$2 = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
var _merge$1 = merge;
var _merge2$1 = _interopRequireDefault$3(_merge$1);
var _shared = shared;
function _interopRequireDefault$3(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _classCallCheck$3(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
var svgns = "http://www.w3.org/2000/svg";
var SVGRenderer = function() {
  function SVGRenderer2(svg2, encodings2, options) {
    _classCallCheck$3(this, SVGRenderer2);
    this.svg = svg2;
    this.encodings = encodings2;
    this.options = options;
    this.document = options.xmlDocument || document;
  }
  _createClass$2(SVGRenderer2, [{
    key: "render",
    value: function render2() {
      var currentX = this.options.marginLeft;
      this.prepareSVG();
      for (var i = 0; i < this.encodings.length; i++) {
        var encoding = this.encodings[i];
        var encodingOptions = (0, _merge2$1.default)(this.options, encoding.options);
        var group = this.createGroup(currentX, encodingOptions.marginTop, this.svg);
        this.setGroupOptions(group, encodingOptions);
        this.drawSvgBarcode(group, encodingOptions, encoding);
        this.drawSVGText(group, encodingOptions, encoding);
        currentX += encoding.width;
      }
    }
  }, {
    key: "prepareSVG",
    value: function prepareSVG() {
      while (this.svg.firstChild) {
        this.svg.removeChild(this.svg.firstChild);
      }
      (0, _shared.calculateEncodingAttributes)(this.encodings, this.options);
      var totalWidth = (0, _shared.getTotalWidthOfEncodings)(this.encodings);
      var maxHeight = (0, _shared.getMaximumHeightOfEncodings)(this.encodings);
      var width = totalWidth + this.options.marginLeft + this.options.marginRight;
      this.setSvgAttributes(width, maxHeight);
      if (this.options.background) {
        this.drawRect(0, 0, width, maxHeight, this.svg).setAttribute("style", "fill:" + this.options.background + ";");
      }
    }
  }, {
    key: "drawSvgBarcode",
    value: function drawSvgBarcode(parent, options, encoding) {
      var binary = encoding.data;
      var yFrom;
      if (options.textPosition == "top") {
        yFrom = options.fontSize + options.textMargin;
      } else {
        yFrom = 0;
      }
      var barWidth = 0;
      var x = 0;
      for (var b = 0; b < binary.length; b++) {
        x = b * options.width + encoding.barcodePadding;
        if (binary[b] === "1") {
          barWidth++;
        } else if (barWidth > 0) {
          this.drawRect(x - options.width * barWidth, yFrom, options.width * barWidth, options.height, parent);
          barWidth = 0;
        }
      }
      if (barWidth > 0) {
        this.drawRect(x - options.width * (barWidth - 1), yFrom, options.width * barWidth, options.height, parent);
      }
    }
  }, {
    key: "drawSVGText",
    value: function drawSVGText(parent, options, encoding) {
      var textElem = this.document.createElementNS(svgns, "text");
      if (options.displayValue) {
        var x, y;
        textElem.setAttribute("style", "font:" + options.fontOptions + " " + options.fontSize + "px " + options.font);
        if (options.textPosition == "top") {
          y = options.fontSize - options.textMargin;
        } else {
          y = options.height + options.textMargin + options.fontSize;
        }
        if (options.textAlign == "left" || encoding.barcodePadding > 0) {
          x = 0;
          textElem.setAttribute("text-anchor", "start");
        } else if (options.textAlign == "right") {
          x = encoding.width - 1;
          textElem.setAttribute("text-anchor", "end");
        } else {
          x = encoding.width / 2;
          textElem.setAttribute("text-anchor", "middle");
        }
        textElem.setAttribute("x", x);
        textElem.setAttribute("y", y);
        textElem.appendChild(this.document.createTextNode(encoding.text));
        parent.appendChild(textElem);
      }
    }
  }, {
    key: "setSvgAttributes",
    value: function setSvgAttributes(width, height) {
      var svg2 = this.svg;
      svg2.setAttribute("width", width + "px");
      svg2.setAttribute("height", height + "px");
      svg2.setAttribute("x", "0px");
      svg2.setAttribute("y", "0px");
      svg2.setAttribute("viewBox", "0 0 " + width + " " + height);
      svg2.setAttribute("xmlns", svgns);
      svg2.setAttribute("version", "1.1");
      svg2.setAttribute("style", "transform: translate(0,0)");
    }
  }, {
    key: "createGroup",
    value: function createGroup(x, y, parent) {
      var group = this.document.createElementNS(svgns, "g");
      group.setAttribute("transform", "translate(" + x + ", " + y + ")");
      parent.appendChild(group);
      return group;
    }
  }, {
    key: "setGroupOptions",
    value: function setGroupOptions(group, options) {
      group.setAttribute("style", "fill:" + options.lineColor + ";");
    }
  }, {
    key: "drawRect",
    value: function drawRect(x, y, width, height, parent) {
      var rect = this.document.createElementNS(svgns, "rect");
      rect.setAttribute("x", x);
      rect.setAttribute("y", y);
      rect.setAttribute("width", width);
      rect.setAttribute("height", height);
      parent.appendChild(rect);
      return rect;
    }
  }]);
  return SVGRenderer2;
}();
svg.default = SVGRenderer;
var object = {};
Object.defineProperty(object, "__esModule", {
  value: true
});
var _createClass$1 = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
function _classCallCheck$2(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
var ObjectRenderer = function() {
  function ObjectRenderer2(object2, encodings2, options) {
    _classCallCheck$2(this, ObjectRenderer2);
    this.object = object2;
    this.encodings = encodings2;
    this.options = options;
  }
  _createClass$1(ObjectRenderer2, [{
    key: "render",
    value: function render2() {
      this.object.encodings = this.encodings;
    }
  }]);
  return ObjectRenderer2;
}();
object.default = ObjectRenderer;
Object.defineProperty(renderers, "__esModule", {
  value: true
});
var _canvas = canvas;
var _canvas2 = _interopRequireDefault$2(_canvas);
var _svg = svg;
var _svg2 = _interopRequireDefault$2(_svg);
var _object = object;
var _object2 = _interopRequireDefault$2(_object);
function _interopRequireDefault$2(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
renderers.default = { CanvasRenderer: _canvas2.default, SVGRenderer: _svg2.default, ObjectRenderer: _object2.default };
var exceptions = {};
Object.defineProperty(exceptions, "__esModule", {
  value: true
});
function _classCallCheck$1(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var InvalidInputException = function(_Error) {
  _inherits(InvalidInputException2, _Error);
  function InvalidInputException2(symbology, input) {
    _classCallCheck$1(this, InvalidInputException2);
    var _this = _possibleConstructorReturn(this, (InvalidInputException2.__proto__ || Object.getPrototypeOf(InvalidInputException2)).call(this));
    _this.name = "InvalidInputException";
    _this.symbology = symbology;
    _this.input = input;
    _this.message = '"' + _this.input + '" is not a valid input for ' + _this.symbology;
    return _this;
  }
  return InvalidInputException2;
}(Error);
var InvalidElementException = function(_Error2) {
  _inherits(InvalidElementException2, _Error2);
  function InvalidElementException2() {
    _classCallCheck$1(this, InvalidElementException2);
    var _this2 = _possibleConstructorReturn(this, (InvalidElementException2.__proto__ || Object.getPrototypeOf(InvalidElementException2)).call(this));
    _this2.name = "InvalidElementException";
    _this2.message = "Not supported type to render on";
    return _this2;
  }
  return InvalidElementException2;
}(Error);
var NoElementException = function(_Error3) {
  _inherits(NoElementException2, _Error3);
  function NoElementException2() {
    _classCallCheck$1(this, NoElementException2);
    var _this3 = _possibleConstructorReturn(this, (NoElementException2.__proto__ || Object.getPrototypeOf(NoElementException2)).call(this));
    _this3.name = "NoElementException";
    _this3.message = "No element to render on.";
    return _this3;
  }
  return NoElementException2;
}(Error);
exceptions.InvalidInputException = InvalidInputException;
exceptions.InvalidElementException = InvalidElementException;
exceptions.NoElementException = NoElementException;
Object.defineProperty(getRenderProperties$1, "__esModule", {
  value: true
});
var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function(obj) {
  return typeof obj;
} : function(obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};
var _getOptionsFromElement = getOptionsFromElement$1;
var _getOptionsFromElement2 = _interopRequireDefault$1(_getOptionsFromElement);
var _renderers = renderers;
var _renderers2 = _interopRequireDefault$1(_renderers);
var _exceptions$1 = exceptions;
function _interopRequireDefault$1(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function getRenderProperties(element2) {
  if (typeof element2 === "string") {
    return querySelectedRenderProperties(element2);
  } else if (Array.isArray(element2)) {
    var returnArray = [];
    for (var i = 0; i < element2.length; i++) {
      returnArray.push(getRenderProperties(element2[i]));
    }
    return returnArray;
  } else if (typeof HTMLCanvasElement !== "undefined" && element2 instanceof HTMLImageElement) {
    return newCanvasRenderProperties(element2);
  } else if (element2 && element2.nodeName && element2.nodeName.toLowerCase() === "svg" || typeof SVGElement !== "undefined" && element2 instanceof SVGElement) {
    return {
      element: element2,
      options: (0, _getOptionsFromElement2.default)(element2),
      renderer: _renderers2.default.SVGRenderer
    };
  } else if (typeof HTMLCanvasElement !== "undefined" && element2 instanceof HTMLCanvasElement) {
    return {
      element: element2,
      options: (0, _getOptionsFromElement2.default)(element2),
      renderer: _renderers2.default.CanvasRenderer
    };
  } else if (element2 && element2.getContext) {
    return {
      element: element2,
      renderer: _renderers2.default.CanvasRenderer
    };
  } else if (element2 && (typeof element2 === "undefined" ? "undefined" : _typeof(element2)) === "object" && !element2.nodeName) {
    return {
      element: element2,
      renderer: _renderers2.default.ObjectRenderer
    };
  } else {
    throw new _exceptions$1.InvalidElementException();
  }
}
function querySelectedRenderProperties(string) {
  var selector = document.querySelectorAll(string);
  if (selector.length === 0) {
    return void 0;
  } else {
    var returnArray = [];
    for (var i = 0; i < selector.length; i++) {
      returnArray.push(getRenderProperties(selector[i]));
    }
    return returnArray;
  }
}
function newCanvasRenderProperties(imgElement) {
  var canvas2 = document.createElement("canvas");
  return {
    element: canvas2,
    options: (0, _getOptionsFromElement2.default)(imgElement),
    renderer: _renderers2.default.CanvasRenderer,
    afterRender: function afterRender() {
      imgElement.setAttribute("src", canvas2.toDataURL());
    }
  };
}
getRenderProperties$1.default = getRenderProperties;
var ErrorHandler$1 = {};
Object.defineProperty(ErrorHandler$1, "__esModule", {
  value: true
});
var _createClass = function() {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
function _classCallCheck(instance2, Constructor) {
  if (!(instance2 instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
var ErrorHandler = function() {
  function ErrorHandler2(api) {
    _classCallCheck(this, ErrorHandler2);
    this.api = api;
  }
  _createClass(ErrorHandler2, [{
    key: "handleCatch",
    value: function handleCatch(e) {
      if (e.name === "InvalidInputException") {
        if (this.api._options.valid !== this.api._defaults.valid) {
          this.api._options.valid(false);
        } else {
          throw e.message;
        }
      } else {
        throw e;
      }
      this.api.render = function() {
      };
    }
  }, {
    key: "wrapBarcodeCall",
    value: function wrapBarcodeCall(func) {
      try {
        var result = func.apply(void 0, arguments);
        this.api._options.valid(true);
        return result;
      } catch (e) {
        this.handleCatch(e);
        return this.api;
      }
    }
  }]);
  return ErrorHandler2;
}();
ErrorHandler$1.default = ErrorHandler;
var _barcodes = barcodes;
var _barcodes2 = _interopRequireDefault(_barcodes);
var _merge = merge;
var _merge2 = _interopRequireDefault(_merge);
var _linearizeEncodings = linearizeEncodings$1;
var _linearizeEncodings2 = _interopRequireDefault(_linearizeEncodings);
var _fixOptions = fixOptions$1;
var _fixOptions2 = _interopRequireDefault(_fixOptions);
var _getRenderProperties = getRenderProperties$1;
var _getRenderProperties2 = _interopRequireDefault(_getRenderProperties);
var _optionsFromStrings = optionsFromStrings$1;
var _optionsFromStrings2 = _interopRequireDefault(_optionsFromStrings);
var _ErrorHandler = ErrorHandler$1;
var _ErrorHandler2 = _interopRequireDefault(_ErrorHandler);
var _exceptions = exceptions;
var _defaults = defaults$1;
var _defaults2 = _interopRequireDefault(_defaults);
function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
var API = function API2() {
};
var JsBarcode = function JsBarcode2(element2, text2, options) {
  var api = new API();
  if (typeof element2 === "undefined") {
    throw Error("No element to render on was provided.");
  }
  api._renderProperties = (0, _getRenderProperties2.default)(element2);
  api._encodings = [];
  api._options = _defaults2.default;
  api._errorHandler = new _ErrorHandler2.default(api);
  if (typeof text2 !== "undefined") {
    options = options || {};
    if (!options.format) {
      options.format = autoSelectBarcode();
    }
    api.options(options)[options.format](text2, options).render();
  }
  return api;
};
JsBarcode.getModule = function(name) {
  return _barcodes2.default[name];
};
for (var name in _barcodes2.default) {
  if (_barcodes2.default.hasOwnProperty(name)) {
    registerBarcode(_barcodes2.default, name);
  }
}
function registerBarcode(barcodes2, name) {
  API.prototype[name] = API.prototype[name.toUpperCase()] = API.prototype[name.toLowerCase()] = function(text2, options) {
    var api = this;
    return api._errorHandler.wrapBarcodeCall(function() {
      options.text = typeof options.text === "undefined" ? void 0 : "" + options.text;
      var newOptions = (0, _merge2.default)(api._options, options);
      newOptions = (0, _optionsFromStrings2.default)(newOptions);
      var Encoder = barcodes2[name];
      var encoded = encode2(text2, Encoder, newOptions);
      api._encodings.push(encoded);
      return api;
    });
  };
}
function encode2(text2, Encoder, options) {
  text2 = "" + text2;
  var encoder2 = new Encoder(text2, options);
  if (!encoder2.valid()) {
    throw new _exceptions.InvalidInputException(encoder2.constructor.name, text2);
  }
  var encoded = encoder2.encode();
  encoded = (0, _linearizeEncodings2.default)(encoded);
  for (var i = 0; i < encoded.length; i++) {
    encoded[i].options = (0, _merge2.default)(options, encoded[i].options);
  }
  return encoded;
}
function autoSelectBarcode() {
  if (_barcodes2.default["CODE128"]) {
    return "CODE128";
  }
  return Object.keys(_barcodes2.default)[0];
}
API.prototype.options = function(options) {
  this._options = (0, _merge2.default)(this._options, options);
  return this;
};
API.prototype.blank = function(size) {
  var zeroes = new Array(size + 1).join("0");
  this._encodings.push({ data: zeroes });
  return this;
};
API.prototype.init = function() {
  if (!this._renderProperties) {
    return;
  }
  if (!Array.isArray(this._renderProperties)) {
    this._renderProperties = [this._renderProperties];
  }
  var renderProperty;
  for (var i in this._renderProperties) {
    renderProperty = this._renderProperties[i];
    var options = (0, _merge2.default)(this._options, renderProperty.options);
    if (options.format == "auto") {
      options.format = autoSelectBarcode();
    }
    this._errorHandler.wrapBarcodeCall(function() {
      var text2 = options.value;
      var Encoder = _barcodes2.default[options.format.toUpperCase()];
      var encoded = encode2(text2, Encoder, options);
      render(renderProperty, encoded, options);
    });
  }
};
API.prototype.render = function() {
  if (!this._renderProperties) {
    throw new _exceptions.NoElementException();
  }
  if (Array.isArray(this._renderProperties)) {
    for (var i = 0; i < this._renderProperties.length; i++) {
      render(this._renderProperties[i], this._encodings, this._options);
    }
  } else {
    render(this._renderProperties, this._encodings, this._options);
  }
  return this;
};
API.prototype._defaults = _defaults2.default;
function render(renderProperties, encodings2, options) {
  encodings2 = (0, _linearizeEncodings2.default)(encodings2);
  for (var i = 0; i < encodings2.length; i++) {
    encodings2[i].options = (0, _merge2.default)(options, encodings2[i].options);
    (0, _fixOptions2.default)(encodings2[i].options);
  }
  (0, _fixOptions2.default)(options);
  var Renderer = renderProperties.renderer;
  var renderer = new Renderer(renderProperties.element, encodings2, options);
  renderer.render();
  if (renderProperties.afterRender) {
    renderProperties.afterRender();
  }
}
if (typeof window !== "undefined") {
  window.JsBarcode = JsBarcode;
}
if (typeof jQuery !== "undefined") {
  jQuery.fn.JsBarcode = function(content, options) {
    var elementArray = [];
    jQuery(this).each(function() {
      elementArray.push(this);
    });
    return JsBarcode(elementArray, content, options);
  };
}
var JsBarcode_1 = JsBarcode;
const JsBarcode$1 = /* @__PURE__ */ getDefaultExportFromCjs(JsBarcode_1);
var qrcode = { exports: {} };
(function(module, exports) {
  var qrcode2 = function() {
    var qrcode3 = function(typeNumber, errorCorrectionLevel) {
      var PAD0 = 236;
      var PAD1 = 17;
      var _typeNumber = typeNumber;
      var _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
      var _modules = null;
      var _moduleCount = 0;
      var _dataCache = null;
      var _dataList = [];
      var _this = {};
      var makeImpl = function(test, maskPattern) {
        _moduleCount = _typeNumber * 4 + 17;
        _modules = function(moduleCount) {
          var modules = new Array(moduleCount);
          for (var row = 0; row < moduleCount; row += 1) {
            modules[row] = new Array(moduleCount);
            for (var col = 0; col < moduleCount; col += 1) {
              modules[row][col] = null;
            }
          }
          return modules;
        }(_moduleCount);
        setupPositionProbePattern(0, 0);
        setupPositionProbePattern(_moduleCount - 7, 0);
        setupPositionProbePattern(0, _moduleCount - 7);
        setupPositionAdjustPattern();
        setupTimingPattern();
        setupTypeInfo(test, maskPattern);
        if (_typeNumber >= 7) {
          setupTypeNumber(test);
        }
        if (_dataCache == null) {
          _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
        }
        mapData(_dataCache, maskPattern);
      };
      var setupPositionProbePattern = function(row, col) {
        for (var r = -1; r <= 7; r += 1) {
          if (row + r <= -1 || _moduleCount <= row + r)
            continue;
          for (var c = -1; c <= 7; c += 1) {
            if (col + c <= -1 || _moduleCount <= col + c)
              continue;
            if (0 <= r && r <= 6 && (c == 0 || c == 6) || 0 <= c && c <= 6 && (r == 0 || r == 6) || 2 <= r && r <= 4 && 2 <= c && c <= 4) {
              _modules[row + r][col + c] = true;
            } else {
              _modules[row + r][col + c] = false;
            }
          }
        }
      };
      var getBestMaskPattern = function() {
        var minLostPoint = 0;
        var pattern = 0;
        for (var i = 0; i < 8; i += 1) {
          makeImpl(true, i);
          var lostPoint = QRUtil.getLostPoint(_this);
          if (i == 0 || minLostPoint > lostPoint) {
            minLostPoint = lostPoint;
            pattern = i;
          }
        }
        return pattern;
      };
      var setupTimingPattern = function() {
        for (var r = 8; r < _moduleCount - 8; r += 1) {
          if (_modules[r][6] != null) {
            continue;
          }
          _modules[r][6] = r % 2 == 0;
        }
        for (var c = 8; c < _moduleCount - 8; c += 1) {
          if (_modules[6][c] != null) {
            continue;
          }
          _modules[6][c] = c % 2 == 0;
        }
      };
      var setupPositionAdjustPattern = function() {
        var pos = QRUtil.getPatternPosition(_typeNumber);
        for (var i = 0; i < pos.length; i += 1) {
          for (var j = 0; j < pos.length; j += 1) {
            var row = pos[i];
            var col = pos[j];
            if (_modules[row][col] != null) {
              continue;
            }
            for (var r = -2; r <= 2; r += 1) {
              for (var c = -2; c <= 2; c += 1) {
                if (r == -2 || r == 2 || c == -2 || c == 2 || r == 0 && c == 0) {
                  _modules[row + r][col + c] = true;
                } else {
                  _modules[row + r][col + c] = false;
                }
              }
            }
          }
        }
      };
      var setupTypeNumber = function(test) {
        var bits = QRUtil.getBCHTypeNumber(_typeNumber);
        for (var i = 0; i < 18; i += 1) {
          var mod = !test && (bits >> i & 1) == 1;
          _modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
        }
        for (var i = 0; i < 18; i += 1) {
          var mod = !test && (bits >> i & 1) == 1;
          _modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
        }
      };
      var setupTypeInfo = function(test, maskPattern) {
        var data = _errorCorrectionLevel << 3 | maskPattern;
        var bits = QRUtil.getBCHTypeInfo(data);
        for (var i = 0; i < 15; i += 1) {
          var mod = !test && (bits >> i & 1) == 1;
          if (i < 6) {
            _modules[i][8] = mod;
          } else if (i < 8) {
            _modules[i + 1][8] = mod;
          } else {
            _modules[_moduleCount - 15 + i][8] = mod;
          }
        }
        for (var i = 0; i < 15; i += 1) {
          var mod = !test && (bits >> i & 1) == 1;
          if (i < 8) {
            _modules[8][_moduleCount - i - 1] = mod;
          } else if (i < 9) {
            _modules[8][15 - i - 1 + 1] = mod;
          } else {
            _modules[8][15 - i - 1] = mod;
          }
        }
        _modules[_moduleCount - 8][8] = !test;
      };
      var mapData = function(data, maskPattern) {
        var inc = -1;
        var row = _moduleCount - 1;
        var bitIndex = 7;
        var byteIndex = 0;
        var maskFunc = QRUtil.getMaskFunction(maskPattern);
        for (var col = _moduleCount - 1; col > 0; col -= 2) {
          if (col == 6)
            col -= 1;
          while (true) {
            for (var c = 0; c < 2; c += 1) {
              if (_modules[row][col - c] == null) {
                var dark = false;
                if (byteIndex < data.length) {
                  dark = (data[byteIndex] >>> bitIndex & 1) == 1;
                }
                var mask = maskFunc(row, col - c);
                if (mask) {
                  dark = !dark;
                }
                _modules[row][col - c] = dark;
                bitIndex -= 1;
                if (bitIndex == -1) {
                  byteIndex += 1;
                  bitIndex = 7;
                }
              }
            }
            row += inc;
            if (row < 0 || _moduleCount <= row) {
              row -= inc;
              inc = -inc;
              break;
            }
          }
        }
      };
      var createBytes = function(buffer, rsBlocks) {
        var offset = 0;
        var maxDcCount = 0;
        var maxEcCount = 0;
        var dcdata = new Array(rsBlocks.length);
        var ecdata = new Array(rsBlocks.length);
        for (var r = 0; r < rsBlocks.length; r += 1) {
          var dcCount = rsBlocks[r].dataCount;
          var ecCount = rsBlocks[r].totalCount - dcCount;
          maxDcCount = Math.max(maxDcCount, dcCount);
          maxEcCount = Math.max(maxEcCount, ecCount);
          dcdata[r] = new Array(dcCount);
          for (var i = 0; i < dcdata[r].length; i += 1) {
            dcdata[r][i] = 255 & buffer.getBuffer()[i + offset];
          }
          offset += dcCount;
          var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
          var rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);
          var modPoly = rawPoly.mod(rsPoly);
          ecdata[r] = new Array(rsPoly.getLength() - 1);
          for (var i = 0; i < ecdata[r].length; i += 1) {
            var modIndex = i + modPoly.getLength() - ecdata[r].length;
            ecdata[r][i] = modIndex >= 0 ? modPoly.getAt(modIndex) : 0;
          }
        }
        var totalCodeCount = 0;
        for (var i = 0; i < rsBlocks.length; i += 1) {
          totalCodeCount += rsBlocks[i].totalCount;
        }
        var data = new Array(totalCodeCount);
        var index = 0;
        for (var i = 0; i < maxDcCount; i += 1) {
          for (var r = 0; r < rsBlocks.length; r += 1) {
            if (i < dcdata[r].length) {
              data[index] = dcdata[r][i];
              index += 1;
            }
          }
        }
        for (var i = 0; i < maxEcCount; i += 1) {
          for (var r = 0; r < rsBlocks.length; r += 1) {
            if (i < ecdata[r].length) {
              data[index] = ecdata[r][i];
              index += 1;
            }
          }
        }
        return data;
      };
      var createData = function(typeNumber2, errorCorrectionLevel2, dataList) {
        var rsBlocks = QRRSBlock.getRSBlocks(typeNumber2, errorCorrectionLevel2);
        var buffer = qrBitBuffer();
        for (var i = 0; i < dataList.length; i += 1) {
          var data = dataList[i];
          buffer.put(data.getMode(), 4);
          buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber2));
          data.write(buffer);
        }
        var totalDataCount = 0;
        for (var i = 0; i < rsBlocks.length; i += 1) {
          totalDataCount += rsBlocks[i].dataCount;
        }
        if (buffer.getLengthInBits() > totalDataCount * 8) {
          throw "code length overflow. (" + buffer.getLengthInBits() + ">" + totalDataCount * 8 + ")";
        }
        if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
          buffer.put(0, 4);
        }
        while (buffer.getLengthInBits() % 8 != 0) {
          buffer.putBit(false);
        }
        while (true) {
          if (buffer.getLengthInBits() >= totalDataCount * 8) {
            break;
          }
          buffer.put(PAD0, 8);
          if (buffer.getLengthInBits() >= totalDataCount * 8) {
            break;
          }
          buffer.put(PAD1, 8);
        }
        return createBytes(buffer, rsBlocks);
      };
      _this.addData = function(data, mode) {
        mode = mode || "Byte";
        var newData = null;
        switch (mode) {
          case "Numeric":
            newData = qrNumber(data);
            break;
          case "Alphanumeric":
            newData = qrAlphaNum(data);
            break;
          case "Byte":
            newData = qr8BitByte(data);
            break;
          case "Kanji":
            newData = qrKanji(data);
            break;
          default:
            throw "mode:" + mode;
        }
        _dataList.push(newData);
        _dataCache = null;
      };
      _this.isDark = function(row, col) {
        if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {
          throw row + "," + col;
        }
        return _modules[row][col];
      };
      _this.getModuleCount = function() {
        return _moduleCount;
      };
      _this.make = function() {
        if (_typeNumber < 1) {
          var typeNumber2 = 1;
          for (; typeNumber2 < 40; typeNumber2++) {
            var rsBlocks = QRRSBlock.getRSBlocks(typeNumber2, _errorCorrectionLevel);
            var buffer = qrBitBuffer();
            for (var i = 0; i < _dataList.length; i++) {
              var data = _dataList[i];
              buffer.put(data.getMode(), 4);
              buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber2));
              data.write(buffer);
            }
            var totalDataCount = 0;
            for (var i = 0; i < rsBlocks.length; i++) {
              totalDataCount += rsBlocks[i].dataCount;
            }
            if (buffer.getLengthInBits() <= totalDataCount * 8) {
              break;
            }
          }
          _typeNumber = typeNumber2;
        }
        makeImpl(false, getBestMaskPattern());
      };
      _this.createTableTag = function(cellSize, margin) {
        cellSize = cellSize || 2;
        margin = typeof margin == "undefined" ? cellSize * 4 : margin;
        var qrHtml = "";
        qrHtml += '<table style="';
        qrHtml += " border-width: 0px; border-style: none;";
        qrHtml += " border-collapse: collapse;";
        qrHtml += " padding: 0px; margin: " + margin + "px;";
        qrHtml += '">';
        qrHtml += "<tbody>";
        for (var r = 0; r < _this.getModuleCount(); r += 1) {
          qrHtml += "<tr>";
          for (var c = 0; c < _this.getModuleCount(); c += 1) {
            qrHtml += '<td style="';
            qrHtml += " border-width: 0px; border-style: none;";
            qrHtml += " border-collapse: collapse;";
            qrHtml += " padding: 0px; margin: 0px;";
            qrHtml += " width: " + cellSize + "px;";
            qrHtml += " height: " + cellSize + "px;";
            qrHtml += " background-color: ";
            qrHtml += _this.isDark(r, c) ? "#000000" : "#ffffff";
            qrHtml += ";";
            qrHtml += '"/>';
          }
          qrHtml += "</tr>";
        }
        qrHtml += "</tbody>";
        qrHtml += "</table>";
        return qrHtml;
      };
      _this.createSvgTag = function(cellSize, margin, alt, title) {
        var opts = {};
        if (typeof arguments[0] == "object") {
          opts = arguments[0];
          cellSize = opts.cellSize;
          margin = opts.margin;
          alt = opts.alt;
          title = opts.title;
        }
        cellSize = cellSize || 2;
        margin = typeof margin == "undefined" ? cellSize * 4 : margin;
        alt = typeof alt === "string" ? { text: alt } : alt || {};
        alt.text = alt.text || null;
        alt.id = alt.text ? alt.id || "qrcode-description" : null;
        title = typeof title === "string" ? { text: title } : title || {};
        title.text = title.text || null;
        title.id = title.text ? title.id || "qrcode-title" : null;
        var size = _this.getModuleCount() * cellSize + margin * 2;
        var c, mc, r, mr, qrSvg = "", rect;
        rect = "l" + cellSize + ",0 0," + cellSize + " -" + cellSize + ",0 0,-" + cellSize + "z ";
        qrSvg += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"';
        qrSvg += !opts.scalable ? ' width="' + size + 'px" height="' + size + 'px"' : "";
        qrSvg += ' viewBox="0 0 ' + size + " " + size + '" ';
        qrSvg += ' preserveAspectRatio="xMinYMin meet"';
        qrSvg += title.text || alt.text ? ' role="img" aria-labelledby="' + escapeXml([title.id, alt.id].join(" ").trim()) + '"' : "";
        qrSvg += ">";
        qrSvg += title.text ? '<title id="' + escapeXml(title.id) + '">' + escapeXml(title.text) + "</title>" : "";
        qrSvg += alt.text ? '<description id="' + escapeXml(alt.id) + '">' + escapeXml(alt.text) + "</description>" : "";
        qrSvg += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>';
        qrSvg += '<path d="';
        for (r = 0; r < _this.getModuleCount(); r += 1) {
          mr = r * cellSize + margin;
          for (c = 0; c < _this.getModuleCount(); c += 1) {
            if (_this.isDark(r, c)) {
              mc = c * cellSize + margin;
              qrSvg += "M" + mc + "," + mr + rect;
            }
          }
        }
        qrSvg += '" stroke="transparent" fill="black"/>';
        qrSvg += "</svg>";
        return qrSvg;
      };
      _this.createDataURL = function(cellSize, margin) {
        cellSize = cellSize || 2;
        margin = typeof margin == "undefined" ? cellSize * 4 : margin;
        var size = _this.getModuleCount() * cellSize + margin * 2;
        var min = margin;
        var max = size - margin;
        return createDataURL(size, size, function(x, y) {
          if (min <= x && x < max && min <= y && y < max) {
            var c = Math.floor((x - min) / cellSize);
            var r = Math.floor((y - min) / cellSize);
            return _this.isDark(r, c) ? 0 : 1;
          } else {
            return 1;
          }
        });
      };
      _this.createImgTag = function(cellSize, margin, alt) {
        cellSize = cellSize || 2;
        margin = typeof margin == "undefined" ? cellSize * 4 : margin;
        var size = _this.getModuleCount() * cellSize + margin * 2;
        var img = "";
        img += "<img";
        img += ' src="';
        img += _this.createDataURL(cellSize, margin);
        img += '"';
        img += ' width="';
        img += size;
        img += '"';
        img += ' height="';
        img += size;
        img += '"';
        if (alt) {
          img += ' alt="';
          img += escapeXml(alt);
          img += '"';
        }
        img += "/>";
        return img;
      };
      var escapeXml = function(s) {
        var escaped = "";
        for (var i = 0; i < s.length; i += 1) {
          var c = s.charAt(i);
          switch (c) {
            case "<":
              escaped += "&lt;";
              break;
            case ">":
              escaped += "&gt;";
              break;
            case "&":
              escaped += "&amp;";
              break;
            case '"':
              escaped += "&quot;";
              break;
            default:
              escaped += c;
              break;
          }
        }
        return escaped;
      };
      var _createHalfASCII = function(margin) {
        var cellSize = 1;
        margin = typeof margin == "undefined" ? cellSize * 2 : margin;
        var size = _this.getModuleCount() * cellSize + margin * 2;
        var min = margin;
        var max = size - margin;
        var y, x, r1, r2, p;
        var blocks = {
          "██": "█",
          "█ ": "▀",
          " █": "▄",
          "  ": " "
        };
        var blocksLastLineNoMargin = {
          "██": "▀",
          "█ ": "▀",
          " █": " ",
          "  ": " "
        };
        var ascii = "";
        for (y = 0; y < size; y += 2) {
          r1 = Math.floor((y - min) / cellSize);
          r2 = Math.floor((y + 1 - min) / cellSize);
          for (x = 0; x < size; x += 1) {
            p = "█";
            if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {
              p = " ";
            }
            if (min <= x && x < max && min <= y + 1 && y + 1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {
              p += " ";
            } else {
              p += "█";
            }
            ascii += margin < 1 && y + 1 >= max ? blocksLastLineNoMargin[p] : blocks[p];
          }
          ascii += "\n";
        }
        if (size % 2 && margin > 0) {
          return ascii.substring(0, ascii.length - size - 1) + Array(size + 1).join("▀");
        }
        return ascii.substring(0, ascii.length - 1);
      };
      _this.createASCII = function(cellSize, margin) {
        cellSize = cellSize || 1;
        if (cellSize < 2) {
          return _createHalfASCII(margin);
        }
        cellSize -= 1;
        margin = typeof margin == "undefined" ? cellSize * 2 : margin;
        var size = _this.getModuleCount() * cellSize + margin * 2;
        var min = margin;
        var max = size - margin;
        var y, x, r, p;
        var white = Array(cellSize + 1).join("██");
        var black = Array(cellSize + 1).join("  ");
        var ascii = "";
        var line = "";
        for (y = 0; y < size; y += 1) {
          r = Math.floor((y - min) / cellSize);
          line = "";
          for (x = 0; x < size; x += 1) {
            p = 1;
            if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cellSize))) {
              p = 0;
            }
            line += p ? white : black;
          }
          for (r = 0; r < cellSize; r += 1) {
            ascii += line + "\n";
          }
        }
        return ascii.substring(0, ascii.length - 1);
      };
      _this.renderTo2dContext = function(context, cellSize) {
        cellSize = cellSize || 2;
        var length = _this.getModuleCount();
        for (var row = 0; row < length; row++) {
          for (var col = 0; col < length; col++) {
            context.fillStyle = _this.isDark(row, col) ? "black" : "white";
            context.fillRect(row * cellSize, col * cellSize, cellSize, cellSize);
          }
        }
      };
      return _this;
    };
    qrcode3.stringToBytesFuncs = {
      "default": function(s) {
        var bytes = [];
        for (var i = 0; i < s.length; i += 1) {
          var c = s.charCodeAt(i);
          bytes.push(c & 255);
        }
        return bytes;
      }
    };
    qrcode3.stringToBytes = qrcode3.stringToBytesFuncs["default"];
    qrcode3.createStringToBytes = function(unicodeData, numChars) {
      var unicodeMap = function() {
        var bin = base64DecodeInputStream(unicodeData);
        var read = function() {
          var b = bin.read();
          if (b == -1)
            throw "eof";
          return b;
        };
        var count = 0;
        var unicodeMap2 = {};
        while (true) {
          var b0 = bin.read();
          if (b0 == -1)
            break;
          var b1 = read();
          var b2 = read();
          var b3 = read();
          var k = String.fromCharCode(b0 << 8 | b1);
          var v = b2 << 8 | b3;
          unicodeMap2[k] = v;
          count += 1;
        }
        if (count != numChars) {
          throw count + " != " + numChars;
        }
        return unicodeMap2;
      }();
      var unknownChar = "?".charCodeAt(0);
      return function(s) {
        var bytes = [];
        for (var i = 0; i < s.length; i += 1) {
          var c = s.charCodeAt(i);
          if (c < 128) {
            bytes.push(c);
          } else {
            var b = unicodeMap[s.charAt(i)];
            if (typeof b == "number") {
              if ((b & 255) == b) {
                bytes.push(b);
              } else {
                bytes.push(b >>> 8);
                bytes.push(b & 255);
              }
            } else {
              bytes.push(unknownChar);
            }
          }
        }
        return bytes;
      };
    };
    var QRMode = {
      MODE_NUMBER: 1 << 0,
      MODE_ALPHA_NUM: 1 << 1,
      MODE_8BIT_BYTE: 1 << 2,
      MODE_KANJI: 1 << 3
    };
    var QRErrorCorrectionLevel = {
      L: 1,
      M: 0,
      Q: 3,
      H: 2
    };
    var QRMaskPattern = {
      PATTERN000: 0,
      PATTERN001: 1,
      PATTERN010: 2,
      PATTERN011: 3,
      PATTERN100: 4,
      PATTERN101: 5,
      PATTERN110: 6,
      PATTERN111: 7
    };
    var QRUtil = function() {
      var PATTERN_POSITION_TABLE = [
        [],
        [6, 18],
        [6, 22],
        [6, 26],
        [6, 30],
        [6, 34],
        [6, 22, 38],
        [6, 24, 42],
        [6, 26, 46],
        [6, 28, 50],
        [6, 30, 54],
        [6, 32, 58],
        [6, 34, 62],
        [6, 26, 46, 66],
        [6, 26, 48, 70],
        [6, 26, 50, 74],
        [6, 30, 54, 78],
        [6, 30, 56, 82],
        [6, 30, 58, 86],
        [6, 34, 62, 90],
        [6, 28, 50, 72, 94],
        [6, 26, 50, 74, 98],
        [6, 30, 54, 78, 102],
        [6, 28, 54, 80, 106],
        [6, 32, 58, 84, 110],
        [6, 30, 58, 86, 114],
        [6, 34, 62, 90, 118],
        [6, 26, 50, 74, 98, 122],
        [6, 30, 54, 78, 102, 126],
        [6, 26, 52, 78, 104, 130],
        [6, 30, 56, 82, 108, 134],
        [6, 34, 60, 86, 112, 138],
        [6, 30, 58, 86, 114, 142],
        [6, 34, 62, 90, 118, 146],
        [6, 30, 54, 78, 102, 126, 150],
        [6, 24, 50, 76, 102, 128, 154],
        [6, 28, 54, 80, 106, 132, 158],
        [6, 32, 58, 84, 110, 136, 162],
        [6, 26, 54, 82, 110, 138, 166],
        [6, 30, 58, 86, 114, 142, 170]
      ];
      var G15 = 1 << 10 | 1 << 8 | 1 << 5 | 1 << 4 | 1 << 2 | 1 << 1 | 1 << 0;
      var G18 = 1 << 12 | 1 << 11 | 1 << 10 | 1 << 9 | 1 << 8 | 1 << 5 | 1 << 2 | 1 << 0;
      var G15_MASK = 1 << 14 | 1 << 12 | 1 << 10 | 1 << 4 | 1 << 1;
      var _this = {};
      var getBCHDigit = function(data) {
        var digit = 0;
        while (data != 0) {
          digit += 1;
          data >>>= 1;
        }
        return digit;
      };
      _this.getBCHTypeInfo = function(data) {
        var d = data << 10;
        while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
          d ^= G15 << getBCHDigit(d) - getBCHDigit(G15);
        }
        return (data << 10 | d) ^ G15_MASK;
      };
      _this.getBCHTypeNumber = function(data) {
        var d = data << 12;
        while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
          d ^= G18 << getBCHDigit(d) - getBCHDigit(G18);
        }
        return data << 12 | d;
      };
      _this.getPatternPosition = function(typeNumber) {
        return PATTERN_POSITION_TABLE[typeNumber - 1];
      };
      _this.getMaskFunction = function(maskPattern) {
        switch (maskPattern) {
          case QRMaskPattern.PATTERN000:
            return function(i, j) {
              return (i + j) % 2 == 0;
            };
          case QRMaskPattern.PATTERN001:
            return function(i, j) {
              return i % 2 == 0;
            };
          case QRMaskPattern.PATTERN010:
            return function(i, j) {
              return j % 3 == 0;
            };
          case QRMaskPattern.PATTERN011:
            return function(i, j) {
              return (i + j) % 3 == 0;
            };
          case QRMaskPattern.PATTERN100:
            return function(i, j) {
              return (Math.floor(i / 2) + Math.floor(j / 3)) % 2 == 0;
            };
          case QRMaskPattern.PATTERN101:
            return function(i, j) {
              return i * j % 2 + i * j % 3 == 0;
            };
          case QRMaskPattern.PATTERN110:
            return function(i, j) {
              return (i * j % 2 + i * j % 3) % 2 == 0;
            };
          case QRMaskPattern.PATTERN111:
            return function(i, j) {
              return (i * j % 3 + (i + j) % 2) % 2 == 0;
            };
          default:
            throw "bad maskPattern:" + maskPattern;
        }
      };
      _this.getErrorCorrectPolynomial = function(errorCorrectLength) {
        var a = qrPolynomial([1], 0);
        for (var i = 0; i < errorCorrectLength; i += 1) {
          a = a.multiply(qrPolynomial([1, QRMath.gexp(i)], 0));
        }
        return a;
      };
      _this.getLengthInBits = function(mode, type) {
        if (1 <= type && type < 10) {
          switch (mode) {
            case QRMode.MODE_NUMBER:
              return 10;
            case QRMode.MODE_ALPHA_NUM:
              return 9;
            case QRMode.MODE_8BIT_BYTE:
              return 8;
            case QRMode.MODE_KANJI:
              return 8;
            default:
              throw "mode:" + mode;
          }
        } else if (type < 27) {
          switch (mode) {
            case QRMode.MODE_NUMBER:
              return 12;
            case QRMode.MODE_ALPHA_NUM:
              return 11;
            case QRMode.MODE_8BIT_BYTE:
              return 16;
            case QRMode.MODE_KANJI:
              return 10;
            default:
              throw "mode:" + mode;
          }
        } else if (type < 41) {
          switch (mode) {
            case QRMode.MODE_NUMBER:
              return 14;
            case QRMode.MODE_ALPHA_NUM:
              return 13;
            case QRMode.MODE_8BIT_BYTE:
              return 16;
            case QRMode.MODE_KANJI:
              return 12;
            default:
              throw "mode:" + mode;
          }
        } else {
          throw "type:" + type;
        }
      };
      _this.getLostPoint = function(qrcode4) {
        var moduleCount = qrcode4.getModuleCount();
        var lostPoint = 0;
        for (var row = 0; row < moduleCount; row += 1) {
          for (var col = 0; col < moduleCount; col += 1) {
            var sameCount = 0;
            var dark = qrcode4.isDark(row, col);
            for (var r = -1; r <= 1; r += 1) {
              if (row + r < 0 || moduleCount <= row + r) {
                continue;
              }
              for (var c = -1; c <= 1; c += 1) {
                if (col + c < 0 || moduleCount <= col + c) {
                  continue;
                }
                if (r == 0 && c == 0) {
                  continue;
                }
                if (dark == qrcode4.isDark(row + r, col + c)) {
                  sameCount += 1;
                }
              }
            }
            if (sameCount > 5) {
              lostPoint += 3 + sameCount - 5;
            }
          }
        }
        for (var row = 0; row < moduleCount - 1; row += 1) {
          for (var col = 0; col < moduleCount - 1; col += 1) {
            var count = 0;
            if (qrcode4.isDark(row, col))
              count += 1;
            if (qrcode4.isDark(row + 1, col))
              count += 1;
            if (qrcode4.isDark(row, col + 1))
              count += 1;
            if (qrcode4.isDark(row + 1, col + 1))
              count += 1;
            if (count == 0 || count == 4) {
              lostPoint += 3;
            }
          }
        }
        for (var row = 0; row < moduleCount; row += 1) {
          for (var col = 0; col < moduleCount - 6; col += 1) {
            if (qrcode4.isDark(row, col) && !qrcode4.isDark(row, col + 1) && qrcode4.isDark(row, col + 2) && qrcode4.isDark(row, col + 3) && qrcode4.isDark(row, col + 4) && !qrcode4.isDark(row, col + 5) && qrcode4.isDark(row, col + 6)) {
              lostPoint += 40;
            }
          }
        }
        for (var col = 0; col < moduleCount; col += 1) {
          for (var row = 0; row < moduleCount - 6; row += 1) {
            if (qrcode4.isDark(row, col) && !qrcode4.isDark(row + 1, col) && qrcode4.isDark(row + 2, col) && qrcode4.isDark(row + 3, col) && qrcode4.isDark(row + 4, col) && !qrcode4.isDark(row + 5, col) && qrcode4.isDark(row + 6, col)) {
              lostPoint += 40;
            }
          }
        }
        var darkCount = 0;
        for (var col = 0; col < moduleCount; col += 1) {
          for (var row = 0; row < moduleCount; row += 1) {
            if (qrcode4.isDark(row, col)) {
              darkCount += 1;
            }
          }
        }
        var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
        lostPoint += ratio * 10;
        return lostPoint;
      };
      return _this;
    }();
    var QRMath = function() {
      var EXP_TABLE = new Array(256);
      var LOG_TABLE = new Array(256);
      for (var i = 0; i < 8; i += 1) {
        EXP_TABLE[i] = 1 << i;
      }
      for (var i = 8; i < 256; i += 1) {
        EXP_TABLE[i] = EXP_TABLE[i - 4] ^ EXP_TABLE[i - 5] ^ EXP_TABLE[i - 6] ^ EXP_TABLE[i - 8];
      }
      for (var i = 0; i < 255; i += 1) {
        LOG_TABLE[EXP_TABLE[i]] = i;
      }
      var _this = {};
      _this.glog = function(n) {
        if (n < 1) {
          throw "glog(" + n + ")";
        }
        return LOG_TABLE[n];
      };
      _this.gexp = function(n) {
        while (n < 0) {
          n += 255;
        }
        while (n >= 256) {
          n -= 255;
        }
        return EXP_TABLE[n];
      };
      return _this;
    }();
    function qrPolynomial(num, shift) {
      if (typeof num.length == "undefined") {
        throw num.length + "/" + shift;
      }
      var _num = function() {
        var offset = 0;
        while (offset < num.length && num[offset] == 0) {
          offset += 1;
        }
        var _num2 = new Array(num.length - offset + shift);
        for (var i = 0; i < num.length - offset; i += 1) {
          _num2[i] = num[i + offset];
        }
        return _num2;
      }();
      var _this = {};
      _this.getAt = function(index) {
        return _num[index];
      };
      _this.getLength = function() {
        return _num.length;
      };
      _this.multiply = function(e) {
        var num2 = new Array(_this.getLength() + e.getLength() - 1);
        for (var i = 0; i < _this.getLength(); i += 1) {
          for (var j = 0; j < e.getLength(); j += 1) {
            num2[i + j] ^= QRMath.gexp(QRMath.glog(_this.getAt(i)) + QRMath.glog(e.getAt(j)));
          }
        }
        return qrPolynomial(num2, 0);
      };
      _this.mod = function(e) {
        if (_this.getLength() - e.getLength() < 0) {
          return _this;
        }
        var ratio = QRMath.glog(_this.getAt(0)) - QRMath.glog(e.getAt(0));
        var num2 = new Array(_this.getLength());
        for (var i = 0; i < _this.getLength(); i += 1) {
          num2[i] = _this.getAt(i);
        }
        for (var i = 0; i < e.getLength(); i += 1) {
          num2[i] ^= QRMath.gexp(QRMath.glog(e.getAt(i)) + ratio);
        }
        return qrPolynomial(num2, 0).mod(e);
      };
      return _this;
    }
    var QRRSBlock = function() {
      var RS_BLOCK_TABLE = [
        // L
        // M
        // Q
        // H
        // 1
        [1, 26, 19],
        [1, 26, 16],
        [1, 26, 13],
        [1, 26, 9],
        // 2
        [1, 44, 34],
        [1, 44, 28],
        [1, 44, 22],
        [1, 44, 16],
        // 3
        [1, 70, 55],
        [1, 70, 44],
        [2, 35, 17],
        [2, 35, 13],
        // 4
        [1, 100, 80],
        [2, 50, 32],
        [2, 50, 24],
        [4, 25, 9],
        // 5
        [1, 134, 108],
        [2, 67, 43],
        [2, 33, 15, 2, 34, 16],
        [2, 33, 11, 2, 34, 12],
        // 6
        [2, 86, 68],
        [4, 43, 27],
        [4, 43, 19],
        [4, 43, 15],
        // 7
        [2, 98, 78],
        [4, 49, 31],
        [2, 32, 14, 4, 33, 15],
        [4, 39, 13, 1, 40, 14],
        // 8
        [2, 121, 97],
        [2, 60, 38, 2, 61, 39],
        [4, 40, 18, 2, 41, 19],
        [4, 40, 14, 2, 41, 15],
        // 9
        [2, 146, 116],
        [3, 58, 36, 2, 59, 37],
        [4, 36, 16, 4, 37, 17],
        [4, 36, 12, 4, 37, 13],
        // 10
        [2, 86, 68, 2, 87, 69],
        [4, 69, 43, 1, 70, 44],
        [6, 43, 19, 2, 44, 20],
        [6, 43, 15, 2, 44, 16],
        // 11
        [4, 101, 81],
        [1, 80, 50, 4, 81, 51],
        [4, 50, 22, 4, 51, 23],
        [3, 36, 12, 8, 37, 13],
        // 12
        [2, 116, 92, 2, 117, 93],
        [6, 58, 36, 2, 59, 37],
        [4, 46, 20, 6, 47, 21],
        [7, 42, 14, 4, 43, 15],
        // 13
        [4, 133, 107],
        [8, 59, 37, 1, 60, 38],
        [8, 44, 20, 4, 45, 21],
        [12, 33, 11, 4, 34, 12],
        // 14
        [3, 145, 115, 1, 146, 116],
        [4, 64, 40, 5, 65, 41],
        [11, 36, 16, 5, 37, 17],
        [11, 36, 12, 5, 37, 13],
        // 15
        [5, 109, 87, 1, 110, 88],
        [5, 65, 41, 5, 66, 42],
        [5, 54, 24, 7, 55, 25],
        [11, 36, 12, 7, 37, 13],
        // 16
        [5, 122, 98, 1, 123, 99],
        [7, 73, 45, 3, 74, 46],
        [15, 43, 19, 2, 44, 20],
        [3, 45, 15, 13, 46, 16],
        // 17
        [1, 135, 107, 5, 136, 108],
        [10, 74, 46, 1, 75, 47],
        [1, 50, 22, 15, 51, 23],
        [2, 42, 14, 17, 43, 15],
        // 18
        [5, 150, 120, 1, 151, 121],
        [9, 69, 43, 4, 70, 44],
        [17, 50, 22, 1, 51, 23],
        [2, 42, 14, 19, 43, 15],
        // 19
        [3, 141, 113, 4, 142, 114],
        [3, 70, 44, 11, 71, 45],
        [17, 47, 21, 4, 48, 22],
        [9, 39, 13, 16, 40, 14],
        // 20
        [3, 135, 107, 5, 136, 108],
        [3, 67, 41, 13, 68, 42],
        [15, 54, 24, 5, 55, 25],
        [15, 43, 15, 10, 44, 16],
        // 21
        [4, 144, 116, 4, 145, 117],
        [17, 68, 42],
        [17, 50, 22, 6, 51, 23],
        [19, 46, 16, 6, 47, 17],
        // 22
        [2, 139, 111, 7, 140, 112],
        [17, 74, 46],
        [7, 54, 24, 16, 55, 25],
        [34, 37, 13],
        // 23
        [4, 151, 121, 5, 152, 122],
        [4, 75, 47, 14, 76, 48],
        [11, 54, 24, 14, 55, 25],
        [16, 45, 15, 14, 46, 16],
        // 24
        [6, 147, 117, 4, 148, 118],
        [6, 73, 45, 14, 74, 46],
        [11, 54, 24, 16, 55, 25],
        [30, 46, 16, 2, 47, 17],
        // 25
        [8, 132, 106, 4, 133, 107],
        [8, 75, 47, 13, 76, 48],
        [7, 54, 24, 22, 55, 25],
        [22, 45, 15, 13, 46, 16],
        // 26
        [10, 142, 114, 2, 143, 115],
        [19, 74, 46, 4, 75, 47],
        [28, 50, 22, 6, 51, 23],
        [33, 46, 16, 4, 47, 17],
        // 27
        [8, 152, 122, 4, 153, 123],
        [22, 73, 45, 3, 74, 46],
        [8, 53, 23, 26, 54, 24],
        [12, 45, 15, 28, 46, 16],
        // 28
        [3, 147, 117, 10, 148, 118],
        [3, 73, 45, 23, 74, 46],
        [4, 54, 24, 31, 55, 25],
        [11, 45, 15, 31, 46, 16],
        // 29
        [7, 146, 116, 7, 147, 117],
        [21, 73, 45, 7, 74, 46],
        [1, 53, 23, 37, 54, 24],
        [19, 45, 15, 26, 46, 16],
        // 30
        [5, 145, 115, 10, 146, 116],
        [19, 75, 47, 10, 76, 48],
        [15, 54, 24, 25, 55, 25],
        [23, 45, 15, 25, 46, 16],
        // 31
        [13, 145, 115, 3, 146, 116],
        [2, 74, 46, 29, 75, 47],
        [42, 54, 24, 1, 55, 25],
        [23, 45, 15, 28, 46, 16],
        // 32
        [17, 145, 115],
        [10, 74, 46, 23, 75, 47],
        [10, 54, 24, 35, 55, 25],
        [19, 45, 15, 35, 46, 16],
        // 33
        [17, 145, 115, 1, 146, 116],
        [14, 74, 46, 21, 75, 47],
        [29, 54, 24, 19, 55, 25],
        [11, 45, 15, 46, 46, 16],
        // 34
        [13, 145, 115, 6, 146, 116],
        [14, 74, 46, 23, 75, 47],
        [44, 54, 24, 7, 55, 25],
        [59, 46, 16, 1, 47, 17],
        // 35
        [12, 151, 121, 7, 152, 122],
        [12, 75, 47, 26, 76, 48],
        [39, 54, 24, 14, 55, 25],
        [22, 45, 15, 41, 46, 16],
        // 36
        [6, 151, 121, 14, 152, 122],
        [6, 75, 47, 34, 76, 48],
        [46, 54, 24, 10, 55, 25],
        [2, 45, 15, 64, 46, 16],
        // 37
        [17, 152, 122, 4, 153, 123],
        [29, 74, 46, 14, 75, 47],
        [49, 54, 24, 10, 55, 25],
        [24, 45, 15, 46, 46, 16],
        // 38
        [4, 152, 122, 18, 153, 123],
        [13, 74, 46, 32, 75, 47],
        [48, 54, 24, 14, 55, 25],
        [42, 45, 15, 32, 46, 16],
        // 39
        [20, 147, 117, 4, 148, 118],
        [40, 75, 47, 7, 76, 48],
        [43, 54, 24, 22, 55, 25],
        [10, 45, 15, 67, 46, 16],
        // 40
        [19, 148, 118, 6, 149, 119],
        [18, 75, 47, 31, 76, 48],
        [34, 54, 24, 34, 55, 25],
        [20, 45, 15, 61, 46, 16]
      ];
      var qrRSBlock = function(totalCount, dataCount) {
        var _this2 = {};
        _this2.totalCount = totalCount;
        _this2.dataCount = dataCount;
        return _this2;
      };
      var _this = {};
      var getRsBlockTable = function(typeNumber, errorCorrectionLevel) {
        switch (errorCorrectionLevel) {
          case QRErrorCorrectionLevel.L:
            return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
          case QRErrorCorrectionLevel.M:
            return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
          case QRErrorCorrectionLevel.Q:
            return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
          case QRErrorCorrectionLevel.H:
            return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
          default:
            return void 0;
        }
      };
      _this.getRSBlocks = function(typeNumber, errorCorrectionLevel) {
        var rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);
        if (typeof rsBlock == "undefined") {
          throw "bad rs block @ typeNumber:" + typeNumber + "/errorCorrectionLevel:" + errorCorrectionLevel;
        }
        var length = rsBlock.length / 3;
        var list = [];
        for (var i = 0; i < length; i += 1) {
          var count = rsBlock[i * 3 + 0];
          var totalCount = rsBlock[i * 3 + 1];
          var dataCount = rsBlock[i * 3 + 2];
          for (var j = 0; j < count; j += 1) {
            list.push(qrRSBlock(totalCount, dataCount));
          }
        }
        return list;
      };
      return _this;
    }();
    var qrBitBuffer = function() {
      var _buffer = [];
      var _length = 0;
      var _this = {};
      _this.getBuffer = function() {
        return _buffer;
      };
      _this.getAt = function(index) {
        var bufIndex = Math.floor(index / 8);
        return (_buffer[bufIndex] >>> 7 - index % 8 & 1) == 1;
      };
      _this.put = function(num, length) {
        for (var i = 0; i < length; i += 1) {
          _this.putBit((num >>> length - i - 1 & 1) == 1);
        }
      };
      _this.getLengthInBits = function() {
        return _length;
      };
      _this.putBit = function(bit) {
        var bufIndex = Math.floor(_length / 8);
        if (_buffer.length <= bufIndex) {
          _buffer.push(0);
        }
        if (bit) {
          _buffer[bufIndex] |= 128 >>> _length % 8;
        }
        _length += 1;
      };
      return _this;
    };
    var qrNumber = function(data) {
      var _mode = QRMode.MODE_NUMBER;
      var _data = data;
      var _this = {};
      _this.getMode = function() {
        return _mode;
      };
      _this.getLength = function(buffer) {
        return _data.length;
      };
      _this.write = function(buffer) {
        var data2 = _data;
        var i = 0;
        while (i + 2 < data2.length) {
          buffer.put(strToNum(data2.substring(i, i + 3)), 10);
          i += 3;
        }
        if (i < data2.length) {
          if (data2.length - i == 1) {
            buffer.put(strToNum(data2.substring(i, i + 1)), 4);
          } else if (data2.length - i == 2) {
            buffer.put(strToNum(data2.substring(i, i + 2)), 7);
          }
        }
      };
      var strToNum = function(s) {
        var num = 0;
        for (var i = 0; i < s.length; i += 1) {
          num = num * 10 + chatToNum(s.charAt(i));
        }
        return num;
      };
      var chatToNum = function(c) {
        if ("0" <= c && c <= "9") {
          return c.charCodeAt(0) - "0".charCodeAt(0);
        }
        throw "illegal char :" + c;
      };
      return _this;
    };
    var qrAlphaNum = function(data) {
      var _mode = QRMode.MODE_ALPHA_NUM;
      var _data = data;
      var _this = {};
      _this.getMode = function() {
        return _mode;
      };
      _this.getLength = function(buffer) {
        return _data.length;
      };
      _this.write = function(buffer) {
        var s = _data;
        var i = 0;
        while (i + 1 < s.length) {
          buffer.put(
            getCode(s.charAt(i)) * 45 + getCode(s.charAt(i + 1)),
            11
          );
          i += 2;
        }
        if (i < s.length) {
          buffer.put(getCode(s.charAt(i)), 6);
        }
      };
      var getCode = function(c) {
        if ("0" <= c && c <= "9") {
          return c.charCodeAt(0) - "0".charCodeAt(0);
        } else if ("A" <= c && c <= "Z") {
          return c.charCodeAt(0) - "A".charCodeAt(0) + 10;
        } else {
          switch (c) {
            case " ":
              return 36;
            case "$":
              return 37;
            case "%":
              return 38;
            case "*":
              return 39;
            case "+":
              return 40;
            case "-":
              return 41;
            case ".":
              return 42;
            case "/":
              return 43;
            case ":":
              return 44;
            default:
              throw "illegal char :" + c;
          }
        }
      };
      return _this;
    };
    var qr8BitByte = function(data) {
      var _mode = QRMode.MODE_8BIT_BYTE;
      var _bytes = qrcode3.stringToBytes(data);
      var _this = {};
      _this.getMode = function() {
        return _mode;
      };
      _this.getLength = function(buffer) {
        return _bytes.length;
      };
      _this.write = function(buffer) {
        for (var i = 0; i < _bytes.length; i += 1) {
          buffer.put(_bytes[i], 8);
        }
      };
      return _this;
    };
    var qrKanji = function(data) {
      var _mode = QRMode.MODE_KANJI;
      var stringToBytes = qrcode3.stringToBytesFuncs["SJIS"];
      if (!stringToBytes) {
        throw "sjis not supported.";
      }
      !function(c, code) {
        var test = stringToBytes(c);
        if (test.length != 2 || (test[0] << 8 | test[1]) != code) {
          throw "sjis not supported.";
        }
      }("友", 38726);
      var _bytes = stringToBytes(data);
      var _this = {};
      _this.getMode = function() {
        return _mode;
      };
      _this.getLength = function(buffer) {
        return ~~(_bytes.length / 2);
      };
      _this.write = function(buffer) {
        var data2 = _bytes;
        var i = 0;
        while (i + 1 < data2.length) {
          var c = (255 & data2[i]) << 8 | 255 & data2[i + 1];
          if (33088 <= c && c <= 40956) {
            c -= 33088;
          } else if (57408 <= c && c <= 60351) {
            c -= 49472;
          } else {
            throw "illegal char at " + (i + 1) + "/" + c;
          }
          c = (c >>> 8 & 255) * 192 + (c & 255);
          buffer.put(c, 13);
          i += 2;
        }
        if (i < data2.length) {
          throw "illegal char at " + (i + 1);
        }
      };
      return _this;
    };
    var byteArrayOutputStream = function() {
      var _bytes = [];
      var _this = {};
      _this.writeByte = function(b) {
        _bytes.push(b & 255);
      };
      _this.writeShort = function(i) {
        _this.writeByte(i);
        _this.writeByte(i >>> 8);
      };
      _this.writeBytes = function(b, off, len) {
        off = off || 0;
        len = len || b.length;
        for (var i = 0; i < len; i += 1) {
          _this.writeByte(b[i + off]);
        }
      };
      _this.writeString = function(s) {
        for (var i = 0; i < s.length; i += 1) {
          _this.writeByte(s.charCodeAt(i));
        }
      };
      _this.toByteArray = function() {
        return _bytes;
      };
      _this.toString = function() {
        var s = "";
        s += "[";
        for (var i = 0; i < _bytes.length; i += 1) {
          if (i > 0) {
            s += ",";
          }
          s += _bytes[i];
        }
        s += "]";
        return s;
      };
      return _this;
    };
    var base64EncodeOutputStream = function() {
      var _buffer = 0;
      var _buflen = 0;
      var _length = 0;
      var _base64 = "";
      var _this = {};
      var writeEncoded = function(b) {
        _base64 += String.fromCharCode(encode3(b & 63));
      };
      var encode3 = function(n) {
        if (n < 0)
          ;
        else if (n < 26) {
          return 65 + n;
        } else if (n < 52) {
          return 97 + (n - 26);
        } else if (n < 62) {
          return 48 + (n - 52);
        } else if (n == 62) {
          return 43;
        } else if (n == 63) {
          return 47;
        }
        throw "n:" + n;
      };
      _this.writeByte = function(n) {
        _buffer = _buffer << 8 | n & 255;
        _buflen += 8;
        _length += 1;
        while (_buflen >= 6) {
          writeEncoded(_buffer >>> _buflen - 6);
          _buflen -= 6;
        }
      };
      _this.flush = function() {
        if (_buflen > 0) {
          writeEncoded(_buffer << 6 - _buflen);
          _buffer = 0;
          _buflen = 0;
        }
        if (_length % 3 != 0) {
          var padlen = 3 - _length % 3;
          for (var i = 0; i < padlen; i += 1) {
            _base64 += "=";
          }
        }
      };
      _this.toString = function() {
        return _base64;
      };
      return _this;
    };
    var base64DecodeInputStream = function(str) {
      var _str = str;
      var _pos = 0;
      var _buffer = 0;
      var _buflen = 0;
      var _this = {};
      _this.read = function() {
        while (_buflen < 8) {
          if (_pos >= _str.length) {
            if (_buflen == 0) {
              return -1;
            }
            throw "unexpected end of file./" + _buflen;
          }
          var c = _str.charAt(_pos);
          _pos += 1;
          if (c == "=") {
            _buflen = 0;
            return -1;
          } else if (c.match(/^\s$/)) {
            continue;
          }
          _buffer = _buffer << 6 | decode(c.charCodeAt(0));
          _buflen += 6;
        }
        var n = _buffer >>> _buflen - 8 & 255;
        _buflen -= 8;
        return n;
      };
      var decode = function(c) {
        if (65 <= c && c <= 90) {
          return c - 65;
        } else if (97 <= c && c <= 122) {
          return c - 97 + 26;
        } else if (48 <= c && c <= 57) {
          return c - 48 + 52;
        } else if (c == 43) {
          return 62;
        } else if (c == 47) {
          return 63;
        } else {
          throw "c:" + c;
        }
      };
      return _this;
    };
    var gifImage = function(width, height) {
      var _width = width;
      var _height = height;
      var _data = new Array(width * height);
      var _this = {};
      _this.setPixel = function(x, y, pixel) {
        _data[y * _width + x] = pixel;
      };
      _this.write = function(out) {
        out.writeString("GIF87a");
        out.writeShort(_width);
        out.writeShort(_height);
        out.writeByte(128);
        out.writeByte(0);
        out.writeByte(0);
        out.writeByte(0);
        out.writeByte(0);
        out.writeByte(0);
        out.writeByte(255);
        out.writeByte(255);
        out.writeByte(255);
        out.writeString(",");
        out.writeShort(0);
        out.writeShort(0);
        out.writeShort(_width);
        out.writeShort(_height);
        out.writeByte(0);
        var lzwMinCodeSize = 2;
        var raster = getLZWRaster(lzwMinCodeSize);
        out.writeByte(lzwMinCodeSize);
        var offset = 0;
        while (raster.length - offset > 255) {
          out.writeByte(255);
          out.writeBytes(raster, offset, 255);
          offset += 255;
        }
        out.writeByte(raster.length - offset);
        out.writeBytes(raster, offset, raster.length - offset);
        out.writeByte(0);
        out.writeString(";");
      };
      var bitOutputStream = function(out) {
        var _out = out;
        var _bitLength = 0;
        var _bitBuffer = 0;
        var _this2 = {};
        _this2.write = function(data, length) {
          if (data >>> length != 0) {
            throw "length over";
          }
          while (_bitLength + length >= 8) {
            _out.writeByte(255 & (data << _bitLength | _bitBuffer));
            length -= 8 - _bitLength;
            data >>>= 8 - _bitLength;
            _bitBuffer = 0;
            _bitLength = 0;
          }
          _bitBuffer = data << _bitLength | _bitBuffer;
          _bitLength = _bitLength + length;
        };
        _this2.flush = function() {
          if (_bitLength > 0) {
            _out.writeByte(_bitBuffer);
          }
        };
        return _this2;
      };
      var getLZWRaster = function(lzwMinCodeSize) {
        var clearCode = 1 << lzwMinCodeSize;
        var endCode = (1 << lzwMinCodeSize) + 1;
        var bitLength = lzwMinCodeSize + 1;
        var table = lzwTable();
        for (var i = 0; i < clearCode; i += 1) {
          table.add(String.fromCharCode(i));
        }
        table.add(String.fromCharCode(clearCode));
        table.add(String.fromCharCode(endCode));
        var byteOut = byteArrayOutputStream();
        var bitOut = bitOutputStream(byteOut);
        bitOut.write(clearCode, bitLength);
        var dataIndex = 0;
        var s = String.fromCharCode(_data[dataIndex]);
        dataIndex += 1;
        while (dataIndex < _data.length) {
          var c = String.fromCharCode(_data[dataIndex]);
          dataIndex += 1;
          if (table.contains(s + c)) {
            s = s + c;
          } else {
            bitOut.write(table.indexOf(s), bitLength);
            if (table.size() < 4095) {
              if (table.size() == 1 << bitLength) {
                bitLength += 1;
              }
              table.add(s + c);
            }
            s = c;
          }
        }
        bitOut.write(table.indexOf(s), bitLength);
        bitOut.write(endCode, bitLength);
        bitOut.flush();
        return byteOut.toByteArray();
      };
      var lzwTable = function() {
        var _map = {};
        var _size = 0;
        var _this2 = {};
        _this2.add = function(key) {
          if (_this2.contains(key)) {
            throw "dup key:" + key;
          }
          _map[key] = _size;
          _size += 1;
        };
        _this2.size = function() {
          return _size;
        };
        _this2.indexOf = function(key) {
          return _map[key];
        };
        _this2.contains = function(key) {
          return typeof _map[key] != "undefined";
        };
        return _this2;
      };
      return _this;
    };
    var createDataURL = function(width, height, getPixel) {
      var gif = gifImage(width, height);
      for (var y = 0; y < height; y += 1) {
        for (var x = 0; x < width; x += 1) {
          gif.setPixel(x, y, getPixel(x, y));
        }
      }
      var b = byteArrayOutputStream();
      gif.write(b);
      var base64 = base64EncodeOutputStream();
      var bytes = b.toByteArray();
      for (var i = 0; i < bytes.length; i += 1) {
        base64.writeByte(bytes[i]);
      }
      base64.flush();
      return "data:image/gif;base64," + base64;
    };
    return qrcode3;
  }();
  !function() {
    qrcode2.stringToBytesFuncs["UTF-8"] = function(s) {
      function toUTF8Array(str) {
        var utf8 = [];
        for (var i = 0; i < str.length; i++) {
          var charcode = str.charCodeAt(i);
          if (charcode < 128)
            utf8.push(charcode);
          else if (charcode < 2048) {
            utf8.push(
              192 | charcode >> 6,
              128 | charcode & 63
            );
          } else if (charcode < 55296 || charcode >= 57344) {
            utf8.push(
              224 | charcode >> 12,
              128 | charcode >> 6 & 63,
              128 | charcode & 63
            );
          } else {
            i++;
            charcode = 65536 + ((charcode & 1023) << 10 | str.charCodeAt(i) & 1023);
            utf8.push(
              240 | charcode >> 18,
              128 | charcode >> 12 & 63,
              128 | charcode >> 6 & 63,
              128 | charcode & 63
            );
          }
        }
        return utf8;
      }
      return toUTF8Array(s);
    };
  }();
  (function(factory) {
    {
      module.exports = factory();
    }
  })(function() {
    return qrcode2;
  });
})(qrcode);
var qrcodeExports = qrcode.exports;
const QR = /* @__PURE__ */ getDefaultExportFromCjs(qrcodeExports);
const __ANCHOR_SIZE = 7;
function resolveConfig(config) {
  return (
    /** @satisfies {import('./types').QRConfig} */
    {
      ...config,
      margin: config.margin ?? 1,
      shape: config.shape ?? /** @type {const} */
      "square",
      logoRatio: config.logoRatio ?? 1,
      moduleFill: config.moduleFill ?? "currentcolor",
      anchorOuterFill: config.anchorOuterFill ?? "currentcolor",
      anchorInnerFill: config.anchorInnerFill ?? "currentcolor",
      typeNumber: config.typeNumber ?? 0,
      errorCorrectionLevel: config.errorCorrectionLevel ?? "H"
    }
  );
}
function createQrSvgParts(config, qr) {
  const { data, margin, shape, logo, logoRatio, anchorInnerFill, anchorOuterFill, moduleFill, typeNumber, errorCorrectionLevel } = resolveConfig(config);
  if (!qr) {
    qr = QR(typeNumber, errorCorrectionLevel);
    qr.addData(data);
    qr.make();
  }
  const count = qr.getModuleCount();
  const size = count + margin * 2;
  const anchors = [
    ["top-left", margin, margin],
    ["top-right", count - __ANCHOR_SIZE + margin, margin],
    ["bottom-left", margin, count - __ANCHOR_SIZE + margin]
  ];
  let anchorsSvg = "";
  for (const [position, x, y] of anchors) {
    let outerD = `M${x} ${y} h7 v7 h-7 v-7z m1 1 v5 h5 v-5 h-5 z`;
    let innerD = `M${x + 2} ${y + 2} h3 v3 h-3 v-3 z`;
    if (shape !== "square") {
      outerD = `M${x + 0.5} ${y}h6s0.5 0 .5 .5v6s0 .5-.5 .5h-6s-.5 0-.5-.5v-6s0-.5 .5-.5zm.75 1s-.25 0-.25 .25v4.5s0 .25 .25 .25h4.5s.25 0 .25-.25v-4.5s0-.25 -.25 -.25h-4.5z`;
      innerD = `M${x + 2.5} ${y + 2} h2 s.5 0 .5 .5 v2 s0 .5-.5 .5 h-2 s-.5 0-.5-.5 v-2 s0-.5 .5-.5 z`;
    }
    const outerPath = `<path class="anchor-outer" fill="${anchorOuterFill}" d="${outerD}" />`;
    const innerPath = `<path class="anchor-outer" fill="${anchorInnerFill}" d="${innerD}" />`;
    anchorsSvg += `<g class="anchor" data-position="${position}">${outerPath} ${innerPath}</g>`;
  }
  anchorsSvg = `<g class="anchors">${anchorsSvg}</g>`;
  let modulesSvg = "";
  for (let col = 0; col < count; col++) {
    for (let row = 0; row < count; row++) {
      if (!qr.isDark(col, row) || isAnchor(col, row, count) || logo && isLogo(col, row, count))
        continue;
      const x = col + margin;
      const y = row + margin;
      modulesSvg += `<rect class="module" fill="${moduleFill}" data-column="${col}" data-row="${row}" x="${x}" y="${y}" width="1" height="1" ${shape === "circle" ? 'rx="0.5"' : ""} />`;
    }
  }
  modulesSvg = `<g class="modules">${modulesSvg}</g>`;
  let logoSvg = "";
  if (logo) {
    const safelyRemovableSize = Math.floor(count * Math.sqrt(0.1));
    const { width, height } = calculateLogoSize(safelyRemovableSize * 0.8, logoRatio);
    const x = (size - width + 1) / 2;
    const y = (size - height + 1) / 2;
    logoSvg = `<image width="${width}" height="${height}" x="${x}" y="${y}" href="${logo}" class="logo" />`;
  }
  return {
    attributes: {
      viewBox: `0, 0 ${size} ${size}`,
      xmlns: "http://www.w3.org/2000/svg",
      version: "1.1"
    },
    anchors: anchorsSvg,
    modules: modulesSvg,
    logo: logoSvg
  };
}
function createQrSvgString(config) {
  const { anchors, attributes, logo, modules } = createQrSvgParts(config);
  const rAttributes = { ...attributes };
  if (config.width)
    rAttributes.width = config.width;
  if (config.height)
    rAttributes.height = config.height;
  return `<svg ${Object.entries(rAttributes).map(([name, value]) => `${name}="${value}"`).join(" ")}>${anchors} ${modules} ${logo}</svg>`;
}
function isAnchor(col, row, count) {
  if (row <= __ANCHOR_SIZE)
    return col <= __ANCHOR_SIZE || col >= count - __ANCHOR_SIZE;
  if (col <= __ANCHOR_SIZE)
    return row >= count - __ANCHOR_SIZE;
  return false;
}
function isLogo(col, row, count) {
  const center = count / 2;
  const maskXToYRatio = 1;
  const safelyRemovableHalf = Math.floor(count * Math.sqrt(0.1) / 2);
  const safelyRemovableHalfX = safelyRemovableHalf * maskXToYRatio;
  const safelyRemovableHalfY = safelyRemovableHalf / maskXToYRatio;
  const safelyRemovableStartX = center - safelyRemovableHalfX;
  const safelyRemovableEndX = center + safelyRemovableHalfX;
  const safelyRemovableStartY = center - safelyRemovableHalfY;
  const safelyRemovableEndY = center + safelyRemovableHalfY;
  return row >= safelyRemovableStartY && row <= safelyRemovableEndY && col >= safelyRemovableStartX && col <= safelyRemovableEndX;
}
function calculateLogoSize(logoSize, logoRatio) {
  if (logoRatio >= 1) {
    return {
      width: logoSize,
      height: logoSize / logoRatio
    };
  }
  return {
    width: logoSize * logoRatio,
    height: logoSize
  };
}
const CodeGenerator_svelte_svelte_type_style_lang = "";
function create_else_block_1(ctx) {
  let p;
  let t0;
  let t1_value = (
    /*codeType*/
    ctx[1] === "QR Code" ? "QR Code" : "Barcode"
  );
  let t1;
  return {
    c() {
      p = element("p");
      t0 = text("Please add a value to generate your ");
      t1 = text(t1_value);
    },
    m(target, anchor) {
      insert(target, p, anchor);
      append(p, t0);
      append(p, t1);
    },
    p(ctx2, dirty) {
      if (dirty & /*codeType*/
      2 && t1_value !== (t1_value = /*codeType*/
      ctx2[1] === "QR Code" ? "QR Code" : "Barcode"))
        set_data(t1, t1_value);
    },
    d(detaching) {
      if (detaching) {
        detach(p);
      }
    }
  };
}
function create_if_block(ctx) {
  let if_block_anchor;
  function select_block_type_1(ctx2, dirty) {
    if (
      /*codeType*/
      ctx2[1] === "QR Code"
    )
      return create_if_block_1;
    return create_else_block;
  }
  let current_block_type = select_block_type_1(ctx);
  let if_block = current_block_type(ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (current_block_type === (current_block_type = select_block_type_1(ctx2)) && if_block) {
        if_block.p(ctx2, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx2);
        if (if_block) {
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      }
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_block.d(detaching);
    }
  };
}
function create_else_block(ctx) {
  let div1;
  let div0;
  let t0;
  let t1;
  let if_block0 = (
    /*showLogo*/
    ctx[3] && /*customLogo*/
    ctx[4] && create_if_block_4(ctx)
  );
  let if_block1 = (
    /*value*/
    ctx[0] && create_if_block_3(ctx)
  );
  let if_block2 = (
    /*showValue*/
    ctx[2] && create_if_block_2(ctx)
  );
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      if (if_block0)
        if_block0.c();
      t0 = space();
      if (if_block1)
        if_block1.c();
      t1 = space();
      if (if_block2)
        if_block2.c();
      attr(div0, "class", "logo-and-barcode svelte-1foui59");
      set_style(
        div0,
        "height",
        /*size*/
        ctx[5] + "px, width: 100%"
      );
      attr(div1, "class", "barcode-container svelte-1foui59");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      if (if_block0)
        if_block0.m(div0, null);
      append(div0, t0);
      if (if_block1)
        if_block1.m(div0, null);
      append(div1, t1);
      if (if_block2)
        if_block2.m(div1, null);
    },
    p(ctx2, dirty) {
      if (
        /*showLogo*/
        ctx2[3] && /*customLogo*/
        ctx2[4]
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
        } else {
          if_block0 = create_if_block_4(ctx2);
          if_block0.c();
          if_block0.m(div0, t0);
        }
      } else if (if_block0) {
        if_block0.d(1);
        if_block0 = null;
      }
      if (
        /*value*/
        ctx2[0]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
        } else {
          if_block1 = create_if_block_3(ctx2);
          if_block1.c();
          if_block1.m(div0, null);
        }
      } else if (if_block1) {
        if_block1.d(1);
        if_block1 = null;
      }
      if (dirty & /*size*/
      32) {
        set_style(
          div0,
          "height",
          /*size*/
          ctx2[5] + "px, width: 100%"
        );
      }
      if (
        /*showValue*/
        ctx2[2]
      ) {
        if (if_block2) {
          if_block2.p(ctx2, dirty);
        } else {
          if_block2 = create_if_block_2(ctx2);
          if_block2.c();
          if_block2.m(div1, null);
        }
      } else if (if_block2) {
        if_block2.d(1);
        if_block2 = null;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
      if (if_block2)
        if_block2.d();
    }
  };
}
function create_if_block_1(ctx) {
  let div2;
  let div0;
  let t0;
  let div1;
  let t1_value = (
    /*showValue*/
    (ctx[2] ? (
      /*value*/
      ctx[0]
    ) : "") + ""
  );
  let t1;
  return {
    c() {
      div2 = element("div");
      div0 = element("div");
      t0 = space();
      div1 = element("div");
      t1 = text(t1_value);
      attr(div1, "class", "qr-value svelte-1foui59");
      set_style(
        div1,
        "color",
        /*primColor*/
        ctx[6]
      );
      set_style(
        div1,
        "max-width",
        /*size*/
        ctx[5] + "px"
      );
      attr(div2, "class", "qr-container svelte-1foui59");
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, div0);
      ctx[12](div0);
      append(div2, t0);
      append(div2, div1);
      append(div1, t1);
    },
    p(ctx2, dirty) {
      if (dirty & /*showValue, value*/
      5 && t1_value !== (t1_value = /*showValue*/
      (ctx2[2] ? (
        /*value*/
        ctx2[0]
      ) : "") + ""))
        set_data(t1, t1_value);
      if (dirty & /*primColor*/
      64) {
        set_style(
          div1,
          "color",
          /*primColor*/
          ctx2[6]
        );
      }
      if (dirty & /*size*/
      32) {
        set_style(
          div1,
          "max-width",
          /*size*/
          ctx2[5] + "px"
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div2);
      }
      ctx[12](null);
    }
  };
}
function create_if_block_4(ctx) {
  let img;
  let img_src_value;
  return {
    c() {
      img = element("img");
      attr(img, "class", "custom-logo svelte-1foui59");
      if (!src_url_equal(img.src, img_src_value = /*customLogo*/
      ctx[4]))
        attr(img, "src", img_src_value);
      attr(img, "alt", "logo");
      set_style(
        img,
        "height",
        /*size*/
        ctx[5] + "px"
      );
    },
    m(target, anchor) {
      insert(target, img, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*customLogo*/
      16 && !src_url_equal(img.src, img_src_value = /*customLogo*/
      ctx2[4])) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*size*/
      32) {
        set_style(
          img,
          "height",
          /*size*/
          ctx2[5] + "px"
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(img);
      }
    }
  };
}
function create_if_block_3(ctx) {
  let svg2;
  return {
    c() {
      svg2 = svg_element("svg");
      attr(svg2, "class", "barcode");
      attr(
        svg2,
        "height",
        /*size*/
        ctx[5]
      );
    },
    m(target, anchor) {
      insert(target, svg2, anchor);
      ctx[13](svg2);
    },
    p(ctx2, dirty) {
      if (dirty & /*size*/
      32) {
        attr(
          svg2,
          "height",
          /*size*/
          ctx2[5]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(svg2);
      }
      ctx[13](null);
    }
  };
}
function create_if_block_2(ctx) {
  let div;
  let p;
  let t;
  return {
    c() {
      div = element("div");
      p = element("p");
      t = text(
        /*value*/
        ctx[0]
      );
      attr(p, "class", "svelte-1foui59");
      attr(div, "class", "barcode-value svelte-1foui59");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, p);
      append(p, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*value*/
      1)
        set_data(
          t,
          /*value*/
          ctx2[0]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_fragment(ctx) {
  let div;
  let styleable_action;
  let mounted;
  let dispose;
  function select_block_type(ctx2, dirty) {
    if (
      /*value*/
      ctx2[0]
    )
      return create_if_block;
    return create_else_block_1;
  }
  let current_block_type = select_block_type(ctx);
  let if_block = current_block_type(ctx);
  return {
    c() {
      div = element("div");
      if_block.c();
      attr(div, "class", "overall svelte-1foui59");
      attr(div, "styles", "border: 3px solid red; width: 100px; height: 200px;");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_block.m(div, null);
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[10].call(
          null,
          div,
          /*$component*/
          ctx[9].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (current_block_type === (current_block_type = select_block_type(ctx2)) && if_block) {
        if_block.p(ctx2, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx2);
        if (if_block) {
          if_block.c();
          if_block.m(div, null);
        }
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      512)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[9].styles
        );
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $component;
  let { value } = $$props;
  let { codeType } = $$props;
  let { showValue } = $$props;
  let { showLogo } = $$props;
  let { customLogo } = $$props;
  let { size } = $$props;
  let { primColor } = $$props;
  const { styleable } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value2) => $$invalidate(9, $component = value2));
  let barcodeElement;
  function generateBarcode() {
    if (barcodeElement && value) {
      JsBarcode$1(barcodeElement, value, {
        displayValue: false,
        // Hide the library's built in value, optionally display it later
        width: size / 100,
        height: size
      });
    }
  }
  let qrContainer;
  const generateQr = () => {
    if (qrContainer && codeType === "QR Code" && value) {
      const svg2 = createQrSvgString({
        data: value,
        logo: showLogo ? customLogo : "",
        moduleFill: primColor,
        anchorOuterFill: primColor,
        anchorInnerFill: primColor,
        width: size,
        height: size
      });
      $$invalidate(8, qrContainer.innerHTML = svg2, qrContainer);
    }
  };
  onMount(() => {
    if (codeType === "Barcode") {
      generateBarcode();
    } else {
      generateQr();
    }
  });
  function div0_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      qrContainer = $$value;
      $$invalidate(8, qrContainer);
    });
  }
  function svg_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      barcodeElement = $$value;
      $$invalidate(7, barcodeElement);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("codeType" in $$props2)
      $$invalidate(1, codeType = $$props2.codeType);
    if ("showValue" in $$props2)
      $$invalidate(2, showValue = $$props2.showValue);
    if ("showLogo" in $$props2)
      $$invalidate(3, showLogo = $$props2.showLogo);
    if ("customLogo" in $$props2)
      $$invalidate(4, customLogo = $$props2.customLogo);
    if ("size" in $$props2)
      $$invalidate(5, size = $$props2.size);
    if ("primColor" in $$props2)
      $$invalidate(6, primColor = $$props2.primColor);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*codeType, value, barcodeElement, size*/
    163) {
      if (codeType === "Barcode" && value && barcodeElement && size) {
        generateBarcode();
      }
    }
    if ($$self.$$.dirty & /*codeType, value, qrContainer, showLogo, customLogo, size, primColor*/
    379) {
      if (codeType === "QR Code" && value && qrContainer && (showLogo !== void 0 || customLogo !== void 0 || size || primColor)) {
        generateQr();
      }
    }
  };
  return [
    value,
    codeType,
    showValue,
    showLogo,
    customLogo,
    size,
    primColor,
    barcodeElement,
    qrContainer,
    $component,
    styleable,
    component,
    div0_binding,
    svg_binding
  ];
}
class CodeGenerator extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      value: 0,
      codeType: 1,
      showValue: 2,
      showLogo: 3,
      customLogo: 4,
      size: 5,
      primColor: 6
    });
  }
}
export {
  CodeGenerator as default
};
