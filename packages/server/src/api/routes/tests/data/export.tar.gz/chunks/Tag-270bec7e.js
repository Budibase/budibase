import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, t as text, a as space, b as attr, f as insert, g as append, q as action_destroyer, j as set_data, k as transition_in, z as group_outros, n as transition_out, A as check_outros, h as is_function, o as detach, u as getContext, v as component_subscribe, aq as ClearButton, c as create_component, m as mount_component, p as destroy_component } from "./index-8b9900f1.js";
const indexVars = "";
const Tag_svelte_svelte_type_style_lang = "";
function create_if_block(ctx) {
  let clearbutton;
  let current;
  clearbutton = new ClearButton({});
  clearbutton.$on("click", function() {
    if (is_function(
      /*onClick*/
      ctx[0]
    ))
      ctx[0].apply(this, arguments);
  });
  return {
    c() {
      create_component(clearbutton.$$.fragment);
    },
    m(target, anchor) {
      mount_component(clearbutton, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
    },
    i(local) {
      if (current)
        return;
      transition_in(clearbutton.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(clearbutton.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(clearbutton, detaching);
    }
  };
}
function create_fragment(ctx) {
  let div;
  let span;
  let t0;
  let t1;
  let div_class_value;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  let if_block = (
    /*closable*/
    ctx[1] && create_if_block(ctx)
  );
  return {
    c() {
      div = element("div");
      span = element("span");
      t0 = text(
        /*componentText*/
        ctx[3]
      );
      t1 = space();
      if (if_block)
        if_block.c();
      attr(span, "class", "spectrum-Tag-label svelte-jml011");
      attr(div, "class", div_class_value = "spectrum-Tag spectrum-Tag--size" + /*size*/
      ctx[2] + " svelte-jml011");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, span);
      append(span, t0);
      append(div, t1);
      if (if_block)
        if_block.m(div, null);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[6].call(
          null,
          div,
          /*styles*/
          ctx[4]
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (!current || dirty & /*componentText*/
      8)
        set_data(
          t0,
          /*componentText*/
          ctx2[3]
        );
      if (
        /*closable*/
        ctx2[1]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*closable*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (!current || dirty & /*size*/
      4 && div_class_value !== (div_class_value = "spectrum-Tag spectrum-Tag--size" + /*size*/
      ctx2[2] + " svelte-jml011")) {
        attr(div, "class", div_class_value);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*styles*/
      16)
        styleable_action.update.call(
          null,
          /*styles*/
          ctx2[4]
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block)
        if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let styles;
  let componentText;
  let $component;
  let $builderStore;
  let { onClick } = $$props;
  let { text: text2 = "" } = $$props;
  let { color } = $$props;
  let { textColor } = $$props;
  let { closable = false } = $$props;
  let { size = "M" } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(11, $component = value));
  const { styleable, builderStore } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(12, $builderStore = value));
  const getComponentText = (text3, builderState, componentState) => {
    if (!builderState.inBuilder || componentState.editing) {
      return text3 || " ";
    }
    return text3 || componentState.name || "Placeholder text";
  };
  const enrichStyles = (styles2, color2, textColor2) => {
    if (!color2) {
      return styles2;
    }
    return {
      ...styles2,
      normal: {
        ...styles2 == null ? void 0 : styles2.normal,
        "background-color": color2,
        "border-color": color2,
        color: textColor2 || "white",
        "--spectrum-clearbutton-medium-icon-color": "white"
      }
    };
  };
  $$self.$$set = ($$props2) => {
    if ("onClick" in $$props2)
      $$invalidate(0, onClick = $$props2.onClick);
    if ("text" in $$props2)
      $$invalidate(8, text2 = $$props2.text);
    if ("color" in $$props2)
      $$invalidate(9, color = $$props2.color);
    if ("textColor" in $$props2)
      $$invalidate(10, textColor = $$props2.textColor);
    if ("closable" in $$props2)
      $$invalidate(1, closable = $$props2.closable);
    if ("size" in $$props2)
      $$invalidate(2, size = $$props2.size);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$component, color, textColor*/
    3584) {
      $$invalidate(4, styles = enrichStyles($component.styles, color, textColor));
    }
    if ($$self.$$.dirty & /*text, $builderStore, $component*/
    6400) {
      $$invalidate(3, componentText = getComponentText(text2, $builderStore, $component));
    }
  };
  return [
    onClick,
    closable,
    size,
    componentText,
    styles,
    component,
    styleable,
    builderStore,
    text2,
    color,
    textColor,
    $component,
    $builderStore
  ];
}
class Tag extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      onClick: 0,
      text: 8,
      color: 9,
      textColor: 10,
      closable: 1,
      size: 2
    });
  }
}
export {
  Tag as default
};
