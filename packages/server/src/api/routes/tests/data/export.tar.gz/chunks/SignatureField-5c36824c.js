import { S as SvelteComponent, i as init, s as safe_not_equal, cc as SignatureModal, W as binding_callbacks, a0 as bind, c as create_component, a as space, m as mount_component, f as insert, a1 as add_flush_callback, k as transition_in, n as transition_out, o as detach, p as destroy_component, u as getContext, v as component_subscribe, y as empty, z as group_outros, A as check_outros, cd as Signature, e as element, b as attr, cb as ActionButton, t as text, j as set_data } from "./index-8b9900f1.js";
import { F as Field } from "./Field-a0270b82.js";
import "./Placeholder-4dedd9c4.js";
import "./InnerForm-0042fa8f.js";
const SignatureField_svelte_svelte_type_style_lang = "";
function create_if_block(ctx) {
  let show_if;
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block_1, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    var _a, _b, _c, _d;
    if (dirty & /*fieldState*/
    256)
      show_if = null;
    if (show_if == null)
      show_if = !!(Array.isArray(
        /*fieldState*/
        (_a = ctx2[8]) == null ? void 0 : _a.value
      ) && !/*fieldState*/
      ((_c = (_b = ctx2[8]) == null ? void 0 : _b.value) == null ? void 0 : _c.length) || !/*fieldState*/
      ((_d = ctx2[8]) == null ? void 0 : _d.value));
    if (show_if)
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx, -1);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2, dirty);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_else_block(ctx) {
  var _a;
  let div;
  let coresignature;
  let current;
  coresignature = new Signature({
    props: {
      darkMode: (
        /*darkMode*/
        ctx[12]
      ),
      disabled: (
        /*$builderStore*/
        ctx[13].inBuilder || /*fieldState*/
        ctx[8].disabled
      ),
      editable: false,
      value: (
        /*fieldState*/
        (_a = ctx[8]) == null ? void 0 : _a.value
      )
    }
  });
  coresignature.$on(
    "clear",
    /*deleteSignature*/
    ctx[17]
  );
  return {
    c() {
      div = element("div");
      create_component(coresignature.$$.fragment);
      attr(div, "class", "signature-field svelte-1v3n4b5");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(coresignature, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      const coresignature_changes = {};
      if (dirty & /*darkMode*/
      4096)
        coresignature_changes.darkMode = /*darkMode*/
        ctx2[12];
      if (dirty & /*$builderStore, fieldState*/
      8448)
        coresignature_changes.disabled = /*$builderStore*/
        ctx2[13].inBuilder || /*fieldState*/
        ctx2[8].disabled;
      if (dirty & /*fieldState*/
      256)
        coresignature_changes.value = /*fieldState*/
        (_a2 = ctx2[8]) == null ? void 0 : _a2.value;
      coresignature.$set(coresignature_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(coresignature.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(coresignature.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(coresignature);
    }
  };
}
function create_if_block_1(ctx) {
  let actionbutton;
  let current;
  actionbutton = new ActionButton({
    props: {
      fullWidth: true,
      disabled: (
        /*fieldState*/
        ctx[8].disabled
      ),
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  actionbutton.$on(
    "click",
    /*click_handler*/
    ctx[22]
  );
  return {
    c() {
      create_component(actionbutton.$$.fragment);
    },
    m(target, anchor) {
      mount_component(actionbutton, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const actionbutton_changes = {};
      if (dirty & /*fieldState*/
      256)
        actionbutton_changes.disabled = /*fieldState*/
        ctx2[8].disabled;
      if (dirty & /*$$scope, buttonText*/
      536871040) {
        actionbutton_changes.$$scope = { dirty, ctx: ctx2 };
      }
      actionbutton.$set(actionbutton_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(actionbutton.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(actionbutton.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(actionbutton, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let t_value = (
    /*buttonText*/
    (ctx[7] ? (
      /*buttonText*/
      ctx[7]
    ) : "Add signature") + ""
  );
  let t;
  return {
    c() {
      t = text(t_value);
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*buttonText*/
      128 && t_value !== (t_value = /*buttonText*/
      (ctx2[7] ? (
        /*buttonText*/
        ctx2[7]
      ) : "Add signature") + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*fieldState*/
    ctx[8] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*fieldState*/
        ctx2[8]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*fieldState*/
          256) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  var _a, _b;
  let signaturemodal;
  let t;
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let updating_fieldSchema;
  let current;
  let signaturemodal_props = {
    onConfirm: (
      /*saveSignature*/
      ctx[16]
    ),
    title: (
      /*label*/
      ctx[1] || /*fieldSchema*/
      ((_a = ctx[10]) == null ? void 0 : _a.name) || ""
    ),
    value: (
      /*fieldState*/
      (_b = ctx[8]) == null ? void 0 : _b.value
    ),
    darkMode: (
      /*darkMode*/
      ctx[12]
    )
  };
  signaturemodal = new SignatureModal({ props: signaturemodal_props });
  ctx[21](signaturemodal);
  function field_1_fieldState_binding(value) {
    ctx[23](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[24](value);
  }
  function field_1_fieldSchema_binding(value) {
    ctx[25](value);
  }
  let field_1_props = {
    label: (
      /*label*/
      ctx[1]
    ),
    field: (
      /*field*/
      ctx[0]
    ),
    disabled: (
      /*disabled*/
      ctx[2]
    ),
    readonly: (
      /*readonly*/
      ctx[3]
    ),
    validation: (
      /*validation*/
      ctx[4]
    ),
    span: (
      /*span*/
      ctx[5]
    ),
    helpText: (
      /*helpText*/
      ctx[6]
    ),
    type: "signature_single",
    defaultValue: [],
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*fieldState*/
    ctx[8] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[8];
  }
  if (
    /*fieldApi*/
    ctx[9] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[9];
  }
  if (
    /*fieldSchema*/
    ctx[10] !== void 0
  ) {
    field_1_props.fieldSchema = /*fieldSchema*/
    ctx[10];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  binding_callbacks.push(() => bind(field_1, "fieldSchema", field_1_fieldSchema_binding));
  return {
    c() {
      create_component(signaturemodal.$$.fragment);
      t = space();
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(signaturemodal, target, anchor);
      insert(target, t, anchor);
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      var _a2, _b2;
      const signaturemodal_changes = {};
      if (dirty & /*label, fieldSchema*/
      1026)
        signaturemodal_changes.title = /*label*/
        ctx2[1] || /*fieldSchema*/
        ((_a2 = ctx2[10]) == null ? void 0 : _a2.name) || "";
      if (dirty & /*fieldState*/
      256)
        signaturemodal_changes.value = /*fieldState*/
        (_b2 = ctx2[8]) == null ? void 0 : _b2.value;
      if (dirty & /*darkMode*/
      4096)
        signaturemodal_changes.darkMode = /*darkMode*/
        ctx2[12];
      signaturemodal.$set(signaturemodal_changes);
      const field_1_changes = {};
      if (dirty & /*label*/
      2)
        field_1_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*field*/
      1)
        field_1_changes.field = /*field*/
        ctx2[0];
      if (dirty & /*disabled*/
      4)
        field_1_changes.disabled = /*disabled*/
        ctx2[2];
      if (dirty & /*readonly*/
      8)
        field_1_changes.readonly = /*readonly*/
        ctx2[3];
      if (dirty & /*validation*/
      16)
        field_1_changes.validation = /*validation*/
        ctx2[4];
      if (dirty & /*span*/
      32)
        field_1_changes.span = /*span*/
        ctx2[5];
      if (dirty & /*helpText*/
      64)
        field_1_changes.helpText = /*helpText*/
        ctx2[6];
      if (dirty & /*$$scope, fieldState, $builderStore, modal, buttonText, darkMode*/
      536885632) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty & /*fieldState*/
      256) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[8];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty & /*fieldApi*/
      512) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[9];
        add_flush_callback(() => updating_fieldApi = false);
      }
      if (!updating_fieldSchema && dirty & /*fieldSchema*/
      1024) {
        updating_fieldSchema = true;
        field_1_changes.fieldSchema = /*fieldSchema*/
        ctx2[10];
        add_flush_callback(() => updating_fieldSchema = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(signaturemodal.$$.fragment, local);
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(signaturemodal.$$.fragment, local);
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      ctx[21](null);
      destroy_component(signaturemodal, detaching);
      destroy_component(field_1, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let currentTheme;
  let darkMode;
  let $context;
  let $builderStore;
  let { field } = $$props;
  let { label } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { validation } = $$props;
  let { onChange } = $$props;
  let { span } = $$props;
  let { helpText = null } = $$props;
  let { buttonText = "Add signature" } = $$props;
  let fieldState;
  let fieldApi;
  let fieldSchema;
  let modal;
  const { API, notificationStore, builderStore } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(13, $builderStore = value));
  const context = getContext("context");
  component_subscribe($$self, context, (value) => $$invalidate(20, $context = value));
  const formContext = getContext("form");
  const saveSignature = async (canvas) => {
    var _a, _b;
    try {
      const signatureFile = canvas.toFile();
      let updateValue;
      if (signatureFile) {
        let attachRequest = new FormData();
        attachRequest.append("file", signatureFile);
        let sourceId = (_a = formContext == null ? void 0 : formContext.dataSource) == null ? void 0 : _a.tableId;
        if (((_b = formContext == null ? void 0 : formContext.dataSource) == null ? void 0 : _b.type) === "viewV2") {
          sourceId = formContext.dataSource.id;
        }
        const resp = await API.uploadAttachment(sourceId, attachRequest);
        const [signatureAttachment] = resp;
        updateValue = signatureAttachment;
      } else {
        updateValue = null;
      }
      const changed = fieldApi.setValue(updateValue);
      if (onChange && changed) {
        onChange({ value: updateValue });
      }
    } catch (error) {
      notificationStore.actions.error(`There was a problem saving your signature`);
      console.error(error);
    }
  };
  const deleteSignature = async () => {
    const changed = fieldApi.setValue(null);
    if (onChange && changed) {
      onChange({ value: null });
    }
  };
  function signaturemodal_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      modal = $$value;
      $$invalidate(11, modal);
    });
  }
  const click_handler = () => {
    if (!$builderStore.inBuilder) {
      modal.show();
    }
  };
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(8, fieldState);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(9, fieldApi);
  }
  function field_1_fieldSchema_binding(value) {
    fieldSchema = value;
    $$invalidate(10, fieldSchema);
  }
  $$self.$$set = ($$props2) => {
    if ("field" in $$props2)
      $$invalidate(0, field = $$props2.field);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("disabled" in $$props2)
      $$invalidate(2, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(3, readonly = $$props2.readonly);
    if ("validation" in $$props2)
      $$invalidate(4, validation = $$props2.validation);
    if ("onChange" in $$props2)
      $$invalidate(18, onChange = $$props2.onChange);
    if ("span" in $$props2)
      $$invalidate(5, span = $$props2.span);
    if ("helpText" in $$props2)
      $$invalidate(6, helpText = $$props2.helpText);
    if ("buttonText" in $$props2)
      $$invalidate(7, buttonText = $$props2.buttonText);
  };
  $$self.$$.update = () => {
    var _a;
    if ($$self.$$.dirty & /*$context*/
    1048576) {
      $$invalidate(19, currentTheme = (_a = $context == null ? void 0 : $context.device) == null ? void 0 : _a.theme);
    }
    if ($$self.$$.dirty & /*currentTheme*/
    524288) {
      $$invalidate(12, darkMode = !(currentTheme == null ? void 0 : currentTheme.includes("light")));
    }
  };
  return [
    field,
    label,
    disabled,
    readonly,
    validation,
    span,
    helpText,
    buttonText,
    fieldState,
    fieldApi,
    fieldSchema,
    modal,
    darkMode,
    $builderStore,
    builderStore,
    context,
    saveSignature,
    deleteSignature,
    onChange,
    currentTheme,
    $context,
    signaturemodal_binding,
    click_handler,
    field_1_fieldState_binding,
    field_1_fieldApi_binding,
    field_1_fieldSchema_binding
  ];
}
class SignatureField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      field: 0,
      label: 1,
      disabled: 2,
      readonly: 3,
      validation: 4,
      onChange: 18,
      span: 5,
      helpText: 6,
      buttonText: 7
    });
  }
}
export {
  SignatureField as default
};
