import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, a as space, t as text, b as attr, al as set_style, f as insert, g as append, q as action_destroyer, j as set_data, h as is_function, B as noop, o as detach, r as run_all, u as getContext, v as component_subscribe, ae as src_url_equal } from "./index-8b9900f1.js";
const CardHorizontal_svelte_svelte_type_style_lang = "";
function create_if_block(ctx) {
  let img;
  let img_src_value;
  return {
    c() {
      img = element("img");
      set_style(
        img,
        "--imageWidth",
        /*imageWidth*/
        ctx[9]
      );
      set_style(
        img,
        "--imageHeight",
        /*imageHeight*/
        ctx[10]
      );
      attr(img, "class", "image svelte-140q71n");
      if (!src_url_equal(img.src, img_src_value = /*imageUrl*/
      ctx[0]))
        attr(img, "src", img_src_value);
      attr(img, "alt", "");
    },
    m(target, anchor) {
      insert(target, img, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*imageWidth*/
      512) {
        set_style(
          img,
          "--imageWidth",
          /*imageWidth*/
          ctx2[9]
        );
      }
      if (dirty & /*imageHeight*/
      1024) {
        set_style(
          img,
          "--imageHeight",
          /*imageHeight*/
          ctx2[10]
        );
      }
      if (dirty & /*imageUrl*/
      1 && !src_url_equal(img.src, img_src_value = /*imageUrl*/
      ctx2[0])) {
        attr(img, "src", img_src_value);
      }
    },
    d(detaching) {
      if (detaching) {
        detach(img);
      }
    }
  };
}
function create_fragment(ctx) {
  let div1;
  let t0;
  let div0;
  let main;
  let h2;
  let t1;
  let t2;
  let p0;
  let t3;
  let t4;
  let footer;
  let p1;
  let t5;
  let t6;
  let a;
  let t7;
  let a_href_value;
  let styleable_action;
  let mounted;
  let dispose;
  let if_block = (
    /*showImage*/
    ctx[11] && create_if_block(ctx)
  );
  return {
    c() {
      div1 = element("div");
      if (if_block)
        if_block.c();
      t0 = space();
      div0 = element("div");
      main = element("main");
      h2 = element("h2");
      t1 = text(
        /*heading*/
        ctx[1]
      );
      t2 = space();
      p0 = element("p");
      t3 = text(
        /*description*/
        ctx[2]
      );
      t4 = space();
      footer = element("footer");
      p1 = element("p");
      t5 = text(
        /*subtext*/
        ctx[3]
      );
      t6 = space();
      a = element("a");
      t7 = text(
        /*linkText*/
        ctx[4]
      );
      attr(h2, "class", "heading svelte-140q71n");
      attr(p0, "class", "text svelte-140q71n");
      attr(p1, "class", "subtext svelte-140q71n");
      set_style(
        a,
        "--linkColor",
        /*linkColor*/
        ctx[6]
      );
      set_style(
        a,
        "--linkHoverColor",
        /*linkHoverColor*/
        ctx[7]
      );
      attr(a, "href", a_href_value = /*linkUrl*/
      ctx[5] || "/");
      attr(a, "class", "svelte-140q71n");
      attr(footer, "class", "svelte-140q71n");
      attr(div0, "class", "content svelte-140q71n");
      attr(div1, "class", "container svelte-140q71n");
      set_style(
        div1,
        "--cardWidth",
        /*cardWidth*/
        ctx[8]
      );
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      if (if_block)
        if_block.m(div1, null);
      append(div1, t0);
      append(div1, div0);
      append(div0, main);
      append(main, h2);
      append(h2, t1);
      append(main, t2);
      append(main, p0);
      append(p0, t3);
      append(div0, t4);
      append(div0, footer);
      append(footer, p1);
      append(p1, t5);
      append(footer, t6);
      append(footer, a);
      append(a, t7);
      if (!mounted) {
        dispose = [
          action_destroyer(
            /*linkable*/
            ctx[14].call(null, a)
          ),
          action_destroyer(styleable_action = /*styleable*/
          ctx[13].call(
            null,
            div1,
            /*$component*/
            ctx[12].styles
          ))
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (
        /*showImage*/
        ctx2[11]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          if_block.m(div1, t0);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (dirty & /*heading*/
      2)
        set_data(
          t1,
          /*heading*/
          ctx2[1]
        );
      if (dirty & /*description*/
      4)
        set_data(
          t3,
          /*description*/
          ctx2[2]
        );
      if (dirty & /*subtext*/
      8)
        set_data(
          t5,
          /*subtext*/
          ctx2[3]
        );
      if (dirty & /*linkText*/
      16)
        set_data(
          t7,
          /*linkText*/
          ctx2[4]
        );
      if (dirty & /*linkColor*/
      64) {
        set_style(
          a,
          "--linkColor",
          /*linkColor*/
          ctx2[6]
        );
      }
      if (dirty & /*linkHoverColor*/
      128) {
        set_style(
          a,
          "--linkHoverColor",
          /*linkHoverColor*/
          ctx2[7]
        );
      }
      if (dirty & /*linkUrl*/
      32 && a_href_value !== (a_href_value = /*linkUrl*/
      ctx2[5] || "/")) {
        attr(a, "href", a_href_value);
      }
      if (dirty & /*cardWidth*/
      256) {
        set_style(
          div1,
          "--cardWidth",
          /*cardWidth*/
          ctx2[8]
        );
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      4096)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[12].styles
        );
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if (if_block)
        if_block.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let showImage;
  let $component;
  const { styleable, linkable } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(12, $component = value));
  const className = "";
  let { imageUrl = "" } = $$props;
  let { heading = "" } = $$props;
  let { description = "" } = $$props;
  let { subtext = "" } = $$props;
  let { linkText = "" } = $$props;
  let { linkUrl } = $$props;
  let { linkColor } = $$props;
  let { linkHoverColor } = $$props;
  let { cardWidth } = $$props;
  let { imageWidth } = $$props;
  let { imageHeight } = $$props;
  $$self.$$set = ($$props2) => {
    if ("imageUrl" in $$props2)
      $$invalidate(0, imageUrl = $$props2.imageUrl);
    if ("heading" in $$props2)
      $$invalidate(1, heading = $$props2.heading);
    if ("description" in $$props2)
      $$invalidate(2, description = $$props2.description);
    if ("subtext" in $$props2)
      $$invalidate(3, subtext = $$props2.subtext);
    if ("linkText" in $$props2)
      $$invalidate(4, linkText = $$props2.linkText);
    if ("linkUrl" in $$props2)
      $$invalidate(5, linkUrl = $$props2.linkUrl);
    if ("linkColor" in $$props2)
      $$invalidate(6, linkColor = $$props2.linkColor);
    if ("linkHoverColor" in $$props2)
      $$invalidate(7, linkHoverColor = $$props2.linkHoverColor);
    if ("cardWidth" in $$props2)
      $$invalidate(8, cardWidth = $$props2.cardWidth);
    if ("imageWidth" in $$props2)
      $$invalidate(9, imageWidth = $$props2.imageWidth);
    if ("imageHeight" in $$props2)
      $$invalidate(10, imageHeight = $$props2.imageHeight);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*imageUrl*/
    1) {
      $$invalidate(11, showImage = !!imageUrl);
    }
  };
  return [
    imageUrl,
    heading,
    description,
    subtext,
    linkText,
    linkUrl,
    linkColor,
    linkHoverColor,
    cardWidth,
    imageWidth,
    imageHeight,
    showImage,
    $component,
    styleable,
    linkable,
    component,
    className
  ];
}
class CardHorizontal extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      className: 16,
      imageUrl: 0,
      heading: 1,
      description: 2,
      subtext: 3,
      linkText: 4,
      linkUrl: 5,
      linkColor: 6,
      linkHoverColor: 7,
      cardWidth: 8,
      imageWidth: 9,
      imageHeight: 10
    });
  }
  get className() {
    return this.$$.ctx[16];
  }
}
export {
  CardHorizontal as default
};
