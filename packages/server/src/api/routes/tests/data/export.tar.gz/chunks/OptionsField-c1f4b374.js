import { S as SvelteComponent, i as init, s as safe_not_equal, W as binding_callbacks, a0 as bind, c as create_component, m as mount_component, a1 as add_flush_callback, k as transition_in, n as transition_out, p as destroy_component, y as empty, f as insert, z as group_outros, A as check_outros, o as detach, c0 as Select } from "./index-8b9900f1.js";
import { R as RadioGroup } from "./RadioGroup-75258068.js";
import { F as Field } from "./Field-a0270b82.js";
import { g as getOptions } from "./optionsParser-a13cad91.js";
import "./Placeholder-4dedd9c4.js";
import "./InnerForm-0042fa8f.js";
function create_if_block(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block_1, create_if_block_2];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (!/*optionsType*/
    ctx2[5] || /*optionsType*/
    ctx2[5] === "select")
      return 0;
    if (
      /*optionsType*/
      ctx2[5] === "radio"
    )
      return 1;
    return -1;
  }
  if (~(current_block_type_index = select_block_type(ctx))) {
    if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  }
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].m(target, anchor);
      }
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if (~current_block_type_index) {
          if_blocks[current_block_type_index].p(ctx2, dirty);
        }
      } else {
        if (if_block) {
          group_outros();
          transition_out(if_blocks[previous_block_index], 1, 1, () => {
            if_blocks[previous_block_index] = null;
          });
          check_outros();
        }
        if (~current_block_type_index) {
          if_block = if_blocks[current_block_type_index];
          if (!if_block) {
            if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
            if_block.c();
          } else {
            if_block.p(ctx2, dirty);
          }
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        } else {
          if_block = null;
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].d(detaching);
      }
    }
  };
}
function create_if_block_2(ctx) {
  let coreradiogroup;
  let current;
  coreradiogroup = new RadioGroup({
    props: {
      value: (
        /*fieldState*/
        ctx[14].value
      ),
      id: (
        /*fieldState*/
        ctx[14].fieldId
      ),
      disabled: (
        /*fieldState*/
        ctx[14].disabled
      ),
      readonly: (
        /*fieldState*/
        ctx[14].readonly
      ),
      error: (
        /*fieldState*/
        ctx[14].error
      ),
      options: (
        /*options*/
        ctx[16]
      ),
      direction: (
        /*direction*/
        ctx[9]
      ),
      getOptionLabel: (
        /*flatOptions*/
        ctx[17] ? func_4 : func_5
      ),
      getOptionTitle: (
        /*flatOptions*/
        ctx[17] ? func_6 : func_7
      ),
      getOptionValue: (
        /*flatOptions*/
        ctx[17] ? func_8 : func_9
      ),
      sort: (
        /*sort*/
        ctx[10]
      )
    }
  });
  coreradiogroup.$on(
    "change",
    /*handleChange*/
    ctx[18]
  );
  return {
    c() {
      create_component(coreradiogroup.$$.fragment);
    },
    m(target, anchor) {
      mount_component(coreradiogroup, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const coreradiogroup_changes = {};
      if (dirty & /*fieldState*/
      16384)
        coreradiogroup_changes.value = /*fieldState*/
        ctx2[14].value;
      if (dirty & /*fieldState*/
      16384)
        coreradiogroup_changes.id = /*fieldState*/
        ctx2[14].fieldId;
      if (dirty & /*fieldState*/
      16384)
        coreradiogroup_changes.disabled = /*fieldState*/
        ctx2[14].disabled;
      if (dirty & /*fieldState*/
      16384)
        coreradiogroup_changes.readonly = /*fieldState*/
        ctx2[14].readonly;
      if (dirty & /*fieldState*/
      16384)
        coreradiogroup_changes.error = /*fieldState*/
        ctx2[14].error;
      if (dirty & /*options*/
      65536)
        coreradiogroup_changes.options = /*options*/
        ctx2[16];
      if (dirty & /*direction*/
      512)
        coreradiogroup_changes.direction = /*direction*/
        ctx2[9];
      if (dirty & /*flatOptions*/
      131072)
        coreradiogroup_changes.getOptionLabel = /*flatOptions*/
        ctx2[17] ? func_4 : func_5;
      if (dirty & /*flatOptions*/
      131072)
        coreradiogroup_changes.getOptionTitle = /*flatOptions*/
        ctx2[17] ? func_6 : func_7;
      if (dirty & /*flatOptions*/
      131072)
        coreradiogroup_changes.getOptionValue = /*flatOptions*/
        ctx2[17] ? func_8 : func_9;
      if (dirty & /*sort*/
      1024)
        coreradiogroup_changes.sort = /*sort*/
        ctx2[10];
      coreradiogroup.$set(coreradiogroup_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(coreradiogroup.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(coreradiogroup.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(coreradiogroup, detaching);
    }
  };
}
function create_if_block_1(ctx) {
  let coreselect;
  let current;
  coreselect = new Select({
    props: {
      value: (
        /*fieldState*/
        ctx[14].value
      ),
      id: (
        /*fieldState*/
        ctx[14].fieldId
      ),
      disabled: (
        /*fieldState*/
        ctx[14].disabled
      ),
      readonly: (
        /*fieldState*/
        ctx[14].readonly
      ),
      error: (
        /*fieldState*/
        ctx[14].error
      ),
      options: (
        /*options*/
        ctx[16]
      ),
      placeholder: (
        /*placeholder*/
        ctx[2]
      ),
      getOptionLabel: (
        /*flatOptions*/
        ctx[17] ? func : func_1
      ),
      getOptionValue: (
        /*flatOptions*/
        ctx[17] ? func_2 : func_3
      ),
      autocomplete: (
        /*autocomplete*/
        ctx[8]
      ),
      sort: (
        /*sort*/
        ctx[10]
      )
    }
  });
  coreselect.$on(
    "change",
    /*handleChange*/
    ctx[18]
  );
  return {
    c() {
      create_component(coreselect.$$.fragment);
    },
    m(target, anchor) {
      mount_component(coreselect, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const coreselect_changes = {};
      if (dirty & /*fieldState*/
      16384)
        coreselect_changes.value = /*fieldState*/
        ctx2[14].value;
      if (dirty & /*fieldState*/
      16384)
        coreselect_changes.id = /*fieldState*/
        ctx2[14].fieldId;
      if (dirty & /*fieldState*/
      16384)
        coreselect_changes.disabled = /*fieldState*/
        ctx2[14].disabled;
      if (dirty & /*fieldState*/
      16384)
        coreselect_changes.readonly = /*fieldState*/
        ctx2[14].readonly;
      if (dirty & /*fieldState*/
      16384)
        coreselect_changes.error = /*fieldState*/
        ctx2[14].error;
      if (dirty & /*options*/
      65536)
        coreselect_changes.options = /*options*/
        ctx2[16];
      if (dirty & /*placeholder*/
      4)
        coreselect_changes.placeholder = /*placeholder*/
        ctx2[2];
      if (dirty & /*flatOptions*/
      131072)
        coreselect_changes.getOptionLabel = /*flatOptions*/
        ctx2[17] ? func : func_1;
      if (dirty & /*flatOptions*/
      131072)
        coreselect_changes.getOptionValue = /*flatOptions*/
        ctx2[17] ? func_2 : func_3;
      if (dirty & /*autocomplete*/
      256)
        coreselect_changes.autocomplete = /*autocomplete*/
        ctx2[8];
      if (dirty & /*sort*/
      1024)
        coreselect_changes.sort = /*sort*/
        ctx2[10];
      coreselect.$set(coreselect_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(coreselect.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(coreselect.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(coreselect, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*fieldState*/
    ctx[14] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*fieldState*/
        ctx2[14]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*fieldState*/
          16384) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let updating_fieldSchema;
  let current;
  function field_1_fieldState_binding(value) {
    ctx[25](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[26](value);
  }
  function field_1_fieldSchema_binding(value) {
    ctx[27](value);
  }
  let field_1_props = {
    field: (
      /*field*/
      ctx[0]
    ),
    label: (
      /*label*/
      ctx[1]
    ),
    disabled: (
      /*disabled*/
      ctx[3]
    ),
    readonly: (
      /*readonly*/
      ctx[4]
    ),
    validation: (
      /*validation*/
      ctx[6]
    ),
    defaultValue: (
      /*defaultValue*/
      ctx[7]
    ),
    span: (
      /*span*/
      ctx[11]
    ),
    helpText: (
      /*helpText*/
      ctx[12]
    ),
    type: "options",
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*fieldState*/
    ctx[14] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[14];
  }
  if (
    /*fieldApi*/
    ctx[15] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[15];
  }
  if (
    /*fieldSchema*/
    ctx[13] !== void 0
  ) {
    field_1_props.fieldSchema = /*fieldSchema*/
    ctx[13];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  binding_callbacks.push(() => bind(field_1, "fieldSchema", field_1_fieldSchema_binding));
  return {
    c() {
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const field_1_changes = {};
      if (dirty & /*field*/
      1)
        field_1_changes.field = /*field*/
        ctx2[0];
      if (dirty & /*label*/
      2)
        field_1_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*disabled*/
      8)
        field_1_changes.disabled = /*disabled*/
        ctx2[3];
      if (dirty & /*readonly*/
      16)
        field_1_changes.readonly = /*readonly*/
        ctx2[4];
      if (dirty & /*validation*/
      64)
        field_1_changes.validation = /*validation*/
        ctx2[6];
      if (dirty & /*defaultValue*/
      128)
        field_1_changes.defaultValue = /*defaultValue*/
        ctx2[7];
      if (dirty & /*span*/
      2048)
        field_1_changes.span = /*span*/
        ctx2[11];
      if (dirty & /*helpText*/
      4096)
        field_1_changes.helpText = /*helpText*/
        ctx2[12];
      if (dirty & /*$$scope, fieldState, options, placeholder, flatOptions, autocomplete, sort, optionsType, direction*/
      268650276) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty & /*fieldState*/
      16384) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[14];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty & /*fieldApi*/
      32768) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[15];
        add_flush_callback(() => updating_fieldApi = false);
      }
      if (!updating_fieldSchema && dirty & /*fieldSchema*/
      8192) {
        updating_fieldSchema = true;
        field_1_changes.fieldSchema = /*fieldSchema*/
        ctx2[13];
        add_flush_callback(() => updating_fieldSchema = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field_1, detaching);
    }
  };
}
const func = (x) => x;
const func_1 = (x) => x.label;
const func_2 = (x) => x;
const func_3 = (x) => x.value;
const func_4 = (x) => x;
const func_5 = (x) => x.label;
const func_6 = (x) => x;
const func_7 = (x) => x.label;
const func_8 = (x) => x;
const func_9 = (x) => x.value;
function instance($$self, $$props, $$invalidate) {
  let flatOptions;
  let options;
  let { field } = $$props;
  let { label } = $$props;
  let { placeholder } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { optionsType = "select" } = $$props;
  let { validation } = $$props;
  let { defaultValue } = $$props;
  let { optionsSource = "schema" } = $$props;
  let { dataProvider } = $$props;
  let { labelColumn } = $$props;
  let { valueColumn } = $$props;
  let { customOptions } = $$props;
  let { autocomplete = false } = $$props;
  let { direction = "vertical" } = $$props;
  let { onChange } = $$props;
  let { sort = true } = $$props;
  let { span } = $$props;
  let { helpText = null } = $$props;
  let fieldState;
  let fieldApi;
  let fieldSchema;
  const handleChange = (e) => {
    const changed = fieldApi.setValue(e.detail);
    if (onChange && changed) {
      onChange({ value: e.detail });
    }
  };
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(14, fieldState);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(15, fieldApi);
  }
  function field_1_fieldSchema_binding(value) {
    fieldSchema = value;
    $$invalidate(13, fieldSchema);
  }
  $$self.$$set = ($$props2) => {
    if ("field" in $$props2)
      $$invalidate(0, field = $$props2.field);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("placeholder" in $$props2)
      $$invalidate(2, placeholder = $$props2.placeholder);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(4, readonly = $$props2.readonly);
    if ("optionsType" in $$props2)
      $$invalidate(5, optionsType = $$props2.optionsType);
    if ("validation" in $$props2)
      $$invalidate(6, validation = $$props2.validation);
    if ("defaultValue" in $$props2)
      $$invalidate(7, defaultValue = $$props2.defaultValue);
    if ("optionsSource" in $$props2)
      $$invalidate(19, optionsSource = $$props2.optionsSource);
    if ("dataProvider" in $$props2)
      $$invalidate(20, dataProvider = $$props2.dataProvider);
    if ("labelColumn" in $$props2)
      $$invalidate(21, labelColumn = $$props2.labelColumn);
    if ("valueColumn" in $$props2)
      $$invalidate(22, valueColumn = $$props2.valueColumn);
    if ("customOptions" in $$props2)
      $$invalidate(23, customOptions = $$props2.customOptions);
    if ("autocomplete" in $$props2)
      $$invalidate(8, autocomplete = $$props2.autocomplete);
    if ("direction" in $$props2)
      $$invalidate(9, direction = $$props2.direction);
    if ("onChange" in $$props2)
      $$invalidate(24, onChange = $$props2.onChange);
    if ("sort" in $$props2)
      $$invalidate(10, sort = $$props2.sort);
    if ("span" in $$props2)
      $$invalidate(11, span = $$props2.span);
    if ("helpText" in $$props2)
      $$invalidate(12, helpText = $$props2.helpText);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*optionsSource*/
    524288) {
      $$invalidate(17, flatOptions = optionsSource == null || optionsSource === "schema");
    }
    if ($$self.$$.dirty & /*optionsSource, fieldSchema, dataProvider, labelColumn, valueColumn, customOptions*/
    16261120) {
      $$invalidate(16, options = getOptions(optionsSource, fieldSchema, dataProvider, labelColumn, valueColumn, customOptions));
    }
  };
  return [
    field,
    label,
    placeholder,
    disabled,
    readonly,
    optionsType,
    validation,
    defaultValue,
    autocomplete,
    direction,
    sort,
    span,
    helpText,
    fieldSchema,
    fieldState,
    fieldApi,
    options,
    flatOptions,
    handleChange,
    optionsSource,
    dataProvider,
    labelColumn,
    valueColumn,
    customOptions,
    onChange,
    field_1_fieldState_binding,
    field_1_fieldApi_binding,
    field_1_fieldSchema_binding
  ];
}
class OptionsField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      field: 0,
      label: 1,
      placeholder: 2,
      disabled: 3,
      readonly: 4,
      optionsType: 5,
      validation: 6,
      defaultValue: 7,
      optionsSource: 19,
      dataProvider: 20,
      labelColumn: 21,
      valueColumn: 22,
      customOptions: 23,
      autocomplete: 8,
      direction: 9,
      onChange: 24,
      sort: 10,
      span: 11,
      helpText: 12
    });
  }
}
export {
  OptionsField as default
};
