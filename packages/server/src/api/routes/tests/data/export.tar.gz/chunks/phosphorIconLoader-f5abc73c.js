const loadedWeights = /* @__PURE__ */ new Set();
async function loadPhosphorIconWeight(weight = "regular") {
  if (loadedWeights.has(weight))
    return;
  try {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = `https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2.1.2/src/${weight}/style.css`;
    await new Promise((resolve, reject) => {
      link.onload = resolve;
      link.onerror = reject;
      document.head.appendChild(link);
    });
    loadedWeights.add(weight);
  } catch (error) {
    console.error(`Failed to load phosphor icon weight: ${weight}`, error);
  }
}
export {
  loadPhosphorIconWeight as l
};
