import { S as SvelteComponent, i as init, s as safe_not_equal, W as binding_callbacks, a0 as bind, c as create_component, m as mount_component, a1 as add_flush_callback, k as transition_in, n as transition_out, p as destroy_component, u as getContext, v as component_subscribe, y as empty, f as insert, z as group_outros, A as check_outros, o as detach, e as element, al as set_style } from "./index-8b9900f1.js";
import { T as TextArea } from "./TextArea-78f87eef.js";
import { F as Field } from "./Field-a0270b82.js";
import "./Placeholder-4dedd9c4.js";
import "./InnerForm-0042fa8f.js";
const JSONField_svelte_svelte_type_style_lang = "";
function create_if_block(ctx) {
  let div;
  let coretextarea;
  let current;
  coretextarea = new TextArea({
    props: {
      value: (
        /*serialiseValue*/
        ctx[12](
          /*fieldState*/
          ctx[7].value
        )
      ),
      disabled: (
        /*fieldState*/
        ctx[7].disabled
      ),
      readonly: (
        /*fieldState*/
        ctx[7].readonly
      ),
      error: (
        /*fieldState*/
        ctx[7].error
      ),
      id: (
        /*fieldState*/
        ctx[7].fieldId
      ),
      placeholder: (
        /*placeholder*/
        ctx[2]
      )
    }
  });
  coretextarea.$on(
    "change",
    /*handleChange*/
    ctx[13]
  );
  return {
    c() {
      div = element("div");
      create_component(coretextarea.$$.fragment);
      set_style(
        div,
        "--height",
        /*height*/
        ctx[9]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(coretextarea, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const coretextarea_changes = {};
      if (dirty & /*fieldState*/
      128)
        coretextarea_changes.value = /*serialiseValue*/
        ctx2[12](
          /*fieldState*/
          ctx2[7].value
        );
      if (dirty & /*fieldState*/
      128)
        coretextarea_changes.disabled = /*fieldState*/
        ctx2[7].disabled;
      if (dirty & /*fieldState*/
      128)
        coretextarea_changes.readonly = /*fieldState*/
        ctx2[7].readonly;
      if (dirty & /*fieldState*/
      128)
        coretextarea_changes.error = /*fieldState*/
        ctx2[7].error;
      if (dirty & /*fieldState*/
      128)
        coretextarea_changes.id = /*fieldState*/
        ctx2[7].fieldId;
      if (dirty & /*placeholder*/
      4)
        coretextarea_changes.placeholder = /*placeholder*/
        ctx2[2];
      coretextarea.$set(coretextarea_changes);
      if (!current || dirty & /*height*/
      512) {
        set_style(
          div,
          "--height",
          /*height*/
          ctx2[9]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(coretextarea.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(coretextarea.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(coretextarea);
    }
  };
}
function create_default_slot(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*fieldState*/
    ctx[7] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*fieldState*/
        ctx2[7]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*fieldState*/
          128) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let current;
  function field_1_fieldState_binding(value) {
    ctx[16](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[17](value);
  }
  let field_1_props = {
    label: (
      /*label*/
      ctx[1]
    ),
    field: (
      /*field*/
      ctx[0]
    ),
    disabled: (
      /*disabled*/
      ctx[3]
    ),
    readonly: (
      /*readonly*/
      ctx[4]
    ),
    validation: (
      /*validation*/
      ctx[11]
    ),
    defaultValue: (
      /*defaultValue*/
      ctx[5]
    ),
    helpText: (
      /*helpText*/
      ctx[6]
    ),
    type: "json",
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*fieldState*/
    ctx[7] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[7];
  }
  if (
    /*fieldApi*/
    ctx[8] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[8];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  return {
    c() {
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const field_1_changes = {};
      if (dirty & /*label*/
      2)
        field_1_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*field*/
      1)
        field_1_changes.field = /*field*/
        ctx2[0];
      if (dirty & /*disabled*/
      8)
        field_1_changes.disabled = /*disabled*/
        ctx2[3];
      if (dirty & /*readonly*/
      16)
        field_1_changes.readonly = /*readonly*/
        ctx2[4];
      if (dirty & /*defaultValue*/
      32)
        field_1_changes.defaultValue = /*defaultValue*/
        ctx2[5];
      if (dirty & /*helpText*/
      64)
        field_1_changes.helpText = /*helpText*/
        ctx2[6];
      if (dirty & /*$$scope, height, fieldState, placeholder*/
      524932) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty & /*fieldState*/
      128) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[7];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty & /*fieldApi*/
      256) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[8];
        add_flush_callback(() => updating_fieldApi = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field_1, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let height;
  let $component;
  let { field } = $$props;
  let { label } = $$props;
  let { placeholder } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { defaultValue = "" } = $$props;
  let { onChange } = $$props;
  let { helpText = null } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(15, $component = value));
  const validation = [
    {
      constraint: "json",
      type: "json",
      error: "JSON syntax is invalid"
    }
  ];
  let fieldState;
  let fieldApi;
  const serialiseValue = (value) => {
    return JSON.stringify(value || void 0, null, 4) || "";
  };
  const parseValue = (value) => {
    try {
      return JSON.parse(value);
    } catch (error) {
      return value;
    }
  };
  const handleChange = (e) => {
    const value = parseValue(e.detail);
    const changed = fieldApi.setValue(value);
    if (onChange && changed) {
      onChange({ value });
    }
  };
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(7, fieldState);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(8, fieldApi);
  }
  $$self.$$set = ($$props2) => {
    if ("field" in $$props2)
      $$invalidate(0, field = $$props2.field);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("placeholder" in $$props2)
      $$invalidate(2, placeholder = $$props2.placeholder);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(4, readonly = $$props2.readonly);
    if ("defaultValue" in $$props2)
      $$invalidate(5, defaultValue = $$props2.defaultValue);
    if ("onChange" in $$props2)
      $$invalidate(14, onChange = $$props2.onChange);
    if ("helpText" in $$props2)
      $$invalidate(6, helpText = $$props2.helpText);
  };
  $$self.$$.update = () => {
    var _a, _b;
    if ($$self.$$.dirty & /*$component*/
    32768) {
      $$invalidate(9, height = ((_b = (_a = $component.styles) == null ? void 0 : _a.normal) == null ? void 0 : _b.height) || "124px");
    }
  };
  return [
    field,
    label,
    placeholder,
    disabled,
    readonly,
    defaultValue,
    helpText,
    fieldState,
    fieldApi,
    height,
    component,
    validation,
    serialiseValue,
    handleChange,
    onChange,
    $component,
    field_1_fieldState_binding,
    field_1_fieldApi_binding
  ];
}
class JSONField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      field: 0,
      label: 1,
      placeholder: 2,
      disabled: 3,
      readonly: 4,
      defaultValue: 5,
      onChange: 14,
      helpText: 6
    });
  }
}
export {
  JSONField as default
};
