import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, k as transition_in, z as group_outros, n as transition_out, A as check_outros, o as detach, u as getContext, v as component_subscribe, ac as Modal, c as create_component, m as mount_component, p as destroy_component, I as Icon, F as create_slot, e as element, a as space, b as attr, am as null_to_empty, g as append, q as action_destroyer, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, h as is_function, W as binding_callbacks } from "./index-8b9900f1.js";
const Modal_svelte_svelte_type_style_lang = "";
function create_if_block(ctx) {
  let modal_1;
  let current;
  let modal_1_props = {
    disableCancel: (
      /*$builderStore*/
      ctx[5].inBuilder || /*ignoreClicksOutside*/
      ctx[0]
    ),
    zIndex: 2,
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  modal_1 = new Modal({ props: modal_1_props });
  ctx[16](modal_1);
  modal_1.$on(
    "cancel",
    /*handleModalClose*/
    ctx[11]
  );
  return {
    c() {
      create_component(modal_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(modal_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const modal_1_changes = {};
      if (dirty & /*$builderStore, ignoreClicksOutside*/
      33)
        modal_1_changes.disableCancel = /*$builderStore*/
        ctx2[5].inBuilder || /*ignoreClicksOutside*/
        ctx2[0];
      if (dirty & /*$$scope, size, $component*/
      131090) {
        modal_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modal_1.$set(modal_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(modal_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(modal_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      ctx[16](null);
      destroy_component(modal_1, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let div3;
  let div0;
  let icon;
  let t;
  let div2;
  let div1;
  let div3_class_value;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({
    props: {
      color: "var(--spectrum-global-color-gray-800)",
      name: "x",
      hoverable: true
    }
  });
  icon.$on(
    "click",
    /*handleModalClose*/
    ctx[11]
  );
  const default_slot_template = (
    /*#slots*/
    ctx[15].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[17],
    null
  );
  return {
    c() {
      div3 = element("div");
      div0 = element("div");
      create_component(icon.$$.fragment);
      t = space();
      div2 = element("div");
      div1 = element("div");
      if (default_slot)
        default_slot.c();
      attr(div0, "class", "modal-header svelte-3ffq1h");
      attr(div1, "class", "modal-main-inner svelte-3ffq1h");
      attr(div2, "class", "modal-main svelte-3ffq1h");
      attr(div3, "class", div3_class_value = null_to_empty(`modal-content ${/*size*/
      ctx[1]}`) + " svelte-3ffq1h");
    },
    m(target, anchor) {
      insert(target, div3, anchor);
      append(div3, div0);
      mount_component(icon, div0, null);
      append(div3, t);
      append(div3, div2);
      append(div2, div1);
      if (default_slot) {
        default_slot.m(div1, null);
      }
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[7].call(
          null,
          div3,
          /*$component*/
          ctx[4].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        131072)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[17],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[17]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[17],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*size*/
      2 && div3_class_value !== (div3_class_value = null_to_empty(`modal-content ${/*size*/
      ctx2[1]}`) + " svelte-3ffq1h")) {
        attr(div3, "class", div3_class_value);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      16)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[4].styles
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div3);
      }
      destroy_component(icon);
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function create_fragment(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (!/*$builderStore*/
  ctx[5].inBuilder || /*open*/
  ctx[3]) && create_if_block(ctx);
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (!/*$builderStore*/
      ctx2[5].inBuilder || /*open*/
      ctx2[3]) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*$builderStore, open*/
          40) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let open;
  let $component;
  let $modalStore;
  let $dndIsDragging;
  let $builderStore;
  let { $$slots: slots = {}, $$scope } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(4, $component = value));
  const { styleable, modalStore, builderStore, dndIsDragging } = getContext("sdk");
  component_subscribe($$self, modalStore, (value) => $$invalidate(13, $modalStore = value));
  component_subscribe($$self, builderStore, (value) => $$invalidate(5, $builderStore = value));
  component_subscribe($$self, dndIsDragging, (value) => $$invalidate(14, $dndIsDragging = value));
  let { onClose } = $$props;
  let { ignoreClicksOutside } = $$props;
  let { size } = $$props;
  let modal;
  const handleModalClose = async () => {
    if (onClose) {
      await onClose();
    }
    modalStore.actions.close();
  };
  const handleOpen = (open2, modal2) => {
    if (!modal2)
      return;
    if (open2) {
      modal2.show();
    } else {
      modal2.hide();
    }
  };
  function modal_1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      modal = $$value;
      $$invalidate(2, modal);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("onClose" in $$props2)
      $$invalidate(12, onClose = $$props2.onClose);
    if ("ignoreClicksOutside" in $$props2)
      $$invalidate(0, ignoreClicksOutside = $$props2.ignoreClicksOutside);
    if ("size" in $$props2)
      $$invalidate(1, size = $$props2.size);
    if ("$$scope" in $$props2)
      $$invalidate(17, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$builderStore, $component, $modalStore, $dndIsDragging*/
    24624) {
      {
        if ($builderStore.inBuilder) {
          if ($component.inSelectedPath && $modalStore.contentId !== $component.id) {
            modalStore.actions.open($component.id);
          } else if (!$component.inSelectedPath && $modalStore.contentId === $component.id && !$dndIsDragging) {
            modalStore.actions.close();
          }
        }
      }
    }
    if ($$self.$$.dirty & /*$modalStore, $component*/
    8208) {
      $$invalidate(3, open = $modalStore.contentId === $component.id);
    }
    if ($$self.$$.dirty & /*open, modal*/
    12) {
      handleOpen(open, modal);
    }
  };
  return [
    ignoreClicksOutside,
    size,
    modal,
    open,
    $component,
    $builderStore,
    component,
    styleable,
    modalStore,
    builderStore,
    dndIsDragging,
    handleModalClose,
    onClose,
    $modalStore,
    $dndIsDragging,
    slots,
    modal_1_binding,
    $$scope
  ];
}
class Modal_1 extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      onClose: 12,
      ignoreClicksOutside: 0,
      size: 1
    });
  }
}
export {
  Modal_1 as default
};
