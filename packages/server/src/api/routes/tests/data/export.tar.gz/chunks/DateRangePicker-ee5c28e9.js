import { S as SvelteComponent, i as init, s as safe_not_equal, an as Select_1, e as element, c as create_component, f as insert, m as mount_component, q as action_destroyer, h as is_function, k as transition_in, n as transition_out, o as detach, p as destroy_component, ao as dayjs, u as getContext, v as component_subscribe, w as onDestroy } from "./index-8b9900f1.js";
import { u as utc } from "./utc-71549d16.js";
function create_fragment(ctx) {
  let div;
  let select;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  select = new Select_1({
    props: {
      placeholder: null,
      options: (
        /*options*/
        ctx[4]
      ),
      value: (
        /*value*/
        ctx[0]
      )
    }
  });
  select.$on(
    "change",
    /*change_handler*/
    ctx[11]
  );
  return {
    c() {
      div = element("div");
      create_component(select.$$.fragment);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(select, div, null);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[3].call(
          null,
          div,
          /*$component*/
          ctx[1].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      const select_changes = {};
      if (dirty & /*value*/
      1)
        select_changes.value = /*value*/
        ctx2[0];
      select.$set(select_changes);
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      2)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[1].styles
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(select.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(select.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(select);
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let dataProviderId;
  let addExtension;
  let removeExtension;
  let queryExtension;
  let $component;
  dayjs.extend(utc);
  let { dataProvider } = $$props;
  let { field } = $$props;
  let { defaultValue } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value2) => $$invalidate(1, $component = value2));
  const { styleable, ActionTypes, getAction } = getContext("sdk");
  const options = [
    "Last 1 day",
    "Last 7 days",
    "Last 30 days",
    "Last 3 months",
    "Last 6 months",
    "Last 1 year"
  ];
  let value = options.includes(defaultValue) ? defaultValue : "Last 30 days";
  const getQueryExtension = (field2, value2) => {
    if (!field2 || !value2) {
      return null;
    }
    let low = dayjs.utc().subtract(1, "year");
    let high = dayjs.utc().add(1, "day");
    if (value2 === "Last 1 day") {
      low = dayjs.utc().subtract(1, "day");
    } else if (value2 === "Last 7 days") {
      low = dayjs.utc().subtract(7, "days");
    } else if (value2 === "Last 30 days") {
      low = dayjs.utc().subtract(30, "days");
    } else if (value2 === "Last 3 months") {
      low = dayjs.utc().subtract(3, "months");
    } else if (value2 === "Last 6 months") {
      low = dayjs.utc().subtract(6, "months");
    }
    return {
      range: {
        [field2]: { low: low.format(), high: high.format() }
      }
    };
  };
  onDestroy(() => {
    removeExtension == null ? void 0 : removeExtension($component.id);
  });
  const change_handler = (e) => $$invalidate(0, value = e.detail);
  $$self.$$set = ($$props2) => {
    if ("dataProvider" in $$props2)
      $$invalidate(5, dataProvider = $$props2.dataProvider);
    if ("field" in $$props2)
      $$invalidate(6, field = $$props2.field);
    if ("defaultValue" in $$props2)
      $$invalidate(7, defaultValue = $$props2.defaultValue);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*dataProvider*/
    32) {
      $$invalidate(10, dataProviderId = dataProvider == null ? void 0 : dataProvider.id);
    }
    if ($$self.$$.dirty & /*dataProviderId*/
    1024) {
      $$invalidate(9, addExtension = getAction(dataProviderId, ActionTypes.AddDataProviderQueryExtension));
    }
    if ($$self.$$.dirty & /*dataProviderId*/
    1024) {
      removeExtension = getAction(dataProviderId, ActionTypes.RemoveDataProviderQueryExtension);
    }
    if ($$self.$$.dirty & /*field, value*/
    65) {
      $$invalidate(8, queryExtension = getQueryExtension(field, value));
    }
    if ($$self.$$.dirty & /*addExtension, $component, queryExtension*/
    770) {
      addExtension == null ? void 0 : addExtension($component.id, queryExtension);
    }
  };
  return [
    value,
    $component,
    component,
    styleable,
    options,
    dataProvider,
    field,
    defaultValue,
    queryExtension,
    addExtension,
    dataProviderId,
    change_handler
  ];
}
class DateRangePicker extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      dataProvider: 5,
      field: 6,
      defaultValue: 7
    });
  }
}
export {
  DateRangePicker as default
};
