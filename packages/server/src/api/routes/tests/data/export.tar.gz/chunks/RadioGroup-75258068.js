import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, b as attr, am as null_to_empty, f as insert, B as noop, o as detach, Y as createEventDispatcher, N as ensure_array_like, y as empty, O as destroy_each, bZ as init_binding_group, a as space, t as text, bg as set_input_value, d as toggle_class, g as append, l as listen, j as set_data, r as run_all } from "./index-8b9900f1.js";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[15] = list[i];
  return child_ctx;
}
function create_if_block(ctx) {
  let each_1_anchor;
  let each_value = ensure_array_like(
    /*parsedOptions*/
    ctx[7]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*getOptionTitle, parsedOptions, readonly, getOptionLabel, getOptionValue, disabled, value, onChange*/
      509) {
        each_value = ensure_array_like(
          /*parsedOptions*/
          ctx2[7]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_each_block(ctx) {
  let div;
  let input;
  let input_value_value;
  let value_has_changed = false;
  let t0;
  let span;
  let t1;
  let label;
  let t2_value = (
    /*getOptionLabel*/
    ctx[4](
      /*option*/
      ctx[15]
    ) + ""
  );
  let t2;
  let t3;
  let div_title_value;
  let binding_group;
  let mounted;
  let dispose;
  binding_group = init_binding_group(
    /*$$binding_groups*/
    ctx[12][0]
  );
  return {
    c() {
      div = element("div");
      input = element("input");
      t0 = space();
      span = element("span");
      t1 = space();
      label = element("label");
      t2 = text(t2_value);
      t3 = space();
      input.__value = input_value_value = /*getOptionValue*/
      ctx[5](
        /*option*/
        ctx[15]
      );
      set_input_value(input, input.__value);
      attr(input, "type", "radio");
      attr(input, "class", "spectrum-Radio-input svelte-ylb1af");
      input.disabled = /*disabled*/
      ctx[2];
      attr(span, "class", "spectrum-Radio-button");
      attr(label, "for", "");
      attr(label, "class", "spectrum-Radio-label");
      attr(div, "title", div_title_value = /*getOptionTitle*/
      ctx[6](
        /*option*/
        ctx[15]
      ));
      attr(div, "class", "spectrum-Radio spectrum-FieldGroup-item spectrum-Radio--emphasized svelte-ylb1af");
      toggle_class(
        div,
        "readonly",
        /*readonly*/
        ctx[3]
      );
      binding_group.p(input);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, input);
      input.checked = input.__value === /*value*/
      ctx[0];
      append(div, t0);
      append(div, span);
      append(div, t1);
      append(div, label);
      append(label, t2);
      append(div, t3);
      if (!mounted) {
        dispose = [
          listen(
            input,
            "change",
            /*onChange*/
            ctx[8]
          ),
          listen(
            input,
            "change",
            /*input_change_handler*/
            ctx[11]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty & /*getOptionValue, parsedOptions*/
      160 && input_value_value !== (input_value_value = /*getOptionValue*/
      ctx2[5](
        /*option*/
        ctx2[15]
      ))) {
        input.__value = input_value_value;
        set_input_value(input, input.__value);
        value_has_changed = true;
      }
      if (dirty & /*disabled*/
      4) {
        input.disabled = /*disabled*/
        ctx2[2];
      }
      if (value_has_changed || dirty & /*value, parsedOptions*/
      129) {
        input.checked = input.__value === /*value*/
        ctx2[0];
      }
      if (dirty & /*getOptionLabel, parsedOptions*/
      144 && t2_value !== (t2_value = /*getOptionLabel*/
      ctx2[4](
        /*option*/
        ctx2[15]
      ) + ""))
        set_data(t2, t2_value);
      if (dirty & /*getOptionTitle, parsedOptions*/
      192 && div_title_value !== (div_title_value = /*getOptionTitle*/
      ctx2[6](
        /*option*/
        ctx2[15]
      ))) {
        attr(div, "title", div_title_value);
      }
      if (dirty & /*readonly*/
      8) {
        toggle_class(
          div,
          "readonly",
          /*readonly*/
          ctx2[3]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      binding_group.r();
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_fragment(ctx) {
  let div;
  let show_if = (
    /*parsedOptions*/
    ctx[7] && Array.isArray(
      /*parsedOptions*/
      ctx[7]
    )
  );
  let div_class_value;
  let if_block = show_if && create_if_block(ctx);
  return {
    c() {
      div = element("div");
      if (if_block)
        if_block.c();
      attr(div, "class", div_class_value = null_to_empty(`spectrum-FieldGroup spectrum-FieldGroup--${/*direction*/
      ctx[1]}`) + " svelte-ylb1af");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block)
        if_block.m(div, null);
    },
    p(ctx2, [dirty]) {
      if (dirty & /*parsedOptions*/
      128)
        show_if = /*parsedOptions*/
        ctx2[7] && Array.isArray(
          /*parsedOptions*/
          ctx2[7]
        );
      if (show_if) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          if_block.m(div, null);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (dirty & /*direction*/
      2 && div_class_value !== (div_class_value = null_to_empty(`spectrum-FieldGroup spectrum-FieldGroup--${/*direction*/
      ctx2[1]}`) + " svelte-ylb1af")) {
        attr(div, "class", div_class_value);
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block)
        if_block.d();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let parsedOptions;
  let { direction = "vertical" } = $$props;
  let { value = null } = $$props;
  let { options = [] } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { getOptionLabel = (option) => option } = $$props;
  let { getOptionValue = (option) => option } = $$props;
  let { getOptionTitle = (option) => option } = $$props;
  let { sort = false } = $$props;
  const dispatch = createEventDispatcher();
  const onChange = (e) => dispatch("change", e.target.value);
  const getSortedOptions = (options2, getLabel, sort2) => {
    if (!(options2 == null ? void 0 : options2.length) || !Array.isArray(options2)) {
      return [];
    }
    if (!sort2) {
      return options2;
    }
    return [...options2].sort((a, b) => {
      const labelA = getLabel(a);
      const labelB = getLabel(b);
      return labelA > labelB ? 1 : -1;
    });
  };
  const $$binding_groups = [[]];
  function input_change_handler() {
    value = this.__value;
    $$invalidate(0, value);
  }
  $$self.$$set = ($$props2) => {
    if ("direction" in $$props2)
      $$invalidate(1, direction = $$props2.direction);
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("options" in $$props2)
      $$invalidate(9, options = $$props2.options);
    if ("disabled" in $$props2)
      $$invalidate(2, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(3, readonly = $$props2.readonly);
    if ("getOptionLabel" in $$props2)
      $$invalidate(4, getOptionLabel = $$props2.getOptionLabel);
    if ("getOptionValue" in $$props2)
      $$invalidate(5, getOptionValue = $$props2.getOptionValue);
    if ("getOptionTitle" in $$props2)
      $$invalidate(6, getOptionTitle = $$props2.getOptionTitle);
    if ("sort" in $$props2)
      $$invalidate(10, sort = $$props2.sort);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*options, getOptionLabel, sort*/
    1552) {
      $$invalidate(7, parsedOptions = getSortedOptions(options, getOptionLabel, sort));
    }
  };
  return [
    value,
    direction,
    disabled,
    readonly,
    getOptionLabel,
    getOptionValue,
    getOptionTitle,
    parsedOptions,
    onChange,
    options,
    sort,
    input_change_handler,
    $$binding_groups
  ];
}
class RadioGroup extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      direction: 1,
      value: 0,
      options: 9,
      disabled: 2,
      readonly: 3,
      getOptionLabel: 4,
      getOptionValue: 5,
      getOptionTitle: 6,
      sort: 10
    });
  }
}
export {
  RadioGroup as R
};
