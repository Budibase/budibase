import { S as SvelteComponent, i as init, s as safe_not_equal, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component, u as getContext, v as component_subscribe, a3 as writable, aX as memo, w as onDestroy, bs as assign, bt as exclude_internal_props, y as empty, f as insert, o as detach, W as binding_callbacks, e as element, a as space, b as attr, d as toggle_class, g as append, q as action_destroyer, z as group_outros, A as check_outros, h as is_function, t as text, am as null_to_empty, l as listen, bU as set_data_maybe_contenteditable, r as run_all, a0 as bind, bR as get_spread_update, bS as get_spread_object, a1 as add_flush_callback, F as create_slot, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, B as noop, I as Icon, j as set_data } from "./index-8b9900f1.js";
import Placeholder from "./Placeholder-4dedd9c4.js";
import { I as InnerForm } from "./InnerForm-0042fa8f.js";
const Field_svelte_svelte_type_style_lang = "";
function create_else_block(ctx) {
  let div1;
  let previous_key = (
    /*$component*/
    ctx[10].editing
  );
  let t;
  let div0;
  let show_if;
  let current_block_type_index;
  let if_block;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  let key_block = create_key_block(ctx);
  const if_block_creators = [create_if_block_1, create_if_block_2, create_else_block_1];
  const if_blocks = [];
  function select_block_type_1(ctx2, dirty) {
    if (dirty[0] & /*schemaType, type*/
    8208)
      show_if = null;
    if (!/*fieldState*/
    ctx2[1])
      return 0;
    if (show_if == null)
      show_if = !!/*schemaType*/
      (ctx2[13] && /*schemaType*/
      ctx2[13] !== /*type*/
      ctx2[4] && !["options", "longform"].includes(
        /*type*/
        ctx2[4]
      ));
    if (show_if)
      return 1;
    return 2;
  }
  current_block_type_index = select_block_type_1(ctx, [-1, -1]);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      div1 = element("div");
      key_block.c();
      t = space();
      div0 = element("div");
      if_block.c();
      attr(div0, "class", "spectrum-Form-itemField svelte-87iude");
      attr(div1, "class", "spectrum-Form-item svelte-87iude");
      toggle_class(
        div1,
        "span-2",
        /*span*/
        ctx[7] === 2
      );
      toggle_class(
        div1,
        "span-3",
        /*span*/
        ctx[7] === 3
      );
      toggle_class(
        div1,
        "span-6",
        /*span*/
        ctx[7] === 6 || !/*span*/
        ctx[7]
      );
      toggle_class(
        div1,
        "above",
        /*labelPos*/
        ctx[18] === "above"
      );
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      key_block.m(div1, null);
      append(div1, t);
      append(div1, div0);
      if_blocks[current_block_type_index].m(div0, null);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[15].call(
          null,
          div1,
          /*$component*/
          ctx[10].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*$component*/
      1024 && safe_not_equal(previous_key, previous_key = /*$component*/
      ctx2[10].editing)) {
        key_block.d(1);
        key_block = create_key_block(ctx2);
        key_block.c();
        key_block.m(div1, t);
      } else {
        key_block.p(ctx2, dirty);
      }
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_1(ctx2, dirty);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div0, null);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty[0] & /*$component*/
      1024)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[10].styles
        );
      if (!current || dirty[0] & /*span*/
      128) {
        toggle_class(
          div1,
          "span-2",
          /*span*/
          ctx2[7] === 2
        );
      }
      if (!current || dirty[0] & /*span*/
      128) {
        toggle_class(
          div1,
          "span-3",
          /*span*/
          ctx2[7] === 3
        );
      }
      if (!current || dirty[0] & /*span*/
      128) {
        toggle_class(
          div1,
          "span-6",
          /*span*/
          ctx2[7] === 6 || !/*span*/
          ctx2[7]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      key_block.d(detaching);
      if_blocks[current_block_type_index].d();
      mounted = false;
      dispose();
    }
  };
}
function create_if_block(ctx) {
  let innerform;
  let current;
  innerform = new InnerForm({
    props: {
      disabled: (
        /*disabled*/
        ctx[5]
      ),
      readonly: (
        /*readonly*/
        ctx[6]
      ),
      currentStep: writable(1),
      provideContext: false,
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(innerform.$$.fragment);
    },
    m(target, anchor) {
      mount_component(innerform, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const innerform_changes = {};
      if (dirty[0] & /*disabled*/
      32)
        innerform_changes.disabled = /*disabled*/
        ctx2[5];
      if (dirty[0] & /*readonly*/
      64)
        innerform_changes.readonly = /*readonly*/
        ctx2[6];
      if (dirty[0] & /*$$props, fieldState, fieldApi, fieldSchema*/
      4194311 | dirty[1] & /*$$scope*/
      16) {
        innerform_changes.$$scope = { dirty, ctx: ctx2 };
      }
      innerform.$set(innerform_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(innerform.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(innerform.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(innerform, detaching);
    }
  };
}
function create_key_block(ctx) {
  let label_1;
  let t_value = (
    /*label*/
    (ctx[3] || " ") + ""
  );
  let t;
  let label_1_contenteditable_value;
  let label_1_for_value;
  let label_1_class_value;
  let mounted;
  let dispose;
  return {
    c() {
      var _a;
      label_1 = element("label");
      t = text(t_value);
      attr(label_1, "contenteditable", label_1_contenteditable_value = /*$component*/
      ctx[10].editing);
      attr(label_1, "for", label_1_for_value = /*fieldState*/
      (_a = ctx[1]) == null ? void 0 : _a.fieldId);
      attr(label_1, "class", label_1_class_value = null_to_empty(`spectrum-FieldLabel spectrum-FieldLabel--sizeM spectrum-Form-itemLabel ${/*labelClass*/
      ctx[12]}`) + " svelte-87iude");
      toggle_class(label_1, "hidden", !/*label*/
      ctx[3]);
      toggle_class(
        label_1,
        "readonly",
        /*readonly*/
        ctx[6]
      );
    },
    m(target, anchor) {
      insert(target, label_1, anchor);
      append(label_1, t);
      ctx[33](label_1);
      if (!mounted) {
        dispose = [
          listen(label_1, "blur", function() {
            if (is_function(
              /*$component*/
              ctx[10].editing ? (
                /*updateLabel*/
                ctx[21]
              ) : null
            ))
              /*$component*/
              (ctx[10].editing ? (
                /*updateLabel*/
                ctx[21]
              ) : null).apply(this, arguments);
          }),
          listen(
            label_1,
            "input",
            /*input_handler*/
            ctx[34]
          )
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      var _a;
      ctx = new_ctx;
      if (dirty[0] & /*label*/
      8 && t_value !== (t_value = /*label*/
      (ctx[3] || " ") + ""))
        set_data_maybe_contenteditable(
          t,
          t_value,
          /*$component*/
          ctx[10].editing
        );
      if (dirty[0] & /*$component*/
      1024 && label_1_contenteditable_value !== (label_1_contenteditable_value = /*$component*/
      ctx[10].editing)) {
        attr(label_1, "contenteditable", label_1_contenteditable_value);
      }
      if (dirty[0] & /*fieldState*/
      2 && label_1_for_value !== (label_1_for_value = /*fieldState*/
      (_a = ctx[1]) == null ? void 0 : _a.fieldId)) {
        attr(label_1, "for", label_1_for_value);
      }
      if (dirty[0] & /*labelClass*/
      4096 && label_1_class_value !== (label_1_class_value = null_to_empty(`spectrum-FieldLabel spectrum-FieldLabel--sizeM spectrum-Form-itemLabel ${/*labelClass*/
      ctx[12]}`) + " svelte-87iude")) {
        attr(label_1, "class", label_1_class_value);
      }
      if (dirty[0] & /*labelClass, label*/
      4104) {
        toggle_class(label_1, "hidden", !/*label*/
        ctx[3]);
      }
      if (dirty[0] & /*labelClass, readonly*/
      4160) {
        toggle_class(
          label_1,
          "readonly",
          /*readonly*/
          ctx[6]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(label_1);
      }
      ctx[33](null);
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_else_block_1(ctx) {
  let t;
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[29].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[35],
    null
  );
  const if_block_creators = [create_if_block_3, create_if_block_4];
  const if_blocks = [];
  function select_block_type_2(ctx2, dirty) {
    if (
      /*fieldState*/
      ctx2[1].error
    )
      return 0;
    if (
      /*helpText*/
      ctx2[8]
    )
      return 1;
    return -1;
  }
  if (~(current_block_type_index = select_block_type_2(ctx))) {
    if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  }
  return {
    c() {
      if (default_slot)
        default_slot.c();
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      insert(target, t, anchor);
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].m(target, anchor);
      }
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty[1] & /*$$scope*/
        16)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[35],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[35]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[35],
              dirty,
              null
            ),
            null
          );
        }
      }
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_2(ctx2);
      if (current_block_type_index === previous_block_index) {
        if (~current_block_type_index) {
          if_blocks[current_block_type_index].p(ctx2, dirty);
        }
      } else {
        if (if_block) {
          group_outros();
          transition_out(if_blocks[previous_block_index], 1, 1, () => {
            if_blocks[previous_block_index] = null;
          });
          check_outros();
        }
        if (~current_block_type_index) {
          if_block = if_blocks[current_block_type_index];
          if (!if_block) {
            if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
            if_block.c();
          } else {
            if_block.p(ctx2, dirty);
          }
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        } else {
          if_block = null;
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      if (default_slot)
        default_slot.d(detaching);
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].d(detaching);
      }
    }
  };
}
function create_if_block_2(ctx) {
  let placeholder;
  let current;
  placeholder = new Placeholder({
    props: {
      text: "This Field setting is the wrong data type for this component"
    }
  });
  return {
    c() {
      create_component(placeholder.$$.fragment);
    },
    m(target, anchor) {
      mount_component(placeholder, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(placeholder.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(placeholder.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(placeholder, detaching);
    }
  };
}
function create_if_block_1(ctx) {
  let placeholder;
  let current;
  placeholder = new Placeholder({});
  return {
    c() {
      create_component(placeholder.$$.fragment);
    },
    m(target, anchor) {
      mount_component(placeholder, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(placeholder.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(placeholder.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(placeholder, detaching);
    }
  };
}
function create_if_block_4(ctx) {
  let div;
  let icon;
  let t0;
  let span_1;
  let t1;
  let current;
  icon = new Icon({ props: { name: "question" } });
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      t0 = space();
      span_1 = element("span");
      t1 = text(
        /*helpText*/
        ctx[8]
      );
      attr(span_1, "class", "svelte-87iude");
      attr(div, "class", "helpText svelte-87iude");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      append(div, t0);
      append(div, span_1);
      append(span_1, t1);
      current = true;
    },
    p(ctx2, dirty) {
      if (!current || dirty[0] & /*helpText*/
      256)
        set_data(
          t1,
          /*helpText*/
          ctx2[8]
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
    }
  };
}
function create_if_block_3(ctx) {
  let div;
  let icon;
  let t0;
  let span_1;
  let t1_value = (
    /*fieldState*/
    ctx[1].error + ""
  );
  let t1;
  let current;
  icon = new Icon({ props: { name: "warning" } });
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      t0 = space();
      span_1 = element("span");
      t1 = text(t1_value);
      attr(span_1, "class", "svelte-87iude");
      attr(div, "class", "error svelte-87iude");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      append(div, t0);
      append(div, span_1);
      append(span_1, t1);
      current = true;
    },
    p(ctx2, dirty) {
      if ((!current || dirty[0] & /*fieldState*/
      2) && t1_value !== (t1_value = /*fieldState*/
      ctx2[1].error + ""))
        set_data(t1, t1_value);
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
    }
  };
}
function create_default_slot_2(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[29].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[35],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty[1] & /*$$scope*/
        16)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[35],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[35]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[35],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let updating_fieldSchema;
  let current;
  const field_1_spread_levels = [
    /*$$props*/
    ctx[22]
  ];
  function field_1_fieldState_binding(value) {
    ctx[30](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[31](value);
  }
  function field_1_fieldSchema_binding(value) {
    ctx[32](value);
  }
  let field_1_props = {
    $$slots: { default: [create_default_slot_2] },
    $$scope: { ctx }
  };
  for (let i = 0; i < field_1_spread_levels.length; i += 1) {
    field_1_props = assign(field_1_props, field_1_spread_levels[i]);
  }
  if (
    /*fieldState*/
    ctx[1] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[1];
  }
  if (
    /*fieldApi*/
    ctx[2] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[2];
  }
  if (
    /*fieldSchema*/
    ctx[0] !== void 0
  ) {
    field_1_props.fieldSchema = /*fieldSchema*/
    ctx[0];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  binding_callbacks.push(() => bind(field_1, "fieldSchema", field_1_fieldSchema_binding));
  return {
    c() {
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const field_1_changes = dirty[0] & /*$$props*/
      4194304 ? get_spread_update(field_1_spread_levels, [get_spread_object(
        /*$$props*/
        ctx2[22]
      )]) : {};
      if (dirty[1] & /*$$scope*/
      16) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty[0] & /*fieldState*/
      2) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[1];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty[0] & /*fieldApi*/
      4) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[2];
        add_flush_callback(() => updating_fieldApi = false);
      }
      if (!updating_fieldSchema && dirty[0] & /*fieldSchema*/
      1) {
        updating_fieldSchema = true;
        field_1_changes.fieldSchema = /*fieldSchema*/
        ctx2[0];
        add_flush_callback(() => updating_fieldSchema = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field_1, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (!/*formContext*/
    ctx2[14])
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if_block.p(ctx2, dirty);
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_fragment(ctx) {
  var _a;
  let provider;
  let current;
  provider = new /*Provider*/
  ctx[16]({
    props: {
      data: { value: (
        /*fieldState*/
        (_a = ctx[1]) == null ? void 0 : _a.value
      ) },
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(provider.$$.fragment);
    },
    m(target, anchor) {
      mount_component(provider, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      const provider_changes = {};
      if (dirty[0] & /*fieldState*/
      2)
        provider_changes.data = { value: (
          /*fieldState*/
          (_a2 = ctx2[1]) == null ? void 0 : _a2.value
        ) };
      if (dirty[0] & /*disabled, readonly, $$props, fieldState, fieldApi, fieldSchema, $component, span, schemaType, type, helpText, labelClass, labelNode, label, touched*/
      4210687 | dirty[1] & /*$$scope*/
      16) {
        provider_changes.$$scope = { dirty, ctx: ctx2 };
      }
      provider.$set(provider_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(provider.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(provider.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(provider, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let schemaType;
  let unsubscribe;
  let labelClass;
  let $component;
  let $fieldInfo;
  let $formStep;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { label = void 0 } = $$props;
  let { field = void 0 } = $$props;
  let { fieldState } = $$props;
  let { fieldApi } = $$props;
  let { fieldSchema } = $$props;
  let { defaultValue = void 0 } = $$props;
  let { type } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { validation } = $$props;
  let { span = 6 } = $$props;
  let { helpText = void 0 } = $$props;
  const formContext = getContext("form");
  const formStepContext = getContext("form-step");
  const fieldGroupContext = getContext("field-group");
  const { styleable, builderStore, Provider } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(10, $component = value));
  const formApi = formContext == null ? void 0 : formContext.formApi;
  const labelPos = (fieldGroupContext == null ? void 0 : fieldGroupContext.labelPosition) || "above";
  let formField;
  let touched = false;
  let labelNode;
  const formStep = formStepContext || writable(1);
  component_subscribe($$self, formStep, (value) => $$invalidate(28, $formStep = value));
  const fieldInfo = memo({
    field: field || $component.name,
    type,
    defaultValue,
    disabled,
    readonly,
    validation,
    formStep: $formStep || 1
  });
  component_subscribe($$self, fieldInfo, (value) => $$invalidate(27, $fieldInfo = value));
  const registerField = (info) => {
    $$invalidate(26, formField = formApi == null ? void 0 : formApi.registerField(info.field, info.type, info.defaultValue, info.disabled, info.readonly, info.validation, info.formStep));
  };
  const updateLabel = (e) => {
    if (touched) {
      const label2 = e.target;
      builderStore.actions.updateProp("label", label2.textContent);
    }
    $$invalidate(11, touched = false);
  };
  onDestroy(() => {
    fieldApi == null ? void 0 : fieldApi.deregister();
    unsubscribe == null ? void 0 : unsubscribe();
  });
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(1, fieldState), $$invalidate(26, formField);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(2, fieldApi), $$invalidate(26, formField);
  }
  function field_1_fieldSchema_binding(value) {
    fieldSchema = value;
    $$invalidate(0, fieldSchema), $$invalidate(26, formField);
  }
  function label_1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      labelNode = $$value;
      $$invalidate(9, labelNode);
    });
  }
  const input_handler = () => $$invalidate(11, touched = true);
  $$self.$$set = ($$new_props) => {
    $$invalidate(22, $$props = assign(assign({}, $$props), exclude_internal_props($$new_props)));
    if ("label" in $$new_props)
      $$invalidate(3, label = $$new_props.label);
    if ("field" in $$new_props)
      $$invalidate(23, field = $$new_props.field);
    if ("fieldState" in $$new_props)
      $$invalidate(1, fieldState = $$new_props.fieldState);
    if ("fieldApi" in $$new_props)
      $$invalidate(2, fieldApi = $$new_props.fieldApi);
    if ("fieldSchema" in $$new_props)
      $$invalidate(0, fieldSchema = $$new_props.fieldSchema);
    if ("defaultValue" in $$new_props)
      $$invalidate(24, defaultValue = $$new_props.defaultValue);
    if ("type" in $$new_props)
      $$invalidate(4, type = $$new_props.type);
    if ("disabled" in $$new_props)
      $$invalidate(5, disabled = $$new_props.disabled);
    if ("readonly" in $$new_props)
      $$invalidate(6, readonly = $$new_props.readonly);
    if ("validation" in $$new_props)
      $$invalidate(25, validation = $$new_props.validation);
    if ("span" in $$new_props)
      $$invalidate(7, span = $$new_props.span);
    if ("helpText" in $$new_props)
      $$invalidate(8, helpText = $$new_props.helpText);
    if ("$$scope" in $$new_props)
      $$invalidate(35, $$scope = $$new_props.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*field, $component, type, defaultValue, disabled, readonly, validation, $formStep*/
    327156848) {
      fieldInfo.set({
        field: field || $component.name,
        type,
        defaultValue,
        disabled,
        readonly,
        validation,
        formStep: $formStep || 1
      });
    }
    if ($$self.$$.dirty[0] & /*$fieldInfo*/
    134217728) {
      registerField($fieldInfo);
    }
    if ($$self.$$.dirty[0] & /*formField*/
    67108864) {
      unsubscribe = formField == null ? void 0 : formField.subscribe((value) => {
        $$invalidate(1, fieldState = value == null ? void 0 : value.fieldState);
        $$invalidate(2, fieldApi = value == null ? void 0 : value.fieldApi);
        $$invalidate(0, fieldSchema = value == null ? void 0 : value.fieldSchema);
      });
    }
    if ($$self.$$.dirty[0] & /*fieldSchema*/
    1) {
      $$invalidate(13, schemaType = (fieldSchema == null ? void 0 : fieldSchema.type) !== "formula" && (fieldSchema == null ? void 0 : fieldSchema.type) !== "bigint" ? fieldSchema == null ? void 0 : fieldSchema.type : "string");
    }
    if ($$self.$$.dirty[0] & /*$component, labelNode*/
    1536) {
      $component.editing && (labelNode == null ? void 0 : labelNode.focus());
    }
  };
  $$invalidate(12, labelClass = labelPos === "above" ? "" : `spectrum-FieldLabel--${labelPos}`);
  $$props = exclude_internal_props($$props);
  return [
    fieldSchema,
    fieldState,
    fieldApi,
    label,
    type,
    disabled,
    readonly,
    span,
    helpText,
    labelNode,
    $component,
    touched,
    labelClass,
    schemaType,
    formContext,
    styleable,
    Provider,
    component,
    labelPos,
    formStep,
    fieldInfo,
    updateLabel,
    $$props,
    field,
    defaultValue,
    validation,
    formField,
    $fieldInfo,
    $formStep,
    slots,
    field_1_fieldState_binding,
    field_1_fieldApi_binding,
    field_1_fieldSchema_binding,
    label_1_binding,
    input_handler,
    $$scope
  ];
}
class Field extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        label: 3,
        field: 23,
        fieldState: 1,
        fieldApi: 2,
        fieldSchema: 0,
        defaultValue: 24,
        type: 4,
        disabled: 5,
        readonly: 6,
        validation: 25,
        span: 7,
        helpText: 8
      },
      null,
      [-1, -1]
    );
  }
}
export {
  Field as F
};
