import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, B as noop, o as detach, u as getContext, v as component_subscribe, e as element, t as text, b as attr, d as toggle_class, g as append, q as action_destroyer, l as listen, h as is_function, bU as set_data_maybe_contenteditable, r as run_all, W as binding_callbacks } from "./index-8b9900f1.js";
const Text_svelte_svelte_type_style_lang = "";
function create_key_block(ctx) {
  let p;
  let t;
  let p_contenteditable_value;
  let p_class_value;
  let styleable_action;
  let mounted;
  let dispose;
  return {
    c() {
      p = element("p");
      t = text(
        /*componentText*/
        ctx[9]
      );
      attr(p, "contenteditable", p_contenteditable_value = /*$component*/
      ctx[4].editing);
      attr(p, "class", p_class_value = "spectrum-Body " + /*sizeClass*/
      ctx[8] + " " + /*alignClass*/
      ctx[7] + " svelte-1bo4sd3");
      toggle_class(
        p,
        "placeholder",
        /*placeholder*/
        ctx[10]
      );
      toggle_class(
        p,
        "bold",
        /*bold*/
        ctx[0]
      );
      toggle_class(
        p,
        "italic",
        /*italic*/
        ctx[1]
      );
      toggle_class(
        p,
        "underline",
        /*underline*/
        ctx[2]
      );
    },
    m(target, anchor) {
      insert(target, p, anchor);
      append(p, t);
      ctx[20](p);
      if (!mounted) {
        dispose = [
          action_destroyer(styleable_action = /*styleable*/
          ctx[11].call(
            null,
            p,
            /*styles*/
            ctx[6]
          )),
          listen(p, "blur", function() {
            if (is_function(
              /*$component*/
              ctx[4].editing ? (
                /*updateText*/
                ctx[14]
              ) : null
            ))
              /*$component*/
              (ctx[4].editing ? (
                /*updateText*/
                ctx[14]
              ) : null).apply(this, arguments);
          }),
          listen(
            p,
            "input",
            /*input_handler*/
            ctx[21]
          )
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*componentText*/
      512)
        set_data_maybe_contenteditable(
          t,
          /*componentText*/
          ctx[9],
          /*$component*/
          ctx[4].editing
        );
      if (dirty & /*$component*/
      16 && p_contenteditable_value !== (p_contenteditable_value = /*$component*/
      ctx[4].editing)) {
        attr(p, "contenteditable", p_contenteditable_value);
      }
      if (dirty & /*sizeClass, alignClass*/
      384 && p_class_value !== (p_class_value = "spectrum-Body " + /*sizeClass*/
      ctx[8] + " " + /*alignClass*/
      ctx[7] + " svelte-1bo4sd3")) {
        attr(p, "class", p_class_value);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*styles*/
      64)
        styleable_action.update.call(
          null,
          /*styles*/
          ctx[6]
        );
      if (dirty & /*sizeClass, alignClass, placeholder*/
      1408) {
        toggle_class(
          p,
          "placeholder",
          /*placeholder*/
          ctx[10]
        );
      }
      if (dirty & /*sizeClass, alignClass, bold*/
      385) {
        toggle_class(
          p,
          "bold",
          /*bold*/
          ctx[0]
        );
      }
      if (dirty & /*sizeClass, alignClass, italic*/
      386) {
        toggle_class(
          p,
          "italic",
          /*italic*/
          ctx[1]
        );
      }
      if (dirty & /*sizeClass, alignClass, underline*/
      388) {
        toggle_class(
          p,
          "underline",
          /*underline*/
          ctx[2]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(p);
      }
      ctx[20](null);
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_fragment(ctx) {
  let previous_key = (
    /*$component*/
    ctx[4].editing
  );
  let key_block_anchor;
  let key_block = create_key_block(ctx);
  return {
    c() {
      key_block.c();
      key_block_anchor = empty();
    },
    m(target, anchor) {
      key_block.m(target, anchor);
      insert(target, key_block_anchor, anchor);
    },
    p(ctx2, [dirty]) {
      if (dirty & /*$component*/
      16 && safe_not_equal(previous_key, previous_key = /*$component*/
      ctx2[4].editing)) {
        key_block.d(1);
        key_block = create_key_block(ctx2);
        key_block.c();
        key_block.m(key_block_anchor.parentNode, key_block_anchor);
      } else {
        key_block.p(ctx2, dirty);
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(key_block_anchor);
      }
      key_block.d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let placeholder;
  let componentText;
  let sizeClass;
  let alignClass;
  let styles;
  let $component;
  let $builderStore;
  const { styleable, builderStore } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(19, $builderStore = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(4, $component = value));
  let { text: text2 } = $$props;
  let { color } = $$props;
  let { align } = $$props;
  let { bold } = $$props;
  let { italic } = $$props;
  let { underline } = $$props;
  let { size } = $$props;
  let node;
  let touched = false;
  const getComponentText = (text3, builderState, componentState) => {
    if (!builderState.inBuilder || componentState.editing) {
      return text3 || "";
    }
    return text3 || componentState.name || "Placeholder text";
  };
  const enrichStyles = (styles2, color2) => {
    if (!color2) {
      return styles2;
    }
    return {
      ...styles2,
      normal: { ...styles2 == null ? void 0 : styles2.normal, color: color2 }
    };
  };
  const updateText = (e) => {
    if (touched) {
      builderStore.actions.updateProp("text", e.target.textContent);
    }
    $$invalidate(5, touched = false);
  };
  function p_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      node = $$value;
      $$invalidate(3, node);
    });
  }
  const input_handler = () => $$invalidate(5, touched = true);
  $$self.$$set = ($$props2) => {
    if ("text" in $$props2)
      $$invalidate(15, text2 = $$props2.text);
    if ("color" in $$props2)
      $$invalidate(16, color = $$props2.color);
    if ("align" in $$props2)
      $$invalidate(17, align = $$props2.align);
    if ("bold" in $$props2)
      $$invalidate(0, bold = $$props2.bold);
    if ("italic" in $$props2)
      $$invalidate(1, italic = $$props2.italic);
    if ("underline" in $$props2)
      $$invalidate(2, underline = $$props2.underline);
    if ("size" in $$props2)
      $$invalidate(18, size = $$props2.size);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$component, node*/
    24) {
      $component.editing && (node == null ? void 0 : node.focus());
    }
    if ($$self.$$.dirty & /*$builderStore, text, $component*/
    557072) {
      $$invalidate(10, placeholder = $builderStore.inBuilder && !text2 && !$component.editing);
    }
    if ($$self.$$.dirty & /*text, $builderStore, $component*/
    557072) {
      $$invalidate(9, componentText = getComponentText(text2, $builderStore, $component));
    }
    if ($$self.$$.dirty & /*size*/
    262144) {
      $$invalidate(8, sizeClass = `spectrum-Body--size${size || "M"}`);
    }
    if ($$self.$$.dirty & /*align*/
    131072) {
      $$invalidate(7, alignClass = `align--${align || "left"}`);
    }
    if ($$self.$$.dirty & /*$component, color*/
    65552) {
      $$invalidate(6, styles = enrichStyles($component.styles, color));
    }
  };
  return [
    bold,
    italic,
    underline,
    node,
    $component,
    touched,
    styles,
    alignClass,
    sizeClass,
    componentText,
    placeholder,
    styleable,
    builderStore,
    component,
    updateText,
    text2,
    color,
    align,
    size,
    $builderStore,
    p_binding,
    input_handler
  ];
}
class Text extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      text: 15,
      color: 16,
      align: 17,
      bold: 0,
      italic: 1,
      underline: 2,
      size: 18
    });
  }
}
export {
  Text as default
};
