import { S as SvelteComponent, i as init, s as safe_not_equal, aK as FieldType, bs as assign, c as create_component, m as mount_component, bR as get_spread_update, bS as get_spread_object, k as transition_in, n as transition_out, p as destroy_component, c9 as compute_rest_props, bt as exclude_internal_props } from "./index-8b9900f1.js";
import BBReferenceField from "./BBReferenceField-cfc17956.js";
import "./RelationshipField-3efc82fb.js";
import "./Multiselect-cb208362.js";
import "./Field-a0270b82.js";
import "./Placeholder-4dedd9c4.js";
import "./InnerForm-0042fa8f.js";
import "./users-bee20df5.js";
function create_fragment(ctx) {
  let bbreferencefield;
  let current;
  const bbreferencefield_spread_levels = [
    /*$$restProps*/
    ctx[0],
    { type: FieldType.BB_REFERENCE_SINGLE }
  ];
  let bbreferencefield_props = {};
  for (let i = 0; i < bbreferencefield_spread_levels.length; i += 1) {
    bbreferencefield_props = assign(bbreferencefield_props, bbreferencefield_spread_levels[i]);
  }
  bbreferencefield = new BBReferenceField({ props: bbreferencefield_props });
  return {
    c() {
      create_component(bbreferencefield.$$.fragment);
    },
    m(target, anchor) {
      mount_component(bbreferencefield, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const bbreferencefield_changes = dirty & /*$$restProps*/
      1 ? get_spread_update(bbreferencefield_spread_levels, [
        get_spread_object(
          /*$$restProps*/
          ctx2[0]
        ),
        bbreferencefield_spread_levels[1]
      ]) : {};
      bbreferencefield.$set(bbreferencefield_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(bbreferencefield.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(bbreferencefield.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(bbreferencefield, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  const omit_props_names = [];
  let $$restProps = compute_rest_props($$props, omit_props_names);
  $$self.$$set = ($$new_props) => {
    $$props = assign(assign({}, $$props), exclude_internal_props($$new_props));
    $$invalidate(0, $$restProps = compute_rest_props($$props, omit_props_names));
  };
  return [$$restProps];
}
class BBReferenceSingleField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {});
  }
}
export {
  BBReferenceSingleField as default
};
