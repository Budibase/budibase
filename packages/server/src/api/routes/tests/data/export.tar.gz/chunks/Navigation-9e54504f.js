import { S as SvelteComponent, i as init, s as safe_not_equal, F as create_slot, e as element, a as space, b as attr, f as insert, g as append, q as action_destroyer, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, h as is_function, k as transition_in, n as transition_out, o as detach, u as getContext, v as component_subscribe, ae as src_url_equal } from "./index-8b9900f1.js";
const Navigation_svelte_svelte_type_style_lang = "";
function create_if_block(ctx) {
  let div;
  let a;
  let img;
  let img_src_value;
  let mounted;
  let dispose;
  return {
    c() {
      div = element("div");
      a = element("a");
      img = element("img");
      attr(img, "class", "logo svelte-1ggxdm7");
      attr(img, "alt", "logo");
      if (!src_url_equal(img.src, img_src_value = /*logoUrl*/
      ctx[0] || "/builder/bblogo.png"))
        attr(img, "src", img_src_value);
      attr(img, "height", "48");
      attr(a, "href", "/");
      attr(div, "class", "nav__top svelte-1ggxdm7");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, a);
      append(a, img);
      if (!mounted) {
        dispose = action_destroyer(
          /*linkable*/
          ctx[3].call(null, a)
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty & /*logoUrl*/
      1 && !src_url_equal(img.src, img_src_value = /*logoUrl*/
      ctx2[0] || "/builder/bblogo.png")) {
        attr(img, "src", img_src_value);
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_fragment(ctx) {
  let div1;
  let t;
  let div0;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  let if_block = !/*hideLogo*/
  ctx[1] && create_if_block(ctx);
  const default_slot_template = (
    /*#slots*/
    ctx[7].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[6],
    null
  );
  return {
    c() {
      div1 = element("div");
      if (if_block)
        if_block.c();
      t = space();
      div0 = element("div");
      if (default_slot)
        default_slot.c();
      attr(div0, "class", "nav__menu svelte-1ggxdm7");
      attr(div1, "class", "nav svelte-1ggxdm7");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      if (if_block)
        if_block.m(div1, null);
      append(div1, t);
      append(div1, div0);
      if (default_slot) {
        default_slot.m(div0, null);
      }
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[4].call(
          null,
          div1,
          /*$component*/
          ctx[2].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (!/*hideLogo*/
      ctx2[1]) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          if_block.m(div1, t);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        64)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[6],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[6]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[6],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      4)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[2].styles
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if (if_block)
        if_block.d();
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $component;
  let { $$slots: slots = {}, $$scope } = $$props;
  const { linkable, styleable } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(2, $component = value));
  let { logoUrl } = $$props;
  let { hideLogo } = $$props;
  $$self.$$set = ($$props2) => {
    if ("logoUrl" in $$props2)
      $$invalidate(0, logoUrl = $$props2.logoUrl);
    if ("hideLogo" in $$props2)
      $$invalidate(1, hideLogo = $$props2.hideLogo);
    if ("$$scope" in $$props2)
      $$invalidate(6, $$scope = $$props2.$$scope);
  };
  return [logoUrl, hideLogo, $component, linkable, styleable, component, $$scope, slots];
}
class Navigation extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { logoUrl: 0, hideLogo: 1 });
  }
}
export {
  Navigation as default
};
