import { S as SvelteComponent, i as init, s as safe_not_equal, I as Icon, e as element, c as create_component, a as space, b as attr, f as insert, m as mount_component, g as append, k as transition_in, n as transition_out, o as detach, p as destroy_component, Y as createEventDispatcher, v as component_subscribe, a3 as writable, ao as dayjs, bA as parseDate, bB as Field, a$ as ArrayOperator, F as create_slot, $ as Popover, W as binding_callbacks, a0 as bind, l as listen, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, a1 as add_flush_callback, bC as PopoverAlignment, u as getContext, aK as FieldType, z as group_outros, A as check_outros, bD as cloneDeep, bE as OperatorOptions, bF as FilterValueType, a_ as BasicOperator, bG as stringifyDate, V as bubble, an as Select_1, ap as Button, t as text, j as set_data, a7 as Input, B as noop, y as empty, b9 as construct_svelte_component, bH as RangeOperator, d as toggle_class, aJ as capitalise, bI as getDateDisplayValue, bJ as uiStateStore, aX as memo, X as setContext, aZ as UILogicalOperator, E as EmptyFilterOption, U as onMount, w as onDestroy, x as buildQuery, bK as componentStore, bL as ActionTypes, bM as getAction, N as ensure_array_like, O as destroy_each, C as subscribe, bN as InternalTable, D as fetchData, bO as getValidOperatorsForType } from "./index-8b9900f1.js";
import Container from "./Container-4931ed81.js";
import { D as DatePicker_1 } from "./DatePicker-068351bc.js";
import { D as DatePicker } from "./DatePicker-35c5ed8a.js";
import { C as CheckboxGroup } from "./CheckboxGroup-9d863d31.js";
import { R as RadioGroup } from "./RadioGroup-75258068.js";
import BBReferenceField from "./BBReferenceField-cfc17956.js";
import { u as utc } from "./utc-71549d16.js";
import "./RelationshipField-3efc82fb.js";
import "./Multiselect-cb208362.js";
import "./Field-a0270b82.js";
import "./Placeholder-4dedd9c4.js";
import "./InnerForm-0042fa8f.js";
import "./users-bee20df5.js";
var FilterType = /* @__PURE__ */ ((FilterType2) => {
  FilterType2["STRING"] = "string";
  FilterType2["FUZZY"] = "fuzzy";
  FilterType2["RANGE"] = "range";
  FilterType2["EQUAL"] = "equal";
  FilterType2["NOT_EQUAL"] = "notEqual";
  FilterType2["EMPTY"] = "empty";
  FilterType2["NOT_EMPTY"] = "notEmpty";
  FilterType2["ONE_OF"] = "oneOf";
  return FilterType2;
})(FilterType || {});
function create_fragment$4(ctx) {
  let div1;
  let coredatepicker0;
  let t0;
  let div0;
  let icon;
  let t1;
  let coredatepicker1;
  let current;
  coredatepicker0 = new DatePicker({
    props: {
      value: (
        /*parsedFrom*/
        ctx[4]
      ),
      enableTime: (
        /*enableTime*/
        ctx[0]
      ),
      timeOnly: (
        /*timeOnly*/
        ctx[1]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        ctx[2]
      )
    }
  });
  coredatepicker0.$on(
    "change",
    /*change_handler*/
    ctx[12]
  );
  icon = new Icon({ props: { name: "caret-right" } });
  coredatepicker1 = new DatePicker({
    props: {
      value: (
        /*parsedTo*/
        ctx[3]
      ),
      enableTime: (
        /*enableTime*/
        ctx[0]
      ),
      timeOnly: (
        /*timeOnly*/
        ctx[1]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        ctx[2]
      )
    }
  });
  coredatepicker1.$on(
    "change",
    /*change_handler_1*/
    ctx[13]
  );
  return {
    c() {
      div1 = element("div");
      create_component(coredatepicker0.$$.fragment);
      t0 = space();
      div0 = element("div");
      create_component(icon.$$.fragment);
      t1 = space();
      create_component(coredatepicker1.$$.fragment);
      attr(div0, "class", "arrow svelte-1i3abvq");
      attr(div1, "class", "date-range svelte-1i3abvq");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      mount_component(coredatepicker0, div1, null);
      append(div1, t0);
      append(div1, div0);
      mount_component(icon, div0, null);
      append(div1, t1);
      mount_component(coredatepicker1, div1, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      const coredatepicker0_changes = {};
      if (dirty & /*parsedFrom*/
      16)
        coredatepicker0_changes.value = /*parsedFrom*/
        ctx2[4];
      if (dirty & /*enableTime*/
      1)
        coredatepicker0_changes.enableTime = /*enableTime*/
        ctx2[0];
      if (dirty & /*timeOnly*/
      2)
        coredatepicker0_changes.timeOnly = /*timeOnly*/
        ctx2[1];
      if (dirty & /*ignoreTimezones*/
      4)
        coredatepicker0_changes.ignoreTimezones = /*ignoreTimezones*/
        ctx2[2];
      coredatepicker0.$set(coredatepicker0_changes);
      const coredatepicker1_changes = {};
      if (dirty & /*parsedTo*/
      8)
        coredatepicker1_changes.value = /*parsedTo*/
        ctx2[3];
      if (dirty & /*enableTime*/
      1)
        coredatepicker1_changes.enableTime = /*enableTime*/
        ctx2[0];
      if (dirty & /*timeOnly*/
      2)
        coredatepicker1_changes.timeOnly = /*timeOnly*/
        ctx2[1];
      if (dirty & /*ignoreTimezones*/
      4)
        coredatepicker1_changes.ignoreTimezones = /*ignoreTimezones*/
        ctx2[2];
      coredatepicker1.$set(coredatepicker1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(coredatepicker0.$$.fragment, local);
      transition_in(icon.$$.fragment, local);
      transition_in(coredatepicker1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(coredatepicker0.$$.fragment, local);
      transition_out(icon.$$.fragment, local);
      transition_out(coredatepicker1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      destroy_component(coredatepicker0);
      destroy_component(icon);
      destroy_component(coredatepicker1);
    }
  };
}
function instance$4($$self, $$props, $$invalidate) {
  let parsedFrom;
  let parsedTo;
  let $valueStore;
  let { enableTime = false } = $$props;
  let { timeOnly = false } = $$props;
  let { ignoreTimezones = false } = $$props;
  let { value = [] } = $$props;
  const dispatch = createEventDispatcher();
  const valueStore = writable();
  component_subscribe($$self, valueStore, (value2) => $$invalidate(11, $valueStore = value2));
  let fromDate;
  let toDate;
  const parseValue = (value2) => {
    if (!Array.isArray(value2) || !value2[0] || !value2[1]) {
      $$invalidate(9, fromDate = null);
      $$invalidate(10, toDate = null);
    } else {
      $$invalidate(9, fromDate = dayjs(value2[0]));
      $$invalidate(10, toDate = dayjs(value2[1]));
    }
  };
  const onChangeFrom = (utc2) => {
    const fromDate2 = utc2 ? enableTime ? dayjs(utc2) : dayjs(utc2).startOf("day") : null;
    if (fromDate2 && (!toDate || fromDate2.isAfter(toDate))) {
      $$invalidate(10, toDate = !enableTime ? fromDate2.endOf("day") : fromDate2);
    } else if (!fromDate2) {
      $$invalidate(10, toDate = null);
    }
    dispatch("change", [fromDate2, toDate]);
  };
  const onChangeTo = (utc2) => {
    const toDate2 = utc2 ? enableTime ? dayjs(utc2) : dayjs(utc2).startOf("day") : null;
    if (toDate2 && (!fromDate || toDate2.isBefore(fromDate))) {
      $$invalidate(9, fromDate = !enableTime ? toDate2.startOf("day") : toDate2);
    } else if (!toDate2) {
      $$invalidate(9, fromDate = null);
    }
    dispatch("change", [fromDate, toDate2]);
  };
  const change_handler = (e) => onChangeFrom(e.detail);
  const change_handler_1 = (e) => onChangeTo(e.detail);
  $$self.$$set = ($$props2) => {
    if ("enableTime" in $$props2)
      $$invalidate(0, enableTime = $$props2.enableTime);
    if ("timeOnly" in $$props2)
      $$invalidate(1, timeOnly = $$props2.timeOnly);
    if ("ignoreTimezones" in $$props2)
      $$invalidate(2, ignoreTimezones = $$props2.ignoreTimezones);
    if ("value" in $$props2)
      $$invalidate(8, value = $$props2.value);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*value*/
    256) {
      valueStore.set(value || []);
    }
    if ($$self.$$.dirty & /*$valueStore*/
    2048) {
      parseValue($valueStore);
    }
    if ($$self.$$.dirty & /*fromDate, enableTime*/
    513) {
      $$invalidate(4, parsedFrom = fromDate ? parseDate(fromDate, { enableTime }) : void 0);
    }
    if ($$self.$$.dirty & /*toDate, enableTime*/
    1025) {
      $$invalidate(3, parsedTo = toDate ? parseDate(toDate, { enableTime }) : void 0);
    }
  };
  return [
    enableTime,
    timeOnly,
    ignoreTimezones,
    parsedTo,
    parsedFrom,
    valueStore,
    onChangeFrom,
    onChangeTo,
    value,
    fromDate,
    toDate,
    $valueStore,
    change_handler,
    change_handler_1
  ];
}
class DateRangePicker extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$4, create_fragment$4, safe_not_equal, {
      enableTime: 0,
      timeOnly: 1,
      ignoreTimezones: 2,
      value: 8
    });
  }
}
function create_default_slot$3(ctx) {
  let daterangepicker;
  let current;
  daterangepicker = new DateRangePicker({
    props: {
      error: (
        /*error*/
        ctx[5]
      ),
      disabled: (
        /*disabled*/
        ctx[3]
      ),
      readonly: (
        /*readonly*/
        ctx[4]
      ),
      value: (
        /*value*/
        ctx[0]
      ),
      appendTo: (
        /*appendTo*/
        ctx[7]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        ctx[8]
      ),
      enableTime: (
        /*enableTime*/
        ctx[9]
      ),
      timeOnly: (
        /*timeOnly*/
        ctx[10]
      )
    }
  });
  daterangepicker.$on(
    "change",
    /*onChange*/
    ctx[11]
  );
  return {
    c() {
      create_component(daterangepicker.$$.fragment);
    },
    m(target, anchor) {
      mount_component(daterangepicker, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const daterangepicker_changes = {};
      if (dirty & /*error*/
      32)
        daterangepicker_changes.error = /*error*/
        ctx2[5];
      if (dirty & /*disabled*/
      8)
        daterangepicker_changes.disabled = /*disabled*/
        ctx2[3];
      if (dirty & /*readonly*/
      16)
        daterangepicker_changes.readonly = /*readonly*/
        ctx2[4];
      if (dirty & /*value*/
      1)
        daterangepicker_changes.value = /*value*/
        ctx2[0];
      if (dirty & /*appendTo*/
      128)
        daterangepicker_changes.appendTo = /*appendTo*/
        ctx2[7];
      if (dirty & /*ignoreTimezones*/
      256)
        daterangepicker_changes.ignoreTimezones = /*ignoreTimezones*/
        ctx2[8];
      if (dirty & /*enableTime*/
      512)
        daterangepicker_changes.enableTime = /*enableTime*/
        ctx2[9];
      if (dirty & /*timeOnly*/
      1024)
        daterangepicker_changes.timeOnly = /*timeOnly*/
        ctx2[10];
      daterangepicker.$set(daterangepicker_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(daterangepicker.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(daterangepicker.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(daterangepicker, detaching);
    }
  };
}
function create_fragment$3(ctx) {
  let field;
  let current;
  field = new Field({
    props: {
      helpText: (
        /*helpText*/
        ctx[6]
      ),
      label: (
        /*label*/
        ctx[1]
      ),
      labelPosition: (
        /*labelPosition*/
        ctx[2]
      ),
      error: (
        /*error*/
        ctx[5]
      ),
      $$slots: { default: [create_default_slot$3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(field.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const field_changes = {};
      if (dirty & /*helpText*/
      64)
        field_changes.helpText = /*helpText*/
        ctx2[6];
      if (dirty & /*label*/
      2)
        field_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*labelPosition*/
      4)
        field_changes.labelPosition = /*labelPosition*/
        ctx2[2];
      if (dirty & /*error*/
      32)
        field_changes.error = /*error*/
        ctx2[5];
      if (dirty & /*$$scope, error, disabled, readonly, value, appendTo, ignoreTimezones, enableTime, timeOnly*/
      10169) {
        field_changes.$$scope = { dirty, ctx: ctx2 };
      }
      field.$set(field_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field, detaching);
    }
  };
}
function instance$3($$self, $$props, $$invalidate) {
  let { value = void 0 } = $$props;
  let { label = null } = $$props;
  let { labelPosition = "above" } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { error = null } = $$props;
  let { helpText = null } = $$props;
  let { appendTo = void 0 } = $$props;
  let { ignoreTimezones = false } = $$props;
  let { enableTime = false } = $$props;
  let { timeOnly = false } = $$props;
  const dispatch = createEventDispatcher();
  const onChange = (e) => {
    $$invalidate(0, value = e.detail);
    dispatch("change", e.detail);
  };
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("labelPosition" in $$props2)
      $$invalidate(2, labelPosition = $$props2.labelPosition);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(4, readonly = $$props2.readonly);
    if ("error" in $$props2)
      $$invalidate(5, error = $$props2.error);
    if ("helpText" in $$props2)
      $$invalidate(6, helpText = $$props2.helpText);
    if ("appendTo" in $$props2)
      $$invalidate(7, appendTo = $$props2.appendTo);
    if ("ignoreTimezones" in $$props2)
      $$invalidate(8, ignoreTimezones = $$props2.ignoreTimezones);
    if ("enableTime" in $$props2)
      $$invalidate(9, enableTime = $$props2.enableTime);
    if ("timeOnly" in $$props2)
      $$invalidate(10, timeOnly = $$props2.timeOnly);
  };
  return [
    value,
    label,
    labelPosition,
    disabled,
    readonly,
    error,
    helpText,
    appendTo,
    ignoreTimezones,
    enableTime,
    timeOnly,
    onChange
  ];
}
class DateRangePicker_1 extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$3, create_fragment$3, safe_not_equal, {
      value: 0,
      label: 1,
      labelPosition: 2,
      disabled: 3,
      readonly: 4,
      error: 5,
      helpText: 6,
      appendTo: 7,
      ignoreTimezones: 8,
      enableTime: 9,
      timeOnly: 10
    });
  }
}
function isArrayOperator(op) {
  return op === ArrayOperator.CONTAINS_ANY || op === ArrayOperator.ONE_OF;
}
const FilterPopover_svelte_svelte_type_style_lang = "";
function get_if_ctx_1(ctx) {
  const child_ctx = ctx.slice();
  const constants_0 = isArrayOperator(
    /*editableFilter*/
    child_ctx[13].operator
  );
  child_ctx[44] = constants_0;
  return child_ctx;
}
function get_if_ctx(ctx) {
  const child_ctx = ctx.slice();
  const constants_0 = isArrayOperator(
    /*editableFilter*/
    child_ctx[13].operator
  );
  child_ctx[42] = constants_0;
  const constants_1 = (
    /*isMulti*/
    child_ctx[42] ? CheckboxGroup : RadioGroup
  );
  child_ctx[43] = constants_1;
  return child_ctx;
}
const get_anchor_slot_changes = (dirty) => ({});
const get_anchor_slot_context = (ctx) => ({});
function create_if_block$2(ctx) {
  let div;
  let select;
  let t0;
  let show_if;
  let show_if_1;
  let current_block_type_index;
  let if_block;
  let t1;
  let button;
  let current;
  select = new Select_1({
    props: {
      quiet: true,
      value: (
        /*editableFilter*/
        ctx[13].operator
      ),
      disabled: !/*editableFilter*/
      ctx[13].field,
      options: (
        /*operators*/
        ctx[5]
      ),
      autoWidth: true
    }
  });
  select.$on(
    "change",
    /*change_handler*/
    ctx[27]
  );
  const if_block_creators = [
    create_if_block_1$1,
    create_if_block_2,
    create_if_block_3,
    create_if_block_4,
    create_if_block_5,
    create_if_block_6,
    create_if_block_7,
    create_else_block
  ];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    var _a, _b, _c;
    if (dirty[0] & /*editableFilter*/
    8192)
      show_if = null;
    if (dirty[0] & /*editableFilter*/
    8192)
      show_if_1 = null;
    if (show_if == null)
      show_if = !!/*editableFilter*/
      (((_a = ctx2[13]) == null ? void 0 : _a.type) && [
        FieldType.STRING,
        FieldType.LONGFORM,
        FieldType.NUMBER,
        FieldType.BIGINT,
        FieldType.FORMULA,
        FieldType.AI
      ].includes(
        /*editableFilter*/
        ctx2[13].type
      ));
    if (show_if)
      return 0;
    if (
      /*editableFilter*/
      ((_b = ctx2[13]) == null ? void 0 : _b.type) && /*editableFilter*/
      ((_c = ctx2[13]) == null ? void 0 : _c.type) === FieldType.ARRAY || /*editableFilter*/
      ctx2[13].type === FieldType.OPTIONS && /*editableFilter*/
      ctx2[13].operator === ArrayOperator.ONE_OF
    )
      return 1;
    if (
      /*editableFilter*/
      ctx2[13].type === FieldType.OPTIONS
    )
      return 2;
    if (
      /*editableFilter*/
      ctx2[13].type === FieldType.DATETIME && /*editableFilter*/
      ctx2[13].operator === "range"
    )
      return 3;
    if (
      /*editableFilter*/
      ctx2[13].type === FieldType.DATETIME
    )
      return 4;
    if (
      /*editableFilter*/
      ctx2[13].type === FieldType.BOOLEAN
    )
      return 5;
    if (show_if_1 == null)
      show_if_1 = !!/*editableFilter*/
      (ctx2[13].type && [FieldType.BB_REFERENCE, FieldType.BB_REFERENCE_SINGLE].includes(
        /*editableFilter*/
        ctx2[13].type
      ));
    if (show_if_1)
      return 6;
    return 7;
  }
  function select_block_ctx(ctx2, index) {
    if (index === 1)
      return get_if_ctx(ctx2);
    if (index === 6)
      return get_if_ctx_1(ctx2);
    return ctx2;
  }
  current_block_type_index = select_block_type(ctx, [-1, -1]);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](select_block_ctx(ctx, current_block_type_index));
  button = new Button({
    props: {
      cta: true,
      $$slots: { default: [create_default_slot_1$1] },
      $$scope: { ctx }
    }
  });
  button.$on(
    "click",
    /*click_handler*/
    ctx[34]
  );
  return {
    c() {
      div = element("div");
      create_component(select.$$.fragment);
      t0 = space();
      if_block.c();
      t1 = space();
      create_component(button.$$.fragment);
      attr(div, "class", "operator svelte-y8gc31");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(select, div, null);
      insert(target, t0, anchor);
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, t1, anchor);
      mount_component(button, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const select_changes = {};
      if (dirty[0] & /*editableFilter*/
      8192)
        select_changes.value = /*editableFilter*/
        ctx2[13].operator;
      if (dirty[0] & /*editableFilter*/
      8192)
        select_changes.disabled = !/*editableFilter*/
        ctx2[13].field;
      if (dirty[0] & /*operators*/
      32)
        select_changes.options = /*operators*/
        ctx2[5];
      select.$set(select_changes);
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2, dirty);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(select_block_ctx(ctx2, current_block_type_index), dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](select_block_ctx(ctx2, current_block_type_index));
          if_block.c();
        } else {
          if_block.p(select_block_ctx(ctx2, current_block_type_index), dirty);
        }
        transition_in(if_block, 1);
        if_block.m(t1.parentNode, t1);
      }
      const button_changes = {};
      if (dirty[0] & /*buttonText*/
      16 | dirty[1] & /*$$scope*/
      256) {
        button_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button.$set(button_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(select.$$.fragment, local);
      transition_in(if_block);
      transition_in(button.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(select.$$.fragment, local);
      transition_out(if_block);
      transition_out(button.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
        detach(t0);
        detach(t1);
      }
      destroy_component(select);
      if_blocks[current_block_type_index].d(detaching);
      destroy_component(button, detaching);
    }
  };
}
function create_else_block(ctx) {
  let input;
  let current;
  input = new Input({ props: { disabled: true } });
  return {
    c() {
      create_component(input.$$.fragment);
    },
    m(target, anchor) {
      mount_component(input, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(input.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(input.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(input, detaching);
    }
  };
}
function create_if_block_7(ctx) {
  let previous_key = (
    /*multi*/
    ctx[44]
  );
  let key_block_anchor;
  let current;
  let key_block = create_key_block_1(ctx);
  return {
    c() {
      key_block.c();
      key_block_anchor = empty();
    },
    m(target, anchor) {
      key_block.m(target, anchor);
      insert(target, key_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*editableFilter*/
      8192 && safe_not_equal(previous_key, previous_key = /*multi*/
      ctx2[44])) {
        group_outros();
        transition_out(key_block, 1, 1, noop);
        check_outros();
        key_block = create_key_block_1(ctx2);
        key_block.c();
        transition_in(key_block, 1);
        key_block.m(key_block_anchor.parentNode, key_block_anchor);
      } else {
        key_block.p(ctx2, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(key_block);
      current = true;
    },
    o(local) {
      transition_out(key_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(key_block_anchor);
      }
      key_block.d(detaching);
    }
  };
}
function create_if_block_6(ctx) {
  let select;
  let current;
  select = new Select_1({
    props: {
      value: (
        /*editableFilter*/
        ctx[13].value
      ),
      disabled: (
        /*editableFilter*/
        ctx[13].noValue
      ),
      options: [{ label: "True", value: "true" }, { label: "False", value: "false" }]
    }
  });
  select.$on(
    "change",
    /*change_handler_6*/
    ctx[33]
  );
  return {
    c() {
      create_component(select.$$.fragment);
    },
    m(target, anchor) {
      mount_component(select, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const select_changes = {};
      if (dirty[0] & /*editableFilter*/
      8192)
        select_changes.value = /*editableFilter*/
        ctx2[13].value;
      if (dirty[0] & /*editableFilter*/
      8192)
        select_changes.disabled = /*editableFilter*/
        ctx2[13].noValue;
      select.$set(select_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(select.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(select.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(select, detaching);
    }
  };
}
function create_if_block_5(ctx) {
  let datepicker;
  let current;
  datepicker = new DatePicker_1({
    props: {
      enableTime: (
        /*enableTime*/
        ctx[10]
      ),
      timeOnly: (
        /*timeOnly*/
        ctx[11]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        ctx[12]
      ),
      disabled: (
        /*editableFilter*/
        ctx[13].noValue
      ),
      value: (
        /*editableFilter*/
        ctx[13].value
      )
    }
  });
  datepicker.$on(
    "change",
    /*change_handler_5*/
    ctx[32]
  );
  return {
    c() {
      create_component(datepicker.$$.fragment);
    },
    m(target, anchor) {
      mount_component(datepicker, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const datepicker_changes = {};
      if (dirty[0] & /*enableTime*/
      1024)
        datepicker_changes.enableTime = /*enableTime*/
        ctx2[10];
      if (dirty[0] & /*timeOnly*/
      2048)
        datepicker_changes.timeOnly = /*timeOnly*/
        ctx2[11];
      if (dirty[0] & /*ignoreTimezones*/
      4096)
        datepicker_changes.ignoreTimezones = /*ignoreTimezones*/
        ctx2[12];
      if (dirty[0] & /*editableFilter*/
      8192)
        datepicker_changes.disabled = /*editableFilter*/
        ctx2[13].noValue;
      if (dirty[0] & /*editableFilter*/
      8192)
        datepicker_changes.value = /*editableFilter*/
        ctx2[13].value;
      datepicker.$set(datepicker_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(datepicker.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(datepicker.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(datepicker, detaching);
    }
  };
}
function create_if_block_4(ctx) {
  let daterangepicker;
  let current;
  daterangepicker = new DateRangePicker_1({
    props: {
      enableTime: (
        /*enableTime*/
        ctx[10]
      ),
      timeOnly: (
        /*timeOnly*/
        ctx[11]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        ctx[12]
      ),
      value: (
        /*parseDateRange*/
        ctx[18](
          /*editableFilter*/
          ctx[13].value
        )
      )
    }
  });
  daterangepicker.$on(
    "change",
    /*change_handler_4*/
    ctx[31]
  );
  return {
    c() {
      create_component(daterangepicker.$$.fragment);
    },
    m(target, anchor) {
      mount_component(daterangepicker, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const daterangepicker_changes = {};
      if (dirty[0] & /*enableTime*/
      1024)
        daterangepicker_changes.enableTime = /*enableTime*/
        ctx2[10];
      if (dirty[0] & /*timeOnly*/
      2048)
        daterangepicker_changes.timeOnly = /*timeOnly*/
        ctx2[11];
      if (dirty[0] & /*ignoreTimezones*/
      4096)
        daterangepicker_changes.ignoreTimezones = /*ignoreTimezones*/
        ctx2[12];
      if (dirty[0] & /*editableFilter*/
      8192)
        daterangepicker_changes.value = /*parseDateRange*/
        ctx2[18](
          /*editableFilter*/
          ctx2[13].value
        );
      daterangepicker.$set(daterangepicker_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(daterangepicker.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(daterangepicker.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(daterangepicker, detaching);
    }
  };
}
function create_if_block_3(ctx) {
  let coreradiogroup;
  let current;
  coreradiogroup = new RadioGroup({
    props: {
      value: (
        /*editableFilter*/
        ctx[13].value
      ),
      disabled: (
        /*editableFilter*/
        ctx[13].noValue
      ),
      options: (
        /*options*/
        ctx[14]
      ),
      direction: "vertical"
    }
  });
  coreradiogroup.$on(
    "change",
    /*change_handler_3*/
    ctx[30]
  );
  return {
    c() {
      create_component(coreradiogroup.$$.fragment);
    },
    m(target, anchor) {
      mount_component(coreradiogroup, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const coreradiogroup_changes = {};
      if (dirty[0] & /*editableFilter*/
      8192)
        coreradiogroup_changes.value = /*editableFilter*/
        ctx2[13].value;
      if (dirty[0] & /*editableFilter*/
      8192)
        coreradiogroup_changes.disabled = /*editableFilter*/
        ctx2[13].noValue;
      if (dirty[0] & /*options*/
      16384)
        coreradiogroup_changes.options = /*options*/
        ctx2[14];
      coreradiogroup.$set(coreradiogroup_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(coreradiogroup.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(coreradiogroup.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(coreradiogroup, detaching);
    }
  };
}
function create_if_block_2(ctx) {
  let previous_key = (
    /*type*/
    ctx[43]
  );
  let key_block_anchor;
  let current;
  let key_block = create_key_block(ctx);
  return {
    c() {
      key_block.c();
      key_block_anchor = empty();
    },
    m(target, anchor) {
      key_block.m(target, anchor);
      insert(target, key_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*editableFilter*/
      8192 && safe_not_equal(previous_key, previous_key = /*type*/
      ctx2[43])) {
        group_outros();
        transition_out(key_block, 1, 1, noop);
        check_outros();
        key_block = create_key_block(ctx2);
        key_block.c();
        transition_in(key_block, 1);
        key_block.m(key_block_anchor.parentNode, key_block_anchor);
      } else {
        key_block.p(ctx2, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(key_block);
      current = true;
    },
    o(local) {
      transition_out(key_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(key_block_anchor);
      }
      key_block.d(detaching);
    }
  };
}
function create_if_block_1$1(ctx) {
  let input;
  let current;
  input = new Input({
    props: {
      disabled: (
        /*editableFilter*/
        ctx[13].noValue
      ),
      value: (
        /*editableFilter*/
        ctx[13].value
      )
    }
  });
  input.$on(
    "change",
    /*change_handler_1*/
    ctx[28]
  );
  return {
    c() {
      create_component(input.$$.fragment);
    },
    m(target, anchor) {
      mount_component(input, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const input_changes = {};
      if (dirty[0] & /*editableFilter*/
      8192)
        input_changes.disabled = /*editableFilter*/
        ctx2[13].noValue;
      if (dirty[0] & /*editableFilter*/
      8192)
        input_changes.value = /*editableFilter*/
        ctx2[13].value;
      input.$set(input_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(input.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(input.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(input, detaching);
    }
  };
}
function create_key_block_1(ctx) {
  let bbreferencefield;
  let current;
  bbreferencefield = new BBReferenceField({
    props: {
      disabled: (
        /*editableFilter*/
        ctx[13].noValue
      ),
      defaultValue: (
        /*editableFilter*/
        ctx[13].value
      ),
      multi: (
        /*multi*/
        ctx[44]
      ),
      onChange: (
        /*changeUser*/
        ctx[20]
      ),
      defaultRows: Object.values(
        /*$rowCache*/
        ctx[15]
      )
    }
  });
  bbreferencefield.$on(
    "rows",
    /*cacheUserRows*/
    ctx[21]
  );
  return {
    c() {
      create_component(bbreferencefield.$$.fragment);
    },
    m(target, anchor) {
      mount_component(bbreferencefield, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const bbreferencefield_changes = {};
      if (dirty[0] & /*editableFilter*/
      8192)
        bbreferencefield_changes.disabled = /*editableFilter*/
        ctx2[13].noValue;
      if (dirty[0] & /*editableFilter*/
      8192)
        bbreferencefield_changes.defaultValue = /*editableFilter*/
        ctx2[13].value;
      if (dirty[0] & /*editableFilter*/
      8192)
        bbreferencefield_changes.multi = /*multi*/
        ctx2[44];
      if (dirty[0] & /*$rowCache*/
      32768)
        bbreferencefield_changes.defaultRows = Object.values(
          /*$rowCache*/
          ctx2[15]
        );
      bbreferencefield.$set(bbreferencefield_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(bbreferencefield.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(bbreferencefield.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(bbreferencefield, detaching);
    }
  };
}
function create_key_block(ctx) {
  let switch_instance;
  let switch_instance_anchor;
  let current;
  var switch_value = (
    /*type*/
    ctx[43]
  );
  function switch_props(ctx2, dirty) {
    return {
      props: {
        value: (
          /*editableFilter*/
          ctx2[13].value || []
        ),
        disabled: (
          /*editableFilter*/
          ctx2[13].noValue
        ),
        options: (
          /*options*/
          ctx2[14]
        ),
        direction: "vertical"
      }
    };
  }
  if (switch_value) {
    switch_instance = construct_svelte_component(switch_value, switch_props(ctx));
    switch_instance.$on(
      "change",
      /*change_handler_2*/
      ctx[29]
    );
  }
  return {
    c() {
      if (switch_instance)
        create_component(switch_instance.$$.fragment);
      switch_instance_anchor = empty();
    },
    m(target, anchor) {
      if (switch_instance)
        mount_component(switch_instance, target, anchor);
      insert(target, switch_instance_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*editableFilter*/
      8192 && switch_value !== (switch_value = /*type*/
      ctx2[43])) {
        if (switch_instance) {
          group_outros();
          const old_component = switch_instance;
          transition_out(old_component.$$.fragment, 1, 0, () => {
            destroy_component(old_component, 1);
          });
          check_outros();
        }
        if (switch_value) {
          switch_instance = construct_svelte_component(switch_value, switch_props(ctx2));
          switch_instance.$on(
            "change",
            /*change_handler_2*/
            ctx2[29]
          );
          create_component(switch_instance.$$.fragment);
          transition_in(switch_instance.$$.fragment, 1);
          mount_component(switch_instance, switch_instance_anchor.parentNode, switch_instance_anchor);
        } else {
          switch_instance = null;
        }
      } else if (switch_value) {
        const switch_instance_changes = {};
        if (dirty[0] & /*editableFilter*/
        8192)
          switch_instance_changes.value = /*editableFilter*/
          ctx2[13].value || [];
        if (dirty[0] & /*editableFilter*/
        8192)
          switch_instance_changes.disabled = /*editableFilter*/
          ctx2[13].noValue;
        if (dirty[0] & /*options*/
        16384)
          switch_instance_changes.options = /*options*/
          ctx2[14];
        switch_instance.$set(switch_instance_changes);
      }
    },
    i(local) {
      if (current)
        return;
      if (switch_instance)
        transition_in(switch_instance.$$.fragment, local);
      current = true;
    },
    o(local) {
      if (switch_instance)
        transition_out(switch_instance.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(switch_instance_anchor);
      }
      if (switch_instance)
        destroy_component(switch_instance, detaching);
    }
  };
}
function create_default_slot_1$1(ctx) {
  let t_value = (
    /*buttonText*/
    (ctx[4] || "Apply") + ""
  );
  let t;
  return {
    c() {
      t = text(t_value);
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*buttonText*/
      16 && t_value !== (t_value = /*buttonText*/
      (ctx2[4] || "Apply") + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot$2(ctx) {
  let div1;
  let div0;
  let current;
  let if_block = (
    /*editableFilter*/
    ctx[13] && /*fieldSchema*/
    ctx[6] && create_if_block$2(ctx)
  );
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      if (if_block)
        if_block.c();
      attr(div0, "class", "filter-popover-body svelte-y8gc31");
      attr(div1, "class", "filter-popover svelte-y8gc31");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      if (if_block)
        if_block.m(div0, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*editableFilter*/
        ctx2[13] && /*fieldSchema*/
        ctx2[6]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*editableFilter, fieldSchema*/
          8256) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$2(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div0, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if (if_block)
        if_block.d();
    }
  };
}
function create_fragment$2(ctx) {
  let div;
  let t;
  let popover_1;
  let updating_open;
  let current;
  let mounted;
  let dispose;
  const anchor_slot_template = (
    /*#slots*/
    ctx[25].anchor
  );
  const anchor_slot = create_slot(
    anchor_slot_template,
    ctx,
    /*$$scope*/
    ctx[39],
    get_anchor_slot_context
  );
  function popover_1_open_binding(value) {
    ctx[36](value);
  }
  let popover_1_props = {
    minWidth: 300,
    maxWidth: 300,
    anchor: (
      /*anchor*/
      ctx[8]
    ),
    align: (
      /*align*/
      ctx[2]
    ),
    showPopover: (
      /*showPopover*/
      ctx[3]
    ),
    customZIndex: 5,
    $$slots: { default: [create_default_slot$2] },
    $$scope: { ctx }
  };
  if (
    /*open*/
    ctx[9] !== void 0
  ) {
    popover_1_props.open = /*open*/
    ctx[9];
  }
  popover_1 = new Popover({ props: popover_1_props });
  ctx[35](popover_1);
  binding_callbacks.push(() => bind(popover_1, "open", popover_1_open_binding));
  popover_1.$on(
    "open",
    /*open_handler*/
    ctx[37]
  );
  popover_1.$on(
    "close",
    /*close_handler*/
    ctx[38]
  );
  return {
    c() {
      div = element("div");
      if (anchor_slot)
        anchor_slot.c();
      t = space();
      create_component(popover_1.$$.fragment);
      attr(div, "class", "anchor");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (anchor_slot) {
        anchor_slot.m(div, null);
      }
      ctx[26](div);
      insert(target, t, anchor);
      mount_component(popover_1, target, anchor);
      current = true;
      if (!mounted) {
        dispose = listen(
          div,
          "click",
          /*show*/
          ctx[0]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (anchor_slot) {
        if (anchor_slot.p && (!current || dirty[1] & /*$$scope*/
        256)) {
          update_slot_base(
            anchor_slot,
            anchor_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[39],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[39]
            ) : get_slot_changes(
              anchor_slot_template,
              /*$$scope*/
              ctx2[39],
              dirty,
              get_anchor_slot_changes
            ),
            get_anchor_slot_context
          );
        }
      }
      const popover_1_changes = {};
      if (dirty[0] & /*anchor*/
      256)
        popover_1_changes.anchor = /*anchor*/
        ctx2[8];
      if (dirty[0] & /*align*/
      4)
        popover_1_changes.align = /*align*/
        ctx2[2];
      if (dirty[0] & /*showPopover*/
      8)
        popover_1_changes.showPopover = /*showPopover*/
        ctx2[3];
      if (dirty[0] & /*editableFilter, buttonText, options, enableTime, timeOnly, ignoreTimezones, $rowCache, operators, fieldSchema*/
      64624 | dirty[1] & /*$$scope*/
      256) {
        popover_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_open && dirty[0] & /*open*/
      512) {
        updating_open = true;
        popover_1_changes.open = /*open*/
        ctx2[9];
        add_flush_callback(() => updating_open = false);
      }
      popover_1.$set(popover_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(anchor_slot, local);
      transition_in(popover_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(anchor_slot, local);
      transition_out(popover_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
        detach(t);
      }
      if (anchor_slot)
        anchor_slot.d(detaching);
      ctx[26](null);
      ctx[35](null);
      destroy_component(popover_1, detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance$2($$self, $$props, $$invalidate) {
  let editableFilter;
  let fieldSchema;
  let options;
  let $rowCache;
  let { $$slots: slots = {}, $$scope } = $$props;
  dayjs.extend(utc);
  const show = () => popover == null ? void 0 : popover.show();
  const hide = () => popover == null ? void 0 : popover.hide();
  let { align = PopoverAlignment.Left } = $$props;
  let { showPopover = true } = $$props;
  let { filter = void 0 } = $$props;
  let { schema = null } = $$props;
  let { buttonText = void 0 } = $$props;
  let { config = void 0 } = $$props;
  let { operators = void 0 } = $$props;
  const dispatch = createEventDispatcher();
  const rowCache = getContext("rows");
  component_subscribe($$self, rowCache, (value) => $$invalidate(15, $rowCache = value));
  let popover;
  let anchor;
  let open = false;
  let enableTime;
  let timeOnly;
  let ignoreTimezones;
  const parseDateRange = (range) => {
    if (!range) {
      return;
    }
    const values = [range.low, range.high];
    if (values.filter((value) => value).length === 2) {
      return values;
    }
  };
  const sanitizeOperator = (filter2) => {
    var _a;
    if (!filter2)
      return;
    const clone = cloneDeep(filter2);
    const isOperatorArray = isArrayOperator(filter2.operator);
    if (isOperatorArray && typeof filter2.value === "string" && ![FieldType.STRING, FieldType.NUMBER].includes(filter2.type)) {
      clone.value = [filter2.value];
    } else if (isOperatorArray && !((_a = filter2 == null ? void 0 : filter2.value) == null ? void 0 : _a.length)) {
      delete clone.value;
    } else if (!isOperatorArray && Array.isArray(filter2.value)) {
      clone.value = filter2.value[0];
    }
    const noValueOptions = [OperatorOptions.Empty.value, OperatorOptions.NotEmpty.value];
    clone.noValue = noValueOptions.includes(clone.operator);
    if (!(clone == null ? void 0 : clone.operator)) {
      delete clone.value;
    }
    return clone;
  };
  const getOptions = (schema2) => {
    if (!schema2)
      return [];
    const constraints = fieldSchema == null ? void 0 : fieldSchema.constraints;
    const opts = (constraints == null ? void 0 : constraints.inclusion) ?? [];
    return opts;
  };
  const getDefaultFilter = (filter2, schema2, config2) => {
    var _a;
    if (filter2) {
      return cloneDeep(filter2);
    } else if (!schema2 || !config2) {
      return;
    }
    const schemaField = schema2[config2.field];
    const defaultValue = (schemaField == null ? void 0 : schemaField.type) === FieldType.BOOLEAN ? "true" : void 0;
    const defaultFilter = {
      valueType: FilterValueType.VALUE,
      field: config2.field,
      type: schemaField == null ? void 0 : schemaField.type,
      operator: BasicOperator.EMPTY,
      value: defaultValue
    };
    return {
      ...defaultFilter,
      operator: (_a = operators == null ? void 0 : operators[0]) == null ? void 0 : _a.value
    };
  };
  const changeUser = (update) => {
    if (!update || !editableFilter)
      return;
    $$invalidate(13, editableFilter = sanitizeOperator({ ...editableFilter, value: update.value }));
  };
  const cacheUserRows = (e) => {
    const retrieved = e.detail.reduce(
      (acc, ele) => {
        acc[ele._id] = ele;
        return acc;
      },
      {}
    );
    rowCache.update((state) => ({ ...state, ...retrieved }));
  };
  function div_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      anchor = $$value;
      $$invalidate(8, anchor);
    });
  }
  const change_handler = (e) => {
    if (!editableFilter)
      return;
    const sanitized = sanitizeOperator({ ...editableFilter, operator: e.detail });
    $$invalidate(13, editableFilter = { ...sanitized || editableFilter });
  };
  const change_handler_1 = (e) => {
    if (!editableFilter)
      return;
    $$invalidate(13, editableFilter = sanitizeOperator({ ...editableFilter, value: e.detail }));
  };
  const change_handler_2 = (e) => {
    if (!editableFilter)
      return;
    $$invalidate(13, editableFilter = sanitizeOperator({ ...editableFilter, value: e.detail }));
  };
  const change_handler_3 = (e) => {
    if (!editableFilter)
      return;
    $$invalidate(13, editableFilter = sanitizeOperator({ ...editableFilter, value: e.detail }));
  };
  const change_handler_4 = (e) => {
    const [from, to] = e.detail;
    const parsedFrom = enableTime ? from.utc().format() : stringifyDate(from, { enableTime, timeOnly, ignoreTimezones });
    const parsedTo = enableTime ? to.utc().format() : stringifyDate(to, { enableTime, timeOnly, ignoreTimezones });
    if (!editableFilter)
      return;
    $$invalidate(13, editableFilter = sanitizeOperator({
      ...editableFilter,
      value: { low: parsedFrom, high: parsedTo }
    }));
  };
  const change_handler_5 = (e) => {
    if (!editableFilter)
      return;
    $$invalidate(13, editableFilter = sanitizeOperator({ ...editableFilter, value: e.detail }));
  };
  const change_handler_6 = (e) => {
    if (!editableFilter)
      return;
    $$invalidate(13, editableFilter = sanitizeOperator({ ...editableFilter, value: e.detail }));
  };
  const click_handler = () => {
    const sanitized = sanitizeOperator(editableFilter);
    const { noValue, value, operator } = sanitized || {};
    const update = !noValue && !value || !operator ? void 0 : sanitized;
    dispatch("change", update);
    hide();
  };
  function popover_1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      popover = $$value;
      $$invalidate(7, popover);
    });
  }
  function popover_1_open_binding(value) {
    open = value;
    $$invalidate(9, open);
  }
  function open_handler(event) {
    bubble.call(this, $$self, event);
  }
  function close_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("align" in $$props2)
      $$invalidate(2, align = $$props2.align);
    if ("showPopover" in $$props2)
      $$invalidate(3, showPopover = $$props2.showPopover);
    if ("filter" in $$props2)
      $$invalidate(22, filter = $$props2.filter);
    if ("schema" in $$props2)
      $$invalidate(23, schema = $$props2.schema);
    if ("buttonText" in $$props2)
      $$invalidate(4, buttonText = $$props2.buttonText);
    if ("config" in $$props2)
      $$invalidate(24, config = $$props2.config);
    if ("operators" in $$props2)
      $$invalidate(5, operators = $$props2.operators);
    if ("$$scope" in $$props2)
      $$invalidate(39, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*filter, schema, config*/
    29360128) {
      $$invalidate(13, editableFilter = getDefaultFilter(filter, schema, config));
    }
    if ($$self.$$.dirty[0] & /*config, schema*/
    25165824) {
      $$invalidate(6, fieldSchema = config ? schema == null ? void 0 : schema[config == null ? void 0 : config.field] : void 0);
    }
    if ($$self.$$.dirty[0] & /*fieldSchema*/
    64) {
      $$invalidate(14, options = getOptions(fieldSchema));
    }
    if ($$self.$$.dirty[0] & /*fieldSchema*/
    64) {
      if ((fieldSchema == null ? void 0 : fieldSchema.type) === FieldType.DATETIME) {
        $$invalidate(10, enableTime = !(fieldSchema == null ? void 0 : fieldSchema.dateOnly));
        $$invalidate(11, timeOnly = !!(fieldSchema == null ? void 0 : fieldSchema.timeOnly));
        $$invalidate(12, ignoreTimezones = !!(fieldSchema == null ? void 0 : fieldSchema.ignoreTimezones));
      }
    }
  };
  return [
    show,
    hide,
    align,
    showPopover,
    buttonText,
    operators,
    fieldSchema,
    popover,
    anchor,
    open,
    enableTime,
    timeOnly,
    ignoreTimezones,
    editableFilter,
    options,
    $rowCache,
    dispatch,
    rowCache,
    parseDateRange,
    sanitizeOperator,
    changeUser,
    cacheUserRows,
    filter,
    schema,
    config,
    slots,
    div_binding,
    change_handler,
    change_handler_1,
    change_handler_2,
    change_handler_3,
    change_handler_4,
    change_handler_5,
    change_handler_6,
    click_handler,
    popover_1_binding,
    popover_1_open_binding,
    open_handler,
    close_handler,
    $$scope
  ];
}
class FilterPopover extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance$2,
      create_fragment$2,
      safe_not_equal,
      {
        show: 0,
        hide: 1,
        align: 2,
        showPopover: 3,
        filter: 22,
        schema: 23,
        buttonText: 4,
        config: 24,
        operators: 5
      },
      null,
      [-1, -1]
    );
  }
  get show() {
    return this.$$.ctx[0];
  }
  get hide() {
    return this.$$.ctx[1];
  }
}
const FilterButton_svelte_svelte_type_style_lang = "";
function create_default_slot$1(ctx) {
  let t;
  return {
    c() {
      t = text(
        /*buttonText*/
        ctx[2]
      );
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*buttonText*/
      4)
        set_data(
          t,
          /*buttonText*/
          ctx2[2]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_1(ctx) {
  let span;
  let t;
  return {
    c() {
      span = element("span");
      t = text(
        /*filterDisplay*/
        ctx[11]
      );
      attr(span, "class", "display svelte-1ohvvxo");
    },
    m(target, anchor) {
      insert(target, span, anchor);
      append(span, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*filterDisplay*/
      2048)
        set_data(
          t,
          /*filterDisplay*/
          ctx2[11]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(span);
      }
    }
  };
}
function create_if_block$1(ctx) {
  let span;
  let t;
  return {
    c() {
      span = element("span");
      t = text(
        /*filterMeta*/
        ctx[9]
      );
      attr(span, "class", "filterMeta");
    },
    m(target, anchor) {
      insert(target, span, anchor);
      append(span, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*filterMeta*/
      512)
        set_data(
          t,
          /*filterMeta*/
          ctx2[9]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(span);
      }
    }
  };
}
function create_anchor_slot(ctx) {
  var _a, _b;
  let div3;
  let div2;
  let div1;
  let div0;
  let icon;
  let t0;
  let span1;
  let span0;
  let t1_value = (
    /*config*/
    (((_a = ctx[4]) == null ? void 0 : _a.label) || /*config*/
    ((_b = ctx[4]) == null ? void 0 : _b.field)) + ""
  );
  let t1;
  let t2;
  let t3;
  let div1_class_value;
  let div1_title_value;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({
    props: {
      name: (
        /*iconName*/
        ctx[13]
      ),
      size: (
        /*size*/
        ctx[1]
      )
    }
  });
  let if_block0 = (
    /*filter*/
    ctx[3] && create_if_block_1(ctx)
  );
  let if_block1 = (
    /*filterMeta*/
    ctx[9] && create_if_block$1(ctx)
  );
  return {
    c() {
      div3 = element("div");
      div2 = element("div");
      div1 = element("div");
      div0 = element("div");
      create_component(icon.$$.fragment);
      t0 = space();
      span1 = element("span");
      span0 = element("span");
      t1 = text(t1_value);
      t2 = space();
      if (if_block0)
        if_block0.c();
      t3 = space();
      if (if_block1)
        if_block1.c();
      attr(div0, "class", "toggle-wrap svelte-1ohvvxo");
      attr(span0, "class", "field");
      attr(span1, "class", "spectrum-Button-label svelte-1ohvvxo");
      toggle_class(
        span1,
        "truncate",
        /*truncate*/
        ctx[12]
      );
      attr(div1, "class", div1_class_value = "new-styles spectrum-Button spectrum-Button--secondary spectrum-Button--size" + /*size*/
      ctx[1].toUpperCase() + " svelte-1ohvvxo");
      attr(div1, "title", div1_title_value = /*filterTitle*/
      ctx[10] || /*filterDisplay*/
      ctx[11]);
      toggle_class(
        div1,
        "is-disabled",
        /*disabled*/
        ctx[0]
      );
      attr(div2, "class", "filter-button-wrap svelte-1ohvvxo");
      toggle_class(div2, "inactive", !/*filter*/
      ctx[3]);
      attr(div3, "slot", "anchor");
    },
    m(target, anchor) {
      insert(target, div3, anchor);
      append(div3, div2);
      append(div2, div1);
      append(div1, div0);
      mount_component(icon, div0, null);
      append(div1, t0);
      append(div1, span1);
      append(span1, span0);
      append(span0, t1);
      append(span1, t2);
      if (if_block0)
        if_block0.m(span1, null);
      append(div1, t3);
      if (if_block1)
        if_block1.m(div1, null);
      ctx[19](div1);
      current = true;
      if (!mounted) {
        dispose = listen(
          div0,
          "click",
          /*click_handler*/
          ctx[18]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      var _a2, _b2;
      const icon_changes = {};
      if (dirty & /*iconName*/
      8192)
        icon_changes.name = /*iconName*/
        ctx2[13];
      if (dirty & /*size*/
      2)
        icon_changes.size = /*size*/
        ctx2[1];
      icon.$set(icon_changes);
      if ((!current || dirty & /*config*/
      16) && t1_value !== (t1_value = /*config*/
      (((_a2 = ctx2[4]) == null ? void 0 : _a2.label) || /*config*/
      ((_b2 = ctx2[4]) == null ? void 0 : _b2.field)) + ""))
        set_data(t1, t1_value);
      if (
        /*filter*/
        ctx2[3]
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
        } else {
          if_block0 = create_if_block_1(ctx2);
          if_block0.c();
          if_block0.m(span1, null);
        }
      } else if (if_block0) {
        if_block0.d(1);
        if_block0 = null;
      }
      if (!current || dirty & /*truncate*/
      4096) {
        toggle_class(
          span1,
          "truncate",
          /*truncate*/
          ctx2[12]
        );
      }
      if (
        /*filterMeta*/
        ctx2[9]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
        } else {
          if_block1 = create_if_block$1(ctx2);
          if_block1.c();
          if_block1.m(div1, null);
        }
      } else if (if_block1) {
        if_block1.d(1);
        if_block1 = null;
      }
      if (!current || dirty & /*size*/
      2 && div1_class_value !== (div1_class_value = "new-styles spectrum-Button spectrum-Button--secondary spectrum-Button--size" + /*size*/
      ctx2[1].toUpperCase() + " svelte-1ohvvxo")) {
        attr(div1, "class", div1_class_value);
      }
      if (!current || dirty & /*filterTitle, filterDisplay*/
      3072 && div1_title_value !== (div1_title_value = /*filterTitle*/
      ctx2[10] || /*filterDisplay*/
      ctx2[11])) {
        attr(div1, "title", div1_title_value);
      }
      if (!current || dirty & /*size, disabled*/
      3) {
        toggle_class(
          div1,
          "is-disabled",
          /*disabled*/
          ctx2[0]
        );
      }
      if (!current || dirty & /*filter*/
      8) {
        toggle_class(div2, "inactive", !/*filter*/
        ctx2[3]);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div3);
      }
      destroy_component(icon);
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
      ctx[19](null);
      mounted = false;
      dispose();
    }
  };
}
function create_fragment$1(ctx) {
  let filterpopover;
  let current;
  let filterpopover_props = {
    filter: (
      /*filter*/
      ctx[3]
    ),
    operators: (
      /*operators*/
      ctx[6]
    ),
    schema: (
      /*schema*/
      ctx[5]
    ),
    config: (
      /*config*/
      ctx[4]
    ),
    buttonText: (
      /*buttonText*/
      ctx[2]
    ),
    $$slots: {
      anchor: [create_anchor_slot],
      default: [create_default_slot$1]
    },
    $$scope: { ctx }
  };
  filterpopover = new FilterPopover({ props: filterpopover_props });
  ctx[20](filterpopover);
  filterpopover.$on(
    "change",
    /*change_handler*/
    ctx[21]
  );
  return {
    c() {
      create_component(filterpopover.$$.fragment);
    },
    m(target, anchor) {
      mount_component(filterpopover, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const filterpopover_changes = {};
      if (dirty & /*filter*/
      8)
        filterpopover_changes.filter = /*filter*/
        ctx2[3];
      if (dirty & /*operators*/
      64)
        filterpopover_changes.operators = /*operators*/
        ctx2[6];
      if (dirty & /*schema*/
      32)
        filterpopover_changes.schema = /*schema*/
        ctx2[5];
      if (dirty & /*config*/
      16)
        filterpopover_changes.config = /*config*/
        ctx2[4];
      if (dirty & /*buttonText*/
      4)
        filterpopover_changes.buttonText = /*buttonText*/
        ctx2[2];
      if (dirty & /*$$scope, filter, size, filterTitle, filterDisplay, button, disabled, filterMeta, truncate, config, iconName, buttonText*/
      67125023) {
        filterpopover_changes.$$scope = { dirty, ctx: ctx2 };
      }
      filterpopover.$set(filterpopover_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(filterpopover.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(filterpopover.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      ctx[20](null);
      destroy_component(filterpopover, detaching);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let iconName;
  let fieldSchema;
  let filterOp;
  let truncate;
  let filterDisplay;
  let $rowCache;
  let { disabled = false } = $$props;
  let { size = "S" } = $$props;
  let { buttonText = "Apply" } = $$props;
  let { filter = void 0 } = $$props;
  let { config = void 0 } = $$props;
  let { schema = null } = $$props;
  let { operators = void 0 } = $$props;
  const dispatch = createEventDispatcher();
  const rowCache = getContext("rows");
  component_subscribe($$self, rowCache, (value) => $$invalidate(22, $rowCache = value));
  let popover;
  let button;
  let filterMeta;
  let filterTitle;
  const parseDateDisplay = (filter2, fieldSchema2) => {
    if (!filter2 || !fieldSchema2 || fieldSchema2.type !== FieldType.DATETIME)
      return "";
    if (filter2.operator === RangeOperator.RANGE) {
      const enableTime = !fieldSchema2.dateOnly;
      const { high, low } = filter2.value;
      return `${getDateDisplayValue(low, { enableTime })}
        - ${getDateDisplayValue(high, { enableTime })}`;
    }
    const parsed = parseDate(filter2.value, { enableTime: !fieldSchema2.dateOnly });
    const display = getDateDisplayValue(parsed, { enableTime: !fieldSchema2.dateOnly });
    return `${display}`;
  };
  const parseMultiDisplay = (value) => {
    const moreThanOne = Array.isArray(value) && (value == null ? void 0 : value.length) > 1 ? `+${(value == null ? void 0 : value.length) - 1} more` : void 0;
    $$invalidate(9, filterMeta = moreThanOne);
    $$invalidate(10, filterTitle = `${value == null ? void 0 : value.join(", ")}`);
    return `${value == null ? void 0 : value[0]}`;
  };
  const displayText = (filter2, fieldSchema2) => {
    $$invalidate(9, filterMeta = void 0);
    $$invalidate(10, filterTitle = void 0);
    if (!filter2 || !fieldSchema2)
      return;
    let display = filter2.value;
    if (fieldSchema2.type === FieldType.BOOLEAN) {
      display = capitalise(filter2.value);
    } else if (fieldSchema2.type === FieldType.DATETIME) {
      display = parseDateDisplay(filter2, fieldSchema2);
    } else if (fieldSchema2.type === FieldType.ARRAY) {
      if (!isArrayOperator(filter2.operator)) {
        display = filter2.value;
      } else {
        const filterVals = Array.isArray(filter2.value) ? filter2.value : [filter2.value];
        display = parseMultiDisplay(filterVals);
      }
    } else if (fieldSchema2.type === FieldType.BB_REFERENCE || fieldSchema2.type === FieldType.BB_REFERENCE_SINGLE) {
      let userDisplay = "";
      if (!isArrayOperator(filter2.operator)) {
        const userRow = $rowCache == null ? void 0 : $rowCache[filter2.value];
        userDisplay = (userRow == null ? void 0 : userRow.email) ?? filter2.value;
      } else {
        const filterVals = Array.isArray(filter2.value) ? filter2.value : [filter2.value];
        userDisplay = parseMultiDisplay(filterVals.map((val) => {
          var _a;
          return ((_a = $rowCache == null ? void 0 : $rowCache[val]) == null ? void 0 : _a.email) ?? val;
        }));
      }
      display = userDisplay;
    }
    return `${filterOp == null ? void 0 : filterOp.label.toLowerCase()} ${filter2.noValue ? "" : display}`;
  };
  const click_handler = (e) => {
    if (filter) {
      e.stopPropagation();
    }
    if (!disabled) {
      dispatch("toggle");
    }
  };
  function div1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      button = $$value;
      $$invalidate(8, button);
    });
  }
  function filterpopover_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      popover = $$value;
      $$invalidate(7, popover);
    });
  }
  function change_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("disabled" in $$props2)
      $$invalidate(0, disabled = $$props2.disabled);
    if ("size" in $$props2)
      $$invalidate(1, size = $$props2.size);
    if ("buttonText" in $$props2)
      $$invalidate(2, buttonText = $$props2.buttonText);
    if ("filter" in $$props2)
      $$invalidate(3, filter = $$props2.filter);
    if ("config" in $$props2)
      $$invalidate(4, config = $$props2.config);
    if ("schema" in $$props2)
      $$invalidate(5, schema = $$props2.schema);
    if ("operators" in $$props2)
      $$invalidate(6, operators = $$props2.operators);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*filter*/
    8) {
      $$invalidate(13, iconName = !filter ? "sliders-horizontal" : "x-circle");
    }
    if ($$self.$$.dirty & /*config, schema*/
    48) {
      $$invalidate(17, fieldSchema = config ? schema == null ? void 0 : schema[config == null ? void 0 : config.field] : void 0);
    }
    if ($$self.$$.dirty & /*filter, operators*/
    72) {
      $$invalidate(16, filterOp = filter ? operators == null ? void 0 : operators.find((op) => op.value === filter.operator) : void 0);
    }
    if ($$self.$$.dirty & /*filterOp*/
    65536) {
      $$invalidate(12, truncate = (filterOp == null ? void 0 : filterOp.value) !== RangeOperator.RANGE);
    }
    if ($$self.$$.dirty & /*filter, fieldSchema*/
    131080) {
      $$invalidate(11, filterDisplay = displayText(filter, fieldSchema));
    }
  };
  return [
    disabled,
    size,
    buttonText,
    filter,
    config,
    schema,
    operators,
    popover,
    button,
    filterMeta,
    filterTitle,
    filterDisplay,
    truncate,
    iconName,
    dispatch,
    rowCache,
    filterOp,
    fieldSchema,
    click_handler,
    div1_binding,
    filterpopover_binding,
    change_handler
  ];
}
class FilterButton extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, {
      disabled: 0,
      size: 1,
      buttonText: 2,
      filter: 3,
      config: 4,
      schema: 5,
      operators: 6
    });
  }
}
const Filter_svelte_svelte_type_style_lang = "";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[53] = list[i];
  const constants_0 = (
    /*$memoFilters*/
    child_ctx[6][
      /*config*/
      child_ctx[53].field
    ]
  );
  child_ctx[54] = constants_0;
  return child_ctx;
}
function create_each_block(ctx) {
  let filterbutton;
  let current;
  function change_handler(...args) {
    return (
      /*change_handler*/
      ctx[29](
        /*config*/
        ctx[53],
        ...args
      )
    );
  }
  function toggle_handler() {
    return (
      /*toggle_handler*/
      ctx[30](
        /*config*/
        ctx[53]
      )
    );
  }
  filterbutton = new FilterButton({
    props: {
      size: (
        /*size*/
        ctx[1]
      ),
      config: (
        /*config*/
        ctx[53]
      ),
      filter: (
        /*filter*/
        ctx[54]
      ),
      schema: (
        /*schema*/
        ctx[5]
      ),
      buttonText: (
        /*buttonText*/
        ctx[2]
      ),
      operators: (
        /*getOperators*/
        ctx[10](
          /*config*/
          ctx[53],
          /*schema*/
          ctx[5]
        )
      )
    }
  });
  filterbutton.$on("change", change_handler);
  filterbutton.$on("toggle", toggle_handler);
  return {
    c() {
      create_component(filterbutton.$$.fragment);
    },
    m(target, anchor) {
      mount_component(filterbutton, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const filterbutton_changes = {};
      if (dirty[0] & /*size*/
      2)
        filterbutton_changes.size = /*size*/
        ctx[1];
      if (dirty[0] & /*visibleFilters*/
      128)
        filterbutton_changes.config = /*config*/
        ctx[53];
      if (dirty[0] & /*$memoFilters, visibleFilters*/
      192)
        filterbutton_changes.filter = /*filter*/
        ctx[54];
      if (dirty[0] & /*schema*/
      32)
        filterbutton_changes.schema = /*schema*/
        ctx[5];
      if (dirty[0] & /*buttonText*/
      4)
        filterbutton_changes.buttonText = /*buttonText*/
        ctx[2];
      if (dirty[0] & /*visibleFilters, schema*/
      160)
        filterbutton_changes.operators = /*getOperators*/
        ctx[10](
          /*config*/
          ctx[53],
          /*schema*/
          ctx[5]
        );
      filterbutton.$set(filterbutton_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(filterbutton.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(filterbutton.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(filterbutton, detaching);
    }
  };
}
function create_if_block(ctx) {
  let button;
  let current;
  button = new Button({
    props: {
      size: (
        /*size*/
        ctx[1]
      ),
      secondary: true,
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  button.$on(
    "click",
    /*clearAll*/
    ctx[11]
  );
  return {
    c() {
      create_component(button.$$.fragment);
    },
    m(target, anchor) {
      mount_component(button, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const button_changes = {};
      if (dirty[0] & /*size*/
      2)
        button_changes.size = /*size*/
        ctx2[1];
      if (dirty[1] & /*$$scope*/
      67108864) {
        button_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button.$set(button_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(button.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(button.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(button, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let t;
  return {
    c() {
      t = text("Clear all");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot(ctx) {
  let t;
  let show_if = (
    /*showClear*/
    ctx[0] && Object.keys(
      /*filters*/
      ctx[4]
    ).length
  );
  let if_block_anchor;
  let current;
  let each_value = ensure_array_like(
    /*visibleFilters*/
    ctx[7] || []
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  let if_block = show_if && create_if_block(ctx);
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*size, visibleFilters, $memoFilters, schema, buttonText, getOperators, filters*/
      1270) {
        each_value = ensure_array_like(
          /*visibleFilters*/
          ctx2[7] || []
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(t.parentNode, t);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      if (dirty[0] & /*showClear, filters*/
      17)
        show_if = /*showClear*/
        ctx2[0] && Object.keys(
          /*filters*/
          ctx2[4]
        ).length;
      if (show_if) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*showClear, filters*/
          17) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      transition_in(if_block);
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      destroy_each(each_blocks, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let div1;
  let div0;
  let container;
  let current;
  container = new Container({
    props: {
      wrap: true,
      direction: "row",
      hAlign: "left",
      vAlign: "top",
      gap: "S",
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      create_component(container.$$.fragment);
      attr(div0, "class", "filters svelte-u18njk");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      mount_component(container, div0, null);
      current = true;
    },
    p(ctx2, dirty) {
      const container_changes = {};
      if (dirty[0] & /*size, showClear, filters, visibleFilters, $memoFilters, schema, buttonText*/
      247 | dirty[1] & /*$$scope*/
      67108864) {
        container_changes.$$scope = { dirty, ctx: ctx2 };
      }
      container.$set(container_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(container.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(container.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      destroy_component(container);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let filterExtension;
  let query;
  let filterDatasource;
  let componentId;
  let target;
  let loaded;
  let isGridblock;
  let visibleFilters;
  let addAction;
  let removeAction;
  let addExtension;
  let removeExtension;
  let rels;
  let relIds;
  let fetchedRows;
  let $component;
  let $uiStateStore;
  let $userFetch, $$unsubscribe_userFetch = noop, $$subscribe_userFetch = () => ($$unsubscribe_userFetch(), $$unsubscribe_userFetch = subscribe(userFetch, ($$value) => $$invalidate(28, $userFetch = $$value)), userFetch);
  let $memoFilters;
  component_subscribe($$self, uiStateStore, ($$value) => $$invalidate(35, $uiStateStore = $$value));
  $$self.$$.on_destroy.push(() => $$unsubscribe_userFetch());
  let { persistFilters = false } = $$props;
  let { showClear = false } = $$props;
  let { filterConfig = [] } = $$props;
  let { targetComponent } = $$props;
  let { size = "M" } = $$props;
  let { buttonText = "Apply" } = $$props;
  const memoFilters = memo({});
  component_subscribe($$self, memoFilters, (value) => $$invalidate(6, $memoFilters = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(34, $component = value));
  const { API, fetchDatasourceSchema, getRelationshipSchemaAdditions } = getContext("sdk");
  const rowCache = writable({});
  setContext("rows", rowCache);
  const baseFilter = {
    logicalOperator: UILogicalOperator.ALL,
    onEmptyFilter: EmptyFilterOption.RETURN_NONE,
    groups: [
      {
        logicalOperator: UILogicalOperator.ALL,
        // could be configurable
        filters: []
      }
    ]
  };
  let userFetch;
  let hydrated = false;
  let filters = {};
  let schema;
  let dataComponent = null;
  const initTarget = (target2) => {
    if (!dataComponent && target2) {
      $$invalidate(16, dataComponent = target2);
      if (!hydrated) {
        hydrateFilters();
      }
    } else if (dataComponent && !target2) {
      $$invalidate(15, hydrated = false);
      $$invalidate(16, dataComponent = null);
      $$invalidate(4, filters = {});
      $$invalidate(5, schema = null);
    }
  };
  const getValidOperatorsForType$1 = (config, schema2) => {
    if (!(config == null ? void 0 : config.field) || !config.columnType || !schema2) {
      return [];
    }
    const fieldType = config.columnType || schema2[config.field].type;
    let coreOperators = getValidOperatorsForType({ type: fieldType }, config.field, filterDatasource);
    const isDateTime = fieldType === FieldType.DATETIME;
    const opToDisplay = {
      rangeHigh: isDateTime ? "Before" : void 0,
      rangeLow: isDateTime ? "After" : void 0,
      [FilterType.EQUAL]: "Is",
      [FilterType.NOT_EQUAL]: "Is not"
    };
    coreOperators = [
      ...coreOperators,
      ...fieldType === FieldType.DATETIME ? [
        {
          value: RangeOperator.RANGE,
          label: "Between"
        }
      ] : []
    ];
    return coreOperators.filter((op) => {
      if (isDateTime && op.value === FilterType.ONE_OF)
        return false;
      return true;
    }).map((op) => ({
      ...op,
      label: opToDisplay[op.value] || op.label
    }));
  };
  const buildExtension = (filters2) => {
    const extension = cloneDeep(baseFilter);
    delete extension.onEmptyFilter;
    if (extension.groups) {
      const groups = extension.groups;
      groups[0].filters = Object.values(filters2);
    }
    return extension;
  };
  const fire = (extension) => {
    if (!($component == null ? void 0 : $component.id) || !componentId)
      return;
    if (Object.keys(filters).length == 0) {
      removeExtension == null ? void 0 : removeExtension($component.id);
      toLocalStorage();
      return;
    }
    if (persistFilters) {
      toLocalStorage();
    }
    addExtension == null ? void 0 : addExtension($component.id, isGridblock ? extension : query);
  };
  const toLocalStorage = () => {
    uiStateStore.update((state) => ({
      ...state,
      [$component.id]: {
        sourceId: filterDatasource.resourceId,
        filters
      }
    }));
  };
  const clearLocalStorage = () => {
    uiStateStore.update((state) => {
      delete state[$component.id];
      return state;
    });
  };
  const excludedTypes = [FieldType.ATTACHMENT_SINGLE, FieldType.ATTACHMENTS, FieldType.AI];
  async function fetchSchema(datasource) {
    if (datasource) {
      const fetchedSchema = await fetchDatasourceSchema(datasource, {
        enrichRelationships: true,
        formSchema: false
      });
      const filteredSchemaEntries = Object.entries(fetchedSchema || {}).filter(([_, field]) => {
        return !excludedTypes.includes(field.type);
      });
      const filteredSchema = Object.fromEntries(filteredSchemaEntries);
      const enrichedSchema = await getRelationshipSchemaAdditions(filteredSchema);
      $$invalidate(5, schema = { ...filteredSchema, ...enrichedSchema });
    } else {
      $$invalidate(5, schema = null);
    }
  }
  const getOperators = (config, schema2) => {
    const operators = getValidOperatorsForType$1(config, schema2);
    return operators;
  };
  const clearAll = () => {
    $$invalidate(4, filters = {});
    uiStateStore.update((state) => {
      delete state[$component.id];
      return state;
    });
  };
  const createFetch = (initValue) => {
    let searchFilter = {
      logicalOperator: UILogicalOperator.ALL,
      filters: [
        {
          field: "_id",
          operator: ArrayOperator.ONE_OF,
          value: Array.isArray(initValue) ? initValue : [initValue]
        }
      ]
    };
    let initFilter = initValue ? {
      logicalOperator: UILogicalOperator.ALL,
      groups: [searchFilter],
      onEmptyFilter: EmptyFilterOption.RETURN_NONE
    } : void 0;
    const ds = {
      type: "user",
      tableId: InternalTable.USER_METADATA
    };
    return fetchData({
      API,
      datasource: ds,
      options: { filter: initFilter, limit: 100 }
    });
  };
  const initRelationShips = (filters2) => {
    const filtered = Object.entries(filters2 || {}).filter(([_, filter]) => {
      return filter.type === FieldType.BB_REFERENCE_SINGLE || filter.type === FieldType.BB_REFERENCE;
    });
    return Object.fromEntries(filtered);
  };
  const getRelIds = (filters2) => {
    const filtered = Object.entries(filters2 || {}).reduce(
      (acc, [_, filter]) => {
        if ((filter.type === FieldType.BB_REFERENCE_SINGLE || filter.type === FieldType.BB_REFERENCE) && filter.value) {
          acc = [
            ...acc,
            ...Array.isArray(filter.value) ? filter.value : [filter.value]
          ];
        }
        return acc;
      },
      []
    );
    const uniqueIds = new Set(filtered);
    return Array.from(uniqueIds);
  };
  const hydrateFilters = () => {
    var _a;
    if (persistFilters) {
      const filterState = (_a = $uiStateStore[$component.id]) == null ? void 0 : _a.filters;
      $$invalidate(4, filters = cloneDeep(filterState || {}));
    }
    $$invalidate(15, hydrated = true);
  };
  onMount(() => {
    if (!persistFilters) {
      clearLocalStorage();
    } else {
      hydrateFilters();
    }
  });
  onDestroy(() => {
    removeExtension == null ? void 0 : removeExtension($component.id);
  });
  const change_handler = (config, e) => {
    if (!e.detail) {
      const { [config.field]: removed, ...rest } = filters;
      $$invalidate(4, filters = { ...rest });
    } else {
      $$invalidate(4, filters = { ...filters, [config.field]: e.detail });
    }
  };
  const toggle_handler = (config) => {
    const { [config.field]: removed, ...rest } = filters;
    $$invalidate(4, filters = { ...rest });
  };
  $$self.$$set = ($$props2) => {
    if ("persistFilters" in $$props2)
      $$invalidate(12, persistFilters = $$props2.persistFilters);
    if ("showClear" in $$props2)
      $$invalidate(0, showClear = $$props2.showClear);
    if ("filterConfig" in $$props2)
      $$invalidate(13, filterConfig = $$props2.filterConfig);
    if ("targetComponent" in $$props2)
      $$invalidate(14, targetComponent = $$props2.targetComponent);
    if ("size" in $$props2)
      $$invalidate(1, size = $$props2.size);
    if ("buttonText" in $$props2)
      $$invalidate(2, buttonText = $$props2.buttonText);
  };
  $$self.$$.update = () => {
    var _a, _b, _c;
    if ($$self.$$.dirty[0] & /*filters*/
    16) {
      memoFilters.set(filters);
    }
    if ($$self.$$.dirty[0] & /*$memoFilters*/
    64) {
      $$invalidate(23, filterExtension = buildExtension($memoFilters));
    }
    if ($$self.$$.dirty[0] & /*filterExtension*/
    8388608) {
      query = filterExtension ? buildQuery(filterExtension) : null;
    }
    if ($$self.$$.dirty[0] & /*targetComponent*/
    16384) {
      $$invalidate(20, filterDatasource = ((_a = targetComponent == null ? void 0 : targetComponent.embeddedData) == null ? void 0 : _a.dataSource) ?? (targetComponent == null ? void 0 : targetComponent.datasource));
    }
    if ($$self.$$.dirty[0] & /*targetComponent*/
    16384) {
      $$invalidate(22, componentId = ((_b = targetComponent == null ? void 0 : targetComponent.embeddedData) == null ? void 0 : _b.componentId) ?? (targetComponent == null ? void 0 : targetComponent.id));
    }
    if ($$self.$$.dirty[0] & /*componentId*/
    4194304) {
      $$invalidate(27, target = componentStore.actions.getComponentById(componentId));
    }
    if ($$self.$$.dirty[0] & /*targetComponent*/
    16384) {
      $$invalidate(24, loaded = (((_c = targetComponent == null ? void 0 : targetComponent.embeddedData) == null ? void 0 : _c.loaded) ?? (targetComponent == null ? void 0 : targetComponent.loaded)) || false);
    }
    if ($$self.$$.dirty[0] & /*loaded, target*/
    150994944) {
      loaded && initTarget(target);
    }
    if ($$self.$$.dirty[0] & /*dataComponent, filterDatasource*/
    1114112) {
      dataComponent && fetchSchema(filterDatasource);
    }
    if ($$self.$$.dirty[0] & /*dataComponent*/
    65536) {
      $$invalidate(21, isGridblock = (dataComponent == null ? void 0 : dataComponent._component) === "@budibase/standard-components/gridblock");
    }
    if ($$self.$$.dirty[0] & /*filterConfig, schema*/
    8224) {
      $$invalidate(7, visibleFilters = filterConfig == null ? void 0 : filterConfig.filter((filter) => filter.active && (schema == null ? void 0 : schema[filter.field])));
    }
    if ($$self.$$.dirty[0] & /*isGridblock*/
    2097152) {
      $$invalidate(26, addAction = isGridblock ? ActionTypes.AddDataProviderFilterExtension : ActionTypes.AddDataProviderQueryExtension);
    }
    if ($$self.$$.dirty[0] & /*isGridblock*/
    2097152) {
      $$invalidate(25, removeAction = isGridblock ? ActionTypes.RemoveDataProviderFilterExtension : ActionTypes.RemoveDataProviderQueryExtension);
    }
    if ($$self.$$.dirty[0] & /*componentId, loaded, addAction*/
    88080384) {
      addExtension = componentId && loaded ? getAction(componentId, addAction) : null;
    }
    if ($$self.$$.dirty[0] & /*componentId, loaded, removeAction*/
    54525952) {
      removeExtension = componentId && loaded ? getAction(componentId, removeAction) : null;
    }
    if ($$self.$$.dirty[0] & /*hydrated, dataComponent, loaded, filterExtension*/
    25264128) {
      hydrated && dataComponent && loaded && fire(filterExtension);
    }
    if ($$self.$$.dirty[0] & /*$memoFilters*/
    64) {
      $$invalidate(19, rels = initRelationShips($memoFilters));
    }
    if ($$self.$$.dirty[0] & /*rels*/
    524288) {
      $$invalidate(18, relIds = getRelIds(rels));
    }
    if ($$self.$$.dirty[0] & /*userFetch, relIds*/
    262152) {
      if (!userFetch && relIds.length) {
        $$subscribe_userFetch($$invalidate(3, userFetch = createFetch(relIds)));
      }
    }
    if ($$self.$$.dirty[0] & /*userFetch, $userFetch*/
    268435464) {
      $$invalidate(17, fetchedRows = userFetch ? $userFetch == null ? void 0 : $userFetch.rows : []);
    }
    if ($$self.$$.dirty[0] & /*fetchedRows*/
    131072) {
      if (fetchedRows.length) {
        const fetched = fetchedRows.reduce(
          (acc, ele) => {
            acc[ele._id] = ele;
            return acc;
          },
          {}
        );
        rowCache.update((state) => ({ ...state, ...fetched }));
      }
    }
  };
  return [
    showClear,
    size,
    buttonText,
    userFetch,
    filters,
    schema,
    $memoFilters,
    visibleFilters,
    memoFilters,
    component,
    getOperators,
    clearAll,
    persistFilters,
    filterConfig,
    targetComponent,
    hydrated,
    dataComponent,
    fetchedRows,
    relIds,
    rels,
    filterDatasource,
    isGridblock,
    componentId,
    filterExtension,
    loaded,
    removeAction,
    addAction,
    target,
    $userFetch,
    change_handler,
    toggle_handler
  ];
}
class Filter extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        persistFilters: 12,
        showClear: 0,
        filterConfig: 13,
        targetComponent: 14,
        size: 1,
        buttonText: 2
      },
      null,
      [-1, -1]
    );
  }
}
export {
  Filter as default
};
