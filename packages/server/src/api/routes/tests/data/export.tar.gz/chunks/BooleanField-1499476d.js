import { S as SvelteComponent, i as init, s as safe_not_equal, W as binding_callbacks, a0 as bind, c as create_component, m as mount_component, a1 as add_flush_callback, k as transition_in, n as transition_out, p as destroy_component, y as empty, f as insert, z as group_outros, A as check_outros, o as detach, c7 as Checkbox } from "./index-8b9900f1.js";
import { F as Field } from "./Field-a0270b82.js";
import "./Placeholder-4dedd9c4.js";
import "./InnerForm-0042fa8f.js";
function create_if_block(ctx) {
  let corecheckbox;
  let current;
  corecheckbox = new Checkbox({
    props: {
      value: (
        /*fieldState*/
        ctx[10].value
      ),
      disabled: (
        /*fieldState*/
        ctx[10].disabled
      ),
      readonly: (
        /*fieldState*/
        ctx[10].readonly
      ),
      error: (
        /*fieldState*/
        ctx[10].error
      ),
      id: (
        /*fieldState*/
        ctx[10].fieldId
      ),
      size: (
        /*size*/
        ctx[5]
      ),
      text: (
        /*text*/
        ctx[2]
      )
    }
  });
  corecheckbox.$on(
    "change",
    /*handleChange*/
    ctx[13]
  );
  return {
    c() {
      create_component(corecheckbox.$$.fragment);
    },
    m(target, anchor) {
      mount_component(corecheckbox, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const corecheckbox_changes = {};
      if (dirty & /*fieldState*/
      1024)
        corecheckbox_changes.value = /*fieldState*/
        ctx2[10].value;
      if (dirty & /*fieldState*/
      1024)
        corecheckbox_changes.disabled = /*fieldState*/
        ctx2[10].disabled;
      if (dirty & /*fieldState*/
      1024)
        corecheckbox_changes.readonly = /*fieldState*/
        ctx2[10].readonly;
      if (dirty & /*fieldState*/
      1024)
        corecheckbox_changes.error = /*fieldState*/
        ctx2[10].error;
      if (dirty & /*fieldState*/
      1024)
        corecheckbox_changes.id = /*fieldState*/
        ctx2[10].fieldId;
      if (dirty & /*size*/
      32)
        corecheckbox_changes.size = /*size*/
        ctx2[5];
      if (dirty & /*text*/
      4)
        corecheckbox_changes.text = /*text*/
        ctx2[2];
      corecheckbox.$set(corecheckbox_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(corecheckbox.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(corecheckbox.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(corecheckbox, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*fieldState*/
    ctx[10] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*fieldState*/
        ctx2[10]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*fieldState*/
          1024) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let current;
  function field_1_fieldState_binding(value) {
    ctx[15](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[16](value);
  }
  let field_1_props = {
    label: (
      /*label*/
      ctx[1]
    ),
    field: (
      /*field*/
      ctx[0]
    ),
    disabled: (
      /*disabled*/
      ctx[3]
    ),
    readonly: (
      /*readonly*/
      ctx[4]
    ),
    validation: (
      /*validation*/
      ctx[6]
    ),
    span: (
      /*span*/
      ctx[8]
    ),
    helpText: (
      /*helpText*/
      ctx[9]
    ),
    defaultValue: (
      /*isTruthy*/
      ctx[12](
        /*defaultValue*/
        ctx[7]
      )
    ),
    type: "boolean",
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*fieldState*/
    ctx[10] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[10];
  }
  if (
    /*fieldApi*/
    ctx[11] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[11];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  return {
    c() {
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const field_1_changes = {};
      if (dirty & /*label*/
      2)
        field_1_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*field*/
      1)
        field_1_changes.field = /*field*/
        ctx2[0];
      if (dirty & /*disabled*/
      8)
        field_1_changes.disabled = /*disabled*/
        ctx2[3];
      if (dirty & /*readonly*/
      16)
        field_1_changes.readonly = /*readonly*/
        ctx2[4];
      if (dirty & /*validation*/
      64)
        field_1_changes.validation = /*validation*/
        ctx2[6];
      if (dirty & /*span*/
      256)
        field_1_changes.span = /*span*/
        ctx2[8];
      if (dirty & /*helpText*/
      512)
        field_1_changes.helpText = /*helpText*/
        ctx2[9];
      if (dirty & /*defaultValue*/
      128)
        field_1_changes.defaultValue = /*isTruthy*/
        ctx2[12](
          /*defaultValue*/
          ctx2[7]
        );
      if (dirty & /*$$scope, fieldState, size, text*/
      132132) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty & /*fieldState*/
      1024) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[10];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty & /*fieldApi*/
      2048) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[11];
        add_flush_callback(() => updating_fieldApi = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field_1, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { field } = $$props;
  let { label } = $$props;
  let { text } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { size } = $$props;
  let { validation } = $$props;
  let { defaultValue } = $$props;
  let { onChange } = $$props;
  let { span } = $$props;
  let { helpText = null } = $$props;
  let fieldState;
  let fieldApi;
  const isTruthy = (value) => {
    if (!value) {
      return false;
    }
    if (value === true) {
      return true;
    }
    if (typeof value === "string" && value.toLowerCase() === "true") {
      return true;
    }
    return false;
  };
  const handleChange = (e) => {
    const changed = fieldApi.setValue(e.detail);
    if (onChange && changed) {
      onChange({ value: e.detail });
    }
  };
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(10, fieldState);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(11, fieldApi);
  }
  $$self.$$set = ($$props2) => {
    if ("field" in $$props2)
      $$invalidate(0, field = $$props2.field);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("text" in $$props2)
      $$invalidate(2, text = $$props2.text);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(4, readonly = $$props2.readonly);
    if ("size" in $$props2)
      $$invalidate(5, size = $$props2.size);
    if ("validation" in $$props2)
      $$invalidate(6, validation = $$props2.validation);
    if ("defaultValue" in $$props2)
      $$invalidate(7, defaultValue = $$props2.defaultValue);
    if ("onChange" in $$props2)
      $$invalidate(14, onChange = $$props2.onChange);
    if ("span" in $$props2)
      $$invalidate(8, span = $$props2.span);
    if ("helpText" in $$props2)
      $$invalidate(9, helpText = $$props2.helpText);
  };
  return [
    field,
    label,
    text,
    disabled,
    readonly,
    size,
    validation,
    defaultValue,
    span,
    helpText,
    fieldState,
    fieldApi,
    isTruthy,
    handleChange,
    onChange,
    field_1_fieldState_binding,
    field_1_fieldApi_binding
  ];
}
class BooleanField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      field: 0,
      label: 1,
      text: 2,
      disabled: 3,
      readonly: 4,
      size: 5,
      validation: 6,
      defaultValue: 7,
      onChange: 14,
      span: 8,
      helpText: 9
    });
  }
}
export {
  BooleanField as default
};
