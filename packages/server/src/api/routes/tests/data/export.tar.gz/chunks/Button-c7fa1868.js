import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, B as noop, o as detach, u as getContext, v as component_subscribe, e as element, a as space, t as text, b as attr, am as null_to_empty, d as toggle_class, g as append, q as action_destroyer, l as listen, h as is_function, bU as set_data_maybe_contenteditable, r as run_all, W as binding_callbacks } from "./index-8b9900f1.js";
import { l as loadPhosphorIconWeight } from "./phosphorIconLoader-f5abc73c.js";
const Button_svelte_svelte_type_style_lang = "";
function create_if_block(ctx) {
  let i;
  let i_class_value;
  return {
    c() {
      i = element("i");
      attr(i, "class", i_class_value = /*iconClass*/
      ctx[13] + " " + /*size*/
      ctx[1] + " svelte-1033xd6");
    },
    m(target, anchor) {
      insert(target, i, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*iconClass, size*/
      8194 && i_class_value !== (i_class_value = /*iconClass*/
      ctx2[13] + " " + /*size*/
      ctx2[1] + " svelte-1033xd6")) {
        attr(i, "class", i_class_value);
      }
    },
    d(detaching) {
      if (detaching) {
        detach(i);
      }
    }
  };
}
function create_key_block(ctx) {
  let button;
  let t0;
  let t1;
  let button_class_value;
  let button_disabled_value;
  let button_contenteditable_value;
  let styleable_action;
  let mounted;
  let dispose;
  let if_block = (
    /*icon*/
    ctx[4] && create_if_block(ctx)
  );
  return {
    c() {
      button = element("button");
      if (if_block)
        if_block.c();
      t0 = space();
      t1 = text(
        /*componentText*/
        ctx[12]
      );
      attr(button, "class", button_class_value = null_to_empty(`spectrum-Button spectrum-Button--size${/*size*/
      ctx[1]} spectrum-Button--${/*type*/
      ctx[2]} gap-${/*gap*/
      ctx[5]}`) + " svelte-1033xd6");
      button.disabled = button_disabled_value = /*disabled*/
      ctx[0] || /*handlingOnClick*/
      ctx[10];
      attr(button, "contenteditable", button_contenteditable_value = /*$component*/
      ctx[8].editing && !/*icon*/
      ctx[4]);
      toggle_class(
        button,
        "spectrum-Button--quiet",
        /*quiet*/
        ctx[3]
      );
      toggle_class(
        button,
        "custom",
        /*customBg*/
        ctx[11]
      );
      toggle_class(
        button,
        "active",
        /*active*/
        ctx[6]
      );
    },
    m(target, anchor) {
      insert(target, button, anchor);
      if (if_block)
        if_block.m(button, null);
      append(button, t0);
      append(button, t1);
      ctx[24](button);
      if (!mounted) {
        dispose = [
          action_destroyer(styleable_action = /*styleable*/
          ctx[14].call(
            null,
            button,
            /*$component*/
            ctx[8].styles
          )),
          listen(
            button,
            "click",
            /*handleOnClick*/
            ctx[18]
          ),
          listen(button, "blur", function() {
            if (is_function(
              /*$component*/
              ctx[8].editing ? (
                /*updateText*/
                ctx[17]
              ) : null
            ))
              /*$component*/
              (ctx[8].editing ? (
                /*updateText*/
                ctx[17]
              ) : null).apply(this, arguments);
          }),
          listen(
            button,
            "input",
            /*input_handler*/
            ctx[25]
          )
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (
        /*icon*/
        ctx[4]
      ) {
        if (if_block) {
          if_block.p(ctx, dirty);
        } else {
          if_block = create_if_block(ctx);
          if_block.c();
          if_block.m(button, t0);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (dirty & /*componentText*/
      4096)
        set_data_maybe_contenteditable(
          t1,
          /*componentText*/
          ctx[12],
          /*$component*/
          ctx[8].editing && !/*icon*/
          ctx[4]
        );
      if (dirty & /*size, type, gap*/
      38 && button_class_value !== (button_class_value = null_to_empty(`spectrum-Button spectrum-Button--size${/*size*/
      ctx[1]} spectrum-Button--${/*type*/
      ctx[2]} gap-${/*gap*/
      ctx[5]}`) + " svelte-1033xd6")) {
        attr(button, "class", button_class_value);
      }
      if (dirty & /*disabled, handlingOnClick*/
      1025 && button_disabled_value !== (button_disabled_value = /*disabled*/
      ctx[0] || /*handlingOnClick*/
      ctx[10])) {
        button.disabled = button_disabled_value;
      }
      if (dirty & /*$component, icon*/
      272 && button_contenteditable_value !== (button_contenteditable_value = /*$component*/
      ctx[8].editing && !/*icon*/
      ctx[4])) {
        attr(button, "contenteditable", button_contenteditable_value);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      256)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx[8].styles
        );
      if (dirty & /*size, type, gap, quiet*/
      46) {
        toggle_class(
          button,
          "spectrum-Button--quiet",
          /*quiet*/
          ctx[3]
        );
      }
      if (dirty & /*size, type, gap, customBg*/
      2086) {
        toggle_class(
          button,
          "custom",
          /*customBg*/
          ctx[11]
        );
      }
      if (dirty & /*size, type, gap, active*/
      102) {
        toggle_class(
          button,
          "active",
          /*active*/
          ctx[6]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      if (if_block)
        if_block.d();
      ctx[24](null);
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_fragment(ctx) {
  let previous_key = (
    /*$component*/
    ctx[8].editing
  );
  let key_block_anchor;
  let key_block = create_key_block(ctx);
  return {
    c() {
      key_block.c();
      key_block_anchor = empty();
    },
    m(target, anchor) {
      key_block.m(target, anchor);
      insert(target, key_block_anchor, anchor);
    },
    p(ctx2, [dirty]) {
      if (dirty & /*$component*/
      256 && safe_not_equal(previous_key, previous_key = /*$component*/
      ctx2[8].editing)) {
        key_block.d(1);
        key_block = create_key_block(ctx2);
        key_block.c();
        key_block.m(key_block_anchor.parentNode, key_block_anchor);
      } else {
        key_block.p(ctx2, dirty);
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(key_block_anchor);
      }
      key_block.d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let isLegacyIcon;
  let isPhosphorIcon;
  let iconClass;
  let componentText;
  let customBg;
  let $component;
  let $builderStore;
  const { styleable, builderStore } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(23, $builderStore = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(8, $component = value));
  let { disabled = false } = $$props;
  let { text: text2 = "" } = $$props;
  let { onClick } = $$props;
  let { size = "M" } = $$props;
  let { type = "cta" } = $$props;
  let { quiet = false } = $$props;
  let { icon = null } = $$props;
  let { gap = "M" } = $$props;
  let { active = false } = $$props;
  let node;
  let touched = false;
  let handlingOnClick = false;
  const getComponentText = (text3, builderState, componentState) => {
    if (componentState.editing) {
      return text3 || " ";
    }
    return text3 || componentState.name || "Placeholder text";
  };
  const updateText = (e) => {
    if (touched) {
      builderStore.actions.updateProp("text", e.target.textContent);
    }
    $$invalidate(9, touched = false);
  };
  const handleOnClick = async () => {
    $$invalidate(10, handlingOnClick = true);
    if (onClick) {
      await onClick();
    }
    $$invalidate(10, handlingOnClick = false);
  };
  function button_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      node = $$value;
      $$invalidate(7, node);
    });
  }
  const input_handler = () => $$invalidate(9, touched = true);
  $$self.$$set = ($$props2) => {
    if ("disabled" in $$props2)
      $$invalidate(0, disabled = $$props2.disabled);
    if ("text" in $$props2)
      $$invalidate(19, text2 = $$props2.text);
    if ("onClick" in $$props2)
      $$invalidate(20, onClick = $$props2.onClick);
    if ("size" in $$props2)
      $$invalidate(1, size = $$props2.size);
    if ("type" in $$props2)
      $$invalidate(2, type = $$props2.type);
    if ("quiet" in $$props2)
      $$invalidate(3, quiet = $$props2.quiet);
    if ("icon" in $$props2)
      $$invalidate(4, icon = $$props2.icon);
    if ("gap" in $$props2)
      $$invalidate(5, gap = $$props2.gap);
    if ("active" in $$props2)
      $$invalidate(6, active = $$props2.active);
  };
  $$self.$$.update = () => {
    var _a, _b, _c, _d;
    if ($$self.$$.dirty & /*icon*/
    16) {
      $$invalidate(22, isLegacyIcon = icon && (icon.startsWith("ri-") || icon.includes("remix")));
    }
    if ($$self.$$.dirty & /*icon, isLegacyIcon*/
    4194320) {
      $$invalidate(21, isPhosphorIcon = icon && !isLegacyIcon);
    }
    if ($$self.$$.dirty & /*isPhosphorIcon*/
    2097152) {
      if (isPhosphorIcon) {
        loadPhosphorIconWeight("regular");
      }
    }
    if ($$self.$$.dirty & /*isPhosphorIcon, icon*/
    2097168) {
      $$invalidate(13, iconClass = isPhosphorIcon ? (() => {
        const iconName = icon.replace(/^ph-/, "");
        return `ph ph-${iconName}`;
      })() : icon);
    }
    if ($$self.$$.dirty & /*$component, node*/
    384) {
      $component.editing && (node == null ? void 0 : node.focus());
    }
    if ($$self.$$.dirty & /*text, $builderStore, $component*/
    8913152) {
      $$invalidate(12, componentText = getComponentText(text2, $builderStore, $component));
    }
    if ($$self.$$.dirty & /*$component*/
    256) {
      $$invalidate(11, customBg = ((_b = (_a = $component.styles) == null ? void 0 : _a.normal) == null ? void 0 : _b.background) || ((_d = (_c = $component.styles) == null ? void 0 : _c.normal) == null ? void 0 : _d["background-image"]));
    }
  };
  return [
    disabled,
    size,
    type,
    quiet,
    icon,
    gap,
    active,
    node,
    $component,
    touched,
    handlingOnClick,
    customBg,
    componentText,
    iconClass,
    styleable,
    builderStore,
    component,
    updateText,
    handleOnClick,
    text2,
    onClick,
    isPhosphorIcon,
    isLegacyIcon,
    $builderStore,
    button_binding,
    input_handler
  ];
}
class Button extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      disabled: 0,
      text: 19,
      onClick: 20,
      size: 1,
      type: 2,
      quiet: 3,
      icon: 4,
      gap: 5,
      active: 6
    });
  }
}
export {
  Button as default
};
