import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, b as attr, d as toggle_class, f as insert, g as append, B as noop, o as detach, U as onMount, w as onDestroy, W as binding_callbacks, y as empty, z as group_outros, n as transition_out, A as check_outros, k as transition_in, Y as createEventDispatcher, a0 as bind, c as create_component, m as mount_component, a1 as add_flush_callback, p as destroy_component, V as bubble, u as getContext, v as component_subscribe, X as setContext, a3 as writable } from "./index-8b9900f1.js";
import { T as TextArea } from "./TextArea-78f87eef.js";
import { F as Field } from "./Field-a0270b82.js";
import "./Placeholder-4dedd9c4.js";
import "./InnerForm-0042fa8f.js";
function create_fragment$3(ctx) {
  let div;
  let textarea;
  return {
    c() {
      div = element("div");
      textarea = element("textarea");
      textarea.disabled = true;
      attr(
        textarea,
        "id",
        /*id*/
        ctx[0]
      );
      attr(
        div,
        "style",
        /*styleString*/
        ctx[3]
      );
      attr(div, "class", "svelte-1888jbe");
      toggle_class(
        div,
        "disabled",
        /*disabled*/
        ctx[1]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, textarea);
      ctx[9](textarea);
    },
    p(ctx2, [dirty]) {
      if (dirty & /*id*/
      1) {
        attr(
          textarea,
          "id",
          /*id*/
          ctx2[0]
        );
      }
      if (dirty & /*styleString*/
      8) {
        attr(
          div,
          "style",
          /*styleString*/
          ctx2[3]
        );
      }
      if (dirty & /*disabled*/
      2) {
        toggle_class(
          div,
          "disabled",
          /*disabled*/
          ctx2[1]
        );
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      ctx[9](null);
    }
  };
}
function instance$3($$self, $$props, $$invalidate) {
  let styleString;
  let { height = null } = $$props;
  let { scroll = true } = $$props;
  let { easyMDEOptions = null } = $$props;
  let { mde = null } = $$props;
  let { id = null } = $$props;
  let { fullScreenOffset = null } = $$props;
  let { disabled = false } = $$props;
  let element2 = void 0;
  onMount(async () => {
    $$invalidate(4, height = height || "200px");
    const { default: EasyMDE } = await import("./easymde-68976a10.js").then((n) => n.e);
    $$invalidate(5, mde = new EasyMDE({
      element: element2,
      spellChecker: false,
      status: false,
      unorderedListStyle: "-",
      maxHeight: scroll ? height : void 0,
      minHeight: scroll ? void 0 : height,
      ...easyMDEOptions
    }));
  });
  onDestroy(() => {
    mde == null ? void 0 : mde.toTextArea();
  });
  const getStyleString = (offset) => {
    let string = "";
    string += `--fullscreen-offset-x:${(offset == null ? void 0 : offset.x) || "0px"};`;
    string += `--fullscreen-offset-y:${(offset == null ? void 0 : offset.y) || "0px"};`;
    return string;
  };
  function textarea_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      element2 = $$value;
      $$invalidate(2, element2);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("height" in $$props2)
      $$invalidate(4, height = $$props2.height);
    if ("scroll" in $$props2)
      $$invalidate(6, scroll = $$props2.scroll);
    if ("easyMDEOptions" in $$props2)
      $$invalidate(7, easyMDEOptions = $$props2.easyMDEOptions);
    if ("mde" in $$props2)
      $$invalidate(5, mde = $$props2.mde);
    if ("id" in $$props2)
      $$invalidate(0, id = $$props2.id);
    if ("fullScreenOffset" in $$props2)
      $$invalidate(8, fullScreenOffset = $$props2.fullScreenOffset);
    if ("disabled" in $$props2)
      $$invalidate(1, disabled = $$props2.disabled);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*fullScreenOffset*/
    256) {
      $$invalidate(3, styleString = getStyleString(fullScreenOffset));
    }
  };
  return [
    id,
    disabled,
    element2,
    styleString,
    height,
    mde,
    scroll,
    easyMDEOptions,
    fullScreenOffset,
    textarea_binding
  ];
}
class SpectrumMDE extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$3, create_fragment$3, safe_not_equal, {
      height: 4,
      scroll: 6,
      easyMDEOptions: 7,
      mde: 5,
      id: 0,
      fullScreenOffset: 8,
      disabled: 1
    });
  }
}
function create_key_block(ctx) {
  let spectrummde;
  let updating_mde;
  let current;
  function spectrummde_mde_binding(value) {
    ctx[9](value);
  }
  let spectrummde_props = {
    scroll: true,
    height: (
      /*height*/
      ctx[1]
    ),
    id: (
      /*id*/
      ctx[3]
    ),
    fullScreenOffset: (
      /*fullScreenOffset*/
      ctx[4]
    ),
    disabled: (
      /*disabled*/
      ctx[5]
    ),
    easyMDEOptions: {
      initialValue: (
        /*value*/
        ctx[0]
      ),
      placeholder: (
        /*placeholder*/
        ctx[2]
      ),
      toolbar: (
        /*disabled*/
        ctx[5] || /*readonly*/
        ctx[6] ? false : void 0
      ),
      .../*easyMDEOptions*/
      ctx[7]
    }
  };
  if (
    /*mde*/
    ctx[8] !== void 0
  ) {
    spectrummde_props.mde = /*mde*/
    ctx[8];
  }
  spectrummde = new SpectrumMDE({ props: spectrummde_props });
  binding_callbacks.push(() => bind(spectrummde, "mde", spectrummde_mde_binding));
  return {
    c() {
      create_component(spectrummde.$$.fragment);
    },
    m(target, anchor) {
      mount_component(spectrummde, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const spectrummde_changes = {};
      if (dirty & /*height*/
      2)
        spectrummde_changes.height = /*height*/
        ctx2[1];
      if (dirty & /*id*/
      8)
        spectrummde_changes.id = /*id*/
        ctx2[3];
      if (dirty & /*fullScreenOffset*/
      16)
        spectrummde_changes.fullScreenOffset = /*fullScreenOffset*/
        ctx2[4];
      if (dirty & /*disabled*/
      32)
        spectrummde_changes.disabled = /*disabled*/
        ctx2[5];
      if (dirty & /*value, placeholder, disabled, readonly, easyMDEOptions*/
      229)
        spectrummde_changes.easyMDEOptions = {
          initialValue: (
            /*value*/
            ctx2[0]
          ),
          placeholder: (
            /*placeholder*/
            ctx2[2]
          ),
          toolbar: (
            /*disabled*/
            ctx2[5] || /*readonly*/
            ctx2[6] ? false : void 0
          ),
          .../*easyMDEOptions*/
          ctx2[7]
        };
      if (!updating_mde && dirty & /*mde*/
      256) {
        updating_mde = true;
        spectrummde_changes.mde = /*mde*/
        ctx2[8];
        add_flush_callback(() => updating_mde = false);
      }
      spectrummde.$set(spectrummde_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(spectrummde.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(spectrummde.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(spectrummde, detaching);
    }
  };
}
function create_fragment$2(ctx) {
  let previous_key = (
    /*height*/
    ctx[1]
  );
  let key_block_anchor;
  let current;
  let key_block = create_key_block(ctx);
  return {
    c() {
      key_block.c();
      key_block_anchor = empty();
    },
    m(target, anchor) {
      key_block.m(target, anchor);
      insert(target, key_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (dirty & /*height*/
      2 && safe_not_equal(previous_key, previous_key = /*height*/
      ctx2[1])) {
        group_outros();
        transition_out(key_block, 1, 1, noop);
        check_outros();
        key_block = create_key_block(ctx2);
        key_block.c();
        transition_in(key_block, 1);
        key_block.m(key_block_anchor.parentNode, key_block_anchor);
      } else {
        key_block.p(ctx2, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(key_block);
      current = true;
    },
    o(local) {
      transition_out(key_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(key_block_anchor);
      }
      key_block.d(detaching);
    }
  };
}
function instance$2($$self, $$props, $$invalidate) {
  let { value = null } = $$props;
  let { height = null } = $$props;
  let { placeholder = null } = $$props;
  let { id = null } = $$props;
  let { fullScreenOffset = null } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { easyMDEOptions = {} } = $$props;
  const dispatch = createEventDispatcher();
  let latestValue;
  let mde;
  const checkValue = (val) => {
    if (mde && val !== latestValue) {
      mde.value(val);
    }
  };
  const update = () => {
    latestValue = mde.value();
    dispatch("change", latestValue);
  };
  function spectrummde_mde_binding(value2) {
    mde = value2;
    $$invalidate(8, mde);
  }
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("height" in $$props2)
      $$invalidate(1, height = $$props2.height);
    if ("placeholder" in $$props2)
      $$invalidate(2, placeholder = $$props2.placeholder);
    if ("id" in $$props2)
      $$invalidate(3, id = $$props2.id);
    if ("fullScreenOffset" in $$props2)
      $$invalidate(4, fullScreenOffset = $$props2.fullScreenOffset);
    if ("disabled" in $$props2)
      $$invalidate(5, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(6, readonly = $$props2.readonly);
    if ("easyMDEOptions" in $$props2)
      $$invalidate(7, easyMDEOptions = $$props2.easyMDEOptions);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*value*/
    1) {
      checkValue(value);
    }
    if ($$self.$$.dirty & /*mde*/
    256) {
      mde == null ? void 0 : mde.codemirror.on("blur", update);
    }
    if ($$self.$$.dirty & /*readonly, disabled, mde*/
    352) {
      if (readonly || disabled) {
        mde == null ? void 0 : mde.togglePreview();
      }
    }
  };
  return [
    value,
    height,
    placeholder,
    id,
    fullScreenOffset,
    disabled,
    readonly,
    easyMDEOptions,
    mde,
    spectrummde_mde_binding
  ];
}
class MarkdownEditor extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$2, create_fragment$2, safe_not_equal, {
      value: 0,
      height: 1,
      placeholder: 2,
      id: 3,
      fullScreenOffset: 4,
      disabled: 5,
      readonly: 6,
      easyMDEOptions: 7
    });
  }
}
function create_fragment$1(ctx) {
  let div;
  let markdowneditor;
  let current;
  markdowneditor = new MarkdownEditor({
    props: {
      value: (
        /*value*/
        ctx[0]
      ),
      placeholder: (
        /*placeholder*/
        ctx[1]
      ),
      height: (
        /*height*/
        ctx[4]
      ),
      id: (
        /*id*/
        ctx[5]
      ),
      fullScreenOffset: (
        /*fullScreenOffset*/
        ctx[6]
      ),
      disabled: (
        /*disabled*/
        ctx[2]
      ),
      easyMDEOptions: (
        /*easyMDEOptions*/
        ctx[7]
      ),
      readonly: (
        /*readonly*/
        ctx[3]
      )
    }
  });
  markdowneditor.$on(
    "change",
    /*change_handler*/
    ctx[8]
  );
  return {
    c() {
      div = element("div");
      create_component(markdowneditor.$$.fragment);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(markdowneditor, div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      const markdowneditor_changes = {};
      if (dirty & /*value*/
      1)
        markdowneditor_changes.value = /*value*/
        ctx2[0];
      if (dirty & /*placeholder*/
      2)
        markdowneditor_changes.placeholder = /*placeholder*/
        ctx2[1];
      if (dirty & /*height*/
      16)
        markdowneditor_changes.height = /*height*/
        ctx2[4];
      if (dirty & /*id*/
      32)
        markdowneditor_changes.id = /*id*/
        ctx2[5];
      if (dirty & /*fullScreenOffset*/
      64)
        markdowneditor_changes.fullScreenOffset = /*fullScreenOffset*/
        ctx2[6];
      if (dirty & /*disabled*/
      4)
        markdowneditor_changes.disabled = /*disabled*/
        ctx2[2];
      if (dirty & /*easyMDEOptions*/
      128)
        markdowneditor_changes.easyMDEOptions = /*easyMDEOptions*/
        ctx2[7];
      if (dirty & /*readonly*/
      8)
        markdowneditor_changes.readonly = /*readonly*/
        ctx2[3];
      markdowneditor.$set(markdowneditor_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(markdowneditor.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(markdowneditor.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(markdowneditor);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let { value = "" } = $$props;
  let { placeholder = null } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { height = null } = $$props;
  let { id = null } = $$props;
  let { fullScreenOffset = null } = $$props;
  let { easyMDEOptions = null } = $$props;
  function change_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("placeholder" in $$props2)
      $$invalidate(1, placeholder = $$props2.placeholder);
    if ("disabled" in $$props2)
      $$invalidate(2, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(3, readonly = $$props2.readonly);
    if ("height" in $$props2)
      $$invalidate(4, height = $$props2.height);
    if ("id" in $$props2)
      $$invalidate(5, id = $$props2.id);
    if ("fullScreenOffset" in $$props2)
      $$invalidate(6, fullScreenOffset = $$props2.fullScreenOffset);
    if ("easyMDEOptions" in $$props2)
      $$invalidate(7, easyMDEOptions = $$props2.easyMDEOptions);
  };
  return [
    value,
    placeholder,
    disabled,
    readonly,
    height,
    id,
    fullScreenOffset,
    easyMDEOptions,
    change_handler
  ];
}
class RichTextField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, {
      value: 0,
      placeholder: 1,
      disabled: 2,
      readonly: 3,
      height: 4,
      id: 5,
      fullScreenOffset: 6,
      easyMDEOptions: 7
    });
  }
}
function create_if_block(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block_1, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*useRichText*/
      ctx2[12]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_else_block(ctx) {
  let coretextarea;
  let current;
  coretextarea = new TextArea({
    props: {
      value: (
        /*fieldState*/
        ctx[9].value
      ),
      disabled: (
        /*fieldState*/
        ctx[9].disabled
      ),
      readonly: (
        /*fieldState*/
        ctx[9].readonly
      ),
      error: (
        /*fieldState*/
        ctx[9].error
      ),
      id: (
        /*fieldState*/
        ctx[9].fieldId
      ),
      placeholder: (
        /*placeholder*/
        ctx[2]
      ),
      minHeight: (
        /*height*/
        ctx[11]
      )
    }
  });
  coretextarea.$on(
    "change",
    /*handleChange*/
    ctx[18]
  );
  return {
    c() {
      create_component(coretextarea.$$.fragment);
    },
    m(target, anchor) {
      mount_component(coretextarea, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const coretextarea_changes = {};
      if (dirty & /*fieldState*/
      512)
        coretextarea_changes.value = /*fieldState*/
        ctx2[9].value;
      if (dirty & /*fieldState*/
      512)
        coretextarea_changes.disabled = /*fieldState*/
        ctx2[9].disabled;
      if (dirty & /*fieldState*/
      512)
        coretextarea_changes.readonly = /*fieldState*/
        ctx2[9].readonly;
      if (dirty & /*fieldState*/
      512)
        coretextarea_changes.error = /*fieldState*/
        ctx2[9].error;
      if (dirty & /*fieldState*/
      512)
        coretextarea_changes.id = /*fieldState*/
        ctx2[9].fieldId;
      if (dirty & /*placeholder*/
      4)
        coretextarea_changes.placeholder = /*placeholder*/
        ctx2[2];
      if (dirty & /*height*/
      2048)
        coretextarea_changes.minHeight = /*height*/
        ctx2[11];
      coretextarea.$set(coretextarea_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(coretextarea.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(coretextarea.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(coretextarea, detaching);
    }
  };
}
function create_if_block_1(ctx) {
  let corerichtextfield;
  let current;
  corerichtextfield = new RichTextField({
    props: {
      value: (
        /*fieldState*/
        ctx[9].value
      ),
      disabled: (
        /*fieldState*/
        ctx[9].disabled
      ),
      readonly: (
        /*fieldState*/
        ctx[9].readonly
      ),
      error: (
        /*fieldState*/
        ctx[9].error
      ),
      id: (
        /*fieldState*/
        ctx[9].fieldId
      ),
      placeholder: (
        /*placeholder*/
        ctx[2]
      ),
      height: (
        /*height*/
        ctx[11]
      ),
      fullScreenOffset: {
        x: (
          /*$layout*/
          ctx[13].screenXOffset
        ),
        y: (
          /*$layout*/
          ctx[13].screenYOffset
        )
      },
      easyMDEOptions: {
        hideIcons: (
          /*$context*/
          ctx[14].device.mobile ? ["side-by-side", "guide"] : []
        )
      }
    }
  });
  corerichtextfield.$on(
    "change",
    /*handleChange*/
    ctx[18]
  );
  return {
    c() {
      create_component(corerichtextfield.$$.fragment);
    },
    m(target, anchor) {
      mount_component(corerichtextfield, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const corerichtextfield_changes = {};
      if (dirty & /*fieldState*/
      512)
        corerichtextfield_changes.value = /*fieldState*/
        ctx2[9].value;
      if (dirty & /*fieldState*/
      512)
        corerichtextfield_changes.disabled = /*fieldState*/
        ctx2[9].disabled;
      if (dirty & /*fieldState*/
      512)
        corerichtextfield_changes.readonly = /*fieldState*/
        ctx2[9].readonly;
      if (dirty & /*fieldState*/
      512)
        corerichtextfield_changes.error = /*fieldState*/
        ctx2[9].error;
      if (dirty & /*fieldState*/
      512)
        corerichtextfield_changes.id = /*fieldState*/
        ctx2[9].fieldId;
      if (dirty & /*placeholder*/
      4)
        corerichtextfield_changes.placeholder = /*placeholder*/
        ctx2[2];
      if (dirty & /*height*/
      2048)
        corerichtextfield_changes.height = /*height*/
        ctx2[11];
      if (dirty & /*$layout*/
      8192)
        corerichtextfield_changes.fullScreenOffset = {
          x: (
            /*$layout*/
            ctx2[13].screenXOffset
          ),
          y: (
            /*$layout*/
            ctx2[13].screenYOffset
          )
        };
      if (dirty & /*$context*/
      16384)
        corerichtextfield_changes.easyMDEOptions = {
          hideIcons: (
            /*$context*/
            ctx2[14].device.mobile ? ["side-by-side", "guide"] : []
          )
        };
      corerichtextfield.$set(corerichtextfield_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(corerichtextfield.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(corerichtextfield.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(corerichtextfield, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*fieldState*/
    ctx[9] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*fieldState*/
        ctx2[9]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*fieldState*/
          512) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let updating_fieldSchema;
  let current;
  function field_1_fieldState_binding(value) {
    ctx[22](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[23](value);
  }
  function field_1_fieldSchema_binding(value) {
    ctx[24](value);
  }
  let field_1_props = {
    label: (
      /*label*/
      ctx[1]
    ),
    field: (
      /*field*/
      ctx[0]
    ),
    disabled: (
      /*disabled*/
      ctx[3]
    ),
    readonly: (
      /*readonly*/
      ctx[4]
    ),
    validation: (
      /*validation*/
      ctx[5]
    ),
    defaultValue: (
      /*defaultValue*/
      ctx[6]
    ),
    helpText: (
      /*helpText*/
      ctx[7]
    ),
    type: "longform",
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*fieldState*/
    ctx[9] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[9];
  }
  if (
    /*fieldApi*/
    ctx[10] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[10];
  }
  if (
    /*fieldSchema*/
    ctx[8] !== void 0
  ) {
    field_1_props.fieldSchema = /*fieldSchema*/
    ctx[8];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  binding_callbacks.push(() => bind(field_1, "fieldSchema", field_1_fieldSchema_binding));
  return {
    c() {
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const field_1_changes = {};
      if (dirty & /*label*/
      2)
        field_1_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*field*/
      1)
        field_1_changes.field = /*field*/
        ctx2[0];
      if (dirty & /*disabled*/
      8)
        field_1_changes.disabled = /*disabled*/
        ctx2[3];
      if (dirty & /*readonly*/
      16)
        field_1_changes.readonly = /*readonly*/
        ctx2[4];
      if (dirty & /*validation*/
      32)
        field_1_changes.validation = /*validation*/
        ctx2[5];
      if (dirty & /*defaultValue*/
      64)
        field_1_changes.defaultValue = /*defaultValue*/
        ctx2[6];
      if (dirty & /*helpText*/
      128)
        field_1_changes.helpText = /*helpText*/
        ctx2[7];
      if (dirty & /*$$scope, fieldState, placeholder, height, $layout, $context, useRichText*/
      67140100) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty & /*fieldState*/
      512) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[9];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty & /*fieldApi*/
      1024) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[10];
        add_flush_callback(() => updating_fieldApi = false);
      }
      if (!updating_fieldSchema && dirty & /*fieldSchema*/
      256) {
        updating_fieldSchema = true;
        field_1_changes.fieldSchema = /*fieldSchema*/
        ctx2[8];
        add_flush_callback(() => updating_fieldSchema = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field_1, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let useRichText;
  let $component;
  let $layout;
  let $context;
  let { field } = $$props;
  let { label } = $$props;
  let { placeholder } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { validation } = $$props;
  let { defaultValue = "" } = $$props;
  let { format = "auto" } = $$props;
  let { onChange } = $$props;
  let { helpText = null } = $$props;
  let fieldState;
  let fieldApi;
  let fieldSchema;
  const context = getContext("context");
  component_subscribe($$self, context, (value) => $$invalidate(14, $context = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(21, $component = value));
  const layout = getContext("layout");
  component_subscribe($$self, layout, (value) => $$invalidate(13, $layout = value));
  const newContext = writable($component);
  setContext("component", newContext);
  let height;
  const handleChange = (e) => {
    const changed = fieldApi.setValue(e.detail);
    if (onChange && changed) {
      onChange({ value: e.detail });
    }
  };
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(9, fieldState);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(10, fieldApi);
  }
  function field_1_fieldSchema_binding(value) {
    fieldSchema = value;
    $$invalidate(8, fieldSchema);
  }
  $$self.$$set = ($$props2) => {
    if ("field" in $$props2)
      $$invalidate(0, field = $$props2.field);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("placeholder" in $$props2)
      $$invalidate(2, placeholder = $$props2.placeholder);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(4, readonly = $$props2.readonly);
    if ("validation" in $$props2)
      $$invalidate(5, validation = $$props2.validation);
    if ("defaultValue" in $$props2)
      $$invalidate(6, defaultValue = $$props2.defaultValue);
    if ("format" in $$props2)
      $$invalidate(19, format = $$props2.format);
    if ("onChange" in $$props2)
      $$invalidate(20, onChange = $$props2.onChange);
    if ("helpText" in $$props2)
      $$invalidate(7, helpText = $$props2.helpText);
  };
  $$self.$$.update = () => {
    var _a, _b;
    if ($$self.$$.dirty & /*format, fieldSchema*/
    524544) {
      $$invalidate(12, useRichText = format === "rich" || format !== "plain" && (fieldSchema == null ? void 0 : fieldSchema.useRichText));
    }
    if ($$self.$$.dirty & /*$component*/
    2097152) {
      {
        $$invalidate(11, height = ((_b = (_a = $component.styles) == null ? void 0 : _a.normal) == null ? void 0 : _b.height) || "150px");
        newContext.set({
          ...$component,
          styles: {
            ...$component.styles,
            normal: {
              ...$component.styles.normal,
              height: void 0
            }
          }
        });
      }
    }
  };
  return [
    field,
    label,
    placeholder,
    disabled,
    readonly,
    validation,
    defaultValue,
    helpText,
    fieldSchema,
    fieldState,
    fieldApi,
    height,
    useRichText,
    $layout,
    $context,
    context,
    component,
    layout,
    handleChange,
    format,
    onChange,
    $component,
    field_1_fieldState_binding,
    field_1_fieldApi_binding,
    field_1_fieldSchema_binding
  ];
}
class LongFormField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      field: 0,
      label: 1,
      placeholder: 2,
      disabled: 3,
      readonly: 4,
      validation: 5,
      defaultValue: 6,
      format: 19,
      onChange: 20,
      helpText: 7
    });
  }
}
export {
  LongFormField as default
};
