import { S as SvelteComponent, i as init, s as safe_not_equal, F as create_slot, e as element, a as space, b as attr, f as insert, g as append, q as action_destroyer, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, k as transition_in, z as group_outros, n as transition_out, A as check_outros, h as is_function, o as detach, u as getContext, v as component_subscribe, U as onMount, N as ensure_array_like, y as empty, O as destroy_each, c as create_component, d as toggle_class, m as mount_component, p as destroy_component, W as binding_callbacks } from "./index-8b9900f1.js";
import Placeholder from "./Placeholder-4dedd9c4.js";
const Section_svelte_svelte_type_style_lang = "";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[16] = list[i];
  return child_ctx;
}
function create_if_block(ctx) {
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(new Array(
    /*layoutMap*/
    ctx[8][
      /*type*/
      ctx[0]
    ] - /*$component*/
    ctx[3].children
  ));
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*$builderStore, type, $component*/
      25) {
        each_value = ensure_array_like(new Array(
          /*layoutMap*/
          ctx2[8][
            /*type*/
            ctx2[0]
          ] - /*$component*/
          ctx2[3].children
        ));
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_each_block(ctx) {
  let div;
  let placeholder;
  let t;
  let current;
  placeholder = new Placeholder({});
  return {
    c() {
      div = element("div");
      create_component(placeholder.$$.fragment);
      t = space();
      attr(div, "class", "svelte-4l2zvi");
      toggle_class(
        div,
        "placeholder",
        /*$builderStore*/
        ctx[4].inBuilder
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(placeholder, div, null);
      append(div, t);
      current = true;
    },
    p(ctx2, dirty) {
      if (!current || dirty & /*$builderStore*/
      16) {
        toggle_class(
          div,
          "placeholder",
          /*$builderStore*/
          ctx2[4].inBuilder
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(placeholder.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(placeholder.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(placeholder);
    }
  };
}
function create_fragment(ctx) {
  let div;
  let t;
  let div_class_value;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[12].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[11],
    null
  );
  let if_block = (
    /*layoutMap*/
    ctx[8][
      /*type*/
      ctx[0]
    ] - /*$component*/
    ctx[3].children > 0 && create_if_block(ctx)
  );
  return {
    c() {
      div = element("div");
      if (default_slot)
        default_slot.c();
      t = space();
      if (if_block)
        if_block.c();
      attr(div, "class", div_class_value = /*type*/
      ctx[0] + " columns-" + /*columnsDependingOnSize*/
      ctx[2] + " svelte-4l2zvi");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (default_slot) {
        default_slot.m(div, null);
      }
      append(div, t);
      if (if_block)
        if_block.m(div, null);
      ctx[13](div);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[5].call(
          null,
          div,
          /*$component*/
          ctx[3].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        2048)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[11],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[11]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[11],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (
        /*layoutMap*/
        ctx2[8][
          /*type*/
          ctx2[0]
        ] - /*$component*/
        ctx2[3].children > 0
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*type, $component*/
          9) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (!current || dirty & /*type, columnsDependingOnSize*/
      5 && div_class_value !== (div_class_value = /*type*/
      ctx2[0] + " columns-" + /*columnsDependingOnSize*/
      ctx2[2] + " svelte-4l2zvi")) {
        attr(div, "class", div_class_value);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      8)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[3].styles
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (default_slot)
        default_slot.d(detaching);
      if (if_block)
        if_block.d();
      ctx[13](null);
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let columnsDependingOnSize;
  let $component;
  let $builderStore;
  let { $$slots: slots = {}, $$scope } = $$props;
  const { styleable, builderStore } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(4, $builderStore = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(3, $component = value));
  let { type = "mainSidebar" } = $$props;
  let { minSize = 250 } = $$props;
  let layoutMap = {
    mainSidebar: 2,
    sidebarMain: 2,
    oneColumn: 1,
    twoColumns: 2,
    threeColumns: 3
  };
  let container;
  let containerWidth;
  const setupResizeObserver = (element2) => {
    const resizeObserver = new ResizeObserver((entries) => {
      if (!(entries == null ? void 0 : entries[0])) {
        return;
      }
      const element3 = entries[0].target;
      $$invalidate(10, containerWidth = element3.clientWidth);
    });
    resizeObserver.observe(element2);
    return resizeObserver;
  };
  function calculateColumns(parentWidth) {
    const numberOfAllowedColumns = Math.floor(parentWidth / minSize) || 100;
    if (layoutMap[type] <= numberOfAllowedColumns) {
      return false;
    } else if (layoutMap[type] > numberOfAllowedColumns) {
      return numberOfAllowedColumns;
    }
  }
  onMount(() => {
    let resizeObserver = setupResizeObserver(container);
    return () => {
      resizeObserver.disconnect();
    };
  });
  function div_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      container = $$value;
      $$invalidate(1, container);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("type" in $$props2)
      $$invalidate(0, type = $$props2.type);
    if ("minSize" in $$props2)
      $$invalidate(9, minSize = $$props2.minSize);
    if ("$$scope" in $$props2)
      $$invalidate(11, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*containerWidth*/
    1024) {
      $$invalidate(2, columnsDependingOnSize = calculateColumns(containerWidth));
    }
  };
  return [
    type,
    container,
    columnsDependingOnSize,
    $component,
    $builderStore,
    styleable,
    builderStore,
    component,
    layoutMap,
    minSize,
    containerWidth,
    $$scope,
    slots,
    div_binding
  ];
}
class Section extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { type: 0, minSize: 9 });
  }
}
export {
  Section as default
};
