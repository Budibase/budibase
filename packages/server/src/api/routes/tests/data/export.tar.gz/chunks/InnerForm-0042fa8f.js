import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, z as group_outros, n as transition_out, A as check_outros, k as transition_in, o as detach, u as getContext, v as component_subscribe, a3 as writable, az as get_store_value, X as setContext, a2 as derived, B as noop, C as subscribe, bD as cloneDeep, c2 as deepSet, c3 as createValidatorFromConstraints, c4 as deepGet, at as uuid, F as create_slot, e as element, b as attr, q as action_destroyer, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, h as is_function, c as create_component, m as mount_component, p as destroy_component, aK as FieldType } from "./index-8b9900f1.js";
function create_else_block(ctx) {
  let div;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[29].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[30],
    null
  );
  return {
    c() {
      div = element("div");
      if (default_slot)
        default_slot.c();
      attr(
        div,
        "class",
        /*size*/
        ctx[0]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (default_slot) {
        default_slot.m(div, null);
      }
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[10].call(
          null,
          div,
          /*$component*/
          ctx[8].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty[0] & /*$$scope*/
        1073741824)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[30],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[30]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[30],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty[0] & /*size*/
      1) {
        attr(
          div,
          "class",
          /*size*/
          ctx2[0]
        );
      }
      if (styleable_action && is_function(styleable_action.update) && dirty[0] & /*$component*/
      256)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[8].styles
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block(ctx) {
  let provider;
  let current;
  provider = new /*Provider*/
  ctx[11]({
    props: {
      actions: (
        /*actions*/
        ctx[12]
      ),
      data: (
        /*dataContext*/
        ctx[3]
      ),
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(provider.$$.fragment);
    },
    m(target, anchor) {
      mount_component(provider, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const provider_changes = {};
      if (dirty[0] & /*dataContext*/
      8)
        provider_changes.data = /*dataContext*/
        ctx2[3];
      if (dirty[0] & /*$$scope, size, $component*/
      1073742081) {
        provider_changes.$$scope = { dirty, ctx: ctx2 };
      }
      provider.$set(provider_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(provider.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(provider.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(provider, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let div;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[29].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[30],
    null
  );
  return {
    c() {
      div = element("div");
      if (default_slot)
        default_slot.c();
      attr(
        div,
        "class",
        /*size*/
        ctx[0]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (default_slot) {
        default_slot.m(div, null);
      }
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[10].call(
          null,
          div,
          /*$component*/
          ctx[8].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty[0] & /*$$scope*/
        1073741824)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[30],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[30]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[30],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty[0] & /*size*/
      1) {
        attr(
          div,
          "class",
          /*size*/
          ctx2[0]
        );
      }
      if (styleable_action && is_function(styleable_action.update) && dirty[0] & /*$component*/
      256)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[8].styles
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function create_fragment(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*provideContext*/
      ctx2[1]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let values;
  let errors;
  let enrichments;
  let valid;
  let currentStepValid;
  let formValue;
  let dataContext;
  let $currentStepValid, $$unsubscribe_currentStepValid = noop, $$subscribe_currentStepValid = () => ($$unsubscribe_currentStepValid(), $$unsubscribe_currentStepValid = subscribe(currentStepValid, ($$value) => $$invalidate(24, $currentStepValid = $$value)), currentStepValid);
  let $currentStep, $$unsubscribe_currentStep = noop, $$subscribe_currentStep = () => ($$unsubscribe_currentStep(), $$unsubscribe_currentStep = subscribe(currentStep, ($$value) => $$invalidate(25, $currentStep = $$value)), currentStep);
  let $enrichments, $$unsubscribe_enrichments = noop, $$subscribe_enrichments = () => ($$unsubscribe_enrichments(), $$unsubscribe_enrichments = subscribe(enrichments, ($$value) => $$invalidate(26, $enrichments = $$value)), enrichments);
  let $values, $$unsubscribe_values = noop, $$subscribe_values = () => ($$unsubscribe_values(), $$unsubscribe_values = subscribe(values, ($$value) => $$invalidate(27, $values = $$value)), values);
  let $errors, $$unsubscribe_errors = noop, $$subscribe_errors = () => ($$unsubscribe_errors(), $$unsubscribe_errors = subscribe(errors, ($$value) => $$invalidate(28, $errors = $$value)), errors);
  let $component;
  $$self.$$.on_destroy.push(() => $$unsubscribe_currentStepValid());
  $$self.$$.on_destroy.push(() => $$unsubscribe_currentStep());
  $$self.$$.on_destroy.push(() => $$unsubscribe_enrichments());
  $$self.$$.on_destroy.push(() => $$unsubscribe_values());
  $$self.$$.on_destroy.push(() => $$unsubscribe_errors());
  let { $$slots: slots = {}, $$scope } = $$props;
  let { dataSource = void 0 } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { initialValues = void 0 } = $$props;
  let { size = void 0 } = $$props;
  let { schema = void 0 } = $$props;
  let { definition = void 0 } = $$props;
  let { disableSchemaValidation = false } = $$props;
  let { editAutoColumns = false } = $$props;
  let { provideContext = true } = $$props;
  let { currentStep } = $$props;
  $$subscribe_currentStep();
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(8, $component = value));
  const { styleable, Provider, ActionTypes } = getContext("sdk");
  let fields = [];
  const formState = writable({
    values: {},
    errors: {},
    valid: true,
    currentStep: get_store_value(currentStep)
  });
  const deriveFieldProperty = (fieldStores, getProp) => {
    return derived(fieldStores, (fieldValues) => {
      return fieldValues.reduce((map, field) => ({ ...map, [field.name]: getProp(field) }), {});
    });
  };
  const deriveBindingEnrichments = (fieldStores) => {
    return derived(fieldStores, (fieldValues) => {
      const enrichments2 = {};
      fieldValues.forEach((field) => {
        if (field.type === "attachment") {
          const value = field.fieldState.value;
          let url = null;
          if (Array.isArray(value) && value[0] != null) {
            url = value[0].url;
          }
          enrichments2[`${field.name}_first`] = url;
        }
      });
      return enrichments2;
    });
  };
  const deriveFormValue = (initialValues2, values2, enrichments2) => {
    let formValue2 = cloneDeep(initialValues2 || {});
    const sortedFields = Object.entries(values2 || {}).map(([key, value]) => {
      var _a;
      const field = getField(key);
      return {
        key,
        value,
        lastUpdate: ((_a = get_store_value(field).fieldState) == null ? void 0 : _a.lastUpdate) || 0
      };
    }).sort((a, b) => {
      return a.lastUpdate - b.lastUpdate;
    });
    sortedFields.forEach(({ key, value }) => {
      deepSet(formValue2, key, value);
    });
    Object.entries(enrichments2 || {}).forEach(([key, value]) => {
      deepSet(formValue2, key, value);
    });
    return formValue2;
  };
  const getField = (name) => {
    return fields.find((field) => get_store_value(field).name === name);
  };
  const sanitiseValue = (value, schema2, type) => {
    var _a;
    if (Array.isArray(value) && type === FieldType.ARRAY && schema2) {
      const options = ((_a = schema2 == null ? void 0 : schema2.constraints) == null ? void 0 : _a.inclusion) || [];
      const filtered = value.map((opt) => String(opt)).filter((opt) => options.includes(opt));
      return filtered;
    }
    return value;
  };
  const formApi = {
    registerField: (field, type, defaultValue = null, fieldDisabled = false, fieldReadOnly = false, validationRules, step = 1) => {
      var _a, _b, _c;
      if (!field) {
        return;
      }
      const schemaConstraints = disableSchemaValidation ? null : (_a = schema == null ? void 0 : schema[field]) == null ? void 0 : _a.constraints;
      const validator = createValidatorFromConstraints(schemaConstraints, validationRules, field, definition);
      defaultValue = sanitiseValue(defaultValue, schema == null ? void 0 : schema[field], type);
      let initialValue = deepGet(initialValues, field) ?? defaultValue;
      let initialError = null;
      let fieldId = `id-${uuid()}`;
      const existingField = getField(field);
      if (existingField) {
        const { fieldState } = get_store_value(existingField);
        fieldId = fieldState.fieldId;
        if (fieldState.value != null && fieldState.value !== "") {
          initialValue = fieldState.value;
        }
        if (fieldState.error) {
          initialError = validator == null ? void 0 : validator(initialValue);
        }
      }
      const isAutoColumn = !!((_b = schema == null ? void 0 : schema[field]) == null ? void 0 : _b.autocolumn);
      const fieldInfo = writable({
        name: field,
        type,
        step: step || 1,
        fieldState: {
          fieldId,
          value: initialValue,
          error: initialError,
          disabled: disabled || fieldDisabled || isAutoColumn && !editAutoColumns,
          readonly: readonly || fieldReadOnly || ((_c = schema == null ? void 0 : schema[field]) == null ? void 0 : _c.readonly),
          defaultValue,
          validator,
          lastUpdate: Date.now()
        },
        fieldApi: makeFieldApi(field),
        fieldSchema: (schema == null ? void 0 : schema[field]) ?? {}
      });
      if (existingField) {
        const otherFields = fields.filter((info) => get_store_value(info).name !== field);
        $$invalidate(21, fields = [...otherFields, fieldInfo]);
      } else {
        $$invalidate(21, fields = [...fields, fieldInfo]);
      }
      return fieldInfo;
    },
    validate: () => {
      const stepFields = fields.filter((field) => get_store_value(field).step === get_store_value(currentStep));
      let valid2 = true;
      let hasScrolled = false;
      stepFields.forEach((field) => {
        const fieldValid = get_store_value(field).fieldApi.validate();
        valid2 = valid2 && fieldValid;
        if (!valid2 && !hasScrolled) {
          handleScrollToField({ field: get_store_value(field) });
          hasScrolled = true;
        }
      });
      return valid2;
    },
    reset: () => {
      fields.forEach((field) => {
        get_store_value(field).fieldApi.reset();
      });
    },
    changeStep: ({ type, number }) => {
      if (type === "next") {
        currentStep.update((step) => step + 1);
      } else if (type === "prev") {
        currentStep.update((step) => Math.max(1, step - 1));
      } else if (type === "first") {
        currentStep.set(1);
      } else if (type === "specific" && number && !isNaN(number)) {
        currentStep.set(parseInt(number));
      }
    },
    setStep: (step) => {
      if (step) {
        currentStep.set(step);
      }
    },
    setFieldValue: (fieldName, value) => {
      const field = getField(fieldName);
      if (!field) {
        return;
      }
      const { fieldApi } = get_store_value(field);
      fieldApi.setValue(value);
    },
    resetField: (fieldName) => {
      const field = getField(fieldName);
      if (!field) {
        return;
      }
      const { fieldApi } = get_store_value(field);
      fieldApi.reset();
    }
  };
  const makeFieldApi = (field) => {
    const setValue = (value, skipCheck = false) => {
      const fieldInfo = getField(field);
      const { fieldState } = get_store_value(fieldInfo);
      const { validator } = fieldState;
      if (!skipCheck && fieldState.value === value) {
        return false;
      }
      const error = validator == null ? void 0 : validator(value);
      fieldInfo.update((state) => {
        state.fieldState.value = value;
        state.fieldState.error = error;
        state.fieldState.lastUpdate = Date.now();
        return state;
      });
      return true;
    };
    const reset = () => {
      const fieldInfo = getField(field);
      const { fieldState } = get_store_value(fieldInfo);
      const newValue = fieldState.defaultValue;
      fieldInfo.update((state) => {
        state.fieldState.value = newValue;
        state.fieldState.error = null;
        state.fieldState.lastUpdate = Date.now();
        return state;
      });
    };
    const deregister = () => {
      const fieldInfo = getField(field);
      fieldInfo.update((state) => {
        state.fieldState.validator = null;
        state.fieldState.error = null;
        return state;
      });
    };
    const setDisabled = (fieldDisabled) => {
      var _a;
      const fieldInfo = getField(field);
      const isAutoColumn = !!((_a = schema == null ? void 0 : schema[field]) == null ? void 0 : _a.autocolumn);
      fieldInfo.update((state) => {
        state.fieldState.disabled = disabled || fieldDisabled || isAutoColumn;
        return state;
      });
    };
    return {
      setValue,
      reset,
      setDisabled,
      deregister,
      validate: () => {
        const fieldInfo = getField(field);
        setValue(get_store_value(fieldInfo).fieldState.value, true);
        return !get_store_value(fieldInfo).fieldState.error;
      }
    };
  };
  setContext("form", {
    formState,
    formApi,
    // Datasource is needed by attachment fields to be able to upload files
    // to the correct table ID
    dataSource
  });
  setContext("form-step", writable(1));
  const handleUpdateFieldValue = ({ type, field, value }) => {
    if (type === "set") {
      formApi.setFieldValue(field, value);
    } else {
      formApi.resetField(field);
    }
  };
  const handleScrollToField = (props) => {
    let field;
    if (typeof props.field === "string") {
      field = get_store_value(getField(props.field));
    } else {
      field = props.field;
    }
    const fieldId = field.fieldState.fieldId;
    const fieldElement = document.getElementById(fieldId);
    if (fieldElement) {
      fieldElement.focus({ preventScroll: true });
    }
    const label = document.querySelector(`label[for="${fieldId}"]`);
    if (label) {
      label.style.scrollMargin = "100px";
      label.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  };
  const actions = [
    {
      type: ActionTypes.ValidateForm,
      callback: formApi.validate
    },
    {
      type: ActionTypes.ClearForm,
      callback: formApi.reset
    },
    {
      type: ActionTypes.ChangeFormStep,
      callback: formApi.changeStep
    },
    {
      type: ActionTypes.UpdateFieldValue,
      callback: handleUpdateFieldValue
    },
    {
      type: ActionTypes.ScrollTo,
      callback: handleScrollToField
    }
  ];
  $$self.$$set = ($$props2) => {
    if ("dataSource" in $$props2)
      $$invalidate(13, dataSource = $$props2.dataSource);
    if ("disabled" in $$props2)
      $$invalidate(14, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(15, readonly = $$props2.readonly);
    if ("initialValues" in $$props2)
      $$invalidate(16, initialValues = $$props2.initialValues);
    if ("size" in $$props2)
      $$invalidate(0, size = $$props2.size);
    if ("schema" in $$props2)
      $$invalidate(17, schema = $$props2.schema);
    if ("definition" in $$props2)
      $$invalidate(18, definition = $$props2.definition);
    if ("disableSchemaValidation" in $$props2)
      $$invalidate(19, disableSchemaValidation = $$props2.disableSchemaValidation);
    if ("editAutoColumns" in $$props2)
      $$invalidate(20, editAutoColumns = $$props2.editAutoColumns);
    if ("provideContext" in $$props2)
      $$invalidate(1, provideContext = $$props2.provideContext);
    if ("currentStep" in $$props2)
      $$subscribe_currentStep($$invalidate(2, currentStep = $$props2.currentStep));
    if ("$$scope" in $$props2)
      $$invalidate(30, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*fields*/
    2097152) {
      $$subscribe_values($$invalidate(7, values = deriveFieldProperty(fields, (f) => f.fieldState.value)));
    }
    if ($$self.$$.dirty[0] & /*fields*/
    2097152) {
      $$subscribe_errors($$invalidate(6, errors = deriveFieldProperty(fields, (f) => f.fieldState.error)));
    }
    if ($$self.$$.dirty[0] & /*fields*/
    2097152) {
      $$subscribe_enrichments($$invalidate(5, enrichments = deriveBindingEnrichments(fields)));
    }
    if ($$self.$$.dirty[0] & /*$errors*/
    268435456) {
      $$invalidate(22, valid = !Object.values($errors).some((error) => error != null));
    }
    if ($$self.$$.dirty[0] & /*currentStep, fields*/
    2097156) {
      $$subscribe_currentStepValid($$invalidate(4, currentStepValid = derived([currentStep, ...fields], ([currentStepValue, ...fieldsValue]) => {
        return !fieldsValue.filter((f) => f.step === currentStepValue).some((f) => f.fieldState.error != null);
      })));
    }
    if ($$self.$$.dirty[0] & /*$values, $errors, valid, $currentStep*/
    440401920) {
      {
        formState.set({
          values: $values,
          errors: $errors,
          valid,
          currentStep: $currentStep
        });
      }
    }
    if ($$self.$$.dirty[0] & /*initialValues, $values, $enrichments*/
    201392128) {
      $$invalidate(23, formValue = deriveFormValue(initialValues, $values, $enrichments));
    }
    if ($$self.$$.dirty[0] & /*formValue, valid, $currentStep, $currentStepValid*/
    62914560) {
      $$invalidate(3, dataContext = {
        ...formValue,
        // These static values are prefixed to avoid clashes with actual columns
        __value: formValue,
        __valid: valid,
        __currentStep: $currentStep,
        __currentStepValid: $currentStepValid
      });
    }
  };
  return [
    size,
    provideContext,
    currentStep,
    dataContext,
    currentStepValid,
    enrichments,
    errors,
    values,
    $component,
    component,
    styleable,
    Provider,
    actions,
    dataSource,
    disabled,
    readonly,
    initialValues,
    schema,
    definition,
    disableSchemaValidation,
    editAutoColumns,
    fields,
    valid,
    formValue,
    $currentStepValid,
    $currentStep,
    $enrichments,
    $values,
    $errors,
    slots,
    $$scope
  ];
}
class InnerForm extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        dataSource: 13,
        disabled: 14,
        readonly: 15,
        initialValues: 16,
        size: 0,
        schema: 17,
        definition: 18,
        disableSchemaValidation: 19,
        editAutoColumns: 20,
        provideContext: 1,
        currentStep: 2
      },
      null,
      [-1, -1]
    );
  }
}
export {
  InnerForm as I
};
