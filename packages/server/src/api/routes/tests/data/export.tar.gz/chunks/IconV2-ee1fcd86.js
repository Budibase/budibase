import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, z as group_outros, n as transition_out, A as check_outros, k as transition_in, o as detach, u as getContext, v as component_subscribe, e as element, c as create_component, al as set_style, m as mount_component, q as action_destroyer, h as is_function, p as destroy_component, b as attr, am as null_to_empty, d as toggle_class, l as listen, B as noop, r as run_all } from "./index-8b9900f1.js";
import Placeholder from "./Placeholder-4dedd9c4.js";
import { l as loadPhosphorIconWeight } from "./phosphorIconLoader-f5abc73c.js";
const IconV2_svelte_svelte_type_style_lang = "";
function create_if_block_1(ctx) {
  let div;
  let placeholder;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  placeholder = new Placeholder({});
  return {
    c() {
      div = element("div");
      create_component(placeholder.$$.fragment);
      set_style(
        div,
        "width",
        /*size*/
        ctx[1] + "px"
      );
      set_style(
        div,
        "height",
        /*size*/
        ctx[1] + "px"
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(placeholder, div, null);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[6].call(
          null,
          div,
          /*styles*/
          ctx[4]
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (!current || dirty & /*size*/
      2) {
        set_style(
          div,
          "width",
          /*size*/
          ctx2[1] + "px"
        );
      }
      if (!current || dirty & /*size*/
      2) {
        set_style(
          div,
          "height",
          /*size*/
          ctx2[1] + "px"
        );
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*styles*/
      16)
        styleable_action.update.call(
          null,
          /*styles*/
          ctx2[4]
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(placeholder.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(placeholder.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(placeholder);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block(ctx) {
  let i;
  let i_class_value;
  let styleable_action;
  let mounted;
  let dispose;
  return {
    c() {
      i = element("i");
      attr(i, "class", i_class_value = null_to_empty(
        /*iconClass*/
        ctx[3]
      ) + " svelte-1ghy1wa");
      set_style(
        i,
        "width",
        /*size*/
        ctx[1] + "px"
      );
      set_style(
        i,
        "height",
        /*size*/
        ctx[1] + "px"
      );
      set_style(i, "display", "inline-flex");
      set_style(i, "align-items", "center");
      set_style(i, "justify-content", "center");
      toggle_class(
        i,
        "hoverable",
        /*onClick*/
        ctx[2] != null
      );
    },
    m(target, anchor) {
      insert(target, i, anchor);
      if (!mounted) {
        dispose = [
          action_destroyer(styleable_action = /*styleable*/
          ctx[6].call(
            null,
            i,
            /*styles*/
            ctx[4]
          )),
          listen(i, "click", function() {
            if (is_function(
              /*onClick*/
              ctx[2]
            ))
              ctx[2].apply(this, arguments);
          })
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*iconClass*/
      8 && i_class_value !== (i_class_value = null_to_empty(
        /*iconClass*/
        ctx[3]
      ) + " svelte-1ghy1wa")) {
        attr(i, "class", i_class_value);
      }
      if (dirty & /*size*/
      2) {
        set_style(
          i,
          "width",
          /*size*/
          ctx[1] + "px"
        );
      }
      if (dirty & /*size*/
      2) {
        set_style(
          i,
          "height",
          /*size*/
          ctx[1] + "px"
        );
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*styles*/
      16)
        styleable_action.update.call(
          null,
          /*styles*/
          ctx[4]
        );
      if (dirty & /*iconClass, onClick*/
      12) {
        toggle_class(
          i,
          "hoverable",
          /*onClick*/
          ctx[2] != null
        );
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(i);
      }
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_fragment(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block, create_if_block_1];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*icon*/
      ctx2[0]
    )
      return 0;
    if (
      /*$builderStore*/
      ctx2[5].inBuilder
    )
      return 1;
    return -1;
  }
  if (~(current_block_type_index = select_block_type(ctx))) {
    if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  }
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].m(target, anchor);
      }
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if (~current_block_type_index) {
          if_blocks[current_block_type_index].p(ctx2, dirty);
        }
      } else {
        if (if_block) {
          group_outros();
          transition_out(if_blocks[previous_block_index], 1, 1, () => {
            if_blocks[previous_block_index] = null;
          });
          check_outros();
        }
        if (~current_block_type_index) {
          if_block = if_blocks[current_block_type_index];
          if (!if_block) {
            if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
            if_block.c();
          } else {
            if_block.p(ctx2, dirty);
          }
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        } else {
          if_block = null;
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].d(detaching);
      }
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let styles;
  let iconClass;
  let $component;
  let $builderStore;
  const { styleable, builderStore } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(5, $builderStore = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(11, $component = value));
  let { icon } = $$props;
  let { size = 24 } = $$props;
  let { weight = "regular" } = $$props;
  let { color } = $$props;
  let { onClick } = $$props;
  $$self.$$set = ($$props2) => {
    if ("icon" in $$props2)
      $$invalidate(0, icon = $$props2.icon);
    if ("size" in $$props2)
      $$invalidate(1, size = $$props2.size);
    if ("weight" in $$props2)
      $$invalidate(9, weight = $$props2.weight);
    if ("color" in $$props2)
      $$invalidate(10, color = $$props2.color);
    if ("onClick" in $$props2)
      $$invalidate(2, onClick = $$props2.onClick);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*weight, icon*/
    513) {
      if (weight && icon) {
        loadPhosphorIconWeight(weight);
      }
    }
    if ($$self.$$.dirty & /*$component, color, size*/
    3074) {
      $$invalidate(4, styles = {
        ...$component.styles,
        normal: {
          ...$component.styles.normal,
          color: color || "var(--spectrum-global-color-gray-900)",
          "font-size": `${size}px`
        }
      });
    }
    if ($$self.$$.dirty & /*icon, weight*/
    513) {
      $$invalidate(3, iconClass = icon ? (() => {
        const iconName = icon.replace(/^ph-/, "");
        if (weight === "regular") {
          return `ph ph-${iconName}`;
        } else {
          return `ph-${weight} ph-${iconName}`;
        }
      })() : "");
    }
  };
  return [
    icon,
    size,
    onClick,
    iconClass,
    styles,
    $builderStore,
    styleable,
    builderStore,
    component,
    weight,
    color,
    $component
  ];
}
class IconV2 extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      icon: 0,
      size: 1,
      weight: 9,
      color: 10,
      onClick: 2
    });
  }
}
export {
  IconV2 as default
};
