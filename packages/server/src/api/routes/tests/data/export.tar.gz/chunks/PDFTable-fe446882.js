import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, b as attr, d as toggle_class, al as set_style, f as insert, g as append, q as action_destroyer, h as is_function, B as noop, o as detach, u as getContext, v as component_subscribe, x as buildQuery, cv as stringifyRow, N as ensure_array_like, a as space, y as empty, O as destroy_each, t as text, j as set_data, C as subscribe, D as fetchData } from "./index-8b9900f1.js";
const PDFTable_svelte_svelte_type_style_lang = "";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[19] = list[i];
  return child_ctx;
}
function get_each_context_1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[22] = list[i];
  return child_ctx;
}
function get_each_context_2(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[22] = list[i];
  return child_ctx;
}
function create_if_block(ctx) {
  let t;
  let each1_anchor;
  let each_value_2 = ensure_array_like(Object.keys(
    /*schema*/
    ctx[0]
  ));
  let each_blocks_1 = [];
  for (let i = 0; i < each_value_2.length; i += 1) {
    each_blocks_1[i] = create_each_block_2(get_each_context_2(ctx, each_value_2, i));
  }
  let each_value = ensure_array_like(
    /*stringifiedRows*/
    ctx[2]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  return {
    c() {
      for (let i = 0; i < each_blocks_1.length; i += 1) {
        each_blocks_1[i].c();
      }
      t = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks_1.length; i += 1) {
        if (each_blocks_1[i]) {
          each_blocks_1[i].m(target, anchor);
        }
      }
      insert(target, t, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each1_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*schema, Object*/
      1) {
        each_value_2 = ensure_array_like(Object.keys(
          /*schema*/
          ctx2[0]
        ));
        let i;
        for (i = 0; i < each_value_2.length; i += 1) {
          const child_ctx = get_each_context_2(ctx2, each_value_2, i);
          if (each_blocks_1[i]) {
            each_blocks_1[i].p(child_ctx, dirty);
          } else {
            each_blocks_1[i] = create_each_block_2(child_ctx);
            each_blocks_1[i].c();
            each_blocks_1[i].m(t.parentNode, t);
          }
        }
        for (; i < each_blocks_1.length; i += 1) {
          each_blocks_1[i].d(1);
        }
        each_blocks_1.length = each_value_2.length;
      }
      if (dirty & /*Object, schema, stringifiedRows*/
      5) {
        each_value = ensure_array_like(
          /*stringifiedRows*/
          ctx2[2]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(each1_anchor.parentNode, each1_anchor);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(each1_anchor);
      }
      destroy_each(each_blocks_1, detaching);
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_each_block_2(ctx) {
  let div;
  let t_value = (
    /*schema*/
    ctx[0][
      /*col*/
      ctx[22]
    ].displayName + ""
  );
  let t;
  return {
    c() {
      div = element("div");
      t = text(t_value);
      attr(div, "class", "cell header svelte-y4fs9");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*schema*/
      1 && t_value !== (t_value = /*schema*/
      ctx2[0][
        /*col*/
        ctx2[22]
      ].displayName + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_each_block_1(ctx) {
  let div;
  let t_value = (
    /*row*/
    ctx[19][
      /*col*/
      ctx[22]
    ] + ""
  );
  let t;
  return {
    c() {
      div = element("div");
      t = text(t_value);
      attr(div, "class", "cell svelte-y4fs9");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*stringifiedRows, schema*/
      5 && t_value !== (t_value = /*row*/
      ctx2[19][
        /*col*/
        ctx2[22]
      ] + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_each_block(ctx) {
  let each_1_anchor;
  let each_value_1 = ensure_array_like(Object.keys(
    /*schema*/
    ctx[0]
  ));
  let each_blocks = [];
  for (let i = 0; i < each_value_1.length; i += 1) {
    each_blocks[i] = create_each_block_1(get_each_context_1(ctx, each_value_1, i));
  }
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*stringifiedRows, Object, schema*/
      5) {
        each_value_1 = ensure_array_like(Object.keys(
          /*schema*/
          ctx2[0]
        ));
        let i;
        for (i = 0; i < each_value_1.length; i += 1) {
          const child_ctx = get_each_context_1(ctx2, each_value_1, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block_1(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value_1.length;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_fragment(ctx) {
  let div1;
  let div0;
  let styleable_action;
  let mounted;
  let dispose;
  let if_block = (
    /*schema*/
    ctx[0] && create_if_block(ctx)
  );
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      if (if_block)
        if_block.c();
      attr(div0, "class", "table svelte-y4fs9");
      toggle_class(div0, "valid", !!/*schema*/
      ctx[0]);
      attr(div1, "class", "vars svelte-y4fs9");
      set_style(
        div1,
        "--cols",
        /*columnCount*/
        ctx[4]
      );
      set_style(
        div1,
        "--rows",
        /*rowCount*/
        ctx[3]
      );
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      if (if_block)
        if_block.m(div0, null);
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[7].call(
          null,
          div0,
          /*$component*/
          ctx[5].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (
        /*schema*/
        ctx2[0]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          if_block.m(div0, null);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      32)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[5].styles
        );
      if (dirty & /*schema*/
      1) {
        toggle_class(div0, "valid", !!/*schema*/
        ctx2[0]);
      }
      if (dirty & /*columnCount*/
      16) {
        set_style(
          div1,
          "--cols",
          /*columnCount*/
          ctx2[4]
        );
      }
      if (dirty & /*rowCount*/
      8) {
        set_style(
          div1,
          "--rows",
          /*rowCount*/
          ctx2[3]
        );
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if (if_block)
        if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let query;
  let fetch;
  let schema;
  let columnCount;
  let rowCount;
  let stringifiedRows;
  let $fetch, $$unsubscribe_fetch = noop, $$subscribe_fetch = () => ($$unsubscribe_fetch(), $$unsubscribe_fetch = subscribe(fetch, ($$value) => $$invalidate(15, $fetch = $$value)), fetch);
  let $component;
  $$self.$$.on_destroy.push(() => $$unsubscribe_fetch());
  let { datasource } = $$props;
  let { filter = void 0 } = $$props;
  let { sortColumn = void 0 } = $$props;
  let { sortOrder = void 0 } = $$props;
  let { columns = void 0 } = $$props;
  let { limit = 20 } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(5, $component = value));
  const { styleable, API } = getContext("sdk");
  const createFetch = (datasource2) => {
    return fetchData({
      API,
      datasource: datasource2,
      options: {
        query,
        sortColumn,
        sortOrder,
        limit,
        paginate: false
      }
    });
  };
  const sanitizeSchema = (schema2, columns2) => {
    if (!schema2) {
      return {};
    }
    let sanitized = {};
    Object.entries(schema2).forEach(([field, fieldSchema]) => {
      if (fieldSchema.visible !== false) {
        sanitized[field] = { ...fieldSchema, displayName: field };
      }
    });
    if (!(columns2 == null ? void 0 : columns2.length)) {
      columns2 = Object.values(sanitized).slice(0, 3);
    }
    let pruned = {};
    for (let col of columns2) {
      if (sanitized[col.name]) {
        pruned[col.name] = {
          ...sanitized[col.name],
          displayName: col.displayName || sanitized[col.name].displayName
        };
      }
    }
    sanitized = pruned;
    return sanitized;
  };
  $$self.$$set = ($$props2) => {
    if ("datasource" in $$props2)
      $$invalidate(8, datasource = $$props2.datasource);
    if ("filter" in $$props2)
      $$invalidate(9, filter = $$props2.filter);
    if ("sortColumn" in $$props2)
      $$invalidate(10, sortColumn = $$props2.sortColumn);
    if ("sortOrder" in $$props2)
      $$invalidate(11, sortOrder = $$props2.sortOrder);
    if ("columns" in $$props2)
      $$invalidate(12, columns = $$props2.columns);
    if ("limit" in $$props2)
      $$invalidate(13, limit = $$props2.limit);
  };
  $$self.$$.update = () => {
    var _a;
    if ($$self.$$.dirty & /*filter*/
    512) {
      $$invalidate(14, query = buildQuery(filter));
    }
    if ($$self.$$.dirty & /*datasource*/
    256) {
      $$subscribe_fetch($$invalidate(1, fetch = createFetch(datasource)));
    }
    if ($$self.$$.dirty & /*fetch, query, sortColumn, sortOrder, limit*/
    27650) {
      fetch.update({ query, sortColumn, sortOrder, limit });
    }
    if ($$self.$$.dirty & /*$fetch, columns*/
    36864) {
      $$invalidate(0, schema = sanitizeSchema($fetch.schema, columns));
    }
    if ($$self.$$.dirty & /*schema*/
    1) {
      $$invalidate(4, columnCount = Object.keys(schema).length);
    }
    if ($$self.$$.dirty & /*$fetch*/
    32768) {
      $$invalidate(3, rowCount = ((_a = $fetch.rows) == null ? void 0 : _a.length) || 0);
    }
    if ($$self.$$.dirty & /*$fetch, schema*/
    32769) {
      $$invalidate(2, stringifiedRows = (($fetch == null ? void 0 : $fetch.rows) || []).map((row) => stringifyRow(row, schema)));
    }
  };
  return [
    schema,
    fetch,
    stringifiedRows,
    rowCount,
    columnCount,
    $component,
    component,
    styleable,
    datasource,
    filter,
    sortColumn,
    sortOrder,
    columns,
    limit,
    query,
    $fetch
  ];
}
class PDFTable extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      datasource: 8,
      filter: 9,
      sortColumn: 10,
      sortOrder: 11,
      columns: 12,
      limit: 13
    });
  }
}
export {
  PDFTable as default
};
