import { S as SvelteComponent, i as init, s as safe_not_equal, ap as Button, W as binding_callbacks, a0 as bind, $ as Popover, c as create_component, a as space, m as mount_component, f as insert, a1 as add_flush_callback, k as transition_in, n as transition_out, o as detach, p as destroy_component, t as text, j as set_data, V as bubble, N as ensure_array_like, y as empty, z as group_outros, A as check_outros, O as destroy_each } from "./index-8b9900f1.js";
import { M as Menu, I as Item } from "./Item-43bbcac6.js";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[19] = list[i];
  return child_ctx;
}
function create_default_slot_3(ctx) {
  let t_value = (
    /*text*/
    (ctx[1] || "Action") + ""
  );
  let t;
  return {
    c() {
      t = text(t_value);
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*text*/
      2 && t_value !== (t_value = /*text*/
      (ctx2[1] || "Action") + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_2(ctx) {
  let t0_value = (
    /*button*/
    (ctx[19].text || "Button") + ""
  );
  let t0;
  let t1;
  return {
    c() {
      t0 = text(t0_value);
      t1 = space();
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*buttons*/
      1 && t0_value !== (t0_value = /*button*/
      (ctx2[19].text || "Button") + ""))
        set_data(t0, t0_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
    }
  };
}
function create_each_block(ctx) {
  let menuitem;
  let current;
  function click_handler_2() {
    return (
      /*click_handler_2*/
      ctx[13](
        /*button*/
        ctx[19]
      )
    );
  }
  menuitem = new Item({
    props: {
      disabled: (
        /*button*/
        ctx[19].disabled
      ),
      $$slots: { default: [create_default_slot_2] },
      $$scope: { ctx }
    }
  });
  menuitem.$on("click", click_handler_2);
  return {
    c() {
      create_component(menuitem.$$.fragment);
    },
    m(target, anchor) {
      mount_component(menuitem, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const menuitem_changes = {};
      if (dirty & /*buttons*/
      1)
        menuitem_changes.disabled = /*button*/
        ctx[19].disabled;
      if (dirty & /*$$scope, buttons*/
      4194305) {
        menuitem_changes.$$scope = { dirty, ctx };
      }
      menuitem.$set(menuitem_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(menuitem.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(menuitem.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(menuitem, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(
    /*buttons*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*buttons, handleClick*/
      513) {
        each_value = ensure_array_like(
          /*buttons*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let menu;
  let current;
  menu = new Menu({
    props: {
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(menu.$$.fragment);
    },
    m(target, anchor) {
      mount_component(menu, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const menu_changes = {};
      if (dirty & /*$$scope, buttons*/
      4194305) {
        menu_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menu.$set(menu_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(menu.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(menu.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(menu, detaching);
    }
  };
}
function create_fragment(ctx) {
  let button_1;
  let updating_ref;
  let t;
  let popover_1;
  let current;
  function button_1_ref_binding(value) {
    ctx[10](value);
  }
  let button_1_props = {
    size: (
      /*size*/
      ctx[2]
    ),
    icon: "caret-down",
    quiet: (
      /*quiet*/
      ctx[6]
    ),
    primary: (
      /*quiet*/
      ctx[6]
    ),
    cta: !/*quiet*/
    ctx[6],
    newStyles: !/*quiet*/
    ctx[6],
    reverse: true,
    $$slots: { default: [create_default_slot_3] },
    $$scope: { ctx }
  };
  if (
    /*anchor*/
    ctx[7] !== void 0
  ) {
    button_1_props.ref = /*anchor*/
    ctx[7];
  }
  button_1 = new Button({ props: button_1_props });
  binding_callbacks.push(() => bind(button_1, "ref", button_1_ref_binding));
  button_1.$on(
    "click",
    /*click_handler_1*/
    ctx[11]
  );
  button_1.$on(
    "click",
    /*click_handler*/
    ctx[12]
  );
  let popover_1_props = {
    align: (
      /*align*/
      ctx[3]
    ),
    anchor: (
      /*anchor*/
      ctx[7]
    ),
    offset: (
      /*offset*/
      ctx[4]
    ),
    animate: (
      /*animate*/
      ctx[5]
    ),
    resizable: false,
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  popover_1 = new Popover({ props: popover_1_props });
  ctx[14](popover_1);
  popover_1.$on(
    "close",
    /*close_handler*/
    ctx[15]
  );
  popover_1.$on(
    "open",
    /*open_handler*/
    ctx[16]
  );
  popover_1.$on(
    "mouseenter",
    /*mouseenter_handler*/
    ctx[17]
  );
  popover_1.$on(
    "mouseleave",
    /*mouseleave_handler*/
    ctx[18]
  );
  return {
    c() {
      create_component(button_1.$$.fragment);
      t = space();
      create_component(popover_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(button_1, target, anchor);
      insert(target, t, anchor);
      mount_component(popover_1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const button_1_changes = {};
      if (dirty & /*size*/
      4)
        button_1_changes.size = /*size*/
        ctx2[2];
      if (dirty & /*quiet*/
      64)
        button_1_changes.quiet = /*quiet*/
        ctx2[6];
      if (dirty & /*quiet*/
      64)
        button_1_changes.primary = /*quiet*/
        ctx2[6];
      if (dirty & /*quiet*/
      64)
        button_1_changes.cta = !/*quiet*/
        ctx2[6];
      if (dirty & /*quiet*/
      64)
        button_1_changes.newStyles = !/*quiet*/
        ctx2[6];
      if (dirty & /*$$scope, text*/
      4194306) {
        button_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_ref && dirty & /*anchor*/
      128) {
        updating_ref = true;
        button_1_changes.ref = /*anchor*/
        ctx2[7];
        add_flush_callback(() => updating_ref = false);
      }
      button_1.$set(button_1_changes);
      const popover_1_changes = {};
      if (dirty & /*align*/
      8)
        popover_1_changes.align = /*align*/
        ctx2[3];
      if (dirty & /*anchor*/
      128)
        popover_1_changes.anchor = /*anchor*/
        ctx2[7];
      if (dirty & /*offset*/
      16)
        popover_1_changes.offset = /*offset*/
        ctx2[4];
      if (dirty & /*animate*/
      32)
        popover_1_changes.animate = /*animate*/
        ctx2[5];
      if (dirty & /*$$scope, buttons*/
      4194305) {
        popover_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      popover_1.$set(popover_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(button_1.$$.fragment, local);
      transition_in(popover_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(button_1.$$.fragment, local);
      transition_out(popover_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(button_1, detaching);
      ctx[14](null);
      destroy_component(popover_1, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { buttons } = $$props;
  let { text: text2 = "Action" } = $$props;
  let { size = "M" } = $$props;
  let { align = "left" } = $$props;
  let { offset } = $$props;
  let { animate } = $$props;
  let { quiet = false } = $$props;
  let anchor;
  let popover;
  const handleClick = async (button) => {
    var _a;
    popover.hide();
    await ((_a = button.onClick) == null ? void 0 : _a.call(button));
  };
  function button_1_ref_binding(value) {
    anchor = value;
    $$invalidate(7, anchor);
  }
  const click_handler_1 = () => popover == null ? void 0 : popover.show();
  function click_handler(event) {
    bubble.call(this, $$self, event);
  }
  const click_handler_2 = (button) => handleClick(button);
  function popover_1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      popover = $$value;
      $$invalidate(8, popover);
    });
  }
  function close_handler(event) {
    bubble.call(this, $$self, event);
  }
  function open_handler(event) {
    bubble.call(this, $$self, event);
  }
  function mouseenter_handler(event) {
    bubble.call(this, $$self, event);
  }
  function mouseleave_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("buttons" in $$props2)
      $$invalidate(0, buttons = $$props2.buttons);
    if ("text" in $$props2)
      $$invalidate(1, text2 = $$props2.text);
    if ("size" in $$props2)
      $$invalidate(2, size = $$props2.size);
    if ("align" in $$props2)
      $$invalidate(3, align = $$props2.align);
    if ("offset" in $$props2)
      $$invalidate(4, offset = $$props2.offset);
    if ("animate" in $$props2)
      $$invalidate(5, animate = $$props2.animate);
    if ("quiet" in $$props2)
      $$invalidate(6, quiet = $$props2.quiet);
  };
  return [
    buttons,
    text2,
    size,
    align,
    offset,
    animate,
    quiet,
    anchor,
    popover,
    handleClick,
    button_1_ref_binding,
    click_handler_1,
    click_handler,
    click_handler_2,
    popover_1_binding,
    close_handler,
    open_handler,
    mouseenter_handler,
    mouseleave_handler
  ];
}
class CollapsedButtonGroup extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      buttons: 0,
      text: 1,
      size: 2,
      align: 3,
      offset: 4,
      animate: 5,
      quiet: 6
    });
  }
}
export {
  CollapsedButtonGroup as C
};
