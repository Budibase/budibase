import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, k as transition_in, z as group_outros, n as transition_out, A as check_outros, o as detach, u as getContext, v as component_subscribe, a3 as writable, cm as hashString, B as noop, c as create_component, m as mount_component, p as destroy_component, F as create_slot, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes } from "./index-a0738cd3.js";
import { I as InnerForm } from "./InnerForm-c723d600.js";
function create_if_block(ctx) {
  let previous_key = (
    /*resetKey*/
    ctx[10]
  );
  let key_block_anchor;
  let current;
  let key_block = create_key_block(ctx);
  return {
    c() {
      key_block.c();
      key_block_anchor = empty();
    },
    m(target, anchor) {
      key_block.m(target, anchor);
      insert(target, key_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*resetKey*/
      1024 && safe_not_equal(previous_key, previous_key = /*resetKey*/
      ctx2[10])) {
        group_outros();
        transition_out(key_block, 1, 1, noop);
        check_outros();
        key_block = create_key_block(ctx2);
        key_block.c();
        transition_in(key_block, 1);
        key_block.m(key_block_anchor.parentNode, key_block_anchor);
      } else {
        key_block.p(ctx2, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(key_block);
      current = true;
    },
    o(local) {
      transition_out(key_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(key_block_anchor);
      }
      key_block.d(detaching);
    }
  };
}
function create_default_slot(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[19].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[20],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        1048576)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[20],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[20]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[20],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_key_block(ctx) {
  let innerform;
  let current;
  innerform = new InnerForm({
    props: {
      dataSource: (
        /*dataSource*/
        ctx[0]
      ),
      size: (
        /*size*/
        ctx[1]
      ),
      disabled: (
        /*disabled*/
        ctx[2]
      ),
      readonly: (
        /*readonly*/
        ctx[3]
      ),
      schema: (
        /*schema*/
        ctx[6]
      ),
      definition: (
        /*definition*/
        ctx[8]
      ),
      initialValues: (
        /*initialValues*/
        ctx[7]
      ),
      disableSchemaValidation: (
        /*disableSchemaValidation*/
        ctx[4]
      ),
      editAutoColumns: (
        /*editAutoColumns*/
        ctx[5]
      ),
      currentStep: (
        /*currentStep*/
        ctx[13]
      ),
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(innerform.$$.fragment);
    },
    m(target, anchor) {
      mount_component(innerform, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const innerform_changes = {};
      if (dirty & /*dataSource*/
      1)
        innerform_changes.dataSource = /*dataSource*/
        ctx2[0];
      if (dirty & /*size*/
      2)
        innerform_changes.size = /*size*/
        ctx2[1];
      if (dirty & /*disabled*/
      4)
        innerform_changes.disabled = /*disabled*/
        ctx2[2];
      if (dirty & /*readonly*/
      8)
        innerform_changes.readonly = /*readonly*/
        ctx2[3];
      if (dirty & /*schema*/
      64)
        innerform_changes.schema = /*schema*/
        ctx2[6];
      if (dirty & /*definition*/
      256)
        innerform_changes.definition = /*definition*/
        ctx2[8];
      if (dirty & /*initialValues*/
      128)
        innerform_changes.initialValues = /*initialValues*/
        ctx2[7];
      if (dirty & /*disableSchemaValidation*/
      16)
        innerform_changes.disableSchemaValidation = /*disableSchemaValidation*/
        ctx2[4];
      if (dirty & /*editAutoColumns*/
      32)
        innerform_changes.editAutoColumns = /*editAutoColumns*/
        ctx2[5];
      if (dirty & /*$$scope*/
      1048576) {
        innerform_changes.$$scope = { dirty, ctx: ctx2 };
      }
      innerform.$set(innerform_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(innerform.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(innerform.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(innerform, detaching);
    }
  };
}
function create_fragment(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*loaded*/
    ctx[9] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (
        /*loaded*/
        ctx2[9]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*loaded*/
          512) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let schemaKey;
  let initialValues;
  let resetKey;
  let $context;
  let $component;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { dataSource } = $$props;
  let { size } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { actionType = "Create" } = $$props;
  let { initialFormStep = 1 } = $$props;
  let { disableSchemaValidation = false } = $$props;
  let { editAutoColumns = false } = $$props;
  const context = getContext("context");
  component_subscribe($$self, context, (value) => $$invalidate(17, $context = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(18, $component = value));
  const { fetchDatasourceSchema, fetchDatasourceDefinition } = getContext("sdk");
  const getInitialFormStep = () => {
    const parsedFormStep = parseInt(initialFormStep.toString());
    if (isNaN(parsedFormStep)) {
      return 1;
    }
    return parsedFormStep;
  };
  let definition;
  let schema;
  let loaded = false;
  let currentStep = getContext("current-step") || writable(getInitialFormStep());
  const getInitialValues = (type, dataSource2, path, context2) => {
    var _a, _b;
    if (type !== "Update") {
      return {};
    }
    const dsType = dataSource2 == null ? void 0 : dataSource2.type;
    if (dsType !== "table" && dsType !== "viewV2") {
      return {};
    }
    for (let id of path.toReversed().slice(1)) {
      if (dataSource2.type === "viewV2" && ((_a = context2[id]) == null ? void 0 : _a._viewId) === dataSource2.id) {
        return context2[id];
      }
      if (dataSource2.type === "table" && ((_b = context2[id]) == null ? void 0 : _b.tableId) === dataSource2.tableId) {
        return context2[id];
      }
    }
    return {};
  };
  const fetchSchema = async (dataSource2) => {
    try {
      $$invalidate(8, definition = await fetchDatasourceDefinition(dataSource2));
    } catch (error) {
      $$invalidate(8, definition = void 0);
    }
    const res = await fetchDatasourceSchema(dataSource2);
    $$invalidate(6, schema = res || {});
    if (!loaded) {
      $$invalidate(9, loaded = true);
    }
  };
  const generateSchemaKey = (schema2) => {
    if (!schema2) {
      return null;
    }
    const fields = Object.keys(schema2);
    fields.sort();
    return fields.map((field) => `${field}:${schema2[field].type}`).join("-");
  };
  $$self.$$set = ($$props2) => {
    if ("dataSource" in $$props2)
      $$invalidate(0, dataSource = $$props2.dataSource);
    if ("size" in $$props2)
      $$invalidate(1, size = $$props2.size);
    if ("disabled" in $$props2)
      $$invalidate(2, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(3, readonly = $$props2.readonly);
    if ("actionType" in $$props2)
      $$invalidate(14, actionType = $$props2.actionType);
    if ("initialFormStep" in $$props2)
      $$invalidate(15, initialFormStep = $$props2.initialFormStep);
    if ("disableSchemaValidation" in $$props2)
      $$invalidate(4, disableSchemaValidation = $$props2.disableSchemaValidation);
    if ("editAutoColumns" in $$props2)
      $$invalidate(5, editAutoColumns = $$props2.editAutoColumns);
    if ("$$scope" in $$props2)
      $$invalidate(20, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*dataSource*/
    1) {
      fetchSchema(dataSource);
    }
    if ($$self.$$.dirty & /*schema*/
    64) {
      $$invalidate(16, schemaKey = generateSchemaKey(schema));
    }
    if ($$self.$$.dirty & /*actionType, dataSource, $component, $context*/
    409601) {
      $$invalidate(7, initialValues = getInitialValues(actionType, dataSource, $component.path, $context));
    }
    if ($$self.$$.dirty & /*schemaKey, initialValues, disabled, readonly*/
    65676) {
      $$invalidate(10, resetKey = hashString(schemaKey + JSON.stringify(initialValues) + disabled + readonly));
    }
  };
  return [
    dataSource,
    size,
    disabled,
    readonly,
    disableSchemaValidation,
    editAutoColumns,
    schema,
    initialValues,
    definition,
    loaded,
    resetKey,
    context,
    component,
    currentStep,
    actionType,
    initialFormStep,
    schemaKey,
    $context,
    $component,
    slots,
    $$scope
  ];
}
class Form extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      dataSource: 0,
      size: 1,
      disabled: 2,
      readonly: 3,
      actionType: 14,
      initialFormStep: 15,
      disableSchemaValidation: 4,
      editAutoColumns: 5
    });
  }
}
export {
  Form as default
};
