import { S as SvelteComponent, i as init, s as safe_not_equal, K as Block, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component, M as BlockComponent, W as binding_callbacks, a0 as bind, a1 as add_flush_callback, y as empty, f as insert, z as group_outros, A as check_outros, o as detach, bV as makePropSafe } from "./index-a0738cd3.js";
function create_if_block(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: (
        /*chartType*/
        ctx[6]
      ),
      props: {
        dataProvider: `{{ literal ${makePropSafe(
          /*dataProviderId*/
          ctx[36]
        )} }}`,
        height: (
          /*height*/
          ctx[18]
        ),
        width: (
          /*width*/
          ctx[19]
        ),
        title: (
          /*chartTitle*/
          ctx[5]
        ),
        labelColumn: (
          /*labelColumn*/
          ctx[14]
        ),
        valueColumn: (
          /*valueColumn*/
          ctx[20]
        ),
        valueColumns: (
          /*valueColumns*/
          ctx[23]
        ),
        palette: (
          /*palette*/
          ctx[8]
        ),
        dataLabels: (
          /*dataLabels*/
          ctx[17]
        ),
        legend: (
          /*legend*/
          ctx[15]
        ),
        animate: (
          /*animate*/
          ctx[16]
        ),
        valueUnits: (
          /*valueUnits*/
          ctx[24]
        ),
        yAxisLabel: (
          /*yAxisLabel*/
          ctx[25]
        ),
        xAxisLabel: (
          /*xAxisLabel*/
          ctx[26]
        ),
        yAxisUnits: (
          /*yAxisUnits*/
          ctx[27]
        ),
        stacked: (
          /*stacked*/
          ctx[21]
        ),
        horizontal: (
          /*horizontal*/
          ctx[22]
        ),
        curve: (
          /*curve*/
          ctx[28]
        ),
        gradient: (
          /*gradient*/
          ctx[29]
        ),
        //issue?
        closeColumn: (
          /*closeColumn*/
          ctx[30]
        ),
        openColumn: (
          /*openColumn*/
          ctx[31]
        ),
        highColumn: (
          /*highColumn*/
          ctx[32]
        ),
        lowColumn: (
          /*lowColumn*/
          ctx[33]
        ),
        dateColumn: (
          /*dateColumn*/
          ctx[34]
        ),
        bucketCount: (
          /*bucketCount*/
          ctx[35]
        ),
        c1: (
          /*c1*/
          ctx[9]
        ),
        c2: (
          /*c2*/
          ctx[10]
        ),
        c3: (
          /*c3*/
          ctx[11]
        ),
        c4: (
          /*c4*/
          ctx[12]
        ),
        c5: (
          /*c5*/
          ctx[13]
        )
      }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*chartType*/
      64)
        blockcomponent_changes.type = /*chartType*/
        ctx2[6];
      if (dirty[0] & /*height, width, chartTitle, labelColumn, valueColumn, valueColumns, palette, dataLabels, legend, animate, valueUnits, yAxisLabel, xAxisLabel, yAxisUnits, stacked, horizontal, curve, gradient, closeColumn, c1, c2, c3, c4, c5*/
      2147483424 | dirty[1] & /*dataProviderId, openColumn, highColumn, lowColumn, dateColumn, bucketCount*/
      63)
        blockcomponent_changes.props = {
          dataProvider: `{{ literal ${makePropSafe(
            /*dataProviderId*/
            ctx2[36]
          )} }}`,
          height: (
            /*height*/
            ctx2[18]
          ),
          width: (
            /*width*/
            ctx2[19]
          ),
          title: (
            /*chartTitle*/
            ctx2[5]
          ),
          labelColumn: (
            /*labelColumn*/
            ctx2[14]
          ),
          valueColumn: (
            /*valueColumn*/
            ctx2[20]
          ),
          valueColumns: (
            /*valueColumns*/
            ctx2[23]
          ),
          palette: (
            /*palette*/
            ctx2[8]
          ),
          dataLabels: (
            /*dataLabels*/
            ctx2[17]
          ),
          legend: (
            /*legend*/
            ctx2[15]
          ),
          animate: (
            /*animate*/
            ctx2[16]
          ),
          valueUnits: (
            /*valueUnits*/
            ctx2[24]
          ),
          yAxisLabel: (
            /*yAxisLabel*/
            ctx2[25]
          ),
          xAxisLabel: (
            /*xAxisLabel*/
            ctx2[26]
          ),
          yAxisUnits: (
            /*yAxisUnits*/
            ctx2[27]
          ),
          stacked: (
            /*stacked*/
            ctx2[21]
          ),
          horizontal: (
            /*horizontal*/
            ctx2[22]
          ),
          curve: (
            /*curve*/
            ctx2[28]
          ),
          gradient: (
            /*gradient*/
            ctx2[29]
          ),
          //issue?
          closeColumn: (
            /*closeColumn*/
            ctx2[30]
          ),
          openColumn: (
            /*openColumn*/
            ctx2[31]
          ),
          highColumn: (
            /*highColumn*/
            ctx2[32]
          ),
          lowColumn: (
            /*lowColumn*/
            ctx2[33]
          ),
          dateColumn: (
            /*dateColumn*/
            ctx2[34]
          ),
          bucketCount: (
            /*bucketCount*/
            ctx2[35]
          ),
          c1: (
            /*c1*/
            ctx2[9]
          ),
          c2: (
            /*c2*/
            ctx2[10]
          ),
          c3: (
            /*c3*/
            ctx2[11]
          ),
          c4: (
            /*c4*/
            ctx2[12]
          ),
          c5: (
            /*c5*/
            ctx2[13]
          )
        };
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*dataProviderId*/
    ctx[36] && /*chartType*/
    ctx[6] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*dataProviderId*/
        ctx2[36] && /*chartType*/
        ctx2[6]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*chartType*/
          64 | dirty[1] & /*dataProviderId*/
          32) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_default_slot(ctx) {
  let blockcomponent;
  let updating_id;
  let current;
  function blockcomponent_id_binding(value) {
    ctx[37](value);
  }
  let blockcomponent_props = {
    type: "dataprovider",
    context: "provider",
    props: {
      dataSource: (
        /*dataSource*/
        ctx[7]
      ),
      filter: (
        /*filter*/
        ctx[0]
      ),
      sortColumn: (
        /*sortColumn*/
        ctx[1]
      ),
      sortOrder: (
        /*sortOrder*/
        ctx[2]
      ),
      limit: (
        /*limit*/
        ctx[3]
      ),
      autoRefresh: (
        /*autoRefresh*/
        ctx[4]
      )
    },
    $$slots: { default: [create_default_slot_1] },
    $$scope: { ctx }
  };
  if (
    /*dataProviderId*/
    ctx[36] !== void 0
  ) {
    blockcomponent_props.id = /*dataProviderId*/
    ctx[36];
  }
  blockcomponent = new BlockComponent({ props: blockcomponent_props });
  binding_callbacks.push(() => bind(blockcomponent, "id", blockcomponent_id_binding));
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*dataSource, filter, sortColumn, sortOrder, limit, autoRefresh*/
      159)
        blockcomponent_changes.props = {
          dataSource: (
            /*dataSource*/
            ctx2[7]
          ),
          filter: (
            /*filter*/
            ctx2[0]
          ),
          sortColumn: (
            /*sortColumn*/
            ctx2[1]
          ),
          sortOrder: (
            /*sortOrder*/
            ctx2[2]
          ),
          limit: (
            /*limit*/
            ctx2[3]
          ),
          autoRefresh: (
            /*autoRefresh*/
            ctx2[4]
          )
        };
      if (dirty[0] & /*chartType, height, width, chartTitle, labelColumn, valueColumn, valueColumns, palette, dataLabels, legend, animate, valueUnits, yAxisLabel, xAxisLabel, yAxisUnits, stacked, horizontal, curve, gradient, closeColumn, c1, c2, c3, c4, c5*/
      2147483488 | dirty[1] & /*$$scope, dataProviderId, openColumn, highColumn, lowColumn, dateColumn, bucketCount*/
      191) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_id && dirty[1] & /*dataProviderId*/
      32) {
        updating_id = true;
        blockcomponent_changes.id = /*dataProviderId*/
        ctx2[36];
        add_flush_callback(() => updating_id = false);
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_fragment(ctx) {
  let block;
  let current;
  block = new Block({
    props: {
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(block.$$.fragment);
    },
    m(target, anchor) {
      mount_component(block, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const block_changes = {};
      if (dirty[0] & /*dataSource, filter, sortColumn, sortOrder, limit, autoRefresh, chartType, height, width, chartTitle, labelColumn, valueColumn, valueColumns, palette, dataLabels, legend, animate, valueUnits, yAxisLabel, xAxisLabel, yAxisUnits, stacked, horizontal, curve, gradient, closeColumn, c1, c2, c3, c4, c5*/
      2147483647 | dirty[1] & /*$$scope, dataProviderId, openColumn, highColumn, lowColumn, dateColumn, bucketCount*/
      191) {
        block_changes.$$scope = { dirty, ctx: ctx2 };
      }
      block.$set(block_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(block.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(block.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(block, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { filter } = $$props;
  let { sortColumn } = $$props;
  let { sortOrder } = $$props;
  let { limit } = $$props;
  let { autoRefresh } = $$props;
  let { chartTitle } = $$props;
  let { chartType } = $$props;
  let { dataSource } = $$props;
  let { palette } = $$props;
  let { c1, c2, c3, c4, c5 } = $$props;
  let { labelColumn } = $$props;
  let { legend } = $$props;
  let { animate } = $$props;
  let { dataLabels } = $$props;
  let { height } = $$props;
  let { width } = $$props;
  let { valueColumn } = $$props;
  let { stacked } = $$props;
  let { horizontal } = $$props;
  let { valueColumns } = $$props;
  let { valueUnits } = $$props;
  let { yAxisLabel } = $$props;
  let { xAxisLabel } = $$props;
  let { yAxisUnits } = $$props;
  let { curve } = $$props;
  let { gradient } = $$props;
  let { closeColumn } = $$props;
  let { openColumn } = $$props;
  let { highColumn } = $$props;
  let { lowColumn } = $$props;
  let { dateColumn } = $$props;
  let { bucketCount } = $$props;
  let dataProviderId;
  function blockcomponent_id_binding(value) {
    dataProviderId = value;
    $$invalidate(36, dataProviderId);
  }
  $$self.$$set = ($$props2) => {
    if ("filter" in $$props2)
      $$invalidate(0, filter = $$props2.filter);
    if ("sortColumn" in $$props2)
      $$invalidate(1, sortColumn = $$props2.sortColumn);
    if ("sortOrder" in $$props2)
      $$invalidate(2, sortOrder = $$props2.sortOrder);
    if ("limit" in $$props2)
      $$invalidate(3, limit = $$props2.limit);
    if ("autoRefresh" in $$props2)
      $$invalidate(4, autoRefresh = $$props2.autoRefresh);
    if ("chartTitle" in $$props2)
      $$invalidate(5, chartTitle = $$props2.chartTitle);
    if ("chartType" in $$props2)
      $$invalidate(6, chartType = $$props2.chartType);
    if ("dataSource" in $$props2)
      $$invalidate(7, dataSource = $$props2.dataSource);
    if ("palette" in $$props2)
      $$invalidate(8, palette = $$props2.palette);
    if ("c1" in $$props2)
      $$invalidate(9, c1 = $$props2.c1);
    if ("c2" in $$props2)
      $$invalidate(10, c2 = $$props2.c2);
    if ("c3" in $$props2)
      $$invalidate(11, c3 = $$props2.c3);
    if ("c4" in $$props2)
      $$invalidate(12, c4 = $$props2.c4);
    if ("c5" in $$props2)
      $$invalidate(13, c5 = $$props2.c5);
    if ("labelColumn" in $$props2)
      $$invalidate(14, labelColumn = $$props2.labelColumn);
    if ("legend" in $$props2)
      $$invalidate(15, legend = $$props2.legend);
    if ("animate" in $$props2)
      $$invalidate(16, animate = $$props2.animate);
    if ("dataLabels" in $$props2)
      $$invalidate(17, dataLabels = $$props2.dataLabels);
    if ("height" in $$props2)
      $$invalidate(18, height = $$props2.height);
    if ("width" in $$props2)
      $$invalidate(19, width = $$props2.width);
    if ("valueColumn" in $$props2)
      $$invalidate(20, valueColumn = $$props2.valueColumn);
    if ("stacked" in $$props2)
      $$invalidate(21, stacked = $$props2.stacked);
    if ("horizontal" in $$props2)
      $$invalidate(22, horizontal = $$props2.horizontal);
    if ("valueColumns" in $$props2)
      $$invalidate(23, valueColumns = $$props2.valueColumns);
    if ("valueUnits" in $$props2)
      $$invalidate(24, valueUnits = $$props2.valueUnits);
    if ("yAxisLabel" in $$props2)
      $$invalidate(25, yAxisLabel = $$props2.yAxisLabel);
    if ("xAxisLabel" in $$props2)
      $$invalidate(26, xAxisLabel = $$props2.xAxisLabel);
    if ("yAxisUnits" in $$props2)
      $$invalidate(27, yAxisUnits = $$props2.yAxisUnits);
    if ("curve" in $$props2)
      $$invalidate(28, curve = $$props2.curve);
    if ("gradient" in $$props2)
      $$invalidate(29, gradient = $$props2.gradient);
    if ("closeColumn" in $$props2)
      $$invalidate(30, closeColumn = $$props2.closeColumn);
    if ("openColumn" in $$props2)
      $$invalidate(31, openColumn = $$props2.openColumn);
    if ("highColumn" in $$props2)
      $$invalidate(32, highColumn = $$props2.highColumn);
    if ("lowColumn" in $$props2)
      $$invalidate(33, lowColumn = $$props2.lowColumn);
    if ("dateColumn" in $$props2)
      $$invalidate(34, dateColumn = $$props2.dateColumn);
    if ("bucketCount" in $$props2)
      $$invalidate(35, bucketCount = $$props2.bucketCount);
  };
  return [
    filter,
    sortColumn,
    sortOrder,
    limit,
    autoRefresh,
    chartTitle,
    chartType,
    dataSource,
    palette,
    c1,
    c2,
    c3,
    c4,
    c5,
    labelColumn,
    legend,
    animate,
    dataLabels,
    height,
    width,
    valueColumn,
    stacked,
    horizontal,
    valueColumns,
    valueUnits,
    yAxisLabel,
    xAxisLabel,
    yAxisUnits,
    curve,
    gradient,
    closeColumn,
    openColumn,
    highColumn,
    lowColumn,
    dateColumn,
    bucketCount,
    dataProviderId,
    blockcomponent_id_binding
  ];
}
class ChartBlock extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        filter: 0,
        sortColumn: 1,
        sortOrder: 2,
        limit: 3,
        autoRefresh: 4,
        chartTitle: 5,
        chartType: 6,
        dataSource: 7,
        palette: 8,
        c1: 9,
        c2: 10,
        c3: 11,
        c4: 12,
        c5: 13,
        labelColumn: 14,
        legend: 15,
        animate: 16,
        dataLabels: 17,
        height: 18,
        width: 19,
        valueColumn: 20,
        stacked: 21,
        horizontal: 22,
        valueColumns: 23,
        valueUnits: 24,
        yAxisLabel: 25,
        xAxisLabel: 26,
        yAxisUnits: 27,
        curve: 28,
        gradient: 29,
        closeColumn: 30,
        openColumn: 31,
        highColumn: 32,
        lowColumn: 33,
        dateColumn: 34,
        bucketCount: 35
      },
      null,
      [-1, -1]
    );
  }
}
export {
  ChartBlock as default
};
