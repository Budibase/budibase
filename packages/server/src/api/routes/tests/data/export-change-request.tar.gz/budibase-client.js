(function() {
  "use strict";
  try {
    if (typeof document != "undefined") {
      var elementStyle = document.createElement("style");
      elementStyle.appendChild(document.createTextNode(`/* Custom variables */
:root {
  --background: #ffffff;
  --ink: #000000;

  /* Brand colours */
  --bb-coral: #ff4e4e;
  --bb-coral-light: #f97777;
  --bb-indigo: #6e56ff;
  --bb-indigo-light: #9f8fff;
  --bb-lime: #ecffb5;
  --bb-forest-green: #053835;
  --bb-beige: #f6efea;
  --bb-blue: #6a9bcc;
  --bb-green: #788c5d;

  /* Custom spectrum additions */
  --spectrum-global-color-static-red-1200: #740000;
  --spectrum-global-color-static-orange-1200: #612300;
  --spectrum-global-color-static-yellow-1200: #483300;
  --spectrum-global-color-static-green-1200: #053f27;
  --spectrum-global-color-static-seafoam-1200: #123c3a;
  --spectrum-global-color-static-blue-1200: #003571;
  --spectrum-global-color-static-indigo-1200: #262986;
  --spectrum-global-color-static-magenta-1200: #700037;

  --grey-1: #fafafa;
  --grey-2: #f5f5f5;
  --grey-3: #eeeeee;
  --grey-4: #e0e0e0;
  --grey-5: #bdbdbd;
  --grey-6: #9e9e9e;
  --grey-7: #757575;
  --grey-8: #616161;
  --grey-9: #424242;

  --blue-light: #f1f4fc;
  --blue: #4285f4;
  --blue-dark: #2f4c9b;

  --red-light: #ffe6e6;
  --red: #e26d69;
  --red-dark: #800400;

  --yellow-light: #fff7e6;
  --yellow: #ffd26a;
  --yellow-dark: #805900;

  --orange-light: #fff0e6;
  --orange: #f0955a;
  --orange-dark: #803300;

  --green-light: #e6ffeb;
  --green: #84c991;
  --green-dark: #008017;

  --purple-light: #e9e6ff;
  --purple: #806fde;
  --purple-dark: #130080;

  --error-bg: rgba(226, 109, 105, 0.3);
  --warning-bg: rgba(255, 210, 106, 0.3);
  --error-content: rgba(226, 109, 105, 0.6);
  --warning-content: rgba(255, 210, 106, 0.6);

  --rounded-small: 4px;
  --rounded-medium: 8px;
  --rounded-large: 16px;

  --font-sans:
    "Inter", -apple-system, BlinkMacSystemFont, Segoe UI, "Helvetica Neue",
    Arial, "Noto Sans", sans-serif;
  --font-accent:
    "Inter", -apple-system, BlinkMacSystemFont, Segoe UI, "Helvetica Neue",
    Arial, "Noto Sans", sans-serif;
  --font-serif: "Georgia", Cambria, Times New Roman, Times, serif;
  --font-mono:
    Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;

  font-size: 16px;
  --font-size-xs: 0.75rem;
  --font-size-s: 0.875rem;
  --font-size-m: 1rem;
  --font-size-l: 1.15rem;
  --font-size-xl: 1.3rem;

  --heading-font-size-xs: 0.875rem;
  --heading-font-size-s: 1.12rem;
  --heading-font-size-m: 1.5rem;
  --heading-font-size-l: 2.6rem;
  --heading-font-size-xl: 3rem;

  --font-render: optimizeLegibility;
  --font-smooth: antialiased;

  --spacing-xs: 0.25rem;
  --spacing-s: 0.5rem;
  --spacing-m: 0.75rem;
  --spacing-l: 1rem;
  --spacing-xl: 1.25rem;

  --layout-xs: 1.25rem;
  --layout-s: 1.5rem;
  --layout-m: 2rem;
  --layout-l: 3rem;
  --layout-xl: 4rem;

  --border-radius-xs: 0.125rem;
  --border-radius-s: 0.35rem;
  --border-radius-m: 0.5rem;
  --border-radius-l: 1rem;
  --border-radius-xl: 100rem;

  --border-black: 2px var(--ink) solid;
  --border-dark: 2px var(--grey-7) solid;
  --border-grey: 1px var(--grey-4) solid;
  --border-grey-2: 2px var(--grey-4) solid;
  --border-light: 1px var(--grey-3) solid;
  --border-light-2: 2px var(--grey-3) solid;
  --border-blue: 2px var(--blue) solid;
  --border-transparent: 2px transparent solid;
}

/* Spectrum overrides */
.spectrum {
  --spectrum-alias-body-text-font-family: var(--font-sans) !important;
  --spectrum-global-font-family-base: var(--font-sans) !important;
  --spectrum-global-font-line-height-small: 1.4 !important;
  --spectrum-alias-text-color-disabled: var(
    --spectrum-global-color-gray-600
  ) !important;
  --spectrum-global-dimension-font-size-25: 9px !important;
  --spectrum-global-dimension-font-size-50: 11px !important;
  --spectrum-global-dimension-font-size-75: 12px !important;
  --spectrum-global-dimension-font-size-100: 13px !important;
  --spectrum-global-dimension-font-size-150: 15px !important;
  --spectrum-global-dimension-font-size-200: 16px !important;
  --spectrum-global-dimension-font-size-300: 18px !important;
  --spectrum-global-dimension-font-size-400: 20px !important;
  --spectrum-global-dimension-font-size-500: 22px !important;
  --spectrum-global-dimension-font-size-600: 25px !important;
  --spectrum-global-dimension-font-size-700: 28px !important;
  --spectrum-global-dimension-font-size-800: 32px !important;
  --spectrum-global-dimension-font-size-900: 36px !important;
  --spectrum-global-dimension-font-size-1000: 40px !important;
  --spectrum-global-dimension-font-size-1100: 45px !important;
  --spectrum-global-dimension-font-size-1200: 50px !important;
  --spectrum-global-dimension-font-size-1300: 60px !important;
  --spectrum-alias-font-size-default: 14px !important;
}
* {
  font-style: normal !important;
}

/* Generic styles */
a {
  text-decoration: none;
}

/* Custom theme additions */
.spectrum--darkest {
  --drop-shadow: rgba(0, 0, 0, 0.6);
  --spectrum-global-color-red-100: #570000;
  --spectrum-global-color-orange-100: #481801;
  --spectrum-global-color-yellow-100: #352400;
  --spectrum-global-color-green-100: #002f07;
  --spectrum-global-color-seafoam-100: #122b2a;
  --spectrum-global-color-blue-100: #002651;
  --spectrum-global-color-indigo-100: #1a1d61;
  --spectrum-global-color-magenta-100: #530329;
  --translucent-grey: rgba(255, 255, 255, 0.1);
}
.spectrum--dark {
  --drop-shadow: rgba(0, 0, 0, 0.3);
  --spectrum-global-color-red-100: #7b0000;
  --spectrum-global-color-orange-100: #662500;
  --spectrum-global-color-yellow-100: #4c3600;
  --spectrum-global-color-green-100: #00450a;
  --spectrum-global-color-seafoam-100: #12413f;
  --spectrum-global-color-blue-100: #003877;
  --spectrum-global-color-indigo-100: #282c8c;
  --spectrum-global-color-magenta-100: #76003a;
  --translucent-grey: rgba(255, 255, 255, 0.065);
}
.spectrum--light,
.spectrum--lightest {
  --drop-shadow: rgba(0, 0, 0, 0.075);
  --spectrum-global-color-red-100: #ffddd6;
  --spectrum-global-color-orange-100: #ffdfad;
  --spectrum-global-color-yellow-100: #fbf198;
  --spectrum-global-color-green-100: #cef8e0;
  --spectrum-global-color-seafoam-100: #cef7f3;
  --spectrum-global-color-blue-100: #e0f2ff;
  --spectrum-global-color-indigo-100: #edeeff;
  --spectrum-global-color-magenta-100: #ffeaf1;
  --translucent-grey: rgba(0, 0, 0, 0.085);
}
.spectrum-FieldLabel--sizeS {
  --spectrum-fieldlabel-text-font-weight: var(--spectrum-fieldlabel-s-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-fieldlabel-text-line-height: var(--spectrum-fieldlabel-s-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-fieldlabel-text-size: var(--spectrum-fieldlabel-s-text-size, var(--spectrum-global-dimension-font-size-75));
  --spectrum-fieldlabel-asterisk-gap: var(--spectrum-fieldlabel-s-asterisk-gap, var(--spectrum-global-dimension-size-25));
  --spectrum-fieldlabel-asterisk-margin-y: var(--spectrum-fieldlabel-s-asterisk-margin-y, var(--spectrum-global-dimension-size-50));
  --spectrum-fieldlabel-padding-top: var(--spectrum-fieldlabel-s-padding-top, var(--spectrum-global-dimension-size-50));
  --spectrum-fieldlabel-padding-bottom: var(--spectrum-fieldlabel-s-padding-bottom, var(--spectrum-global-dimension-size-65));
}

.spectrum-FieldLabel--sizeM {
  --spectrum-fieldlabel-text-font-weight: var(--spectrum-fieldlabel-m-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-fieldlabel-text-line-height: var(--spectrum-fieldlabel-m-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-fieldlabel-text-size: var(--spectrum-fieldlabel-m-text-size, var(--spectrum-global-dimension-font-size-75));
  --spectrum-fieldlabel-asterisk-gap: var(--spectrum-fieldlabel-m-asterisk-gap, var(--spectrum-global-dimension-size-25));
  --spectrum-fieldlabel-asterisk-margin-y: var(--spectrum-fieldlabel-m-asterisk-margin-y, var(--spectrum-global-dimension-size-50));
  --spectrum-fieldlabel-padding-top: var(--spectrum-fieldlabel-m-padding-top, var(--spectrum-global-dimension-size-50));
  --spectrum-fieldlabel-padding-bottom: var(--spectrum-fieldlabel-m-padding-bottom, var(--spectrum-global-dimension-size-65));
}

.spectrum-FieldLabel--sizeL {
  --spectrum-fieldlabel-text-font-weight: var(--spectrum-fieldlabel-l-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-fieldlabel-text-line-height: var(--spectrum-fieldlabel-l-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-fieldlabel-text-size: var(--spectrum-fieldlabel-l-text-size, var(--spectrum-global-dimension-font-size-100));
  --spectrum-fieldlabel-asterisk-gap: var(--spectrum-fieldlabel-l-asterisk-gap, var(--spectrum-global-dimension-size-25));
  --spectrum-fieldlabel-asterisk-margin-y: var(--spectrum-fieldlabel-l-asterisk-margin-y, var(--spectrum-global-dimension-size-50));
  --spectrum-fieldlabel-padding-top: var(--spectrum-fieldlabel-l-padding-top, var(--spectrum-global-dimension-size-75));
  --spectrum-fieldlabel-padding-bottom: var(--spectrum-fieldlabel-l-padding-bottom, var(--spectrum-global-dimension-size-115));
}

.spectrum-FieldLabel--sizeXL {
  --spectrum-fieldlabel-text-font-weight: var(--spectrum-fieldlabel-xl-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-fieldlabel-text-line-height: var(--spectrum-fieldlabel-xl-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-fieldlabel-text-size: var(--spectrum-fieldlabel-xl-text-size, var(--spectrum-global-dimension-font-size-200));
  --spectrum-fieldlabel-asterisk-gap: var(--spectrum-fieldlabel-xl-asterisk-gap, var(--spectrum-global-dimension-size-25));
  --spectrum-fieldlabel-asterisk-margin-y: var(--spectrum-fieldlabel-xl-asterisk-margin-y, var(--spectrum-global-dimension-size-50));
  --spectrum-fieldlabel-padding-top: var(--spectrum-fieldlabel-xl-padding-top, var(--spectrum-global-dimension-size-115));
  --spectrum-fieldlabel-padding-bottom: var(--spectrum-fieldlabel-xl-padding-bottom, var(--spectrum-global-dimension-size-130));
}

.spectrum-FieldLabel,
.spectrum-Form-itemLabel {
  display: block;

  box-sizing: border-box;

  padding-top: var(--spectrum-fieldlabel-padding-top);

  padding-bottom: var(--spectrum-fieldlabel-padding-bottom);
  padding-left: 0;
  padding-right: 0;

  font-size: var(--spectrum-fieldlabel-text-size);
  font-weight: var(--spectrum-fieldlabel-text-font-weight);
  line-height: var(--spectrum-fieldlabel-text-line-height);

  vertical-align: top;

  -webkit-font-smoothing: subpixel-antialiased;
  -moz-osx-font-smoothing: auto;
  font-smoothing: subpixel-antialiased;
}

[dir="ltr"] .spectrum-FieldLabel-requiredIcon {
  margin-left: var(--spectrum-fieldlabel-asterisk-gap);
  margin-right: 0;
}

[dir="rtl"] .spectrum-FieldLabel-requiredIcon {
  margin-right: var(--spectrum-fieldlabel-asterisk-gap);
  margin-left: 0;
}

.spectrum-FieldLabel-requiredIcon {
  margin-top: var(--spectrum-fieldlabel-asterisk-margin-y);
  margin-bottom: 0;
}

[dir="ltr"] .spectrum-FieldLabel--left {
  padding-left: 0;
  padding-right: var(--spectrum-fieldlabel-side-m-padding-right, var(--spectrum-global-dimension-size-100));
}

[dir="rtl"] .spectrum-FieldLabel--left {
  padding-right: 0;
  padding-left: var(--spectrum-fieldlabel-side-m-padding-right, var(--spectrum-global-dimension-size-100));
}

.spectrum-FieldLabel--left {
  display: inline-block;
  padding-top: var(--spectrum-fieldlabel-side-m-padding-top, var(--spectrum-global-dimension-size-100));
  padding-bottom: 0;
}

[dir="ltr"] .spectrum-FieldLabel--left .spectrum-FieldLabel-requiredIcon {
    margin-left: var(--spectrum-fieldlabel-asterisk-gap);
    margin-right: 0;
}

[dir="rtl"] .spectrum-FieldLabel--left .spectrum-FieldLabel-requiredIcon {
    margin-right: var(--spectrum-fieldlabel-asterisk-gap);
    margin-left: 0;
}

.spectrum-FieldLabel--left .spectrum-FieldLabel-requiredIcon {
    margin-top: var(--spectrum-fieldlabel-side-m-asterisk-margin-y, var(--spectrum-global-dimension-size-50));
    margin-bottom: 0;
  }

[dir="ltr"] .spectrum-FieldLabel--right {
  text-align: right;
}

[dir="rtl"] .spectrum-FieldLabel--right {
  text-align: left;
}

[dir="ltr"] .spectrum-FieldLabel--right {
  padding-left: 0;
  padding-right: var(--spectrum-fieldlabel-side-m-padding-right, var(--spectrum-global-dimension-size-100));
}

[dir="rtl"] .spectrum-FieldLabel--right {
  padding-right: 0;
  padding-left: var(--spectrum-fieldlabel-side-m-padding-right, var(--spectrum-global-dimension-size-100));
}

.spectrum-FieldLabel--right {
  display: inline-block;
  padding-top: var(--spectrum-fieldlabel-side-m-padding-top, var(--spectrum-global-dimension-size-100));
  padding-bottom: 0;
}

.spectrum-Form {
  --spectrum-tableform-border-spacing: 0 var(--spectrum-global-dimension-size-300);
  --spectrum-tableform-margin: calc(var(--spectrum-global-dimension-size-250) * -1) 0;
  --spectrum-tableform-labelsabove-item-gap: var(--spectrum-global-dimension-size-100);

  display: table;
  border-collapse: separate;
  border-spacing: var(--spectrum-tableform-border-spacing);
  margin: var(--spectrum-tableform-margin);
}

.spectrum-Form-item {
  display: table-row;
}

.spectrum-Form-itemLabel {
  display: table-cell;
}

.spectrum-Form-itemField {
  display: table-cell;
}

.spectrum-Form--labelsAbove {
  display: -ms-flexbox;
  display: flex;
  -ms-flex-direction: column;
      flex-direction: column;
  margin: 0;
}

.spectrum-Form--labelsAbove .spectrum-Form-item {
    display: -ms-flexbox;
    display: flex;
    -ms-flex-direction: column;
        flex-direction: column;
  }

.spectrum-Form--labelsAbove .spectrum-Form-item + .spectrum-Form-item {
      margin-top: var(--spectrum-tableform-labelsabove-item-gap);
    }

.spectrum-FieldLabel,
.spectrum-Form-itemLabel {
  color: var(--spectrum-fieldlabel-m-text-color, var(--spectrum-alias-label-text-color));
}

.spectrum-FieldLabel.is-disabled, .spectrum-Form-itemLabel.is-disabled {
    color: var(--spectrum-fieldlabel-m-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }

.spectrum-FieldLabel.is-disabled .spectrum-FieldLabel-requiredIcon, .spectrum-Form-itemLabel.is-disabled .spectrum-FieldLabel-requiredIcon {
      color: var(--spectrum-fieldlabel-m-asterisk-color-disabled, var(--spectrum-alias-text-color-disabled));
    }

.spectrum-FieldLabel-requiredIcon {
  color: var(--spectrum-fieldlabel-m-asterisk-color, var(--spectrum-global-color-gray-600));
}
.spectrum-Tooltip {
  --spectrum-overlay-animation-distance: var(--spectrum-picker-m-popover-offset-y, var(--spectrum-global-dimension-size-75));

  visibility: hidden;

  opacity: 0;

  transition: transform var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
              opacity var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
              visibility 0ms linear var(--spectrum-global-animation-duration-100, 130ms);

  pointer-events: none;
}

.spectrum-Tooltip.is-open {
  visibility: visible;

  opacity: 1;

  transition-delay: 0ms;

  pointer-events: auto;
}

.spectrum-Tooltip--bottom.is-open {
  transform: translateY(var(--spectrum-overlay-animation-distance));
}

.spectrum-Tooltip--top.is-open {
  transform: translateY(calc(-1 * var(--spectrum-overlay-animation-distance)));
}

.spectrum-Tooltip--right.is-open {
  transform: translateX(var(--spectrum-overlay-animation-distance));
}

.spectrum-Tooltip--left.is-open {
  transform: translateX(calc(-1 * var(--spectrum-overlay-animation-distance)));
}

.spectrum-Tooltip {
  --spectrum-tooltip-target-offset: 3px;
  --spectrum-tooltip-tip-width: var(--spectrum-tooltip-tip-height, var(--spectrum-global-dimension-size-50));
}

.spectrum-Tooltip {

  position: relative;
  left: 0px;
  top: 0px;

  display: -ms-inline-flexbox;

  display: inline-flex;
  -ms-flex-direction: row;
      flex-direction: row;
  -ms-flex-align: center;
      align-items: center;
  box-sizing: border-box;

  vertical-align: top;

  width: auto;
  padding: var(--spectrum-tooltip-padding-top, var(--spectrum-global-dimension-size-50)) var(--spectrum-tooltip-padding-x, var(--spectrum-global-dimension-size-125));
  border-radius: var(--spectrum-tooltip-border-radius, var(--spectrum-global-dimension-size-50));
  min-height: var(--spectrum-tooltip-min-height, var(--spectrum-global-dimension-size-300));
  max-width: var(--spectrum-tooltip-max-width, var(--spectrum-global-dimension-size-2000));

  font-size: var(--spectrum-tooltip-text-size, var(--spectrum-global-dimension-font-size-75));
  font-weight: var(--spectrum-tooltip-text-font-weight, var(--spectrum-global-font-weight-regular));
  line-height: var(--spectrum-tooltip-text-line-height, var(--spectrum-alias-component-text-line-height));
  word-break: break-word;
  -webkit-font-smoothing: antialiased;
}

.spectrum-Tooltip {
    cursor: default;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
  }

.spectrum-Tooltip p {
    margin: 0;
  }

.spectrum-Tooltip-tip {
  position: absolute;

  height: 0;
  width: 0;

  border-width: var(--spectrum-tooltip-tip-width, var(--spectrum-global-dimension-size-100));
  border-style: solid;
  border-left-color: transparent;
  border-right-color: transparent;
  border-bottom-color: transparent;
}

.spectrum-Tooltip--right .spectrum-Tooltip-tip, .spectrum-Tooltip--left .spectrum-Tooltip-tip {
    top: 50%;
    margin-top: calc(-1 * var(--spectrum-tooltip-tip-width, var(--spectrum-global-dimension-size-100)));
  }

.spectrum-Tooltip--right {
  margin-left: var(--spectrum-tooltip-target-offset);
}

.spectrum-Tooltip--right .spectrum-Tooltip-tip {
    right: 100%;
    transform: rotate(90deg);
  }

.spectrum-Tooltip--left {
  margin-right: var(--spectrum-tooltip-target-offset);
}

.spectrum-Tooltip--left .spectrum-Tooltip-tip {
    left: 100%;
    transform: rotate(-90deg);
  }

.spectrum-Tooltip--top {
  margin-bottom: var(--spectrum-tooltip-target-offset);
}

.spectrum-Tooltip--top .spectrum-Tooltip-tip {
    top: 100%;
  }

.spectrum-Tooltip--bottom {
  margin-top: var(--spectrum-tooltip-target-offset);
}

.spectrum-Tooltip--bottom .spectrum-Tooltip-tip {
    bottom: 100%;
    transform: rotate(-180deg);
  }

.spectrum-Tooltip--bottom .spectrum-Tooltip-tip, .spectrum-Tooltip--top .spectrum-Tooltip-tip {
    left: 50%;
    margin-left: calc(-1 * var(--spectrum-tooltip-tip-width, var(--spectrum-global-dimension-size-100)));
  }

[dir="ltr"] .spectrum-Tooltip-typeIcon {
  margin-left: calc(var(--spectrum-tooltip-icon-margin-x, var(--spectrum-global-dimension-size-100)) - var(--spectrum-tooltip-padding-x, var(--spectrum-global-dimension-size-125)));
}

[dir="rtl"] .spectrum-Tooltip-typeIcon {
  margin-right: calc(var(--spectrum-tooltip-icon-margin-x, var(--spectrum-global-dimension-size-100)) - var(--spectrum-tooltip-padding-x, var(--spectrum-global-dimension-size-125)));
}

[dir="ltr"] .spectrum-Tooltip-typeIcon {
  margin-right: var(--spectrum-tooltip-icon-margin-x, var(--spectrum-global-dimension-size-100));
}

[dir="rtl"] .spectrum-Tooltip-typeIcon {
  margin-left: var(--spectrum-tooltip-icon-margin-x, var(--spectrum-global-dimension-size-100));
}

.spectrum-Tooltip-typeIcon {
  width: var(--spectrum-tooltip-icon-size, var(--spectrum-global-dimension-size-175));
  height: var(--spectrum-tooltip-icon-size, var(--spectrum-global-dimension-size-175));
  -ms-flex-item-align: start;
      align-self: flex-start;
  -ms-flex-negative: 0;
      flex-shrink: 0;
  margin-top: 1px;
}

.spectrum-Tooltip-label {
  line-height: var(--spectrum-tooltip-text-line-height, var(--spectrum-alias-component-text-line-height));
}

.u-tooltip-showOnHover {
  display: inline-block;
  position: relative;
}

.u-tooltip-showOnHover .spectrum-Tooltip {
    position: absolute;
    white-space: nowrap;
    visibility: visible !important;
    transition: transform var(--spectrum-global-animation-duration-100, 130ms)
      ease-in-out;
    top: -100%;
  }

.u-tooltip-showOnHover .spectrum-Tooltip-label {
    max-width: none;
  }

.u-tooltip-showOnHover .spectrum-Tooltip--right,
  .u-tooltip-showOnHover .spectrum-Tooltip--left {
    top: 50%;
  }

.u-tooltip-showOnHover .spectrum-Tooltip--right .spectrum-Tooltip-tip, .u-tooltip-showOnHover .spectrum-Tooltip--left .spectrum-Tooltip-tip {
      top: 50%;
    }

.u-tooltip-showOnHover .spectrum-Tooltip--right {
    left: 100%;
    transform: translate(0, -50%);
  }

.u-tooltip-showOnHover .spectrum-Tooltip--left {
    transform: translate(-100%, -50%);
  }

.u-tooltip-showOnHover .spectrum-Tooltip--bottom,
  .u-tooltip-showOnHover .spectrum-Tooltip--top {
    left: 50%;
  }

.u-tooltip-showOnHover .spectrum-Tooltip--bottom .spectrum-Tooltip-tip, .u-tooltip-showOnHover .spectrum-Tooltip--top .spectrum-Tooltip-tip {
      left: 50%;
    }

.u-tooltip-showOnHover .spectrum-Tooltip--bottom {
    top: 100%;
    transform: translate(-50%, calc(-1 * var(--spectrum-tooltip-tip-margin, var(--spectrum-global-dimension-size-50))));
  }

.u-tooltip-showOnHover .spectrum-Tooltip--top {
    transform: translate(-50%, var(--spectrum-tooltip-tip-margin, var(--spectrum-global-dimension-size-50)));
  }

.u-tooltip-showOnHover:hover .spectrum-Tooltip,
  .u-tooltip-showOnHover:focus .spectrum-Tooltip,
  .u-tooltip-showOnHover.is-focused .spectrum-Tooltip,
  .u-tooltip-showOnHover *:focus .spectrum-Tooltip {
    opacity: 1;
  }

.u-tooltip-showOnHover:hover .spectrum-Tooltip.spectrum-Tooltip--bottom,
  .u-tooltip-showOnHover:focus .spectrum-Tooltip.spectrum-Tooltip--bottom,
  .u-tooltip-showOnHover.is-focused .spectrum-Tooltip.spectrum-Tooltip--bottom,
  .u-tooltip-showOnHover *:focus .spectrum-Tooltip.spectrum-Tooltip--bottom {
    transform: translate(-50%, 0);
  }

.u-tooltip-showOnHover:hover .spectrum-Tooltip.spectrum-Tooltip--top,
  .u-tooltip-showOnHover:focus .spectrum-Tooltip.spectrum-Tooltip--top,
  .u-tooltip-showOnHover.is-focused .spectrum-Tooltip.spectrum-Tooltip--top,
  .u-tooltip-showOnHover *:focus .spectrum-Tooltip.spectrum-Tooltip--top {
    transform: translate(-50%, calc(-1 * var(--spectrum-tooltip-tip-margin, var(--spectrum-global-dimension-size-50))));
  }

.u-tooltip-showOnHover:hover .spectrum-Tooltip.spectrum-Tooltip--left,
  .u-tooltip-showOnHover:focus .spectrum-Tooltip.spectrum-Tooltip--left,
  .u-tooltip-showOnHover.is-focused .spectrum-Tooltip.spectrum-Tooltip--left,
  .u-tooltip-showOnHover *:focus .spectrum-Tooltip.spectrum-Tooltip--left {
    transform: translate(
      calc(-100% - var(--spectrum-tooltip-tip-margin, var(--spectrum-global-dimension-size-50))),
      -50%
    );
  }

.u-tooltip-showOnHover:hover .spectrum-Tooltip.spectrum-Tooltip--right,
  .u-tooltip-showOnHover:focus .spectrum-Tooltip.spectrum-Tooltip--right,
  .u-tooltip-showOnHover.is-focused .spectrum-Tooltip.spectrum-Tooltip--right,
  .u-tooltip-showOnHover *:focus .spectrum-Tooltip.spectrum-Tooltip--right {
    transform: translate(var(--spectrum-tooltip-tip-margin, var(--spectrum-global-dimension-size-50)), -50%);
  }

.spectrum-Tooltip {
  background-color: var(--spectrum-tooltip-background-color, var(--spectrum-global-color-static-gray-700));

  color: var(--spectrum-tooltip-text-color, var(--spectrum-global-color-static-white));
}

.spectrum-Tooltip-tip {
  border-top-color: var(--spectrum-tooltip-background-color, var(--spectrum-global-color-static-gray-700));
}

.spectrum-Tooltip--negative,
/** @deprecated */.spectrum-Tooltip--error {
  background-color: var(--spectrum-tooltip-negative-background-color, var(--spectrum-global-color-static-red-700));
}

.spectrum-Tooltip--negative .spectrum-Tooltip-tip, .spectrum-Tooltip--error .spectrum-Tooltip-tip {
    border-top-color: var(--spectrum-tooltip-negative-background-color, var(--spectrum-global-color-static-red-700));
  }

.spectrum-Tooltip--info,
/** @deprecated */.spectrum-Tooltip--help {
  background-color: var(--spectrum-tooltip-info-background-color, var(--spectrum-global-color-static-blue-700));
}

.spectrum-Tooltip--info .spectrum-Tooltip-tip, .spectrum-Tooltip--help .spectrum-Tooltip-tip {
    border-top-color: var(--spectrum-tooltip-info-background-color, var(--spectrum-global-color-static-blue-700));
  }

.spectrum-Tooltip--positive,
/** @deprecated */.spectrum-Tooltip--success {
  background-color: var(--spectrum-tooltip-positive-background-color, var(--spectrum-global-color-static-green-700));
}

.spectrum-Tooltip--positive .spectrum-Tooltip-tip, .spectrum-Tooltip--success .spectrum-Tooltip-tip {
    border-top-color: var(--spectrum-tooltip-positive-background-color, var(--spectrum-global-color-static-green-700));
  }
.abs-tooltip.svelte-dwbp30.svelte-dwbp30{display:contents;pointer-events:all}.spectrum-Tooltip.noWrap.svelte-dwbp30 .spectrum-Tooltip-label.svelte-dwbp30{width:max-content}.spectrum-Tooltip.svelte-dwbp30.svelte-dwbp30{position:absolute;z-index:9999;pointer-events:none;margin:0;max-width:280px;transition:top 130ms ease-out,
      left 130ms ease-out}.spectrum-Tooltip-label.svelte-dwbp30.svelte-dwbp30{display:-webkit-box;-webkit-line-clamp:3;line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;font-size:12px;font-weight:600}.spectrum-Tooltip--default.svelte-dwbp30.svelte-dwbp30{background:var(--spectrum-global-color-gray-500)}.spectrum-Tooltip--default.svelte-dwbp30 .spectrum-Tooltip-tip.svelte-dwbp30{border-top-color:var(--spectrum-global-color-gray-500)}.spectrum-Tooltip--top.svelte-dwbp30.svelte-dwbp30{transform:translateX(-50%) translateY(calc(-100% - 8px))}.spectrum-Tooltip--right.svelte-dwbp30.svelte-dwbp30{transform:translateX(8px) translateY(-50%)}.spectrum-Tooltip--bottom.svelte-dwbp30.svelte-dwbp30{transform:translateX(-50%) translateY(8px)}.spectrum-Tooltip--left.svelte-dwbp30.svelte-dwbp30{transform:translateX(calc(-100% - 8px)) translateY(-50%)}i.svelte-8f9wnr{display:grid;place-items:center;color:var(--color);transition:color 130ms ease-out;font-size:var(--size)}i.hoverable.svelte-8f9wnr{pointer-events:all}i.hoverable.svelte-8f9wnr:hover{color:var(--hover-color, var(--spectrum-global-color-gray-900));cursor:pointer}i.hoverable.svelte-8f9wnr:active{color:var(--hover-color, var(--spectrum-global-color-gray-900))}i.disabled.svelte-8f9wnr{color:var(--spectrum-global-color-gray-500);pointer-events:none}.container.svelte-19tap7e{display:flex;align-items:center}.icon-container.svelte-19tap7e{position:relative;display:flex;justify-content:center;margin-left:5px;margin-right:5px}.icon.svelte-19tap7e{transform:scale(0.75)}.icon-small.svelte-19tap7e{margin-bottom:-2px}label.svelte-dqoj9e{white-space:nowrap}.spectrum-FieldLabel--right.svelte-dqoj9e,.spectrum-FieldLabel--left.svelte-dqoj9e{padding-right:var(--spectrum-global-dimension-size-200)}.spectrum-Form-item.above.svelte-e52e9j.svelte-e52e9j{display:flex;flex-direction:column}.spectrum-Form-itemField.svelte-e52e9j.svelte-e52e9j{position:relative;width:100%}.error.svelte-e52e9j.svelte-e52e9j{color:var(
      --spectrum-semantic-negative-color-default,
      var(--spectrum-global-color-red-500)
    );font-size:var(--spectrum-global-dimension-font-size-75);margin-top:var(--spectrum-global-dimension-size-75)}.helpText.svelte-e52e9j.svelte-e52e9j{display:flex;margin-top:var(--spectrum-global-dimension-size-75);align-items:center}.helpText.svelte-e52e9j svg{width:13px;color:var(--spectrum-global-color-gray-600);margin-right:6px}.helpText.svelte-e52e9j span.svelte-e52e9j{color:var(--spectrum-global-color-gray-800);font-size:var(--spectrum-global-dimension-font-size-75)}.spectrum-Checkbox {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-align: start;
      align-items: flex-start;

  position: relative;

  min-height: var(--spectrum-checkbox-height);
  max-width: 100%;

  vertical-align: top;
}

.spectrum-Checkbox-input {
  font-family: inherit;
  font-size: 100%;
  line-height: 1.15;
  margin: 0;
  overflow: visible;
  box-sizing: border-box;
  padding: 0;

  position: absolute;
  width: 100%;
  height: 100%;

  opacity: .0001;
  z-index: 1;

  cursor: pointer;
}

.spectrum-Checkbox-input:disabled {
    cursor: default;
  }

.spectrum-Checkbox-input:checked + .spectrum-Checkbox-box:before {
      border-width: calc(var(--spectrum-checkbox-box-size) / 2);
    }

.spectrum-Checkbox-input:checked + .spectrum-Checkbox-box .spectrum-Checkbox-checkmark {
      transform: scale(1);
      opacity: 1;
    }

.spectrum-Checkbox-input.focus-ring + .spectrum-Checkbox-box:after {
        margin: calc(var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25)) * -1);
      }

.spectrum-Checkbox--sizeS {
  --spectrum-checkbox-text-font-style: var(--spectrum-checkbox-s-text-font-style, var(--spectrum-global-font-style-regular));
  --spectrum-checkbox-text-font-weight: var(--spectrum-checkbox-s-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-checkbox-text-line-height: var(--spectrum-checkbox-s-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-checkbox-box-border-radius: var(--spectrum-checkbox-s-box-border-radius, var(--spectrum-alias-border-radius-small));
  --spectrum-checkbox-box-border-size: var(--spectrum-checkbox-s-box-border-size, var(--spectrum-alias-border-size-thick));
  --spectrum-checkbox-text-size: var(--spectrum-checkbox-s-text-size, var(--spectrum-alias-item-text-size-s));
  --spectrum-checkbox-text-padding-top: var(--spectrum-checkbox-s-text-padding-top, var(--spectrum-alias-item-text-padding-top-s));
  --spectrum-checkbox-height: var(--spectrum-checkbox-s-height, var(--spectrum-alias-item-height-s));
  --spectrum-checkbox-checkmark-size: var(--spectrum-checkbox-s-checkmark-size, var(--spectrum-alias-ui-icon-checkmark-size-75));
  --spectrum-checkbox-box-size: var(--spectrum-checkbox-s-box-size, var(--spectrum-alias-item-control-2-size-s));
  --spectrum-checkbox-text-gap: var(--spectrum-checkbox-s-text-gap, var(--spectrum-alias-item-control-gap-s));
}

.spectrum-Checkbox--sizeM {
  --spectrum-checkbox-text-font-style: var(--spectrum-checkbox-m-text-font-style, var(--spectrum-global-font-style-regular));
  --spectrum-checkbox-text-font-weight: var(--spectrum-checkbox-m-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-checkbox-text-line-height: var(--spectrum-checkbox-m-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-checkbox-box-border-radius: var(--spectrum-checkbox-m-box-border-radius, var(--spectrum-alias-border-radius-small));
  --spectrum-checkbox-box-border-size: var(--spectrum-checkbox-m-box-border-size, var(--spectrum-alias-border-size-thick));
  --spectrum-checkbox-text-size: var(--spectrum-checkbox-m-text-size, var(--spectrum-alias-item-text-size-m));
  --spectrum-checkbox-text-padding-top: var(--spectrum-checkbox-m-text-padding-top, var(--spectrum-alias-item-text-padding-top-m));
  --spectrum-checkbox-height: var(--spectrum-checkbox-m-height, var(--spectrum-alias-item-height-m));
  --spectrum-checkbox-checkmark-size: var(--spectrum-checkbox-m-checkmark-size, var(--spectrum-alias-ui-icon-checkmark-size-100));
  --spectrum-checkbox-box-size: var(--spectrum-checkbox-m-box-size, var(--spectrum-alias-item-control-2-size-m));
  --spectrum-checkbox-text-gap: var(--spectrum-checkbox-m-text-gap, var(--spectrum-alias-item-control-gap-m));
}

.spectrum-Checkbox--sizeL {
  --spectrum-checkbox-text-font-style: var(--spectrum-checkbox-l-text-font-style, var(--spectrum-global-font-style-regular));
  --spectrum-checkbox-text-font-weight: var(--spectrum-checkbox-l-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-checkbox-text-line-height: var(--spectrum-checkbox-l-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-checkbox-box-border-radius: var(--spectrum-checkbox-l-box-border-radius, var(--spectrum-alias-border-radius-small));
  --spectrum-checkbox-box-border-size: var(--spectrum-checkbox-l-box-border-size, var(--spectrum-alias-border-size-thick));
  --spectrum-checkbox-text-size: var(--spectrum-checkbox-l-text-size, var(--spectrum-alias-item-text-size-l));
  --spectrum-checkbox-text-padding-top: var(--spectrum-checkbox-l-text-padding-top, var(--spectrum-alias-item-text-padding-top-l));
  --spectrum-checkbox-height: var(--spectrum-checkbox-l-height, var(--spectrum-alias-item-height-l));
  --spectrum-checkbox-checkmark-size: var(--spectrum-checkbox-l-checkmark-size, var(--spectrum-alias-ui-icon-checkmark-size-200));
  --spectrum-checkbox-box-size: var(--spectrum-checkbox-l-box-size, var(--spectrum-alias-item-control-2-size-l));
  --spectrum-checkbox-text-gap: var(--spectrum-checkbox-l-text-gap, var(--spectrum-alias-item-control-gap-l));
}

.spectrum-Checkbox--sizeXL {
  --spectrum-checkbox-text-font-style: var(--spectrum-checkbox-xl-text-font-style, var(--spectrum-global-font-style-regular));
  --spectrum-checkbox-text-font-weight: var(--spectrum-checkbox-xl-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-checkbox-text-line-height: var(--spectrum-checkbox-xl-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-checkbox-box-border-radius: var(--spectrum-checkbox-xl-box-border-radius, var(--spectrum-alias-border-radius-small));
  --spectrum-checkbox-box-border-size: var(--spectrum-checkbox-xl-box-border-size, var(--spectrum-alias-border-size-thick));
  --spectrum-checkbox-text-size: var(--spectrum-checkbox-xl-text-size, var(--spectrum-alias-item-text-size-xl));
  --spectrum-checkbox-text-padding-top: var(--spectrum-checkbox-xl-text-padding-top, var(--spectrum-alias-item-text-padding-top-xl));
  --spectrum-checkbox-height: var(--spectrum-checkbox-xl-height, var(--spectrum-alias-item-height-xl));
  --spectrum-checkbox-checkmark-size: var(--spectrum-checkbox-xl-checkmark-size, var(--spectrum-alias-ui-icon-checkmark-size-300));
  --spectrum-checkbox-box-size: var(--spectrum-checkbox-xl-box-size, var(--spectrum-alias-item-control-2-size-xl));
  --spectrum-checkbox-text-gap: var(--spectrum-checkbox-xl-text-gap, var(--spectrum-alias-item-control-gap-xl));
}

.spectrum-Checkbox.is-indeterminate .spectrum-Checkbox-box:before, .spectrum-Checkbox.is-indeterminate .spectrum-Checkbox-input:checked + .spectrum-Checkbox-box:before {
      border-width: calc(var(--spectrum-checkbox-box-size) / 2);
    }

.spectrum-Checkbox.is-indeterminate .spectrum-Checkbox-box .spectrum-Checkbox-checkmark, .spectrum-Checkbox.is-indeterminate .spectrum-Checkbox-input:checked + .spectrum-Checkbox-box .spectrum-Checkbox-checkmark {
      display: none;
    }

.spectrum-Checkbox.is-indeterminate .spectrum-Checkbox-box .spectrum-Checkbox-partialCheckmark, .spectrum-Checkbox.is-indeterminate .spectrum-Checkbox-input:checked + .spectrum-Checkbox-box .spectrum-Checkbox-partialCheckmark {
      display: block;

      transform: scale(1);
      opacity: 1;
    }

[dir="ltr"] .spectrum-Checkbox-label {
  text-align: left;
}

[dir="rtl"] .spectrum-Checkbox-label {
  text-align: right;
}

[dir="ltr"] .spectrum-Checkbox-label {
  margin-left: var(--spectrum-checkbox-text-gap);
}

[dir="rtl"] .spectrum-Checkbox-label {
  margin-right: var(--spectrum-checkbox-text-gap);
}

.spectrum-Checkbox-label {
  margin-top: var(--spectrum-checkbox-text-padding-top);

  font-size: var(--spectrum-checkbox-text-size);
  font-weight: var(--spectrum-checkbox-text-font-weight);
  font-style: var(--spectrum-checkbox-text-font-style);
  line-height: var(--spectrum-checkbox-text-line-height);

  transition: color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
}

.spectrum-Checkbox-box {
  position: relative;
  box-sizing: border-box;
  width: var(--spectrum-checkbox-box-size);
  height: var(--spectrum-checkbox-box-size);
  margin: calc((var(--spectrum-checkbox-height) - var(--spectrum-checkbox-box-size)) / 2) 0;

  -ms-flex-positive: 0;

      flex-grow: 0;
  -ms-flex-negative: 0;
      flex-shrink: 0;
}

.spectrum-Checkbox-box:before {
    display: block;
    z-index: 0;
    content: '';
    box-sizing: border-box;
    position: absolute;

    width: var(--spectrum-checkbox-box-size);
    height: var(--spectrum-checkbox-box-size);

    border-radius: var(--spectrum-checkbox-box-border-radius);
    border-width: var(--spectrum-checkbox-box-border-size);
    border-style: solid;

    transition: border var(--spectrum-global-animation-duration-100, 130ms) ease-in-out, box-shadow var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
  }

.spectrum-Checkbox-box:after {
    border-radius: calc(var(--spectrum-checkbox-box-border-radius) + var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25)));
    content: '';
    display: block;
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    top: 0;
    margin: var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25));

    transition: box-shadow var(--spectrum-global-animation-duration-100, 130ms) ease-out,
                margin var(--spectrum-global-animation-duration-100, 130ms) ease-out;
    transform: translate(0, 0);
  }

[dir="ltr"] .spectrum-Checkbox-checkmark,[dir="ltr"] 
.spectrum-Checkbox-partialCheckmark {
  left: 50%;
}

[dir="rtl"] .spectrum-Checkbox-checkmark,[dir="rtl"] 
.spectrum-Checkbox-partialCheckmark {
  right: 50%;
}

.spectrum-Checkbox-checkmark,
.spectrum-Checkbox-partialCheckmark {
  position: absolute;
  top: 50%;

  opacity: 0;
  transform: scale(0);

  transition: opacity var(--spectrum-global-animation-duration-100, 130ms) ease-in-out, transform var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
}

[dir="ltr"] .spectrum-Checkbox-checkmark {
  margin-left: calc(var(--spectrum-checkbox-checkmark-size) / -2);
}

[dir="rtl"] .spectrum-Checkbox-checkmark {
  margin-right: calc(var(--spectrum-checkbox-checkmark-size) / -2);
}

.spectrum-Checkbox-checkmark {
  margin-top: calc(var(--spectrum-checkbox-checkmark-size) / -2);
}

[dir="ltr"] .spectrum-Checkbox-partialCheckmark {
  margin-left: calc(var(--spectrum-checkbox-checkmark-size) / -2);
}

[dir="rtl"] .spectrum-Checkbox-partialCheckmark {
  margin-right: calc(var(--spectrum-checkbox-checkmark-size) / -2);
}

.spectrum-Checkbox-partialCheckmark {
  margin-top: calc(var(--spectrum-checkbox-checkmark-size) / -2);
}

.spectrum-Checkbox-partialCheckmark {
  display: none;
}

.spectrum-Checkbox {
  color: var(--spectrum-checkbox-m-text-color, var(--spectrum-alias-text-color));
}

.spectrum-Checkbox-checkmark,
.spectrum-Checkbox-partialCheckmark {
  color: var(--spectrum-checkbox-m-checkmark-color, var(--spectrum-global-color-gray-75));
}

.spectrum-Checkbox-box:before {
    forced-color-adjust: none;
    border-color: var(--spectrum-checkbox-m-box-border-color, var(--spectrum-global-color-gray-600));
    background-color: var(--spectrum-checkbox-m-box-background-color, var(--spectrum-global-color-gray-75));
  }

.spectrum-Checkbox-label {
  color: var(--spectrum-checkbox-m-text-color, var(--spectrum-alias-text-color));
}

.spectrum-Checkbox.is-indeterminate .spectrum-Checkbox-box:before, .spectrum-Checkbox-input:checked + .spectrum-Checkbox-box:before {
    border-color: var(--spectrum-checkbox-m-box-border-color-selected, var(--spectrum-global-color-gray-700));
  }

.spectrum-Checkbox:hover.is-indeterminate .spectrum-Checkbox-box:before, .spectrum-Checkbox:hover .spectrum-Checkbox-input:checked + .spectrum-Checkbox-box:before {
      border-color: var(--spectrum-checkbox-m-box-border-color-selected-hover, var(--spectrum-global-color-gray-800));
    }

.spectrum-Checkbox:active.is-indeterminate .spectrum-Checkbox-box:before, .spectrum-Checkbox:active .spectrum-Checkbox-input:checked + .spectrum-Checkbox-box:before {
      border-color: var(--spectrum-checkbox-m-box-border-color-selected-down, var(--spectrum-global-color-gray-900));
    }

.spectrum-Checkbox {
  border-color: var(--spectrum-checkbox-m-box-border-color, var(--spectrum-global-color-gray-600));
}

.spectrum-Checkbox:hover .spectrum-Checkbox-box:before {
        border-color: var(--spectrum-checkbox-m-box-border-color-hover, var(--spectrum-global-color-gray-700));
      }

.spectrum-Checkbox:hover .spectrum-Checkbox-label {
      color: var(--spectrum-checkbox-m-text-color-hover, var(--spectrum-alias-text-color-hover));
    }

.spectrum-Checkbox:active .spectrum-Checkbox-box:before {
        border-color: var(--spectrum-checkbox-m-box-border-color-down, var(--spectrum-global-color-gray-800));
      }

.spectrum-Checkbox:active .spectrum-Checkbox-label {
      color: var(--spectrum-checkbox-m-text-color-down, var(--spectrum-alias-text-color-down));
    }

.spectrum-Checkbox .spectrum-Checkbox-input:disabled + .spectrum-Checkbox-box:before, .spectrum-Checkbox .spectrum-Checkbox-input:checked:disabled + .spectrum-Checkbox-box:before {
      border-color: var(--spectrum-checkbox-m-box-border-color-disabled, var(--spectrum-global-color-gray-400));
      background-color: var(--spectrum-checkbox-m-box-background-color-disabled, var(--spectrum-global-color-gray-75));
    }

.spectrum-Checkbox .spectrum-Checkbox-input:disabled ~ .spectrum-Checkbox-label, .spectrum-Checkbox .spectrum-Checkbox-input:checked:disabled ~ .spectrum-Checkbox-label {
    forced-color-adjust: none;
    color: var(--spectrum-checkbox-m-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }

.spectrum-Checkbox-input.focus-ring + .spectrum-Checkbox-box:before {
      border-color: var(--spectrum-checkbox-m-box-border-color-key-focus, var(--spectrum-global-color-gray-700));
    }

.spectrum-Checkbox-input.focus-ring + .spectrum-Checkbox-box:after {
      box-shadow: 0 0 0 var(--spectrum-checkbox-m-focus-ring-size-key-focus, var(--spectrum-alias-focus-ring-size))
        var(--spectrum-checkbox-m-focus-ring-color-key-focus, var(--spectrum-alias-focus-ring-color));
    }

.spectrum-Checkbox.is-indeterminate .spectrum-Checkbox-input.focus-ring + .spectrum-Checkbox-box:before, .spectrum-Checkbox-input:checked.focus-ring + .spectrum-Checkbox-box:before {
        border-color: var(--spectrum-checkbox-m-box-border-color-selected-key-focus, var(--spectrum-global-color-gray-800));
      }

.spectrum-Checkbox-input.focus-ring ~ .spectrum-Checkbox-label {
    color: var(--spectrum-checkbox-m-text-color-key-focus, var(--spectrum-alias-text-color-hover));
  }

.spectrum-Checkbox--emphasized
  .spectrum-Checkbox-input:checked
  + .spectrum-Checkbox-box:before, .spectrum-Checkbox--emphasized.is-indeterminate .spectrum-Checkbox-box:before, .spectrum-Checkbox--emphasized.is-indeterminate
  .spectrum-Checkbox-input.focus-ring
  + .spectrum-Checkbox-box:before {
    border-color: var(--spectrum-checkbox-m-emphasized-box-border-color-selected, var(--spectrum-global-color-blue-500));
  }

.spectrum-Checkbox--emphasized:hover.is-indeterminate .spectrum-Checkbox-box:before, .spectrum-Checkbox--emphasized:hover .spectrum-Checkbox-input:checked + .spectrum-Checkbox-box:before {
      border-color: var(--spectrum-checkbox-m-emphasized-box-border-color-selected-hover, var(--spectrum-global-color-blue-600));
    }

.spectrum-Checkbox--emphasized:active.is-indeterminate .spectrum-Checkbox-box:before, .spectrum-Checkbox--emphasized:active .spectrum-Checkbox-input:checked + .spectrum-Checkbox-box:before {
      border-color: var(--spectrum-checkbox-m-emphasized-box-border-color-selected-down, var(--spectrum-global-color-blue-700));
    }

.spectrum-Checkbox.is-invalid .spectrum-Checkbox-input:checked + .spectrum-Checkbox-box:before, .spectrum-Checkbox.is-invalid .spectrum-Checkbox-box:before {
      border-color: var(--spectrum-checkbox-m-box-border-color-error, var(--spectrum-global-color-red-500));
    }

.spectrum-Checkbox.is-invalid .spectrum-Checkbox-label {
    color: var(--spectrum-checkbox-m-text-color-error, var(--spectrum-global-color-red-600));
  }

.spectrum-Checkbox.is-invalid.is-indeterminate .spectrum-Checkbox-input.focus-ring + .spectrum-Checkbox-box:before, .spectrum-Checkbox.is-invalid .spectrum-Checkbox-input.focus-ring + .spectrum-Checkbox-box:before {
        border-color: var(--spectrum-checkbox-m-box-border-color-error-hover, var(--spectrum-global-color-red-600));
      }

.spectrum-Checkbox.is-invalid.is-indeterminate .spectrum-Checkbox-input.focus-ring ~ .spectrum-Checkbox-label, .spectrum-Checkbox.is-invalid .spectrum-Checkbox-input.focus-ring ~ .spectrum-Checkbox-label {
      color: var(--spectrum-checkbox-m-text-color-error-hover, var(--spectrum-global-color-red-700));
    }

.spectrum-Checkbox.is-invalid:hover .spectrum-Checkbox-input:checked + .spectrum-Checkbox-box:before, .spectrum-Checkbox.is-invalid:hover .spectrum-Checkbox-box:before {
        border-color: var(--spectrum-checkbox-m-box-border-color-error-hover, var(--spectrum-global-color-red-600));
      }

.spectrum-Checkbox.is-invalid:hover .spectrum-Checkbox-label {
      color: var(--spectrum-checkbox-m-text-color-error-hover, var(--spectrum-global-color-red-700));
    }

.spectrum-Checkbox.is-invalid:active .spectrum-Checkbox-input:checked + .spectrum-Checkbox-box:before, .spectrum-Checkbox.is-invalid:active .spectrum-Checkbox-box:before {
        border-color: var(--spectrum-checkbox-m-box-border-color-error-down, var(--spectrum-global-color-red-700));
      }

.spectrum-Checkbox.is-invalid:active .spectrum-Checkbox-label {
      color: var(--spectrum-checkbox-m-text-color-error-down, var(--spectrum-global-color-red-700));
    }

@media (forced-colors: active) {
    .spectrum-Checkbox-input.focus-ring + .spectrum-Checkbox-box {
      forced-color-adjust: none;
      outline-color: var(--spectrum-checkbox-m-focus-ring-color-key-focus, var(--spectrum-alias-focus-ring-color));
      outline-style: auto;
      outline-offset: var(--spectrum-checkbox-m-focus-ring-gap-key-focus, var(--spectrum-alias-focus-ring-gap));
      outline-width: var(--spectrum-checkbox-m-focus-ring-size-key-focus, var(--spectrum-alias-focus-ring-size));
    }

  .spectrum-Checkbox {
    --spectrum-checkbox-m-text-color-disabled: GrayText;
    --spectrum-checkbox-m-box-border-color-key-focus: FieldText;
    --spectrum-checkbox-m-box-border-color-selected-hover: Highlight;
    --spectrum-checkbox-m-emphasized-box-border-color-selected-hover: Highlight;
    --spectrum-checkbox-m-emphasized-box-border-color-selected: Highlight;
    --spectrum-checkbox-m-checkmark-color: HighlightText;
    --spectrum-checkbox-m-focus-ring-color-key-focus: Highlight;
    --spectrum-checkbox-m-focus-ring-gap-key-focus: var(--spectrum-global-dimension-static-size-25, 2px);
    --spectrum-checkbox-m-focus-ring-size-key-focus: var(--spectrum-global-dimension-static-size-40, 3px);
    --spectrum-checkbox-m-box-border-color-error: FieldText;
    --spectrum-checkbox-m-box-border-color-error-hover: FieldText;
    --spectrum-checkbox-m-text-color-error: FieldText;
  }
}
.spectrum-FieldGroup {
  --spectrum-fieldgroup-margin: var(--spectrum-global-dimension-size-200);
}

.spectrum-FieldGroup {
  display: -ms-flexbox;
  display: flex;
  vertical-align: top;
  -ms-flex-wrap: wrap;
      flex-wrap: wrap;
}

[dir="ltr"] .spectrum-FieldGroup--horizontal .spectrum-FieldGroup-item:not(:last-child) {
    margin-right: var(--spectrum-fieldgroup-margin);
}

[dir="rtl"] .spectrum-FieldGroup--horizontal .spectrum-FieldGroup-item:not(:last-child) {
    margin-left: var(--spectrum-fieldgroup-margin);
}

.spectrum-FieldGroup--vertical {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-direction: column;
      flex-direction: column;
}
.icon.svelte-19fatlf{position:absolute;margin:0 !important}.spectrum-Checkbox--sizeS.svelte-19fatlf i{font-size:12px}.spectrum-Checkbox--sizeM.svelte-19fatlf i{font-size:14px}.spectrum-Checkbox--sizeL.svelte-19fatlf i{font-size:16px}.spectrum-Checkbox--sizeXL.svelte-19fatlf i{font-size:18px}.spectrum-Checkbox-input.svelte-19fatlf{opacity:0}.readonly.svelte-19fatlf{pointer-events:none}.spectrum-InputGroup {
  --spectrum-combobox-quiet-fieldbutton-border-radius: 0;
  --spectrum-combobox-field-border-width-right: 0;

  --spectrum-inputgroup-generic-padding: var(--spectrum-global-dimension-size-150);

  --spectrum-datepicker-range-input-width-first: calc(var(--spectrum-global-dimension-size-1600) - 2 * var(--spectrum-inputgroup-generic-padding));
  --spectrum-datepicker-input-width: calc(var(--spectrum-datepicker-range-input-width-first) + var(--spectrum-icon-alert-medium-width, var(--spectrum-global-dimension-size-225)));
  --spectrum-datepicker-range-input-width-quiet-first: calc(var(--spectrum-global-dimension-size-900) + var(--spectrum-global-dimension-size-200));
  --spectrum-datepicker-input-width-quiet: calc(var(--spectrum-datepicker-range-input-width-quiet-first) + var(--spectrum-icon-alert-medium-width, var(--spectrum-global-dimension-size-225)));

  --spectrum-datepicker-datetime-input-width-first: calc(var(--spectrum-datepicker-input-width) + var(--spectrum-global-dimension-size-450));
  --spectrum-datepicker-datetime-input-width: calc(var(--spectrum-datepicker-datetime-input-width-first) + var(--spectrum-icon-alert-medium-width, var(--spectrum-global-dimension-size-225)));

  --spectrum-datepicker-datetime-quiet-input-width-first: calc(var(--spectrum-datepicker-input-width) + var(--spectrum-global-dimension-size-300));
  --spectrum-datepicker-datetime-quiet-input-width: calc(var(--spectrum-datepicker-datetime-quiet-input-width-first) + var(--spectrum-icon-alert-medium-width, var(--spectrum-global-dimension-size-225)));

  --spectrum-datepicker-range-dash-margin-left: calc(-0.5 * var(--spectrum-global-dimension-static-font-size-100, 14px));
  --spectrum-datepicker-range-dash-padding-top: 0;
  --spectrum-datepicker-range-dash-line-height: calc(var(--spectrum-textfield-m-height, var(--spectrum-alias-item-height-m)) - var(--spectrum-global-dimension-size-100));
  --spectrum-combobox-button-width: var(--spectrum-global-dimension-size-400);

  --spectrum-combobox-quiet-button-offset: calc(var(--spectrum-actionbutton-m-min-width, var(--spectrum-global-dimension-size-400)) / 2 - var(--spectrum-icon-chevron-down-medium-width) / 2);
}

.spectrum-InputGroup {
  position: relative;
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-direction: row;
      flex-direction: row;
  -ms-flex-wrap: nowrap;
      flex-wrap: nowrap;
  min-width: var(--spectrum-alias-single-line-width, var(--spectrum-global-dimension-size-2400));
  border-radius: var(--spectrum-alias-border-radius-regular, var(--spectrum-global-dimension-size-50));
}

[dir="ltr"] .spectrum-InputGroup .spectrum-InputGroup-button {
    border-top-left-radius: var(--spectrum-combobox-fieldbutton-border-top-left-radius, 0);
}

[dir="rtl"] .spectrum-InputGroup .spectrum-InputGroup-button {
    border-top-right-radius: var(--spectrum-combobox-fieldbutton-border-top-left-radius, 0);
}

[dir="ltr"] .spectrum-InputGroup .spectrum-InputGroup-button {
    border-bottom-left-radius: var(--spectrum-combobox-fieldbutton-border-bottom-left-radius, 0);
}

[dir="rtl"] .spectrum-InputGroup .spectrum-InputGroup-button {
    border-bottom-right-radius: var(--spectrum-combobox-fieldbutton-border-bottom-left-radius, 0);
}

.spectrum-InputGroup .spectrum-InputGroup-button {
    padding: 0;
    width: var(--spectrum-combobox-button-width);
  }

.spectrum-InputGroup .spectrum-InputGroup-input {
    width: auto;
  }

.spectrum-InputGroup-button {
  position: relative;
}

[dir="ltr"] .spectrum-InputGroup-input {
  border-top-right-radius: var(--spectrum-combobox-textfield-border-top-right-radius, 0);
}

[dir="rtl"] .spectrum-InputGroup-input {
  border-top-left-radius: var(--spectrum-combobox-textfield-border-top-right-radius, 0);
}

[dir="ltr"] .spectrum-InputGroup-input {
  border-bottom-right-radius: var(--spectrum-combobox-textfield-border-bottom-right-radius, 0);
}

[dir="rtl"] .spectrum-InputGroup-input {
  border-bottom-left-radius: var(--spectrum-combobox-textfield-border-bottom-right-radius, 0);
}

[dir="ltr"] .spectrum-InputGroup-input {
  border-right-width: var(--spectrum-combobox-field-border-width-right);
}

[dir="rtl"] .spectrum-InputGroup-input {
  border-left-width: var(--spectrum-combobox-field-border-width-right);
}

.spectrum-InputGroup-input {
  -ms-flex: 1;
      flex: 1;
}

.spectrum-InputGroup--quiet {
  border-radius: var(--spectrum-combobox-quiet-fieldbutton-border-radius);
}

[dir="ltr"] .spectrum-InputGroup--quiet .spectrum-InputGroup-button {

    padding-left: var(--spectrum-combobox-quiet-button-offset);
}

[dir="rtl"] .spectrum-InputGroup--quiet .spectrum-InputGroup-button {

    padding-right: var(--spectrum-combobox-quiet-button-offset);
}

[dir="ltr"] .spectrum-InputGroup--quiet .spectrum-InputGroup-button {
    padding-right: var(
      --spectrum-combobox-quiet-fieldbutton-padding-right
    );
}

[dir="rtl"] .spectrum-InputGroup--quiet .spectrum-InputGroup-button {
    padding-left: var(
      --spectrum-combobox-quiet-fieldbutton-padding-right
    );
}

[dir="ltr"] .spectrum-InputGroup--quiet .spectrum-InputGroup-button {
    border-left: 0;
}

[dir="rtl"] .spectrum-InputGroup--quiet .spectrum-InputGroup-button {
    border-right: 0;
}

[dir="ltr"] .spectrum-InputGroup--quiet .spectrum-InputGroup-button {
    border-right: 0;
}

[dir="rtl"] .spectrum-InputGroup--quiet .spectrum-InputGroup-button {
    border-left: 0;
}

.spectrum-InputGroup--quiet .spectrum-InputGroup-button {
    width: auto;
    position: relative;


    border-top: 0;
    border-bottom: var(--spectrum-textfield-quiet-m-border-size, var(--spectrum-alias-border-size-thin)) solid;
    border-radius: var(--spectrum-combobox-quiet-fieldbutton-border-radius);
  }

[dir="ltr"] .spectrum-InputGroup--quiet .spectrum-InputGroup-button:after {
      right: calc(var(--spectrum-combobox-quiet-button-offset) * -1);
}

[dir="rtl"] .spectrum-InputGroup--quiet .spectrum-InputGroup-button:after {
      left: calc(var(--spectrum-combobox-quiet-button-offset) * -1);
}

.spectrum-InputGroup--quiet .spectrum-InputGroup-button:after {
      content: "";
      position: absolute;
      height: 100%;
      width: var(--spectrum-combobox-quiet-button-offset);
    }

[dir="ltr"] .spectrum-InputGroup--quiet .spectrum-InputGroup-icon {
    right: 0;
}

[dir="rtl"] .spectrum-InputGroup--quiet .spectrum-InputGroup-icon {
    left: 0;
}

.spectrum-Datepicker--range {
  border-radius: var(--spectrum-alias-border-radius-regular, var(--spectrum-global-dimension-size-50));
}

.spectrum-Datepicker--range.spectrum-InputGroup--quiet {
    border-radius: var(--spectrum-combobox-quiet-fieldbutton-border-radius);
  }

.spectrum-Datepicker--range.spectrum-InputGroup--quiet .spectrum-InputGroup-textfield {
      min-width: 0;
      width: var(--spectrum-datepicker-input-width-quiet);
    }

.spectrum-Datepicker--range.spectrum-InputGroup--quiet .spectrum-InputGroup-textfield:first-of-type {
        width: var(--spectrum-datepicker-range-input-width-quiet-first);
      }

.spectrum-Datepicker--range.spectrum-InputGroup--quiet .spectrum-InputGroup-button {
      border-radius: var(--spectrum-combobox-quiet-fieldbutton-border-radius);
    }

.spectrum-Datepicker--range.spectrum-Datepicker--datetimeRange .spectrum-InputGroup-textfield {
      width: var(--spectrum-datepicker-datetime-input-width);
      min-width: 0;
    }

.spectrum-Datepicker--range.spectrum-Datepicker--datetimeRange .spectrum-InputGroup-textfield:first-of-type {
        width: var(--spectrum-datepicker-datetime-input-width-first);
      }

.spectrum-Datepicker--range.spectrum-Datepicker--datetimeRange.spectrum-InputGroup--quiet .spectrum-InputGroup-textfield {
        width: var(--spectrum-datepicker-datetime-quiet-input-width);
      }

.spectrum-Datepicker--range.spectrum-Datepicker--datetimeRange.spectrum-InputGroup--quiet .spectrum-InputGroup-textfield:first-of-type {
          width: var(
            --spectrum-datepicker-datetime-quiet-input-width-first
          );
        }

.spectrum-Datepicker--range .spectrum-InputGroup-textfield {
    -ms-flex: initial;
        flex: initial;
    min-width: 0;
    width: var(--spectrum-datepicker-input-width);
  }

.spectrum-Datepicker--range .spectrum-InputGroup-textfield:first-of-type {
      width: var(--spectrum-datepicker-range-input-width-first);
    }

[dir="ltr"] .spectrum-Datepicker--range .spectrum-InputGroup-textfield.is-invalid .spectrum-InputGroup-input {
        padding-right: var(--spectrum-inputgroup-generic-padding);
}

[dir="rtl"] .spectrum-Datepicker--range .spectrum-InputGroup-textfield.is-invalid .spectrum-InputGroup-input {
        padding-left: var(--spectrum-inputgroup-generic-padding);
}

.spectrum-Datepicker--range .spectrum-InputGroup-input {
    width: 100%;
  }

[dir="ltr"] .spectrum-Datepicker--range .spectrum-InputGroup-input.spectrum-Datepicker-startField {
      border-right: 0;
}

[dir="rtl"] .spectrum-Datepicker--range .spectrum-InputGroup-input.spectrum-Datepicker-startField {
      border-left: 0;
}

[dir="ltr"] .spectrum-Datepicker--range .spectrum-InputGroup-input.spectrum-Datepicker-startField {
      padding-right: var(--spectrum-inputgroup-generic-padding);
}

[dir="rtl"] .spectrum-Datepicker--range .spectrum-InputGroup-input.spectrum-Datepicker-startField {
      padding-left: var(--spectrum-inputgroup-generic-padding);
}

[dir="ltr"] .spectrum-Datepicker--range .spectrum-InputGroup-input.spectrum-Datepicker-endField {
      border-left: 0;
}

[dir="rtl"] .spectrum-Datepicker--range .spectrum-InputGroup-input.spectrum-Datepicker-endField {
      border-right: 0;
}

[dir="ltr"] .spectrum-Datepicker--range .spectrum-InputGroup-input.spectrum-Datepicker-endField {
      padding-left: var(--spectrum-inputgroup-generic-padding);
}

[dir="rtl"] .spectrum-Datepicker--range .spectrum-InputGroup-input.spectrum-Datepicker-endField {
      padding-right: var(--spectrum-inputgroup-generic-padding);
}

.spectrum-Datepicker--range .spectrum-InputGroup-input.spectrum-Datepicker-endField {
      border-radius: 0;
    }

.spectrum-Datepicker--range .spectrum-Datepicker-rangeDash {
    line-height: var(--spectrum-datepicker-range-dash-line-height);
    padding-top: var(--spectrum-datepicker-range-dash-padding-top);
    -ms-flex: initial;
        flex: initial;
    width: 0;
    z-index: 1;
  }

.spectrum-Datepicker--range .spectrum-Datepicker-rangeDash:before {
      content: "–";
      display: inline-block;
      margin-top: 0;
      margin-bottom: 0;
      margin-left: var(--spectrum-datepicker-range-dash-margin-left);
      margin-right: var(--spectrum-datepicker-range-dash-margin-left);
      overflow: hidden;
      text-align: center;
      vertical-align: middle;
      width: var(--spectrum-global-dimension-static-font-size-100, 14px);
    }

[dir="ltr"] .spectrum-Datepicker--range.spectrum-InputGroup--quiet .spectrum-Datepicker--rangeDash:before {
        margin-left: var(--spectrum-datepicker-range-dash-margin-left);
}

[dir="rtl"] .spectrum-Datepicker--range.spectrum-InputGroup--quiet .spectrum-Datepicker--rangeDash:before {
        margin-right: var(--spectrum-datepicker-range-dash-margin-left);
}

.spectrum-InputGroup.is-focused:not(.is-invalid) .spectrum-InputGroup-textfield .spectrum-InputGroup-input {
          border-color: var(--spectrum-textfield-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
        }

.spectrum-InputGroup.is-focused:not(.is-invalid) .spectrum-InputGroup-button {
        border-color: var(--spectrum-textfield-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
      }

.spectrum-InputGroup:hover:not(.is-focused):not(.is-keyboardFocused):not(.is-disabled) .spectrum-InputGroup-textfield .spectrum-InputGroup-input {
          border-color: var(--spectrum-textfield-m-border-color-hover, var(--spectrum-alias-border-color-hover));
        }

.spectrum-InputGroup:hover:not(.is-focused):not(.is-keyboardFocused):not(.is-disabled) .spectrum-InputGroup-button {
        border-color: var(--spectrum-textfield-m-border-color-hover, var(--spectrum-alias-border-color-hover));
      }

.spectrum-InputGroup:hover:not(.is-focused):not(.is-keyboardFocused):not(.is-disabled).is-invalid .spectrum-InputGroup-textfield .spectrum-InputGroup-input {
            border-color: var(--spectrum-textfield-m-border-color-error-hover, var(--spectrum-semantic-negative-color-state-hover));
          }

.spectrum-InputGroup:hover:not(.is-focused):not(.is-keyboardFocused):not(.is-disabled).is-invalid .spectrum-InputGroup-button {
          border-color: var(--spectrum-textfield-m-border-color-error-hover, var(--spectrum-semantic-negative-color-state-hover));
        }

.spectrum-InputGroup.is-disabled .spectrum-Datepicker-rangeDash {
      color: var(--spectrum-alias-text-color-disabled, var(--spectrum-global-color-gray-500));
    }

.spectrum-InputGroup.is-focused .spectrum-InputGroup-button,
  .spectrum-InputGroup.is-focused .spectrum-InputGroup-input {
    border-color: var(--spectrum-picker-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
  }

.spectrum-InputGroup.is-focused.is-invalid .spectrum-InputGroup-button,
    .spectrum-InputGroup.is-focused.is-invalid .spectrum-InputGroup-input {
      border-color: var(--spectrum-picker-m-border-color-error, var(--spectrum-global-color-red-500));
    }

.spectrum-InputGroup:not(.spectrum-InputGroup--quiet).is-keyboardFocused {
    box-shadow: 0 0 0 1px var(--spectrum-picker-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
  }

.spectrum-InputGroup:not(.spectrum-InputGroup--quiet).is-keyboardFocused .spectrum-InputGroup-input,
  .spectrum-InputGroup:not(.spectrum-InputGroup--quiet).is-keyboardFocused .spectrum-InputGroup-input.focus-ring {
    box-shadow: none ;
  }

.spectrum-InputGroup:not(.spectrum-InputGroup--quiet).is-keyboardFocused.is-invalid {
      box-shadow: 0 0 0 1px var(--spectrum-picker-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-InputGroup:not(.spectrum-InputGroup--quiet).is-keyboardFocused.is-invalid .spectrum-InputGroup-button,
    .spectrum-InputGroup:not(.spectrum-InputGroup--quiet).is-keyboardFocused.is-invalid .spectrum-InputGroup-input {
      border-color: var(--spectrum-picker-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-InputGroup:not(.spectrum-InputGroup--quiet).is-keyboardFocused .spectrum-InputGroup-button {
    box-shadow: none;
  }

.spectrum-InputGroup--quiet .spectrum-InputGroup-button,
    .spectrum-InputGroup--quiet .spectrum-InputGroup-button:hover,
    .spectrum-InputGroup--quiet .spectrum-InputGroup-button:focus,
    .spectrum-InputGroup--quiet .spectrum-InputGroup-button:active,
    .spectrum-InputGroup--quiet .spectrum-InputGroup-button.is-selected,
    .spectrum-InputGroup--quiet .spectrum-InputGroup-button.is-invalid {
      border-color: var(--spectrum-textfield-quiet-m-border-color, var(--spectrum-alias-border-color));
    }

.spectrum-InputGroup--quiet .spectrum-InputGroup-button:disabled,
    .spectrum-InputGroup--quiet .spectrum-InputGroup-button:disabled:hover {
      border-color: var(--spectrum-textfield-quiet-m-border-color-disabled, var(--spectrum-alias-border-color-mid));
    }

.spectrum-InputGroup--quiet:hover:not(.is-focused):not(.is-keyboardFocused):not(.is-disabled) .spectrum-InputGroup-input,
    .spectrum-InputGroup--quiet:hover:not(.is-focused):not(.is-keyboardFocused):not(.is-disabled) .spectrum-InputGroup-button {
      border-color: var(--spectrum-textfield-quiet-m-border-color-hover, var(--spectrum-alias-border-color-hover));
    }

.spectrum-InputGroup--quiet.is-invalid .spectrum-InputGroup-input,
    .spectrum-InputGroup--quiet.is-invalid .spectrum-InputGroup-button {
      border-color: var(--spectrum-textfield-quiet-m-border-color-error, var(--spectrum-semantic-negative-color-default));
    }

.spectrum-InputGroup--quiet.is-focused .spectrum-InputGroup-input,
    .spectrum-InputGroup--quiet.is-focused .spectrum-InputGroup-button {
      border-color: var(--spectrum-textfield-quiet-m-border-color-mouse-focus, var(--spectrum-alias-border-color-mouse-focus));
    }

.spectrum-InputGroup--quiet.is-focused.is-invalid .spectrum-InputGroup-input,
      .spectrum-InputGroup--quiet.is-focused.is-invalid .spectrum-InputGroup-button {
        border-color: var(--spectrum-textfield-quiet-m-border-color-error-mouse-focus, var(--spectrum-semantic-negative-color-state-hover));
      }

.spectrum-InputGroup--quiet.is-keyboardFocused .spectrum-InputGroup-input,
    .spectrum-InputGroup--quiet.is-keyboardFocused .spectrum-InputGroup-button {
      box-shadow: 0 1px 0 var(--spectrum-textfield-quiet-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
      border-color: var(--spectrum-textfield-quiet-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-InputGroup--quiet.is-keyboardFocused.is-invalid .spectrum-InputGroup-input,
      .spectrum-InputGroup--quiet.is-keyboardFocused.is-invalid .spectrum-InputGroup-button {
        box-shadow: 0 1px 0 var(--spectrum-picker-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
        border-color: var(--spectrum-picker-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
      }
.spectrum-Menu {
  --spectrum-menu-margin-x: var(--spectrum-global-dimension-size-40);
  --spectrum-listitem-heading-text-size: var(
    --spectrum-global-dimension-font-size-50
  );
  --spectrum-listitem-heading-text-font-weight: 400;
  --spectrum-listitem-heading-text-transform: uppercase;
  --spectrum-listitem-heading-letter-spacing: 0.06em;
  --spectrum-listitem-heading-margin: var(--spectrum-global-dimension-size-75) 0
    0 0;
  --spectrum-listitem-heading-padding: 0
    var(--spectrum-global-dimension-size-450) 0
    var(--spectrum-global-dimension-size-150);

  --spectrum-listitem-padding-y: var(
    --spectrum-global-dimension-size-85
  );

  --spectrum-listitem-icon-margin-top: var(
    --spectrum-global-dimension-size-50
  );
  --spectrum-listitem-label-line-height: 1.3;
  --spectrum-listitem-heading-line-height: var(--spectrum-alias-body-text-line-height, var(--spectrum-global-font-line-height-medium));
}

.spectrum-Menu {
  --spectrum-listitem-divider-size: var(--spectrum-listitem-m-divider-size, var(--spectrum-alias-border-size-thick));
  --spectrum-listitem-divider-padding: var(--spectrum-listitem-m-divider-padding, 3px);
  --spectrum-listitem-focus-indicator-size: var(--spectrum-listitem-m-focus-indicator-size, var(--spectrum-alias-border-size-thick));
  --spectrum-listitem-text-font-weight: var(--spectrum-listitem-m-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-listitem-text-size: var(--spectrum-listitem-m-text-size, var(--spectrum-alias-item-text-size-m));
  --spectrum-listitem-height: var(--spectrum-listitem-m-height, var(--spectrum-alias-item-height-m));
  --spectrum-listitem-icon-gap: var(--spectrum-listitem-m-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-m));
  --spectrum-listitem-padding-left: var(--spectrum-listitem-m-padding-left, var(--spectrum-alias-item-workflow-padding-left-m));
  --spectrum-listitem-padding-right: var(--spectrum-listitem-m-padding-right, var(--spectrum-alias-item-padding-m));
  --spectrum-listitem-thumbnail-padding-left: var(--spectrum-listitem-m-thumbnail-padding-left, var(--spectrum-alias-item-padding-m));
}

.spectrum-Menu {
  display: inline-block;

  box-sizing: border-box;

  margin-top: var(--spectrum-popover-padding-y, var(--spectrum-global-dimension-size-50));

  margin-bottom: var(--spectrum-popover-padding-y, var(--spectrum-global-dimension-size-50));
  margin-left: 0;
  margin-right: 0;
  padding: 0;

  list-style-type: none;

  overflow: auto;
}

.spectrum-Menu > .spectrum-Menu-sectionHeading {
    margin-top: var(--spectrum-menu-margin-x);
    margin-bottom: var(--spectrum-menu-margin-x);
  }

[dir="ltr"] .spectrum-Menu.is-selectable .spectrum-Menu-item {
      padding-right: var(
        --spectrum-listitem-selectable-padding-right
      );
}

[dir="rtl"] .spectrum-Menu.is-selectable .spectrum-Menu-item {
      padding-left: var(
        --spectrum-listitem-selectable-padding-right
      );
}

[dir="ltr"] .spectrum-Menu.is-selectable .spectrum-Menu-item.is-selected {
        padding-right: calc(var(--spectrum-listitem-padding-right) - var(--spectrum-popover-border-size, var(--spectrum-alias-border-size-thin)));
}

[dir="rtl"] .spectrum-Menu.is-selectable .spectrum-Menu-item.is-selected {
        padding-left: calc(var(--spectrum-listitem-padding-right) - var(--spectrum-popover-border-size, var(--spectrum-alias-border-size-thin)));
}

.spectrum-Menu-checkmark {
  transform: scale(1);
  opacity: 1;
}

[dir="ltr"] .spectrum-Menu-item {

  border-left: var(--spectrum-listitem-focus-indicator-size) solid
    transparent;
}

[dir="rtl"] .spectrum-Menu-item {

  border-right: var(--spectrum-listitem-focus-indicator-size) solid
    transparent;
}

.spectrum-Menu-item {
  cursor: pointer;
  position: relative;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-align: center;
      align-items: center;

  box-sizing: border-box;

  padding: var(--spectrum-listitem-padding-y)
    var(--spectrum-listitem-padding-right)
    var(--spectrum-listitem-padding-y)
    var(--spectrum-listitem-padding-left);

  margin: 0;

  min-height: var(--spectrum-listitem-height);

  font-size: var(--spectrum-listitem-text-size);
  font-weight: var(--spectrum-listitem-text-font-weight);
  font-style: normal;
  text-decoration: none;
}

.spectrum-Menu-item:focus {
    outline: none;
  }

[dir="ltr"] .spectrum-Menu-item.is-selected {
    padding-right: calc(var(--spectrum-listitem-padding-right) - var(--spectrum-popover-border-size, var(--spectrum-alias-border-size-thin)));
}

[dir="rtl"] .spectrum-Menu-item.is-selected {
    padding-left: calc(var(--spectrum-listitem-padding-right) - var(--spectrum-popover-border-size, var(--spectrum-alias-border-size-thin)));
}

.spectrum-Menu-item.is-selected .spectrum-Menu-checkmark {
      display: block;
    }

.spectrum-Menu-item .spectrum-Icon,
  .spectrum-Menu-item .spectrum-Menu-itemIcon {
    -ms-flex-negative: 0;
        flex-shrink: 0;
    -ms-flex-item-align: start;
        align-self: flex-start;
  }

[dir="ltr"] .spectrum-Menu-item .spectrum-Icon + .spectrum-Menu-itemLabel,[dir="ltr"] 
  .spectrum-Menu-item .spectrum-Menu-itemIcon + .spectrum-Menu-itemLabel {
    margin-left: var(--spectrum-listitem-icon-gap);
}

[dir="rtl"] .spectrum-Menu-item .spectrum-Icon + .spectrum-Menu-itemLabel,[dir="rtl"] 
  .spectrum-Menu-item .spectrum-Menu-itemIcon + .spectrum-Menu-itemLabel {
    margin-right: var(--spectrum-listitem-icon-gap);
}

.spectrum-Menu-item .spectrum-Icon + .spectrum-Menu-itemLabel,
  .spectrum-Menu-item .spectrum-Menu-itemIcon + .spectrum-Menu-itemLabel {

    width: calc(100% - var(--spectrum-icon-checkmark-medium-width) - var(--spectrum-listitem-icon-gap) - var(--spectrum-listitem-thumbnail-padding-left) - var(--spectrum-alias-workflow-icon-size-m, var(--spectrum-global-dimension-size-225)));
  }

.spectrum-Menu-itemLabel {
  -ms-flex: 1 1 auto;
      flex: 1 1 auto;
  line-height: var(--spectrum-listitem-label-line-height);
  -webkit-hyphens: auto;
      -ms-hyphens: auto;
          hyphens: auto;
  overflow-wrap: break-word;
  width: calc(100% - var(--spectrum-icon-checkmark-medium-width) - var(--spectrum-listitem-icon-gap));
}

.spectrum-Menu-itemLabel--wrapping {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
}

.spectrum-Menu-checkmark {
  display: none;
  -ms-flex-item-align: start;
      align-self: flex-start;
}

[dir="ltr"] .spectrum-Menu-checkmark,[dir="ltr"] 
.spectrum-Menu-chevron {
  margin-left: var(--spectrum-listitem-icon-gap);
}

[dir="rtl"] .spectrum-Menu-checkmark,[dir="rtl"] 
.spectrum-Menu-chevron {
  margin-right: var(--spectrum-listitem-icon-gap);
}

.spectrum-Menu-checkmark,
.spectrum-Menu-chevron {
  -ms-flex-positive: 0;
      flex-grow: 0;
  margin-top: var(--spectrum-listitem-icon-margin-top);
}

[dir="rtl"] .spectrum-Menu-chevron { transform: matrix(-1, 0, 0, 1, 0, 0) ; }

.spectrum-Menu-divider {
  box-sizing: content-box;
  overflow: visible;

  height: var(--spectrum-listitem-divider-size);
  margin-top: calc(var(--spectrum-listitem-divider-padding) / 2);
  margin-bottom: calc(var(--spectrum-listitem-divider-padding) / 2);
  margin-left: var(--spectrum-listitem-padding-y);
  margin-right: var(--spectrum-listitem-padding-y);
  padding: 0;
  border: none;
}

.spectrum-Menu-sectionHeading {
  display: block;
  margin: var(--spectrum-listitem-heading-margin);
  padding: var(--spectrum-listitem-heading-padding);

  font-size: var(--spectrum-listitem-heading-text-size);
  font-weight: var(--spectrum-listitem-heading-text-font-weight);
  line-height: var(--spectrum-listitem-heading-line-height);
  text-transform: var(--spectrum-listitem-heading-text-transform);
  letter-spacing: var(--spectrum-listitem-heading-letter-spacing);
}

.spectrum-Menu .spectrum-Menu {
  display: block;
}

.spectrum-Menu {
  --spectrum-listheading-text-color: var(--spectrum-global-color-gray-700);
}

.spectrum-Menu {
  background-color: var(--spectrum-listitem-m-background-color, var(--spectrum-alias-background-color-transparent));
}

.spectrum-Menu-item {
  background-color: var(--spectrum-listitem-m-background-color, var(--spectrum-alias-background-color-transparent));
  color: var(--spectrum-listitem-m-text-color, var(--spectrum-alias-text-color));
}

[dir="ltr"] .spectrum-Menu-item.focus-ring,[dir="ltr"] 
  .spectrum-Menu-item.is-focused {
    border-left-color: var(--spectrum-listitem-m-focus-indicator-color, var(--spectrum-alias-border-color-focus));
}

[dir="rtl"] .spectrum-Menu-item.focus-ring,[dir="rtl"] 
  .spectrum-Menu-item.is-focused {
    border-right-color: var(--spectrum-listitem-m-focus-indicator-color, var(--spectrum-alias-border-color-focus));
}

.spectrum-Menu-item.focus-ring,
  .spectrum-Menu-item.is-focused {
    background-color: var(--spectrum-listitem-m-background-color-key-focus, var(--spectrum-alias-background-color-hover-overlay));
    color: var(--spectrum-listitem-m-text-color-key-focus, var(--spectrum-alias-text-color));
  }

.spectrum-Menu-item:hover,
  .spectrum-Menu-item:focus,
  .spectrum-Menu-item.is-highlighted,
  .spectrum-Menu-item.is-open {
    background-color: var(--spectrum-listitem-m-background-color-hover, var(--spectrum-alias-background-color-hover-overlay));
    color: var(--spectrum-listitem-m-text-color-hover, var(--spectrum-alias-text-color));
  }

.spectrum-Menu-item.is-selected {
    color: var(--spectrum-listitem-m-text-color-selected, var(--spectrum-alias-text-color));
  }

.spectrum-Menu-item.is-selected .spectrum-Menu-checkmark {
      color: var(--spectrum-listitem-m-icon-color-selected, var(--spectrum-alias-icon-color-selected));
    }

.spectrum-Menu-item .is-active,
  .spectrum-Menu-item:active {
    background-color: var(--spectrum-listitem-m-background-color-down, var(--spectrum-alias-background-color-hover-overlay));
  }

.spectrum-Menu-item.is-disabled {
    background-color: var(--spectrum-listitem-m-background-color-disabled, var(--spectrum-alias-background-color-transparent));
    background-image: none;
    color: var(--spectrum-listitem-m-text-color-disabled, var(--spectrum-alias-text-color-disabled));
    cursor: default;
  }

.spectrum-Menu-sectionHeading {
  color: var(--spectrum-listheading-text-color);
}

.spectrum-Menu-divider {
  background-color: var(--spectrum-listitem-m-divider-color, var(--spectrum-alias-border-color-extralight));
}
.spectrum-Popover {
  --spectrum-overlay-animation-distance: var(--spectrum-picker-m-popover-offset-y, var(--spectrum-global-dimension-size-75));

  visibility: hidden;

  opacity: 0;

  transition: transform var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
              opacity var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
              visibility 0ms linear var(--spectrum-global-animation-duration-100, 130ms);

  pointer-events: none;
}

.spectrum-Popover.is-open {
  visibility: visible;

  opacity: 1;

  transition-delay: 0ms;

  pointer-events: auto;
}

.spectrum-Popover--bottom.is-open {
  transform: translateY(var(--spectrum-overlay-animation-distance));
}

.spectrum-Popover--top.is-open {
  transform: translateY(calc(-1 * var(--spectrum-overlay-animation-distance)));
}

.spectrum-Popover--right.is-open {
  transform: translateX(var(--spectrum-overlay-animation-distance));
}

.spectrum-Popover--left.is-open {
  transform: translateX(calc(-1 * var(--spectrum-overlay-animation-distance)));
}

.spectrum-Popover {
  --spectrum-popover-target-offset: 13px;
  --spectrum-popover-dialog-padding: 30px 29px;
  --spectrum-popover-dialog-min-width: 270px;

  --spectrum-popover-min-width: var(--spectrum-global-dimension-size-400);
  --spectrum-popover-min-height: var(--spectrum-global-dimension-size-400);
}

.spectrum-Popover {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-direction: column;
      flex-direction: column;
  box-sizing: border-box;

  min-width: var(--spectrum-popover-min-width, var(--spectrum-global-dimension-size-400));
  min-height: var(--spectrum-popover-min-height, var(--spectrum-global-dimension-size-400));

  position: absolute;

  border-style: solid;
  border-width: var(--spectrum-popover-border-size, var(--spectrum-alias-border-size-thin));
  border-radius: var(--spectrum-popover-border-radius, var(--spectrum-alias-border-radius-regular));

  outline: none;
  box-sizing: border-box;
}

.spectrum-Popover-tip {
  position: absolute;
  -webkit-transform: translate(0, 0);
}

.spectrum-Popover-tip .spectrum-Popover-tip-triangle {
    stroke-linecap: square;
    stroke-linejoin: miter;
    stroke-width: var(--spectrum-popover-border-size, var(--spectrum-alias-border-size-thin));
  }

.spectrum-Popover--dialog {
  min-width: var(--spectrum-popover-dialog-min-width);
  padding: var(--spectrum-popover-dialog-padding);
}

.spectrum-Popover--left.spectrum-Popover--withTip {
    margin-right: var(--spectrum-popover-target-offset);
  }

.spectrum-Popover--left .spectrum-Popover-tip {
    left: 100%;
  }

.spectrum-Popover--right.spectrum-Popover--withTip {
    margin-left: var(--spectrum-popover-target-offset);
  }

.spectrum-Popover--right .spectrum-Popover-tip {
    right: 100%;
    transform: scaleX(-1);
  }

.spectrum-Popover--left .spectrum-Popover-tip, .spectrum-Popover--right .spectrum-Popover-tip {
    top: 50%;
    margin-top: calc(var(--spectrum-global-dimension-size-150) * -1);
  }

.spectrum-Popover--bottom.spectrum-Popover--withTip {
    margin-top: var(--spectrum-popover-target-offset);
  }

.spectrum-Popover--bottom .spectrum-Popover-tip {
    bottom: 100%;
    transform: scaleY(-1);
  }

.spectrum-Popover--top.spectrum-Popover--withTip {
    margin-bottom: var(--spectrum-popover-target-offset);
  }

.spectrum-Popover--top .spectrum-Popover-tip {
    top: 100%;
  }

.spectrum-Popover--bottom .spectrum-Popover-tip, .spectrum-Popover--top .spectrum-Popover-tip {
    left: 50%;
    margin-left: calc(var(--spectrum-global-dimension-size-150) * -1);
  }

.spectrum-Popover {
  background-color: var(--spectrum-popover-background-color, var(--spectrum-global-color-gray-50));
  border-color: var(--spectrum-popover-border-color, var(--spectrum-alias-border-color-dark));
  filter: drop-shadow(0 1px 4px var(--spectrum-popover-shadow-color, var(--spectrum-alias-dropshadow-color)));
  -webkit-filter: drop-shadow(0 1px 4px var(--spectrum-popover-shadow-color, var(--spectrum-alias-dropshadow-color)));
  will-change: filter;
  -webkit-clip-path: inset(-30px -30px);
          clip-path: inset(-30px -30px);
}

.spectrum-Popover .spectrum-Popover-tip .spectrum-Popover-tip-triangle {
      fill: var(--spectrum-popover-background-color, var(--spectrum-global-color-gray-50));
      stroke: var(--spectrum-popover-border-color, var(--spectrum-alias-border-color-dark));
    }
.spectrum-Popover.svelte-z8qspy{min-width:var(--spectrum-global-dimension-size-2000);border-color:var(--spectrum-global-color-gray-200);overflow:auto;transition:opacity 260ms ease-out;filter:none;-webkit-filter:none;box-shadow:0 1px 4px var(--drop-shadow)}.blockPointerEvents.svelte-z8qspy{pointer-events:none}.hidden.svelte-z8qspy{opacity:0;pointer-events:none}.customZIndex.svelte-z8qspy{z-index:var(--customZIndex) !important}.spectrum-InputGroup.svelte-g074q3.svelte-g074q3{min-width:0;width:100%}.spectrum-Textfield.svelte-g074q3.svelte-g074q3{width:100%}.spectrum-Textfield-input.svelte-g074q3.svelte-g074q3{width:0}.check.svelte-g074q3.svelte-g074q3{display:none}li.is-selected.svelte-g074q3 .check.svelte-g074q3{display:block}.popover-content.svelte-g074q3.svelte-g074q3{display:contents}.popover-content.svelte-g074q3:not(.auto-width) .spectrum-Menu-itemLabel.svelte-g074q3{width:0;flex:1 1 auto}/*!
Copyright 2023 Adobe. All rights reserved.
This file is licensed to you under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License. You may obtain a copy
of the License at http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under
the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
OF ANY KIND, either express or implied. See the License for the specific language
governing permissions and limitations under the License.
*/

.spectrum-Calendar{
  --spectrum-calendar-border-radius-reset:0;
  --spectrum-calendar-border-width-reset:0;
  --spectrum-calendar-margin-y:24px;
  --spectrum-calendar-margin-x:32px;
  --spectrum-calendar-width:calc((var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400)) + var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50)) * 2) * 7);
  --spectrum-calendar-button-gap:var(--spectrum-global-dimension-size-40);
  --spectrum-calendar-title-text-letter-spacing:var(--spectrum-detail-m-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
}

.spectrum-Calendar{
  width:var(--spectrum-calendar-width, 250px);
  display:inline-block;
}

.spectrum-Calendar--padded{
  margin:var(--spectrum-calendar-margin-x) var(--spectrum-calendar-margin-y);
}

.spectrum-Calendar-header{
  display:flex;
  width:100%;
  align-items:center;
}

.spectrum-Calendar-title{
  font-size:var(--spectrum-calendar-title-text-size, var(--spectrum-global-dimension-font-size-300));
  font-weight:bold;

  line-height:var(--spectrum-calendar-title-height, var(--spectrum-global-dimension-static-size-400));
  margin:0;
  order:1;
  flex-grow:1;

  text-align:center;
  overflow:hidden;
  white-space:nowrap;
  text-overflow:ellipsis;
}

[dir="ltr"] .spectrum-Calendar .spectrum-Calendar-prevMonth,[dir="ltr"] 
  .spectrum-Calendar .spectrum-Calendar-nextMonth,[dir="rtl"] 
  .spectrum-Calendar .spectrum-Calendar-prevMonth,[dir="rtl"] 
  .spectrum-Calendar .spectrum-Calendar-nextMonth{
    margin:0 var(--spectrum-calendar-button-gap);
  }

[dir="rtl"] .spectrum-Calendar-prevMonth,[dir="rtl"] 
.spectrum-Calendar-nextMonth{ transform:matrix(-1, 0, 0, 1, 0, 0); }

.spectrum-Calendar-prevMonth{
  order:0;
}

.spectrum-Calendar-nextMonth{
  order:2;
}

.spectrum-Calendar-dayOfWeek{
  display:flex;
  flex-direction:column;
  justify-content:flex-end;
  height:100%;

  width:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));

  border-bottom:none !important;

  font-size:var(--spectrum-calendar-day-title-text-size, var(--spectrum-global-dimension-font-size-50));
  font-weight:var(--spectrum-calendar-day-title-text-font-weight, var(--spectrum-alias-detail-text-font-weight-regular));
  text-transform:uppercase;
  text-decoration:none !important;

  cursor:default;
}

.spectrum-Calendar-dayOfWeek[title]{
    border-bottom:none;
    text-decoration:underline;
    text-decoration:underline dotted;
    letter-spacing:var(--spectrum-calendar-title-text-letter-spacing);
  }

.spectrum-Calendar-body{
  outline:none;
}

.spectrum-Calendar-table{
  table-layout:fixed;

  border-collapse:collapse;
  border-spacing:0;

  -webkit-user-select:none;
  user-select:none;
}

.spectrum-Calendar-tableCell{
  text-align:center;
  padding:0;
  position:relative;
  box-sizing:content-box;
  height:var(--spectrum-calendar-day-height, var(--spectrum-global-dimension-size-400));
  width:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
  padding:var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50));
}

.spectrum-Calendar-tableCell:focus{
    outline:0;
  }

[dir="ltr"] .spectrum-Calendar-date{
  left:0;
}

[dir="rtl"] .spectrum-Calendar-date{
  right:0;
}

.spectrum-Calendar-date{
  position:absolute;
  display:block;
  top:0;

  box-sizing:border-box;

  height:var(--spectrum-calendar-day-height, var(--spectrum-global-dimension-size-400));
  width:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
  margin:var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50));

  border-radius:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
  border:var(--spectrum-calendar-day-border-size, var(--spectrum-alias-border-size-thick)) solid transparent;

  font-size:var(--spectrum-calendar-day-text-size, var(--spectrum-alias-font-size-default));
  line-height:calc(var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400)) - var(--spectrum-calendar-day-border-size, var(--spectrum-alias-border-size-thick)) * 2);
  white-space:nowrap;

  cursor:pointer;
}

.spectrum-Calendar-date:lang(ja),
  .spectrum-Calendar-date:lang(zh),
  .spectrum-Calendar-date:lang(ko){
    font-size:var(--spectrum-calendar-day-text-size-han, var(--spectrum-global-dimension-font-size-50));
  }

.spectrum-Calendar-date.is-disabled{
    cursor:default;
    pointer-events:none;
  }

.spectrum-Calendar-date.is-outsideMonth{
    visibility:hidden;
  }

[dir="ltr"] .spectrum-Calendar-date:before{
    left:calc(50% - var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400)) / 2);
}

[dir="rtl"] .spectrum-Calendar-date:before{
    right:calc(50% - var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400)) / 2);
}

.spectrum-Calendar-date:before{
    content:"";
    position:absolute;
    top:calc(50% - var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400)) / 2);
    box-sizing:border-box;
    width:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
    height:var(--spectrum-calendar-day-height, var(--spectrum-global-dimension-size-400));
    border-radius:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
    border:var(--spectrum-calendar-day-border-size, var(--spectrum-alias-border-size-thick)) solid transparent;
  }

.spectrum-Calendar-date.is-selected:not(.is-range-selection){
    font-weight:var(--spectrum-calendar-day-text-font-weight-selected, var(--spectrum-global-font-weight-bold));
  }

.spectrum-Calendar-date.is-selected:not(.is-range-selection):before{
      display:none;
    }

.spectrum-Calendar-date.is-today{
    font-weight:var(--spectrum-calendar-day-today-text-font-weight, var(--spectrum-global-font-weight-bold));
  }

.spectrum-Calendar-date.is-range-selection{
    margin:var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50)) 0;
    border-width:var(--spectrum-calendar-border-width-reset);
    line-height:var(--spectrum-calendar-day-height, var(--spectrum-global-dimension-size-400));
    border-radius:var(--spectrum-calendar-border-radius-reset);
    width:calc(var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400)) + var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50)) * 2);
  }

.spectrum-Calendar-date.is-range-selection.is-range-start,
    .spectrum-Calendar-date.is-range-selection.is-range-end,
    .spectrum-Calendar-date.is-range-selection.is-selection-start,
    .spectrum-Calendar-date.is-range-selection.is-selection-end{
      width:calc(var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400)) + var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50)));
    }

.spectrum-Calendar-date.is-range-selection.is-selection-start,
    .spectrum-Calendar-date.is-range-selection.is-selection-end{
      font-weight:var(--spectrum-calendar-day-text-font-weight-cap-selected, var(--spectrum-global-font-weight-bold));
    }

.spectrum-Calendar-date.is-range-selection.is-selection-start:after, .spectrum-Calendar-date.is-range-selection.is-selection-end:after{
        position:absolute;
        top:0;

        display:block;

        height:var(--spectrum-calendar-day-height, var(--spectrum-global-dimension-size-400));
        width:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));

        border-radius:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));

        content:"";
      }

[dir="ltr"] .spectrum-Calendar-date.is-range-selection.is-range-start,[dir="ltr"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-start{
      padding-right:var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50));
}

[dir="rtl"] .spectrum-Calendar-date.is-range-selection.is-range-start,[dir="rtl"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-start{
      padding-left:var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50));
}

[dir="ltr"] .spectrum-Calendar-date.is-range-selection.is-range-start,[dir="ltr"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-start{
      margin-left:var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50));
}

[dir="rtl"] .spectrum-Calendar-date.is-range-selection.is-range-start,[dir="rtl"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-start{
      margin-right:var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50));
}

[dir="ltr"] .spectrum-Calendar-date.is-range-selection.is-range-start,[dir="ltr"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-start{
      border-top-left-radius:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
}

[dir="rtl"] .spectrum-Calendar-date.is-range-selection.is-range-start,[dir="rtl"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-start{
      border-top-right-radius:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
}

[dir="ltr"] .spectrum-Calendar-date.is-range-selection.is-range-start,[dir="ltr"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-start{
      border-bottom-left-radius:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
}

[dir="rtl"] .spectrum-Calendar-date.is-range-selection.is-range-start,[dir="rtl"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-start{
      border-bottom-right-radius:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
}

[dir="ltr"] .spectrum-Calendar-date.is-range-selection.is-range-start:before,[dir="ltr"] 
      .spectrum-Calendar-date.is-range-selection.is-range-start:after,[dir="ltr"] 
      .spectrum-Calendar-date.is-range-selection.is-selection-start:before,[dir="ltr"] 
      .spectrum-Calendar-date.is-range-selection.is-selection-start:after{
        left:0;
}

[dir="rtl"] .spectrum-Calendar-date.is-range-selection.is-range-start:before,[dir="rtl"] 
      .spectrum-Calendar-date.is-range-selection.is-range-start:after,[dir="rtl"] 
      .spectrum-Calendar-date.is-range-selection.is-selection-start:before,[dir="rtl"] 
      .spectrum-Calendar-date.is-range-selection.is-selection-start:after{
        right:0;
}

[dir="ltr"] .spectrum-Calendar-date.is-range-selection.is-range-end,[dir="ltr"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-end{
      padding-left:var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50));
}

[dir="rtl"] .spectrum-Calendar-date.is-range-selection.is-range-end,[dir="rtl"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-end{
      padding-right:var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50));
}

[dir="ltr"] .spectrum-Calendar-date.is-range-selection.is-range-end,[dir="ltr"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-end{
      margin-right:var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50));
}

[dir="rtl"] .spectrum-Calendar-date.is-range-selection.is-range-end,[dir="rtl"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-end{
      margin-left:var(--spectrum-calendar-day-padding, var(--spectrum-global-dimension-static-size-50));
}

[dir="ltr"] .spectrum-Calendar-date.is-range-selection.is-range-end,[dir="ltr"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-end{
      border-top-right-radius:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
}

[dir="rtl"] .spectrum-Calendar-date.is-range-selection.is-range-end,[dir="rtl"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-end{
      border-top-left-radius:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
}

[dir="ltr"] .spectrum-Calendar-date.is-range-selection.is-range-end,[dir="ltr"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-end{
      border-bottom-right-radius:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
}

[dir="rtl"] .spectrum-Calendar-date.is-range-selection.is-range-end,[dir="rtl"] 
    .spectrum-Calendar-date.is-range-selection.is-selection-end{
      border-bottom-left-radius:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
}

[dir="ltr"] .spectrum-Calendar-date.is-range-selection.is-range-end:before,[dir="ltr"] 
      .spectrum-Calendar-date.is-range-selection.is-range-end:after,[dir="ltr"] 
      .spectrum-Calendar-date.is-range-selection.is-selection-end:before,[dir="ltr"] 
      .spectrum-Calendar-date.is-range-selection.is-selection-end:after{
        left:auto;
}

[dir="rtl"] .spectrum-Calendar-date.is-range-selection.is-range-end:before,[dir="rtl"] 
      .spectrum-Calendar-date.is-range-selection.is-range-end:after,[dir="rtl"] 
      .spectrum-Calendar-date.is-range-selection.is-selection-end:before,[dir="rtl"] 
      .spectrum-Calendar-date.is-range-selection.is-selection-end:after{
        right:auto;
}

[dir="ltr"] .spectrum-Calendar-date.is-range-selection.is-range-end:before,[dir="ltr"] 
      .spectrum-Calendar-date.is-range-selection.is-range-end:after,[dir="ltr"] 
      .spectrum-Calendar-date.is-range-selection.is-selection-end:before,[dir="ltr"] 
      .spectrum-Calendar-date.is-range-selection.is-selection-end:after{
        right:0;
}

[dir="rtl"] .spectrum-Calendar-date.is-range-selection.is-range-end:before,[dir="rtl"] 
      .spectrum-Calendar-date.is-range-selection.is-range-end:after,[dir="rtl"] 
      .spectrum-Calendar-date.is-range-selection.is-selection-end:before,[dir="rtl"] 
      .spectrum-Calendar-date.is-range-selection.is-selection-end:after{
        left:0;
}

.spectrum-Calendar-date.is-range-selection.is-selection-start.is-selection-end,
    .spectrum-Calendar-date.is-range-selection.is-selection-start.is-range-end,
    .spectrum-Calendar-date.is-range-selection.is-selection-end.is-range-start,
    .spectrum-Calendar-date.is-range-selection.is-range-start.is-range-end{
      width:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
      border-radius:var(--spectrum-calendar-day-width, var(--spectrum-global-dimension-size-400));
    }

.spectrum-Calendar-prevMonth{
  color:var(--spectrum-calendar-button-icon-color, var(--spectrum-global-color-gray-700));
}

.spectrum-Calendar-nextMonth{
  color:var(--spectrum-calendar-button-icon-color, var(--spectrum-global-color-gray-700));
}

.spectrum-Calendar-dayOfWeek{
  color:var(--spectrum-calendar-day-title-text-color, var(--spectrum-global-color-gray-700));
}

.spectrum-Calendar-date:hover{
    color:var(--spectrum-calendar-day-text-color-hover, var(--spectrum-alias-text-color-hover));
  }

.spectrum-Calendar-date:hover:not(.is-selection-end):not(.is-selection-start):before{
        background:var(--spectrum-calendar-day-background-color-hover, var(--spectrum-alias-highlight-hover));
      }

.spectrum-Calendar-date:hover.is-selected{
      color:var(--spectrum-calendar-day-text-color-selected-hover, var(--spectrum-alias-text-color-hover));
    }

.spectrum-Calendar-date:hover.is-selected:not(.is-selection-end):not(.is-selection-start):before{
          background:var(--spectrum-calendar-day-background-color-selected-hover, var(--spectrum-alias-highlight-selected-hover));
        }

.spectrum-Calendar-date:hover.is-range-selection:before{
        background:var(--spectrum-calendar-day-background-color-selected-hover, var(--spectrum-alias-highlight-selected-hover));
      }

.spectrum-Calendar-date:active{
    background-color:var(--spectrum-calendar-day-background-color-down, var(--spectrum-alias-highlight-down));
  }

.spectrum-Calendar-date.is-selected{
    color:var(--spectrum-calendar-day-text-color-selected, var(--spectrum-alias-text-color-hover));
    background:var(--spectrum-calendar-day-background-color-selected, var(--spectrum-alias-highlight-selected));
  }

.spectrum-Calendar-date.is-selected:not(.is-range-selection){
    background:var(--spectrum-calendar-day-background-color-cap-selected, var(--spectrum-alias-highlight-selected-hover));
  }

.spectrum-Calendar-date.is-today{
    color:var(--spectrum-calendar-day-today-text-color, var(--spectrum-alias-text-color));
    border-color:var(--spectrum-calendar-day-today-border-color, var(--spectrum-global-color-gray-800));
  }

.spectrum-Calendar-date.is-today:before{
      border-color:var(--spectrum-calendar-day-today-border-color, var(--spectrum-global-color-gray-800));
    }

.spectrum-Calendar-date.is-today:hover.is-selected:not(.is-range-selection):before{
          background:var(--spectrum-calendar-day-today-background-color-selected-hover, var(--spectrum-alias-highlight-selected-hover));
        }

.spectrum-Calendar-date.is-today.is-disabled{
      color:var(--spectrum-calendar-day-today-text-color-disabled, var(--spectrum-alias-text-color-disabled));
      border-color:var(--spectrum-calendar-day-today-border-color-disabled, var(--spectrum-global-color-gray-400));
    }

.spectrum-Calendar-date.is-today.is-disabled:before{
        border-color:var(--spectrum-calendar-day-today-border-color-disabled, var(--spectrum-global-color-gray-400));
      }

.spectrum-Calendar-date.is-focused:not(.is-range-selection){
    background:var(--spectrum-calendar-day-background-color-key-focus, var(--spectrum-alias-highlight-hover));
    border-color:var(--spectrum-calendar-day-border-color-key-focus, var(--spectrum-alias-focus-color));
    color:var(--spectrum-calendar-day-text-color-key-focus, var(--spectrum-alias-text-color-hover));
  }

.spectrum-Calendar-date.is-focused:not(.is-range-selection).is-today{
      border-color:var(--spectrum-calendar-day-border-color-key-focus, var(--spectrum-alias-focus-color));
    }

.spectrum-Calendar-date.is-focused:not(.is-range-selection):active,
    .spectrum-Calendar-date.is-focused:not(.is-range-selection).is-selected{
      color:var(--spectrum-calendar-day-text-color-selected, var(--spectrum-alias-text-color-hover));
      background:var(--spectrum-calendar-day-background-color-cap-selected, var(--spectrum-alias-highlight-selected-hover));
      border-color:var(--spectrum-calendar-day-border-color-key-focus, var(--spectrum-alias-focus-color));
    }

.spectrum-Calendar-date.is-focused.is-selected:before{
        background:var(--spectrum-calendar-day-background-color-selected-hover, var(--spectrum-alias-highlight-selected-hover));
      }

.spectrum-Calendar-date.is-focused.is-range-selection:before{
        background:var(--spectrum-calendar-day-background-color-selected-hover, var(--spectrum-alias-highlight-selected-hover));
      }

.spectrum-Calendar-date.is-focused:before{
      border-color:var(--spectrum-calendar-day-border-color-key-focus, var(--spectrum-alias-focus-color));
    }

.spectrum-Calendar-date.is-disabled{
    color:var(--spectrum-calendar-day-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }

.spectrum-Calendar-date.is-selection-start,
  .spectrum-Calendar-date.is-selection-end{
    color:var(--spectrum-calendar-day-text-color-cap-selected, var(--spectrum-alias-text-color-hover));
  }

.spectrum-Calendar-date.is-selection-start:after, .spectrum-Calendar-date.is-selection-end:after{
      background-color:var(--spectrum-calendar-day-background-color-selected, var(--spectrum-alias-highlight-selected));
    }

.spectrum-Calendar-date.is-selection-start.is-disabled, .spectrum-Calendar-date.is-selection-end.is-disabled{
      color:var(--spectrum-calendar-day-text-color-disabled, var(--spectrum-alias-text-color-disabled));
    }

@media (forced-colors: active){
  .spectrum-Calendar-date{
    color:CanvasText;
    forced-color-adjust:none;
    --spectrum-calendar-button-icon-color:ButtonText;
    --spectrum-calendar-day-background-color-cap-selected:Highlight;
    --spectrum-calendar-day-background-color-down:ButtonFace;
    --spectrum-calendar-day-background-color-hover:Transparent;
    --spectrum-calendar-day-background-color-key-focus:ButtonFace;
    --spectrum-calendar-day-background-color-selected-hover:Transparent;
    --spectrum-calendar-day-background-color-selected:Highlight;
    --spectrum-calendar-day-border-color-key-focus:ButtonText;
    --spectrum-calendar-day-text-color-cap-selected:HighlightText;
    --spectrum-calendar-day-text-color-disabled:GrayText;
    --spectrum-calendar-day-text-color-hover:ButtonText;
    --spectrum-calendar-day-text-color-key-focus:ButtonText;
    --spectrum-calendar-day-text-color-selected-hover:HighlightText;
    --spectrum-calendar-day-text-color-selected:HighlightText;
    --spectrum-calendar-day-title-text-color:CanvasText;
    --spectrum-calendar-day-today-background-color-selected-hover:Highlight;
    --spectrum-calendar-day-today-border-color-disabled:GrayText;
    --spectrum-calendar-day-today-border-color:ButtonText;
    --spectrum-calendar-day-today-text-color-disabled:GrayText;
    --spectrum-calendar-day-today-text-color:ButtonText;
  }
    .spectrum-Calendar-date.is-range-selection{
      color:HighlightText;
    }
        .spectrum-Calendar-date.is-range-selection.is-selection-start:after, .spectrum-Calendar-date.is-range-selection.is-selection-end:after{
          content:none;
        }
      .spectrum-Calendar-date.is-disabled.is-range-selection{
        background:Highlight;
        color:HighlightText;
      }

      .spectrum-Calendar-date.is-disabled.is-selected{
        background:Highlight;
        color:HighlightText;
      }
      .spectrum-Calendar-date:hover.is-today{
        color:ButtonText;
      }
}
.spectrum-Textfield {
  --spectrum-textfield-border-size: var(--spectrum-textfield-m-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-textfield-text-line-height: var(--spectrum-textfield-m-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-textfield-text-size: var(--spectrum-textfield-m-text-size, var(--spectrum-alias-item-text-size-m));
  --spectrum-textfield-height: var(--spectrum-textfield-m-height, var(--spectrum-alias-item-height-m));
  --spectrum-textfield-padding-left: var(--spectrum-textfield-m-padding-left, var(--spectrum-alias-item-padding-m));
  --spectrum-textfield-padding-right: var(--spectrum-textfield-m-padding-right, var(--spectrum-alias-item-padding-m));
  --spectrum-textfield-min-width: var(--spectrum-textfield-m-min-width, var(--spectrum-global-dimension-size-600));
  --spectrum-textfield-success-icon-height: var(--spectrum-textfield-m-success-icon-height, var(--spectrum-alias-ui-icon-checkmark-size-100));
  --spectrum-textfield-success-icon-width: var(--spectrum-textfield-m-success-icon-width, var(--spectrum-alias-ui-icon-checkmark-size-100));
  --spectrum-textfield-success-icon-margin-left: var(--spectrum-textfield-m-success-icon-margin-left, var(--spectrum-global-dimension-size-150));
  --spectrum-textfield-error-icon-height: var(--spectrum-textfield-m-error-icon-height, var(--spectrum-alias-ui-icon-alert-size-100));
  --spectrum-textfield-error-icon-width: var(--spectrum-textfield-m-error-icon-width, var(--spectrum-alias-ui-icon-alert-size-100));
  --spectrum-textfield-error-icon-margin-left: var(--spectrum-textfield-m-error-icon-margin-left, var(--spectrum-global-dimension-size-150));
  --spectrum-textfield-placeholder-text-font-style: var(--spectrum-textfield-m-placeholder-text-font-style, var(--spectrum-global-font-style-italic));
  --spectrum-textfield-placeholder-text-font-weight: var(--spectrum-textfield-m-placeholder-text-font-weight, var(--spectrum-global-font-weight-regular));
  --spectrum-textfield-border-radius: var(--spectrum-textfield-m-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-textfield-quiet-border-size: var(--spectrum-textfield-quiet-m-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-textfield-quiet-padding-left: var(--spectrum-textfield-quiet-m-padding-left, 0);
  --spectrum-textfield-quiet-padding-right: var(--spectrum-textfield-quiet-m-padding-right, 0);
  --spectrum-textfield-quiet-success-icon-margin-left: var(--spectrum-textfield-quiet-m-success-icon-margin-left, var(--spectrum-global-dimension-size-150));
  --spectrum-textfield-quiet-error-icon-margin-left: var(--spectrum-textfield-quiet-m-error-icon-margin-left, var(--spectrum-global-dimension-size-150));
  --spectrum-textfield-quiet-border-radius: var(--spectrum-textfield-quiet-m-border-radius, 0px);

  --spectrum-textarea-text-padding-top: var(--spectrum-textarea-m-text-padding-top, var(--spectrum-alias-item-text-padding-top-m));

  --spectrum-textarea-text-padding-bottom: var(--spectrum-textarea-m-text-padding-bottom, var(--spectrum-alias-item-text-padding-bottom-m));

  --spectrum-textarea-height: var(--spectrum-textarea-m-height, var(--spectrum-alias-item-height-m));

  --spectrum-textarea-padding-left: var(--spectrum-textarea-m-padding-left, var(--spectrum-alias-item-padding-m));

  --spectrum-textarea-padding-right: var(--spectrum-textarea-m-padding-right, var(--spectrum-alias-item-padding-m));
  --spectrum-textfield-padding-top: 3px;
  --spectrum-textfield-padding-bottom: 5px;
  --spectrum-textfield-text-font-family: var(--spectrum-alias-body-text-font-family, var(--spectrum-global-font-family-base));
  --spectrum-textfield-icon-gap: var(--spectrum-global-dimension-size-65);
  --spectrum-textfield-quiet-icon-gap: var(--spectrum-global-dimension-size-75);
  --spectrum-textarea-min-height: var(--spectrum-textarea-height);
  --spectrum-textarea-height-adjusted: auto;
  --spectrum-textarea-padding-top: var(--spectrum-textarea-text-padding-top);
  --spectrum-textarea-padding-bottom: var(--spectrum-textarea-text-padding-bottom);
}

.spectrum-Textfield {
  display: -ms-inline-flexbox;
  display: inline-flex;
  position: relative;
  min-width: var(--spectrum-textfield-min-width);
  width: var(--spectrum-alias-single-line-width, var(--spectrum-global-dimension-size-2400));
}

.spectrum-Textfield.spectrum-Textfield--quiet.spectrum-Textfield--multiline
    .spectrum-Textfield-input {
    height: var(--spectrum-textfield-height);
    min-height: var(--spectrum-textfield-height);
  }

.spectrum-Textfield-input {
  box-sizing: border-box;
  border: var(--spectrum-textfield-border-size) solid;
  border-radius: var(--spectrum-textfield-border-radius);
  padding: var(--spectrum-textfield-padding-top)
    var(--spectrum-textfield-padding-right) var(--spectrum-textfield-padding-bottom)
    calc(var(--spectrum-textfield-padding-left) - 1px);
  text-indent: 0;

  width: 100%;
  height: var(--spectrum-textfield-height);

  vertical-align: top;
  margin: 0;
  overflow: visible;
  font-family: var(--spectrum-textfield-text-font-family);
  font-size: var(--spectrum-textfield-text-size);
  line-height: var(--spectrum-textfield-text-line-height);
  text-overflow: ellipsis;

  transition: border-color var(--spectrum-global-animation-duration-100, 130ms)
      ease-in-out,
    box-shadow var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;

  outline: none;

  -webkit-appearance: none;
  -moz-appearance: textfield;
}

.spectrum-Textfield-input::placeholder {
    font-weight: var(--spectrum-textfield-placeholder-text-font-weight);
    font-style: var(--spectrum-textfield-placeholder-text-font-style);
    transition: color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
    opacity: 1;
  }

.spectrum-Textfield-input::-ms-input-placeholder {
    font-weight: var(--spectrum-textfield-placeholder-text-font-weight);
    font-style: var(--spectrum-textfield-placeholder-text-font-style);
    transition: color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
    opacity: 1;
  }

.spectrum-Textfield-input:lang(ja)::placeholder, .spectrum-Textfield-input:lang(zh)::placeholder, .spectrum-Textfield-input:lang(ko)::placeholder {
      font-style: normal;
    }

.spectrum-Textfield-input:lang(ja)::-ms-input-placeholder, .spectrum-Textfield-input:lang(zh)::-ms-input-placeholder, .spectrum-Textfield-input:lang(ko)::-ms-input-placeholder {
      font-style: normal;
    }

.spectrum-Textfield-input:hover::placeholder {
      font-weight: var(--spectrum-textfield-placeholder-text-font-weight);
    }

.spectrum-Textfield-input:disabled {
    resize: none;
    opacity: 1;
  }

.spectrum-Textfield-input:disabled::placeholder {
      font-weight: var(--spectrum-textfield-placeholder-text-font-weight);
    }

.spectrum-Textfield-input::-ms-clear {
    width: 0;
    height: 0;
  }

.spectrum-Textfield-input::-webkit-inner-spin-button,
  .spectrum-Textfield-input::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

.spectrum-Textfield-input:-moz-ui-invalid {
    box-shadow: none;
  }

[dir="ltr"] .spectrum-Textfield.is-valid .spectrum-Textfield-input {
    padding-right: calc(var(--spectrum-textfield-padding-right) + var(--spectrum-icon-checkmark-medium-width) + var(--spectrum-textfield-success-icon-margin-left));
}

[dir="rtl"] .spectrum-Textfield.is-valid .spectrum-Textfield-input {
    padding-left: calc(var(--spectrum-textfield-padding-right) + var(--spectrum-icon-checkmark-medium-width) + var(--spectrum-textfield-success-icon-margin-left));
}

[dir="ltr"] .spectrum-Textfield.is-invalid .spectrum-Textfield-input {
    padding-right: calc(var(--spectrum-textfield-padding-right) + var(--spectrum-icon-alert-medium-width, var(--spectrum-global-dimension-size-225)) + var(--spectrum-textfield-error-icon-margin-left));
}

[dir="rtl"] .spectrum-Textfield.is-invalid .spectrum-Textfield-input {
    padding-left: calc(var(--spectrum-textfield-padding-right) + var(--spectrum-icon-alert-medium-width, var(--spectrum-global-dimension-size-225)) + var(--spectrum-textfield-error-icon-margin-left));
}

.spectrum-Textfield--multiline .spectrum-Textfield-input {
    height: var(--spectrum-textarea-height-adjusted);
    min-height: var(--spectrum-textarea-min-height);
    padding: var(--spectrum-textarea-padding-top)
      var(--spectrum-textarea-padding-right)
      var(--spectrum-textarea-padding-bottom)
      calc(var(--spectrum-textarea-padding-left) - 1px);
    overflow: auto;
  }

[dir="ltr"] .spectrum-Textfield--quiet .spectrum-Textfield-input {
    padding-left: var(--spectrum-textfield-quiet-padding-left);
}

[dir="rtl"] .spectrum-Textfield--quiet .spectrum-Textfield-input {
    padding-right: var(--spectrum-textfield-quiet-padding-left);
}

[dir="ltr"] .spectrum-Textfield--quiet .spectrum-Textfield-input {
    padding-right: var(--spectrum-textfield-quiet-padding-right);
}

[dir="rtl"] .spectrum-Textfield--quiet .spectrum-Textfield-input {
    padding-left: var(--spectrum-textfield-quiet-padding-right);
}

.spectrum-Textfield--quiet .spectrum-Textfield-input {
    border-radius: var(--spectrum-textfield-quiet-border-radius);
    border-top-width: 0;
    border-bottom-width: var(--spectrum-textfield-quiet-border-size);
    border-left-width: 0;
    border-right-width: 0;
    resize: none;
    overflow-y: hidden;
  }

[dir="ltr"] .is-invalid.spectrum-Textfield--quiet .spectrum-Textfield-input {
      padding-right: calc(var(--spectrum-icon-alert-medium-width, var(--spectrum-global-dimension-size-225)) + var(--spectrum-textfield-quiet-error-icon-margin-left));
}

[dir="rtl"] .is-invalid.spectrum-Textfield--quiet .spectrum-Textfield-input {
      padding-left: calc(var(--spectrum-icon-alert-medium-width, var(--spectrum-global-dimension-size-225)) + var(--spectrum-textfield-quiet-error-icon-margin-left));
}

[dir="ltr"] .is-valid.spectrum-Textfield--quiet .spectrum-Textfield-input {
      padding-right: calc(var(--spectrum-icon-checkmark-medium-width) + var(--spectrum-textfield-quiet-success-icon-margin-left));
}

[dir="rtl"] .is-valid.spectrum-Textfield--quiet .spectrum-Textfield-input {
      padding-left: calc(var(--spectrum-icon-checkmark-medium-width) + var(--spectrum-textfield-quiet-success-icon-margin-left));
}

.spectrum-Textfield-validationIcon {
  position: absolute;
  pointer-events: all;
}

[dir="ltr"] .spectrum-Textfield--quiet .spectrum-Textfield-validationIcon {
    padding-right: 0;
}

[dir="rtl"] .spectrum-Textfield--quiet .spectrum-Textfield-validationIcon {
    padding-left: 0;
}

[dir="ltr"] .spectrum-Textfield.is-invalid .spectrum-Textfield-validationIcon {

    right: var(--spectrum-textfield-error-icon-margin-left);
}

[dir="rtl"] .spectrum-Textfield.is-invalid .spectrum-Textfield-validationIcon {

    left: var(--spectrum-textfield-error-icon-margin-left);
}

.spectrum-Textfield.is-invalid .spectrum-Textfield-validationIcon {
    width: var(--spectrum-textfield-error-icon-width);
    height: var(--spectrum-textfield-error-icon-height);
    bottom: calc(var(--spectrum-textfield-height) / 2 - var(--spectrum-textfield-error-icon-height) / 2);
  }

[dir="ltr"] .spectrum-Textfield--quiet.spectrum-Textfield.is-invalid .spectrum-Textfield-validationIcon {
      right: 0;
}

[dir="rtl"] .spectrum-Textfield--quiet.spectrum-Textfield.is-invalid .spectrum-Textfield-validationIcon {
      left: 0;
}

[dir="ltr"] .spectrum-Textfield.is-valid .spectrum-Textfield-validationIcon {
    right: var(--spectrum-textfield-success-icon-margin-left);
}

[dir="rtl"] .spectrum-Textfield.is-valid .spectrum-Textfield-validationIcon {
    left: var(--spectrum-textfield-success-icon-margin-left);
}

.spectrum-Textfield.is-valid .spectrum-Textfield-validationIcon {
    width: var(--spectrum-textfield-success-icon-width);
    height: var(--spectrum-textfield-success-icon-height);
    bottom: calc(var(--spectrum-textfield-height) / 2 - var(--spectrum-textfield-success-icon-height) / 2);
  }

[dir="ltr"] .spectrum-Textfield--quiet.spectrum-Textfield.is-valid .spectrum-Textfield-validationIcon {
      right: 0;
}

[dir="rtl"] .spectrum-Textfield--quiet.spectrum-Textfield.is-valid .spectrum-Textfield-validationIcon {
      left: 0;
}

[dir="ltr"] .spectrum-Textfield-icon {
  left: var(--spectrum-textfield-error-icon-margin-left);
}

[dir="rtl"] .spectrum-Textfield-icon {
  right: var(--spectrum-textfield-error-icon-margin-left);
}

.spectrum-Textfield-icon {
  display: block;
  position: absolute;
  height: var(--spectrum-alias-workflow-icon-size-m, var(--spectrum-global-dimension-size-225));
  width: var(--spectrum-alias-workflow-icon-size-m, var(--spectrum-global-dimension-size-225));
  top: calc(var(--spectrum-textfield-height) / 2 - var(--spectrum-alias-workflow-icon-size-m, var(--spectrum-global-dimension-size-225)) / 2);
}

[dir="ltr"] .spectrum-Textfield--quiet .spectrum-Textfield-icon {
    left: 0;
}

[dir="rtl"] .spectrum-Textfield--quiet .spectrum-Textfield-icon {
    right: 0;
}

[dir="ltr"] .spectrum-Textfield--quiet .spectrum-Textfield-icon ~ .spectrum-Textfield-input {
      padding-left: calc(var(--spectrum-alias-workflow-icon-size-m, var(--spectrum-global-dimension-size-225)) + var(--spectrum-textfield-quiet-icon-gap));
}

[dir="rtl"] .spectrum-Textfield--quiet .spectrum-Textfield-icon ~ .spectrum-Textfield-input {
      padding-right: calc(var(--spectrum-alias-workflow-icon-size-m, var(--spectrum-global-dimension-size-225)) + var(--spectrum-textfield-quiet-icon-gap));
}

[dir="ltr"] .spectrum-Textfield-icon + .spectrum-Textfield-input {
    padding-left: calc(var(--spectrum-textfield-error-icon-margin-left) + var(--spectrum-alias-workflow-icon-size-m, var(--spectrum-global-dimension-size-225)) + var(--spectrum-textfield-icon-gap));
}

[dir="rtl"] .spectrum-Textfield-icon + .spectrum-Textfield-input {
    padding-right: calc(var(--spectrum-textfield-error-icon-margin-left) + var(--spectrum-alias-workflow-icon-size-m, var(--spectrum-global-dimension-size-225)) + var(--spectrum-textfield-icon-gap));
}

.spectrum-Textfield--multiline .spectrum-Textfield-icon ~ .spectrum-Textfield-input {
      height: var(--spectrum-textfield-height);
      min-height: var(--spectrum-textfield-height);
    }

.spectrum-Textfield {
  --spectrum-textfield-m-validation-icon-color-valid: var(--spectrum-semantic-positive-color-icon, var(--spectrum-global-color-green-600));
}

.spectrum-Textfield:hover .spectrum-Textfield-input {
      border-color: var(--spectrum-textfield-m-border-color-hover, var(--spectrum-alias-border-color-hover));
      box-shadow: none;
    }

.spectrum-Textfield:hover .spectrum-Textfield-input::placeholder {
        color: var(--spectrum-textfield-m-placeholder-text-color-hover, var(--spectrum-alias-placeholder-text-color-hover));
      }

.spectrum-Textfield:hover .spectrum-Textfield-icon {
      color: var(--spectrum-textfield-m-icon-color-hover, var(--spectrum-global-color-gray-900));
    }

.spectrum-Textfield:active .spectrum-Textfield-input {
      border-color: var(--spectrum-textfield-m-border-color-down, var(--spectrum-alias-border-color-mouse-focus));
    }

.spectrum-Textfield:active .spectrum-Textfield-icon {
      color: var(--spectrum-textfield-m-icon-color-down, var(--spectrum-alias-icon-color-down));
    }

.spectrum-Textfield.is-valid .spectrum-Textfield-validationIcon {
      color: var(--spectrum-textfield-m-validation-icon-color-valid, var(--spectrum-global-color-green-400));
    }

.spectrum-Textfield.is-invalid .spectrum-Textfield-validationIcon {
      color: var(--spectrum-textfield-m-validation-icon-color-error, var(--spectrum-semantic-negative-color-icon));
    }

.spectrum-Textfield.is-invalid:hover .spectrum-Textfield-input {
        border-color: var(--spectrum-textfield-m-border-color-error-hover, var(--spectrum-semantic-negative-color-state-hover));
      }

.spectrum-Textfield.is-disabled .spectrum-Textfield-validationIcon {
      color: var(--spectrum-textfield-m-validation-icon-color-disabled, var(--spectrum-global-color-gray-500));
    }

.spectrum-Textfield.is-disabled .spectrum-Textfield-icon {
      color: var(--spectrum-textfield-m-icon-color-disabled, var(--spectrum-global-color-gray-500));
    }

.spectrum-Textfield-icon {
  color: var(--spectrum-textfield-m-icon-color, var(--spectrum-alias-icon-color));
}

.spectrum-Textfield-input {
  background-color: var(--spectrum-textfield-m-background-color, var(--spectrum-global-color-gray-50));
  border-color: var(--spectrum-textfield-m-border-color, var(--spectrum-alias-border-color));
  color: var(--spectrum-textfield-m-text-color, var(--spectrum-alias-text-color));
}

.spectrum-Textfield-input::placeholder {
    color: var(--spectrum-textfield-m-placeholder-text-color, var(--spectrum-alias-placeholder-text-color));
  }

.spectrum-Textfield.is-focused .spectrum-Textfield-input,
  .spectrum-Textfield-input:focus {
    border-color: var(--spectrum-textfield-m-border-color-down, var(--spectrum-alias-border-color-mouse-focus));
  }

.spectrum-Textfield.is-keyboardFocused .spectrum-Textfield-input,
  .spectrum-Textfield-input.focus-ring {
    border-color: var(--spectrum-textfield-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    box-shadow: 0 0 0 1px var(--spectrum-textfield-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
  }

.spectrum-Textfield.is-invalid .spectrum-Textfield-input {
    border-color: var(--spectrum-textfield-m-border-color-error, var(--spectrum-semantic-negative-color-default));
  }

.is-keyboardFocused.spectrum-Textfield.is-invalid .spectrum-Textfield-input,
    .spectrum-Textfield.is-invalid .spectrum-Textfield-input.focus-ring {
      border-color: var(--spectrum-textfield-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
      box-shadow: 0 0 0 1px var(--spectrum-textfield-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-Textfield.is-disabled .spectrum-Textfield-input,
  .spectrum-Textfield.is-disabled:hover .spectrum-Textfield-input,
  .spectrum-Textfield-input :disabled {
    background-color: var(--spectrum-textfield-m-background-color-disabled, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-textfield-m-border-color-disabled, var(--spectrum-alias-border-color-transparent));
    color: var(--spectrum-textfield-m-text-color-disabled, var(--spectrum-alias-text-color-disabled));
    -webkit-text-fill-color: var(--spectrum-textfield-m-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }

.spectrum-Textfield.is-disabled .spectrum-Textfield-input::placeholder, .spectrum-Textfield.is-disabled:hover .spectrum-Textfield-input::placeholder, .spectrum-Textfield-input :disabled::placeholder {
      color: var(--spectrum-textfield-m-placeholder-text-color-disabled, var(--spectrum-alias-text-color-disabled));
    }

.spectrum-Textfield--quiet .spectrum-Textfield-input {
    background-color: var(--spectrum-textfield-quiet-m-background-color, var(--spectrum-alias-background-color-transparent));
    border-color: var(--spectrum-textfield-quiet-m-border-color, var(--spectrum-alias-border-color));
  }

:hover.spectrum-Textfield--quiet .spectrum-Textfield-input {
      border-color: var(--spectrum-textfield-quiet-m-border-color-hover, var(--spectrum-alias-border-color-hover));
    }

:active.spectrum-Textfield--quiet .spectrum-Textfield-input {
      border-color: var(--spectrum-textfield-quiet-m-border-color-down, var(--spectrum-alias-border-color-mouse-focus));
    }

.is-focused.spectrum-Textfield--quiet .spectrum-Textfield-input,
    .spectrum-Textfield--quiet .spectrum-Textfield-input:focus {
      border-color: var(--spectrum-textfield-quiet-m-border-color-mouse-focus, var(--spectrum-alias-border-color-mouse-focus));
    }

.is-keyboardFocused.spectrum-Textfield--quiet .spectrum-Textfield-input,
    .spectrum-Textfield--quiet .spectrum-Textfield-input.focus-ring {
      border-color: var(--spectrum-textfield-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
      box-shadow: 0 1px 0 var(--spectrum-textfield-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    }

.is-invalid.spectrum-Textfield--quiet .spectrum-Textfield-input {
      border-color: var(--spectrum-textfield-quiet-m-border-color-error, var(--spectrum-semantic-negative-color-default));
    }

.is-focused.is-invalid.spectrum-Textfield--quiet .spectrum-Textfield-input,
      .is-invalid.spectrum-Textfield--quiet .spectrum-Textfield-input:focus {
        border-color: var(--spectrum-textfield-quiet-m-border-color-error-mouse-focus, var(--spectrum-semantic-negative-color-state-hover));
      }

.is-keyboardFocused.is-invalid.spectrum-Textfield--quiet .spectrum-Textfield-input,
      .is-invalid.spectrum-Textfield--quiet .spectrum-Textfield-input.focus-ring {
        border-color: var(--spectrum-textfield-quiet-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
        box-shadow: 0 1px 0 var(--spectrum-textfield-quiet-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
      }

.is-disabled:hover.spectrum-Textfield--quiet .spectrum-Textfield-input,
    .is-disabled.spectrum-Textfield--quiet .spectrum-Textfield-input,
    .spectrum-Textfield--quiet .spectrum-Textfield-input :disabled {
      background-color: var(--spectrum-textfield-quiet-m-background-color-disabled, var(--spectrum-alias-background-color-transparent));
      border-color: var(--spectrum-textfield-quiet-m-border-color-disabled, var(--spectrum-alias-border-color-mid));
    }
.spectrum-Textfield-input.svelte-1eqovy0.svelte-1eqovy0{pointer-events:none}.spectrum-Textfield.svelte-1eqovy0.svelte-1eqovy0:not(.is-disabled):hover{cursor:pointer}.spectrum-Datepicker.svelte-1eqovy0.svelte-1eqovy0{width:100%;overflow:hidden}.spectrum-Datepicker.svelte-1eqovy0 .spectrum-Textfield.svelte-1eqovy0{width:100%}.is-disabled.svelte-1eqovy0.svelte-1eqovy0{pointer-events:none !important}input.svelte-1eqovy0.svelte-1eqovy0:read-only{border-right-width:1px;border-top-right-radius:var(--spectrum-textfield-border-radius);border-bottom-right-radius:var(--spectrum-textfield-border-radius)}.error-icon.svelte-1eqovy0.svelte-1eqovy0{position:absolute;right:8px;bottom:calc(var(--spectrum-textfield-height) / 2);transform:translateY(50%)}input.svelte-zyjkwa{background:none;border:none;outline:none;color:var(--spectrum-alias-text-color);padding:4px 6px 5px 6px;border-radius:4px;transition:background 130ms ease-out;font-size:18px;font-weight:bold;font-family:var(--font-sans);-webkit-font-smoothing:antialiased;box-sizing:content-box !important}input.svelte-zyjkwa:focus,input.svelte-zyjkwa:hover{--space:30px;background:var(--spectrum-global-color-gray-200);z-index:1}input.hide-arrows.svelte-zyjkwa::-webkit-outer-spin-button,input.hide-arrows.svelte-zyjkwa::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}input.hide-arrows.svelte-zyjkwa{-moz-appearance:textfield;appearance:textfield}input[type="time"].svelte-zyjkwa::-webkit-calendar-picker-indicator{display:none}.time-picker.svelte-60qev7{display:flex;flex-direction:row;align-items:center}.spectrum-Picker {
  --spectrum-button-line-height: 1.3;
  position: relative;

  display: -ms-inline-flexbox;

  display: inline-flex;
  box-sizing: border-box;

  -ms-flex-align: center;

      align-items: center;
  -ms-flex-pack: center;
      justify-content: center;
  overflow: visible;
  margin: 0;

  border-style: solid;
  text-transform: none;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  -webkit-appearance: button;
  vertical-align: top;

  transition: background var(--spectrum-global-animation-duration-100, 130ms) ease-out,
    border-color var(--spectrum-global-animation-duration-100, 130ms) ease-out,
    color var(--spectrum-global-animation-duration-100, 130ms) ease-out,
    box-shadow var(--spectrum-global-animation-duration-100, 130ms) ease-out;

  text-decoration: none;
  font-family: var(--spectrum-alias-body-text-font-family, var(--spectrum-global-font-family-base));

  line-height: var(--spectrum-button-line-height);

  -moz-user-select: none;

   -ms-user-select: none;

       user-select: none;
  -webkit-user-select: none;

  cursor: pointer;
}

.spectrum-Picker:focus {
    outline: none;
  }

.spectrum-Picker::-moz-focus-inner {
    border: 0;
    border-style: none;
    padding: 0;
    margin-top: -2px;
    margin-bottom: -2px;
  }

.spectrum-Picker:disabled {
    cursor: default;
  }

[dir="ltr"] .spectrum-Picker {
  padding-left: var(--spectrum-picker-textonly-padding-left);
  padding-right: var(--spectrum-picker-textonly-padding-right);
}

[dir="rtl"] .spectrum-Picker {
  padding-right: var(--spectrum-picker-textonly-padding-left);
  padding-left: var(--spectrum-picker-textonly-padding-right);
}

.spectrum-Picker {

  display: -ms-flexbox;

  display: flex;
  -ms-flex-pack: center;
      justify-content: center;
  -ms-flex-align: center;
      align-items: center;
  max-width: 100%;
  width: var(--spectrum-picker-width);
  min-width: var(--spectrum-picker-min-width);
  height: var(--spectrum-picker-height);

  margin: 0;
  padding-top: 0;
  padding-bottom: 0;

  border-width: var(--spectrum-picker-border-size);
  border-style: solid;
  border-radius: var(--spectrum-picker-border-radius);

  transition: background-color var(--spectrum-global-animation-duration-100, 130ms),
    box-shadow var(--spectrum-global-animation-duration-100, 130ms),
    border-color var(--spectrum-global-animation-duration-100, 130ms);
}

.spectrum-Picker:disabled,
  .spectrum-Picker.is-disabled {
    border-width: var(--spectrum-picker-disabled-border-size);
    cursor: default;
  }

[dir="ltr"] .spectrum-Picker .spectrum-Picker-icon {
    margin-right: var(--spectrum-picker-icon-gap);
}

[dir="rtl"] .spectrum-Picker .spectrum-Picker-icon {
    margin-left: var(--spectrum-picker-icon-gap);
}

.spectrum-Picker .spectrum-Picker-icon {
    -ms-flex-negative: 0;
        flex-shrink: 0;
  }

[dir="ltr"] .spectrum-Picker .spectrum-Picker-label + .spectrum-Picker-icon {
    margin-left: var(--spectrum-picker-icon-gap);
}

[dir="rtl"] .spectrum-Picker .spectrum-Picker-label + .spectrum-Picker-icon {
    margin-right: var(--spectrum-picker-icon-gap);
}

.spectrum-Picker--sizeS {
  --spectrum-picker-border-size: var(--spectrum-picker-s-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-picker-text-size: var(--spectrum-picker-s-text-size, var(--spectrum-alias-item-text-size-s));
  --spectrum-picker-icon-gap: var(--spectrum-picker-s-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-s));
  --spectrum-picker-height: var(--spectrum-picker-s-height, var(--spectrum-alias-item-height-s));
  --spectrum-picker-placeholder-text-font-style: var(--spectrum-picker-s-placeholder-text-font-style, var(--spectrum-global-font-style-italic));
  --spectrum-picker-placeholder-text-font-weight: var(--spectrum-picker-s-placeholder-text-font-weight, var(--spectrum-global-font-weight-regular));
  --spectrum-picker-border-radius: var(--spectrum-picker-s-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-picker-width: var(--spectrum-picker-s-width, var(--spectrum-global-dimension-size-2000));
  --spectrum-picker-min-width: var(--spectrum-picker-s-min-width, var(--spectrum-global-dimension-size-450));
  --spectrum-picker-popover-max-width: var(--spectrum-picker-s-popover-max-width, var(--spectrum-global-dimension-size-1800));
  --spectrum-picker-ui-icon-gap: var(--spectrum-picker-s-ui-icon-gap, var(--spectrum-alias-item-ui-icon-gap-s));
  --spectrum-picker-error-icon-margin-left: var(--spectrum-picker-s-error-icon-margin-left, var(--spectrum-global-dimension-size-100));
  --spectrum-picker-textonly-padding-left: var(--spectrum-picker-s-textonly-padding-left, var(--spectrum-alias-item-padding-s));
  --spectrum-picker-textonly-padding-right: var(--spectrum-picker-s-textonly-padding-right, var(--spectrum-alias-item-padding-s));
}

.spectrum-Picker--sizeM {
  --spectrum-picker-border-size: var(--spectrum-picker-m-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-picker-text-size: var(--spectrum-picker-m-text-size, var(--spectrum-alias-item-text-size-m));
  --spectrum-picker-height: var(--spectrum-picker-m-height, var(--spectrum-alias-item-height-m));
  --spectrum-picker-icon-gap: var(--spectrum-picker-m-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-m));
  --spectrum-picker-placeholder-text-font-style: var(--spectrum-picker-m-placeholder-text-font-style, var(--spectrum-global-font-style-italic));
  --spectrum-picker-placeholder-text-font-weight: var(--spectrum-picker-m-placeholder-text-font-weight, var(--spectrum-global-font-weight-regular));
  --spectrum-picker-border-radius: var(--spectrum-picker-m-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-picker-width: var(--spectrum-picker-m-width, var(--spectrum-global-dimension-size-3000));
  --spectrum-picker-min-width: var(--spectrum-picker-m-min-width, var(--spectrum-global-dimension-size-600));
  --spectrum-picker-popover-max-width: var(--spectrum-picker-m-popover-max-width, var(--spectrum-global-dimension-size-2400));
  --spectrum-picker-ui-icon-gap: var(--spectrum-picker-m-ui-icon-gap, var(--spectrum-alias-item-ui-icon-gap-m));
  --spectrum-picker-error-icon-margin-left: var(--spectrum-picker-m-error-icon-margin-left, var(--spectrum-global-dimension-size-150));
  --spectrum-picker-textonly-padding-left: var(--spectrum-picker-m-textonly-padding-left, var(--spectrum-alias-item-padding-m));
  --spectrum-picker-textonly-padding-right: var(--spectrum-picker-m-textonly-padding-right, var(--spectrum-alias-item-padding-m));
}

.spectrum-Picker--sizeL {
  --spectrum-picker-border-size: var(--spectrum-picker-l-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-picker-text-size: var(--spectrum-picker-l-text-size, var(--spectrum-alias-item-text-size-l));
  --spectrum-picker-icon-gap: var(--spectrum-picker-l-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-l));
  --spectrum-picker-height: var(--spectrum-picker-l-height, var(--spectrum-alias-item-height-l));
  --spectrum-picker-placeholder-text-font-style: var(--spectrum-picker-l-placeholder-text-font-style, var(--spectrum-global-font-style-italic));
  --spectrum-picker-placeholder-text-font-weight: var(--spectrum-picker-l-placeholder-text-font-weight, var(--spectrum-global-font-weight-regular));
  --spectrum-picker-border-radius: var(--spectrum-picker-l-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-picker-width: var(--spectrum-picker-l-width, var(--spectrum-global-dimension-size-2000));
  --spectrum-picker-min-width: var(--spectrum-picker-l-min-width, var(--spectrum-global-dimension-size-750));
  --spectrum-picker-popover-max-width: var(--spectrum-picker-l-popover-max-width, var(--spectrum-global-dimension-size-3000));
  --spectrum-picker-ui-icon-gap: var(--spectrum-picker-l-ui-icon-gap, var(--spectrum-alias-item-ui-icon-gap-l));
  --spectrum-picker-error-icon-margin-left: var(--spectrum-picker-l-error-icon-margin-left, var(--spectrum-global-dimension-size-185));
  --spectrum-picker-textonly-padding-left: var(--spectrum-picker-l-textonly-padding-left, var(--spectrum-alias-item-padding-l));
  --spectrum-picker-textonly-padding-right: var(--spectrum-picker-l-textonly-padding-right, var(--spectrum-alias-item-padding-l));
}

.spectrum-Picker--sizeXL {
  --spectrum-picker-border-size: var(--spectrum-picker-xl-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-picker-icon-gap: var(--spectrum-picker-xl-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-l));
  --spectrum-picker-text-size: var(--spectrum-picker-xl-text-size, var(--spectrum-alias-item-text-size-xl));
  --spectrum-picker-height: var(--spectrum-picker-xl-height, var(--spectrum-alias-item-height-xl));
  --spectrum-picker-placeholder-text-font-style: var(--spectrum-picker-xl-placeholder-text-font-style, var(--spectrum-global-font-style-italic));
  --spectrum-picker-placeholder-text-font-weight: var(--spectrum-picker-xl-placeholder-text-font-weight, var(--spectrum-global-font-weight-regular));
  --spectrum-picker-border-radius: var(--spectrum-picker-xl-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-picker-width: var(--spectrum-picker-xl-width, var(--spectrum-global-dimension-size-3000));
  --spectrum-picker-min-width: var(--spectrum-picker-xl-min-width, var(--spectrum-global-dimension-size-900));
  --spectrum-picker-popover-max-width: var(--spectrum-picker-xl-popover-max-width, var(--spectrum-global-dimension-size-3600));
  --spectrum-picker-ui-icon-gap: var(--spectrum-picker-xl-ui-icon-gap, var(--spectrum-alias-item-ui-icon-gap-xl));
  --spectrum-picker-error-icon-margin-left: var(--spectrum-picker-xl-error-icon-margin-left, var(--spectrum-global-dimension-size-225));
  --spectrum-picker-textonly-padding-left: var(--spectrum-picker-xl-textonly-padding-left, var(--spectrum-alias-item-padding-xl));
  --spectrum-picker-textonly-padding-right: var(--spectrum-picker-xl-textonly-padding-right, var(--spectrum-alias-item-padding-xl));
}

.spectrum-Picker {
  --spectrum-picker-min-width: var(--spectrum-global-dimension-size-400);
  --spectrum-picker-disabled-border-size: 0;

  --spectrum-picker-popover-max-width: var(--spectrum-global-dimension-size-3000);
  --spectrum-picker-width: var(--spectrum-global-dimension-size-2400);
  --spectrum-picker-border-size-increase-focus: 1px;
}

.spectrum-Picker--quiet {
  --spectrum-picker-border-size: 0;
  --spectrum-picker-border-radius: 0;
  --spectrum-picker-textonly-padding-left: 0;
  --spectrum-picker-textonly-padding-right: 0;
}

.spectrum-Picker--quiet {
  width: auto;
  min-width: 0;
}

.spectrum-Picker--quiet:disabled.focus-ring, .spectrum-Picker--quiet.is-disabled.focus-ring {
      box-shadow: none;
    }

[dir="ltr"] .spectrum-Picker-label {
  text-align: left;
}

[dir="rtl"] .spectrum-Picker-label {
  text-align: right;
}

.spectrum-Picker-label {
  -ms-flex: 1 1 auto;
      flex: 1 1 auto;

  white-space: nowrap;
  overflow: hidden;

  height: calc(var(--spectrum-picker-height) - var(--spectrum-picker-border-size) * 2);
  line-height: calc(var(--spectrum-picker-height) - var(--spectrum-picker-border-size) * 2);

  font-size: var(--spectrum-picker-text-size);

  text-overflow: ellipsis;
}

.spectrum-Picker-label.is-placeholder {
    font-weight: var(--spectrum-picker-placeholder-text-font-weight);
    font-style: var(--spectrum-picker-placeholder-text-font-style);
    transition: color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
  }

.spectrum-Picker-menuIcon {
  display: inline-block;
  position: relative;
  vertical-align: top;
  transition: color var(--spectrum-global-animation-duration-100, 130ms) ease-out;
  -ms-flex-negative: 0;
      flex-shrink: 0;
}

[dir="ltr"] .spectrum-Picker-validationIcon {
  margin-left: var(--spectrum-picker-error-icon-margin-left);
}

[dir="rtl"] .spectrum-Picker-validationIcon {
  margin-right: var(--spectrum-picker-error-icon-margin-left);
}

[dir="ltr"] .spectrum-Picker-label ~ .spectrum-Picker-menuIcon {
  margin-left: var(--spectrum-picker-ui-icon-gap);
}

[dir="rtl"] .spectrum-Picker-label ~ .spectrum-Picker-menuIcon {
  margin-right: var(--spectrum-picker-ui-icon-gap);
}

.spectrum-Picker-popover {
  max-width: var(--spectrum-picker-popover-max-width);
}

[dir="ltr"] .spectrum-Picker-popover--quiet {
  margin-left: calc(-1 * (var(--spectrum-picker-quiet-m-popover-offset-x, var(--spectrum-global-dimension-size-150)) + var(--spectrum-popover-border-size, var(--spectrum-alias-border-size-thin))));
}

[dir="rtl"] .spectrum-Picker-popover--quiet {
  margin-right: calc(-1 * (var(--spectrum-picker-quiet-m-popover-offset-x, var(--spectrum-global-dimension-size-150)) + var(--spectrum-popover-border-size, var(--spectrum-alias-border-size-thin))));
}

.spectrum-Picker {
  color: var(--spectrum-picker-m-text-color, var(--spectrum-alias-text-color));
  background-color: var(--spectrum-picker-m-background-color, var(--spectrum-global-color-gray-75));
  border-color: var(--spectrum-picker-m-border-color, var(--spectrum-alias-border-color));
}

.spectrum-Picker:hover {
    color: var(--spectrum-picker-m-text-color-hover, var(--spectrum-alias-text-color-hover));
    background-color: var(--spectrum-picker-m-background-color-hover, var(--spectrum-global-color-gray-50));
    border-color: var(--spectrum-picker-m-border-color-hover, var(--spectrum-alias-border-color-hover));
  }

.spectrum-Picker:hover .spectrum-Picker-menuIcon {
      color: var(--spectrum-picker-m-icon-color-hover, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-Picker:active,
  .spectrum-Picker.is-open {
    background-color: var(--spectrum-picker-m-background-color-down, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-picker-m-border-color-down, var(--spectrum-alias-border-color-down));
  }

.spectrum-Picker:active.is-placeholder .spectrum-Picker-label, .spectrum-Picker.is-open.is-placeholder .spectrum-Picker-label {
        color: var(--spectrum-picker-m-placeholder-text-color-down, var(--spectrum-alias-placeholder-text-color-down));
      }

.spectrum-Picker.focus-ring,
  .spectrum-Picker.is-focused {
    background-color: var(--spectrum-picker-m-background-color-key-focus, var(--spectrum-global-color-gray-50));
    border-color: var(--spectrum-picker-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    box-shadow: 0 0 0 var(--spectrum-picker-border-size-increase-focus) var(--spectrum-picker-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    color: var(--spectrum-picker-m-text-color-key-focus, var(--spectrum-alias-text-color-hover));
  }

.spectrum-Picker.focus-ring.is-placeholder, .spectrum-Picker.is-focused.is-placeholder {
      color: var(--spectrum-picker-m-placeholder-text-color-key-focus, var(--spectrum-alias-placeholder-text-color-hover));
    }

.spectrum-Picker.is-invalid {
    border-color: var(--spectrum-picker-m-border-color-error, var(--spectrum-global-color-red-500));
  }

.spectrum-Picker.is-invalid .spectrum-Picker-validationIcon {
      color: var(--spectrum-picker-m-validation-icon-color-error, var(--spectrum-semantic-negative-color-icon));
    }

.spectrum-Picker.is-invalid:hover {
      border-color: var(--spectrum-picker-m-border-color-error-hover, var(--spectrum-global-color-red-600));
    }

.spectrum-Picker.is-invalid:active,
    .spectrum-Picker.is-invalid.is-open {
      border-color: var(--spectrum-picker-m-border-color-error-down, var(--spectrum-global-color-red-600));
    }

.spectrum-Picker.is-invalid.focus-ring,
    .spectrum-Picker.is-invalid.is-focused {
      border-color: var(--spectrum-picker-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
      box-shadow: 0 0 0 var(--spectrum-picker-border-size-increase-focus) var(--spectrum-picker-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-Picker:disabled,
  .spectrum-Picker.is-disabled {
    background-color: var(--spectrum-picker-m-background-color-disabled, var(--spectrum-global-color-gray-200));
    color: var(--spectrum-picker-m-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }

.spectrum-Picker:disabled .spectrum-Picker-icon,
    .spectrum-Picker:disabled .spectrum-Picker-menuIcon,
    .spectrum-Picker:disabled .spectrum-Picker-validationIcon,
    .spectrum-Picker.is-disabled .spectrum-Picker-icon,
    .spectrum-Picker.is-disabled .spectrum-Picker-menuIcon,
    .spectrum-Picker.is-disabled .spectrum-Picker-validationIcon {
      color: var(--spectrum-picker-m-icon-color-disabled, var(--spectrum-alias-icon-color-disabled));
    }

.spectrum-Picker:disabled .spectrum-Picker-label.is-placeholder, .spectrum-Picker.is-disabled .spectrum-Picker-label.is-placeholder {
        color: var(--spectrum-picker-m-placeholder-text-color-disabled, var(--spectrum-alias-text-color-disabled));
      }

.spectrum-Picker-menuIcon {
  color: var(--spectrum-picker-m-icon-color, var(--spectrum-alias-icon-color));
}

.spectrum-Picker-label.is-placeholder {
    color: var(--spectrum-picker-m-placeholder-text-color, var(--spectrum-alias-placeholder-text-color));
  }

.spectrum-Picker-label.is-placeholder:hover {
      color: var(--spectrum-picker-m-placeholder-text-color-hover, var(--spectrum-alias-placeholder-text-color-hover));
    }

.spectrum-Picker-label.is-placeholder:active {
      color: var(--spectrum-picker-m-placeholder-text-color-mouse-focus, var(--spectrum-alias-placeholder-text-color));
    }

.spectrum-Picker--quiet {
  color: var(--spectrum-picker-m-text-color, var(--spectrum-alias-text-color));
  border-color: var(--spectrum-picker-quiet-m-border-color, var(--spectrum-alias-border-color-transparent));
  background-color: var(--spectrum-picker-quiet-m-background-color, var(--spectrum-alias-background-color-transparent));
}

.spectrum-Picker--quiet:hover {
    background-color: var(--spectrum-picker-quiet-m-background-color-hover, var(--spectrum-alias-background-color-transparent));
    color: var(--spectrum-picker-m-text-color-hover, var(--spectrum-alias-text-color-hover));
  }

.spectrum-Picker--quiet.focus-ring,
  .spectrum-Picker--quiet.is-focused {
    background-color: var(--spectrum-picker-quiet-m-background-color-key-focus, var(--spectrum-alias-background-color-transparent));
    box-shadow: 0 2px 0 0 var(--spectrum-picker-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
  }

.spectrum-Picker--quiet.focus-ring.is-placeholder, .spectrum-Picker--quiet.is-focused.is-placeholder {
      color: var(--spectrum-picker-quiet-m-placeholder-text-color-key-focus, var(--spectrum-alias-placeholder-text-color-hover));
    }

.spectrum-Picker--quiet.focus-ring .spectrum-Picker-menuIcon, .spectrum-Picker--quiet.is-focused .spectrum-Picker-menuIcon {
      color: var(--spectrum-picker-m-icon-color-key-focus, var(--spectrum-alias-icon-color-focus))
    }

.spectrum-Picker--quiet:active,
  .spectrum-Picker--quiet.is-open {
    background-color: var(--spectrum-picker-quiet-m-background-color-down, var(--spectrum-alias-background-color-transparent));
    border-color: var(--spectrum-picker-quiet-m-border-color-down, var(--spectrum-alias-border-color-transparent));
  }

.spectrum-Picker--quiet:active.focus-ring,
    .spectrum-Picker--quiet:active.is-focused,
    .spectrum-Picker--quiet.is-open.focus-ring,
    .spectrum-Picker--quiet.is-open.is-focused {
      background-color: var(--spectrum-picker-quiet-m-background-color-key-focus, var(--spectrum-alias-background-color-transparent));
      box-shadow: 0 2px 0 0 var(--spectrum-picker-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-Picker--quiet.is-invalid.focus-ring,
    .spectrum-Picker--quiet.is-invalid.is-focused {
      box-shadow: 0 2px 0 0 var(--spectrum-picker-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-Picker--quiet:disabled,
  .spectrum-Picker--quiet.is-disabled {
    background-color: var(--spectrum-picker-quiet-m-background-color-disabled, var(--spectrum-alias-background-color-transparent));
    color: var(--spectrum-picker-m-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }
.spectrum-ProgressCircle--indeterminate-fill-submask-2 {
  animation: 1s infinite linear spectrum-fill-mask-2;
}

@keyframes spectrum-fill-mask-1 {
  0% {
    transform: rotate(90deg);
  }

  1.69% {
    transform: rotate(72.3deg);
  }

  3.39% {
    transform: rotate(55.5deg);
  }

  5.08% {
    transform: rotate(40.3deg);
  }

  6.78% {
    transform: rotate(25deg);
  }

  8.47% {
    transform: rotate(10.6deg);
  }

  10.17% {
    transform: rotate(0deg);
  }

  11.86% {
    transform: rotate(0deg);
  }

  13.56% {
    transform: rotate(0deg);
  }

  15.25% {
    transform: rotate(0deg);
  }

  16.95% {
    transform: rotate(0deg);
  }

  18.64% {
    transform: rotate(0deg);
  }

  20.34% {
    transform: rotate(0deg);
  }

  22.03% {
    transform: rotate(0deg);
  }

  23.73% {
    transform: rotate(0deg);
  }

  25.42% {
    transform: rotate(0deg);
  }

  27.12% {
    transform: rotate(0deg);
  }

  28.81% {
    transform: rotate(0deg);
  }

  30.51% {
    transform: rotate(0deg);
  }

  32.2% {
    transform: rotate(0deg);
  }

  33.9% {
    transform: rotate(0deg);
  }

  35.59% {
    transform: rotate(0deg);
  }

  37.29% {
    transform: rotate(0deg);
  }

  38.98% {
    transform: rotate(0deg);
  }

  40.68% {
    transform: rotate(0deg);
  }

  42.37% {
    transform: rotate(5.3deg);
  }

  44.07% {
    transform: rotate(13.4deg);
  }

  45.76% {
    transform: rotate(20.6deg);
  }

  47.46% {
    transform: rotate(29deg);
  }

  49.15% {
    transform: rotate(36.5deg);
  }

  50.85% {
    transform: rotate(42.6deg);
  }

  52.54% {
    transform: rotate(48.8deg);
  }

  54.24% {
    transform: rotate(54.2deg);
  }

  55.93% {
    transform: rotate(59.4deg);
  }

  57.63% {
    transform: rotate(63.2deg);
  }

  59.32% {
    transform: rotate(67.2deg);
  }

  61.02% {
    transform: rotate(70.8deg);
  }

  62.71% {
    transform: rotate(73.8deg);
  }

  64.41% {
    transform: rotate(76.2deg);
  }

  66.1% {
    transform: rotate(78.7deg);
  }

  67.8% {
    transform: rotate(80.6deg);
  }

  69.49% {
    transform: rotate(82.6deg);
  }

  71.19% {
    transform: rotate(83.7deg);
  }

  72.88% {
    transform: rotate(85deg);
  }

  74.58% {
    transform: rotate(86.3deg);
  }

  76.27% {
    transform: rotate(87deg);
  }

  77.97% {
    transform: rotate(87.7deg);
  }

  79.66% {
    transform: rotate(88.3deg);
  }

  81.36% {
    transform: rotate(88.6deg);
  }

  83.05% {
    transform: rotate(89.2deg);
  }

  84.75% {
    transform: rotate(89.2deg);
  }

  86.44% {
    transform: rotate(89.5deg);
  }

  88.14% {
    transform: rotate(89.9deg);
  }

  89.83% {
    transform: rotate(89.7deg);
  }

  91.53% {
    transform: rotate(90.1deg);
  }

  93.22% {
    transform: rotate(90.2deg);
  }

  94.92% {
    transform: rotate(90.1deg);
  }

  96.61% {
    transform: rotate(90deg);
  }

  98.31% {
    transform: rotate(89.8deg);
  }

  100% {
    transform: rotate(90deg);
  }
}

@keyframes spectrum-fill-mask-2 {
  0% {
    transform: rotate(180deg);
  }

  1.69% {
    transform: rotate(180deg);
  }

  3.39% {
    transform: rotate(180deg);
  }

  5.08% {
    transform: rotate(180deg);
  }

  6.78% {
    transform: rotate(180deg);
  }

  8.47% {
    transform: rotate(180deg);
  }

  10.17% {
    transform: rotate(179.2deg);
  }

  11.86% {
    transform: rotate(164deg);
  }

  13.56% {
    transform: rotate(151.8deg);
  }

  15.25% {
    transform: rotate(140.8deg);
  }

  16.95% {
    transform: rotate(130.3deg);
  }

  18.64% {
    transform: rotate(120.4deg);
  }

  20.34% {
    transform: rotate(110.8deg);
  }

  22.03% {
    transform: rotate(101.6deg);
  }

  23.73% {
    transform: rotate(93.5deg);
  }

  25.42% {
    transform: rotate(85.4deg);
  }

  27.12% {
    transform: rotate(78.1deg);
  }

  28.81% {
    transform: rotate(71.2deg);
  }

  30.51% {
    transform: rotate(89.1deg);
  }

  32.2% {
    transform: rotate(105.5deg);
  }

  33.9% {
    transform: rotate(121.3deg);
  }

  35.59% {
    transform: rotate(135.5deg);
  }

  37.29% {
    transform: rotate(148.4deg);
  }

  38.98% {
    transform: rotate(161deg);
  }

  40.68% {
    transform: rotate(173.5deg);
  }

  42.37% {
    transform: rotate(180deg);
  }

  44.07% {
    transform: rotate(180deg);
  }

  45.76% {
    transform: rotate(180deg);
  }

  47.46% {
    transform: rotate(180deg);
  }

  49.15% {
    transform: rotate(180deg);
  }

  50.85% {
    transform: rotate(180deg);
  }

  52.54% {
    transform: rotate(180deg);
  }

  54.24% {
    transform: rotate(180deg);
  }

  55.93% {
    transform: rotate(180deg);
  }

  57.63% {
    transform: rotate(180deg);
  }

  59.32% {
    transform: rotate(180deg);
  }

  61.02% {
    transform: rotate(180deg);
  }

  62.71% {
    transform: rotate(180deg);
  }

  64.41% {
    transform: rotate(180deg);
  }

  66.1% {
    transform: rotate(180deg);
  }

  67.8% {
    transform: rotate(180deg);
  }

  69.49% {
    transform: rotate(180deg);
  }

  71.19% {
    transform: rotate(180deg);
  }

  72.88% {
    transform: rotate(180deg);
  }

  74.58% {
    transform: rotate(180deg);
  }

  76.27% {
    transform: rotate(180deg);
  }

  77.97% {
    transform: rotate(180deg);
  }

  79.66% {
    transform: rotate(180deg);
  }

  81.36% {
    transform: rotate(180deg);
  }

  83.05% {
    transform: rotate(180deg);
  }

  84.75% {
    transform: rotate(180deg);
  }

  86.44% {
    transform: rotate(180deg);
  }

  88.14% {
    transform: rotate(180deg);
  }

  89.83% {
    transform: rotate(180deg);
  }

  91.53% {
    transform: rotate(180deg);
  }

  93.22% {
    transform: rotate(180deg);
  }

  94.92% {
    transform: rotate(180deg);
  }

  96.61% {
    transform: rotate(180deg);
  }

  98.31% {
    transform: rotate(180deg);
  }

  100% {
    transform: rotate(180deg);
  }
}

@keyframes spectrum-fills-rotate {
  0% {
    transform: rotate(-90deg);
  }
  100% {
    transform: rotate(270deg);
  }
}

.spectrum-ProgressCircle {
  display: inline-block;
  width: var(--spectrum-progresscircle-medium-width, var(--spectrum-global-dimension-size-400));
  height: var(--spectrum-progresscircle-medium-height, var(--spectrum-global-dimension-size-400));
  position: relative;
  direction: ltr;
}

.spectrum-ProgressCircle-track {
  box-sizing: border-box;
  width: var(--spectrum-progresscircle-medium-width, var(--spectrum-global-dimension-size-400));
  height: var(--spectrum-progresscircle-medium-height, var(--spectrum-global-dimension-size-400));
  border-style: solid;
  border-width: var(--spectrum-progresscircle-medium-border-size);
  border-radius: var(--spectrum-progresscircle-medium-width, var(--spectrum-global-dimension-size-400));
}

[dir="ltr"] .spectrum-ProgressCircle-fills {
  left: 0;
}

[dir="rtl"] .spectrum-ProgressCircle-fills {
  right: 0;
}

.spectrum-ProgressCircle-fills {
  position: absolute;
  top: 0;
  width: 100%;
  height: 100%;
}

.spectrum-ProgressCircle-fill {
  box-sizing: border-box;
  width: var(--spectrum-progresscircle-medium-width, var(--spectrum-global-dimension-size-400));
  height: var(--spectrum-progresscircle-medium-height, var(--spectrum-global-dimension-size-400));
  border-style: solid;
  border-width: var(--spectrum-progresscircle-medium-border-size);
  border-radius: var(--spectrum-progresscircle-medium-width, var(--spectrum-global-dimension-size-400));
}

.spectrum-ProgressCircle-fillMask1,
.spectrum-ProgressCircle-fillMask2 {
  width: 50%;
  height: 100%;
  transform-origin: 100% center;
  transform: rotate(180deg);
  overflow: hidden;
  position: absolute;
}

.spectrum-ProgressCircle-fillSubMask1,
.spectrum-ProgressCircle-fillSubMask2 {
  width: 100%;
  height: 100%;
  transform-origin: 100% center;
  overflow: hidden;
  transform: rotate(-180deg);
}

.spectrum-ProgressCircle-fillMask2 {
  transform: rotate(0deg);
}

.spectrum-ProgressCircle--small {
  width: var(--spectrum-progresscircle-small-width, var(--spectrum-global-dimension-size-200));
  height: var(--spectrum-progresscircle-small-height, var(--spectrum-global-dimension-size-200));
}

.spectrum-ProgressCircle--small .spectrum-ProgressCircle-track {
    width: var(--spectrum-progresscircle-small-width, var(--spectrum-global-dimension-size-200));
    height: var(--spectrum-progresscircle-small-height, var(--spectrum-global-dimension-size-200));
    border-style: solid;
    border-width: var(--spectrum-progresscircle-small-border-size);
    border-radius: var(--spectrum-progresscircle-small-width, var(--spectrum-global-dimension-size-200));
  }

.spectrum-ProgressCircle--small .spectrum-ProgressCircle-fill {
    width: var(--spectrum-progresscircle-small-width, var(--spectrum-global-dimension-size-200));
    height: var(--spectrum-progresscircle-small-height, var(--spectrum-global-dimension-size-200));
    border-style: solid;
    border-width: var(--spectrum-progresscircle-small-border-size);
    border-radius: var(--spectrum-progresscircle-small-width, var(--spectrum-global-dimension-size-200));
  }

.spectrum-ProgressCircle--large {
  width: var(--spectrum-progresscircle-large-width, var(--spectrum-global-dimension-size-800));
  height: var(--spectrum-progresscircle-large-height, var(--spectrum-global-dimension-size-800));
}

.spectrum-ProgressCircle--large .spectrum-ProgressCircle-track {
    width: var(--spectrum-progresscircle-large-width, var(--spectrum-global-dimension-size-800));
    height: var(--spectrum-progresscircle-large-height, var(--spectrum-global-dimension-size-800));
    border-style: solid;
    border-width: var(--spectrum-progresscircle-large-border-size, var(--spectrum-global-dimension-size-50));
    border-radius: var(--spectrum-progresscircle-large-width, var(--spectrum-global-dimension-size-800));
  }

.spectrum-ProgressCircle--large .spectrum-ProgressCircle-fill {
    width: var(--spectrum-progresscircle-large-width, var(--spectrum-global-dimension-size-800));
    height: var(--spectrum-progresscircle-large-height, var(--spectrum-global-dimension-size-800));
    border-style: solid;
    border-width: var(--spectrum-progresscircle-large-border-size, var(--spectrum-global-dimension-size-50));
    border-radius: var(--spectrum-progresscircle-large-width, var(--spectrum-global-dimension-size-800));
  }

.spectrum-ProgressCircle--indeterminate .spectrum-ProgressCircle-fills {
    will-change: transform;
    transform: translateZ(0);
    animation: 1s infinite cubic-bezier(0.25, 0.78, 0.48, 0.89)
      spectrum-fills-rotate;
    transform-origin: center;
  }

.spectrum-ProgressCircle--indeterminate .spectrum-ProgressCircle-fillSubMask1 {
    will-change: transform;
    transform: translateZ(0);
    animation: 1s infinite linear spectrum-fill-mask-1;
  }

.spectrum-ProgressCircle--indeterminate .spectrum-ProgressCircle-fillSubMask2 {
    will-change: transform;
    transform: translateZ(0);
    animation: 1s infinite linear spectrum-fill-mask-2;
  }

.spectrum-ProgressCircle-track {
  border-color: var(--spectrum-progresscircle-medium-track-color, var(--spectrum-alias-track-color-default));
}

.spectrum-ProgressCircle-fill {
  border-color: var(--spectrum-progresscircle-medium-track-fill-color, var(--spectrum-global-color-blue-500));
}

.spectrum-ProgressCircle--overBackground .spectrum-ProgressCircle-track {
    border-color: var(--spectrum-progresscircle-medium-over-background-track-color, var(--spectrum-alias-track-color-over-background));
  }

.spectrum-ProgressCircle--overBackground .spectrum-ProgressCircle-fill {
    border-color: var(--spectrum-progresscircle-medium-over-background-track-fill-color, var(--spectrum-global-color-static-white));
  }

.spectrum-ProgressCircle--indeterminate.spectrum-ProgressCircle--overBackground .spectrum-ProgressCircle-track {
    border-color: var(--spectrum-progresscircle-medium-over-background-track-color, var(--spectrum-alias-track-color-over-background));
  }

.spectrum-ProgressCircle--indeterminate.spectrum-ProgressCircle--overBackground .spectrum-ProgressCircle-fill {
    border-color: var(--spectrum-progresscircle-medium-over-background-track-fill-color, var(--spectrum-global-color-static-white));
  }
.spectrum-StatusLight--sizeS {
  --spectrum-statuslight-info-text-font-weight: var(--spectrum-statuslight-info-s-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-statuslight-info-text-line-height: var(--spectrum-statuslight-info-s-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-statuslight-info-text-size: var(--spectrum-statuslight-info-s-text-size, var(--spectrum-alias-item-text-size-s));
  --spectrum-statuslight-info-dot-size: var(--spectrum-statuslight-info-s-dot-size, var(--spectrum-alias-item-control-1-size-s));
  --spectrum-statuslight-info-text-gap: var(--spectrum-statuslight-info-s-text-gap, var(--spectrum-alias-item-control-gap-s));
  --spectrum-statuslight-info-height: var(--spectrum-statuslight-info-s-height, var(--spectrum-alias-item-height-s));
}

.spectrum-StatusLight--sizeM {
  --spectrum-statuslight-info-text-font-weight: var(--spectrum-statuslight-info-m-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-statuslight-info-text-line-height: var(--spectrum-statuslight-info-m-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-statuslight-info-text-size: var(--spectrum-statuslight-info-m-text-size, var(--spectrum-alias-item-text-size-m));
  --spectrum-statuslight-info-dot-size: var(--spectrum-statuslight-info-m-dot-size, var(--spectrum-alias-item-control-1-size-m));
  --spectrum-statuslight-info-text-gap: var(--spectrum-statuslight-info-m-text-gap, var(--spectrum-alias-item-control-gap-m));
  --spectrum-statuslight-info-height: var(--spectrum-statuslight-info-m-height, var(--spectrum-alias-item-height-m));
}

.spectrum-StatusLight--sizeL {
  --spectrum-statuslight-info-text-font-weight: var(--spectrum-statuslight-info-l-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-statuslight-info-text-line-height: var(--spectrum-statuslight-info-l-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-statuslight-info-text-size: var(--spectrum-statuslight-info-l-text-size, var(--spectrum-alias-item-text-size-l));
  --spectrum-statuslight-info-dot-size: var(--spectrum-statuslight-info-l-dot-size, var(--spectrum-alias-item-control-1-size-l));
  --spectrum-statuslight-info-text-gap: var(--spectrum-statuslight-info-l-text-gap, var(--spectrum-alias-item-control-gap-l));
  --spectrum-statuslight-info-height: var(--spectrum-statuslight-info-l-height, var(--spectrum-alias-item-height-l));
}

.spectrum-StatusLight--sizeXL {
  --spectrum-statuslight-info-text-font-weight: var(--spectrum-statuslight-info-xl-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-statuslight-info-text-line-height: var(--spectrum-statuslight-info-xl-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-statuslight-info-text-size: var(--spectrum-statuslight-info-xl-text-size, var(--spectrum-alias-item-text-size-xl));
  --spectrum-statuslight-info-dot-size: var(--spectrum-statuslight-info-xl-dot-size, var(--spectrum-alias-item-control-1-size-xl));
  --spectrum-statuslight-info-text-gap: var(--spectrum-statuslight-info-xl-text-gap, var(--spectrum-alias-item-control-gap-xl));
  --spectrum-statuslight-info-height: var(--spectrum-statuslight-info-xl-height, var(--spectrum-alias-item-height-xl));
}

.spectrum-StatusLight {
  --spectrum-statuslight-info-padding-y: var(
    --spectrum-global-dimension-size-65
  );
  --spectrum-statuslight-info-text-line-height: 1.44;
  --spectrum-statuslight-info-padding-top: calc(var(--spectrum-statuslight-info-padding-y) - 1px);
  --spectrum-statuslight-info-padding-bottom: calc(var(--spectrum-statuslight-info-padding-y) + 1px);
}

.spectrum-StatusLight {
  min-height: var(--spectrum-statuslight-info-height);
  display: -ms-flexbox;
  display: flex;
  -ms-flex-direction: row;
      flex-direction: row;
  -ms-flex-align: start;
      align-items: flex-start;

  padding-top: var(--spectrum-statuslight-info-padding-top);

  padding-bottom: var(--spectrum-statuslight-info-padding-bottom);
  padding-left: 0;
  padding-right: 0;
  box-sizing: border-box;

  font-size: var(--spectrum-statuslight-info-text-size);
  font-weight: var(--spectrum-statuslight-info-text-font-weight);
  line-height: var(--spectrum-statuslight-info-text-line-height);
}

.spectrum-StatusLight::before {
    content: "";
    -ms-flex-positive: 0;
        flex-grow: 0;
    -ms-flex-negative: 0;
        flex-shrink: 0;
    display: inline-block;
    width: var(--spectrum-statuslight-info-dot-size);
    height: var(--spectrum-statuslight-info-dot-size);
    border-radius: 50%;
    margin-top: var(--spectrum-statuslight-info-padding-bottom);
    margin-bottom: var(--spectrum-statuslight-info-padding-top);
    margin-left: var(--spectrum-statuslight-info-text-gap);
    margin-right: var(--spectrum-statuslight-info-text-gap);
    -ms-high-contrast-adjust: none;
    forced-color-adjust: none;
  }

.spectrum-StatusLight--neutral {
  font-style: italic;
}

.spectrum-StatusLight {
  color: var(--spectrum-statuslight-info-m-text-color, var(--spectrum-alias-text-color));
}

.spectrum-StatusLight[disabled],
  .spectrum-StatusLight.is-disabled {
    color: var(--spectrum-statuslight-info-m-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }

.spectrum-StatusLight[disabled]::before, .spectrum-StatusLight.is-disabled::before {
      background-color: var(--spectrum-statuslight-info-m-dot-color-disabled, var(--spectrum-global-color-gray-400));
    }

.spectrum-StatusLight--negative::before {
  background-color: var(--spectrum-statuslight-negative-m-dot-color, var(--spectrum-semantic-negative-color-status));
}

.spectrum-StatusLight--notice::before {
  background-color: var(--spectrum-statuslight-notice-m-dot-color, var(--spectrum-semantic-notice-color-status));
}

.spectrum-StatusLight--positive::before {
  background-color: var(--spectrum-statuslight-positive-m-dot-color, var(--spectrum-semantic-positive-color-status));
}

.spectrum-StatusLight--info::before,
/** @deprecated */.spectrum-StatusLight--active::before {
  background-color: var(--spectrum-statuslight-info-m-dot-color, var(--spectrum-semantic-informative-color-status));
}

.spectrum-StatusLight--neutral {
  color: var(--spectrum-statuslight-neutral-m-text-color, var(--spectrum-alias-label-text-color));
}

.spectrum-StatusLight--neutral::before {
    background-color: var(--spectrum-statuslight-neutral-m-dot-color, var(--spectrum-global-color-gray-500));
  }

.spectrum-StatusLight--celery::before {
  background-color: var(--spectrum-statuslight-celery-m-dot-color, var(--spectrum-global-color-celery-400));
}

.spectrum-StatusLight--yellow::before {
  background-color: var(--spectrum-statuslight-yellow-m-dot-color, var(--spectrum-global-color-yellow-400));
}

.spectrum-StatusLight--fuchsia::before {
  background-color: var(--spectrum-statuslight-fuchsia-m-dot-color, var(--spectrum-global-color-fuchsia-400));
}

.spectrum-StatusLight--indigo::before {
  background-color: var(--spectrum-statuslight-indigo-m-dot-color, var(--spectrum-global-color-indigo-400));
}

.spectrum-StatusLight--seafoam::before {
  background-color: var(--spectrum-statuslight-seafoam-m-dot-color, var(--spectrum-global-color-seafoam-400));
}

.spectrum-StatusLight--chartreuse::before {
  background-color: var(--spectrum-statuslight-chartreuse-m-dot-color, var(--spectrum-global-color-chartreuse-400));
}

.spectrum-StatusLight--magenta::before {
  background-color: var(--spectrum-statuslight-magenta-m-dot-color, var(--spectrum-global-color-magenta-400));
}

.spectrum-StatusLight--purple::before {
  background-color: var(--spectrum-statuslight-purple-m-dot-color, var(--spectrum-global-color-purple-400));
}
.spectrum-StatusLight.svelte-1wk2ay6{display:flex;flex-direction:row;justify-content:center;align-items:center;--spectrum-statuslight-info-text-gap:4px;min-height:0;padding-top:0;padding-bottom:0}.spectrum-StatusLight.withText.svelte-1wk2ay6::before{margin-right:10px}.spectrum-StatusLight.svelte-1wk2ay6::before{transition:background-color ease-out 160ms}.custom.svelte-1wk2ay6::before{background-color:var(--color) !important}.square.svelte-1wk2ay6::before{width:14px;height:14px;border-radius:4px;margin:0}.hoverable.svelte-1wk2ay6:hover{cursor:pointer;color:var(--spectrum-global-color-gray-900)}.spectrum-StatusLight--sizeXS.svelte-1wk2ay6::before{width:10px;height:10px;border-radius:2px}.spectrum-StatusLight--disabled.svelte-1wk2ay6::before{background-color:var(--spectrum-global-color-gray-400) !important}.spectrum-Tags {
  --spectrum-tag-border-size: var(--spectrum-tag-s-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-tag-icon-gap: var(--spectrum-tag-s-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-s));
  --spectrum-tag-text-size: var(--spectrum-tag-s-text-size, var(--spectrum-alias-item-text-size-s));
  --spectrum-tag-height: var(--spectrum-tag-s-height, var(--spectrum-alias-item-height-s));
  --spectrum-tag-padding-left: var(--spectrum-tag-s-padding-left, var(--spectrum-alias-item-workflow-padding-left-s));
  --spectrum-tag-padding-right: var(--spectrum-tag-s-padding-right, var(--spectrum-alias-item-padding-s));
  --spectrum-tag-avatar-padding-x: var(--spectrum-tag-icon-gap);
  --spectrum-taggroup-tag-gap-x: var(--spectrum-global-dimension-size-100);
  --spectrum-taggroup-tag-gap-y: var(--spectrum-global-dimension-size-100);
}

.spectrum-Tags {
  display: inline-block;

  margin: 0;
  padding: 0;
  list-style: none;
}

[dir="ltr"] .spectrum-Tags-item {
  padding-left: calc(var(--spectrum-tag-padding-left) - var(--spectrum-tag-border-size));
}

[dir="rtl"] .spectrum-Tags-item {
  padding-right: calc(var(--spectrum-tag-padding-left) - var(--spectrum-tag-border-size));
}

[dir="ltr"] .spectrum-Tags-item {
  padding-right: calc(var(--spectrum-tag-padding-right) - var(--spectrum-tag-border-size));
}

[dir="rtl"] .spectrum-Tags-item {
  padding-left: calc(var(--spectrum-tag-padding-right) - var(--spectrum-tag-border-size));
}

.spectrum-Tags-item {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-align: center;
      align-items: center;
  box-sizing: border-box;

  margin-top: calc(var(--spectrum-taggroup-tag-gap-y) / 2);

  margin-bottom: calc(var(--spectrum-taggroup-tag-gap-y) / 2);
  margin-left: calc(var(--spectrum-taggroup-tag-gap-x) / 2);
  margin-right: calc(var(--spectrum-taggroup-tag-gap-x) / 2);
  padding-top: 0;
  padding-bottom: 0;
  height: var(--spectrum-tag-height);
  max-width: 100%;

  border-width: var(--spectrum-tag-border-size);
  border-style: solid;
  border-radius: var(--spectrum-alias-border-radius-regular, var(--spectrum-global-dimension-size-50));
  outline: none;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;

  transition: border-color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
    color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
    box-shadow var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
    background-color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
}

.spectrum-Tags-item.is-disabled {
    pointer-events: none;
  }

[dir="ltr"] .spectrum-Tags-item > .spectrum-Icon,[dir="ltr"] 
  .spectrum-Tags-item > .spectrum-Avatar {
    margin-right: var(--spectrum-tag-icon-gap);
}

[dir="rtl"] .spectrum-Tags-item > .spectrum-Icon,[dir="rtl"] 
  .spectrum-Tags-item > .spectrum-Avatar {
    margin-left: var(--spectrum-tag-icon-gap);
}

[dir="ltr"] .spectrum-Tags-item > .spectrum-Icon,[dir="ltr"] 
  .spectrum-Tags-item > .spectrum-Avatar {
    margin-left: calc(var(--spectrum-tag-avatar-padding-x) - var(--spectrum-tag-padding-left));
}

[dir="rtl"] .spectrum-Tags-item > .spectrum-Icon,[dir="rtl"] 
  .spectrum-Tags-item > .spectrum-Avatar {
    margin-right: calc(var(--spectrum-tag-avatar-padding-x) - var(--spectrum-tag-padding-left));
}

[dir="ltr"] .spectrum-Tags-item > .spectrum-Icon ~ .spectrum-Tags-itemLabel,[dir="ltr"]  .spectrum-Tags-item > .spectrum-Avatar ~ .spectrum-Tags-itemLabel {
      margin-right: calc(var(--spectrum-tag-avatar-padding-x) - var(--spectrum-tag-padding-right));
}

[dir="rtl"] .spectrum-Tags-item > .spectrum-Icon ~ .spectrum-Tags-itemLabel,[dir="rtl"]  .spectrum-Tags-item > .spectrum-Avatar ~ .spectrum-Tags-itemLabel {
      margin-left: calc(var(--spectrum-tag-avatar-padding-x) - var(--spectrum-tag-padding-right));
}

[dir="ltr"] .spectrum-Tags-item .spectrum-ClearButton {
    margin-right: calc(-1 * var(--spectrum-tag-padding-right));
}

[dir="rtl"] .spectrum-Tags-item .spectrum-ClearButton {
    margin-left: calc(-1 * var(--spectrum-tag-padding-right));
}

.spectrum-Tags-itemLabel {
  height: 100%;
  line-height: calc(var(--spectrum-tag-height) - var(--spectrum-tag-border-size) * 2);
  -ms-flex: 1 1 auto;
      flex: 1 1 auto;
  font-size: var(--spectrum-tag-text-size);
  cursor: default;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.spectrum-Tags-item {
  color: var(--spectrum-tag-m-text-color, var(--spectrum-alias-label-text-color));
  background-color: var(--spectrum-tag-m-background-color, var(--spectrum-global-color-gray-75));
  border-color: var(--spectrum-tag-m-border-color, var(--spectrum-alias-border-color-darker-default));
}

.spectrum-Tags-item .spectrum-ClearButton {
    color: var(--spectrum-tag-m-removable-icon-color, var(--spectrum-alias-icon-color));
  }

.spectrum-Tags-item:hover {
    background-color: var(--spectrum-tag-m-background-color-hover, var(--spectrum-global-color-gray-75));
    color: var(--spectrum-tag-m-text-color-hover, var(--spectrum-alias-text-color-hover));
    border-color: var(--spectrum-tag-m-border-color-hover, var(--spectrum-alias-border-color-darker-hover));
  }

.spectrum-Tags-item:hover .spectrum-ClearButton {
      color: var(--spectrum-tag-m-removable-icon-color-hover, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-Tags-item.focus-ring {
    background-color: var(--spectrum-tag-m-background-color-key-focus, var(--spectrum-global-color-gray-75));
    color: var(--spectrum-tag-m-text-color-key-focus, var(--spectrum-alias-text-color-hover));
    border-color: var(--spectrum-tag-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    box-shadow: 0 0 0 var(--spectrum-alias-focus-ring-size, var(--spectrum-global-dimension-static-size-25)) var(--spectrum-tag-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
  }

.spectrum-Tags-item.focus-ring .spectrum-ClearButton {
      color: var(--spectrum-tag-m-removable-icon-color-key-focus, var(--spectrum-alias-icon-color-focus));
    }

.spectrum-Tags-item.is-selected {
    background-color: var(--spectrum-tag-m-background-color-selected, var(--spectrum-global-color-gray-700));
    color: var(--spectrum-tag-m-text-color-selected, var(--spectrum-alias-text-color-over-background));
    border-color: var(--spectrum-tag-m-border-color-selected, var(--spectrum-global-color-gray-700));
  }

.spectrum-Tags-item.is-selected .spectrum-Tags-itemIcon {
      color: var(--spectrum-tag-m-icon-color-selected, var(--spectrum-alias-icon-color-over-background));
    }

.spectrum-Tags-item.is-selected:hover {
      background-color: var(--spectrum-tag-m-background-color-selected-hover, var(--spectrum-global-color-gray-800));
    }

.spectrum-Tags-item.is-selected.focus-ring {
      box-shadow: 0 0 0 var(--spectrum-alias-focus-ring-size, var(--spectrum-global-dimension-static-size-25)) var(--spectrum-tag-m-border-color-selected-key-focus, var(--spectrum-global-color-gray-800));
      border-color: var(--spectrum-tag-m-text-color-selected-key-focus, var(--spectrum-alias-text-color-over-background));
    }

.spectrum-Tags-item.is-selected.is-invalid {
      border-color: var(--spectrum-tag-m-border-color-error-selected, var(--spectrum-semantic-negative-background-color-default));
      background-color: var(--spectrum-tag-m-background-color-error-selected, var(--spectrum-semantic-negative-background-color-default));
    }

.spectrum-Tags-item.is-selected.is-invalid .spectrum-Tags-itemIcon,
      .spectrum-Tags-item.is-selected.is-invalid .spectrum-Tags-itemLabel,
      .spectrum-Tags-item.is-selected.is-invalid .spectrum-Tags-itemClearButton {
        color: var(--spectrum-tag-m-text-color-error-selected, var(--spectrum-alias-text-color-over-background));
      }

.spectrum-Tags-item.is-selected.is-invalid.focus-ring {
        box-shadow: 0 0 0 var(--spectrum-alias-focus-ring-size, var(--spectrum-global-dimension-static-size-25)) var(--spectrum-tag-m-border-color-error-selected-key-focus, var(--spectrum-semantic-negative-background-color-key-focus));
        border-color: var(--spectrum-tag-m-text-color-selected-key-focus, var(--spectrum-alias-text-color-over-background));
      }

.spectrum-Tags-item.is-selected.is-invalid:hover {
        border-color: var(--spectrum-tag-m-border-color-selected, var(--spectrum-global-color-gray-700));
        background-color: var(--spectrum-tag-m-background-color-error-selected-hover, var(--spectrum-semantic-negative-background-color-hover));
      }

.spectrum-Tags-item.is-selected.is-invalid:hover .spectrum-Tags-itemIcon {
          color: var(--spectrum-tag-m-icon-color-selected, var(--spectrum-alias-icon-color-over-background));
        }

.spectrum-Tags-item.is-invalid {
    color: var(--spectrum-tag-m-icon-color-error, var(--spectrum-semantic-negative-color-icon));
    border-color: var(--spectrum-tag-m-border-color-error, var(--spectrum-semantic-negative-color-default));

  }

.spectrum-Tags-item.is-invalid:hover {
      color: var(--spectrum-tag-m-icon-color-error-hover, var(--spectrum-semantic-negative-color-icon));
      border-color: var(--spectrum-tag-m-border-color-error-hover, var(--spectrum-semantic-negative-color-state-hover));
    }

.spectrum-Tags-item.is-invalid:hover .spectrum-Tags-itemIcon,
      .spectrum-Tags-item.is-invalid:hover .spectrum-Tags-itemClearButton {
        color: var(--spectrum-tag-m-icon-color-error-hover, var(--spectrum-semantic-negative-color-icon));
      }

.spectrum-Tags-item.is-invalid.focus-ring {
      color: var(--spectrum-tag-m-icon-color-error-hover, var(--spectrum-semantic-negative-color-icon));
      border-color: var(--spectrum-tag-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
      box-shadow: 0 0 0 var(--spectrum-alias-focus-ring-size, var(--spectrum-global-dimension-static-size-25)) var(--spectrum-tag-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-Tags-item.is-invalid .spectrum-Tags-itemIcon,
    .spectrum-Tags-item.is-invalid .spectrum-Tags-itemClearButton {
      color: var(--spectrum-tag-m-icon-color-error, var(--spectrum-semantic-negative-color-icon));
    }

.spectrum-Tags-item.is-disabled {
    color: var(--spectrum-tag-m-text-color-disabled, var(--spectrum-alias-text-color-disabled));
    background-color: var(--spectrum-tag-m-background-color-disabled, var(--spectrum-alias-background-color-disabled));
    border-color: var(--spectrum-tag-m-border-color-disabled, var(--spectrum-alias-border-color-disabled));
  }

.spectrum-Tags-item.is-disabled .spectrum-Avatar {
      opacity: var(--spectrum-avatar-size-100-opacity-disabled, 0.3);
    }

.spectrum-Tags-item.is-disabled .spectrum-Tags-itemIcon {
      color: var(--spectrum-tag-m-icon-color-disabled, var(--spectrum-alias-icon-color-disabled));
    }

.spectrum-Tags-item--removable:hover {
    color: var(--spectrum-tag-m-removable-text-color-hover, var(--spectrum-alias-text-color-hover));
  }

.spectrum-Tags-item--removable:hover .spectrum-ClearButton {
      color: var(--spectrum-tag-m-removable-icon-color-hover, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-Tags-item--removable:active {
    color: var(--spectrum-tag-m-removable-text-color-down, var(--spectrum-alias-text-color-down));
  }

.spectrum-Tags-item--removable:active .spectrum-ClearButton {
      color: var(--spectrum-tag-m-removable-icon-color-down, var(--spectrum-alias-icon-color-down));
    }

.spectrum-Tags-item--removable.is-invalid:hover {
      border-color: var(--spectrum-tag-m-removable-border-color-error-hover, var(--spectrum-semantic-negative-color-state-hover));
      color: var(--spectrum-tag-m-removable-text-color-error-hover, var(--spectrum-semantic-negative-color-state-down));
    }

.spectrum-Tags-item--removable.is-invalid:hover .spectrum-ClearButton {
        color: var(--spectrum-tag-m-removable-icon-color-error-hover, var(--spectrum-semantic-negative-color-icon));
      }

.spectrum-Tags-item--removable.is-invalid:active {
      border-color: var(--spectrum-tag-m-removable-border-color-error-down, var(--spectrum-semantic-negative-color-state-down));
      color: var(--spectrum-tag-m-removable-text-color-error-down, var(--spectrum-semantic-negative-color-state-down));
    }

.spectrum-Tags-item--removable.is-invalid:active .spectrum-ClearButton {
        color: var(--spectrum-tag-m-removable-icon-color-error-down, var(--spectrum-semantic-negative-color-icon));
      }

.spectrum-Tags-item--removable.focus-ring {
    color: var(--spectrum-tag-m-removable-text-color-key-focus, var(--spectrum-alias-text-color-hover));
  }

.spectrum-Tags-item--removable.focus-ring .spectrum-ClearButton {
      color: var(--spectrum-tag-m-removable-icon-color-key-focus, var(--spectrum-alias-icon-color-focus));
    }

.spectrum-Tags-item--removable.is-selected {
    color: var(--spectrum-tag-m-removable-text-color-selected, var(--spectrum-alias-text-color-over-background));
  }

.spectrum-Tags-item--removable.is-selected.is-focused {
       color: var(--spectrum-tag-m-removable-text-color-selected-key-focus, var(--spectrum-alias-text-color-over-background));
    }

.spectrum-Tags-item--removable.is-selected .spectrum-Tags-itemClearButton {
      color: var(--spectrum-tag-m-removable-button-icon-color-selected, var(--spectrum-alias-icon-color-over-background));
    }

.spectrum-Tags-item--removable.is-selected .spectrum-Tags-itemClearButton:hover {
         color: var(--spectrum-tag-m-removable-button-icon-color-selected-hover, var(--spectrum-alias-icon-color-over-background));
      }

.spectrum-Tags-item--removable.is-selected.is-invalid {
      color: var(--spectrum-tag-m-removable-text-color-error-key-focus, var(--spectrum-semantic-negative-color-state-down));
    }

.spectrum-Tags-item--removable .spectrum-Tags-itemClearButton.is-focused {
      border-color: var(--spectrum-tag-m-removable-border-color-key-focus, var(--spectrum-alias-border-color-focus));
      background-color: var(--spectrum-tag-m-removable-button-background-color-key-focus, var(--spectrum-global-color-gray-75));
      color: var(--spectrum-tag-m-removable-button-icon-color-key-focus, var(--spectrum-alias-icon-color-focus));
    }

.spectrum-Tags-item--removable .spectrum-Tags-itemClearButton:hover {
      color: var(--spectrum-tag-m-removable-button-icon-color-hover, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-Tags-item--removable .spectrum-Tags-itemClearButton:active {
      background-color: var(--spectrum-tag-m-removable-button-background-color-hover, var(--spectrum-global-color-gray-75));
    }
.spectrum-Avatar {
  width: var(--spectrum-avatar-size-50-width, var(--spectrum-alias-avatar-size-50));
  height: var(--spectrum-avatar-size-50-height, var(--spectrum-alias-avatar-size-50));

  border-radius: var(--spectrum-avatar-size-50-border-radius, 50%);
  border-style: none;

  -webkit-user-drag: none;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
}

.spectrum-Avatar {
  opacity: var(--spectrum-avatar-size-100-opacity, 1);
}

.spectrum-Avatar.is-disabled {
    opacity: var(--spectrum-avatar-size-100-opacity-disabled, 0.3);
  }
div.svelte-xutedg{color:white;display:grid;place-items:center;font-weight:600;border-radius:50%;overflow:hidden;user-select:none;text-transform:uppercase;flex-shrink:0}.spectrum-Tags-item.svelte-gzjwsm{margin-bottom:0;margin-top:0;gap:3px;border-radius:8px}.is-emphasized.svelte-gzjwsm{background-color:rgba(75, 117, 255, 0.2);border:0.5px solid rgba(75, 117, 255, 0.2);border-radius:6px;padding:1px 3px;color:var(--spectrum-global-color-gray-900)}.spectrum-Tags.svelte-17cj8k0{margin-top:-8px;margin-left:-4px}.spectrum-Tags.svelte-17cj8k0 .spectrum-Tags-item{margin:8px 0 0 4px !important}.spectrum-Search {
  --spectrum-search-quiet-button-offset: calc(var(--spectrum-actionbutton-m-min-width, var(--spectrum-global-dimension-size-400)) / 2 - var(--spectrum-icon-cross-small-width, var(--spectrum-global-dimension-size-100)) / 2);
}

.spectrum-Search {
  display: inline-block;
  position: relative;
}

[dir="ltr"] .spectrum-Search-clearButton {
  right: 0;
}

[dir="rtl"] .spectrum-Search-clearButton {
  left: 0;
}

.spectrum-Search-clearButton {
  position: absolute;
  top: 0;
}

.spectrum-Search-input {
  -webkit-appearance: none;
  outline-offset: -2px;
}

.spectrum-Search-input::-webkit-search-cancel-button,
  .spectrum-Search-input::-webkit-search-decoration {
    -webkit-appearance: none;
  }

.spectrum-Search--quiet .spectrum-Search-clearButton {
    transform: translateX(var(--spectrum-search-quiet-button-offset));
  }

.spectrum-Search-icon {
  color: var(--spectrum-textfield-m-icon-color, var(--spectrum-alias-icon-color));
}

.spectrum-Search-input:hover ~ .spectrum-Search-icon {
      color: var(--spectrum-search-m-icon-color-hover, var(--spectrum-global-color-gray-900));
    }

.spectrum-Search-input:active ~ .spectrum-Search-icon {
      color: var(--spectrum-search-m-icon-color-down, var(--spectrum-alias-icon-color-down));
    }

.spectrum-Search-input.focus-ring ~ .spectrum-Search-icon {
      color: var(--spectrum-search-m-icon-color-key-focus, var(--spectrum-global-color-gray-900));
    }

.spectrum-Search-input:disabled ~ .spectrum-Search-icon {
      color: var(--spectrum-textfield-m-text-color-disabled, var(--spectrum-alias-text-color-disabled));
    }
.spectrum-Search.svelte-16dnyba,.spectrum-Textfield.svelte-16dnyba{width:100%}.spectrum-Search-input.svelte-16dnyba{padding-left:35px;padding-right:24px}.is-disabled.svelte-16dnyba{pointer-events:none}.spectrum-Search-clearButton.svelte-16dnyba{position:absolute}.search-icon.svelte-16dnyba{position:absolute;top:9px;left:var(--spectrum-textfield-error-icon-margin-left)}.icon-dims.svelte-1mz1j8w{height:15px;width:auto}.spectrum-Picker.svelte-eaxbys.svelte-eaxbys{width:100%;box-shadow:none}.spectrum-Picker-label.auto-width.svelte-eaxbys.svelte-eaxbys{margin-right:var(--spacing-xs)}.spectrum-Picker-label.svelte-eaxbys.svelte-eaxbys:not(.auto-width){overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:0}.placeholder.svelte-eaxbys.svelte-eaxbys{font-style:italic}.spectrum-Picker-label.auto-width.is-placeholder.svelte-eaxbys.svelte-eaxbys{padding-right:2px}.check.svelte-eaxbys.svelte-eaxbys{display:none;padding-left:8px}li.is-selected.svelte-eaxbys .check.svelte-eaxbys{display:block}.option-extra.svelte-eaxbys.svelte-eaxbys{padding-right:8px}.option-extra.icon.svelte-eaxbys.svelte-eaxbys{margin:0 -1px}.popover-content.svelte-eaxbys.svelte-eaxbys{display:contents}.popover-content.auto-width.svelte-eaxbys .spectrum-Menu-itemLabel.svelte-eaxbys{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.popover-content.svelte-eaxbys:not(.auto-width) .spectrum-Menu-itemLabel.svelte-eaxbys{width:0;flex:1 1 auto;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.popover-content.auto-width.svelte-eaxbys .spectrum-Menu-item.svelte-eaxbys{padding-right:var(--spacing-xl)}.spectrum-Menu-item.is-disabled.svelte-eaxbys.svelte-eaxbys{pointer-events:none}.popover-content.svelte-eaxbys .spectrum-Search{margin-top:-1px;width:100%}.popover-content.svelte-eaxbys .spectrum-Search input{height:auto;border-bottom-left-radius:0;border-bottom-right-radius:0;border-left:0;border-right:0;padding-top:var(--spectrum-global-dimension-size-100);padding-bottom:var(--spectrum-global-dimension-size-100)}.popover-content.svelte-eaxbys .spectrum-Search .spectrum-ClearButton{right:2px;top:2px}.popover-content.svelte-eaxbys .spectrum-Search .spectrum-Textfield-icon{top:9px}.footer.svelte-eaxbys.svelte-eaxbys{padding:4px 12px 12px 12px;font-style:italic;max-width:170px;font-size:12px}.option-extra.icon.field-icon.svelte-eaxbys.svelte-eaxbys{display:flex}.option-tag.svelte-eaxbys.svelte-eaxbys{margin:0 var(--spacing-m) 0 var(--spacing-m)}.option-tag.svelte-eaxbys .spectrum-Tags-item > i{margin-top:2px}.loading.svelte-eaxbys.svelte-eaxbys{position:fixed;justify-content:center;right:var(--spacing-s);top:var(--spacing-s)}.loading--withAutocomplete.svelte-eaxbys.svelte-eaxbys{top:calc(34px + var(--spacing-m))}.subtitle-text.svelte-eaxbys.svelte-eaxbys{font-size:12px;line-height:15px;font-weight:500;color:var(--spectrum-global-color-gray-600);display:block;margin-top:var(--spacing-s)}.select-all-item.svelte-eaxbys.svelte-eaxbys{border-bottom:1px solid var(--spectrum-global-color-gray-200);margin-bottom:4px}.select-all-item.svelte-eaxbys .select-all-check.svelte-eaxbys{display:block}.spectrum-Calendar.svelte-ixg9b0.svelte-ixg9b0{width:auto}.spectrum-Calendar-header.svelte-ixg9b0.svelte-ixg9b0{width:auto}.spectrum-Calendar-title.svelte-ixg9b0.svelte-ixg9b0{display:flex;justify-content:flex-start;align-items:stretch;flex:1 1 auto}.spectrum-Calendar-header.svelte-ixg9b0 button.svelte-ixg9b0{border-radius:4px}.spectrum-Calendar-date.is-outsideMonth.svelte-ixg9b0.svelte-ixg9b0{visibility:visible;color:var(--spectrum-global-color-gray-400)}.spectrum-Calendar-date.is-today.svelte-ixg9b0.svelte-ixg9b0,.spectrum-Calendar-date.is-today.svelte-ixg9b0.svelte-ixg9b0::before{border-color:var(--spectrum-global-color-gray-400)}.spectrum-Calendar-date.is-today.is-selected.svelte-ixg9b0.svelte-ixg9b0,.spectrum-Calendar-date.is-today.is-selected.svelte-ixg9b0.svelte-ixg9b0::before{border-color:var(
      --primaryColorHover,
      var(--spectrum-global-color-blue-700)
    )}.spectrum-Calendar-date.is-selected.svelte-ixg9b0.svelte-ixg9b0:not(.is-range-selection){background:var(--primaryColor, var(--spectrum-global-color-blue-400))}.spectrum-Calendar.svelte-ixg9b0 tr.svelte-ixg9b0{box-sizing:content-box;height:40px}.spectrum-Calendar-tableCell.svelte-ixg9b0.svelte-ixg9b0{box-sizing:content-box}.spectrum-Calendar-nextMonth.svelte-ixg9b0.svelte-ixg9b0,.spectrum-Calendar-prevMonth.svelte-ixg9b0.svelte-ixg9b0{order:1;padding:4px}.spectrum-Calendar-date.svelte-ixg9b0.svelte-ixg9b0{color:var(--spectrum-alias-text-color)}.spectrum-Calendar-date.is-selected.svelte-ixg9b0.svelte-ixg9b0{color:white}.spectrum-Calendar-dayOfWeek.svelte-ixg9b0.svelte-ixg9b0{color:var(--spectrum-global-color-gray-600)}.month-selector.svelte-ixg9b0 .spectrum-Picker{background:none;border:none;padding:4px 6px}.month-selector.svelte-ixg9b0 .spectrum-Picker:hover,.month-selector.svelte-ixg9b0 .spectrum-Picker.is-open{background:var(--spectrum-global-color-gray-200)}.month-selector.svelte-ixg9b0 .spectrum-Picker-label{font-size:18px;font-weight:bold}.spectrum-ActionButton {
  --spectrum-button-line-height: 1.3;
  position: relative;

  display: -ms-inline-flexbox;

  display: inline-flex;
  box-sizing: border-box;

  -ms-flex-align: center;

      align-items: center;
  -ms-flex-pack: center;
      justify-content: center;
  overflow: visible;
  margin: 0;

  border-style: solid;
  text-transform: none;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  -webkit-appearance: button;
  vertical-align: top;

  transition: background var(--spectrum-global-animation-duration-100, 130ms) ease-out,
    border-color var(--spectrum-global-animation-duration-100, 130ms) ease-out,
    color var(--spectrum-global-animation-duration-100, 130ms) ease-out,
    box-shadow var(--spectrum-global-animation-duration-100, 130ms) ease-out;

  text-decoration: none;
  font-family: var(--spectrum-alias-body-text-font-family, var(--spectrum-global-font-family-base));

  line-height: var(--spectrum-button-line-height);

  -moz-user-select: none;

   -ms-user-select: none;

       user-select: none;
  -webkit-user-select: none;

  cursor: pointer;
}

.spectrum-ActionButton:focus {
    outline: none;
  }

.spectrum-ActionButton::-moz-focus-inner {
    border: 0;
    border-style: none;
    padding: 0;
    margin-top: -2px;
    margin-bottom: -2px;
  }

.spectrum-ActionButton:disabled {
    cursor: default;
  }

.spectrum-ActionButton .spectrum-Icon {
  max-height: 100%;
  -ms-flex-negative: 0;
      flex-shrink: 0;
}

a.spectrum-ActionButton {
  -webkit-appearance: none;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
}

.spectrum-ActionButton-label {
  -ms-flex-item-align: center;
      -ms-grid-row-align: center;
      align-self: center;
  justify-self: center;
  text-align: center;
}

.spectrum-ActionButton-label:empty {
    display: none;
  }

.spectrum-ActionButton--sizeS {
  --spectrum-actionbutton-quiet-border-size: var(--spectrum-actionbutton-s-quiet-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-actionbutton-quiet-border-radius: var(--spectrum-actionbutton-s-quiet-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-actionbutton-quiet-text-font-weight: var(--spectrum-actionbutton-s-quiet-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-actionbutton-quiet-text-size: var(--spectrum-actionbutton-s-quiet-text-size, var(--spectrum-alias-item-text-size-s));
  --spectrum-actionbutton-border-size: var(--spectrum-actionbutton-s-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-actionbutton-border-radius: var(--spectrum-actionbutton-s-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-actionbutton-min-width: var(--spectrum-actionbutton-s-min-width, var(--spectrum-global-dimension-size-400));
  --spectrum-actionbutton-text-font-weight: var(--spectrum-actionbutton-s-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-actionbutton-text-line-height: var(--spectrum-actionbutton-s-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-actionbutton-text-size: var(--spectrum-actionbutton-s-text-size, var(--spectrum-alias-item-text-size-s));
  --spectrum-actionbutton-icon-gap: var(--spectrum-actionbutton-s-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-s));
  --spectrum-actionbutton-height: var(--spectrum-actionbutton-s-height, var(--spectrum-alias-item-height-s));
  --spectrum-actionbutton-padding-left: var(--spectrum-actionbutton-s-padding-left, var(--spectrum-alias-item-workflow-padding-left-s));
  --spectrum-actionbutton-icononly-padding-left: var(--spectrum-actionbutton-s-icononly-padding-left, var(--spectrum-alias-item-icononly-padding-s));
  --spectrum-actionbutton-icononly-padding-right: var(--spectrum-actionbutton-s-icononly-padding-right, var(--spectrum-alias-item-icononly-padding-s));
  --spectrum-actionbutton-textonly-padding-left: var(--spectrum-actionbutton-s-textonly-padding-left, var(--spectrum-alias-item-padding-s));
  --spectrum-actionbutton-textonly-padding-right: var(--spectrum-actionbutton-s-textonly-padding-right, var(--spectrum-alias-item-padding-s));
  --spectrum-actionbutton-hold-icon-padding-bottom: var(--spectrum-global-dimension-size-25);
  --spectrum-actionbutton-hold-icon-padding-right: var(--spectrum-global-dimension-size-25);
}

.spectrum-ActionButton--sizeM {
  --spectrum-actionbutton-quiet-border-size: var(--spectrum-actionbutton-m-quiet-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-actionbutton-quiet-border-radius: var(--spectrum-actionbutton-m-quiet-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-actionbutton-quiet-text-font-weight: var(--spectrum-actionbutton-m-quiet-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-actionbutton-quiet-text-size: var(--spectrum-actionbutton-m-quiet-text-size, var(--spectrum-alias-item-text-size-m));
  --spectrum-actionbutton-border-size: var(--spectrum-actionbutton-m-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-actionbutton-border-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-actionbutton-min-width: var(--spectrum-actionbutton-m-min-width, var(--spectrum-global-dimension-size-400));
  --spectrum-actionbutton-text-font-weight: var(--spectrum-actionbutton-m-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-actionbutton-text-line-height: var(--spectrum-actionbutton-m-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-actionbutton-text-size: var(--spectrum-actionbutton-m-text-size, var(--spectrum-alias-item-text-size-m));
  --spectrum-actionbutton-height: var(--spectrum-actionbutton-m-height, var(--spectrum-alias-item-height-m));
  --spectrum-actionbutton-icon-gap: var(--spectrum-actionbutton-m-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-m));
  --spectrum-actionbutton-padding-left: var(--spectrum-actionbutton-m-padding-left, var(--spectrum-alias-item-workflow-padding-left-m));
  --spectrum-actionbutton-icononly-padding-left: var(--spectrum-actionbutton-m-icononly-padding-left, var(--spectrum-alias-item-icononly-padding-m));
  --spectrum-actionbutton-icononly-padding-right: var(--spectrum-actionbutton-m-icononly-padding-right, var(--spectrum-alias-item-icononly-padding-m));
  --spectrum-actionbutton-textonly-padding-left: var(--spectrum-actionbutton-m-textonly-padding-left, var(--spectrum-alias-item-padding-m));
  --spectrum-actionbutton-textonly-padding-right: var(--spectrum-actionbutton-m-textonly-padding-right, var(--spectrum-alias-item-padding-m));
  --spectrum-actionbutton-hold-icon-padding-bottom: var(--spectrum-global-dimension-size-40);
  --spectrum-actionbutton-hold-icon-padding-right: var(--spectrum-global-dimension-size-40);
}

.spectrum-ActionButton--sizeL {
  --spectrum-actionbutton-quiet-border-size: var(--spectrum-actionbutton-l-quiet-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-actionbutton-quiet-border-radius: var(--spectrum-actionbutton-l-quiet-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-actionbutton-quiet-text-font-weight: var(--spectrum-actionbutton-l-quiet-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-actionbutton-quiet-text-size: var(--spectrum-actionbutton-l-quiet-text-size, var(--spectrum-alias-item-text-size-l));
  --spectrum-actionbutton-border-size: var(--spectrum-actionbutton-l-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-actionbutton-border-radius: var(--spectrum-actionbutton-l-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-actionbutton-min-width: var(--spectrum-actionbutton-l-min-width, var(--spectrum-global-dimension-size-400));
  --spectrum-actionbutton-text-font-weight: var(--spectrum-actionbutton-l-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-actionbutton-text-line-height: var(--spectrum-actionbutton-l-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-actionbutton-text-size: var(--spectrum-actionbutton-l-text-size, var(--spectrum-alias-item-text-size-l));
  --spectrum-actionbutton-icon-gap: var(--spectrum-actionbutton-l-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-l));
  --spectrum-actionbutton-height: var(--spectrum-actionbutton-l-height, var(--spectrum-alias-item-height-l));
  --spectrum-actionbutton-padding-left: var(--spectrum-actionbutton-l-padding-left, var(--spectrum-alias-item-workflow-padding-left-l));
  --spectrum-actionbutton-icononly-padding-left: var(--spectrum-actionbutton-l-icononly-padding-left, var(--spectrum-alias-item-icononly-padding-l));
  --spectrum-actionbutton-icononly-padding-right: var(--spectrum-actionbutton-l-icononly-padding-right, var(--spectrum-alias-item-icononly-padding-l));
  --spectrum-actionbutton-textonly-padding-left: var(--spectrum-actionbutton-l-textonly-padding-left, var(--spectrum-alias-item-padding-l));
  --spectrum-actionbutton-textonly-padding-right: var(--spectrum-actionbutton-l-textonly-padding-right, var(--spectrum-alias-item-padding-l));
  --spectrum-actionbutton-hold-icon-padding-bottom: var(--spectrum-global-dimension-size-50);
  --spectrum-actionbutton-hold-icon-padding-right: var(--spectrum-global-dimension-size-50);
}

.spectrum-ActionButton--sizeXL {
  --spectrum-actionbutton-quiet-border-size: var(--spectrum-actionbutton-xl-quiet-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-actionbutton-quiet-border-radius: var(--spectrum-actionbutton-xl-quiet-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-actionbutton-quiet-text-font-weight: var(--spectrum-actionbutton-xl-quiet-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-actionbutton-quiet-text-size: var(--spectrum-actionbutton-xl-quiet-text-size, var(--spectrum-alias-item-text-size-xl));
  --spectrum-actionbutton-border-size: var(--spectrum-actionbutton-xl-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-actionbutton-border-radius: var(--spectrum-actionbutton-xl-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-actionbutton-min-width: var(--spectrum-actionbutton-xl-min-width, var(--spectrum-global-dimension-size-400));
  --spectrum-actionbutton-text-font-weight: var(--spectrum-actionbutton-xl-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-actionbutton-text-line-height: var(--spectrum-actionbutton-xl-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-actionbutton-icon-gap: var(--spectrum-actionbutton-xl-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-l));
  --spectrum-actionbutton-text-size: var(--spectrum-actionbutton-xl-text-size, var(--spectrum-alias-item-text-size-xl));
  --spectrum-actionbutton-height: var(--spectrum-actionbutton-xl-height, var(--spectrum-alias-item-height-xl));
  --spectrum-actionbutton-padding-left: var(--spectrum-actionbutton-xl-padding-left, var(--spectrum-alias-item-workflow-padding-left-xl));
  --spectrum-actionbutton-icononly-padding-left: var(--spectrum-actionbutton-xl-icononly-padding-left, var(--spectrum-alias-item-icononly-padding-xl));
  --spectrum-actionbutton-icononly-padding-right: var(--spectrum-actionbutton-xl-icononly-padding-right, var(--spectrum-alias-item-icononly-padding-xl));
  --spectrum-actionbutton-textonly-padding-left: var(--spectrum-actionbutton-xl-textonly-padding-left, var(--spectrum-alias-item-padding-xl));
  --spectrum-actionbutton-textonly-padding-right: var(--spectrum-actionbutton-xl-textonly-padding-right, var(--spectrum-alias-item-padding-xl));
  --spectrum-actionbutton-hold-icon-padding-bottom: var(--spectrum-global-dimension-size-65);
  --spectrum-actionbutton-hold-icon-padding-right: var(--spectrum-global-dimension-size-65);
}

.spectrum-ActionButton {
  --spectrum-actionbutton-padding-left-adjusted: calc(var(--spectrum-actionbutton-padding-left) - var(--spectrum-actionbutton-border-size));
  --spectrum-actionbutton-textonly-padding-left-adjusted: calc(var(--spectrum-actionbutton-textonly-padding-left) - var(--spectrum-actionbutton-border-size));
  --spectrum-actionbutton-textonly-padding-right-adjusted: calc(var(--spectrum-actionbutton-textonly-padding-right) - var(--spectrum-actionbutton-border-size));
  --spectrum-actionbutton-icononly-padding-left-adjusted: calc(var(--spectrum-actionbutton-icononly-padding-left) - var(--spectrum-actionbutton-border-size));
  --spectrum-actionbutton-icononly-padding-right-adjusted: calc(var(--spectrum-actionbutton-icononly-padding-right) - var(--spectrum-actionbutton-border-size));
}

[dir="ltr"] .spectrum-ActionButton {
  padding-left: var(--spectrum-actionbutton-textonly-padding-left-adjusted);
  padding-right: var(--spectrum-actionbutton-textonly-padding-right-adjusted);
}

[dir="rtl"] .spectrum-ActionButton {
  padding-right: var(--spectrum-actionbutton-textonly-padding-left-adjusted);
  padding-left: var(--spectrum-actionbutton-textonly-padding-right-adjusted);
}

.spectrum-ActionButton {
  position: relative;

  height: var(--spectrum-actionbutton-height);
  min-width: var(--spectrum-actionbutton-min-width);

  border-width: var(--spectrum-actionbutton-border-size);
  border-radius: var(--spectrum-actionbutton-border-radius);

  font-size: var(--spectrum-actionbutton-text-size);
  font-weight: var(--spectrum-actionbutton-text-font-weight);
  line-height: var(--spectrum-actionbutton-text-line-height);
}

[dir="ltr"] .spectrum-ActionButton .spectrum-Icon {
    margin-left: calc(-1 * (var(--spectrum-actionbutton-textonly-padding-left-adjusted) - var(--spectrum-actionbutton-padding-left-adjusted)));
}

[dir="rtl"] .spectrum-ActionButton .spectrum-Icon {
    margin-right: calc(-1 * (var(--spectrum-actionbutton-textonly-padding-left-adjusted) - var(--spectrum-actionbutton-padding-left-adjusted)));
}

[dir="ltr"] .spectrum-ActionButton .spectrum-Icon + .spectrum-ActionButton-label {
    padding-left: var(--spectrum-actionbutton-icon-gap);
}

[dir="rtl"] .spectrum-ActionButton .spectrum-Icon + .spectrum-ActionButton-label {
    padding-right: var(--spectrum-actionbutton-icon-gap);
}

[dir="ltr"] .spectrum-ActionButton .spectrum-Icon + .spectrum-ActionButton-label {
    padding-right: 0;
}

[dir="rtl"] .spectrum-ActionButton .spectrum-Icon + .spectrum-ActionButton-label {
    padding-left: 0;
}

.spectrum-ActionButton .spectrum-ActionButton-hold + .spectrum-Icon,
  .spectrum-ActionButton .spectrum-Icon:only-child {
    margin-left: calc(-1 * (var(--spectrum-actionbutton-textonly-padding-left-adjusted) - var(--spectrum-actionbutton-icononly-padding-left-adjusted)));
    margin-right: calc(-1 * (var(--spectrum-actionbutton-textonly-padding-right-adjusted) - var(--spectrum-actionbutton-icononly-padding-right-adjusted)));
  }

.spectrum-ActionButton-label {

  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

[dir="ltr"] .spectrum-ActionButton-hold {
  right: var(--spectrum-actionbutton-hold-icon-padding-right);
}

[dir="rtl"] .spectrum-ActionButton-hold {
  left: var(--spectrum-actionbutton-hold-icon-padding-right);
}

[dir="rtl"] .spectrum-ActionButton-hold { transform: matrix(-1, 0, 0, 1, 0, 0) ; }

.spectrum-ActionButton-hold {
  position: absolute;
  bottom: var(--spectrum-actionbutton-hold-icon-padding-bottom);
}

.spectrum-ActionButton--quiet {
  border-width: var(--spectrum-actionbutton-quiet-border-size);
  border-radius: var(--spectrum-actionbutton-quiet-border-radius);

  font-size: var(--spectrum-actionbutton-quiet-text-size);
  font-weight: var(--spectrum-actionbutton-quiet-text-font-weight);
}

.spectrum-ActionButton {
  --spectrum-actionbutton-m-quiet-border-size-key-focus: 1px;
}

.spectrum-ActionButton {
  background-color: var(--spectrum-actionbutton-m-background-color, var(--spectrum-global-color-gray-75));
  border-color: var(--spectrum-actionbutton-m-border-color, var(--spectrum-alias-border-color));
  color: var(--spectrum-actionbutton-m-text-color, var(--spectrum-alias-text-color));
}

.spectrum-ActionButton .spectrum-Icon {
    color: var(--spectrum-actionbutton-m-icon-color, var(--spectrum-alias-icon-color));
  }

.spectrum-ActionButton .spectrum-ActionButton-hold {
    color: var(--spectrum-actionbutton-m-hold-icon-color, var(--spectrum-alias-icon-color));
  }

.spectrum-ActionButton:hover {
    background-color: var(--spectrum-actionbutton-m-background-color-hover, var(--spectrum-global-color-gray-50));
    border-color: var(--spectrum-actionbutton-m-border-color-hover, var(--spectrum-alias-border-color-hover));
    color: var(--spectrum-actionbutton-m-text-color-hover, var(--spectrum-alias-text-color-hover));
  }

.spectrum-ActionButton:hover .spectrum-Icon {
      color: var(--spectrum-actionbutton-m-icon-color-hover, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-ActionButton:hover .spectrum-ActionButton-hold {
      color: var(--spectrum-actionbutton-m-hold-icon-color-hover, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-ActionButton.focus-ring {
    background-color: var(--spectrum-actionbutton-m-background-color-key-focus, var(--spectrum-global-color-gray-50));
    border-color: var(--spectrum-actionbutton-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    box-shadow: 0 0 0 var(--spectrum-actionbutton-m-quiet-border-size-key-focus, var(--spectrum-alias-border-size-thick)) var(--spectrum-actionbutton-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    color: var(--spectrum-actionbutton-m-text-color-key-focus, var(--spectrum-alias-text-color-hover));
  }

.spectrum-ActionButton.focus-ring:active {
      border-color: var(--spectrum-actionbutton-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-ActionButton.focus-ring .spectrum-Icon {
      color: var(--spectrum-actionbutton-m-icon-color-key-focus, var(--spectrum-alias-icon-color-focus));
    }

.spectrum-ActionButton.focus-ring .spectrum-ActionButton-hold {
      color: var(--spectrum-actionbutton-m-hold-icon-color-key-focus, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-ActionButton:active {
    background-color: var(--spectrum-actionbutton-m-background-color-down, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-actionbutton-m-border-color-down, var(--spectrum-alias-border-color-down));
    color: var(--spectrum-actionbutton-m-text-color-down, var(--spectrum-alias-text-color-down));
  }

.spectrum-ActionButton:active .spectrum-ActionButton-hold {
      color: var(--spectrum-actionbutton-m-hold-icon-color-down, var(--spectrum-alias-icon-color-down));
    }

.spectrum-ActionButton:disabled,
  .spectrum-ActionButton.is-disabled {
    background-color: var(--spectrum-actionbutton-m-background-color-disabled, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-actionbutton-m-border-color-disabled, var(--spectrum-alias-border-color-disabled));
    color: var(--spectrum-actionbutton-m-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }

.spectrum-ActionButton:disabled .spectrum-Icon, .spectrum-ActionButton.is-disabled .spectrum-Icon {
      color: var(--spectrum-actionbutton-m-icon-color-disabled, var(--spectrum-alias-icon-color-disabled));
    }

.spectrum-ActionButton:disabled .spectrum-ActionButton-hold, .spectrum-ActionButton.is-disabled .spectrum-ActionButton-hold {
      color: var(--spectrum-actionbutton-m-hold-icon-color-disabled, var(--spectrum-alias-icon-color-disabled));
    }

.spectrum-ActionButton.is-selected {
    background-color: var(--spectrum-actionbutton-m-background-color-selected, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-actionbutton-m-border-color-selected, var(--spectrum-alias-border-color));
    color: var(--spectrum-actionbutton-m-text-color-selected, var(--spectrum-alias-text-color));
  }

.spectrum-ActionButton.is-selected .spectrum-Icon {
      color: var(--spectrum-actionbutton-m-icon-color-selected, var(--spectrum-alias-icon-color));
    }

.spectrum-ActionButton.is-selected.focus-ring {
      background-color: var(--spectrum-actionbutton-m-background-color-selected-key-focus, var(--spectrum-global-color-gray-200));
      border-color: var(--spectrum-actionbutton-m-border-color-selected-key-focus, var(--spectrum-alias-border-color-focus));
      color: var(--spectrum-actionbutton-m-text-color-selected-key-focus, var(--spectrum-alias-text-color-hover));
    }

.spectrum-ActionButton.is-selected.focus-ring:active {
        border-color: var(--spectrum-actionbutton-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
      }

.spectrum-ActionButton.is-selected.focus-ring .spectrum-Icon {
        color: var(--spectrum-actionbutton-m-icon-color-selected-key-focus, var(--spectrum-alias-icon-color-hover));
      }

.spectrum-ActionButton.is-selected:hover {
      background-color: var(--spectrum-actionbutton-m-background-color-selected-hover, var(--spectrum-global-color-gray-200));
      border-color: var(--spectrum-actionbutton-m-border-color-selected-hover, var(--spectrum-alias-border-color-hover));
      color: var(--spectrum-actionbutton-m-text-color-selected-hover, var(--spectrum-alias-text-color-hover));
    }

.spectrum-ActionButton.is-selected:hover .spectrum-Icon {
        color: var(--spectrum-actionbutton-m-icon-color-selected-hover, var(--spectrum-alias-icon-color-hover));
      }

.spectrum-ActionButton.is-selected:active {
      background-color: var(--spectrum-actionbutton-m-background-color-selected-down, var(--spectrum-global-color-gray-200));
      border-color: var(--spectrum-actionbutton-m-border-color-selected-down, var(--spectrum-alias-border-color-down));
      color: var(--spectrum-actionbutton-m-text-color-selected-down, var(--spectrum-alias-text-color-down));
    }

.spectrum-ActionButton.is-selected:active .spectrum-Icon {
        color: var(--spectrum-actionbutton-m-icon-color-selected-down, var(--spectrum-alias-icon-color-down));
      }

.spectrum-ActionButton.is-selected:disabled,
    .spectrum-ActionButton.is-selected.is-disabled {
      background-color: var(--spectrum-actionbutton-m-background-color-selected-disabled, var(--spectrum-global-color-gray-200));
      border-color: var(--spectrum-actionbutton-m-border-color-selected-disabled, var(--spectrum-alias-border-color-disabled));
      color: var(--spectrum-actionbutton-m-text-color-selected-disabled, var(--spectrum-alias-text-color-disabled));
    }

.spectrum-ActionButton.is-selected:disabled .spectrum-Icon, .spectrum-ActionButton.is-selected.is-disabled .spectrum-Icon {
        color: var(--spectrum-actionbutton-m-icon-color-selected-disabled, var(--spectrum-alias-icon-color-disabled));
      }

.spectrum-ActionButton--emphasized {
  background-color: var(--spectrum-actionbutton-m-emphasized-background-color, var(--spectrum-global-color-gray-75));
  border-color: var(--spectrum-actionbutton-m-emphasized-border-color, var(--spectrum-alias-border-color));
  color: var(--spectrum-actionbutton-m-emphasized-text-color, var(--spectrum-alias-text-color));
}

.spectrum-ActionButton--emphasized .spectrum-Icon {
    color: var(--spectrum-actionbutton-m-emphasized-icon-color, var(--spectrum-alias-icon-color));
  }

.spectrum-ActionButton--emphasized .spectrum-ActionButton-hold {
    color: var(--spectrum-actionbutton-m-emphasized-hold-icon-color, var(--spectrum-alias-icon-color));
  }

.spectrum-ActionButton--emphasized.is-selected .spectrum-ActionButton-hold {
      color: var(--spectrum-actionbutton-m-emphasized-hold-icon-color-selected, var(--spectrum-global-color-static-white));
    }

.spectrum-ActionButton--emphasized.is-selected:hover .spectrum-ActionButton-hold {
        color: var(--spectrum-actionbutton-m-emphasized-text-color-selected-hover, var(--spectrum-global-color-static-white));
      }

.spectrum-ActionButton--emphasized:hover {
    background-color: var(--spectrum-actionbutton-m-emphasized-background-color-hover, var(--spectrum-global-color-gray-50));
    border-color: var(--spectrum-actionbutton-m-emphasized-border-color-hover, var(--spectrum-alias-border-color-hover));
    box-shadow: none;
    color: var(--spectrum-actionbutton-m-emphasized-text-color-hover, var(--spectrum-alias-text-color-hover));
  }

.spectrum-ActionButton--emphasized:hover .spectrum-Icon {
      color: var(--spectrum-actionbutton-m-emphasized-icon-color-hover, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-ActionButton--emphasized:hover .spectrum-ActionButton-hold {
      color: var(--spectrum-actionbutton-m-emphasized-hold-icon-color-hover, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-ActionButton--emphasized.focus-ring {
    background-color: var(--spectrum-actionbutton-m-emphasized-background-color-key-focus, var(--spectrum-global-color-gray-50));
    border-color: var(--spectrum-actionbutton-m-emphasized-border-color-key-focus, var(--spectrum-alias-border-color-hover));
    box-shadow: 0 0 0 var(--spectrum-actionbutton-m-quiet-border-size-key-focus, var(--spectrum-alias-border-size-thick)) var(--spectrum-actionbutton-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    color: var(--spectrum-actionbutton-m-emphasized-text-color-key-focus, var(--spectrum-alias-text-color-hover));
  }

.spectrum-ActionButton--emphasized.focus-ring .spectrum-Icon {
      color: var(--spectrum-actionbutton-m-emphasized-icon-color-key-focus, var(--spectrum-alias-icon-color-focus));
    }

.spectrum-ActionButton--emphasized.focus-ring .spectrum-ActionButton-hold {
      color: var(--spectrum-actionbutton-m-emphasized-hold-icon-color-key-focus, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-ActionButton--emphasized.is-active {
    background-color: var(--spectrum-actionbutton-m-emphasized-background-color-down, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-actionbutton-m-emphasized-border-color-down, var(--spectrum-alias-border-color-down));
    box-shadow: none;
    color: var(--spectrum-actionbutton-m-emphasized-text-color-down, var(--spectrum-alias-text-color-down));
  }

.spectrum-ActionButton--emphasized.is-active .spectrum-ActionButton-hold {
      color: var(--spectrum-actionbutton-m-emphasized-hold-icon-color-down, var(--spectrum-alias-icon-color-down));
    }

.spectrum-ActionButton--emphasized:disabled,
  .spectrum-ActionButton--emphasized.is-disabled {
    background-color: var(--spectrum-actionbutton-m-emphasized-background-color-disabled, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-actionbutton-m-emphasized-border-color-disabled, var(--spectrum-alias-border-color-disabled));
    color: var(--spectrum-actionbutton-m-emphasized-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }

.spectrum-ActionButton--emphasized:disabled .spectrum-Icon, .spectrum-ActionButton--emphasized.is-disabled .spectrum-Icon {
      color: var(--spectrum-actionbutton-m-emphasized-icon-color-disabled, var(--spectrum-alias-icon-color-disabled));
    }

.spectrum-ActionButton--emphasized:disabled .spectrum-ActionButton-hold, .spectrum-ActionButton--emphasized.is-disabled .spectrum-ActionButton-hold {
      color: var(--spectrum-actionbutton-m-emphasized-hold-icon-color-disabled, var(--spectrum-alias-icon-color-disabled));
    }

.spectrum-ActionButton--emphasized.spectrum-ActionButton--quiet.is-selected,
  .spectrum-ActionButton--emphasized.is-selected {
    background-color: var(--spectrum-actionbutton-m-emphasized-background-color-selected, var(--spectrum-semantic-cta-color-background-default));
    border-color: var(--spectrum-actionbutton-m-emphasized-border-color-selected, var(--spectrum-semantic-cta-color-background-default));
    color: var(--spectrum-actionbutton-m-emphasized-text-color-selected, var(--spectrum-global-color-static-white));
  }

.spectrum-ActionButton--emphasized.spectrum-ActionButton--quiet.is-selected .spectrum-Icon, .spectrum-ActionButton--emphasized.is-selected .spectrum-Icon {
      color: var(--spectrum-actionbutton-m-emphasized-icon-color-selected, var(--spectrum-global-color-static-white));
    }

.spectrum-ActionButton--emphasized.spectrum-ActionButton--quiet.is-selected.focus-ring, .spectrum-ActionButton--emphasized.is-selected.focus-ring {
      background-color: var(--spectrum-actionbutton-m-emphasized-background-color-selected-key-focus, var(--spectrum-semantic-cta-color-background-key-focus));
      border-color: var(--spectrum-actionbutton-m-emphasized-border-color-selected-key-focus, var(--spectrum-semantic-cta-color-background-key-focus));
      color: var(--spectrum-actionbutton-m-emphasized-text-color-selected-key-focus, var(--spectrum-global-color-static-white));
    }

.spectrum-ActionButton--emphasized.spectrum-ActionButton--quiet.is-selected.focus-ring .spectrum-Icon, .spectrum-ActionButton--emphasized.is-selected.focus-ring .spectrum-Icon {
        color: var(--spectrum-actionbutton-m-emphasized-icon-color-selected-key-focus, var(--spectrum-global-color-static-white));
      }

.spectrum-ActionButton--emphasized.spectrum-ActionButton--quiet.is-selected:hover, .spectrum-ActionButton--emphasized.is-selected:hover {
      background-color: var(--spectrum-actionbutton-m-emphasized-background-color-selected-hover, var(--spectrum-semantic-cta-color-background-hover));
      border-color: var(--spectrum-actionbutton-m-emphasized-border-color-selected-hover, var(--spectrum-semantic-cta-color-background-hover));
      color: var(--spectrum-actionbutton-m-emphasized-text-color-selected-hover, var(--spectrum-global-color-static-white));
    }

.spectrum-ActionButton--emphasized.spectrum-ActionButton--quiet.is-selected:hover .spectrum-Icon, .spectrum-ActionButton--emphasized.is-selected:hover .spectrum-Icon {
        color: var(--spectrum-actionbutton-m-emphasized-icon-color-selected-hover, var(--spectrum-global-color-static-white));
      }

.spectrum-ActionButton--emphasized.spectrum-ActionButton--quiet.is-selected.is-active, .spectrum-ActionButton--emphasized.is-selected.is-active {
      background-color: var(--spectrum-actionbutton-m-emphasized-background-color-selected-down, var(--spectrum-semantic-cta-color-background-down));
      border-color: var(--spectrum-actionbutton-m-emphasized-border-color-selected-down, var(--spectrum-semantic-cta-color-background-down));
      color: var(--spectrum-actionbutton-m-emphasized-text-color-selected-down, var(--spectrum-global-color-static-white));
    }

.spectrum-ActionButton--emphasized.spectrum-ActionButton--quiet.is-selected.is-active .spectrum-Icon, .spectrum-ActionButton--emphasized.is-selected.is-active .spectrum-Icon {
        color: var(--spectrum-actionbutton-m-emphasized-icon-color-selected-down, var(--spectrum-global-color-static-white));
      }

.spectrum-ActionButton--emphasized.spectrum-ActionButton--quiet.is-selected:disabled,
    .spectrum-ActionButton--emphasized.spectrum-ActionButton--quiet.is-selected.is-disabled,
    .spectrum-ActionButton--emphasized.is-selected:disabled,
    .spectrum-ActionButton--emphasized.is-selected.is-disabled {
      background-color: var(--spectrum-actionbutton-m-emphasized-background-color-selected-disabled, var(--spectrum-global-color-gray-200));
      border-color: var(--spectrum-actionbutton-m-emphasized-border-color-selected-disabled, var(--spectrum-alias-border-color-disabled));
      color: var(--spectrum-actionbutton-m-emphasized-text-color-selected-disabled, var(--spectrum-alias-text-color-disabled));
    }

.spectrum-ActionButton--emphasized.spectrum-ActionButton--quiet.is-selected:disabled .spectrum-Icon, .spectrum-ActionButton--emphasized.spectrum-ActionButton--quiet.is-selected.is-disabled .spectrum-Icon, .spectrum-ActionButton--emphasized.is-selected:disabled .spectrum-Icon, .spectrum-ActionButton--emphasized.is-selected.is-disabled .spectrum-Icon {
        color: var(--spectrum-actionbutton-m-emphasized-icon-color-selected-disabled, var(--spectrum-alias-icon-color-disabled));
      }

.spectrum-ActionButton--quiet {
  background-color: var(--spectrum-actionbutton-m-quiet-background-color, var(--spectrum-alias-background-color-transparent));
  border-color: var(--spectrum-actionbutton-m-quiet-border-color, var(--spectrum-alias-border-color-transparent));
  color: var(--spectrum-actionbutton-m-quiet-text-color, var(--spectrum-alias-text-color));
}

.spectrum-ActionButton--quiet:hover {
    background-color: var(--spectrum-actionbutton-m-quiet-background-color-hover, var(--spectrum-alias-background-color-transparent));
    border-color: var(--spectrum-actionbutton-m-quiet-border-color-hover, var(--spectrum-alias-border-color-transparent));
    color: var(--spectrum-actionbutton-m-quiet-text-color-hover, var(--spectrum-alias-text-color-hover));
  }

.spectrum-ActionButton--quiet.focus-ring {
    background-color: var(--spectrum-actionbutton-m-quiet-background-color-key-focus, var(--spectrum-alias-background-color-transparent));
    box-shadow: 0 0 0 var(--spectrum-actionbutton-m-quiet-border-size-key-focus, var(--spectrum-alias-border-size-thick)) var(--spectrum-actionbutton-m-quiet-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    border-color: var(--spectrum-actionbutton-m-quiet-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    color: var(--spectrum-actionbutton-m-quiet-text-color-key-focus, var(--spectrum-alias-text-color-hover));
  }

.spectrum-ActionButton--quiet:active {
    background-color: var(--spectrum-actionbutton-m-quiet-background-color-down, var(--spectrum-global-color-gray-300));
    border-color: var(--spectrum-actionbutton-m-quiet-border-color-down, var(--spectrum-alias-border-color-transparent));
    color: var(--spectrum-actionbutton-m-quiet-text-color-down, var(--spectrum-alias-text-color-down));
  }

.spectrum-ActionButton--quiet:disabled,
  .spectrum-ActionButton--quiet.is-disabled {
    background-color: var(--spectrum-actionbutton-m-quiet-background-color-disabled, var(--spectrum-alias-background-color-transparent));
    border-color: var(--spectrum-actionbutton-m-quiet-border-color-disabled, var(--spectrum-alias-border-color-transparent));
    color: var(--spectrum-actionbutton-m-quiet-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }

.spectrum-ActionButton--quiet.is-selected {
    background-color: var(--spectrum-actionbutton-m-quiet-background-color-selected, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-actionbutton-m-quiet-border-color-selected, var(--spectrum-alias-border-color-transparent));
    color: var(--spectrum-actionbutton-m-quiet-text-color-selected, var(--spectrum-alias-text-color));
  }

.spectrum-ActionButton--quiet.is-selected.focus-ring {
      background-color: var(--spectrum-actionbutton-m-quiet-background-color-selected-key-focus, var(--spectrum-global-color-gray-200));
      border-color: var(--spectrum-actionbutton-m-quiet-border-color-selected-key-focus, var(--spectrum-alias-border-color-transparent));
      color: var(--spectrum-actionbutton-m-quiet-text-color-selected-key-focus, var(--spectrum-alias-text-color-hover));
    }

.spectrum-ActionButton--quiet.is-selected:hover {
      background-color: var(--spectrum-actionbutton-m-quiet-background-color-selected-hover, var(--spectrum-global-color-gray-200));
      border-color: var(--spectrum-actionbutton-m-quiet-border-color-selected-hover, var(--spectrum-alias-border-color-transparent));
      color: var(--spectrum-actionbutton-m-quiet-text-color-selected-hover, var(--spectrum-alias-text-color-hover));
    }

.spectrum-ActionButton--quiet.is-selected:active {
      background-color: var(--spectrum-actionbutton-m-quiet-background-color-selected-down, var(--spectrum-global-color-gray-200));
      border-color: var(--spectrum-actionbutton-m-quiet-border-color-selected-down, var(--spectrum-alias-border-color-transparent));
      color: var(--spectrum-actionbutton-m-quiet-text-color-selected-down, var(--spectrum-alias-text-color-down));
    }

.spectrum-ActionButton--quiet.is-selected:disabled,
    .spectrum-ActionButton--quiet.is-selected.is-disabled {
      background-color: var(--spectrum-actionbutton-m-quiet-background-color-selected-disabled, var(--spectrum-global-color-gray-200));
      border-color: var(--spectrum-actionbutton-m-quiet-border-color-selected-disabled, var(--spectrum-alias-border-color-transparent));
      color: var(--spectrum-actionbutton-m-quiet-text-color-selected-disabled, var(--spectrum-alias-text-color-disabled));
    }
.tooltip.svelte-12iylyn{pointer-events:none;background:var(--spectrum-global-color-gray-500)}.spectrum-Tooltip-tip.svelte-12iylyn{border-top-color:var(--spectrum-global-color-gray-500)}.spectrum-Tooltip.svelte-12iylyn{max-width:280px}.spectrum-Tooltip-label.svelte-12iylyn{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}button.svelte-1v8ll3t.svelte-1v8ll3t{transition:filter 130ms ease-out,
      background 130ms ease-out,
      border 130ms ease-out,
      color 130ms ease-out;display:flex;flex-direction:row;align-items:center;gap:var(--spacing-s);border-radius:8px;border:1px solid var(--spectrum-global-color-gray-300)}.fullWidth.svelte-1v8ll3t.svelte-1v8ll3t{width:100%;min-width:0;overflow:hidden}.fullWidth.svelte-1v8ll3t .spectrum-ActionButton-label.svelte-1v8ll3t{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;text-align:left}.active.svelte-1v8ll3t.svelte-1v8ll3t,.active.svelte-1v8ll3t i{background-color:rgba(75, 117, 255, 0.1);border:0.5px solid rgba(75, 117, 255, 0.2);color:var(--spectrum-global-color-gray-900)}.active.svelte-1v8ll3t.svelte-1v8ll3t:hover:not(:disabled){background-color:rgba(75, 117, 255, 0.2);border:0.5px solid rgba(75, 117, 255, 0.3)}[dir="ltr"] .spectrum-ActionButton i{margin-left:0;transition:color ease-out 130ms}.is-selected.svelte-1v8ll3t.svelte-1v8ll3t:not(.spectrum-ActionButton--quiet){border-color:var(--spectrum-global-color-gray-300)}.spectrum-ActionButton--quiet.svelte-1v8ll3t.svelte-1v8ll3t{padding:0 8px;border:1px dashed transparent}.spectrum-ActionButton--quiet.svelte-1v8ll3t.svelte-1v8ll3t:hover:not(:disabled){background-color:var(--spectrum-global-color-gray-200);border:1px solid var(--spectrum-global-color-gray-300)}.spectrum-ActionButton--quiet.is-selected.svelte-1v8ll3t.svelte-1v8ll3t{color:var(--spectrum-global-color-gray-900);border:1px solid var(--spectrum-global-color-gray-300)}.noPadding.svelte-1v8ll3t.svelte-1v8ll3t{padding:0;min-width:0}.noPadding.svelte-1v8ll3t.svelte-1v8ll3t:hover:not(:disabled){padding:0;min-width:0;background-color:transparent;border:1px solid transparent}.is-selected.svelte-1v8ll3t i{color:var(--spectrum-global-color-gray-900)}.is-selected.disabled.svelte-1v8ll3t i{color:var(--spectrum-global-color-gray-500)}.spectrum-ActionButton-label.svelte-1v8ll3t.svelte-1v8ll3t{font-weight:600}.tooltip.svelte-1v8ll3t.svelte-1v8ll3t{position:absolute;pointer-events:none;left:50%;top:calc(100% + 4px);width:100vw;max-width:150px;transform:translateX(-50%);text-align:center;z-index:1}.accent.is-selected.svelte-1v8ll3t.svelte-1v8ll3t,.accent.svelte-1v8ll3t.svelte-1v8ll3t:active{border:1px solid var(--accent-border-color);background:var(--accent-bg-color)}.accent.svelte-1v8ll3t.svelte-1v8ll3t:hover:not(:disabled){filter:brightness(1.2)}.date-time-popover.svelte-1ds30rz{padding:8px;overflow:hidden}.footer.svelte-1ds30rz{display:flex;justify-content:space-between;align-items:center;gap:60px}.footer.spaced.svelte-1ds30rz{padding-top:14px}.actions.svelte-1ds30rz{padding:4px 0;flex:1 1 auto;display:flex;justify-content:flex-end;gap:6px}.date-range.svelte-1i3abvq{display:flex;flex-direction:row;border:1px solid var(--spectrum-alias-border-color);border-radius:4px}.date-range.svelte-1i3abvq .spectrum-InputGroup,.date-range.svelte-1i3abvq .spectrum-Textfield,.date-range.svelte-1i3abvq input{min-width:0 !important;width:150px !important}.date-range.svelte-1i3abvq input{border:none;text-align:center}.date-range.svelte-1i3abvq button{display:none}.date-range.svelte-1i3abvq > :first-child input,.date-range.svelte-1i3abvq > :first-child{border-top-right-radius:0;border-bottom-right-radius:0}.date-range.svelte-1i3abvq > :last-child input,.date-range.svelte-1i3abvq > :last-child{border-top-left-radius:0;border-bottom-left-radius:0}.arrow.svelte-1i3abvq{position:absolute;top:50%;left:50%;transform:translateX(-50%) translateY(-50%);z-index:1}.spectrum-Dropzone {
  text-align: center;
  border-width: var(--spectrum-dropzone-border-width, var(--spectrum-alias-border-size-thick));
  border-radius: var(--spectrum-dropzone-border-radius, var(--spectrum-alias-border-radius-regular));
  padding: var(--spectrum-dropzone-padding, var(--spectrum-global-dimension-size-900));
  border-style: dashed;
}

.spectrum-Dropzone.is-dragged {
    border-style: solid;
  }

.spectrum-Dropzone:focus {
    outline: 0;
    border-style: dashed;
  }

.spectrum-Dropzone:focus.focus-ring {
      border-style: solid;
    }

.spectrum-Dropzone {
  border-color: var(--spectrum-dropzone-border-color, var(--spectrum-global-color-gray-300));
}

.spectrum-Dropzone.is-dragged {
    border-color: var(--spectrum-dropzone-border-color-selected-hover, var(--spectrum-global-color-blue-400));
    background-color: var(--spectrum-dropzone-background-color-selected-hover, var(--spectrum-alias-highlight-selected));
  }

.spectrum-Dropzone.is-dragged .spectrum-IllustratedMessage-illustration {
      color: var(--spectrum-global-color-blue-400);
    }

.spectrum-Dropzone:focus {
    border-color: var(--spectrum-dropzone-border-color, var(--spectrum-global-color-gray-300));
  }

.spectrum-Dropzone:focus .spectrum-IllustratedMessage-illustration {
      color: var(--spectrum-global-color-static-gray-500, rgb(188, 188, 188));
    }

.spectrum-Dropzone:focus.focus-ring {
      border-color: var(--spectrum-dropzone-border-color-selected-hover, var(--spectrum-global-color-blue-400));
    }

.spectrum-Dropzone:focus.is-dragged.focus-ring .spectrum-IllustratedMessage-illustration {
        color: var(--spectrum-global-color-blue-400);
      }
.spectrum-IllustratedMessage {
  --spectrum-illustrated-message-description-max-width: 500px;
  --spectrum-illustrated-message-heading-max-width: 500px;
  --spectrum-illustrated-message-illustration-margin-bottom: 24px;
  --spectrum-illustrated-message-heading-margin: 0;
  --spectrum-illustrated-message-description-margin: 4px 0 0 0;
}

.spectrum-IllustratedMessage {
  height: 100%;

  display: -ms-flexbox;

  display: flex;
  -ms-flex-direction: column;
      flex-direction: column;
  -ms-flex-align: center;
      align-items: center;
  -ms-flex-pack: center;
      justify-content: center;

  text-align: center;
}

.spectrum-IllustratedMessage-illustration {
  margin-bottom: var(--spectrum-illustrated-message-illustration-margin-bottom);
}

.spectrum-IllustratedMessage-heading {
  max-width: var(--spectrum-illustrated-message-heading-max-width);
  margin: var(--spectrum-illustrated-message-heading-margin);
}

.spectrum-IllustratedMessage-description {
  max-width: var(--spectrum-illustrated-message-description-max-width);
  margin: var(--spectrum-illustrated-message-description-margin);

  font-style: italic;
}

.spectrum-IllustratedMessage--cta .spectrum-IllustratedMessage-description {
    font-style: normal;
  }

.spectrum-IllustratedMessage-illustration {
  color: var(--spectrum-global-color-gray-500);
  fill: currentColor;
  stroke: currentColor;
}
.spectrum {
  font-family: var(--spectrum-alias-body-text-font-family, var(--spectrum-global-font-family-base));
  font-size: var(--spectrum-alias-font-size-default, var(--spectrum-global-dimension-font-size-100));
}

.spectrum:lang(ar) {
    font-family: var(--spectrum-alias-font-family-ar, myriad-arabic, adobe-clean, 'Source Sans Pro', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Trebuchet MS', 'Lucida Grande', sans-serif);
  }

.spectrum:lang(he) {
    font-family: var(--spectrum-alias-font-family-he, myriad-hebrew, adobe-clean, 'Source Sans Pro', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Trebuchet MS', 'Lucida Grande', sans-serif);
  }

.spectrum:lang(zh-Hans) {
    font-family: var(--spectrum-alias-font-family-zhhans, adobe-clean-han-simplified-c, source-han-simplified-c, 'SimSun', 'Heiti SC Light', 'sans-serif');
  }

.spectrum:lang(zh-Hant) {
    font-family: var(--spectrum-alias-font-family-zh, adobe-clean-han-traditional, source-han-traditional, 'MingLiu', 'Heiti TC Light','sans-serif');
  }

.spectrum:lang(zh) {
    font-family: var(--spectrum-alias-font-family-zh, adobe-clean-han-traditional, source-han-traditional, 'MingLiu', 'Heiti TC Light','sans-serif');
  }

.spectrum:lang(ko) {
    font-family: var(--spectrum-alias-font-family-ko, adobe-clean-han-korean, source-han-korean, 'Malgun Gothic', 'Apple Gothic', 'sans-serif');
  }

.spectrum:lang(ja) {
    font-family: var(--spectrum-alias-font-family-ja, adobe-clean-han-japanese, source-han-japanese, 'Yu Gothic', '\\30E1 \\30A4 \\30EA \\30AA', '\\30D2 \\30E9 \\30AE \\30CE \\89D2 \\30B4  Pro W3', 'Hiragino Kaku Gothic Pro W3', 'Osaka', '\\FF2D \\FF33 \\FF30 \\30B4 \\30B7 \\30C3 \\30AF', 'MS PGothic', 'sans-serif');
  }

.spectrum-Heading--sizeXXXL {
  

    font-size: var(--spectrum-heading-xxxl-text-size, var(--spectrum-alias-heading-xxxl-text-size));
  font-weight: var(--spectrum-heading-xxxl-text-font-weight, var(--spectrum-alias-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-xxxl-text-line-height, var(--spectrum-alias-heading-text-line-height));
  font-style: var(--spectrum-heading-xxxl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-xxxl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-heading-xxxl-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Heading--sizeXXL {
  

    font-size: var(--spectrum-heading-xxl-text-size, var(--spectrum-alias-heading-xxl-text-size));
  font-weight: var(--spectrum-heading-xxl-text-font-weight, var(--spectrum-alias-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-xxl-text-line-height, var(--spectrum-alias-heading-text-line-height));
  font-style: var(--spectrum-heading-xxl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-xxl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-heading-xxl-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Heading--sizeXL {
  

    font-size: var(--spectrum-heading-xl-text-size, var(--spectrum-alias-heading-xl-text-size));
  font-weight: var(--spectrum-heading-xl-text-font-weight, var(--spectrum-alias-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-xl-text-line-height, var(--spectrum-alias-heading-text-line-height));
  font-style: var(--spectrum-heading-xl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-xl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-heading-xl-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Heading--sizeL {
  

    font-size: var(--spectrum-heading-l-text-size, var(--spectrum-alias-heading-l-text-size));
  font-weight: var(--spectrum-heading-l-text-font-weight, var(--spectrum-alias-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-l-text-line-height, var(--spectrum-alias-heading-text-line-height));
  font-style: var(--spectrum-heading-l-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-l-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-heading-l-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Heading--sizeM {
  

    font-size: var(--spectrum-heading-m-text-size, var(--spectrum-alias-heading-m-text-size));
  font-weight: var(--spectrum-heading-m-text-font-weight, var(--spectrum-alias-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-m-text-line-height, var(--spectrum-alias-heading-text-line-height));
  font-style: var(--spectrum-heading-m-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-m-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-heading-m-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Heading--sizeS {
  

    font-size: var(--spectrum-heading-s-text-size, var(--spectrum-alias-heading-s-text-size));
  font-weight: var(--spectrum-heading-s-text-font-weight, var(--spectrum-alias-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-s-text-line-height, var(--spectrum-alias-heading-text-line-height));
  font-style: var(--spectrum-heading-s-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-s-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-heading-s-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Heading--sizeXS {
  

    font-size: var(--spectrum-heading-xs-text-size, var(--spectrum-alias-heading-xs-text-size));
  font-weight: var(--spectrum-heading-xs-text-font-weight, var(--spectrum-alias-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-xs-text-line-height, var(--spectrum-alias-heading-text-line-height));
  font-style: var(--spectrum-heading-xs-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-xs-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-heading-xs-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Heading--sizeXXS {
  

    font-size: var(--spectrum-heading-xxs-text-size, var(--spectrum-alias-heading-xxs-text-size));
  font-weight: var(--spectrum-heading-xxs-text-font-weight, var(--spectrum-alias-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-xxs-text-line-height, var(--spectrum-alias-heading-text-line-height));
  font-style: var(--spectrum-heading-xxs-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-xxs-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-heading-xxs-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Heading {
  font-family: var(--spectrum-heading-m-text-font-family, var(--spectrum-alias-body-text-font-family));
  font-weight: var(--spectrum-heading-m-text-font-weight, var(--spectrum-alias-heading-text-font-weight-regular));
}

.spectrum-Heading em,
  .spectrum-Heading .spectrum-Heading-emphasis {
    font-style: var(--spectrum-heading-m-emphasis-text-font-style, var(--spectrum-global-font-style-italic));
  }

.spectrum-Heading strong,
  .spectrum-Heading .spectrum-Heading-strong {
    font-weight: var(--spectrum-heading-m-strong-text-font-weight, var(--spectrum-global-font-weight-black));
  }

.spectrum-Heading--serif {
  font-family: var(--spectrum-body-serif-m-text-font-family, var(--spectrum-alias-serif-text-font-family));
}

.spectrum-Heading--heavy {
  font-weight: var(--spectrum-heading-heavy-m-text-font-weight, var(--spectrum-global-font-weight-black));
}

.spectrum-Heading--heavy em,
  .spectrum-Heading--heavy .spectrum-Heading-emphasis {
    font-style: var(--spectrum-heading-heavy-m-emphasis-text-font-style, var(--spectrum-global-font-style-italic));
  }

.spectrum-Heading--heavy strong,
  .spectrum-Heading--heavy .spectrum-Heading-strong {
    font-weight: var(--spectrum-heading-heavy-m-strong-text-font-weight, var(--spectrum-global-font-weight-black));
  }

.spectrum-Heading--light {
  font-weight: var(--spectrum-heading-light-m-emphasis-text-font-weight, var(--spectrum-global-font-weight-light));
}

.spectrum-Heading--light em,
  .spectrum-Heading--light .spectrum-Heading-emphasis {
    font-style: var(--spectrum-heading-light-m-emphasis-text-font-style, var(--spectrum-global-font-style-italic));
  }

.spectrum-Heading--light strong,
  .spectrum-Heading--light .spectrum-Heading-strong {
    font-weight: var(--spectrum-heading-light-m-strong-text-font-weight, var(--spectrum-global-font-weight-bold));
  }

.spectrum-Body--sizeXXXL {
  

    font-size: var(--spectrum-body-xxxl-text-size, var(--spectrum-global-dimension-font-size-600));
  font-weight: var(--spectrum-body-xxxl-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  line-height: var(--spectrum-body-xxxl-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-body-xxxl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-xxxl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-body-xxxl-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Body--sizeXXL {
  

    font-size: var(--spectrum-body-xxl-text-size, var(--spectrum-global-dimension-font-size-500));
  font-weight: var(--spectrum-body-xxl-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  line-height: var(--spectrum-body-xxl-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-body-xxl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-xxl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-body-xxl-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Body--sizeXL {
  

    font-size: var(--spectrum-body-xl-text-size, var(--spectrum-global-dimension-font-size-400));
  font-weight: var(--spectrum-body-xl-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  line-height: var(--spectrum-body-xl-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-body-xl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-xl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-body-xl-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Body--sizeL {
  

    font-size: var(--spectrum-body-l-text-size, var(--spectrum-global-dimension-font-size-300));
  font-weight: var(--spectrum-body-l-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  line-height: var(--spectrum-body-l-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-body-l-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-l-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-body-l-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Body--sizeM {
  

    font-size: var(--spectrum-body-m-text-size, var(--spectrum-global-dimension-font-size-200));
  font-weight: var(--spectrum-body-m-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  line-height: var(--spectrum-body-m-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-body-m-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-m-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-body-m-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Body--sizeS {
  

    font-size: var(--spectrum-body-s-text-size, var(--spectrum-alias-font-size-default));
  font-weight: var(--spectrum-body-s-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  line-height: var(--spectrum-body-s-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-body-s-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-s-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-body-s-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Body--sizeXS {
  

    font-size: var(--spectrum-body-xs-text-size, var(--spectrum-global-dimension-font-size-75));
  font-weight: var(--spectrum-body-xs-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  line-height: var(--spectrum-body-xs-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-body-xs-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-xs-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  text-transform: var(--spectrum-body-xs-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum-Body {
  font-family: var(--spectrum-body-m-text-font-family, var(--spectrum-alias-body-text-font-family));
}

.spectrum-Body strong,
  .spectrum-Body .spectrum-Body-strong {
    font-weight: var(--spectrum-body-m-strong-text-font-weight, var(--spectrum-global-font-weight-bold));
  }

.spectrum-Body em,
  .spectrum-Body .spectrum-Body-emphasis {
    font-style: var(--spectrum-body-m-emphasis-text-font-style, var(--spectrum-global-font-style-italic));
  }

.spectrum-Body--serif {
  font-family: var(--spectrum-body-serif-m-text-font-family, var(--spectrum-alias-serif-text-font-family));
}

.spectrum-Detail {
  font-family: var(--spectrum-heading-m-text-font-family, var(--spectrum-alias-body-text-font-family));
}

.spectrum-Detail strong,
  .spectrum-Detail .spectrum-Detail-strong {
    font-weight: var(--spectrum-detail-m-strong-text-font-weight, var(--spectrum-global-font-weight-black));
  }

.spectrum-Detail em,
  .spectrum-Detail .spectrum-Detail-emphasis {
    font-style: var(--spectrum-detail-m-emphasis-text-font-style, var(--spectrum-global-font-style-italic));
  }

.spectrum-Detail--light {
  font-style: var(--spectrum-detail-light-m-text-font-style, var(--spectrum-global-font-style-regular));
  font-weight: var(--spectrum-detail-light-m-text-font-weight, var(--spectrum-alias-detail-text-font-weight-light));
}

.spectrum-Detail--serif {
  font-family: var(--spectrum-body-serif-m-text-font-family, var(--spectrum-alias-serif-text-font-family));
}

.spectrum-Detail--sizeXL {
  

    font-size: var(--spectrum-detail-xl-text-size, var(--spectrum-global-dimension-font-size-200));
  font-weight: var(--spectrum-detail-xl-text-font-weight, var(--spectrum-alias-detail-text-font-weight));
  line-height: var(--spectrum-detail-xl-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-detail-xl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-xl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
  text-transform: var(--spectrum-detail-xl-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;
  
  }

.spectrum-Detail--sizeXL em {
        font-size: var(--spectrum-detail-xl-emphasis-text-size, var(--spectrum-global-dimension-font-size-200));
  font-weight: var(--spectrum-detail-xl-emphasis-text-font-weight, var(--spectrum-alias-detail-text-font-weight));
  line-height: var(--spectrum-detail-xl-emphasis-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-detail-xl-emphasis-text-font-style, var(--spectrum-global-font-style-italic));
  letter-spacing: var(--spectrum-detail-xl-emphasis-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
  text-transform: var(--spectrum-detail-xl-emphasis-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum-Detail--sizeXL strong {
        font-size: var(--spectrum-detail-xl-strong-text-size, var(--spectrum-global-dimension-font-size-200));
  font-weight: var(--spectrum-detail-xl-strong-text-font-weight, var(--spectrum-global-font-weight-black));
  line-height: var(--spectrum-detail-xl-strong-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-detail-xl-strong-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-xl-strong-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
  text-transform: var(--spectrum-detail-xl-strong-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum-Detail--sizeL {
  

    font-size: var(--spectrum-detail-l-text-size, var(--spectrum-global-dimension-font-size-100));
  font-weight: var(--spectrum-detail-l-text-font-weight, var(--spectrum-alias-detail-text-font-weight));
  line-height: var(--spectrum-detail-l-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-detail-l-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-l-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
  text-transform: var(--spectrum-detail-l-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;
  
  }

.spectrum-Detail--sizeL em {
        font-size: var(--spectrum-detail-l-emphasis-text-size, var(--spectrum-global-dimension-font-size-100));
  font-weight: var(--spectrum-detail-l-emphasis-text-font-weight, var(--spectrum-alias-detail-text-font-weight));
  line-height: var(--spectrum-detail-l-emphasis-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-detail-l-emphasis-text-font-style, var(--spectrum-global-font-style-italic));
  letter-spacing: var(--spectrum-detail-l-emphasis-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
  text-transform: var(--spectrum-detail-l-emphasis-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum-Detail--sizeL strong {
        font-size: var(--spectrum-detail-l-strong-text-size, var(--spectrum-global-dimension-font-size-100));
  font-weight: var(--spectrum-detail-l-strong-text-font-weight, var(--spectrum-global-font-weight-black));
  line-height: var(--spectrum-detail-l-strong-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-detail-l-strong-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-l-strong-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
  text-transform: var(--spectrum-detail-l-strong-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum-Detail--sizeM {
  

    font-size: var(--spectrum-detail-m-text-size, var(--spectrum-global-dimension-font-size-75));
  font-weight: var(--spectrum-detail-m-text-font-weight, var(--spectrum-alias-detail-text-font-weight));
  line-height: var(--spectrum-detail-m-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-detail-m-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-m-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
  text-transform: var(--spectrum-detail-m-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;
  
  }

.spectrum-Detail--sizeM em {
        font-size: var(--spectrum-detail-m-emphasis-text-size, var(--spectrum-global-dimension-font-size-75));
  font-weight: var(--spectrum-detail-m-emphasis-text-font-weight, var(--spectrum-alias-detail-text-font-weight));
  line-height: var(--spectrum-detail-m-emphasis-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-detail-m-emphasis-text-font-style, var(--spectrum-global-font-style-italic));
  letter-spacing: var(--spectrum-detail-m-emphasis-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
  text-transform: var(--spectrum-detail-m-emphasis-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum-Detail--sizeM strong {
        font-size: var(--spectrum-detail-m-strong-text-size, var(--spectrum-global-dimension-font-size-75));
  font-weight: var(--spectrum-detail-m-strong-text-font-weight, var(--spectrum-global-font-weight-black));
  line-height: var(--spectrum-detail-m-strong-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-detail-m-strong-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-m-strong-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
  text-transform: var(--spectrum-detail-m-strong-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum-Detail--sizeS {
  

    font-size: var(--spectrum-detail-s-text-size, var(--spectrum-global-dimension-font-size-50));
  font-weight: var(--spectrum-detail-s-text-font-weight, var(--spectrum-alias-detail-text-font-weight));
  line-height: var(--spectrum-detail-s-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-detail-s-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-s-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
  text-transform: var(--spectrum-detail-s-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;
  
  }

.spectrum-Detail--sizeS em {
        font-size: var(--spectrum-detail-s-emphasis-text-size, var(--spectrum-global-dimension-font-size-50));
  font-weight: var(--spectrum-detail-s-emphasis-text-font-weight, var(--spectrum-alias-detail-text-font-weight));
  line-height: var(--spectrum-detail-s-emphasis-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-detail-s-emphasis-text-font-style, var(--spectrum-global-font-style-italic));
  letter-spacing: var(--spectrum-detail-s-emphasis-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
  text-transform: var(--spectrum-detail-s-emphasis-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum-Detail--sizeS strong {
        font-size: var(--spectrum-detail-s-strong-text-size, var(--spectrum-global-dimension-font-size-50));
  font-weight: var(--spectrum-detail-s-strong-text-font-weight, var(--spectrum-global-font-weight-black));
  line-height: var(--spectrum-detail-s-strong-text-line-height, var(--spectrum-alias-body-text-line-height));
  font-style: var(--spectrum-detail-s-strong-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-s-strong-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
  text-transform: var(--spectrum-detail-s-strong-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum-Code {
  font-family: var(--spectrum-heading-m-text-font-family, var(--spectrum-alias-body-text-font-family));
}

.spectrum-Code strong,
  .spectrum-Code .spectrum-Code-strong {
    font-weight: var(--spectrum-code-m-strong-text-font-weight, var(--spectrum-global-font-weight-bold));
  }

.spectrum-Code em,
  .spectrum-Code .spectrum-Code-emphasis {
    font-style: var(--spectrum-code-m-emphasis-text-font-style, var(--spectrum-global-font-style-italic));
  }

.spectrum-Code--serif {
  font-family: var(--spectrum-body-serif-m-text-font-family, var(--spectrum-alias-serif-text-font-family));
}

.spectrum-Code--sizeXL {
  

    font-size: var(--spectrum-code-xl-text-size, var(--spectrum-global-dimension-font-size-400));
  font-weight: var(--spectrum-code-xl-text-font-weight, var(--spectrum-alias-code-text-font-weight-regular));
  line-height: var(--spectrum-code-xl-text-line-height, var(--spectrum-alias-code-text-line-height));
  font-style: var(--spectrum-code-xl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-code-xl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  margin-top: 0;
  margin-bottom: 0;
  font-family: var(--spectrum-code-xl-text-font-family, var(--spectrum-alias-code-text-font-family));

    
  }

.spectrum-Code--sizeL {
  

    font-size: var(--spectrum-code-l-text-size, var(--spectrum-global-dimension-font-size-300));
  font-weight: var(--spectrum-code-l-text-font-weight, var(--spectrum-alias-code-text-font-weight-regular));
  line-height: var(--spectrum-code-l-text-line-height, var(--spectrum-alias-code-text-line-height));
  font-style: var(--spectrum-code-l-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-code-l-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  margin-top: 0;
  margin-bottom: 0;
  font-family: var(--spectrum-code-l-text-font-family, var(--spectrum-alias-code-text-font-family));

    
  }

.spectrum-Code--sizeM {
  

    font-size: var(--spectrum-code-m-text-size, var(--spectrum-global-dimension-font-size-200));
  font-weight: var(--spectrum-code-m-text-font-weight, var(--spectrum-alias-code-text-font-weight-regular));
  line-height: var(--spectrum-code-m-text-line-height, var(--spectrum-alias-code-text-line-height));
  font-style: var(--spectrum-code-m-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-code-m-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  margin-top: 0;
  margin-bottom: 0;
  font-family: var(--spectrum-code-m-text-font-family, var(--spectrum-alias-code-text-font-family));

    
  }

.spectrum-Code--sizeS {
  

    font-size: var(--spectrum-code-s-text-size, var(--spectrum-alias-font-size-default));
  font-weight: var(--spectrum-code-s-text-font-weight, var(--spectrum-alias-code-text-font-weight-regular));
  line-height: var(--spectrum-code-s-text-line-height, var(--spectrum-alias-code-text-line-height));
  font-style: var(--spectrum-code-s-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-code-s-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  margin-top: 0;
  margin-bottom: 0;
  font-family: var(--spectrum-code-s-text-font-family, var(--spectrum-alias-code-text-font-family));

    
  }

.spectrum-Code--sizeXS {
  

    font-size: var(--spectrum-code-xs-text-size, var(--spectrum-global-dimension-font-size-75));
  font-weight: var(--spectrum-code-xs-text-font-weight, var(--spectrum-alias-code-text-font-weight-regular));
  line-height: var(--spectrum-code-xs-text-line-height, var(--spectrum-alias-code-text-line-height));
  font-style: var(--spectrum-code-xs-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-code-xs-text-letter-spacing, var(--spectrum-global-font-letter-spacing-none));
  margin-top: 0;
  margin-bottom: 0;
  font-family: var(--spectrum-code-xs-text-font-family, var(--spectrum-alias-code-text-font-family));

    
  }

.spectrum-Typography .spectrum-Heading--sizeXXXL {
    margin-top: var(--spectrum-heading-xxxl-margin-top, var(--spectrum-alias-heading-xxxl-margin-top));
    margin-bottom: var(--spectrum-heading-xxxl-margin-bottom, var(--spectrum-global-dimension-size-130));
  }

.spectrum-Typography .spectrum-Heading--sizeXXL {
    margin-top: var(--spectrum-heading-xxl-margin-top, var(--spectrum-alias-heading-xxl-margin-top));
    margin-bottom: var(--spectrum-heading-xxl-margin-bottom, var(--spectrum-global-dimension-size-125));
  }

.spectrum-Typography .spectrum-Heading--sizeXL {
    margin-top: var(--spectrum-heading-xl-margin-top, var(--spectrum-alias-heading-xl-margin-top));
    margin-bottom: var(--spectrum-heading-xl-margin-bottom, var(--spectrum-global-dimension-size-115));
  }

.spectrum-Typography .spectrum-Heading--sizeL {
    margin-top: var(--spectrum-heading-l-margin-top, var(--spectrum-alias-heading-l-margin-top));
    margin-bottom: var(--spectrum-heading-l-margin-bottom, var(--spectrum-global-dimension-size-85));
  }

.spectrum-Typography .spectrum-Heading--sizeM {
    margin-top: var(--spectrum-heading-m-margin-top, var(--spectrum-alias-heading-m-margin-top));
    margin-bottom: var(--spectrum-heading-m-margin-bottom, var(--spectrum-global-dimension-size-75));
  }

.spectrum-Typography .spectrum-Heading--sizeS {
    margin-top: var(--spectrum-heading-s-margin-top, var(--spectrum-alias-heading-s-margin-top));
    margin-bottom: var(--spectrum-heading-s-margin-bottom, var(--spectrum-global-dimension-size-65));
  }

.spectrum-Typography .spectrum-Heading--sizeXS {
    margin-top: var(--spectrum-heading-xs-margin-top, var(--spectrum-alias-heading-xs-margin-top));
    margin-bottom: var(--spectrum-heading-xs-margin-bottom, var(--spectrum-global-dimension-size-50));
  }

.spectrum-Typography .spectrum-Heading--sizeXXS {
    margin-top: var(--spectrum-heading-xxs-margin-top, var(--spectrum-alias-heading-xxs-margin-top));
    margin-bottom: var(--spectrum-heading-xxs-margin-bottom, var(--spectrum-global-dimension-size-40));
  }

.spectrum-Typography .spectrum-Body--sizeXXXL {
    margin-top: var(--spectrum-body-xxxl-margin-top, 0px);
    margin-bottom: var(--spectrum-body-xxxl-margin-bottom, var(--spectrum-global-dimension-size-400));
  }

.spectrum-Typography .spectrum-Body--sizeXXL {
    margin-top: var(--spectrum-body-xxl-margin-top, 0px);
    margin-bottom: var(--spectrum-body-xxl-margin-bottom, var(--spectrum-global-dimension-size-300));
  }

.spectrum-Typography .spectrum-Body--sizeXL {
    margin-top: var(--spectrum-body-xl-margin-top, 0px);
    margin-bottom: var(--spectrum-body-xl-margin-bottom, var(--spectrum-global-dimension-size-200));
  }

.spectrum-Typography .spectrum-Body--sizeL {
    margin-top: var(--spectrum-body-l-margin-top, 0px);
    margin-bottom: var(--spectrum-body-l-margin-bottom, var(--spectrum-global-dimension-size-160));
  }

.spectrum-Typography .spectrum-Body--sizeM {
    margin-top: var(--spectrum-body-m-margin-top, 0px);
    margin-bottom: var(--spectrum-body-m-margin-bottom, var(--spectrum-global-dimension-size-150));
  }

.spectrum-Typography .spectrum-Body--sizeS {
    margin-top: var(--spectrum-body-s-margin-top, 0px);
    margin-bottom: var(--spectrum-body-s-margin-bottom, var(--spectrum-global-dimension-size-125));
  }

.spectrum-Typography .spectrum-Body--sizeXS {
    margin-top: var(--spectrum-body-xs-margin-top, 0px);
    margin-bottom: var(--spectrum-body-xs-margin-bottom, var(--spectrum-global-dimension-size-115));
  }

.spectrum:lang(ja) .spectrum-Heading--sizeXXXL, .spectrum:lang(ko) .spectrum-Heading--sizeXXXL, .spectrum:lang(zh) .spectrum-Heading--sizeXXXL {
  

    font-size: var(--spectrum-heading-han-xxxl-text-size, var(--spectrum-alias-heading-xxxl-text-size));
  font-weight: var(--spectrum-heading-han-xxxl-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-han-xxxl-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-heading-han-xxxl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-han-xxxl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-heading-han-xxxl-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Heading--sizeXXL, .spectrum:lang(ko) .spectrum-Heading--sizeXXL, .spectrum:lang(zh) .spectrum-Heading--sizeXXL {
  

    font-size: var(--spectrum-heading-han-xxl-text-size, var(--spectrum-alias-heading-han-xxl-text-size));
  font-weight: var(--spectrum-heading-han-xxl-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-han-xxl-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-heading-han-xxl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-han-xxl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-heading-han-xxl-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Heading--sizeXL, .spectrum:lang(ko) .spectrum-Heading--sizeXL, .spectrum:lang(zh) .spectrum-Heading--sizeXL {
  

    font-size: var(--spectrum-heading-han-xl-text-size, var(--spectrum-alias-heading-han-xl-text-size));
  font-weight: var(--spectrum-heading-han-xl-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-han-xl-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-heading-han-xl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-han-xl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-heading-han-xl-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Heading--sizeL, .spectrum:lang(ko) .spectrum-Heading--sizeL, .spectrum:lang(zh) .spectrum-Heading--sizeL {
  

    font-size: var(--spectrum-heading-han-l-text-size, var(--spectrum-alias-heading-han-l-text-size));
  font-weight: var(--spectrum-heading-han-l-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-han-l-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-heading-han-l-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-han-l-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-heading-han-l-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Heading--sizeM, .spectrum:lang(ko) .spectrum-Heading--sizeM, .spectrum:lang(zh) .spectrum-Heading--sizeM {
  

    font-size: var(--spectrum-heading-han-m-text-size, var(--spectrum-alias-heading-han-m-text-size));
  font-weight: var(--spectrum-heading-han-m-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-han-m-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-heading-han-m-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-han-m-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-heading-han-m-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Heading--sizeS, .spectrum:lang(ko) .spectrum-Heading--sizeS, .spectrum:lang(zh) .spectrum-Heading--sizeS {
  

    font-size: var(--spectrum-heading-han-s-text-size, var(--spectrum-alias-heading-s-text-size));
  font-weight: var(--spectrum-heading-han-s-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-han-s-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-heading-han-s-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-han-s-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-heading-han-s-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Heading--sizeXS, .spectrum:lang(ko) .spectrum-Heading--sizeXS, .spectrum:lang(zh) .spectrum-Heading--sizeXS {
  

    font-size: var(--spectrum-heading-han-xs-text-size, var(--spectrum-alias-heading-xs-text-size));
  font-weight: var(--spectrum-heading-han-xs-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-han-xs-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-heading-han-xs-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-han-xs-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-heading-han-xs-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Heading--sizeXXS, .spectrum:lang(ko) .spectrum-Heading--sizeXXS, .spectrum:lang(zh) .spectrum-Heading--sizeXXS {
  

    font-size: var(--spectrum-heading-han-xxs-text-size, var(--spectrum-alias-heading-xxs-text-size));
  font-weight: var(--spectrum-heading-han-xxs-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular));
  line-height: var(--spectrum-heading-han-xxs-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-heading-han-xxs-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-heading-han-xxs-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-heading-han-xxs-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Heading--heavy, .spectrum:lang(ko) .spectrum-Heading--heavy, .spectrum:lang(zh) .spectrum-Heading--heavy {
      font-weight: var(--spectrum-heading-han-m-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular));
    }

.spectrum:lang(ja) .spectrum-Heading--heavy em,
      .spectrum:lang(ja) .spectrum-Heading--heavy .spectrum-Heading--emphasis,
      .spectrum:lang(ko) .spectrum-Heading--heavy em,
      .spectrum:lang(ko) .spectrum-Heading--heavy .spectrum-Heading--emphasis,
      .spectrum:lang(zh) .spectrum-Heading--heavy em,
      .spectrum:lang(zh) .spectrum-Heading--heavy .spectrum-Heading--emphasis {
        font-style: var(--spectrum-heading-han-heavy-m-emphasis-text-font-style, var(--spectrum-global-font-style-regular));
        font-weight: var(--spectrum-heading-han-heavy-m-emphasis-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-heavy-emphasis));
      }

.spectrum:lang(ja) .spectrum-Heading--heavy strong,
      .spectrum:lang(ja) .spectrum-Heading--heavy .spectrum-Heading--strong,
      .spectrum:lang(ko) .spectrum-Heading--heavy strong,
      .spectrum:lang(ko) .spectrum-Heading--heavy .spectrum-Heading--strong,
      .spectrum:lang(zh) .spectrum-Heading--heavy strong,
      .spectrum:lang(zh) .spectrum-Heading--heavy .spectrum-Heading--strong {
        font-style: var(--spectrum-heading-heavy-m-strong-text-font-style, var(--spectrum-global-font-style-regular));
        font-weight: var(--spectrum-heading-heavy-m-strong-text-font-weight, var(--spectrum-global-font-weight-black));
      }

.spectrum:lang(ja) .spectrum-Heading--light, .spectrum:lang(ko) .spectrum-Heading--light, .spectrum:lang(zh) .spectrum-Heading--light {
      font-weight: var(--spectrum-heading-han-m-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular));
    }

.spectrum:lang(ja) .spectrum-Heading--light em,
      .spectrum:lang(ja) .spectrum-Heading--light .spectrum-Heading--emphasis,
      .spectrum:lang(ko) .spectrum-Heading--light em,
      .spectrum:lang(ko) .spectrum-Heading--light .spectrum-Heading--emphasis,
      .spectrum:lang(zh) .spectrum-Heading--light em,
      .spectrum:lang(zh) .spectrum-Heading--light .spectrum-Heading--emphasis {
        font-style: var(--spectrum-heading-han-light-m-emphasis-text-font-style, var(--spectrum-global-font-style-regular));
        font-weight: var(--spectrum-heading-han-light-m-emphasis-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-light-emphasis));
      }

.spectrum:lang(ja) .spectrum-Heading--light strong,
      .spectrum:lang(ja) .spectrum-Heading--light .spectrum-Heading--strong,
      .spectrum:lang(ko) .spectrum-Heading--light strong,
      .spectrum:lang(ko) .spectrum-Heading--light .spectrum-Heading--strong,
      .spectrum:lang(zh) .spectrum-Heading--light strong,
      .spectrum:lang(zh) .spectrum-Heading--light .spectrum-Heading--strong {
        font-style: var(--spectrum-heading-han-light-m-strong-text-font-style, var(--spectrum-global-font-style-regular));
        font-weight: var(--spectrum-heading-han-light-m-strong-text-font-weight, var(--spectrum-global-font-weight-bold));
      }

.spectrum:lang(ja) .spectrum-Body--sizeXXXL, .spectrum:lang(ko) .spectrum-Body--sizeXXXL, .spectrum:lang(zh) .spectrum-Body--sizeXXXL {
  

    font-size: var(--spectrum-body-han-xxxl-text-size, var(--spectrum-global-dimension-font-size-600));
  font-weight: var(--spectrum-body-han-xxxl-text-font-weight, var(--spectrum-alias-han-body-text-font-weight-regular));
  line-height: var(--spectrum-body-han-xxxl-text-line-height, var(--spectrum-alias-han-body-text-line-height));
  font-style: var(--spectrum-body-han-xxxl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-han-xxxl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-body-han-xxxl-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Body--sizeXXL, .spectrum:lang(ko) .spectrum-Body--sizeXXL, .spectrum:lang(zh) .spectrum-Body--sizeXXL {
  

    font-size: var(--spectrum-body-han-xxl-text-size, var(--spectrum-global-dimension-font-size-500));
  font-weight: var(--spectrum-body-han-xxl-text-font-weight, var(--spectrum-alias-han-body-text-font-weight-regular));
  line-height: var(--spectrum-body-han-xxl-text-line-height, var(--spectrum-alias-han-body-text-line-height));
  font-style: var(--spectrum-body-han-xxl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-han-xxl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-body-han-xxl-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Body--sizeXL, .spectrum:lang(ko) .spectrum-Body--sizeXL, .spectrum:lang(zh) .spectrum-Body--sizeXL {
  

    font-size: var(--spectrum-body-han-xl-text-size, var(--spectrum-global-dimension-font-size-400));
  font-weight: var(--spectrum-body-han-xl-text-font-weight, var(--spectrum-alias-han-body-text-font-weight-regular));
  line-height: var(--spectrum-body-han-xl-text-line-height, var(--spectrum-alias-han-body-text-line-height));
  font-style: var(--spectrum-body-han-xl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-han-xl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-body-han-xl-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Body--sizeL, .spectrum:lang(ko) .spectrum-Body--sizeL, .spectrum:lang(zh) .spectrum-Body--sizeL {
  

    font-size: var(--spectrum-body-han-l-text-size, var(--spectrum-global-dimension-font-size-300));
  font-weight: var(--spectrum-body-han-l-text-font-weight, var(--spectrum-alias-han-body-text-font-weight-regular));
  line-height: var(--spectrum-body-han-l-text-line-height, var(--spectrum-alias-han-body-text-line-height));
  font-style: var(--spectrum-body-han-l-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-han-l-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-body-han-l-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Body--sizeM, .spectrum:lang(ko) .spectrum-Body--sizeM, .spectrum:lang(zh) .spectrum-Body--sizeM {
  

    font-size: var(--spectrum-body-han-m-text-size, var(--spectrum-global-dimension-font-size-200));
  font-weight: var(--spectrum-body-han-m-text-font-weight, var(--spectrum-alias-han-body-text-font-weight-regular));
  line-height: var(--spectrum-body-han-m-text-line-height, var(--spectrum-alias-han-body-text-line-height));
  font-style: var(--spectrum-body-han-m-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-han-m-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-body-han-m-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Body--sizeS, .spectrum:lang(ko) .spectrum-Body--sizeS, .spectrum:lang(zh) .spectrum-Body--sizeS {
  

    font-size: var(--spectrum-body-han-s-text-size, var(--spectrum-alias-font-size-default));
  font-weight: var(--spectrum-body-han-s-text-font-weight, var(--spectrum-alias-han-body-text-font-weight-regular));
  line-height: var(--spectrum-body-han-s-text-line-height, var(--spectrum-alias-han-body-text-line-height));
  font-style: var(--spectrum-body-han-s-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-han-s-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-body-han-s-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Body--sizeXS, .spectrum:lang(ko) .spectrum-Body--sizeXS, .spectrum:lang(zh) .spectrum-Body--sizeXS {
  

    font-size: var(--spectrum-body-han-xs-text-size, var(--spectrum-global-dimension-font-size-75));
  font-weight: var(--spectrum-body-han-xs-text-font-weight, var(--spectrum-alias-han-body-text-font-weight-regular));
  line-height: var(--spectrum-body-han-xs-text-line-height, var(--spectrum-alias-han-body-text-line-height));
  font-style: var(--spectrum-body-han-xs-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-body-han-xs-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-body-han-xs-text-transform, none);
  margin-top: 0;
  margin-bottom: 0;

    
  }

.spectrum:lang(ja) .spectrum-Detail--sizeXL, .spectrum:lang(ko) .spectrum-Detail--sizeXL, .spectrum:lang(zh) .spectrum-Detail--sizeXL {
  

    font-size: var(--spectrum-detail-han-xl-text-size, var(--spectrum-global-dimension-font-size-200));
  font-weight: var(--spectrum-detail-han-xl-text-font-weight, var(--spectrum-alias-detail-text-font-weight));
  line-height: var(--spectrum-detail-han-xl-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-detail-han-xl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-han-xl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-detail-han-xl-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;
  
  }

.spectrum:lang(ja) .spectrum-Detail--sizeXL em, .spectrum:lang(ko) .spectrum-Detail--sizeXL em, .spectrum:lang(zh) .spectrum-Detail--sizeXL em {
        font-size: var(--spectrum-detail-han-xl-emphasis-text-size, var(--spectrum-global-dimension-font-size-200));
  font-weight: var(--spectrum-detail-han-xl-emphasis-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular-emphasis));
  line-height: var(--spectrum-detail-han-xl-emphasis-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-detail-han-xl-emphasis-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-han-xl-emphasis-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-detail-han-xl-emphasis-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum:lang(ja) .spectrum-Detail--sizeXL strong, .spectrum:lang(ko) .spectrum-Detail--sizeXL strong, .spectrum:lang(zh) .spectrum-Detail--sizeXL strong {
        font-size: var(--spectrum-detail-han-xl-strong-text-size, var(--spectrum-global-dimension-font-size-200));
  font-weight: var(--spectrum-detail-han-xl-strong-text-font-weight, var(--spectrum-global-font-weight-black));
  line-height: var(--spectrum-detail-han-xl-strong-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-detail-han-xl-strong-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-han-xl-strong-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-detail-han-xl-strong-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum:lang(ja) .spectrum-Detail--sizeL, .spectrum:lang(ko) .spectrum-Detail--sizeL, .spectrum:lang(zh) .spectrum-Detail--sizeL {
  

    font-size: var(--spectrum-detail-han-l-text-size, var(--spectrum-global-dimension-font-size-100));
  font-weight: var(--spectrum-detail-han-l-text-font-weight, var(--spectrum-alias-detail-text-font-weight));
  line-height: var(--spectrum-detail-han-l-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-detail-han-l-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-han-l-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-detail-han-l-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;
  
  }

.spectrum:lang(ja) .spectrum-Detail--sizeL em, .spectrum:lang(ko) .spectrum-Detail--sizeL em, .spectrum:lang(zh) .spectrum-Detail--sizeL em {
        font-size: var(--spectrum-detail-han-l-emphasis-text-size, var(--spectrum-global-dimension-font-size-100));
  font-weight: var(--spectrum-detail-han-l-emphasis-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular-emphasis));
  line-height: var(--spectrum-detail-han-l-emphasis-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-detail-han-l-emphasis-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-han-l-emphasis-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-detail-han-l-emphasis-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum:lang(ja) .spectrum-Detail--sizeL strong, .spectrum:lang(ko) .spectrum-Detail--sizeL strong, .spectrum:lang(zh) .spectrum-Detail--sizeL strong {
        font-size: var(--spectrum-detail-han-l-strong-text-size, var(--spectrum-global-dimension-font-size-100));
  font-weight: var(--spectrum-detail-han-l-strong-text-font-weight, var(--spectrum-global-font-weight-black));
  line-height: var(--spectrum-detail-han-l-strong-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-detail-han-l-strong-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-han-l-strong-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-detail-han-l-strong-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum:lang(ja) .spectrum-Detail--sizeM, .spectrum:lang(ko) .spectrum-Detail--sizeM, .spectrum:lang(zh) .spectrum-Detail--sizeM {
  

    font-size: var(--spectrum-detail-han-m-text-size, var(--spectrum-global-dimension-font-size-75));
  font-weight: var(--spectrum-detail-han-m-text-font-weight, var(--spectrum-alias-detail-text-font-weight));
  line-height: var(--spectrum-detail-han-m-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-detail-han-m-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-han-m-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-detail-han-m-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;
  
  }

.spectrum:lang(ja) .spectrum-Detail--sizeM em, .spectrum:lang(ko) .spectrum-Detail--sizeM em, .spectrum:lang(zh) .spectrum-Detail--sizeM em {
        font-size: var(--spectrum-detail-han-m-emphasis-text-size, var(--spectrum-global-dimension-font-size-75));
  font-weight: var(--spectrum-detail-han-m-emphasis-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular-emphasis));
  line-height: var(--spectrum-detail-han-m-emphasis-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-detail-han-m-emphasis-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-han-m-emphasis-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-detail-han-m-emphasis-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum:lang(ja) .spectrum-Detail--sizeM strong, .spectrum:lang(ko) .spectrum-Detail--sizeM strong, .spectrum:lang(zh) .spectrum-Detail--sizeM strong {
        font-size: var(--spectrum-detail-han-m-strong-text-size, var(--spectrum-global-dimension-font-size-75));
  font-weight: var(--spectrum-detail-han-m-strong-text-font-weight, var(--spectrum-global-font-weight-black));
  line-height: var(--spectrum-detail-han-m-strong-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-detail-han-m-strong-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-han-m-strong-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-detail-han-m-strong-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum:lang(ja) .spectrum-Detail--sizeS, .spectrum:lang(ko) .spectrum-Detail--sizeS, .spectrum:lang(zh) .spectrum-Detail--sizeS {
  

    font-size: var(--spectrum-detail-han-s-text-size, var(--spectrum-global-dimension-font-size-50));
  font-weight: var(--spectrum-detail-han-s-text-font-weight, var(--spectrum-alias-detail-text-font-weight));
  line-height: var(--spectrum-detail-han-s-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-detail-han-s-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-han-s-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-detail-han-s-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;
  
  }

.spectrum:lang(ja) .spectrum-Detail--sizeS em, .spectrum:lang(ko) .spectrum-Detail--sizeS em, .spectrum:lang(zh) .spectrum-Detail--sizeS em {
        font-size: var(--spectrum-detail-han-s-emphasis-text-size, var(--spectrum-global-dimension-font-size-50));
  font-weight: var(--spectrum-detail-han-s-emphasis-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-regular-emphasis));
  line-height: var(--spectrum-detail-han-s-emphasis-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-detail-han-s-emphasis-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-han-s-emphasis-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-detail-han-s-emphasis-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum:lang(ja) .spectrum-Detail--sizeS strong, .spectrum:lang(ko) .spectrum-Detail--sizeS strong, .spectrum:lang(zh) .spectrum-Detail--sizeS strong {
        font-size: var(--spectrum-detail-han-s-strong-text-size, var(--spectrum-global-dimension-font-size-50));
  font-weight: var(--spectrum-detail-han-s-strong-text-font-weight, var(--spectrum-global-font-weight-black));
  line-height: var(--spectrum-detail-han-s-strong-text-line-height, var(--spectrum-alias-han-heading-text-line-height));
  font-style: var(--spectrum-detail-han-s-strong-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-detail-han-s-strong-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  text-transform: var(--spectrum-detail-han-s-strong-text-transform, uppercase);
  margin-top: 0;
  margin-bottom: 0;

    }

.spectrum:lang(ja) .spectrum-Detail--light, .spectrum:lang(ko) .spectrum-Detail--light, .spectrum:lang(zh) .spectrum-Detail--light {
      font-weight: var(--spectrum-detail-han-m-text-font-weight, var(--spectrum-alias-detail-text-font-weight));
    }

.spectrum:lang(ja) .spectrum-Detail--light em,
      .spectrum:lang(ja) .spectrum-Detail--light .spectrum-Detail--emphasis,
      .spectrum:lang(ko) .spectrum-Detail--light em,
      .spectrum:lang(ko) .spectrum-Detail--light .spectrum-Detail--emphasis,
      .spectrum:lang(zh) .spectrum-Detail--light em,
      .spectrum:lang(zh) .spectrum-Detail--light .spectrum-Detail--emphasis {
        font-style: var(--spectrum-detail-han-light-m-emphasis-text-font-style, var(--spectrum-global-font-style-regular));
        font-weight: var(--spectrum-detail-han-light-m-emphasis-text-font-weight, var(--spectrum-alias-han-heading-text-font-weight-light-emphasis));
      }

.spectrum:lang(ja) .spectrum-Detail--light strong,
      .spectrum:lang(ja) .spectrum-Detail--light .spectrum-Detail--strong,
      .spectrum:lang(ko) .spectrum-Detail--light strong,
      .spectrum:lang(ko) .spectrum-Detail--light .spectrum-Detail--strong,
      .spectrum:lang(zh) .spectrum-Detail--light strong,
      .spectrum:lang(zh) .spectrum-Detail--light .spectrum-Detail--strong {
        font-style: var(--spectrum-detail-han-light-m-strong-text-font-style, var(--spectrum-global-font-style-regular));
        font-weight: var(--spectrum-detail-han-light-m-strong-text-font-weight, var(--spectrum-alias-heading-text-font-weight-regular));
      }

.spectrum:lang(ja) .spectrum-Code--sizeXL, .spectrum:lang(ko) .spectrum-Code--sizeXL, .spectrum:lang(zh) .spectrum-Code--sizeXL {
  

    font-size: var(--spectrum-code-han-xl-text-size, var(--spectrum-global-dimension-font-size-400));
  font-weight: var(--spectrum-code-han-xl-text-font-weight, var(--spectrum-alias-han-body-text-font-weight-regular));
  line-height: var(--spectrum-code-han-xl-text-line-height, var(--spectrum-alias-han-body-text-line-height));
  font-style: var(--spectrum-code-han-xl-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-code-han-xl-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  margin-top: 0;
  margin-bottom: 0;
      font-family: var(--spectrum-code-han-xl-text-font-family, var(--spectrum-alias-font-family-zh));

    
  }

.spectrum:lang(ja) .spectrum-Code--sizeL, .spectrum:lang(ko) .spectrum-Code--sizeL, .spectrum:lang(zh) .spectrum-Code--sizeL {
  

    font-size: var(--spectrum-code-han-l-text-size, var(--spectrum-global-dimension-font-size-300));
  font-weight: var(--spectrum-code-han-l-text-font-weight, var(--spectrum-alias-han-body-text-font-weight-regular));
  line-height: var(--spectrum-code-han-l-text-line-height, var(--spectrum-alias-han-body-text-line-height));
  font-style: var(--spectrum-code-han-l-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-code-han-l-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  margin-top: 0;
  margin-bottom: 0;
      font-family: var(--spectrum-code-han-l-text-font-family, var(--spectrum-alias-font-family-zh));

    
  }

.spectrum:lang(ja) .spectrum-Code--sizeM, .spectrum:lang(ko) .spectrum-Code--sizeM, .spectrum:lang(zh) .spectrum-Code--sizeM {
  

    font-size: var(--spectrum-code-han-m-text-size, var(--spectrum-global-dimension-font-size-200));
  font-weight: var(--spectrum-code-han-m-text-font-weight, var(--spectrum-alias-han-body-text-font-weight-regular));
  line-height: var(--spectrum-code-han-m-text-line-height, var(--spectrum-alias-han-body-text-line-height));
  font-style: var(--spectrum-code-han-m-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-code-han-m-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  margin-top: 0;
  margin-bottom: 0;
      font-family: var(--spectrum-code-han-m-text-font-family, var(--spectrum-alias-font-family-zh));

    
  }

.spectrum:lang(ja) .spectrum-Code--sizeS, .spectrum:lang(ko) .spectrum-Code--sizeS, .spectrum:lang(zh) .spectrum-Code--sizeS {
  

    font-size: var(--spectrum-code-han-s-text-size, var(--spectrum-alias-font-size-default));
  font-weight: var(--spectrum-code-han-s-text-font-weight, var(--spectrum-alias-han-body-text-font-weight-regular));
  line-height: var(--spectrum-code-han-s-text-line-height, var(--spectrum-alias-han-body-text-line-height));
  font-style: var(--spectrum-code-han-s-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-code-han-s-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  margin-top: 0;
  margin-bottom: 0;
      font-family: var(--spectrum-code-han-s-text-font-family, var(--spectrum-alias-font-family-zh));

    
  }

.spectrum:lang(ja) .spectrum-Code--sizeXS, .spectrum:lang(ko) .spectrum-Code--sizeXS, .spectrum:lang(zh) .spectrum-Code--sizeXS {
  

    font-size: var(--spectrum-code-han-xs-text-size, var(--spectrum-global-dimension-font-size-75));
  font-weight: var(--spectrum-code-han-xs-text-font-weight, var(--spectrum-alias-han-body-text-font-weight-regular));
  line-height: var(--spectrum-code-han-xs-text-line-height, var(--spectrum-alias-han-body-text-line-height));
  font-style: var(--spectrum-code-han-xs-text-font-style, var(--spectrum-global-font-style-regular));
  letter-spacing: var(--spectrum-code-han-xs-text-letter-spacing, var(--spectrum-global-font-letter-spacing-han));
  margin-top: 0;
  margin-bottom: 0;
      font-family: var(--spectrum-code-han-xs-text-font-family, var(--spectrum-alias-font-family-zh));

    
  }

.spectrum-Heading--sizeXXXL {
    
    color: var(--spectrum-heading-xxxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading--sizeXXL {
    
    color: var(--spectrum-heading-xxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading--sizeXL {
    
    color: var(--spectrum-heading-xl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading--sizeL {
    
    color: var(--spectrum-heading-l-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading--sizeM {
    
    color: var(--spectrum-heading-m-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading--sizeS {
    
    color: var(--spectrum-heading-s-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading--sizeXS {
    
    color: var(--spectrum-heading-xs-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading--sizeXXS {
    
    color: var(--spectrum-heading-xxs-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading-sizeXXXL--light {
    
    color: var(--spectrum-heading-light-xxxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading-sizeXXL--light {
    
    color: var(--spectrum-heading-light-xxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading-sizeXL--light {
    
    color: var(--spectrum-heading-light-xl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading-sizeL--light {
    
    color: var(--spectrum-heading-light-l-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading-sizeXXXL--heavy {
    
    color: var(--spectrum-heading-heavy-xxxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading-sizeXXL--heavy {
    
    color: var(--spectrum-heading-heavy-xxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading-sizeXL--heavy {
    
    color: var(--spectrum-heading-heavy-xl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading-sizeL--heavy {
    
    color: var(--spectrum-heading-heavy-l-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading-sizeXXXL--heading {
    
    color: var(--spectrum-heading-xxxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading-sizeXXL--heading {
    
    color: var(--spectrum-heading-xxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading-sizeXL--heading {
    
    color: var(--spectrum-heading-xl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Heading-sizeL--heading {
    
    color: var(--spectrum-heading-l-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Body--sizeXXXL {
    
    color: var(--spectrum-body-xxxl-text-color, var(--spectrum-alias-text-color));
  }

.spectrum-Body--sizeXXL {
    
    color: var(--spectrum-body-xxl-text-color, var(--spectrum-alias-text-color));
  }

.spectrum-Body--sizeXL {
    
    color: var(--spectrum-body-xl-text-color, var(--spectrum-alias-text-color));
  }

.spectrum-Body--sizeL {
    
    color: var(--spectrum-body-l-text-color, var(--spectrum-alias-text-color));
  }

.spectrum-Body--sizeM {
    
    color: var(--spectrum-body-m-text-color, var(--spectrum-alias-text-color));
  }

.spectrum-Body--sizeS {
    
    color: var(--spectrum-body-s-text-color, var(--spectrum-alias-text-color));
  }

.spectrum-Body--sizeXS {
    
    color: var(--spectrum-body-xs-text-color, var(--spectrum-alias-text-color));
  }

.spectrum-Detail--sizeXL {
    
    color: var(--spectrum-detail-xl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Detail--sizeL {
    
    color: var(--spectrum-detail-l-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Detail--sizeM {
    
    color: var(--spectrum-detail-m-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Detail--sizeS {
    
    color: var(--spectrum-detail-s-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum-Code--sizeXL {
    
    color: var(--spectrum-code-xl-text-color, var(--spectrum-alias-text-color));
  }

.spectrum-Code--sizeL {
    
    color: var(--spectrum-code-l-text-color, var(--spectrum-alias-text-color));
  }

.spectrum-Code--sizeM {
    
    color: var(--spectrum-code-m-text-color, var(--spectrum-alias-text-color));
  }

.spectrum-Code--sizeS {
    
    color: var(--spectrum-code-s-text-color, var(--spectrum-alias-text-color));
  }

.spectrum-Code--sizeXS {
    
    color: var(--spectrum-code-xs-text-color, var(--spectrum-alias-text-color));
  }

.spectrum:lang(ja) .spectrum-Body--sizeXXXL, .spectrum:lang(ko) .spectrum-Body--sizeXXXL, .spectrum:lang(zh) .spectrum-Body--sizeXXXL {
    
    color: var(--spectrum-body-han-xxxl-text-color, var(--spectrum-alias-text-color));
  }

.spectrum:lang(ja) .spectrum-Body--sizeXXL, .spectrum:lang(ko) .spectrum-Body--sizeXXL, .spectrum:lang(zh) .spectrum-Body--sizeXXL {
    
    color: var(--spectrum-body-han-xxl-text-color, var(--spectrum-alias-text-color));
  }

.spectrum:lang(ja) .spectrum-Body--sizeXL, .spectrum:lang(ko) .spectrum-Body--sizeXL, .spectrum:lang(zh) .spectrum-Body--sizeXL {
    
    color: var(--spectrum-body-han-xl-text-color, var(--spectrum-alias-text-color));
  }

.spectrum:lang(ja) .spectrum-Body--sizeL, .spectrum:lang(ko) .spectrum-Body--sizeL, .spectrum:lang(zh) .spectrum-Body--sizeL {
    
    color: var(--spectrum-body-han-l-text-color, var(--spectrum-alias-text-color));
  }

.spectrum:lang(ja) .spectrum-Body--sizeM, .spectrum:lang(ko) .spectrum-Body--sizeM, .spectrum:lang(zh) .spectrum-Body--sizeM {
    
    color: var(--spectrum-body-han-m-text-color, var(--spectrum-alias-text-color));
  }

.spectrum:lang(ja) .spectrum-Body--sizeS, .spectrum:lang(ko) .spectrum-Body--sizeS, .spectrum:lang(zh) .spectrum-Body--sizeS {
    
    color: var(--spectrum-body-han-s-text-color, var(--spectrum-alias-text-color));
  }

.spectrum:lang(ja) .spectrum-Body--sizeXS, .spectrum:lang(ko) .spectrum-Body--sizeXS, .spectrum:lang(zh) .spectrum-Body--sizeXS {
    
    color: var(--spectrum-body-han-xs-text-color, var(--spectrum-alias-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading--sizeXXXL, .spectrum:lang(ko) .spectrum-Heading--sizeXXXL, .spectrum:lang(zh) .spectrum-Heading--sizeXXXL {
    
    color: var(--spectrum-heading-xxxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading--sizeXXL, .spectrum:lang(ko) .spectrum-Heading--sizeXXL, .spectrum:lang(zh) .spectrum-Heading--sizeXXL {
    
    color: var(--spectrum-heading-xxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading--sizeXL, .spectrum:lang(ko) .spectrum-Heading--sizeXL, .spectrum:lang(zh) .spectrum-Heading--sizeXL {
    
    color: var(--spectrum-heading-xl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading--sizeL, .spectrum:lang(ko) .spectrum-Heading--sizeL, .spectrum:lang(zh) .spectrum-Heading--sizeL {
    
    color: var(--spectrum-heading-l-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading--sizeM, .spectrum:lang(ko) .spectrum-Heading--sizeM, .spectrum:lang(zh) .spectrum-Heading--sizeM {
    
    color: var(--spectrum-heading-m-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading--sizeS, .spectrum:lang(ko) .spectrum-Heading--sizeS, .spectrum:lang(zh) .spectrum-Heading--sizeS {
    
    color: var(--spectrum-heading-s-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading--sizeXS, .spectrum:lang(ko) .spectrum-Heading--sizeXS, .spectrum:lang(zh) .spectrum-Heading--sizeXS {
    
    color: var(--spectrum-heading-xs-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading--sizeXXS, .spectrum:lang(ko) .spectrum-Heading--sizeXXS, .spectrum:lang(zh) .spectrum-Heading--sizeXXS {
    
    color: var(--spectrum-heading-xxs-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading-sizeXXXL--light, .spectrum:lang(ko) .spectrum-Heading-sizeXXXL--light, .spectrum:lang(zh) .spectrum-Heading-sizeXXXL--light {
    
    color: var(--spectrum-heading-light-xxxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading-sizeXXL--light, .spectrum:lang(ko) .spectrum-Heading-sizeXXL--light, .spectrum:lang(zh) .spectrum-Heading-sizeXXL--light {
    
    color: var(--spectrum-heading-light-xxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading-sizeXL--light, .spectrum:lang(ko) .spectrum-Heading-sizeXL--light, .spectrum:lang(zh) .spectrum-Heading-sizeXL--light {
    
    color: var(--spectrum-heading-light-xl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading-sizeL--light, .spectrum:lang(ko) .spectrum-Heading-sizeL--light, .spectrum:lang(zh) .spectrum-Heading-sizeL--light {
    
    color: var(--spectrum-heading-light-l-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading-sizeXXXL--heavy, .spectrum:lang(ko) .spectrum-Heading-sizeXXXL--heavy, .spectrum:lang(zh) .spectrum-Heading-sizeXXXL--heavy {
    
    color: var(--spectrum-heading-heavy-xxxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading-sizeXXL--heavy, .spectrum:lang(ko) .spectrum-Heading-sizeXXL--heavy, .spectrum:lang(zh) .spectrum-Heading-sizeXXL--heavy {
    
    color: var(--spectrum-heading-heavy-xxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading-sizeXL--heavy, .spectrum:lang(ko) .spectrum-Heading-sizeXL--heavy, .spectrum:lang(zh) .spectrum-Heading-sizeXL--heavy {
    
    color: var(--spectrum-heading-heavy-xl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading-sizeL--heavy, .spectrum:lang(ko) .spectrum-Heading-sizeL--heavy, .spectrum:lang(zh) .spectrum-Heading-sizeL--heavy {
    
    color: var(--spectrum-heading-heavy-l-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading-sizeXXXL--heading, .spectrum:lang(ko) .spectrum-Heading-sizeXXXL--heading, .spectrum:lang(zh) .spectrum-Heading-sizeXXXL--heading {
    
    color: var(--spectrum-heading-xxxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading-sizeXXL--heading, .spectrum:lang(ko) .spectrum-Heading-sizeXXL--heading, .spectrum:lang(zh) .spectrum-Heading-sizeXXL--heading {
    
    color: var(--spectrum-heading-xxl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading-sizeXL--heading, .spectrum:lang(ko) .spectrum-Heading-sizeXL--heading, .spectrum:lang(zh) .spectrum-Heading-sizeXL--heading {
    
    color: var(--spectrum-heading-xl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Heading-sizeL--heading, .spectrum:lang(ko) .spectrum-Heading-sizeL--heading, .spectrum:lang(zh) .spectrum-Heading-sizeL--heading {
    
    color: var(--spectrum-heading-l-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Detail--sizeXL, .spectrum:lang(ko) .spectrum-Detail--sizeXL, .spectrum:lang(zh) .spectrum-Detail--sizeXL {
    
    color: var(--spectrum-detail-xl-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Detail--sizeL, .spectrum:lang(ko) .spectrum-Detail--sizeL, .spectrum:lang(zh) .spectrum-Detail--sizeL {
    
    color: var(--spectrum-detail-l-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Detail--sizeM, .spectrum:lang(ko) .spectrum-Detail--sizeM, .spectrum:lang(zh) .spectrum-Detail--sizeM {
    
    color: var(--spectrum-detail-m-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Detail--sizeS, .spectrum:lang(ko) .spectrum-Detail--sizeS, .spectrum:lang(zh) .spectrum-Detail--sizeS {
    
    color: var(--spectrum-detail-s-text-color, var(--spectrum-alias-heading-text-color));
  }

.spectrum:lang(ja) .spectrum-Code--sizeXL, .spectrum:lang(ko) .spectrum-Code--sizeXL, .spectrum:lang(zh) .spectrum-Code--sizeXL {
    
    color: var(--spectrum-code-xl-text-color, var(--spectrum-alias-text-color));
  }

.spectrum:lang(ja) .spectrum-Code--sizeL, .spectrum:lang(ko) .spectrum-Code--sizeL, .spectrum:lang(zh) .spectrum-Code--sizeL {
    
    color: var(--spectrum-code-l-text-color, var(--spectrum-alias-text-color));
  }

.spectrum:lang(ja) .spectrum-Code--sizeM, .spectrum:lang(ko) .spectrum-Code--sizeM, .spectrum:lang(zh) .spectrum-Code--sizeM {
    
    color: var(--spectrum-code-m-text-color, var(--spectrum-alias-text-color));
  }

.spectrum:lang(ja) .spectrum-Code--sizeS, .spectrum:lang(ko) .spectrum-Code--sizeS, .spectrum:lang(zh) .spectrum-Code--sizeS {
    
    color: var(--spectrum-code-s-text-color, var(--spectrum-alias-text-color));
  }

.spectrum:lang(ja) .spectrum-Code--sizeXS, .spectrum:lang(ko) .spectrum-Code--sizeXS, .spectrum:lang(zh) .spectrum-Code--sizeXS {
    
    color: var(--spectrum-code-xs-text-color, var(--spectrum-alias-text-color));
  }

.spectrum,
.spectrum-Body {
  color: var(--spectrum-body-m-text-color, var(--spectrum-alias-text-color));
}
.spectrum-Link--sizeS {
  --spectrum-link-primary-text-size: var(--spectrum-link-primary-s-text-size, var(--spectrum-alias-item-text-size-s));
}

.spectrum-Link--sizeM {
  --spectrum-link-primary-text-size: var(--spectrum-link-primary-m-text-size, var(--spectrum-alias-item-text-size-m));
}

.spectrum-Link--sizeL {
  --spectrum-link-primary-text-size: var(--spectrum-link-primary-l-text-size, var(--spectrum-alias-item-text-size-l));
}

.spectrum-Link--sizeXL {
  --spectrum-link-primary-text-size: var(--spectrum-link-primary-xl-text-size, var(--spectrum-alias-item-text-size-xl));
}

.spectrum-Link--sizeS,
.spectrum-Link--sizeM,
.spectrum-Link--sizeL,
.spectrum-Link--sizeXL {
  font-size: var(--spectrum-link-primary-text-size);
}

.spectrum-Link {
  background-color: transparent;
  -webkit-text-decoration-skip: objects;
  text-decoration: underline;
  transition: color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
  outline: none;
  cursor: pointer;
}

.spectrum-Link.focus-ring {
    text-decoration: underline;
    -webkit-text-decoration-style: double;
            text-decoration-style: double;
  }

.spectrum-Link--quiet {
  text-decoration: none;
}

.spectrum-Link--quiet:hover {
    text-decoration: underline;
  }

.spectrum-Link {
  color: var(--spectrum-link-primary-m-text-color, var(--spectrum-global-color-blue-600));
}

.spectrum-Link:hover {
    color: var(--spectrum-link-primary-m-text-color-hover, var(--spectrum-global-color-blue-600));
  }

.spectrum-Link:active {
    color: var(--spectrum-link-primary-m-text-color-down, var(--spectrum-global-color-blue-700));
  }

.spectrum-Link.focus-ring {
    color: var(--spectrum-link-primary-m-text-color-key-focus, var(--spectrum-alias-text-color-key-focus));
  }

.spectrum-Link--secondary {
  color: inherit;
}

.spectrum-Link--secondary:hover {
    color: inherit;
  }

.spectrum-Link--secondary:active {
    color: inherit;
  }

.spectrum-Link--secondary:focus {
    color: inherit;
  }

.spectrum-Link--overBackground {
  color: var(--spectrum-link-over-background-m-text-color, var(--spectrum-alias-text-color-over-background));
}

.spectrum-Link--overBackground:hover {
    color: var(--spectrum-link-over-background-m-text-color-hover, var(--spectrum-alias-text-color-over-background));
  }

.spectrum-Link--overBackground:active {
    color: var(--spectrum-link-over-background-m-text-color-down, var(--spectrum-alias-text-color-over-background));
  }

.spectrum-Link--overBackground:focus {
    color: var(--spectrum-link-over-background-m-text-color-key-focus, var(--spectrum-alias-text-color-over-background));
  }
a.svelte-171sey2.svelte-171sey2{position:relative}a.disabled.svelte-171sey2.svelte-171sey2{color:var(--spectrum-global-color-gray-500)}a.disabled.svelte-171sey2.svelte-171sey2:hover{text-decoration:none;cursor:default}.tooltip.svelte-171sey2.svelte-171sey2{position:absolute;left:50%;top:100%;transform:translateX(-50%);opacity:0;transition:130ms ease-out;pointer-events:none;z-index:100}a.svelte-171sey2:hover .tooltip.svelte-171sey2{opacity:1}.container.svelte-1wflao9.svelte-1wflao9{--spectrum-dropzone-padding:var(--spectrum-global-dimension-size-400);--spectrum-heading-l-text-size:var(
      --spectrum-global-dimension-font-size-400
    )}.gallery.svelte-1wflao9.svelte-1wflao9,.spectrum-Dropzone.svelte-1wflao9.svelte-1wflao9{user-select:none}input[type="file"].svelte-1wflao9.svelte-1wflao9{display:none}.compact.svelte-1wflao9 .spectrum-Dropzone.svelte-1wflao9{padding:6px 0 !important}.gallery.svelte-1wflao9.svelte-1wflao9{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;background-color:var(--spectrum-global-color-gray-50);color:var(--spectrum-alias-text-color);font-size:var(--spectrum-alias-item-text-size-m);box-sizing:border-box;border:var(--spectrum-alias-border-size-thin)
      var(--spectrum-alias-border-color) solid;border-radius:var(--spectrum-alias-border-radius-regular);padding:10px;margin-bottom:10px;position:relative}.placeholder.svelte-1wflao9.svelte-1wflao9,img.svelte-1wflao9.svelte-1wflao9{height:120px;max-width:100%;object-fit:contain;margin:20px 30px}.compact.svelte-1wflao9 .placeholder.svelte-1wflao9,.compact.svelte-1wflao9 img.svelte-1wflao9{margin:8px 16px}.compact.svelte-1wflao9 img.svelte-1wflao9{height:90px}.compact.svelte-1wflao9 .gallery.svelte-1wflao9{padding:6px 10px;margin-bottom:8px}.compact.svelte-1wflao9 .placeholder.svelte-1wflao9{height:fit-content}.title.svelte-1wflao9.svelte-1wflao9{display:flex;flex-direction:row;justify-content:flex-start;align-items:center}.filename.svelte-1wflao9.svelte-1wflao9{flex:1 1 auto;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:0;margin-right:10px;user-select:all}.placeholder.svelte-1wflao9.svelte-1wflao9{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center}.extension.svelte-1wflao9.svelte-1wflao9{color:var(--spectrum-global-color-gray-600);text-transform:uppercase;font-weight:600;margin-bottom:5px;user-select:all}.nav.svelte-1wflao9.svelte-1wflao9{padding:var(--spacing-xs);position:absolute;top:50%;border-radius:5px;display:none;transition:all 0.3s}.nav.visible.svelte-1wflao9.svelte-1wflao9{display:block}.nav.svelte-1wflao9.svelte-1wflao9:hover{cursor:pointer;color:var(--blue)}.left.svelte-1wflao9.svelte-1wflao9{left:5px}.right.svelte-1wflao9.svelte-1wflao9{right:5px}.delete-button.svelte-1wflao9.svelte-1wflao9{transition:all 0.3s;margin-left:10px;display:flex}.delete-button.svelte-1wflao9.svelte-1wflao9:hover{cursor:pointer;color:var(--red)}.spectrum-Dropzone.svelte-1wflao9.svelte-1wflao9{height:220px;position:relative}.compact.svelte-1wflao9 .spectrum-Dropzone.svelte-1wflao9{height:40px}.spectrum-Dropzone.disabled.svelte-1wflao9.svelte-1wflao9{pointer-events:none;background-color:var(--spectrum-global-color-gray-200)}.disabled.svelte-1wflao9 .spectrum-Heading--sizeL.svelte-1wflao9{color:var(--spectrum-alias-text-color-disabled)}.compact.svelte-1wflao9 .spectrum-IllustratedMessage-description.svelte-1wflao9{margin:0}.tags.svelte-1wflao9.svelte-1wflao9{margin-top:20px;display:flex;flex-wrap:wrap;justify-content:center}.tag.svelte-1wflao9.svelte-1wflao9{margin-top:8px}.loading.svelte-1wflao9.svelte-1wflao9{position:absolute;display:grid;place-items:center;height:100%;width:100%;top:0;left:0}.spectrum-Divider--sizeS {
  --spectrum-divider-height: var(--spectrum-divider-s-height, var(--spectrum-global-dimension-size-10));
  --spectrum-divider-vertical-width: var(--spectrum-divider-s-vertical-width, var(--spectrum-global-dimension-size-10));
}

.spectrum-Divider--sizeM {
  --spectrum-divider-height: var(--spectrum-divider-m-height, var(--spectrum-global-dimension-size-25));
  --spectrum-divider-vertical-width: var(--spectrum-divider-m-vertical-width, var(--spectrum-global-dimension-size-25));
}

.spectrum-Divider--sizeL {
  --spectrum-divider-height: var(--spectrum-divider-l-height, var(--spectrum-global-dimension-size-50));
  --spectrum-divider-vertical-width: var(--spectrum-divider-l-vertical-width, var(--spectrum-global-dimension-size-50));
}

.spectrum-Divider {
  --spectrum-divider-vertical-height: 100%;
}

.spectrum-Divider {
  width: 100%;
  height: var(--spectrum-divider-height);
  overflow: visible;

  border: none;
  border-width: var(--spectrum-divider-height);
  border-radius: var(--spectrum-divider-height);
}

.spectrum-Divider--vertical {
  height: var(--spectrum-divider-vertical-height);
  width: var(--spectrum-divider-vertical-width);
}

.spectrum-Divider {
  --spectrum-divider-l-background-color: var(--spectrum-global-color-gray-800);
  --spectrum-divider-m-background-color: var(--spectrum-global-color-gray-300);
  --spectrum-divider-s-background-color: var(--spectrum-global-color-gray-300);
}

.spectrum-Divider--sizeL {
  background-color: var(--spectrum-divider-l-background-color, var(--spectrum-global-color-gray-800));
}

.spectrum-Divider--sizeM {
  background-color: var(--spectrum-divider-m-background-color, var(--spectrum-global-color-gray-300));
}

.spectrum-Divider--sizeS {
  background-color: var(--spectrum-divider-s-background-color, var(--spectrum-global-color-gray-300));
}
hr.svelte-kjvv8b{background:var(--spectrum-global-color-gray-200)}hr.noMargin.svelte-kjvv8b{margin:0}hr.noGrid.svelte-kjvv8b{grid-area:auto}.spectrum-Textfield.svelte-17nw4ph{width:100%}.inline-icon.svelte-17nw4ph{position:absolute;top:25%;right:2%}.primary-text.svelte-17nw4ph{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.spectrum-InputGroup.svelte-17nw4ph{min-width:0;width:100%}.spectrum-Popover.svelte-17nw4ph{max-height:240px;z-index:999;top:100%}.spectrum-Popover.spectrum-Popover--bottom.spectrum-Picker-popover.is-open.svelte-17nw4ph{width:100%}.no-variables-text.svelte-17nw4ph{padding:var(--spacing-m);color:var(--spectrum-global-color-gray-600)}.add-variable.svelte-17nw4ph{display:flex;padding:var(--spacing-m) 0 var(--spacing-m) var(--spacing-m);align-items:center;gap:var(--spacing-s);cursor:pointer}.add-variable.svelte-17nw4ph:hover{background:var(--grey-1)}.spectrum-Radio {
  --spectrum-radio-circle-border-size: var(--spectrum-radio-m-circle-border-size, var(--spectrum-alias-border-size-thick));
  --spectrum-radio-circle-dot-size: var(--spectrum-radio-m-circle-dot-size, var(--spectrum-global-dimension-static-size-50));
  --spectrum-radio-text-font-style: var(--spectrum-radio-m-text-font-style, var(--spectrum-global-font-style-regular));
  --spectrum-radio-text-font-weight: var(--spectrum-radio-m-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-radio-text-line-height: var(--spectrum-radio-m-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-radio-text-size: var(--spectrum-radio-m-text-size, var(--spectrum-alias-item-text-size-m));
  --spectrum-radio-height: var(--spectrum-radio-m-height, var(--spectrum-alias-item-height-m));
  --spectrum-radio-circle-diameter: var(--spectrum-radio-m-circle-diameter, var(--spectrum-alias-item-control-2-size-m));
  --spectrum-radio-text-gap: var(--spectrum-radio-m-text-gap, var(--spectrum-alias-item-control-gap-m));

  --spectrum-radio-radius: calc(var(--spectrum-radio-circle-diameter) / 2);
  --spectrum-radio-border-width-checked: calc(var(--spectrum-radio-circle-diameter) / 2 - var(--spectrum-radio-circle-dot-size) / 2);

  --spectrum-radio-labelbelow-label-margin: var(
      --spectrum-global-dimension-size-50
    )
    0 0 0;
  --spectrum-radio-labelbelow-height: auto;
  --spectrum-radio-label-margin-top: var(--spectrum-global-dimension-size-75);
}

.spectrum-Radio {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-align: start;
      align-items: flex-start;

  position: relative;

  min-height: var(--spectrum-radio-height);
  max-width: 100%;

  vertical-align: top;
}

.spectrum-Radio-input {
  font-family: inherit;
  font-size: 100%;
  line-height: 1.15;
  margin: 0;
  overflow: visible;
  box-sizing: border-box;
  padding: 0;

  position: absolute;
  width: 100%;
  height: 100%;

  opacity: 0.0001;
  z-index: 1;

  cursor: pointer;
}

.spectrum-Radio-input:disabled {
    cursor: default;
  }

.spectrum-Radio-input:checked + .spectrum-Radio-button:before {
      border-width: var(--spectrum-radio-border-width-checked);
    }

.spectrum-Radio-input.focus-ring + .spectrum-Radio-button:after {
        margin: calc(var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25)) * -1);
      }

[dir="ltr"] .spectrum-Radio-label {
  text-align: left;
}

[dir="rtl"] .spectrum-Radio-label {
  text-align: right;
}

[dir="ltr"] .spectrum-Radio-label {
  margin-left: var(--spectrum-radio-text-gap);
}

[dir="rtl"] .spectrum-Radio-label {
  margin-right: var(--spectrum-radio-text-gap);
}

.spectrum-Radio-label {
  margin-top: var(--spectrum-radio-label-margin-top);

  font-size: var(--spectrum-radio-text-size);
  font-weight: var(--spectrum-radio-text-font-weight);
  font-style: var(--spectrum-radio-text-font-style);
  line-height: var(--spectrum-radio-text-line-height);

  transition: color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
}

.spectrum-Radio-button {
  position: relative;
  box-sizing: border-box;
  width: var(--spectrum-radio-circle-diameter);
  height: var(--spectrum-radio-circle-diameter);
  margin: calc((var(--spectrum-radio-height) - var(--spectrum-radio-circle-diameter)) / 2)
    0;

  -ms-flex-positive: 0;

      flex-grow: 0;
  -ms-flex-negative: 0;
      flex-shrink: 0;
}

.spectrum-Radio-button:before {
    display: block;
    z-index: 0;
    content: "";
    box-sizing: border-box;
    position: absolute;

    width: var(--spectrum-radio-circle-diameter);
    height: var(--spectrum-radio-circle-diameter);

    border-radius: var(--spectrum-radio-radius);
    border-width: var(--spectrum-radio-circle-border-size);
    border-style: solid;

    transition: border var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
      box-shadow var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
  }

.spectrum-Radio-button:after {
    border-radius: 100%;
    content: "";
    display: block;
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    top: 0;
    margin: var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25));

    transition: opacity var(--spectrum-global-animation-duration-100, 130ms) ease-out,
                margin var(--spectrum-global-animation-duration-100, 130ms) ease-out;
  }

.spectrum-Radio--labelBelow {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-direction: column;
      flex-direction: column;
  -ms-flex-align: center;
      align-items: center;
  height: var(--spectrum-radio-labelbelow-height);
}

.spectrum-Radio--labelBelow .spectrum-Radio-button {
    -ms-flex-negative: 0;
        flex-shrink: 0;

    margin: 0;
  }

.spectrum-Radio--labelBelow .spectrum-Radio-label {
    margin: var(--spectrum-radio-labelbelow-label-margin);
  }

.spectrum-Radio {
  --spectrum-radio-m-emphasized-circle-border-color-selected-key-focus: var(--spectrum-radio-m-emphasized-circle-border-color-selected-hover, var(--spectrum-global-color-blue-600));
}

.spectrum-Radio-input:checked + .spectrum-Radio-button:before {
      border-color: var(--spectrum-radio-m-circle-border-color-selected, var(--spectrum-global-color-gray-700));
    }

.spectrum-Radio-label {
  color: var(--spectrum-radio-m-text-color, var(--spectrum-alias-text-color));
}

.spectrum-Radio-button:before {
    background-color: var(--spectrum-radio-m-circle-background-color, var(--spectrum-global-color-gray-75));
    border-color: var(--spectrum-radio-m-circle-border-color, var(--spectrum-global-color-gray-600));
  }

.spectrum-Radio:hover .spectrum-Radio-button:before {
        border-color: var(--spectrum-radio-m-circle-border-color-hover, var(--spectrum-global-color-gray-700));
        box-shadow: none;
      }

.spectrum-Radio:hover .spectrum-Radio-input:checked + .spectrum-Radio-button:before {
        border-color: var(--spectrum-radio-m-circle-border-color-selected-hover, var(--spectrum-global-color-gray-800));
      }

.spectrum-Radio:hover .spectrum-Radio-label {
      color: var(--spectrum-radio-m-text-color-hover, var(--spectrum-alias-text-color-hover));
    }

.spectrum-Radio:active .spectrum-Radio-button:before {
        border-color: var(--spectrum-radio-m-circle-border-color-down, var(--spectrum-global-color-gray-800));
      }

.spectrum-Radio:active .spectrum-Radio-input:checked + .spectrum-Radio-button:before {
        border-color: var(--spectrum-radio-m-circle-border-color-selected-down, var(--spectrum-global-color-gray-900));
      }

.spectrum-Radio:active .spectrum-Radio-label {
      color: var(--spectrum-radio-m-text-color-down, var(--spectrum-alias-text-color-down));
    }

.spectrum-Radio--emphasized .spectrum-Radio-input:checked + .spectrum-Radio-button:before {
      border-color: var(--spectrum-radio-m-emphasized-circle-border-color-selected, var(--spectrum-global-color-blue-500));
    }

.spectrum-Radio--emphasized:hover .spectrum-Radio-input:checked + .spectrum-Radio-button:before {
        border-color: var(--spectrum-radio-m-emphasized-circle-border-color-selected-hover, var(--spectrum-global-color-blue-600));
      }

.spectrum-Radio--emphasized:active .spectrum-Radio-input:checked + .spectrum-Radio-button:before {
        border-color: var(--spectrum-radio-m-emphasized-circle-border-color-selected-down, var(--spectrum-global-color-blue-700));
      }

.spectrum-Radio.is-invalid:hover .spectrum-Radio-input + .spectrum-Radio-button:before, .spectrum-Radio--emphasized.is-invalid:hover .spectrum-Radio-input + .spectrum-Radio-button:before {
        border-color: var(--spectrum-radio-m-emphasized-circle-border-color-error-hover, var(--spectrum-global-color-red-600));
      }

.spectrum-Radio.is-invalid:hover .spectrum-Radio-label, .spectrum-Radio--emphasized.is-invalid:hover .spectrum-Radio-label {
      color: var(--spectrum-radio-m-emphasized-text-color-error-hover, var(--spectrum-global-color-red-700));
    }

.spectrum-Radio.is-invalid:active .spectrum-Radio-input + .spectrum-Radio-button:before, .spectrum-Radio--emphasized.is-invalid:active .spectrum-Radio-input + .spectrum-Radio-button:before {
        border-color: var(--spectrum-radio-m-emphasized-circle-border-color-error-down, var(--spectrum-global-color-red-700));
      }

.spectrum-Radio.is-invalid:active .spectrum-Radio-label, .spectrum-Radio--emphasized.is-invalid:active .spectrum-Radio-label {
      color: var(--spectrum-radio-m-emphasized-text-color-error-down, var(--spectrum-global-color-red-700));
    }

.spectrum-Radio.is-invalid .spectrum-Radio-button:before, .spectrum-Radio.is-invalid .spectrum-Radio-input:checked + .spectrum-Radio-button:before, .spectrum-Radio--emphasized.is-invalid .spectrum-Radio-button:before, .spectrum-Radio--emphasized.is-invalid .spectrum-Radio-input:checked + .spectrum-Radio-button:before {
        border-color: var(--spectrum-radio-m-emphasized-circle-border-color-error, var(--spectrum-global-color-red-500));
      }

.spectrum-Radio.is-invalid .spectrum-Radio-label, .spectrum-Radio--emphasized.is-invalid .spectrum-Radio-label {
      color: var(--spectrum-radio-m-emphasized-text-color-error, var(--spectrum-global-color-red-600));
    }

.spectrum-Radio .spectrum-Radio-input:disabled + .spectrum-Radio-button:before, .spectrum-Radio .spectrum-Radio-input:checked:disabled + .spectrum-Radio-button:before {
      border-color: var(--spectrum-radio-m-emphasized-circle-border-color-disabled, var(--spectrum-global-color-gray-400));
    }

.spectrum-Radio .spectrum-Radio-input:disabled ~ .spectrum-Radio-label, .spectrum-Radio .spectrum-Radio-input:checked:disabled ~ .spectrum-Radio-label {
    color: var(--spectrum-radio-m-emphasized-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }

.spectrum-Radio .spectrum-Radio-input.focus-ring + .spectrum-Radio-button:before, .spectrum-Radio:hover .spectrum-Radio-input.focus-ring + .spectrum-Radio-button:before, .spectrum-Radio--emphasized .spectrum-Radio-input.focus-ring + .spectrum-Radio-button:before, .spectrum-Radio--emphasized:hover .spectrum-Radio-input.focus-ring + .spectrum-Radio-button:before {
        border-color: var(--spectrum-radio-m-circle-border-color-key-focus, var(--spectrum-global-color-gray-700));
      }

.spectrum-Radio .spectrum-Radio-input.focus-ring + .spectrum-Radio-button:after, .spectrum-Radio:hover .spectrum-Radio-input.focus-ring + .spectrum-Radio-button:after, .spectrum-Radio--emphasized .spectrum-Radio-input.focus-ring + .spectrum-Radio-button:after, .spectrum-Radio--emphasized:hover .spectrum-Radio-input.focus-ring + .spectrum-Radio-button:after {
        box-shadow: 0 0 0 var(--spectrum-radio-m-focus-ring-size-key-focus, var(--spectrum-alias-focus-ring-size))
          var(--spectrum-radio-m-focus-ring-color-key-focus, var(--spectrum-alias-focus-ring-color));
      }

.spectrum-Radio .spectrum-Radio-input.focus-ring:checked + .spectrum-Radio-button:before, .spectrum-Radio:hover .spectrum-Radio-input.focus-ring:checked + .spectrum-Radio-button:before, .spectrum-Radio--emphasized .spectrum-Radio-input.focus-ring:checked + .spectrum-Radio-button:before, .spectrum-Radio--emphasized:hover .spectrum-Radio-input.focus-ring:checked + .spectrum-Radio-button:before {
        border-color: var(--spectrum-radio-m-emphasized-circle-border-color-selected-key-focus, var(--spectrum-global-color-blue-600));
      }
.spectrum-Checkbox-input.svelte-hnsjoe.svelte-hnsjoe{opacity:0}.readonly.svelte-hnsjoe.svelte-hnsjoe{pointer-events:none}.icon.svelte-hnsjoe.svelte-hnsjoe{display:none;left:50%;top:50%;position:absolute;transform:translate(-50%, -50%)}.icon.checked.svelte-hnsjoe.svelte-hnsjoe{display:block}.icon.svelte-hnsjoe i{font-size:14px}.select-all-checkbox.svelte-hnsjoe.svelte-hnsjoe{margin-bottom:8px;padding:0}.select-all-checkbox.svelte-hnsjoe .spectrum-Checkbox.svelte-hnsjoe{padding:0}.select-all-checkbox.svelte-hnsjoe .spectrum-Checkbox-input.svelte-hnsjoe{margin:0}.spectrum-FieldGroup.svelte-hnsjoe .select-all-checkbox.svelte-hnsjoe,.spectrum-FieldGroup.svelte-hnsjoe .select-all-checkbox.svelte-hnsjoe:hover,.spectrum-FieldGroup.svelte-hnsjoe .select-all-checkbox.svelte-hnsjoe:focus-within,.spectrum-FieldGroup.svelte-hnsjoe .select-all-checkbox .spectrum-Checkbox.svelte-hnsjoe,.spectrum-FieldGroup.svelte-hnsjoe .select-all-checkbox label.svelte-hnsjoe{background:none !important}.field.svelte-tf9ino{display:flex;gap:var(--spacing-m)}.file-view.svelte-tf9ino{display:flex;gap:var(--spacing-l);align-items:center;border:1px solid var(--spectrum-alias-border-color);border-radius:var(--spectrum-global-dimension-size-50);padding:0px var(--spectrum-alias-item-padding-m)}.file-view.disabled.svelte-tf9ino{color:var(--spectrum-alias-text-color-disabled)}.file-view.status.svelte-tf9ino{background-color:var(--spectrum-global-color-gray-100)}input[type="file"].svelte-tf9ino{display:none}.delete-button.svelte-tf9ino{transition:all 0.3s;margin-left:10px;display:flex}.delete-button.svelte-tf9ino:hover{cursor:pointer;color:var(--red)}.filesize.svelte-tf9ino{white-space:nowrap}.filename.svelte-tf9ino{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.preview.svelte-tf9ino{height:1.5em}.spectrum-Radio-input.svelte-ylb1af{opacity:0}.readonly.svelte-ylb1af{pointer-events:none}/**
 * easymde v2.20.0
 * Copyright Jeroen Akkerman
 * @link https://github.com/ionaru/easy-markdown-editor
 * @license MIT
 */
.CodeMirror{font-family:monospace;height:300px;color:#000;direction:ltr}.CodeMirror-lines{padding:4px 0}.CodeMirror pre.CodeMirror-line,.CodeMirror pre.CodeMirror-line-like{padding:0 4px}.CodeMirror-gutter-filler,.CodeMirror-scrollbar-filler{background-color:#fff}.CodeMirror-gutters{border-right:1px solid #ddd;background-color:#f7f7f7;white-space:nowrap}.CodeMirror-linenumber{padding:0 3px 0 5px;min-width:20px;text-align:right;color:#999;white-space:nowrap}.CodeMirror-guttermarker{color:#000}.CodeMirror-guttermarker-subtle{color:#999}.CodeMirror-cursor{border-left:1px solid #000;border-right:none;width:0}.CodeMirror div.CodeMirror-secondarycursor{border-left:1px solid silver}.cm-fat-cursor .CodeMirror-cursor{width:auto;border:0!important;background:#7e7}.cm-fat-cursor div.CodeMirror-cursors{z-index:1}.cm-fat-cursor .CodeMirror-line::selection,.cm-fat-cursor .CodeMirror-line>span::selection,.cm-fat-cursor .CodeMirror-line>span>span::selection{background:0 0}.cm-fat-cursor .CodeMirror-line::-moz-selection,.cm-fat-cursor .CodeMirror-line>span::-moz-selection,.cm-fat-cursor .CodeMirror-line>span>span::-moz-selection{background:0 0}.cm-fat-cursor{caret-color:transparent}@-moz-keyframes blink{50%{background-color:transparent}}@-webkit-keyframes blink{50%{background-color:transparent}}@keyframes blink{50%{background-color:transparent}}.cm-tab{display:inline-block;text-decoration:inherit}.CodeMirror-rulers{position:absolute;left:0;right:0;top:-50px;bottom:0;overflow:hidden}.CodeMirror-ruler{border-left:1px solid #ccc;top:0;bottom:0;position:absolute}.cm-s-default .cm-header{color:#00f}.cm-s-default .cm-quote{color:#090}.cm-negative{color:#d44}.cm-positive{color:#292}.cm-header,.cm-strong{font-weight:700}.cm-em{font-style:italic}.cm-link{text-decoration:underline}.cm-strikethrough{text-decoration:line-through}.cm-s-default .cm-keyword{color:#708}.cm-s-default .cm-atom{color:#219}.cm-s-default .cm-number{color:#164}.cm-s-default .cm-def{color:#00f}.cm-s-default .cm-variable-2{color:#05a}.cm-s-default .cm-type,.cm-s-default .cm-variable-3{color:#085}.cm-s-default .cm-comment{color:#a50}.cm-s-default .cm-string{color:#a11}.cm-s-default .cm-string-2{color:#f50}.cm-s-default .cm-meta{color:#555}.cm-s-default .cm-qualifier{color:#555}.cm-s-default .cm-builtin{color:#30a}.cm-s-default .cm-bracket{color:#997}.cm-s-default .cm-tag{color:#170}.cm-s-default .cm-attribute{color:#00c}.cm-s-default .cm-hr{color:#999}.cm-s-default .cm-link{color:#00c}.cm-s-default .cm-error{color:red}.cm-invalidchar{color:red}.CodeMirror-composing{border-bottom:2px solid}div.CodeMirror span.CodeMirror-matchingbracket{color:#0b0}div.CodeMirror span.CodeMirror-nonmatchingbracket{color:#a22}.CodeMirror-matchingtag{background:rgba(255,150,0,.3)}.CodeMirror-activeline-background{background:#e8f2ff}.CodeMirror{position:relative;overflow:hidden;background:#fff}.CodeMirror-scroll{overflow:scroll!important;margin-bottom:-50px;margin-right:-50px;padding-bottom:50px;height:100%;outline:0;position:relative;z-index:0}.CodeMirror-sizer{position:relative;border-right:50px solid transparent}.CodeMirror-gutter-filler,.CodeMirror-hscrollbar,.CodeMirror-scrollbar-filler,.CodeMirror-vscrollbar{position:absolute;z-index:6;display:none;outline:0}.CodeMirror-vscrollbar{right:0;top:0;overflow-x:hidden;overflow-y:scroll}.CodeMirror-hscrollbar{bottom:0;left:0;overflow-y:hidden;overflow-x:scroll}.CodeMirror-scrollbar-filler{right:0;bottom:0}.CodeMirror-gutter-filler{left:0;bottom:0}.CodeMirror-gutters{position:absolute;left:0;top:0;min-height:100%;z-index:3}.CodeMirror-gutter{white-space:normal;height:100%;display:inline-block;vertical-align:top;margin-bottom:-50px}.CodeMirror-gutter-wrapper{position:absolute;z-index:4;background:0 0!important;border:none!important}.CodeMirror-gutter-background{position:absolute;top:0;bottom:0;z-index:4}.CodeMirror-gutter-elt{position:absolute;cursor:default;z-index:4}.CodeMirror-gutter-wrapper ::selection{background-color:transparent}.CodeMirror-gutter-wrapper ::-moz-selection{background-color:transparent}.CodeMirror-lines{cursor:text;min-height:1px}.CodeMirror pre.CodeMirror-line,.CodeMirror pre.CodeMirror-line-like{-moz-border-radius:0;-webkit-border-radius:0;border-radius:0;border-width:0;background:0 0;font-family:inherit;font-size:inherit;margin:0;white-space:pre;word-wrap:normal;line-height:inherit;color:inherit;z-index:2;position:relative;overflow:visible;-webkit-tap-highlight-color:transparent;-webkit-font-variant-ligatures:contextual;font-variant-ligatures:contextual}.CodeMirror-wrap pre.CodeMirror-line,.CodeMirror-wrap pre.CodeMirror-line-like{word-wrap:break-word;white-space:pre-wrap;word-break:normal}.CodeMirror-linebackground{position:absolute;left:0;right:0;top:0;bottom:0;z-index:0}.CodeMirror-linewidget{position:relative;z-index:2;padding:.1px}.CodeMirror-rtl pre{direction:rtl}.CodeMirror-code{outline:0}.CodeMirror-gutter,.CodeMirror-gutters,.CodeMirror-linenumber,.CodeMirror-scroll,.CodeMirror-sizer{-moz-box-sizing:content-box;box-sizing:content-box}.CodeMirror-measure{position:absolute;width:100%;height:0;overflow:hidden;visibility:hidden}.CodeMirror-cursor{position:absolute;pointer-events:none}.CodeMirror-measure pre{position:static}div.CodeMirror-cursors{visibility:hidden;position:relative;z-index:3}div.CodeMirror-dragcursors{visibility:visible}.CodeMirror-focused div.CodeMirror-cursors{visibility:visible}.CodeMirror-selected{background:#d9d9d9}.CodeMirror-focused .CodeMirror-selected{background:#d7d4f0}.CodeMirror-crosshair{cursor:crosshair}.CodeMirror-line::selection,.CodeMirror-line>span::selection,.CodeMirror-line>span>span::selection{background:#d7d4f0}.CodeMirror-line::-moz-selection,.CodeMirror-line>span::-moz-selection,.CodeMirror-line>span>span::-moz-selection{background:#d7d4f0}.cm-searching{background-color:#ffa;background-color:rgba(255,255,0,.4)}.cm-force-border{padding-right:.1px}@media print{.CodeMirror div.CodeMirror-cursors{visibility:hidden}}.cm-tab-wrap-hack:after{content:''}span.CodeMirror-selectedtext{background:0 0}.EasyMDEContainer{display:block}.CodeMirror-rtl pre{direction:rtl}.EasyMDEContainer.sided--no-fullscreen{display:flex;flex-direction:row;flex-wrap:wrap}.EasyMDEContainer .CodeMirror{box-sizing:border-box;height:auto;border:1px solid #ced4da;border-bottom-left-radius:4px;border-bottom-right-radius:4px;padding:10px;font:inherit;z-index:0;word-wrap:break-word}.EasyMDEContainer .CodeMirror-scroll{cursor:text}.EasyMDEContainer .CodeMirror-fullscreen{background:#fff;position:fixed!important;top:50px;left:0;right:0;bottom:0;height:auto;z-index:8;border-right:none!important;border-bottom-right-radius:0!important}.EasyMDEContainer .CodeMirror-sided{width:50%!important}.EasyMDEContainer.sided--no-fullscreen .CodeMirror-sided{border-right:none!important;border-bottom-right-radius:0;position:relative;flex:1 1 auto}.EasyMDEContainer .CodeMirror-placeholder{opacity:.5}.EasyMDEContainer .CodeMirror-focused .CodeMirror-selected{background:#d9d9d9}.editor-toolbar{position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;-o-user-select:none;user-select:none;padding:9px 10px;border-top:1px solid #ced4da;border-left:1px solid #ced4da;border-right:1px solid #ced4da;border-top-left-radius:4px;border-top-right-radius:4px}.editor-toolbar.fullscreen{width:100%;height:50px;padding-top:10px;padding-bottom:10px;box-sizing:border-box;background:#fff;border:0;position:fixed;top:0;left:0;opacity:1;z-index:9}.editor-toolbar.fullscreen::before{width:20px;height:50px;background:-moz-linear-gradient(left,#fff 0,rgba(255,255,255,0) 100%);background:-webkit-gradient(linear,left top,right top,color-stop(0,#fff),color-stop(100%,rgba(255,255,255,0)));background:-webkit-linear-gradient(left,#fff 0,rgba(255,255,255,0) 100%);background:-o-linear-gradient(left,#fff 0,rgba(255,255,255,0) 100%);background:-ms-linear-gradient(left,#fff 0,rgba(255,255,255,0) 100%);background:linear-gradient(to right,#fff 0,rgba(255,255,255,0) 100%);position:fixed;top:0;left:0;margin:0;padding:0}.editor-toolbar.fullscreen::after{width:20px;height:50px;background:-moz-linear-gradient(left,rgba(255,255,255,0) 0,#fff 100%);background:-webkit-gradient(linear,left top,right top,color-stop(0,rgba(255,255,255,0)),color-stop(100%,#fff));background:-webkit-linear-gradient(left,rgba(255,255,255,0) 0,#fff 100%);background:-o-linear-gradient(left,rgba(255,255,255,0) 0,#fff 100%);background:-ms-linear-gradient(left,rgba(255,255,255,0) 0,#fff 100%);background:linear-gradient(to right,rgba(255,255,255,0) 0,#fff 100%);position:fixed;top:0;right:0;margin:0;padding:0}.EasyMDEContainer.sided--no-fullscreen .editor-toolbar{width:100%}.editor-toolbar .easymde-dropdown,.editor-toolbar button{background:0 0;display:inline-block;text-align:center;text-decoration:none!important;height:30px;margin:0;padding:0;border:1px solid transparent;border-radius:3px;cursor:pointer}.editor-toolbar button{font-weight:700;min-width:30px;padding:0 6px;white-space:nowrap}.editor-toolbar button.active,.editor-toolbar button:hover{background:#fcfcfc;border-color:#95a5a6}.editor-toolbar i.separator{display:inline-block;width:0;border-left:1px solid #d9d9d9;border-right:1px solid #fff;color:transparent;text-indent:-10px;margin:0 6px}.editor-toolbar button:after{font-family:Arial,"Helvetica Neue",Helvetica,sans-serif;font-size:65%;vertical-align:text-bottom;position:relative;top:2px}.editor-toolbar button.heading-1:after{content:"1"}.editor-toolbar button.heading-2:after{content:"2"}.editor-toolbar button.heading-3:after{content:"3"}.editor-toolbar button.heading-bigger:after{content:"▲"}.editor-toolbar button.heading-smaller:after{content:"▼"}.editor-toolbar.disabled-for-preview button:not(.no-disable){opacity:.6;pointer-events:none}@media only screen and (max-width:700px){.editor-toolbar i.no-mobile{display:none}}.editor-statusbar{padding:8px 10px;font-size:12px;color:#959694;text-align:right}.EasyMDEContainer.sided--no-fullscreen .editor-statusbar{width:100%}.editor-statusbar span{display:inline-block;min-width:4em;margin-left:1em}.editor-statusbar .lines:before{content:'lines: '}.editor-statusbar .words:before{content:'words: '}.editor-statusbar .characters:before{content:'characters: '}.editor-preview-full{position:absolute;width:100%;height:100%;top:0;left:0;z-index:7;overflow:auto;display:none;box-sizing:border-box}.editor-preview-side{position:fixed;bottom:0;width:50%;top:50px;right:0;z-index:9;overflow:auto;display:none;box-sizing:border-box;border:1px solid #ddd;word-wrap:break-word}.editor-preview-active-side{display:block}.EasyMDEContainer.sided--no-fullscreen .editor-preview-active-side{flex:1 1 auto;height:auto;position:static}.editor-preview-active{display:block}.editor-preview{padding:10px;background:#fafafa}.editor-preview>p{margin-top:0}.editor-preview pre{background:#eee;margin-bottom:10px}.editor-preview table td,.editor-preview table th{border:1px solid #ddd;padding:5px}.cm-s-easymde .cm-tag{color:#63a35c}.cm-s-easymde .cm-attribute{color:#795da3}.cm-s-easymde .cm-string{color:#183691}.cm-s-easymde .cm-header-1{font-size:calc(1.375rem + 1.5vw)}.cm-s-easymde .cm-header-2{font-size:calc(1.325rem + .9vw)}.cm-s-easymde .cm-header-3{font-size:calc(1.3rem + .6vw)}.cm-s-easymde .cm-header-4{font-size:calc(1.275rem + .3vw)}.cm-s-easymde .cm-header-5{font-size:1.25rem}.cm-s-easymde .cm-header-6{font-size:1rem}.cm-s-easymde .cm-header-1,.cm-s-easymde .cm-header-2,.cm-s-easymde .cm-header-3,.cm-s-easymde .cm-header-4,.cm-s-easymde .cm-header-5,.cm-s-easymde .cm-header-6{margin-bottom:.5rem;line-height:1.2}.cm-s-easymde .cm-comment{background:rgba(0,0,0,.05);border-radius:2px}.cm-s-easymde .cm-link{color:#7f8c8d}.cm-s-easymde .cm-url{color:#aab2b3}.cm-s-easymde .cm-quote{color:#7f8c8d;font-style:italic}.editor-toolbar .easymde-dropdown{position:relative;background:linear-gradient(to bottom right,#fff 0,#fff 84%,#333 50%,#333 100%);border-radius:0;border:1px solid #fff}.editor-toolbar .easymde-dropdown:hover{background:linear-gradient(to bottom right,#fff 0,#fff 84%,#333 50%,#333 100%)}.easymde-dropdown-content{display:block;visibility:hidden;position:absolute;background-color:#f9f9f9;box-shadow:0 8px 16px 0 rgba(0,0,0,.2);padding:8px;z-index:2;top:30px}.easymde-dropdown:active .easymde-dropdown-content,.easymde-dropdown:focus .easymde-dropdown-content,.easymde-dropdown:focus-within .easymde-dropdown-content{visibility:visible}.easymde-dropdown-content button{display:block}span[data-img-src]::after{content:'';background-image:var(--bg-image);display:block;max-height:100%;max-width:100%;background-size:contain;height:0;padding-top:var(--height);width:var(--width);background-repeat:no-repeat}.CodeMirror .cm-spell-error:not(.cm-url):not(.cm-comment):not(.cm-tag):not(.cm-word){background:rgba(255,0,0,.15)}.disabled.svelte-1888jbe textarea{display:none}.disabled.svelte-1888jbe .CodeMirror-cursor{display:none}.disabled.svelte-1888jbe .EasyMDEContainer{pointer-events:none}.disabled.svelte-1888jbe .editor-toolbar button i{color:var(--spectrum-global-color-gray-400)}.disabled.svelte-1888jbe .CodeMirror{color:var(--spectrum-global-color-gray-600)}.EasyMDEContainer .editor-toolbar{background:var(--spectrum-global-color-gray-50);border-top:1px solid var(--spectrum-alias-border-color);border-left:1px solid var(--spectrum-alias-border-color);border-right:1px solid var(--spectrum-alias-border-color)}.EasyMDEContainer .CodeMirror{border:1px solid var(--spectrum-alias-border-color);background:var(--spectrum-global-color-gray-50);color:var(--spectrum-alias-text-color)}.EasyMDEContainer .editor-toolbar button.active{background:var(--spectrum-global-color-gray-200);border-color:var(--spectrum-global-color-gray-400)}.EasyMDEContainer .editor-toolbar button:hover{background:var(--spectrum-global-color-gray-200);border-color:var(--spectrum-global-color-gray-400)}.EasyMDEContainer .editor-toolbar button{color:var(--spectrum-global-color-gray-800)}.EasyMDEContainer .editor-toolbar i.separator{border-color:var(--spectrum-global-color-gray-300)}.EasyMDEContainer .CodeMirror-cursor{border-color:var(--spectrum-alias-text-color)}.EasyMDEContainer .CodeMirror-selectedtext{background:var(--spectrum-global-color-gray-400) !important}.EasyMDEContainer .CodeMirror-selected{background:var(--spectrum-global-color-gray-400) !important}.EasyMDEContainer .cm-s-easymde .cm-link{color:var(--spectrum-global-color-gray-600)}.EasyMDEContainer .cm-s-easymde .cm-url{color:var(--spectrum-global-color-gray-500)}.EasyMDEContainer .editor-preview{background:var(--spectrum-global-color-gray-50)}.EasyMDEContainer .editor-preview{border:1px solid var(--spectrum-alias-border-color)}.EasyMDEContainer .cm-s-easymde .cm-comment{background:var(--spectrum-global-color-gray-100)}.EasyMDEContainer pre{background:var(--spectrum-global-color-gray-100);padding:4px;border-radius:4px}.EasyMDEContainer code{color:#e83e8c}.EasyMDEContainer pre code{color:var(--spectrum-alias-text-color)}.EasyMDEContainer blockquote{border-left:4px solid var(--spectrum-global-color-gray-400);color:var(--spectrum-global-color-gray-700);margin-left:0;padding-left:20px}.EasyMDEContainer hr{background-color:var(--spectrum-global-color-gray-300);border:none;height:2px}.EasyMDEContainer td, .EasyMDEContainer th{border-color:var(--spectrum-alias-border-color) !important}.EasyMDEContainer a{color:var(--primaryColor)}.EasyMDEContainer a:hover{color:var(--primaryColorHover)}.EasyMDEContainer .editor-toolbar.fullscreen{left:var(--fullscreen-offset-x);top:var(--fullscreen-offset-y)}.EasyMDEContainer .CodeMirror-fullscreen{left:var(--fullscreen-offset-x);top:calc(50px + var(--fullscreen-offset-y))}.EasyMDEContainer .CodeMirror-fullscreen.CodeMirror-sided{width:calc((100% - var(--fullscreen-offset-x)) / 2) !important}.EasyMDEContainer .editor-preview-side{left:calc(50% + (var(--fullscreen-offset-x) / 2));top:calc(50px + var(--fullscreen-offset-y));width:calc((100% - var(--fullscreen-offset-x)) / 2) !important}.indicator-overlay.svelte-jdhkye.svelte-jdhkye{position:absolute;width:100%;height:100%;top:0px;display:flex;flex-direction:column;justify-content:end;padding:var(--spectrum-global-dimension-size-150);box-sizing:border-box;pointer-events:none}.sign-here.svelte-jdhkye.svelte-jdhkye{display:flex;align-items:center;justify-content:center;gap:var(--spectrum-global-dimension-size-150)}.sign-here.svelte-jdhkye hr.svelte-jdhkye{border:0;border-top:2px solid var(--spectrum-global-color-gray-200);width:100%}.canvas-wrap.svelte-jdhkye.svelte-jdhkye{position:relative;margin:auto}.signature.svelte-jdhkye img.svelte-jdhkye{max-width:100%}#signature-canvas.svelte-jdhkye.svelte-jdhkye{max-width:var(--max-sig-width);max-height:var(--max-sig-height)}.signature.light.svelte-jdhkye img.svelte-jdhkye,.signature.light.svelte-jdhkye #signature-canvas.svelte-jdhkye{-webkit-filter:invert(100%);filter:invert(100%)}.signature.image-error.svelte-jdhkye .overlay.svelte-jdhkye{padding-top:0px}.signature.svelte-jdhkye.svelte-jdhkye{width:100%;height:100%;position:relative;text-align:center}.overlay.svelte-jdhkye.svelte-jdhkye{position:absolute;width:100%;height:100%;pointer-events:none;padding:var(--spectrum-global-dimension-size-150);text-align:right;z-index:2;box-sizing:border-box}.save.svelte-jdhkye.svelte-jdhkye,.delete.svelte-jdhkye.svelte-jdhkye{display:inline-block}.spectrum-Slider {
  --spectrum-slider-handle-border-size: var(--spectrum-slider-m-handle-border-size, var(--spectrum-alias-border-size-thick));
  --spectrum-slider-handle-border-size-down: var(--spectrum-slider-m-handle-border-size-down, var(--spectrum-global-dimension-size-75));
  --spectrum-slider-track-border-radius: var(--spectrum-slider-m-track-border-radius, var(--spectrum-global-dimension-static-size-10));
  --spectrum-slider-track-height: var(--spectrum-slider-m-track-height, var(--spectrum-alias-border-size-thick));
  --spectrum-slider-handle-gap: var(--spectrum-slider-m-handle-gap, var(--spectrum-alias-border-size-thicker));
  --spectrum-slider-animation-duration: var(--spectrum-slider-m-animation-duration, var(--spectrum-global-animation-duration-100));
  --spectrum-slider-height: var(--spectrum-slider-m-height, var(--spectrum-alias-item-height-m));
  --spectrum-slider-min-width: var(--spectrum-slider-m-min-width, var(--spectrum-global-dimension-size-1250));
  --spectrum-slider-handle-width: var(--spectrum-slider-m-handle-width, var(--spectrum-alias-item-control-2-size-l));
  --spectrum-slider-handle-height: var(--spectrum-slider-m-handle-height, var(--spectrum-alias-item-control-2-size-l));
  --spectrum-slider-handle-border-radius: var(--spectrum-slider-m-handle-border-radius, var(--spectrum-global-dimension-size-100));
  --spectrum-slider-label-gap-x: var(--spectrum-slider-m-label-gap-x, var(--spectrum-alias-item-control-gap-m));
  --spectrum-slider-tick-mark-width: var(--spectrum-slider-tick-m-mark-width, var(--spectrum-alias-border-size-thick));
  --spectrum-slider-tick-mark-border-radius: var(--spectrum-slider-tick-m-mark-border-radius, var(--spectrum-alias-border-radius-xsmall));
  --spectrum-slider-tick-mark-height: var(--spectrum-slider-tick-m-mark-height, var(--spectrum-global-dimension-size-125));
  --spectrum-slider-label-gap-y: var(--spectrum-global-dimension-size-85);

  --spectrum-slider-controls-margin: calc(var(--spectrum-slider-handle-width) / 2);
  --spectrum-slider-track-margin-offset: calc(var(--spectrum-slider-controls-margin) * -1);

  --spectrum-slider-handle-margin-top: calc(var(--spectrum-slider-handle-width) / -2);
  --spectrum-slider-handle-margin-left: calc(var(--spectrum-slider-handle-width) / -2);

  --spectrum-slider-track-handleoffset: var(--spectrum-slider-handle-gap);
  --spectrum-slider-track-middle-handleoffset: calc(var(--spectrum-slider-handle-gap) + var(--spectrum-slider-handle-width) / 2);

  --spectrum-slider-input-top: calc(var(--spectrum-slider-handle-margin-top) / 4);
  --spectrum-slider-input-left: calc(var(--spectrum-slider-handle-margin-left) / 4);

  --spectrum-slider-ramp-margin-top: 0;
  --spectrum-slider-range-track-reset: 0;
  --spectrum-slide-label-text-size: var(--spectrum-global-dimension-font-size-75);
  --spectrum-slide-label-text-line-height: var(--spectrum-global-font-line-height-small, 1.3);
}

.spectrum-Slider {
  position: relative;
  z-index: 1;
  display: block;
  min-height: var(--spectrum-slider-height);
  min-width: var(--spectrum-slider-min-width);

  -webkit-user-select: none;

     -moz-user-select: none;

      -ms-user-select: none;

          user-select: none;
}

[dir="ltr"] .spectrum-Slider-controls {
  margin-left: var(--spectrum-slider-controls-margin);
}

[dir="rtl"] .spectrum-Slider-controls {
  margin-right: var(--spectrum-slider-controls-margin);
}

.spectrum-Slider-controls {
  display: inline-block;
  box-sizing: border-box;

  position: relative;
  z-index: auto;
  width: calc(100% - var(--spectrum-slider-controls-margin) * 2);
  min-height: var(--spectrum-slider-height);

  vertical-align: top;
}

[dir="ltr"] .spectrum-Slider-track,[dir="ltr"] 
.spectrum-Slider-fill {
  left: 0;
}

[dir="rtl"] .spectrum-Slider-track,[dir="rtl"] 
.spectrum-Slider-fill {
  right: 0;
}

[dir="ltr"] .spectrum-Slider-track,[dir="ltr"] 
.spectrum-Slider-fill {
  right: auto;
}

[dir="rtl"] .spectrum-Slider-track,[dir="rtl"] 
.spectrum-Slider-fill {
  left: auto;
}

.spectrum-Slider-track,
.spectrum-Slider-fill {
  height: var(--spectrum-slider-track-height);
  box-sizing: border-box;

  position: absolute;
  z-index: 1;
  top: calc(var(--spectrum-slider-height) / 2);

  margin-top: calc(var(--spectrum-slider-track-height) / -2);

  pointer-events: none;
}

[dir="ltr"] .spectrum-Slider-track,[dir="ltr"] 
.spectrum-Slider-fill {
  padding-left: 0;
  padding-right: var(--spectrum-slider-track-handleoffset);
}

[dir="rtl"] .spectrum-Slider-track,[dir="rtl"] 
.spectrum-Slider-fill {
  padding-right: 0;
  padding-left: var(--spectrum-slider-track-handleoffset);
}

[dir="ltr"] .spectrum-Slider-track,[dir="ltr"] 
.spectrum-Slider-fill {
  margin-left: var(--spectrum-slider-track-margin-offset);
}

[dir="rtl"] .spectrum-Slider-track,[dir="rtl"] 
.spectrum-Slider-fill {
  margin-right: var(--spectrum-slider-track-margin-offset);
}

.spectrum-Slider-track,
.spectrum-Slider-fill {
  padding-top: 0;
  padding-bottom: 0;
}

.spectrum-Slider-track::before, .spectrum-Slider-fill::before {
    content: "";
    display: block;
    height: 100%;

    border-radius: var(--spectrum-slider-track-border-radius);
  }

[dir="ltr"] .spectrum-Slider-fill {
  margin-left: 0;
}

[dir="rtl"] .spectrum-Slider-fill {
  margin-right: 0;
}

[dir="ltr"] .spectrum-Slider-fill {
  padding-left: calc(var(--spectrum-slider-controls-margin) + var(--spectrum-slider-track-handleoffset));
  padding-right: 0;
}

[dir="rtl"] .spectrum-Slider-fill {
  padding-right: calc(var(--spectrum-slider-controls-margin) + var(--spectrum-slider-track-handleoffset));
  padding-left: 0;
}

.spectrum-Slider-fill {
  padding-top: 0;
  padding-bottom: 0;
}

[dir="ltr"] .spectrum-Slider-fill--right {
  padding-left: 0;
  padding-right: calc(var(--spectrum-slider-controls-margin) + var(--spectrum-slider-track-handleoffset));
}

[dir="rtl"] .spectrum-Slider-fill--right {
  padding-right: 0;
  padding-left: calc(var(--spectrum-slider-controls-margin) + var(--spectrum-slider-track-handleoffset));
}

.spectrum-Slider-fill--right {
  padding-top: 0;
  padding-bottom: 0;
}

[dir="ltr"] .spectrum-Slider-track ~ .spectrum-Slider-track {
  left: auto;
}

[dir="rtl"] .spectrum-Slider-track ~ .spectrum-Slider-track {
  right: auto;
}

[dir="ltr"] .spectrum-Slider-track ~ .spectrum-Slider-track {
  right: var(--spectrum-slider-range-track-reset);
}

[dir="rtl"] .spectrum-Slider-track ~ .spectrum-Slider-track {
  left: var(--spectrum-slider-range-track-reset);
}

[dir="ltr"] .spectrum-Slider-track ~ .spectrum-Slider-track {
  padding-left: var(--spectrum-slider-track-handleoffset);
  padding-right: 0;
}

[dir="rtl"] .spectrum-Slider-track ~ .spectrum-Slider-track {
  padding-right: var(--spectrum-slider-track-handleoffset);
  padding-left: 0;
}

[dir="ltr"] .spectrum-Slider-track ~ .spectrum-Slider-track {
  margin-left: var(--spectrum-slider-range-track-reset);
}

[dir="rtl"] .spectrum-Slider-track ~ .spectrum-Slider-track {
  margin-right: var(--spectrum-slider-range-track-reset);
}

[dir="ltr"] .spectrum-Slider-track ~ .spectrum-Slider-track {
  margin-right: var(--spectrum-slider-track-margin-offset);
}

[dir="rtl"] .spectrum-Slider-track ~ .spectrum-Slider-track {
  margin-left: var(--spectrum-slider-track-margin-offset);
}

.spectrum-Slider-track ~ .spectrum-Slider-track {
  padding-top: 0;
  padding-bottom: 0;
}

.spectrum-Slider--range .spectrum-Slider-value {
    -webkit-user-select: text;
       -moz-user-select: text;
        -ms-user-select: text;
            user-select: text;
  }

[dir="ltr"] .spectrum-Slider--range .spectrum-Slider-track:first-of-type {
      padding-left: 0;
      padding-right: var(--spectrum-slider-track-handleoffset);
}

[dir="rtl"] .spectrum-Slider--range .spectrum-Slider-track:first-of-type {
      padding-right: 0;
      padding-left: var(--spectrum-slider-track-handleoffset);
}

[dir="ltr"] .spectrum-Slider--range .spectrum-Slider-track:first-of-type {
      left: var(--spectrum-slider-range-track-reset);
}

[dir="rtl"] .spectrum-Slider--range .spectrum-Slider-track:first-of-type {
      right: var(--spectrum-slider-range-track-reset);
}

[dir="ltr"] .spectrum-Slider--range .spectrum-Slider-track:first-of-type {
      right: auto;
}

[dir="rtl"] .spectrum-Slider--range .spectrum-Slider-track:first-of-type {
      left: auto;
}

[dir="ltr"] .spectrum-Slider--range .spectrum-Slider-track:first-of-type {
      margin-left: var(--spectrum-slider-track-margin-offset);
}

[dir="rtl"] .spectrum-Slider--range .spectrum-Slider-track:first-of-type {
      margin-right: var(--spectrum-slider-track-margin-offset);
}

.spectrum-Slider--range .spectrum-Slider-track:first-of-type {
      padding-top: 0;
      padding-bottom: 0;
    }

[dir="ltr"] [dir="ltr"] .spectrum-Slider--range .spectrum-Slider-track,[dir="ltr"] [dir="rtl"] 
    .spectrum-Slider--range .spectrum-Slider-track {
      left: auto;
}

[dir="rtl"] [dir="ltr"] .spectrum-Slider--range .spectrum-Slider-track,[dir="rtl"] [dir="rtl"] 
    .spectrum-Slider--range .spectrum-Slider-track {
      right: auto;
}

[dir="ltr"] [dir="ltr"] .spectrum-Slider--range .spectrum-Slider-track,[dir="ltr"] [dir="rtl"] 
    .spectrum-Slider--range .spectrum-Slider-track {
      right: auto;
}

[dir="rtl"] [dir="ltr"] .spectrum-Slider--range .spectrum-Slider-track,[dir="rtl"] [dir="rtl"] 
    .spectrum-Slider--range .spectrum-Slider-track {
      left: auto;
}

[dir="ltr"] .spectrum-Slider--range .spectrum-Slider-track,[dir="rtl"] 
    .spectrum-Slider--range .spectrum-Slider-track {
      padding-top: 0;
      padding-bottom: 0;
      padding-left: var(--spectrum-slider-track-middle-handleoffset);
      padding-right: var(--spectrum-slider-track-middle-handleoffset);
      margin-left: var(--spectrum-slider-range-track-reset);
      margin-right: var(--spectrum-slider-range-track-reset);
      margin-top: var(--spectrum-slider-range-track-reset);
      margin-bottom: var(--spectrum-slider-range-track-reset);
    }

[dir="ltr"] .spectrum-Slider--range .spectrum-Slider-track:last-of-type {
      padding-left: var(--spectrum-slider-track-handleoffset);
      padding-right: 0;
}

[dir="rtl"] .spectrum-Slider--range .spectrum-Slider-track:last-of-type {
      padding-right: var(--spectrum-slider-track-handleoffset);
      padding-left: 0;
}

[dir="ltr"] .spectrum-Slider--range .spectrum-Slider-track:last-of-type {
      left: auto;
}

[dir="rtl"] .spectrum-Slider--range .spectrum-Slider-track:last-of-type {
      right: auto;
}

[dir="ltr"] .spectrum-Slider--range .spectrum-Slider-track:last-of-type {
      right: var(--spectrum-slider-range-track-reset);
}

[dir="rtl"] .spectrum-Slider--range .spectrum-Slider-track:last-of-type {
      left: var(--spectrum-slider-range-track-reset);
}

[dir="ltr"] .spectrum-Slider--range .spectrum-Slider-track:last-of-type {
      margin-right: var(--spectrum-slider-track-margin-offset);
}

[dir="rtl"] .spectrum-Slider--range .spectrum-Slider-track:last-of-type {
      margin-left: var(--spectrum-slider-track-margin-offset);
}

.spectrum-Slider--range .spectrum-Slider-track:last-of-type {
      padding-top: 0;
      padding-bottom: 0;
    }

[dir="ltr"] .spectrum-Slider-ramp {
  left: var(--spectrum-slider-track-margin-offset);
}

[dir="rtl"] .spectrum-Slider-ramp {
  right: var(--spectrum-slider-track-margin-offset);
}

[dir="ltr"] .spectrum-Slider-ramp {
  right: var(--spectrum-slider-track-margin-offset);
}

[dir="rtl"] .spectrum-Slider-ramp {
  left: var(--spectrum-slider-track-margin-offset);
}

.spectrum-Slider-ramp {
  margin-top: var(--spectrum-slider-ramp-margin-top);
  height: var(--spectrum-slider-ramp-track-height, var(--spectrum-global-dimension-static-size-200));

  position: absolute;
  top: calc(var(--spectrum-slider-ramp-track-height, var(--spectrum-global-dimension-static-size-200)) / 2);
}

[dir="rtl"] .spectrum-Slider-ramp svg { transform: matrix(-1, 0, 0, 1, 0, 0) ; }

.spectrum-Slider-ramp svg {
    width: 100%;
    height: 100%;
  }

[dir="ltr"] .spectrum-Slider-handle {
  left: 0;
}

[dir="rtl"] .spectrum-Slider-handle {
  right: 0;
}

[dir="ltr"] .spectrum-Slider-handle {
  margin-left: calc(var(--spectrum-slider-handle-width) / -2);
  margin-right: 0;
}

[dir="rtl"] .spectrum-Slider-handle {
  margin-right: calc(var(--spectrum-slider-handle-width) / -2);
  margin-left: 0;
}

.spectrum-Slider-handle {
  position: absolute;
  top: calc(var(--spectrum-slider-height) / 2);
  z-index: 2;

  display: inline-block;
  box-sizing: border-box;

  width: var(--spectrum-slider-handle-width);
  height: var(--spectrum-slider-handle-height);

  margin-top: var(--spectrum-slider-handle-margin-top);

  margin-bottom: 0;

  border-width: var(--spectrum-slider-handle-border-size);
  border-style: solid;

  border-radius: var(--spectrum-slider-handle-border-radius);

  transition: border-width var(--spectrum-slider-animation-duration) ease-in-out;

  outline: none;
}

.spectrum-Slider-handle:active,
  .spectrum-Slider-handle.is-focused,
  .spectrum-Slider-handle.is-dragged {
    border-width: var(--spectrum-slider-handle-border-size-down);
  }

.spectrum-Slider-handle:active,
  .spectrum-Slider-handle.is-focused,
  .spectrum-Slider-handle.is-dragged,
  .spectrum-Slider-handle.is-tophandle {
    z-index: 3;
  }

.spectrum-Slider-handle:before {
    content: " ";
    display: block;
    position: absolute;
    left: 50%;
    top: 50%;

    transition: box-shadow var(--spectrum-global-animation-duration-100, 130ms)
        ease-out,
      width var(--spectrum-global-animation-duration-100, 130ms) ease-out,
      height var(--spectrum-global-animation-duration-100, 130ms) ease-out;

    width: var(--spectrum-slider-handle-width);
    height: var(--spectrum-slider-handle-height);

    transform: translate(-50%, -50%);

    border-radius: 100%;
  }

.spectrum-Slider-handle.is-focused:before {
      width: calc(var(--spectrum-slider-handle-width) + var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25)) * 2);
      height: calc(var(--spectrum-slider-handle-height) + var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25)) * 2);
    }

[dir="ltr"] .spectrum-Slider-input {
  left: var(--spectrum-slider-input-left);
}

[dir="rtl"] .spectrum-Slider-input {
  right: var(--spectrum-slider-input-left);
}

.spectrum-Slider-input {
  margin: 0;

  width: var(--spectrum-slider-handle-width);
  height: var(--spectrum-slider-handle-height);
  padding: 0;
  position: absolute;
  top: var(--spectrum-slider-input-top);
  overflow: hidden;
  opacity: 0.000001;
  cursor: default;
  -webkit-appearance: none;
  border: 0;
  pointer-events: none;
}

.spectrum-Slider-input:focus {
    outline: none;
  }

.spectrum-Slider-labelContainer {
  display: -ms-flexbox;
  display: flex;
  position: relative;

  width: auto;

  padding-top: var(--spectrum-fieldlabel-m-padding-top, var(--spectrum-global-dimension-size-50));

  font-size: var(--spectrum-slide-label-text-size);
  line-height: var(--spectrum-slide-label-text-line-height);
}

[dir="ltr"] .spectrum-Slider-label {
  padding-left: 0;
}

[dir="rtl"] .spectrum-Slider-label {
  padding-right: 0;
}

.spectrum-Slider-label {
  -ms-flex-positive: 1;
      flex-grow: 1;
}

[dir="ltr"] .spectrum-Slider-value {
  padding-right: 0;
}

[dir="rtl"] .spectrum-Slider-value {
  padding-left: 0;
}

[dir="ltr"] .spectrum-Slider-value {
  text-align: right;
}

[dir="rtl"] .spectrum-Slider-value {
  text-align: left;
}

.spectrum-Slider-value {
  -ms-flex-positive: 0;
      flex-grow: 0;
  cursor: default;
  font-feature-settings: "tnum";
}

[dir="ltr"] .spectrum-Slider-value {
  margin-left: var(--spectrum-slider-label-gap-x);
}

[dir="rtl"] .spectrum-Slider-value {
  margin-right: var(--spectrum-slider-label-gap-x);
}

.spectrum-Slider-ticks {
  display: -ms-flexbox;
  display: flex;
  -ms-flex-pack: justify;
      justify-content: space-between;

  z-index: 0;

  margin: 0 var(--spectrum-slider-track-margin-offset);
  margin-top: calc(var(--spectrum-slider-tick-mark-height) + var(--spectrum-slider-track-height) / 2);
}

.spectrum-Slider-tick {
  position: relative;

  width: var(--spectrum-slider-tick-mark-width);
}

[dir="ltr"] .spectrum-Slider-tick:after {
    left: calc(50% - var(--spectrum-slider-tick-mark-width) / 2);
}

[dir="rtl"] .spectrum-Slider-tick:after {
    right: calc(50% - var(--spectrum-slider-tick-mark-width) / 2);
}

.spectrum-Slider-tick:after {
    display: block;
    position: absolute;
    top: 0;
    content: "";
    width: var(--spectrum-slider-tick-mark-width);
    height: var(--spectrum-slider-tick-mark-height);

    border-radius: var(--spectrum-slider-tick-mark-border-radius);
  }

.spectrum-Slider-tick .spectrum-Slider-tickLabel {
    display: -ms-flexbox;
    display: flex;
    -ms-flex-align: center;
        align-items: center;
    -ms-flex-pack: center;
        justify-content: center;

    margin-top: calc(var(--spectrum-slider-label-gap-y) + var(--spectrum-slider-tick-mark-height));

    margin-bottom: 0;
    margin-left: calc(var(--spectrum-slider-label-gap-x) * -1);
    margin-right: calc(var(--spectrum-slider-label-gap-x) * -1);

    font-size: var(--spectrum-slide-label-text-size);
    line-height: var(--spectrum-slide-label-text-line-height);
  }

.spectrum-Slider-tick:first-of-type .spectrum-Slider-tickLabel, .spectrum-Slider-tick:last-of-type .spectrum-Slider-tickLabel {
      display: block;
      position: absolute;
      margin-left: 0;
      margin-right: 0;
    }

[dir="ltr"] .spectrum-Slider-tick:first-of-type .spectrum-Slider-tickLabel {
      left: 0;
}

[dir="rtl"] .spectrum-Slider-tick:first-of-type .spectrum-Slider-tickLabel {
      right: 0;
}

[dir="ltr"] .spectrum-Slider-tick:last-of-type .spectrum-Slider-tickLabel {
      right: 0;
}

[dir="rtl"] .spectrum-Slider-tick:last-of-type .spectrum-Slider-tickLabel {
      left: 0;
}

.spectrum-Slider.is-disabled {
    cursor: default;
  }

.spectrum-Slider.is-disabled .spectrum-Slider-handle {
      cursor: default;
      pointer-events: none;
    }

.spectrum-Slider {
  --spectrum-slider-m-focus-ring-size-key-focus: var(--spectrum-alias-focus-ring-size, var(--spectrum-global-dimension-static-size-25));
  --spectrum-slider-m-handle-border-color-key-focus: var(
    --spectrum-global-color-gray-800
  );
  --spectrum-slider-m-handle-focus-ring-color-key-focus: var(--spectrum-alias-focus-color, var(--spectrum-global-color-blue-400));
  --spectrum-slider-m-label-text-color: var(--spectrum-alias-label-text-color, var(--spectrum-global-color-gray-700));

  --spectrum-slider-m-label-text-color-disabled: var(--spectrum-alias-text-color-disabled, var(--spectrum-global-color-gray-500));
}

.spectrum-Slider-track::before {
    background: var(--spectrum-slider-m-track-color, var(--spectrum-global-color-gray-400));
  }

.spectrum-Slider-labelContainer {
  color: var(--spectrum-slider-m-label-text-color);
}

.spectrum-Slider--filled .spectrum-Slider-track:first-child::before {
      background: var(--spectrum-slider-m-track-fill-color, var(--spectrum-global-color-gray-700));
    }

.spectrum-Slider-fill::before {
    background: var(--spectrum-slider-m-track-fill-color, var(--spectrum-global-color-gray-700));
  }

.spectrum-Slider-ramp path {
    fill: var(--spectrum-slider-m-track-color, var(--spectrum-global-color-gray-400));
  }

.spectrum-Slider-handle {
  border-color: var(--spectrum-slider-m-handle-border-color, var(--spectrum-global-color-gray-700));
  background: var(--spectrum-slider-m-handle-background-color, var(--spectrum-alias-background-color-transparent));
}

.spectrum-Slider-handle:hover {
    border-color: var(--spectrum-slider-m-handle-border-color-hover, var(--spectrum-global-color-gray-800));
  }

.spectrum-Slider-handle.is-focused {
    border-color: var(--spectrum-slider-m-handle-border-color-key-focus, var(--spectrum-global-color-gray-800));
  }

.spectrum-Slider-handle.is-focused:before {
      box-shadow: 0 0 0 var(--spectrum-slider-m-focus-ring-size-key-focus, var(--spectrum-alias-focus-ring-size))
        var(--spectrum-slider-m-handle-focus-ring-color-key-focus);
    }

.spectrum-Slider-handle:active,
  .spectrum-Slider-handle.is-dragged {
    border-color: var(--spectrum-slider-m-handle-border-color-down, var(--spectrum-global-color-gray-800));
  }

.spectrum-Slider--ramp .spectrum-Slider-handle {
    box-shadow: 0 0 0 4px var(--spectrum-alias-background-color-default, var(--spectrum-global-color-gray-100));
  }

.spectrum-Slider-input {
  background: transparent;
}

.spectrum-Slider-tick:after {
    background-color: var(--spectrum-slider-tick-m-mark-color, var(--spectrum-alias-track-color-default));
  }

.spectrum-Slider-handle.is-dragged {
    border-color: var(--spectrum-slider-m-handle-border-color-down, var(--spectrum-global-color-gray-800));
    background: var(--spectrum-slider-m-handle-background-color-down, var(--spectrum-alias-background-color-transparent));
  }

.spectrum-Slider--range .spectrum-Slider-track:not(:first-of-type):not(:last-of-type):before {
        background: var(--spectrum-slider-m-track-fill-color, var(--spectrum-global-color-gray-700));
      }

.spectrum-Slider.is-disabled .spectrum-Slider-labelContainer {
      color: var(--spectrum-slider-m-label-text-color-disabled);
    }

.spectrum-Slider.is-disabled .spectrum-Slider-handle {
      border-color: var(--spectrum-slider-m-handle-border-color-disabled, var(--spectrum-global-color-gray-400));
      background: var(--spectrum-alias-background-color-default, var(--spectrum-global-color-gray-100));
    }

.spectrum-Slider.is-disabled .spectrum-Slider-handle:hover,
      .spectrum-Slider.is-disabled .spectrum-Slider-handle:active {
        border-color: var(--spectrum-slider-m-handle-border-color-disabled, var(--spectrum-global-color-gray-400));
        background: var(--spectrum-slider-m-handle-background-color, var(--spectrum-alias-background-color-transparent));
      }

.spectrum-Slider.is-disabled .spectrum-Slider-track::before {
        background: var(--spectrum-slider-m-track-color-disabled, var(--spectrum-global-color-gray-300));
      }

.spectrum-Slider.is-disabled.spectrum-Slider--filled .spectrum-Slider-track:first-child::before {
          background: var(--spectrum-slider-m-track-fill-color-disabled, var(--spectrum-global-color-gray-300));
        }

.spectrum-Slider.is-disabled .spectrum-Slider-fill::before {
        background: var(--spectrum-slider-m-track-fill-color-disabled, var(--spectrum-global-color-gray-300));
      }

.spectrum-Slider.is-disabled .spectrum-Slider-ramp path {
        fill: var(--spectrum-slider-ramp-track-color-disabled, var(--spectrum-global-color-gray-200));
      }

.spectrum-Slider.is-disabled.spectrum-Slider--range .spectrum-Slider-track:not(:first-of-type):not(:last-of-type):before {
            background: var(--spectrum-slider-m-track-fill-color-disabled, var(--spectrum-global-color-gray-300));
          }
div.svelte-177ynpe{display:grid;place-items:center}input.svelte-177ynpe{width:100%;padding:0;margin:0;-webkit-appearance:none;appearance:none;background:transparent}input.svelte-177ynpe::-webkit-slider-thumb{-webkit-appearance:none}input.svelte-177ynpe:focus{outline:none}input[type="range"].svelte-177ynpe::-webkit-slider-thumb{-webkit-appearance:none;border:2px solid var(--spectrum-global-color-gray-700);height:16px;width:16px;border-radius:50%;background:var(--background);cursor:pointer;transition:background 130ms ease-out;margin-top:-7px}input[type="range"].svelte-177ynpe::-moz-range-thumb{border:2px solid var(--spectrum-global-color-gray-700);height:12px;width:12px;border-radius:50%;background:var(--background);cursor:pointer;transition:background 130ms ease-out}input[type="range"].svelte-177ynpe::-webkit-slider-runnable-track{width:100%;height:2px;cursor:pointer;background:var(--spectrum-global-color-gray-300);border-radius:2px}input[type="range"].svelte-177ynpe::-moz-range-track{width:100%;height:2px;cursor:pointer;background:var(--spectrum-global-color-gray-300);border-radius:2px}.spectrum-Stepper {
  --spectrum-stepper-width: var(--spectrum-global-dimension-size-900);
  --spectrum-stepper-border-size: var(--spectrum-alias-border-size-thin, var(--spectrum-global-dimension-static-size-10));

  --spectrum-stepper-button-height: calc(var(--spectrum-alias-single-line-height, var(--spectrum-global-dimension-size-400)) / 2);
  --spectrum-stepper-button-width: calc(var(--spectrum-global-dimension-size-300) - var(--spectrum-stepper-border-size));

  --spectrum-stepper-button-padding: calc(var(--spectrum-global-dimension-size-150) / 2);
  --spectrum-stepper-border-radius-reset: 0;
  --spectrum-stepper-border-size-reset: 0;

  --spectrum-stepper-icon-nudge-top: var(--spectrum-global-dimension-size-10);
  --spectrum-stepper-icon-nudge: var(--spectrum-global-dimension-size-25);

  --spectrum-stepper-quiet-width: var(--spectrum-global-dimension-size-600);
  --spectrum-stepper-button-offset: calc(var(--spectrum-stepper-button-width) / 2 - var(--spectrum-icon-chevron-down-small-width, var(--spectrum-global-dimension-size-100)) / 2);
  --spectrum-stepper-quiet-button-width: calc(var(--spectrum-stepper-button-width) - var(--spectrum-stepper-button-offset));
}

.spectrum-Stepper {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-direction: row;
      flex-direction: row;
  -ms-flex-wrap: nowrap;
      flex-wrap: nowrap;

  width: var(--spectrum-stepper-width);
  line-height: 0;
  border-radius: var(--spectrum-alias-border-radius-regular, var(--spectrum-global-dimension-size-50));
  transition: border-color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out, box-shadow var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
}

.spectrum-Stepper::before {
  content: '';
}

[dir="ltr"] .spectrum-Stepper-buttons {
  border-top-left-radius: 0;
}

[dir="rtl"] .spectrum-Stepper-buttons {
  border-top-right-radius: 0;
}

[dir="ltr"] .spectrum-Stepper-buttons {
  border-top-right-radius: var(--spectrum-alias-border-radius-regular, var(--spectrum-global-dimension-size-50));
}

[dir="rtl"] .spectrum-Stepper-buttons {
  border-top-left-radius: var(--spectrum-alias-border-radius-regular, var(--spectrum-global-dimension-size-50));
}

[dir="ltr"] .spectrum-Stepper-buttons {
  border-bottom-right-radius: var(--spectrum-alias-border-radius-regular, var(--spectrum-global-dimension-size-50));
}

[dir="rtl"] .spectrum-Stepper-buttons {
  border-bottom-left-radius: var(--spectrum-alias-border-radius-regular, var(--spectrum-global-dimension-size-50));
}

[dir="ltr"] .spectrum-Stepper-buttons {
  border-bottom-left-radius: 0;
}

[dir="rtl"] .spectrum-Stepper-buttons {
  border-bottom-right-radius: 0;
}

.spectrum-Stepper-buttons {
  display: block;
  transition: box-shadow var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
}

[dir="ltr"] .spectrum-Stepper-stepUp,[dir="ltr"] 
.spectrum-Stepper-stepDown {

  padding-left: var(--spectrum-stepper-button-padding);
}

[dir="rtl"] .spectrum-Stepper-stepUp,[dir="rtl"] 
.spectrum-Stepper-stepDown {

  padding-right: var(--spectrum-stepper-button-padding);
}

[dir="ltr"] .spectrum-Stepper-stepUp,[dir="ltr"] 
.spectrum-Stepper-stepDown {
  padding-right: var(--spectrum-stepper-button-padding);
}

[dir="rtl"] .spectrum-Stepper-stepUp,[dir="rtl"] 
.spectrum-Stepper-stepDown {
  padding-left: var(--spectrum-stepper-button-padding);
}

[dir="ltr"] .spectrum-Stepper-stepUp,[dir="ltr"] 
.spectrum-Stepper-stepDown {
  border-left-width: var(--spectrum-stepper-border-size-reset);
}

[dir="rtl"] .spectrum-Stepper-stepUp,[dir="rtl"] 
.spectrum-Stepper-stepDown {
  border-right-width: var(--spectrum-stepper-border-size-reset);
}

[dir="ltr"] .spectrum-Stepper-stepUp,[dir="ltr"] 
.spectrum-Stepper-stepDown {

  border-top-left-radius: var(--spectrum-stepper-border-radius-reset);
}

[dir="rtl"] .spectrum-Stepper-stepUp,[dir="rtl"] 
.spectrum-Stepper-stepDown {

  border-top-right-radius: var(--spectrum-stepper-border-radius-reset);
}

[dir="ltr"] .spectrum-Stepper-stepUp,[dir="ltr"] 
.spectrum-Stepper-stepDown {
  border-bottom-left-radius: var(--spectrum-stepper-border-radius-reset);
}

[dir="rtl"] .spectrum-Stepper-stepUp,[dir="rtl"] 
.spectrum-Stepper-stepDown {
  border-bottom-right-radius: var(--spectrum-stepper-border-radius-reset);
}

.spectrum-Stepper-stepUp,
.spectrum-Stepper-stepDown {
  position: relative;
  display: -ms-flexbox;
  display: flex;
  box-sizing: border-box;

  height: var(--spectrum-stepper-button-height);
  width: var(--spectrum-stepper-button-width);
  min-width: 0;
  margin: 0 !important;

  border-width: var(--spectrum-stepper-border-size);
}

.spectrum-Stepper-stepUp .spectrum-Icon, .spectrum-Stepper-stepDown .spectrum-Icon {
    margin: 0 !important;
    opacity: 1;
  }

[dir="ltr"] .spectrum-Stepper-stepUp {
  border-bottom-right-radius: var(--spectrum-stepper-border-radius-reset);
}

[dir="rtl"] .spectrum-Stepper-stepUp {
  border-bottom-left-radius: var(--spectrum-stepper-border-radius-reset);
}

.spectrum-Stepper-stepUp {
  border-bottom: none;

  padding-top: var(--spectrum-stepper-icon-nudge-top);
}

[dir="ltr"] .spectrum-Stepper-stepDown {
  border-top-right-radius: var(--spectrum-stepper-border-radius-reset);
}

[dir="rtl"] .spectrum-Stepper-stepDown {
  border-top-left-radius: var(--spectrum-stepper-border-radius-reset);
}

.spectrum-Stepper-stepDown {

  padding-bottom: var(--spectrum-stepper-icon-nudge);
}

.spectrum-Stepper-textfield {
  -ms-flex: 1;
      flex: 1;
  width: auto;
}

[dir="ltr"] .spectrum-Stepper-input {
  border-top-right-radius: var(--spectrum-stepper-border-radius-reset);
}

[dir="rtl"] .spectrum-Stepper-input {
  border-top-left-radius: var(--spectrum-stepper-border-radius-reset);
}

[dir="ltr"] .spectrum-Stepper-input {
  border-bottom-right-radius: var(--spectrum-stepper-border-radius-reset);
}

[dir="rtl"] .spectrum-Stepper-input {
  border-bottom-left-radius: var(--spectrum-stepper-border-radius-reset);
}

.spectrum-Stepper-input {
  min-width: 0;
}

.spectrum-Stepper-textfield {
  min-width: 0;
}

.spectrum-Stepper--quiet {
  border-radius: var(--spectrum-stepper-border-radius-reset);
  width: var(--spectrum-stepper-quiet-width);
}

.spectrum-Stepper--quiet .spectrum-Stepper-buttons {
    border-radius: var(--spectrum-stepper-border-radius-reset);
  }

[dir="ltr"] .spectrum-Stepper--quiet .spectrum-Stepper-stepUp,[dir="ltr"] 
  .spectrum-Stepper--quiet .spectrum-Stepper-stepDown {

    border-right-width: var(--spectrum-stepper-border-size-reset);
}

[dir="rtl"] .spectrum-Stepper--quiet .spectrum-Stepper-stepUp,[dir="rtl"] 
  .spectrum-Stepper--quiet .spectrum-Stepper-stepDown {

    border-left-width: var(--spectrum-stepper-border-size-reset);
}

[dir="ltr"] .spectrum-Stepper--quiet .spectrum-Stepper-stepUp,[dir="ltr"] 
  .spectrum-Stepper--quiet .spectrum-Stepper-stepDown {
    border-left: none;
}

[dir="rtl"] .spectrum-Stepper--quiet .spectrum-Stepper-stepUp,[dir="rtl"] 
  .spectrum-Stepper--quiet .spectrum-Stepper-stepDown {
    border-right: none;
}

[dir="ltr"] .spectrum-Stepper--quiet .spectrum-Stepper-stepUp,[dir="ltr"] 
  .spectrum-Stepper--quiet .spectrum-Stepper-stepDown {

    padding-right: 0;
}

[dir="rtl"] .spectrum-Stepper--quiet .spectrum-Stepper-stepUp,[dir="rtl"] 
  .spectrum-Stepper--quiet .spectrum-Stepper-stepDown {

    padding-left: 0;
}

.spectrum-Stepper--quiet .spectrum-Stepper-stepUp,
  .spectrum-Stepper--quiet .spectrum-Stepper-stepDown {
    width: var(--spectrum-stepper-quiet-button-width);
    min-width: 0;
    border-top: none;
    border-radius: var(--spectrum-stepper-border-radius-reset);
    -ms-flex-pack: end;
        justify-content: flex-end;
  }

[dir="ltr"] .spectrum-Stepper--quiet .spectrum-Stepper-stepUp:after,[dir="ltr"]  .spectrum-Stepper--quiet .spectrum-Stepper-stepDown:after {
      right: calc(var(--spectrum-stepper-button-offset) * -1);
}

[dir="rtl"] .spectrum-Stepper--quiet .spectrum-Stepper-stepUp:after,[dir="rtl"]  .spectrum-Stepper--quiet .spectrum-Stepper-stepDown:after {
      left: calc(var(--spectrum-stepper-button-offset) * -1);
}

.spectrum-Stepper--quiet .spectrum-Stepper-stepUp:after, .spectrum-Stepper--quiet .spectrum-Stepper-stepDown:after {
      content: '';
      position: absolute;
      height: 100%;
      width: var(--spectrum-stepper-button-offset);
    }

.spectrum-Stepper:hover:not(.is-disabled):not(.is-invalid):not(.is-focused):not(.is-keyboardFocused) .spectrum-Stepper-stepUp,
    .spectrum-Stepper:hover:not(.is-disabled):not(.is-invalid):not(.is-focused):not(.is-keyboardFocused) .spectrum-Stepper-stepDown,
    .spectrum-Stepper:hover:not(.is-disabled):not(.is-invalid):not(.is-focused):not(.is-keyboardFocused) .spectrum-Stepper-input {
      border-color: var(--spectrum-textfield-m-border-color-hover, var(--spectrum-alias-border-color-hover));
    }

.spectrum-Stepper.is-focused {
    border-color: var(--spectrum-textfield-m-border-color-mouse-focus, var(--spectrum-alias-border-color-mouse-focus));
  }

.spectrum-Stepper.is-focused .spectrum-Stepper-stepUp,
    .spectrum-Stepper.is-focused .spectrum-Stepper-stepDown {
      border-color: var(--spectrum-textfield-m-border-color-mouse-focus, var(--spectrum-alias-border-color-mouse-focus));
    }

.spectrum-Stepper.is-focused .spectrum-Stepper-input {
      border-color: var(--spectrum-textfield-m-border-color-mouse-focus, var(--spectrum-alias-border-color-mouse-focus));
      box-shadow: none;
    }

.spectrum-Stepper.is-focused.is-invalid {
      border-color: var(--spectrum-textfield-m-border-color-error-mouse-focus, var(--spectrum-semantic-negative-color-state-hover));
    }

.spectrum-Stepper.is-focused.is-invalid .spectrum-Stepper-stepUp,
      .spectrum-Stepper.is-focused.is-invalid .spectrum-Stepper-stepDown {
        border-color: var(--spectrum-textfield-m-border-color-error-mouse-focus, var(--spectrum-semantic-negative-color-state-hover));
      }

.spectrum-Stepper.is-focused.is-invalid .spectrum-Stepper-input {
        border-color: var(--spectrum-textfield-m-border-color-error-mouse-focus, var(--spectrum-semantic-negative-color-state-hover));
      }

.spectrum-Stepper.is-keyboardFocused {
    box-shadow: 0 0 0 1px var(--spectrum-textfield-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
  }

.spectrum-Stepper.is-keyboardFocused .spectrum-Stepper-input,
    .spectrum-Stepper.is-keyboardFocused .spectrum-Stepper-buttons {
      box-shadow: 0 0 0 1px var(--spectrum-textfield-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-Stepper.is-keyboardFocused .spectrum-Stepper-input,
    .spectrum-Stepper.is-keyboardFocused .spectrum-Stepper-stepUp,
    .spectrum-Stepper.is-keyboardFocused .spectrum-Stepper-stepDown {
      border-color: var(--spectrum-textfield-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-Stepper.is-keyboardFocused.is-invalid {
      box-shadow: 0 0 0 1px var(--spectrum-textfield-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-Stepper.is-keyboardFocused.is-invalid .spectrum-Stepper-stepUp,
      .spectrum-Stepper.is-keyboardFocused.is-invalid .spectrum-Stepper-stepDown {
        border-color: var(--spectrum-textfield-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
      }

.spectrum-Stepper.is-keyboardFocused.is-invalid .spectrum-Stepper-buttons {
        box-shadow: 0 0 0 1px var(--spectrum-textfield-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
      }

.spectrum-Stepper.is-invalid .spectrum-Stepper-stepUp,
    .spectrum-Stepper.is-invalid .spectrum-Stepper-stepDown {
      border-color: var(--spectrum-textfield-m-border-color-error, var(--spectrum-semantic-negative-color-default));
    }

.spectrum-Stepper.is-invalid .spectrum-Stepper-input {
      border-color: var(--spectrum-textfield-m-border-color-error, var(--spectrum-semantic-negative-color-default));
    }

.spectrum-Stepper.is-invalid.is-keyboardFocused .spectrum-Stepper-input {
        border-color: var(--spectrum-textfield-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
        box-shadow: 0 0 0 1px var(--spectrum-textfield-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
      }

.spectrum-Stepper.is-invalid.is-keyboardFocused .spectrum-Stepper-buttons {
        box-shadow: 0 0 0 1px var(--spectrum-textfield-m-border-color-error-key-focus, var(--spectrum-alias-border-color-focus));
      }

.spectrum-Stepper.is-disabled .spectrum-Stepper-stepUp,
    .spectrum-Stepper.is-disabled .spectrum-Stepper-stepDown {
      border-color: var(--spectrum-textfield-m-border-color-disabled, var(--spectrum-alias-border-color-transparent));
    }

.spectrum-Stepper-stepUp,
.spectrum-Stepper-stepDown {
  border-color: var(--spectrum-textfield-m-border-color, var(--spectrum-alias-border-color));
}

.spectrum-Stepper-stepUp:disabled, .spectrum-Stepper-stepDown:disabled {
    border-color: var(--spectrum-textfield-m-border-color-disabled, var(--spectrum-alias-border-color-transparent));
  }

.spectrum-Stepper--quiet.is-disabled .spectrum-Stepper-stepUp,
    .spectrum-Stepper--quiet.is-disabled .spectrum-Stepper-stepDown {
      border-color: var(--spectrum-textfield-quiet-m-border-color-disabled, var(--spectrum-alias-border-color-mid));
    }

.spectrum-Stepper--quiet .spectrum-Stepper-stepUp,
  .spectrum-Stepper--quiet .spectrum-Stepper-stepDown {
    border-color: var(--spectrum-textfield-quiet-m-border-color, var(--spectrum-alias-border-color));
  }

.spectrum-Stepper--quiet .spectrum-Stepper-stepUp:disabled, .spectrum-Stepper--quiet .spectrum-Stepper-stepDown:disabled {
      border-color: var(--spectrum-textfield-quiet-m-border-color-disabled, var(--spectrum-alias-border-color-mid));
    }

.spectrum-Stepper--quiet .spectrum-Stepper-input {
    box-shadow: none;
  }

.spectrum-Stepper--quiet.is-invalid .spectrum-Stepper-input {
      border-color: var(--spectrum-textfield-m-border-color-error, var(--spectrum-semantic-negative-color-default));
    }

.spectrum-Stepper--quiet.is-invalid .spectrum-Stepper-stepDown {
      border-color: var(--spectrum-textfield-m-border-color-error, var(--spectrum-semantic-negative-color-default));
    }

.spectrum-Stepper--quiet.is-keyboardFocused,
  .spectrum-Stepper--quiet.is-focused {
    box-shadow: none;
  }

.spectrum-Stepper--quiet.is-keyboardFocused .spectrum-Stepper-buttons,
    .spectrum-Stepper--quiet.is-keyboardFocused .spectrum-Stepper-input,
    .spectrum-Stepper--quiet.is-focused .spectrum-Stepper-buttons,
    .spectrum-Stepper--quiet.is-focused .spectrum-Stepper-input {
      box-shadow: 0 1px 0 0 var(--spectrum-textfield-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-Stepper--quiet.is-keyboardFocused .spectrum-Stepper-stepDown, .spectrum-Stepper--quiet.is-focused .spectrum-Stepper-stepDown {
      border-color: var(--spectrum-textfield-m-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-Stepper--quiet.is-keyboardFocused.is-invalid, .spectrum-Stepper--quiet.is-focused.is-invalid {
      box-shadow: none;
    }

.spectrum-Stepper--quiet.is-keyboardFocused.is-invalid .spectrum-Stepper-input,
      .spectrum-Stepper--quiet.is-keyboardFocused.is-invalid .spectrum-Stepper-buttons,
      .spectrum-Stepper--quiet.is-focused.is-invalid .spectrum-Stepper-input,
      .spectrum-Stepper--quiet.is-focused.is-invalid .spectrum-Stepper-buttons {
        box-shadow: 0 1px 0 0 var(--spectrum-textfield-m-border-color-error, var(--spectrum-semantic-negative-color-default));
      }

.spectrum-Stepper--quiet.is-keyboardFocused.is-invalid .spectrum-Stepper-input, .spectrum-Stepper--quiet.is-focused.is-invalid .spectrum-Stepper-input {
        border-color: var(--spectrum-textfield-m-border-color-error, var(--spectrum-semantic-negative-color-default));
      }

.spectrum-Stepper--quiet.is-keyboardFocused.is-invalid .spectrum-Stepper-stepDown, .spectrum-Stepper--quiet.is-focused.is-invalid .spectrum-Stepper-stepDown {
        border-color: var(--spectrum-textfield-m-border-color-error, var(--spectrum-semantic-negative-color-default));
      }
.spectrum-Stepper.svelte-c6q2wy{width:100%}.spectrum-Stepper.svelte-c6q2wy::before{display:none}.spectrum-Switch {
  --spectrum-switch-handle-border-radius: var(--spectrum-switch-m-handle-border-radius);
  --spectrum-switch-handle-border-size: var(--spectrum-switch-m-handle-border-size, var(--spectrum-alias-border-size-thick));
  --spectrum-switch-cursor-hit-x: var(--spectrum-switch-m-cursor-hit-x, var(--spectrum-global-dimension-size-100));
  --spectrum-switch-text-size: var(--spectrum-switch-m-text-size, var(--spectrum-alias-item-text-size-m));
  --spectrum-switch-height: var(--spectrum-switch-m-height, var(--spectrum-alias-item-height-m));
  --spectrum-switch-track-height: var(--spectrum-switch-m-track-height, var(--spectrum-alias-item-control-3-height-m));
  --spectrum-switch-track-width: var(--spectrum-switch-m-track-width, var(--spectrum-alias-item-control-3-width-m));
  --spectrum-switch-handle-size: var(--spectrum-switch-m-handle-size, var(--spectrum-alias-item-control-2-size-m));
  --spectrum-switch-text-gap: var(--spectrum-switch-m-text-gap, var(--spectrum-alias-item-control-gap-m));
  --spectrum-switch-label-margin-top: var(--spectrum-global-dimension-size-65);
  --spectrum-switch-label-line-height: 1.49;
}

[dir="ltr"] .spectrum-Switch {

  margin-right: calc(var(--spectrum-switch-cursor-hit-x) * 2);
}

[dir="rtl"] .spectrum-Switch {

  margin-left: calc(var(--spectrum-switch-cursor-hit-x) * 2);
}

.spectrum-Switch {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-align: start;
      align-items: flex-start;

  position: relative;

  min-height: var(--spectrum-switch-height);
  max-width: 100%;

  vertical-align: top;
}

[dir="ltr"] .spectrum-Switch-input {
  left: 0;
}

[dir="rtl"] .spectrum-Switch-input {
  right: 0;
}

.spectrum-Switch-input {
  margin: 0;
  box-sizing: border-box;
  padding: 0;

  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  opacity: 0.0001;
  z-index: 1;

  cursor: pointer;
}

[dir="ltr"] .spectrum-Switch-input:checked + .spectrum-Switch-switch::before {
      transform: translateX(
        calc(var(--spectrum-switch-track-width) - 100%)
      );
    }

[dir="rtl"] .spectrum-Switch-input:checked + .spectrum-Switch-switch::before {
      transform: translateX(
        calc(-1 * (var(--spectrum-switch-track-width) - 100%))
      );
    }

.spectrum-Switch-input:disabled,
  .spectrum-Switch-input[disabled] {
    cursor: default;
  }

.spectrum-Switch-input.focus-ring + .spectrum-Switch-switch:after {
        margin: calc(var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25)) * -1);
      }

.spectrum-Switch-label {
  margin-left: var(--spectrum-switch-text-gap);
  margin-right: var(--spectrum-switch-text-gap);
  margin-top: var(--spectrum-switch-label-margin-top);
  margin-bottom: 0;
  font-size: var(--spectrum-switch-text-size);
  line-height: var(--spectrum-switch-label-line-height);
  transition: color var(--spectrum-global-animation-duration-200, 160ms) ease-in-out;
}

[dir="ltr"] .spectrum-Switch-switch {

  left: 0;
}

[dir="rtl"] .spectrum-Switch-switch {

  right: 0;
}

[dir="ltr"] .spectrum-Switch-switch {
  right: 0;
}

[dir="rtl"] .spectrum-Switch-switch {
  left: 0;
}

.spectrum-Switch-switch {
  display: inline-block;
  box-sizing: border-box;
  position: relative;

  width: var(--spectrum-switch-track-width);
  margin-top: calc((var(--spectrum-switch-height) - var(--spectrum-switch-track-height)) / 2);
  margin-bottom: calc((var(--spectrum-switch-height) - var(--spectrum-switch-track-height)) / 2);
  margin-left: 0;
  margin-right: 0;

  -ms-flex-positive: 0;

      flex-grow: 0;
  -ms-flex-negative: 0;
      flex-shrink: 0;

  vertical-align: middle;

  transition: background var(--spectrum-global-animation-duration-100, 130ms)
      ease-in-out,
    border var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;

  height: var(--spectrum-switch-track-height);

  border-radius: calc(var(--spectrum-switch-track-height) / 2);
}

.spectrum-Switch-switch:before {
    display: block;
    position: absolute;
    content: "";
    box-sizing: border-box;
  }

[dir="ltr"] .spectrum-Switch-switch:before {
    left: 0;
}

[dir="rtl"] .spectrum-Switch-switch:before {
    right: 0;
}

.spectrum-Switch-switch:before {
    transition: background var(--spectrum-global-animation-duration-100, 130ms)
        ease-in-out,
      border var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
      transform var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
      box-shadow var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;

    width: var(--spectrum-switch-handle-size);
    height: var(--spectrum-switch-handle-size);

    top: 0;

    border-width: var(--spectrum-switch-handle-border-size);
    border-radius: var(--spectrum-switch-handle-border-radius);
    border-style: solid;
  }

[dir="ltr"] .spectrum-Switch-switch:after {
    left: 0;
}

[dir="rtl"] .spectrum-Switch-switch:after {
    right: 0;
}

[dir="ltr"] .spectrum-Switch-switch:after {
    right: 0;
}

[dir="rtl"] .spectrum-Switch-switch:after {
    left: 0;
}

.spectrum-Switch-switch:after {
    border-radius: calc(var(--spectrum-switch-track-height) + var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25)));
    content: "";
    display: block;
    position: absolute;
    bottom: 0;
    top: 0;
    margin: 0;

    transition: opacity var(--spectrum-global-animation-duration-100, 130ms) ease-out,
                margin var(--spectrum-global-animation-duration-100, 130ms) ease-out;
  }

.spectrum-Switch-switch {
  background-color: var(--spectrum-switch-m-track-color, var(--spectrum-global-color-gray-300));
}

.spectrum-Switch-switch:before {
    background-color: var(--spectrum-switch-m-handle-background-color, var(--spectrum-global-color-gray-75));
    border-color: var(--spectrum-switch-m-handle-border-color, var(--spectrum-global-color-gray-600));
  }

.spectrum-Switch-input ~ .spectrum-Switch-label {
  color: var(--spectrum-switch-m-text-color, var(--spectrum-alias-text-color));
}

.spectrum-Switch-input:checked + .spectrum-Switch-switch {
    background-color: var(--spectrum-switch-m-track-color-selected, var(--spectrum-global-color-gray-700));
  }

.spectrum-Switch-input:checked + .spectrum-Switch-switch:before {
      border-color: var(--spectrum-switch-m-handle-border-color-selected, var(--spectrum-global-color-gray-700));
    }

.spectrum-Switch:hover .spectrum-Switch-input + .spectrum-Switch-switch:before {
        border-color: var(--spectrum-switch-m-handle-border-color-hover, var(--spectrum-global-color-gray-700));
        box-shadow: none;
      }

.spectrum-Switch:hover .spectrum-Switch-input ~ .spectrum-Switch-label {
      color: var(--spectrum-switch-m-text-color-hover, var(--spectrum-alias-text-color-hover));
    }

.spectrum-Switch:hover .spectrum-Switch-input:checked:enabled + .spectrum-Switch-switch {
      background-color: var(--spectrum-switch-m-track-color-selected-hover, var(--spectrum-global-color-gray-800));
    }

.spectrum-Switch:hover .spectrum-Switch-input:checked:enabled + .spectrum-Switch-switch:before {
        border-color: var(--spectrum-switch-m-handle-border-color-selected-hover, var(--spectrum-global-color-gray-800));
      }

.spectrum-Switch:active .spectrum-Switch-input + .spectrum-Switch-switch:before {
        border-color: var(--spectrum-switch-m-handle-border-color-down, var(--spectrum-global-color-gray-800));
      }

.spectrum-Switch:active .spectrum-Switch-input ~ .spectrum-Switch-label {
      color: var(--spectrum-switch-m-text-color-down, var(--spectrum-alias-text-color-down));
    }

.spectrum-Switch:active .spectrum-Switch-input:checked:enabled + .spectrum-Switch-switch {
      background-color: var(--spectrum-switch-m-track-color-selected-down, var(--spectrum-global-color-gray-900));
    }

.spectrum-Switch:active .spectrum-Switch-input:checked:enabled + .spectrum-Switch-switch:before {
        border-color: var(--spectrum-switch-m-handle-border-color-selected-down, var(--spectrum-global-color-gray-900));
      }

.spectrum-Switch .spectrum-Switch-input:disabled + .spectrum-Switch-switch {
    background-color: var(--spectrum-switch-m-track-color-disabled, var(--spectrum-global-color-gray-300));
  }

.spectrum-Switch .spectrum-Switch-input:disabled + .spectrum-Switch-switch:before {
      border-color: var(--spectrum-switch-m-handle-border-color-disabled, var(--spectrum-global-color-gray-400));
    }

.spectrum-Switch .spectrum-Switch-input:disabled ~ .spectrum-Switch-label {
    color: var(--spectrum-switch-m-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }

.spectrum-Switch .spectrum-Switch-input:disabled:checked + .spectrum-Switch-switch {
      background-color: var(--spectrum-switch-m-track-color-selected-disabled, var(--spectrum-global-color-gray-400));
    }

.spectrum-Switch .spectrum-Switch-input:disabled:checked + .spectrum-Switch-switch:before {
        border-color: var(--spectrum-switch-m-handle-border-color-selected-disabled, var(--spectrum-global-color-gray-400));
      }

.spectrum-Switch .spectrum-Switch-input:disabled:checked ~ .spectrum-Switch-label {
      color: var(--spectrum-switch-m-text-color-selected-disabled, var(--spectrum-alias-text-color-disabled));
    }

.spectrum-Switch--emphasized .spectrum-Switch-input:checked + .spectrum-Switch-switch {
    background-color: var(--spectrum-switch-m-emphasized-track-color-selected, var(--spectrum-global-color-blue-500));
  }

.spectrum-Switch--emphasized .spectrum-Switch-input:checked + .spectrum-Switch-switch:before {
      border-color: var(--spectrum-switch-m-emphasized-handle-border-color-selected, var(--spectrum-global-color-blue-500));
    }

.spectrum-Switch--emphasized:hover .spectrum-Switch-input:checked:enabled + .spectrum-Switch-switch {
    background-color: var(--spectrum-switch-m-emphasized-track-color-selected-hover, var(--spectrum-global-color-blue-600));
  }

.spectrum-Switch--emphasized:hover .spectrum-Switch-input:checked:enabled + .spectrum-Switch-switch:before {
      border-color: var(--spectrum-switch-m-emphasized-handle-border-color-selected-hover, var(--spectrum-global-color-blue-600));
    }

.spectrum-Switch.spectrum-Switch--emphasized:active .spectrum-Switch-input:checked:enabled + .spectrum-Switch-switch {
    background-color: var(--spectrum-switch-m-emphasized-track-color-selected-down, var(--spectrum-global-color-blue-700));
  }

.spectrum-Switch.spectrum-Switch--emphasized:active .spectrum-Switch-input:checked:enabled + .spectrum-Switch-switch:before {
      border-color: var(--spectrum-switch-m-emphasized-handle-border-color-selected-down, var(--spectrum-global-color-blue-700));
    }

.spectrum-Switch .spectrum-Switch-input.focus-ring + .spectrum-Switch-switch:after, .spectrum-Switch:hover .spectrum-Switch-input.focus-ring + .spectrum-Switch-switch:after {
        box-shadow: 0 0 0 var(--spectrum-switch-m-focus-ring-size-key-focus, var(--spectrum-alias-focus-ring-size))
          var(--spectrum-switch-m-focus-ring-color-key-focus, var(--spectrum-alias-focus-ring-color));
      }

.spectrum-Switch .spectrum-Switch-input.focus-ring + .spectrum-Switch-switch:before, .spectrum-Switch:hover .spectrum-Switch-input.focus-ring + .spectrum-Switch-switch:before {
        border-color: var(--spectrum-switch-m-handle-border-color-key-focus, var(--spectrum-global-color-gray-700));
      }

.spectrum-Switch .spectrum-Switch-input.focus-ring:checked + .spectrum-Switch-switch, .spectrum-Switch:hover .spectrum-Switch-input.focus-ring:checked + .spectrum-Switch-switch {
        background-color: var(--spectrum-switch-m-track-color-selected-key-focus, var(--spectrum-global-color-gray-800));
      }

.spectrum-Switch .spectrum-Switch-input.focus-ring:checked + .spectrum-Switch-switch:before, .spectrum-Switch:hover .spectrum-Switch-input.focus-ring:checked + .spectrum-Switch-switch:before {
          border-color: var(--spectrum-switch-m-handle-border-color-selected-key-focus, var(--spectrum-global-color-gray-800));
        }

.spectrum-Switch--emphasized .spectrum-Switch-input.focus-ring:checked + .spectrum-Switch-switch, .spectrum-Switch--emphasized:hover .spectrum-Switch-input.focus-ring:checked + .spectrum-Switch-switch {
        background-color: var(--spectrum-switch-m-emphasized-track-color-selected-key-focus, var(--spectrum-global-color-blue-600));
      }

.spectrum-Switch--emphasized .spectrum-Switch-input.focus-ring:checked + .spectrum-Switch-switch:before, .spectrum-Switch--emphasized:hover .spectrum-Switch-input.focus-ring:checked + .spectrum-Switch-switch:before {
          border-color: var(--spectrum-switch-m-emphasized-handle-border-color-selected-key-focus, var(--spectrum-global-color-blue-600));
        }
.spectrum-Switch-input.svelte-7919tl{opacity:0}.noPadding.svelte-7919tl{padding:0;margin:0}.spectrum-Textfield.svelte-1kmb9uq{width:100%}textarea.svelte-1kmb9uq{resize:vertical;min-height:80px !important}.spectrum-Textfield.svelte-15e87u6{width:100%;--spectrum-textfield-padding-bottom:var(--spectrum-textfield-padding-top)}input.svelte-15e87u6::placeholder{color:var(--grey-7)}input.svelte-15e87u6:hover::placeholder{color:var(--grey-7) !important}input.svelte-15e87u6:focus::placeholder{color:var(--grey-7) !important}.spectrum-InputGroup.svelte-tz7in0.svelte-tz7in0{min-width:0;width:100%}.spectrum-InputGroup-input.svelte-tz7in0.svelte-tz7in0{border-right-width:1px}.spectrum-Textfield.svelte-tz7in0.svelte-tz7in0{width:100%}.spectrum-Textfield-input.svelte-tz7in0.svelte-tz7in0{width:0}.override-borders.svelte-tz7in0.svelte-tz7in0{border-top-left-radius:0px;border-bottom-left-radius:0px}.spectrum-Popover.svelte-tz7in0.svelte-tz7in0{max-height:240px;z-index:999;top:100%;width:100%}.subtitle-text.svelte-tz7in0.svelte-tz7in0{font-size:12px;line-height:15px;font-weight:500;color:var(--spectrum-global-color-gray-600);display:block;margin-top:var(--spacing-s)}.check.svelte-tz7in0.svelte-tz7in0{display:none}li.is-selected.svelte-tz7in0 .check.svelte-tz7in0{display:block}.error-message.svelte-wciay3{background:var(--spectrum-global-color-red-400);color:white;font-size:14px;padding:6px 16px;font-weight:500}.fancy-field.svelte-1nk7anx.svelte-1nk7anx{background:var(--spectrum-global-color-gray-75);border:1px solid var(--spectrum-global-color-gray-300);border-radius:4px;box-sizing:border-box;transition:border-color 130ms ease-out,
      background 130ms ease-out,
      background 130ms ease-out;color:var(--spectrum-global-color-gray-800);--padding:16px;--height:64px}.fancy-field.compact.svelte-1nk7anx.svelte-1nk7anx{--padding:8px;--height:36px}.fancy-field.svelte-1nk7anx.svelte-1nk7anx:hover{border-color:var(--spectrum-global-color-gray-400)}.fancy-field.clickable.svelte-1nk7anx.svelte-1nk7anx:hover{background:var(--spectrum-global-color-gray-200);cursor:pointer}.fancy-field.focused.svelte-1nk7anx.svelte-1nk7anx{border-color:var(--spectrum-global-color-blue-400)}.fancy-field.error.svelte-1nk7anx.svelte-1nk7anx{border-color:var(--spectrum-global-color-red-400)}.fancy-field.disabled.svelte-1nk7anx.svelte-1nk7anx{background:var(--spectrum-global-color-gray-200);color:var(--spectrum-global-color-gray-400);border:1px solid var(--spectrum-global-color-gray-300);pointer-events:none}.content.svelte-1nk7anx.svelte-1nk7anx{position:relative;height:var(--height);padding:0 var(--padding)}.fancy-field.auto-height.svelte-1nk7anx .content.svelte-1nk7anx{height:auto}.content.svelte-1nk7anx.svelte-1nk7anx,.field.svelte-1nk7anx.svelte-1nk7anx{display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:var(--padding)}.field.svelte-1nk7anx.svelte-1nk7anx{flex:1 1 auto}.error-icon.svelte-1nk7anx.svelte-1nk7anx{flex:0 0 auto}.error-icon.svelte-1nk7anx i{fill:var(--spectrum-global-color-red-400)}img.svelte-14pbp5s{width:22px}div.svelte-14pbp5s{font-size:var(--font-size-l)}div.svelte-wcobo1{font-size:14px;line-height:15px;font-weight:500;position:absolute;top:10px;color:var(--spectrum-global-color-gray-600);transition:font-size 130ms ease-out,
      top 130ms ease-out,
      transform 130ms ease-out}div.placeholder.svelte-wcobo1{top:50%;font-size:15px;transform:translateY(-50%)}.options.svelte-1mys7zf{margin-top:34px;margin-bottom:14px;display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:6px;flex-wrap:wrap}.options.svelte-1mys7zf .spectrum-ActionButton{font-size:15px;line-height:17px;height:auto;padding:6px 10px}span.svelte-14uwzyc{pointer-events:none}.text.svelte-14uwzyc{font-size:15px;line-height:17px;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;line-clamp:2;-webkit-box-orient:vertical}.text.compact.svelte-14uwzyc{font-size:13px;line-height:15px}.text.svelte-14uwzyc>*{font-size:inherit !important}.fancy-form.svelte-1wjd4hl .fancy-field:not(:first-of-type){border-top-left-radius:0;border-top-right-radius:0}.fancy-form.svelte-1wjd4hl .fancy-field:not(:last-of-type){border-bottom-left-radius:0;border-bottom-right-radius:0}.checkbox-group.has-select-all.svelte-2g5wlw .fancy-field:first-of-type{background:var(--spectrum-global-color-gray-100)}.checkbox-group.has-select-all.svelte-2g5wlw .fancy-field:first-of-type:hover{background:var(--spectrum-global-color-gray-200)}input.svelte-2823mm{width:100%;transition:transform 130ms ease-out;transform:translateY(9px);background:transparent;font-size:15px;line-height:17px;font-family:var(--font-sans);color:var(--spectrum-global-color-gray-900);outline:none;border:none;padding:0;margin:0}input.placeholder.svelte-2823mm{transform:translateY(0);position:absolute;top:0;left:0;height:100%}.suffix.svelte-2823mm{color:var(--spectrum-global-color-gray-600);transform:translateY(9px);font-size:15px;line-height:17px;font-family:var(--font-sans)}input.svelte-2823mm:-webkit-autofill{border-radius:2px;-webkit-box-shadow:0 0 0 100px var(--spectrum-global-color-gray-300) inset;-webkit-text-fill-color:var(--spectrum-global-color-gray-900);transition:-webkit-box-shadow 130ms 200ms,
      background-color 0s 86400s;padding:3px 8px 4px 8px}#picker-wrapper.svelte-4i6wt4 .spectrum-Picker{display:none}.value.svelte-4i6wt4{display:block;flex:1 1 auto;font-size:15px;line-height:17px;color:var(--spectrum-global-color-gray-900);transition:transform 130ms ease-out,
      opacity 130ms ease-out;opacity:1;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;width:0;transform:translateY(9px)}.align.svelte-4i6wt4{display:block;font-size:15px;line-height:17px;color:var(--spectrum-global-color-gray-900);transition:transform 130ms ease-out,
      opacity 130ms ease-out;transform:translateY(9px)}.arrow-alignment.svelte-4i6wt4{transform:translateY(-2px)}.value.placeholder.svelte-4i6wt4{transform:translateY(0);opacity:0;pointer-events:none;margin-top:0}.spectrum-Accordion {
  --spectrum-accordion-item-title-padding-y: var(
    --spectrum-global-dimension-size-150
  );
  --spectrum-accordion-animation-duration: var(--spectrum-global-animation-duration-100, 130ms);
}

.spectrum-Accordion {
  display: block;
  list-style: none;
  padding: 0;
  margin: 0;
}

[dir="ltr"] .spectrum-Accordion-itemIndicator {
  left: var(--spectrum-accordion-item-padding-x, var(--spectrum-global-dimension-size-225));
}

[dir="rtl"] .spectrum-Accordion-itemIndicator {
  right: var(--spectrum-accordion-item-padding-x, var(--spectrum-global-dimension-size-225));
}

[dir="rtl"] .spectrum-Accordion-itemIndicator { transform: matrix(-1, 0, 0, 1, 0, 0) ; }

.spectrum-Accordion-itemIndicator {
  display: block;

  position: absolute;
  top: calc(50% - var(--spectrum-accordion-icon-height, var(--spectrum-global-dimension-size-125)) / 2);

  transition: transform ease var(--spectrum-accordion-animation-duration);
}

.spectrum-Accordion-item {
  z-index: inherit;
  position: relative;

  display: list-item;
  margin: 0;

  border-bottom: var(--spectrum-accordion-item-border-size, var(--spectrum-alias-border-size-thin)) solid transparent;
}

.spectrum-Accordion-item:first-of-type {
    border-top: var(--spectrum-accordion-item-border-size, var(--spectrum-alias-border-size-thin)) solid
      transparent;
  }

.spectrum-Accordion-itemHeading {
  margin: 0;
  position: relative;
  box-sizing: border-box;
}

[dir="ltr"] .spectrum-Accordion-itemHeader {
  padding-left: calc(var(--spectrum-accordion-item-padding-x, var(--spectrum-global-dimension-size-225)) + var(--spectrum-accordion-icon-height, var(--spectrum-global-dimension-size-125)) + var(--spectrum-accordion-icon-gap, var(--spectrum-global-dimension-size-100)) + var(--spectrum-accordion-item-border-left-size, var(--spectrum-alias-border-size-thick)));
}

[dir="rtl"] .spectrum-Accordion-itemHeader {
  padding-right: calc(var(--spectrum-accordion-item-padding-x, var(--spectrum-global-dimension-size-225)) + var(--spectrum-accordion-icon-height, var(--spectrum-global-dimension-size-125)) + var(--spectrum-accordion-icon-gap, var(--spectrum-global-dimension-size-100)) + var(--spectrum-accordion-item-border-left-size, var(--spectrum-alias-border-size-thick)));
}

[dir="ltr"] .spectrum-Accordion-itemHeader {
  padding-right: var(--spectrum-accordion-item-padding-x, var(--spectrum-global-dimension-size-225));
}

[dir="rtl"] .spectrum-Accordion-itemHeader {
  padding-left: var(--spectrum-accordion-item-padding-x, var(--spectrum-global-dimension-size-225));
}

[dir="ltr"] .spectrum-Accordion-itemHeader {
  text-align: left;
}

[dir="rtl"] .spectrum-Accordion-itemHeader {
  text-align: right;
}

.spectrum-Accordion-itemHeader {
  position: relative;

  display: -ms-flexbox;

  display: flex;
  -ms-flex-align: center;
      align-items: center;
  -ms-flex-pack: start;
      justify-content: flex-start;

  box-sizing: border-box;
  padding-top: var(--spectrum-accordion-item-title-padding-y);
  padding-bottom: var(--spectrum-accordion-item-title-padding-y);
  margin: 0;

  min-height: calc(100% - var(--spectrum-accordion-item-border-size, var(--spectrum-alias-border-size-thin)));

  font-size: var(--spectrum-accordion-item-title-text-size, var(--spectrum-global-dimension-font-size-50));
  line-height: var(--spectrum-accordion-text-line-height, var(--spectrum-alias-component-text-line-height));
  text-transform: uppercase;
  letter-spacing: calc(var(--spectrum-accordion-item-title-tracking, var(--spectrum-global-font-letter-spacing-medium)) / 100);

  text-overflow: ellipsis;
  cursor: pointer;
  font-weight: 500;
  -webkit-appearance: none;
  appearance: none;
  background-color: inherit;
  border: 0;
  font-family: inherit;
  width: 100%;
}

.spectrum-Accordion-itemHeader:focus {
    outline: none;
  }

[dir="ltr"] .spectrum-Accordion-itemHeader:focus::after {
      left: 0;
}

[dir="rtl"] .spectrum-Accordion-itemHeader:focus::after {
      right: 0;
}

.spectrum-Accordion-itemHeader:focus::after {
      content: "";

      position: absolute;
      top: calc(-1 * var(--spectrum-accordion-item-border-size, var(--spectrum-alias-border-size-thin)));
      bottom: calc(-1 * var(--spectrum-accordion-item-border-size, var(--spectrum-alias-border-size-thin)));

      width: var(--spectrum-accordion-item-border-left-size, var(--spectrum-alias-border-size-thick));
    }

.spectrum-Accordion-itemContent {
  padding-top: 0;
  padding-bottom: var(--spectrum-accordion-item-content-padding, var(--spectrum-global-dimension-size-200));
  padding-left: var(--spectrum-accordion-item-content-padding, var(--spectrum-global-dimension-size-200));
  padding-right: var(--spectrum-accordion-item-content-padding, var(--spectrum-global-dimension-size-200));
  display: none;
}

[dir="ltr"] .spectrum-Accordion-item.is-open > .spectrum-Accordion-itemHeading > .spectrum-Accordion-itemIndicator { transform: rotate(90deg); }

[dir="rtl"] .spectrum-Accordion-item.is-open > .spectrum-Accordion-itemHeading > .spectrum-Accordion-itemIndicator { transform: matrix(-1, 0, 0, 1, 0, 0) rotate(90deg); }

[dir="ltr"] .spectrum-Accordion-item.is-open > .spectrum-Accordion-itemIndicator { transform: rotate(90deg); }

[dir="rtl"] .spectrum-Accordion-item.is-open > .spectrum-Accordion-itemIndicator { transform: matrix(-1, 0, 0, 1, 0, 0) rotate(90deg); }

.spectrum-Accordion-item.is-open > .spectrum-Accordion-itemHeader::after {
      height: calc(100% - var(--spectrum-accordion-item-border-size, var(--spectrum-alias-border-size-thin)));
    }

.spectrum-Accordion-item.is-open > .spectrum-Accordion-itemContent {
      display: block;
    }

.spectrum-Accordion-item.is-disabled .spectrum-Accordion-itemHeader {
      cursor: default;
    }

.spectrum-Accordion-item {
  border-color: var(--spectrum-accordion-border-color, var(--spectrum-global-color-gray-300));
}

.spectrum-Accordion-itemIndicator {
  color: var(--spectrum-accordion-icon-color, var(--spectrum-global-color-gray-600));
}

.spectrum-Accordion-itemHeader {
  color: var(--spectrum-accordion-text-color, var(--spectrum-global-color-gray-700));
}

.spectrum-Accordion-itemHeader:hover {
    color: var(--spectrum-accordion-text-color-hover, var(--spectrum-global-color-gray-900));

    background-color: var(--spectrum-accordion-item-background-color-hover, var(--spectrum-global-color-gray-200));
  }

.spectrum-Accordion-itemHeader:hover + .spectrum-Accordion-itemIndicator {
      color: var(--spectrum-accordion-icon-color-hover, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-Accordion-itemHeader.focus-ring:after {
      background-color: var(--spectrum-accordion-item-border-left-color-key-focus, var(--spectrum-alias-border-color-key-focus));
    }

.spectrum-Accordion-item.is-open .spectrum-Accordion-itemHeader:hover {
        background-color: transparent;
      }

.spectrum-Accordion-item.is-disabled .spectrum-Accordion-itemHeader,
    .spectrum-Accordion-item.is-disabled .spectrum-Accordion-itemHeader:hover,
    .spectrum-Accordion-item.is-disabled .spectrum-Accordion-itemHeader.focus-ring {
      color: var(--spectrum-accordion-text-color-disabled, var(--spectrum-global-color-gray-500));
      background-color: transparent;
    }

.spectrum-Accordion-item.is-disabled .spectrum-Accordion-itemHeader + .spectrum-Accordion-itemIndicator {
      color: var(--spectrum-accordion-icon-color-disabled, var(--spectrum-alias-icon-color-disabled));
    }

@media (forced-colors: active) {
    .spectrum-Accordion-itemHeader.focus-ring {
      outline: 3px solid CanvasText;
    }
}
.spectrum-Accordion-item.svelte-1h85agu{border:none}.spectrum-Accordion-itemContent.svelte-1h85agu{width:97%}.spectrum-Accordion-itemHeader.svelte-1h85agu{text-transform:none;font-weight:var(--font-weight);min-height:auto;display:flex;gap:var(--spacing-m);padding-left:0}.spectrum-Accordion-itemHeaderS.svelte-1h85agu{font-size:1rem}.spectrum-Accordion-itemHeaderM.svelte-1h85agu{font-size:1.2rem}.spectrum-Accordion-itemHeaderL.svelte-1h85agu{font-size:1.5rem}button.svelte-1h85agu:hover{background-color:transparent}.spectrum-ActionGroup {
  --spectrum-actiongroup-button-gap-reset: 0;
  --spectrum-actiongroup-quiet-compact-button-gap: var(
    --spectrum-global-dimension-size-25
  );
}

.spectrum-ActionGroup {
  display: -ms-flexbox;
  display: flex;
  -ms-flex-wrap: wrap;
      flex-wrap: wrap;
}

.spectrum-ActionGroup .spectrum-ActionGroup-item {
    -ms-flex-negative: 0;
        flex-shrink: 0;
  }

.spectrum-ActionGroup:not(.spectrum-ActionGroup--vertical).spectrum-ActionGroup:not(.spectrum-ActionGroup--compact) {
    margin-top: calc(-1 * var(--spectrum-actiongroup-button-gap-y, var(--spectrum-global-dimension-size-100)));
  }

.spectrum-ActionGroup:not(.spectrum-ActionGroup--vertical).spectrum-ActionGroup:not(.spectrum-ActionGroup--compact) .spectrum-ActionGroup-item {
      -ms-flex-negative: 0;
          flex-shrink: 0;
      margin-top: var(--spectrum-actiongroup-button-gap-y, var(--spectrum-global-dimension-size-100));
    }

[dir="ltr"] .spectrum-ActionGroup:not(.spectrum-ActionGroup--vertical).spectrum-ActionGroup:not(.spectrum-ActionGroup--compact) .spectrum-ActionGroup-item:not(:last-child) {
        margin-right: var(--spectrum-actiongroup-button-gap-x, var(--spectrum-global-dimension-size-100));
}

[dir="rtl"] .spectrum-ActionGroup:not(.spectrum-ActionGroup--vertical).spectrum-ActionGroup:not(.spectrum-ActionGroup--compact) .spectrum-ActionGroup-item:not(:last-child) {
        margin-left: var(--spectrum-actiongroup-button-gap-x, var(--spectrum-global-dimension-size-100));
}

.spectrum-ActionGroup--vertical {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-direction: column;
      flex-direction: column;
}

[dir="ltr"] .spectrum-ActionGroup--vertical .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
    margin-left: var(--spectrum-actiongroup-button-gap-reset);
}

[dir="rtl"] .spectrum-ActionGroup--vertical .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
    margin-right: var(--spectrum-actiongroup-button-gap-reset);
}

.spectrum-ActionGroup--vertical .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
    margin-top: var(--spectrum-actiongroup-button-gap-y, var(--spectrum-global-dimension-size-100));
  }

[dir="ltr"] .spectrum-ActionGroup--vertical.spectrum-ActionGroup--vertical {
    margin-left: var(--spectrum-actiongroup-button-gap-reset);
}

[dir="rtl"] .spectrum-ActionGroup--vertical.spectrum-ActionGroup--vertical {
    margin-right: var(--spectrum-actiongroup-button-gap-reset);
}

.spectrum-ActionGroup--vertical.spectrum-ActionGroup--vertical {
    margin-top: var(--spectrum-actiongroup-button-gap-y, var(--spectrum-global-dimension-size-100));
  }

[dir="ltr"] .spectrum-ActionGroup--compact.spectrum-ActionGroup--quiet .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
      margin-left: var(--spectrum-actiongroup-quiet-compact-button-gap);
}

[dir="rtl"] .spectrum-ActionGroup--compact.spectrum-ActionGroup--quiet .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
      margin-right: var(--spectrum-actiongroup-quiet-compact-button-gap);
}

.spectrum-ActionGroup--compact.spectrum-ActionGroup--quiet .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
      margin-top: var(--spectrum-actiongroup-button-gap-reset);
    }

[dir="ltr"] .spectrum-ActionGroup--compact.spectrum-ActionGroup--quiet.spectrum-ActionGroup--vertical .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
        margin-left: var(--spectrum-actiongroup-button-gap-reset);
}

[dir="rtl"] .spectrum-ActionGroup--compact.spectrum-ActionGroup--quiet.spectrum-ActionGroup--vertical .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
        margin-right: var(--spectrum-actiongroup-button-gap-reset);
}

.spectrum-ActionGroup--compact.spectrum-ActionGroup--quiet.spectrum-ActionGroup--vertical .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
        margin-top: var(
          --spectrum-actiongroup-quiet-compact-button-gap
        );
      }

.spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) {
    -ms-flex-wrap: nowrap;
        flex-wrap: nowrap;
  }

.spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item {
      position: relative;
      border-radius: 0;
      z-index: 0;
    }

[dir="ltr"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:first-child {
        border-top-left-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:first-child {
        border-top-right-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="ltr"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:first-child {
        border-bottom-left-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:first-child {
        border-bottom-right-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="ltr"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:first-child {
        margin-right: calc(-1 * var(--spectrum-actionbutton-m-border-size, var(--spectrum-alias-border-size-thin)) / 2);
}

[dir="rtl"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:first-child {
        margin-left: calc(-1 * var(--spectrum-actionbutton-m-border-size, var(--spectrum-alias-border-size-thin)) / 2);
}

[dir="ltr"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:last-child {
        border-top-right-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:last-child {
        border-top-left-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="ltr"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:last-child {
        border-bottom-right-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:last-child {
        border-bottom-left-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="ltr"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:last-child {
        margin-left: calc(-1 * var(--spectrum-actionbutton-m-border-size, var(--spectrum-alias-border-size-thin)) / 2);
}

[dir="rtl"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:last-child {
        margin-right: calc(-1 * var(--spectrum-actionbutton-m-border-size, var(--spectrum-alias-border-size-thin)) / 2);
}

[dir="ltr"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:last-child {
        margin-right: 0;
}

[dir="rtl"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:last-child {
        margin-left: 0;
}

.spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item.is-selected {
        z-index: 1;
      }

.spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item:hover {
        z-index: 2;
      }

.spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item.focus-ring {
        z-index: 3;
      }

[dir="ltr"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
        margin-left: calc(-1 * var(--spectrum-actionbutton-m-border-size, var(--spectrum-alias-border-size-thin)) / 2);
}

[dir="rtl"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
        margin-right: calc(-1 * var(--spectrum-actionbutton-m-border-size, var(--spectrum-alias-border-size-thin)) / 2);
}

[dir="ltr"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
        margin-right: calc(-1 * var(--spectrum-actionbutton-m-border-size, var(--spectrum-alias-border-size-thin)) / 2);
}

[dir="rtl"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
        margin-left: calc(-1 * var(--spectrum-actionbutton-m-border-size, var(--spectrum-alias-border-size-thin)) / 2);
}

.spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet) .spectrum-ActionGroup-item .spectrum-ActionButton-label {
        width: auto;
      }

.spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet).spectrum-ActionGroup--vertical .spectrum-ActionGroup-item {
        border-radius: 0;
      }

.spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet).spectrum-ActionGroup--vertical .spectrum-ActionGroup-item + .spectrum-ActionGroup-item {
          margin-top: calc(-1 * var(--spectrum-actionbutton-m-border-size, var(--spectrum-alias-border-size-thin)) / 2);
          margin-bottom: calc(-1 * var(--spectrum-actionbutton-m-border-size, var(--spectrum-alias-border-size-thin)) / 2);
        }

[dir="ltr"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet).spectrum-ActionGroup--vertical .spectrum-ActionGroup-item:first-child {
          border-top-left-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet).spectrum-ActionGroup--vertical .spectrum-ActionGroup-item:first-child {
          border-top-right-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="ltr"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet).spectrum-ActionGroup--vertical .spectrum-ActionGroup-item:first-child {
          border-top-right-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet).spectrum-ActionGroup--vertical .spectrum-ActionGroup-item:first-child {
          border-top-left-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

.spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet).spectrum-ActionGroup--vertical .spectrum-ActionGroup-item:first-child {
          border-radius: 0;
          margin-bottom: calc(-1 * var(--spectrum-actionbutton-m-border-size, var(--spectrum-alias-border-size-thin)) / 2);
        }

[dir="ltr"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet).spectrum-ActionGroup--vertical .spectrum-ActionGroup-item:last-child {
          border-bottom-left-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet).spectrum-ActionGroup--vertical .spectrum-ActionGroup-item:last-child {
          border-bottom-right-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="ltr"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet).spectrum-ActionGroup--vertical .spectrum-ActionGroup-item:last-child {
          border-bottom-right-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet).spectrum-ActionGroup--vertical .spectrum-ActionGroup-item:last-child {
          border-bottom-left-radius: var(--spectrum-actionbutton-m-border-radius, var(--spectrum-alias-border-radius-regular));
}

.spectrum-ActionGroup--compact:not(.spectrum-ActionGroup--quiet).spectrum-ActionGroup--vertical .spectrum-ActionGroup-item:last-child {
          border-radius: 0;
          margin-top: calc(-1 * var(--spectrum-actionbutton-m-border-size, var(--spectrum-alias-border-size-thin)) / 2);
          margin-bottom: 0;
        }

.spectrum-ActionGroup--justified .spectrum-ActionGroup-item {
  -ms-flex: 1;
      flex: 1;
}
.spectrum-Label {
  display: inline-block;
  position: relative;

  width: auto;

  padding: var(--spectrum-global-dimension-size-50) var(--spectrum-global-dimension-size-125);

  border-radius: var(--spectrum-alias-border-radius-regular, var(--spectrum-global-dimension-size-50));

  font-size: var(--spectrum-global-dimension-size-150);
  line-height: var(--spectrum-global-font-line-height-medium, 1.5);

  cursor: default;

  -webkit-font-smoothing: subpixel-antialiased;
  -moz-osx-font-smoothing: auto;
  font-smoothing: subpixel-antialiased;
}

.spectrum-Label--large {
  font-size: var(--spectrum-global-dimension-size-175);
  padding: var(--spectrum-global-dimension-size-100) var(--spectrum-global-dimension-size-150);
}

.spectrum-Label--small {
  font-size: var(--spectrum-global-dimension-font-size-50);
  padding: var(--spectrum-global-dimension-size-40) var(--spectrum-global-dimension-size-85);
}

.spectrum-Label {
  color: var(--spectrum-label-colored-text-color, var(--spectrum-global-color-static-white));
}

.spectrum-Label--inactive,
.spectrum-Label--grey {
  background-color: var(--spectrum-label-colored-gray-background-color, var(--spectrum-global-color-static-gray-700));
}

.spectrum-Label--red {
  background-color: var(--spectrum-label-colored-red-background-color, var(--spectrum-global-color-static-red-600));
}

.spectrum-Label--orange, .spectrum-Label--or {
  background-color: var(--spectrum-label-colored-orange-background-color, var(--spectrum-global-color-static-orange-600));
}

.spectrum-Label--yellow {
  background-color: var(--spectrum-label-colored-yellow-background-color, var(--spectrum-global-color-yellow-400));
}

.spectrum-Label--seafoam  {
  background-color: var(--spectrum-label-colored-seafoam-background-color, var(--spectrum-global-color-seafoam-400));
}

.spectrum-Label--green {
  background-color: var(--spectrum-label-colored-green-background-color, var(--spectrum-global-color-static-green-600));
}

.spectrum-Label--blue, .spectrum-Label--active, .spectrum-Label--and  {
  background-color: var(--spectrum-label-colored-blue-background-color, var(--spectrum-global-color-static-blue));
}

.spectrum-Label--fuchsia  {
  background-color: var(--spectrum-label-colored-fuchsia-background-color, var(--spectrum-global-color-fuchsia-400));
}
.spectrum-Label--grey.svelte-35zeo5{background-color:var(--spectrum-global-color-gray-500);font-weight:600}.hoverable.svelte-35zeo5:hover{cursor:pointer}.spectrum-Toast.svelte-n9kell{pointer-events:all;width:100%}.spectrum-Toast--neutral.svelte-n9kell{background-color:var(--grey-2)}.spectrum-Button.svelte-n9kell{border:1px solid rgba(255, 255, 255, 0.2)}.row-content.svelte-n9kell{display:flex}.link.svelte-n9kell{background:none;border:none;margin:0;margin-left:0.5em;padding:0;cursor:pointer;color:white;font-weight:600}u.svelte-n9kell{font-weight:600}.spectrum-Toast.svelte-n9kell{border-radius:0px}.spectrum-Toast-body.svelte-n9kell{display:flex;justify-content:center;align-items:center}.spectrum-Toast {
  --spectrum-toast-icon-padding-y: var(--spectrum-global-dimension-size-85);
  --spectrum-toast-neutral-content-padding-top: var(
    --spectrum-global-dimension-size-65
  );
  --spectrum-toast-content-padding-bottom: var(
    --spectrum-global-dimension-size-65
  );

  --spectrum-toast-button-margin-right: var(
    --spectrum-global-dimension-size-130
  );
}

[dir="ltr"] .spectrum-Toast {
  padding-right: var(--spectrum-toast-neutral-padding-right, var(--spectrum-global-dimension-size-100));
}

[dir="rtl"] .spectrum-Toast {
  padding-left: var(--spectrum-toast-neutral-padding-right, var(--spectrum-global-dimension-size-100));
}

[dir="ltr"] .spectrum-Toast {
  padding-left: var(--spectrum-toast-neutral-padding-left, var(--spectrum-global-dimension-size-200));
}

[dir="rtl"] .spectrum-Toast {
  padding-right: var(--spectrum-toast-neutral-padding-left, var(--spectrum-global-dimension-size-200));
}

.spectrum-Toast {
  box-sizing: border-box;
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-direction: row;
      flex-direction: row;
  -ms-flex-align: stretch;
      align-items: stretch;

  border-radius: var(--spectrum-toast-neutral-border-radius, var(--spectrum-global-dimension-static-size-50));

  padding-top: var(--spectrum-toast-neutral-padding-y, var(--spectrum-global-dimension-size-100));

  padding-bottom: var(--spectrum-toast-neutral-padding-y, var(--spectrum-global-dimension-size-100));

  font-size: var(--spectrum-toast-neutral-text-size, var(--spectrum-alias-font-size-default));
  font-weight: var(--spectrum-toast-neutral-text-font-weight, var(--spectrum-global-font-weight-bold));
  -webkit-font-smoothing: antialiased;
}

[dir="ltr"] .spectrum-Toast-typeIcon {
  margin-right: var(--spectrum-toast-neutral-icon-padding-right, var(--spectrum-global-dimension-size-150));
}

[dir="rtl"] .spectrum-Toast-typeIcon {
  margin-left: var(--spectrum-toast-neutral-icon-padding-right, var(--spectrum-global-dimension-size-150));
}

[dir="ltr"] .spectrum-Toast-typeIcon {
  margin-left: 0;
}

[dir="rtl"] .spectrum-Toast-typeIcon {
  margin-right: 0;
}

.spectrum-Toast-typeIcon {
  -ms-flex-negative: 0;
      flex-shrink: 0;
  -ms-flex-positive: 0;
      flex-grow: 0;

  margin-top: var(--spectrum-toast-icon-padding-y);

  margin-bottom: var(--spectrum-toast-icon-padding-y);
}

[dir="ltr"] .spectrum-Toast-content {
  padding-right: var(--spectrum-toast-neutral-content-padding-right, var(--spectrum-global-dimension-size-200));
}

[dir="rtl"] .spectrum-Toast-content {
  padding-left: var(--spectrum-toast-neutral-content-padding-right, var(--spectrum-global-dimension-size-200));
}

[dir="ltr"] .spectrum-Toast-content {
  padding-left: 0;
}

[dir="rtl"] .spectrum-Toast-content {
  padding-right: 0;
}

[dir="ltr"] .spectrum-Toast-content {

  text-align: left;
}

[dir="rtl"] .spectrum-Toast-content {

  text-align: right;
}

.spectrum-Toast-content {
  -ms-flex: 1 1 auto;
      flex: 1 1 auto;
  display: inline-block;
  box-sizing: border-box;

  padding-top: var(--spectrum-toast-neutral-content-padding-top, var(--spectrum-global-dimension-size-65));
  padding-bottom: var(--spectrum-toast-content-padding-bottom);

  font-size: var(--spectrum-toast-info-text-size, var(--spectrum-alias-font-size-default));
  font-weight: var(--spectrum-toast-info-text-font-weight, var(--spectrum-global-font-weight-bold));
  line-height: var(--spectrum-toast-info-text-line-height, var(--spectrum-alias-body-text-line-height));
}

.spectrum-Toast-buttons {
  display: -ms-flexbox;
  display: flex;
  -ms-flex: 0 0 auto;
      flex: 0 0 auto;
  -ms-flex-align: start;
      align-items: flex-start;
}

[dir="ltr"] .spectrum-Toast-buttons .spectrum-Button + .spectrum-Button,[dir="ltr"] 
    .spectrum-Toast-buttons .spectrum-Button + .spectrum-ClearButton,[dir="ltr"] 
    .spectrum-Toast-buttons .spectrum-ClearButton + .spectrum-Button,[dir="ltr"] 
    .spectrum-Toast-buttons .spectrum-ClearButton + .spectrum-ClearButton {
      margin-left: var(--spectrum-toast-neutral-button-gap-x, var(--spectrum-global-dimension-size-100));
}

[dir="rtl"] .spectrum-Toast-buttons .spectrum-Button + .spectrum-Button,[dir="rtl"] 
    .spectrum-Toast-buttons .spectrum-Button + .spectrum-ClearButton,[dir="rtl"] 
    .spectrum-Toast-buttons .spectrum-ClearButton + .spectrum-Button,[dir="rtl"] 
    .spectrum-Toast-buttons .spectrum-ClearButton + .spectrum-ClearButton {
      margin-right: var(--spectrum-toast-neutral-button-gap-x, var(--spectrum-global-dimension-size-100));
}

.spectrum-Toast-body {
  -ms-flex: 1 1 auto;
      flex: 1 1 auto;
  -ms-flex-item-align: center;
      -ms-grid-row-align: center;
      align-self: center;
}

[dir="ltr"] .spectrum-Toast-body .spectrum-Button {
    float: right;
}

[dir="rtl"] .spectrum-Toast-body .spectrum-Button {
    float: left;
}

[dir="ltr"] .spectrum-Toast-body .spectrum-Button {
    margin-right: var(--spectrum-toast-button-margin-right);
}

[dir="rtl"] .spectrum-Toast-body .spectrum-Button {
    margin-left: var(--spectrum-toast-button-margin-right);
}

[dir="ltr"] .spectrum-Toast-body + .spectrum-Toast-buttons {
    padding-left: var(--spectrum-toast-neutral-padding-right, var(--spectrum-global-dimension-size-100));
}

[dir="rtl"] .spectrum-Toast-body + .spectrum-Toast-buttons {
    padding-right: var(--spectrum-toast-neutral-padding-right, var(--spectrum-global-dimension-size-100));
}

[dir="ltr"] .spectrum-Toast-body + .spectrum-Toast-buttons {

    border-left-width: 1px;
}

[dir="rtl"] .spectrum-Toast-body + .spectrum-Toast-buttons {

    border-right-width: 1px;
}

[dir="ltr"] .spectrum-Toast-body + .spectrum-Toast-buttons {
    border-left-style: solid;
}

[dir="rtl"] .spectrum-Toast-body + .spectrum-Toast-buttons {
    border-right-style: solid;
}

.spectrum-Toast {
  background-color: var(--spectrum-toast-neutral-background-color, var(--spectrum-semantic-neutral-background-color-default));
  color: var(--spectrum-toast-neutral-background-color, var(--spectrum-semantic-neutral-background-color-default));
}

.spectrum-Toast-content {
  color: var(--spectrum-toast-neutral-text-color, var(--spectrum-global-color-static-white));
}

.spectrum-Toast-typeIcon {
  color: white;
}

[dir="ltr"] .spectrum-Toast-buttons {
  border-left-color: rgba(255, 255, 255, 0.2);
}

[dir="rtl"] .spectrum-Toast-buttons {
  border-right-color: rgba(255, 255, 255, 0.2);
}

.spectrum-Toast--warning {
  background-color: var(--spectrum-toast-warning-background-color, var(--spectrum-global-color-static-orange-700));
  color: var(--spectrum-toast-warning-background-color, var(--spectrum-global-color-static-orange-700));
}

.spectrum-Toast--warning .spectrum-Toast-closeButton.focus-ring:not(:active) {
      color: var(--spectrum-toast-warning-background-color, var(--spectrum-global-color-static-orange-700));
    }

.spectrum-Toast--negative,
/** @deprecated */.spectrum-Toast--error {
  background-color: var(--spectrum-toast-negative-background-color, var(--spectrum-semantic-negative-color-background));
  color: var(--spectrum-toast-negative-background-color, var(--spectrum-semantic-negative-color-background));
}

.spectrum-Toast--negative .spectrum-Toast-closeButton.focus-ring:not(:active), .spectrum-Toast--error .spectrum-Toast-closeButton.focus-ring:not(:active) {
      color: var(--spectrum-toast-negative-background-color, var(--spectrum-semantic-negative-color-background));
    }

.spectrum-Toast--info {
  background-color: var(--spectrum-toast-info-background-color, var(--spectrum-semantic-informative-color-background));
  color: var(--spectrum-toast-info-background-color, var(--spectrum-semantic-informative-color-background));
}

.spectrum-Toast--info .spectrum-Toast-closeButton.focus-ring:not(:active) {
      color: var(--spectrum-toast-info-background-color, var(--spectrum-semantic-informative-color-background));
    }

.spectrum-Toast--positive,
/** @deprecated */.spectrum-Toast--success {
  background-color: var(--spectrum-toast-positive-background-color, var(--spectrum-semantic-positive-color-background));
  color: var(--spectrum-toast-positive-background-color, var(--spectrum-semantic-positive-color-background));
}

.spectrum-Toast--positive .spectrum-Toast-closeButton.focus-ring:not(:active), .spectrum-Toast--success .spectrum-Toast-closeButton.focus-ring:not(:active) {
      color: var(--spectrum-toast-positive-background-color, var(--spectrum-semantic-positive-color-background));
    }
.banner.svelte-j1ssay{pointer-events:none;width:100%}.spectrum-LogicButton,
.spectrum-ClearButton,
.spectrum-Button {
  --spectrum-button-line-height: 1.3;
  position: relative;

  display: -ms-inline-flexbox;

  display: inline-flex;
  box-sizing: border-box;

  -ms-flex-align: center;

      align-items: center;
  -ms-flex-pack: center;
      justify-content: center;
  overflow: visible;
  margin: 0;

  border-style: solid;
  text-transform: none;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  -webkit-appearance: button;
  vertical-align: top;

  transition: background var(--spectrum-global-animation-duration-100, 130ms) ease-out,
    border-color var(--spectrum-global-animation-duration-100, 130ms) ease-out,
    color var(--spectrum-global-animation-duration-100, 130ms) ease-out,
    box-shadow var(--spectrum-global-animation-duration-100, 130ms) ease-out;

  text-decoration: none;
  font-family: var(--spectrum-alias-body-text-font-family, var(--spectrum-global-font-family-base));

  line-height: var(--spectrum-button-line-height);

  -moz-user-select: none;

   -ms-user-select: none;

       user-select: none;
  -webkit-user-select: none;

  cursor: pointer;
}

.spectrum-LogicButton:focus,
.spectrum-ClearButton:focus,
.spectrum-Button:focus {
    outline: none;
  }

.spectrum-LogicButton::-moz-focus-inner,
.spectrum-ClearButton::-moz-focus-inner,
.spectrum-Button::-moz-focus-inner {
    border: 0;
    border-style: none;
    padding: 0;
    margin-top: -2px;
    margin-bottom: -2px;
  }

.spectrum-LogicButton:disabled,
.spectrum-ClearButton:disabled,
.spectrum-Button:disabled {
    cursor: default;
  }

.spectrum-Button .spectrum-Icon {
  max-height: 100%;
  -ms-flex-negative: 0;
      flex-shrink: 0;
}

.spectrum-LogicButton:after,
.spectrum-ClearButton:after,
.spectrum-Button:after {
    border-radius: calc(var(--spectrum-button-primary-border-radius) + var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25)));
    content: "";
    display: block;
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    top: 0;
    margin: calc(var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25)) * -1);
    transition: opacity var(--spectrum-global-animation-duration-100, 130ms) ease-out,
                margin var(--spectrum-global-animation-duration-100, 130ms) ease-out;
  }

.spectrum-LogicButton.focus-ring:after,
.spectrum-ClearButton.focus-ring:after,
.spectrum-Button.focus-ring:after {
      margin: calc(var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25)) * -2);
    }

a.spectrum-Button {
  -webkit-appearance: none;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
}

.spectrum-Button-label {
  -ms-flex-item-align: center;
      -ms-grid-row-align: center;
      align-self: center;
  justify-self: center;
  text-align: center;
}

.spectrum-Button-label:empty {
    display: none;
  }

.spectrum-LogicButton {

  height: var(--spectrum-logicbutton-and-height, 24px);
  padding: var(--spectrum-logicbutton-and-padding-x, var(--spectrum-global-dimension-size-100));

  border-width: var(--spectrum-logicbutton-and-border-size, var(--spectrum-alias-border-size-thick));
  border-radius: var(--spectrum-logicbutton-and-border-radius, var(--spectrum-alias-border-radius-regular));

  font-size: var(--spectrum-logicbutton-and-text-size, var(--spectrum-alias-font-size-default));
  font-weight: var(--spectrum-logicbutton-and-text-font-weight, var(--spectrum-global-font-weight-bold));
  line-height: 0;
}

.spectrum-LogicButton:after {
    border-radius: calc(var(--spectrum-logicbutton-and-border-radius, var(--spectrum-alias-border-radius-regular)) + var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25)));
  }

.spectrum-LogicButton.focus-ring:after, .spectrum-LogicButton.is-focused:after {
      box-shadow: 0 0 0 var(--spectrum-button-primary-m-focus-ring-size-key-focus, var(--spectrum-alias-focus-ring-size)) var(--spectrum-button-primary-m-focus-ring-color-key-focus, var(--spectrum-alias-focus-ring-color));
    }

.spectrum-ClearButton {
  background-color: var(--spectrum-clearbutton-medium-background-color, var(--spectrum-alias-background-color-transparent));

  color: var(--spectrum-clearbutton-medium-icon-color, var(--spectrum-alias-icon-color));
}

.spectrum-ClearButton:hover {
    background-color: var(--spectrum-clearbutton-medium-background-color-hover, var(--spectrum-alias-background-color-transparent));

    color: var(--spectrum-clearbutton-medium-icon-color-hover, var(--spectrum-alias-icon-color-hover));
  }

.spectrum-ClearButton:active {
    background-color: var(--spectrum-clearbutton-medium-background-color-down, var(--spectrum-alias-background-color-transparent));

    color: var(--spectrum-clearbutton-medium-icon-color-down, var(--spectrum-alias-icon-color-down));
  }

.spectrum-ClearButton.focus-ring {
    background-color: var(--spectrum-clearbutton-medium-background-color-key-focus, var(--spectrum-alias-background-color-transparent));

    color: var(--spectrum-clearbutton-medium-icon-color-key-focus, var(--spectrum-alias-icon-color-focus));
  }

.spectrum-ClearButton:disabled,
  .spectrum-ClearButton.is-disabled {
    background-color: var(--spectrum-clearbutton-medium-background-color-disabled, var(--spectrum-alias-background-color-transparent));

    color: var(--spectrum-clearbutton-medium-icon-color-disabled, var(--spectrum-alias-icon-color-disabled));
  }

.spectrum-LogicButton--and {
  background-color: var(--spectrum-logicbutton-and-background-color, var(--spectrum-global-color-blue-500));
  border-color: var(--spectrum-logicbutton-and-border-color, var(--spectrum-global-color-blue-500));
  color: var(--spectrum-logicbutton-and-text-color, var(--spectrum-global-color-static-white));
}

.spectrum-LogicButton--and:hover {
    background-color: var(--spectrum-logicbutton-and-background-color-hover, var(--spectrum-global-color-blue-700));
    border-color: var(--spectrum-logicbutton-and-border-color-hover, var(--spectrum-global-color-blue-700));
    color: var(--spectrum-logicbutton-and-text-color, var(--spectrum-global-color-static-white));
  }

.spectrum-LogicButton--and:disabled,
  .spectrum-LogicButton--and.is-disabled {
    background-color: var(--spectrum-logicbutton-and-background-color-disabled, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-logicbutton-and-border-color-disabled, var(--spectrum-global-color-gray-200));
    color: var(--spectrum-logicbutton-and-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }

.spectrum-LogicButton--or {
  background-color: var(--spectrum-logicbutton-or-background-color, var(--spectrum-global-color-magenta-500));
  border-color: var(--spectrum-logicbutton-or-border-color, var(--spectrum-global-color-magenta-500));
  color: var(--spectrum-logicbutton-or-text-color, var(--spectrum-global-color-static-white));
}

.spectrum-LogicButton--or:hover {
    background-color: var(--spectrum-logicbutton-or-background-color-hover, var(--spectrum-global-color-magenta-700));
    border-color: var(--spectrum-logicbutton-or-border-color-hover, var(--spectrum-global-color-magenta-700));
    color: var(--spectrum-logicbutton-or-text-color, var(--spectrum-global-color-static-white));
  }

.spectrum-LogicButton--or:disabled,
  .spectrum-LogicButton--or.is-disabled {
    background-color: var(--spectrum-button-secondary-m-background-color-disabled, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-button-secondary-m-border-color-disabled, var(--spectrum-global-color-gray-200));
    color: var(--spectrum-logicbutton-and-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  }

.spectrum-ClearButton {

  width: var(--spectrum-clearbutton-medium-width, var(--spectrum-alias-single-line-height));
  height: var(--spectrum-clearbutton-medium-height, var(--spectrum-alias-single-line-height));

  border-radius: 100%;

  padding: 0;
  margin: 0;

  border: none;
}

.spectrum-ClearButton > .spectrum-Icon {
    margin-top: 0;
    margin-bottom: 0;
    margin-left: auto;
    margin-right: auto;
  }

.spectrum-ClearButton--overBackground.focus-ring:after {
      margin: calc(var(--spectrum-alias-focus-ring-gap, var(--spectrum-global-dimension-static-size-25)) * -1);
    }

@media screen and (-ms-high-contrast: active), (-ms-high-contrast: none) {
    .spectrum-ClearButton > .spectrum-Icon {
      margin: 0;
    }
}

.spectrum-ClearButton--small {
  width: var(--spectrum-clearbutton-small-width, var(--spectrum-global-dimension-size-300));
  height: var(--spectrum-clearbutton-small-height, var(--spectrum-global-dimension-size-300));
}

.spectrum-Button--sizeS {
  --spectrum-button-primary-focus-ring-size-key-focus: var(--spectrum-button-primary-s-focus-ring-size-key-focus, var(--spectrum-alias-focus-ring-size));
  --spectrum-button-primary-text-font-weight: var(--spectrum-button-primary-s-text-font-weight, var(--spectrum-global-font-weight-bold));
  --spectrum-button-primary-text-line-height: var(--spectrum-button-primary-s-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-button-primary-border-size: var(--spectrum-button-primary-s-border-size, var(--spectrum-alias-border-size-thick));
  --spectrum-button-primary-text-size: var(--spectrum-button-primary-s-text-size, var(--spectrum-alias-item-text-size-s));
  --spectrum-button-primary-icon-gap: var(--spectrum-button-primary-s-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-s));
  --spectrum-button-primary-height: var(--spectrum-button-primary-s-height, var(--spectrum-alias-item-height-s));
  --spectrum-button-primary-padding-left: var(--spectrum-button-primary-s-padding-left, var(--spectrum-alias-item-rounded-workflow-padding-left-s));
  --spectrum-button-primary-border-radius: var(--spectrum-button-primary-s-border-radius, var(--spectrum-alias-item-rounded-border-radius-s));
  --spectrum-button-primary-min-width: var(--spectrum-button-primary-s-min-width, var(--spectrum-global-dimension-size-675));
  --spectrum-button-primary-textonly-padding-left: var(--spectrum-button-primary-s-textonly-padding-left, var(--spectrum-alias-item-rounded-padding-s));
  --spectrum-button-primary-textonly-padding-right: var(--spectrum-button-primary-s-textonly-padding-right, var(--spectrum-alias-item-rounded-padding-s));
  --spectrum-button-primary-text-padding-top: calc(var(--spectrum-button-primary-s-text-padding-top, var(--spectrum-alias-item-text-padding-top-s)) - 3px);
}

.spectrum-Button--sizeM {
  --spectrum-button-primary-min-width: var(--spectrum-button-primary-m-min-width);
  --spectrum-button-primary-focus-ring-size-key-focus: var(--spectrum-button-primary-m-focus-ring-size-key-focus, var(--spectrum-alias-focus-ring-size));
  --spectrum-button-primary-text-font-weight: var(--spectrum-button-primary-m-text-font-weight, var(--spectrum-global-font-weight-bold));
  --spectrum-button-primary-text-line-height: var(--spectrum-button-primary-m-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-button-primary-border-size: var(--spectrum-button-primary-m-border-size, var(--spectrum-alias-border-size-thick));
  --spectrum-button-primary-text-size: var(--spectrum-button-primary-m-text-size, var(--spectrum-alias-item-text-size-m));
  --spectrum-button-primary-text-padding-top: var(--spectrum-button-primary-m-text-padding-top, var(--spectrum-alias-item-text-padding-top-m));
  --spectrum-button-primary-height: var(--spectrum-button-primary-m-height, var(--spectrum-alias-item-height-m));
  --spectrum-button-primary-icon-gap: var(--spectrum-button-primary-m-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-m));
  --spectrum-button-primary-padding-left: var(--spectrum-button-primary-m-padding-left, var(--spectrum-alias-item-rounded-workflow-padding-left-m));
  --spectrum-button-primary-border-radius: var(--spectrum-button-primary-m-border-radius, var(--spectrum-alias-item-rounded-border-radius-m));
  --spectrum-button-primary-textonly-padding-left: var(--spectrum-button-primary-m-textonly-padding-left, var(--spectrum-alias-item-rounded-padding-m));
  --spectrum-button-primary-textonly-padding-right: var(--spectrum-button-primary-m-textonly-padding-right, var(--spectrum-alias-item-rounded-padding-m));
}

.spectrum-Button--sizeL {
  --spectrum-button-primary-focus-ring-size-key-focus: var(--spectrum-button-primary-l-focus-ring-size-key-focus, var(--spectrum-alias-focus-ring-size));
  --spectrum-button-primary-text-font-weight: var(--spectrum-button-primary-l-text-font-weight, var(--spectrum-global-font-weight-bold));
  --spectrum-button-primary-text-line-height: var(--spectrum-button-primary-l-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-button-primary-border-size: var(--spectrum-button-primary-l-border-size, var(--spectrum-alias-border-size-thick));
  --spectrum-button-primary-text-size: var(--spectrum-button-primary-l-text-size, var(--spectrum-alias-item-text-size-l));
  --spectrum-button-primary-text-padding-top: var(--spectrum-button-primary-l-text-padding-top, var(--spectrum-alias-item-text-padding-top-l));
  --spectrum-button-primary-icon-gap: var(--spectrum-button-primary-l-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-l));
  --spectrum-button-primary-height: var(--spectrum-button-primary-l-height, var(--spectrum-alias-item-height-l));
  --spectrum-button-primary-padding-left: var(--spectrum-button-primary-l-padding-left, var(--spectrum-alias-item-rounded-workflow-padding-left-l));
  --spectrum-button-primary-border-radius: var(--spectrum-button-primary-l-border-radius, var(--spectrum-alias-item-rounded-border-radius-l));
  --spectrum-button-primary-min-width: var(--spectrum-button-primary-l-min-width, var(--spectrum-global-dimension-size-1125));
  --spectrum-button-primary-textonly-padding-left: var(--spectrum-button-primary-l-textonly-padding-left, var(--spectrum-alias-item-rounded-padding-l));
  --spectrum-button-primary-textonly-padding-right: var(--spectrum-button-primary-l-textonly-padding-right, var(--spectrum-alias-item-rounded-padding-l));
}

.spectrum-Button--sizeXL {
  --spectrum-button-primary-focus-ring-size-key-focus: var(--spectrum-button-primary-xl-focus-ring-size-key-focus, var(--spectrum-alias-focus-ring-size));
  --spectrum-button-primary-text-font-weight: var(--spectrum-button-primary-xl-text-font-weight, var(--spectrum-global-font-weight-bold));
  --spectrum-button-primary-text-line-height: var(--spectrum-button-primary-xl-text-line-height, var(--spectrum-alias-component-text-line-height));
  --spectrum-button-primary-border-size: var(--spectrum-button-primary-xl-border-size, var(--spectrum-alias-border-size-thick));
  --spectrum-button-primary-icon-gap: var(--spectrum-button-primary-xl-icon-gap, var(--spectrum-alias-item-workflow-icon-gap-l));
  --spectrum-button-primary-text-size: var(--spectrum-button-primary-xl-text-size, var(--spectrum-alias-item-text-size-xl));
  --spectrum-button-primary-text-padding-top: var(--spectrum-button-primary-xl-text-padding-top, var(--spectrum-alias-item-text-padding-top-xl));
  --spectrum-button-primary-height: var(--spectrum-button-primary-xl-height, var(--spectrum-alias-item-height-xl));
  --spectrum-button-primary-padding-left: var(--spectrum-button-primary-xl-padding-left, var(--spectrum-alias-item-rounded-workflow-padding-left-xl));
  --spectrum-button-primary-border-radius: var(--spectrum-button-primary-xl-border-radius, var(--spectrum-alias-item-rounded-border-radius-xl));
  --spectrum-button-primary-min-width: var(--spectrum-button-primary-xl-min-width, var(--spectrum-global-dimension-size-1250));
  --spectrum-button-primary-textonly-padding-left: var(--spectrum-button-primary-xl-textonly-padding-left, var(--spectrum-alias-item-rounded-padding-xl));
  --spectrum-button-primary-textonly-padding-right: var(--spectrum-button-primary-xl-textonly-padding-right, var(--spectrum-alias-item-rounded-padding-xl));
}

.spectrum-Button {
  --spectrum-button-primary-padding-left-adjusted: calc(var(--spectrum-button-primary-padding-left) - var(--spectrum-button-primary-border-size));
  --spectrum-button-primary-textonly-padding-left-adjusted: calc(var(--spectrum-button-primary-textonly-padding-left) - var(--spectrum-button-primary-border-size));
  --spectrum-button-primary-textonly-padding-right-adjusted: calc(var(--spectrum-button-primary-textonly-padding-right) - var(--spectrum-button-primary-border-size));
  --spectrum-button-padding-y: calc(var(--spectrum-button-primary-text-padding-top) - 1px);
}

[dir="ltr"] .spectrum-Button {
  padding-left: var(--spectrum-button-primary-textonly-padding-left-adjusted);
  padding-right: var(--spectrum-button-primary-textonly-padding-right-adjusted);
}

[dir="rtl"] .spectrum-Button {
  padding-right: var(--spectrum-button-primary-textonly-padding-left-adjusted);
  padding-left: var(--spectrum-button-primary-textonly-padding-right-adjusted);
}

.spectrum-Button {

  border-width: var(--spectrum-button-primary-border-size);
  border-style: solid;
  border-radius: var(--spectrum-button-primary-border-radius);

  min-height: var(--spectrum-button-primary-height);
  height: auto;
  min-width: var(--spectrum-button-primary-min-width);
  padding-bottom: calc(var(--spectrum-button-padding-y) + 1px);
  padding-top: calc(var(--spectrum-button-padding-y) - 1px);

  font-size: var(--spectrum-button-primary-text-size);
  font-weight: var(--spectrum-button-primary-text-font-weight);
}

.spectrum-Button:hover,
  .spectrum-Button:active {
    box-shadow: none;
  }

[dir="ltr"] .spectrum-Button .spectrum-Icon {
    margin-left: calc(-1 * (var(--spectrum-button-primary-textonly-padding-left-adjusted) - var(--spectrum-button-primary-padding-left-adjusted)));
}

[dir="rtl"] .spectrum-Button .spectrum-Icon {
    margin-right: calc(-1 * (var(--spectrum-button-primary-textonly-padding-left-adjusted) - var(--spectrum-button-primary-padding-left-adjusted)));
}

[dir="ltr"] .spectrum-Button .spectrum-Icon + .spectrum-Button-label {
    padding-left: var(--spectrum-button-primary-icon-gap);
}

[dir="rtl"] .spectrum-Button .spectrum-Icon + .spectrum-Button-label {
    padding-right: var(--spectrum-button-primary-icon-gap);
}

[dir="ltr"] .spectrum-Button .spectrum-Icon + .spectrum-Button-label {
    padding-right: 0;
}

[dir="rtl"] .spectrum-Button .spectrum-Icon + .spectrum-Button-label {
    padding-left: 0;
}

.spectrum-Button-label {

  line-height: var(--spectrum-button-primary-text-line-height);
}

.spectrum-LogicButton.focus-ring:after, .spectrum-LogicButton.is-focused:after, .spectrum-Button.focus-ring:after, .spectrum-Button.is-focused:after {
      box-shadow: 0 0 0 var(--spectrum-button-primary-focus-ring-size-key-focus) var(--spectrum-button-primary-m-focus-ring-color-key-focus, var(--spectrum-alias-focus-ring-color));
    }

.spectrum-Button--cta {
  background-color: var(--spectrum-button-cta-m-background-color, var(--spectrum-semantic-cta-color-background-default));
  border-color: var(--spectrum-button-cta-m-border-color, var(--spectrum-semantic-cta-color-background-default));
  color: var(--spectrum-button-cta-m-text-color, var(--spectrum-global-color-static-white));
}

.spectrum-Button--cta:hover {
    background-color: var(--spectrum-button-cta-m-background-color-hover, var(--spectrum-semantic-cta-color-background-hover));
    border-color: var(--spectrum-button-cta-m-border-color-hover, var(--spectrum-semantic-cta-color-background-hover));
    color: var(--spectrum-button-cta-m-text-color-hover, var(--spectrum-global-color-static-white));
  }

.spectrum-Button--cta.focus-ring {
    background-color: var(--spectrum-button-cta-m-background-color-key-focus, var(--spectrum-semantic-cta-color-background-hover));
    border-color: var(--spectrum-button-cta-m-border-color-key-focus, var(--spectrum-semantic-cta-color-background-hover));
    color: var(--spectrum-button-cta-m-text-color-key-focus, var(--spectrum-global-color-static-white));
  }

.spectrum-Button--cta:active {
    background-color: var(--spectrum-button-cta-m-background-color-down, var(--spectrum-semantic-cta-color-background-down));
    border-color: var(--spectrum-button-cta-m-border-color-down, var(--spectrum-semantic-cta-color-background-down));
    color: var(--spectrum-button-cta-m-text-color-down, var(--spectrum-global-color-static-white));
  }

.spectrum-Button--cta:disabled,
  .spectrum-Button--cta.is-disabled {
    background-color: var(--spectrum-button-cta-m-background-color-disabled, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-button-cta-m-border-color-disabled, var(--spectrum-global-color-gray-200));
    color: var(--spectrum-button-cta-m-text-color-disabled, var(--spectrum-global-color-gray-500));
  }

.spectrum-Button--primary {
  background-color: var(--spectrum-button-primary-m-background-color, var(--spectrum-alias-background-color-transparent));
  border-color: var(--spectrum-button-primary-m-border-color, var(--spectrum-global-color-gray-800));
  color: var(--spectrum-button-primary-m-text-color, var(--spectrum-global-color-gray-800));
}

.spectrum-Button--primary:hover {
    background-color: var(--spectrum-button-primary-m-background-color-hover, var(--spectrum-global-color-gray-800));
    border-color: var(--spectrum-button-primary-m-border-color-hover, var(--spectrum-global-color-gray-800));
    color: var(--spectrum-button-primary-m-text-color-hover, var(--spectrum-global-color-gray-50));
  }

.spectrum-Button--primary.focus-ring {
    background-color: var(--spectrum-button-primary-m-background-color-key-focus, var(--spectrum-global-color-gray-800));
    border-color: var(--spectrum-button-primary-m-border-color-key-focus, var(--spectrum-global-color-gray-800));
    color: var(--spectrum-button-primary-m-text-color-key-focus, var(--spectrum-global-color-gray-50));
  }

.spectrum-Button--primary:active {
    background-color: var(--spectrum-button-primary-m-background-color-down, var(--spectrum-global-color-gray-900));
    border-color: var(--spectrum-button-primary-m-border-color-down, var(--spectrum-global-color-gray-900));
    color: var(--spectrum-button-primary-m-text-color-down, var(--spectrum-global-color-gray-50));
  }

.spectrum-Button--primary:disabled,
  .spectrum-Button--primary.is-disabled {
    background-color: var(--spectrum-button-primary-m-background-color-disabled, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-button-primary-m-border-color-disabled, var(--spectrum-global-color-gray-200));
    color: var(--spectrum-button-primary-m-text-color-disabled, var(--spectrum-global-color-gray-500));
  }

.spectrum-Button--secondary {
  background-color: var(--spectrum-button-secondary-m-background-color, var(--spectrum-alias-background-color-transparent));
  border-color: var(--spectrum-button-secondary-m-border-color, var(--spectrum-global-color-gray-700));
  color: var(--spectrum-button-secondary-m-text-color, var(--spectrum-global-color-gray-700));
}

.spectrum-Button--secondary:hover {
    background-color: var(--spectrum-button-secondary-m-background-color-hover, var(--spectrum-global-color-gray-700));
    border-color: var(--spectrum-button-secondary-m-border-color-hover, var(--spectrum-global-color-gray-700));
    color: var(--spectrum-button-secondary-m-text-color-hover, var(--spectrum-global-color-gray-50));
  }

.spectrum-Button--secondary.focus-ring {
    background-color: var(--spectrum-button-secondary-m-background-color-key-focus, var(--spectrum-global-color-gray-700));
    border-color: var(--spectrum-button-secondary-m-border-color-key-focus, var(--spectrum-global-color-gray-700));
    color: var(--spectrum-button-secondary-m-text-color-key-focus, var(--spectrum-global-color-gray-50));
  }

.spectrum-Button--secondary:active {
    background-color: var(--spectrum-button-secondary-m-background-color-down, var(--spectrum-global-color-gray-800));
    border-color: var(--spectrum-button-secondary-m-border-color-down, var(--spectrum-global-color-gray-800));
    color: var(--spectrum-button-secondary-m-text-color-down, var(--spectrum-global-color-gray-50));
  }

.spectrum-Button--secondary:disabled,
  .spectrum-Button--secondary.is-disabled {
    background-color: var(--spectrum-button-secondary-m-background-color-disabled, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-button-secondary-m-border-color-disabled, var(--spectrum-global-color-gray-200));
    color: var(--spectrum-button-secondary-m-text-color-disabled, var(--spectrum-global-color-gray-500));
  }

.spectrum-Button--warning {
  background-color: var(--spectrum-button-warning-m-background-color, var(--spectrum-alias-background-color-transparent));
  border-color: var(--spectrum-button-warning-m-border-color, var(--spectrum-semantic-negative-color-text-small));
  color: var(--spectrum-button-warning-m-text-color, var(--spectrum-semantic-negative-color-text-small));
}

.spectrum-Button--warning:hover {
    background-color: var(--spectrum-button-warning-m-background-color-hover, var(--spectrum-semantic-negative-color-text-small));
    border-color: var(--spectrum-button-warning-m-border-color-hover, var(--spectrum-semantic-negative-color-text-small));
    color: var(--spectrum-button-warning-m-text-color-hover, var(--spectrum-global-color-gray-50));
  }

.spectrum-Button--warning.focus-ring {
    background-color: var(--spectrum-button-warning-m-background-color-key-focus, var(--spectrum-semantic-negative-color-text-small));
    border-color: var(--spectrum-button-warning-m-border-color-key-focus, var(--spectrum-semantic-negative-color-text-small));
    color: var(--spectrum-button-warning-m-text-color-key-focus, var(--spectrum-global-color-gray-50));
  }

.spectrum-Button--warning:active {
    background-color: var(--spectrum-button-warning-m-background-color-down, var(--spectrum-global-color-red-700));
    border-color: var(--spectrum-button-warning-m-border-color-down, var(--spectrum-global-color-red-700));
    color: var(--spectrum-button-warning-m-text-color-down, var(--spectrum-global-color-gray-50));
  }

.spectrum-Button--warning:disabled,
  .spectrum-Button--warning.is-disabled {
    background-color: var(--spectrum-button-warning-m-background-color-disabled, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-button-warning-m-border-color-disabled, var(--spectrum-global-color-gray-200));
    color: var(--spectrum-button-warning-m-text-color-disabled, var(--spectrum-global-color-gray-500));
  }

.spectrum-Button--overBackground {
  background-color: var(--spectrum-button-over-background-m-background-color, var(--spectrum-alias-background-color-transparent));
  border-color: var(--spectrum-button-over-background-m-border-color, var(--spectrum-global-color-static-white));
  color: var(--spectrum-button-over-background-m-text-color, var(--spectrum-global-color-static-white));
}

.spectrum-Button--overBackground:hover {
    background-color: var(--spectrum-button-over-background-m-background-color-hover, var(--spectrum-global-color-static-white));
    border-color: var(--spectrum-button-over-background-m-border-color-hover, var(--spectrum-global-color-static-white));
    color: inherit;
  }

.spectrum-Button--overBackground.focus-ring {
    background-color: var(--spectrum-button-over-background-m-background-color-hover, var(--spectrum-global-color-static-white));
    border-color: var(--spectrum-button-over-background-m-border-color-hover, var(--spectrum-global-color-static-white));
    color: inherit;
  }

.spectrum-Button--overBackground.focus-ring:after {
      box-shadow: 0 0 0 var(--spectrum-alias-focus-ring-size, var(--spectrum-global-dimension-static-size-25)) var(--spectrum-button-over-background-m-border-color-key-focus, var(--spectrum-global-color-static-white));
    }

.spectrum-Button--overBackground:active {
    background-color: var(--spectrum-button-over-background-m-background-color-down, var(--spectrum-global-color-static-white));
    border-color: var(--spectrum-button-over-background-m-border-color-down, var(--spectrum-global-color-static-white));
    color: inherit;
  }

.spectrum-Button--overBackground:disabled,
  .spectrum-Button--overBackground.is-disabled {
    background-color: var(--spectrum-button-over-background-m-background-color-disabled, rgba(255,255,255,0.1));
    border-color: var(--spectrum-button-over-background-m-border-color-disabled, var(--spectrum-alias-border-color-transparent));
    color: var(--spectrum-button-over-background-m-text-color-disabled, rgba(255,255,255,0.35));
  }

.spectrum-Button--overBackground.spectrum-Button--quiet,
.spectrum-ClearButton--overBackground {
  background-color: var(--spectrum-button-quiet-over-background-m-background-color, var(--spectrum-alias-background-color-transparent));
  border-color: var(--spectrum-button-quiet-over-background-m-border-color, var(--spectrum-alias-border-color-transparent));
  color: var(--spectrum-button-quiet-over-background-m-text-color, var(--spectrum-global-color-static-white));
}

.spectrum-Button--overBackground.spectrum-Button--quiet:hover, .spectrum-ClearButton--overBackground:hover {
    background-color: var(--spectrum-button-quiet-over-background-m-background-color-hover, rgba(255,255,255,0.1));
    border-color: var(--spectrum-button-quiet-over-background-m-border-color-hover, var(--spectrum-alias-border-color-transparent));
    color: var(--spectrum-button-quiet-over-background-m-text-color-hover, var(--spectrum-global-color-static-white));
  }

.spectrum-Button--overBackground.spectrum-Button--quiet.focus-ring, .spectrum-ClearButton--overBackground.focus-ring {
    background-color: var(--spectrum-button-quiet-over-background-m-background-color-hover, rgba(255,255,255,0.1));
    border-color: var(--spectrum-button-quiet-over-background-m-border-color-hover, var(--spectrum-alias-border-color-transparent));
    color: var(--spectrum-button-quiet-over-background-m-text-color-hover, var(--spectrum-global-color-static-white));
    box-shadow: none;
  }

.spectrum-Button--overBackground.spectrum-Button--quiet.focus-ring:after, .spectrum-ClearButton--overBackground.focus-ring:after {
      box-shadow: 0 0 0 var(--spectrum-alias-focus-ring-size, var(--spectrum-global-dimension-static-size-25)) var(--spectrum-button-over-background-m-border-color-key-focus, var(--spectrum-global-color-static-white));
    }

.spectrum-Button--overBackground.spectrum-Button--quiet:active, .spectrum-ClearButton--overBackground:active {
    background-color: var(--spectrum-button-quiet-over-background-m-background-color-down, rgba(255,255,255,0.2));
    border-color: var(--spectrum-button-quiet-over-background-m-border-color-down, var(--spectrum-alias-border-color-transparent));
    color: var(--spectrum-button-quiet-over-background-m-text-color-down, var(--spectrum-global-color-static-white));
  }

.spectrum-Button--overBackground.spectrum-Button--quiet:disabled,
  .spectrum-Button--overBackground.spectrum-Button--quiet.is-disabled,
  .spectrum-ClearButton--overBackground:disabled,
  .spectrum-ClearButton--overBackground.is-disabled {
    background-color: var(--spectrum-button-quiet-over-background-m-background-color-disabled, var(--spectrum-alias-background-color-transparent));
    border-color: var(--spectrum-button-quiet-over-background-m-border-color-disabled, var(--spectrum-alias-border-color-transparent));
    color: var(--spectrum-button-quiet-over-background-m-text-color-disabled, rgba(255,255,255,0.15));
  }

.spectrum-Button--primary.spectrum-Button--quiet {
  background-color: var(--spectrum-button-quiet-primary-m-background-color, var(--spectrum-alias-background-color-transparent));
  border-color: var(--spectrum-button-quiet-primary-m-border-color, var(--spectrum-alias-border-color-transparent));
  color: var(--spectrum-button-quiet-primary-m-text-color, var(--spectrum-global-color-gray-800));
}

.spectrum-Button--primary.spectrum-Button--quiet:hover {
    background-color: var(--spectrum-button-quiet-primary-m-background-color-hover, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-button-quiet-primary-m-border-color-hover, var(--spectrum-global-color-gray-200));
    color: var(--spectrum-button-quiet-primary-m-text-color-hover, var(--spectrum-global-color-gray-900));
  }

.spectrum-Button--primary.spectrum-Button--quiet.focus-ring {
    background-color: var(--spectrum-button-quiet-primary-m-background-color-key-focus, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-button-quiet-primary-m-border-color-key-focus, var(--spectrum-global-color-gray-200));
    color: var(--spectrum-button-quiet-primary-m-text-color-key-focus, var(--spectrum-global-color-gray-900));
  }

.spectrum-Button--primary.spectrum-Button--quiet:active {
    background-color: var(--spectrum-button-quiet-primary-m-background-color-down, var(--spectrum-global-color-gray-300));
    border-color: var(--spectrum-button-quiet-primary-m-border-color-down, var(--spectrum-global-color-gray-300));
    color: var(--spectrum-button-quiet-primary-m-text-color-down, var(--spectrum-global-color-gray-900));
  }

.spectrum-Button--primary.spectrum-Button--quiet:disabled,
  .spectrum-Button--primary.spectrum-Button--quiet.is-disabled {
    background-color: var(--spectrum-button-quiet-primary-m-background-color-disabled, var(--spectrum-alias-background-color-transparent));
    border-color: var(--spectrum-button-quiet-primary-m-border-color-disabled, var(--spectrum-alias-border-color-transparent));
    color: var(--spectrum-button-quiet-primary-m-text-color-disabled, var(--spectrum-global-color-gray-500));
  }

.spectrum-Button--secondary.spectrum-Button--quiet {
  background-color: var(--spectrum-button-quiet-secondary-m-background-color, var(--spectrum-alias-background-color-transparent));
  border-color: var(--spectrum-button-quiet-secondary-m-border-color, var(--spectrum-alias-border-color-transparent));
  color: var(--spectrum-button-quiet-secondary-m-text-color, var(--spectrum-global-color-gray-700));
}

.spectrum-Button--secondary.spectrum-Button--quiet:hover {
    background-color: var(--spectrum-button-quiet-secondary-m-background-color-hover, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-button-quiet-secondary-m-border-color-hover, var(--spectrum-global-color-gray-200));
    color: var(--spectrum-button-quiet-secondary-m-text-color-hover, var(--spectrum-global-color-gray-800));
  }

.spectrum-Button--secondary.spectrum-Button--quiet.focus-ring {
    background-color: var(--spectrum-button-quiet-secondary-m-background-color-key-focus, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-button-quiet-secondary-m-border-color-key-focus, var(--spectrum-global-color-gray-200));
    color: var(--spectrum-button-quiet-secondary-m-text-color-key-focus, var(--spectrum-global-color-gray-800));
  }

.spectrum-Button--secondary.spectrum-Button--quiet:active {
    background-color: var(--spectrum-button-quiet-secondary-m-background-color-down, var(--spectrum-global-color-gray-300));
    border-color: var(--spectrum-button-quiet-secondary-m-border-color-down, var(--spectrum-global-color-gray-300));
    color: var(--spectrum-button-quiet-secondary-m-text-color-down, var(--spectrum-global-color-gray-800));
  }

.spectrum-Button--secondary.spectrum-Button--quiet:disabled,
  .spectrum-Button--secondary.spectrum-Button--quiet.is-disabled {
    background-color: var(--spectrum-button-quiet-secondary-m-background-color-disabled, var(--spectrum-alias-background-color-transparent));
    border-color: var(--spectrum-button-quiet-secondary-m-border-color-disabled, var(--spectrum-alias-border-color-transparent));
    color: var(--spectrum-button-quiet-secondary-m-text-color-disabled, var(--spectrum-global-color-gray-500));
  }

.spectrum-Button--warning.spectrum-Button--quiet {
  background-color: var(--spectrum-button-quiet-warning-m-background-color, var(--spectrum-alias-background-color-transparent));
  border-color: var(--spectrum-button-quiet-warning-m-border-color, var(--spectrum-alias-border-color-transparent));
  color: var(--spectrum-button-quiet-warning-m-text-color, var(--spectrum-semantic-negative-color-text-small));
}

.spectrum-Button--warning.spectrum-Button--quiet:hover {
    background-color: var(--spectrum-button-quiet-warning-m-background-color-hover, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-button-quiet-warning-m-border-color-hover, var(--spectrum-global-color-gray-200));
    color: var(--spectrum-button-quiet-warning-m-text-color-hover, var(--spectrum-global-color-red-700));
  }

.spectrum-Button--warning.spectrum-Button--quiet.focus-ring {
    background-color: var(--spectrum-button-quiet-warning-m-background-color-key-focus, var(--spectrum-global-color-gray-200));
    border-color: var(--spectrum-button-quiet-warning-m-border-color-key-focus, var(--spectrum-global-color-gray-200));
    color: var(--spectrum-button-quiet-warning-m-text-color-key-focus, var(--spectrum-global-color-red-700));
  }

.spectrum-Button--warning.spectrum-Button--quiet:active {
    background-color: var(--spectrum-button-quiet-warning-m-background-color-down, var(--spectrum-global-color-gray-300));
    border-color: var(--spectrum-button-quiet-warning-m-border-color-down, var(--spectrum-global-color-gray-300));
    color: var(--spectrum-button-quiet-warning-m-text-color-down, var(--spectrum-global-color-red-700));
  }

.spectrum-Button--warning.spectrum-Button--quiet:disabled,
  .spectrum-Button--warning.spectrum-Button--quiet.is-disabled {
    background-color: var(--spectrum-button-quiet-warning-m-background-color-disabled, var(--spectrum-alias-background-color-transparent));
    border-color: var(--spectrum-button-quiet-warning-m-border-color-disabled, var(--spectrum-alias-border-color-transparent));
    color: var(--spectrum-button-quiet-warning-m-text-color-disabled, var(--spectrum-global-color-gray-500));
  }
button.svelte-13vwr7s{position:relative;display:flex;gap:var(--spacing-s)}button.is-disabled.svelte-13vwr7s{cursor:default}.spectrum-Button.svelte-13vwr7s{padding-bottom:calc(var(--spectrum-button-padding-y) - 1px)}.spectrum-Button-label.svelte-13vwr7s{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600 !important;line-height:20px;letter-spacing:-0.02em}.spectrum-Button--sizeM.svelte-13vwr7s{font-size:14px}.active.svelte-13vwr7s{color:var(--spectrum-global-color-blue-600) !important}.spectrum-Button--primary.new-styles.svelte-13vwr7s{background:var(--spectrum-global-color-gray-800);border-color:transparent;color:var(--spectrum-global-color-gray-50)}.spectrum-Button--primary.new-styles.svelte-13vwr7s:hover{background:var(--spectrum-global-color-gray-900)}.spectrum-Button--secondary.new-styles.svelte-13vwr7s{background:var(--spectrum-global-color-gray-200);border-color:transparent;color:var(--spectrum-global-color-gray-900)}.spectrum-Button--secondary.new-styles.svelte-13vwr7s:not(.is-disabled):hover{background:var(--spectrum-global-color-gray-300)}.spectrum-Button--secondary.new-styles.is-disabled.svelte-13vwr7s{color:var(--spectrum-global-color-gray-500)}.spectrum-Button--warning.new-styles.svelte-13vwr7s{background:var(--spectrum-global-color-red-400);border-color:transparent;color:var(--spectrum-global-color-gray-900)}.spectrum-Button--warning.new-styles.svelte-13vwr7s:not(.is-disabled):hover{background:var(--spectrum-global-color-red-500)}.spectrum-Button--primary.new-styles.is-disabled.svelte-13vwr7s{background:var(--spectrum-global-color-gray-200);color:var(--spectrum-global-color-gray-500)}.spectrum-Button--warning.new-styles.is-disabled.svelte-13vwr7s{background:var(--spectrum-global-color-gray-200);color:var(--spectrum-global-color-gray-500)}.spectrum-ButtonGroup {
  --spectrum-buttongroup-button-gap-reset: 0;
}

.spectrum-ButtonGroup {
  display: -ms-flexbox;
  display: flex;
}

.spectrum-ButtonGroup .spectrum-ButtonGroup-item {
    -ms-flex-negative: 0;
        flex-shrink: 0;
  }

[dir="ltr"] .spectrum-ButtonGroup .spectrum-ButtonGroup-item + .spectrum-ButtonGroup-item {
    margin-left: var(--spectrum-buttongroup-button-gap-x, var(--spectrum-global-dimension-static-size-200));
}

[dir="rtl"] .spectrum-ButtonGroup .spectrum-ButtonGroup-item + .spectrum-ButtonGroup-item {
    margin-right: var(--spectrum-buttongroup-button-gap-x, var(--spectrum-global-dimension-static-size-200));
}

.spectrum-ButtonGroup--vertical {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-direction: column;
      flex-direction: column;
}

[dir="ltr"] .spectrum-ButtonGroup--vertical .spectrum-ButtonGroup-item + .spectrum-ButtonGroup-item {
    margin-left: var(--spectrum-buttongroup-button-gap-reset);
}

[dir="rtl"] .spectrum-ButtonGroup--vertical .spectrum-ButtonGroup-item + .spectrum-ButtonGroup-item {
    margin-right: var(--spectrum-buttongroup-button-gap-reset);
}

.spectrum-ButtonGroup--vertical .spectrum-ButtonGroup-item + .spectrum-ButtonGroup-item {
    margin-top: var(--spectrum-buttongroup-button-gap-y, var(--spectrum-global-dimension-static-size-200));
  }
.icon.svelte-b9x87s.svelte-b9x87s{margin-right:var(--spacing-s)}.iconHidden.svelte-b9x87s.svelte-b9x87s{opacity:0}.keys.svelte-b9x87s.svelte-b9x87s{margin-left:30px;display:flex;flex-direction:row;justify-content:flex-end;align-items:center;gap:4px}.key.svelte-b9x87s.svelte-b9x87s{color:var(--spectrum-global-color-gray-900);padding:2px 4px;font-size:12px;font-weight:600;background-color:var(--spectrum-global-color-gray-300);border-radius:4px;min-width:12px;height:16px;text-align:center;margin:-1px 0;display:grid;place-items:center}.is-disabled.svelte-b9x87s .spectrum-Menu-itemLabel.svelte-b9x87s{color:var(--spectrum-global-color-gray-600)}.spectrum-Menu-itemLabel.svelte-b9x87s.svelte-b9x87s{color:var(--spectrum-global-color-gray-900)}.container.svelte-12t4e3i{display:grid;grid-template-columns:1fr;position:relative}.paddingX-S.svelte-12t4e3i{padding-left:var(--spacing-s);padding-right:var(--spacing-s)}.paddingX-M.svelte-12t4e3i{padding-left:var(--spacing-m);padding-right:var(--spacing-m)}.paddingX-L.svelte-12t4e3i{padding-left:var(--spacing-l);padding-right:var(--spacing-l)}.paddingX-XL.svelte-12t4e3i{padding-left:var(--spacing-xl);padding-right:var(--spacing-xl)}.paddingX-XXL.svelte-12t4e3i{padding-left:var(--spectrum-alias-grid-gutter-large);padding-right:var(--spectrum-alias-grid-gutter-large)}.paddingY-S.svelte-12t4e3i{padding-top:var(--spacing-s);padding-bottom:var(--spacing-s)}.paddingY-M.svelte-12t4e3i{padding-top:var(--spacing-m);padding-bottom:var(--spacing-m)}.paddingY-L.svelte-12t4e3i{padding-top:var(--spacing-l);padding-bottom:var(--spacing-l)}.paddingY-XL.svelte-12t4e3i{padding-top:var(--spacing-xl);padding-bottom:var(--spacing-xl)}.paddingY-XXL.svelte-12t4e3i{padding-top:var(--spectrum-alias-grid-gutter-large);padding-bottom:var(--spectrum-alias-grid-gutter-large)}.gap-XXS.svelte-12t4e3i{grid-gap:var(--spacing-xs)}.gap-XS.svelte-12t4e3i{grid-gap:var(--spacing-s)}.gap-S.svelte-12t4e3i{grid-gap:var(--spectrum-alias-grid-gutter-xsmall)}.gap-M.svelte-12t4e3i{grid-gap:var(--spectrum-alias-grid-gutter-small)}.gap-L.svelte-12t4e3i{grid-gap:var(--spectrum-alias-grid-gutter-medium)}.gap-XL.svelte-12t4e3i{grid-gap:var(--spectrum-alias-grid-gutter-large)}.horizontal.gap-S.svelte-12t4e3i *+*{margin-left:var(--spectrum-alias-grid-gutter-xsmall)}.horizontal.gap-M.svelte-12t4e3i *+*{margin-left:var(--spectrum-alias-grid-gutter-small)}.horizontal.gap-L.svelte-12t4e3i *+*{margin-left:var(--spectrum-alias-grid-gutter-medium)}.container.svelte-1lkpxti.svelte-1lkpxti{position:relative}.preview.svelte-1lkpxti.svelte-1lkpxti{width:32px;height:32px;border-radius:100%;position:relative;transition:border-color 130ms ease-in-out;box-shadow:0 0 0 1px var(--spectrum-global-color-gray-400)}.preview.svelte-1lkpxti.svelte-1lkpxti:hover{cursor:pointer;box-shadow:0 0 2px 2px var(--spectrum-global-color-gray-400)}.fill.svelte-1lkpxti.svelte-1lkpxti{width:100%;height:100%;border-radius:100%;position:absolute;top:0;left:0;display:grid;place-items:center}.fill.placeholder.svelte-1lkpxti.svelte-1lkpxti{background-position:0 0,
      10px 10px;background-size:20px 20px;background-image:linear-gradient(
        45deg,
        #eee 25%,
        transparent 25%,
        transparent 75%,
        #eee 75%,
        #eee 100%
      ),
      linear-gradient(
        45deg,
        #eee 25%,
        white 25%,
        white 75%,
        #eee 75%,
        #eee 100%
      )}.size--S.svelte-1lkpxti.svelte-1lkpxti{width:20px;height:20px}.size--M.svelte-1lkpxti.svelte-1lkpxti{width:32px;height:32px}.size--L.svelte-1lkpxti.svelte-1lkpxti{width:48px;height:48px}.colors.svelte-1lkpxti.svelte-1lkpxti{display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr;gap:var(--spacing-xs)}.heading.svelte-1lkpxti.svelte-1lkpxti{font-size:var(--font-size-s);font-weight:600;letter-spacing:0.14px;flex:1 1 auto;text-transform:uppercase;grid-column:1 / 5;margin-bottom:var(--spacing-s)}.color.svelte-1lkpxti.svelte-1lkpxti{height:16px;width:16px;border-radius:100%;box-shadow:0 0 0 1px var(--spectrum-global-color-gray-300);position:relative}.color.svelte-1lkpxti.svelte-1lkpxti:hover{cursor:pointer;box-shadow:0 0 2px 2px var(--spectrum-global-color-gray-300)}.custom.svelte-1lkpxti.svelte-1lkpxti{display:grid;grid-template-columns:1fr auto;align-items:center;gap:var(--spacing-m);margin-right:var(--spacing-xs)}.category--custom.svelte-1lkpxti .heading.svelte-1lkpxti{margin-bottom:var(--spacing-xs)}.container.svelte-1lkpxti.svelte-1lkpxti{display:flex;flex-direction:column;gap:var(--spacing-xl)}.spectrum-wrapper.svelte-1lkpxti.svelte-1lkpxti{background-color:transparent}.property-group-container.svelte-1wbs484{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;border-bottom:var(--border-light)}.property-group-container.svelte-1wbs484:last-child{border-bottom:0px}.property-group-name.svelte-1wbs484{cursor:pointer;display:flex;flex-flow:row nowrap;flex-direction:row;justify-content:space-between;align-items:center;color:var(--spectrum-global-color-gray-800);transition:color 130ms ease-in-out}.property-group-name.open.svelte-1wbs484{padding-bottom:var(--spacing-m)}.property-group-name.padded.svelte-1wbs484{padding:var(--spacing-m) var(--spacing-xl)}.property-group-name.svelte-1wbs484:hover{color:var(--spectrum-global-color-gray-900)}.name.svelte-1wbs484{text-align:left;font-size:var(--spectrum-global-dimension-font-size-100);color:var(--spectrum-global-color-gray-900);letter-spacing:-0.02em;font-weight:500;line-height:20px;font-size:14px;flex:1 1 auto;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;user-select:none}.property-panel.svelte-1wbs484{display:none}.property-panel.padded.svelte-1wbs484{padding:var(--spacing-s) var(--spacing-xl) var(--spacing-xl)
      var(--spacing-xl)}.property-panel.no-title.svelte-1wbs484{padding-top:var(--spacing-xl)}.show.svelte-1wbs484{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;gap:var(--spacing-l)}.drawer.svelte-c271o1{position:absolute;left:25vw;width:50vw;bottom:var(--spacing);height:420px;background:var(--background);border:var(--border-light);z-index:1000;border-radius:8px;overflow:hidden;box-sizing:border-box;transition:transform 260ms ease-out,
      bottom 260ms ease-out,
      left 260ms ease-out,
      width 260ms ease-out,
      height 260ms ease-out;display:flex;flex-direction:column;align-items:stretch}.drawer.modal.svelte-c271o1{left:15vw;width:70vw;bottom:15vh;height:70vh}.drawer.stacked.svelte-c271o1{transform:translateY(calc(-1 * 1024px * (1 - var(--scale-factor))))
      scale(var(--scale-factor))}.overlay.svelte-c271o1,.underlay.svelte-c271o1{top:0;left:0;width:100%;height:100%;z-index:100;display:block;transition:opacity 260ms ease-out}.overlay.svelte-c271o1{position:absolute;background:var(--background);opacity:0.5}.underlay.svelte-c271o1{position:fixed;background:rgba(0, 0, 0, 0.5)}.underlay.hidden.svelte-c271o1,.overlay.hidden.svelte-c271o1{opacity:0 !important;pointer-events:none}header.svelte-c271o1{display:flex;justify-content:space-between;align-items:center;border-bottom:var(--border-light);padding:var(--spacing-m) var(--spacing-xl);gap:var(--spacing-xl)}.text.svelte-c271o1{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;gap:var(--spacing-xs);font-weight:500;color:var(--spectrum-global-color-gray-900)}.buttons.svelte-c271o1{display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:var(--spacing-m)}.buttons.svelte-c271o1 .icon{width:16px;display:flex}.drawer-contents.svelte-1bc8t9i.svelte-1bc8t9i{overflow-y:auto;flex:1 1 auto}.container.svelte-1bc8t9i.svelte-1bc8t9i{height:100%;display:grid;grid-template-columns:320px 1fr}.no-sidebar.svelte-1bc8t9i.svelte-1bc8t9i{grid-template-columns:1fr}.sidebar.svelte-1bc8t9i.svelte-1bc8t9i{border-right:var(--border-light);overflow:auto;scrollbar-width:none}.padding.svelte-1bc8t9i .sidebar.svelte-1bc8t9i{padding:var(--spacing-xl)}.sidebar.svelte-1bc8t9i.svelte-1bc8t9i::-webkit-scrollbar{display:none}.main.svelte-1bc8t9i.svelte-1bc8t9i{height:100%;overflow:auto}.padding.svelte-1bc8t9i .main.svelte-1bc8t9i{padding:var(--spacing-xl);height:calc(100% - var(--spacing-xl) * 2)}.main.svelte-1bc8t9i textarea{min-height:200px}.main.svelte-1bc8t9i p{margin:0}.icon.svelte-1kkqnlv{position:relative;width:28px;height:28px;flex:0 0 28px;display:grid;place-items:center;border-radius:50%}.icon.size--XS.svelte-1kkqnlv{width:18px;height:18px;flex:0 0 18px}.icon.size--S.svelte-1kkqnlv{width:22px;height:22px;flex:0 0 22px}.icon.size--L.svelte-1kkqnlv{width:40px;height:40px;flex:0 0 40px}.tooltip.svelte-1kkqnlv{position:absolute;pointer-events:none;left:calc(50% + 8px);bottom:calc(-50% + 6px);text-align:center;z-index:1}.container.svelte-r1sbsa{position:relative}.preview.svelte-r1sbsa{width:32px;height:32px;position:relative;box-shadow:0 0 0 1px var(--spectrum-global-color-gray-400)}.preview.svelte-r1sbsa:hover{cursor:pointer}.fill.svelte-r1sbsa{width:100%;height:100%;position:absolute;top:0;left:0;display:grid;place-items:center}.size--S.svelte-r1sbsa{width:20px;height:20px}.size--M.svelte-r1sbsa{width:32px;height:32px}.size--L.svelte-r1sbsa{width:48px;height:48px}.spectrum-Popover.svelte-r1sbsa{width:210px;z-index:999;top:100%;padding:var(--spacing-l) var(--spacing-xl);display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;gap:var(--spacing-xl)}.spectrum-Popover--align-right.svelte-r1sbsa{right:0}.icons.svelte-r1sbsa{display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr;gap:var(--spacing-m)}.heading.svelte-r1sbsa{font-size:var(--font-size-s);font-weight:600;letter-spacing:0.14px;flex:1 1 auto;text-transform:uppercase;grid-column:1 / 5;margin-bottom:var(--spacing-s)}.icon.svelte-r1sbsa{height:16px;width:16px;border-radius:100%;box-shadow:0 0 0 1px var(--spectrum-global-color-gray-300);position:relative}.icon.svelte-r1sbsa:hover{cursor:pointer;box-shadow:0 0 2px 2px var(--spectrum-global-color-gray-300)}.custom.svelte-r1sbsa{display:grid;grid-template-columns:1fr auto;align-items:center;gap:var(--spacing-m);margin-right:var(--spacing-xs)}.spectrum-wrapper.svelte-r1sbsa{background-color:transparent}.spectrum-InLineAlert {
  --spectrum-inlinealert-neutral-title-height: 38px;
  --spectrum-inlinealert-neutral-corner-radius: 4px;
  --spectrum-inlinealert-neutral-border-width: 2px;
}

.spectrum-InLineAlert {
  position: relative;

  display: inline-block;
  box-sizing: border-box;
  min-width: var(--spectrum-inlinealert-neutral-min-width, var(--spectrum-global-dimension-static-size-4600));
  min-height: var(--spectrum-inlinealert-neutral-title-height);
  margin-top: 8px;
  margin-bottom: 8px;
  margin-left: 0;
  margin-right: 0;
  padding-top: var(--spectrum-inlinealert-neutral-padding-y, var(--spectrum-global-dimension-static-size-250));
  padding-bottom: var(--spectrum-inlinealert-neutral-padding-y, var(--spectrum-global-dimension-static-size-250));
  padding-left: var(--spectrum-inlinealert-neutral-padding-x, var(--spectrum-global-dimension-static-size-250));
  padding-right: var(--spectrum-inlinealert-neutral-padding-x, var(--spectrum-global-dimension-static-size-250));

  border-width: var(--spectrum-inlinealert-neutral-border-width);
  border-style: solid;
  border-radius: var(--spectrum-inlinealert-neutral-corner-radius);
}

[dir="ltr"] .spectrum-InLineAlert-icon {
  right: 20px;
}

[dir="rtl"] .spectrum-InLineAlert-icon {
  left: 20px;
}

.spectrum-InLineAlert-icon {
  position: absolute;
  display: block;
  top: 20px;
}

[dir="ltr"] .spectrum-InLineAlert-header {
  padding-right: 30px;
}

[dir="rtl"] .spectrum-InLineAlert-header {
  padding-left: 30px;
}

.spectrum-InLineAlert-header {
  display: inline-block;
  height: auto;
  min-height: 0;
  margin: 0;
  padding: 0;

  font-size: 14px;
  font-weight: 700;
  font-style: normal;
  line-height: 14px;
  text-transform: none;
}

.spectrum-InLineAlert-content {
  display: block;
  margin: var(--spectrum-inlinealert-neutral-content-margin-top, var(--spectrum-global-dimension-static-size-100)) 0 0 0;
  padding: 0;

  font-size: 14px;
  word-wrap: break-word;
}

[dir="ltr"] .spectrum-InLineAlert-footer {

  text-align: right;
}

[dir="rtl"] .spectrum-InLineAlert-footer {

  text-align: left;
}

.spectrum-InLineAlert-footer {
  display: block;

  padding-top: 0.5rem;
}

.spectrum-InLineAlert-footer:empty {
    display: none;
  }

[dir="ltr"] .spectrum-InLineAlert-footer .spectrum-Button {
    margin-right: 0;
}

[dir="rtl"] .spectrum-InLineAlert-footer .spectrum-Button {
    margin-left: 0;
}

[dir="ltr"] .spectrum-InLineAlert-footer .spectrum-Button {
    margin-left: 0.75rem;
}

[dir="rtl"] .spectrum-InLineAlert-footer .spectrum-Button {
    margin-right: 0.75rem;
}

.spectrum-InLineAlert {
  background-color: var(--spectrum-inlinealert-neutral-background-color, var(--spectrum-global-color-gray-50));
  color: var(--spectrum-inlinealert-neutral-text-color, var(--spectrum-global-color-gray-700));
}

.spectrum-InLineAlert-header {
  color: var(--spectrum-inlinealert-neutral-title-text-color, var(--spectrum-global-color-gray-900));
}

.spectrum-InLineAlert-content {
  color: var(--spectrum-inlinealert-neutral-text-color, var(--spectrum-global-color-gray-700));
}

.spectrum-InLineAlert--info {
  border-color: var(--spectrum-inlinealert-info-border-color, var(--spectrum-semantic-informative-border-color));
}

.spectrum-InLineAlert--info .spectrum-InLineAlert-icon {
    color: var(--spectrum-inlinealert-info-icon-color, var(--spectrum-semantic-informative-icon-color));
  }

.spectrum-InLineAlert--help {
  border-color: var(--spectrum-inlinealert-info-border-color, var(--spectrum-semantic-informative-border-color));
}

.spectrum-InLineAlert--help .spectrum-InLineAlert-icon {
    color: var(--spectrum-inlinealert-info-icon-color, var(--spectrum-semantic-informative-icon-color));
  }

.spectrum-InLineAlert--error {
  border-color: var(--spectrum-inlinealert-error-border-color, var(--spectrum-semantic-negative-border-color));
}

.spectrum-InLineAlert--error .spectrum-InLineAlert-icon {
    color: var(--spectrum-inlinealert-error-icon-color, var(--spectrum-semantic-negative-icon-color));
  }

.spectrum-InLineAlert--success {
  border-color: var(--spectrum-inlinealert-success-border-color, var(--spectrum-semantic-positive-border-color));
}

.spectrum-InLineAlert--success .spectrum-InLineAlert-icon {
    color: var(--spectrum-inlinealert-success-icon-color, var(--spectrum-semantic-positive-icon-color));
  }

.spectrum-InLineAlert--negative {
  border-color: var(--spectrum-inlinealert-negative-border-color, var(--spectrum-semantic-notice-border-color));
}

.spectrum-InLineAlert--negative .spectrum-InLineAlert-icon {
    color: var(--spectrum-inlinealert-negative-icon-color, var(--spectrum-semantic-notice-icon-color));
  }
.button.svelte-1399oda.svelte-1399oda{margin-top:10px}.spectrum-InLineAlert.svelte-1399oda.svelte-1399oda{--spectrum-semantic-negative-border-color:#e34850;--spectrum-semantic-positive-border-color:#2d9d78;--spectrum-semantic-positive-icon-color:#2d9d78;--spectrum-semantic-negative-icon-color:#e34850;min-width:100px;margin:0;border-width:1px}a.svelte-1399oda.svelte-1399oda{color:white}#docs-link.svelte-1399oda.svelte-1399oda{padding-top:10px;display:flex;align-items:center;gap:5px}#docs-link.svelte-1399oda>.svelte-1399oda{display:flex;align-items:center;gap:5px}div.svelte-1eqnhvn{position:relative}.icon.svelte-1eqnhvn{right:1px;bottom:1px;position:absolute;justify-content:center;align-items:center;display:flex;flex-direction:row;box-sizing:border-box;border-left:1px solid var(--spectrum-alias-border-color);border-top-right-radius:var(--spectrum-alias-border-radius-regular);border-bottom-right-radius:var(--spectrum-alias-border-radius-regular);width:31px;color:var(--spectrum-alias-text-color);background-color:var(--spectrum-global-color-gray-75);transition:background-color var(--spectrum-global-animation-duration-100, 130ms),
      box-shadow var(--spectrum-global-animation-duration-100, 130ms),
      border-color var(--spectrum-global-animation-duration-100, 130ms);height:calc(var(--spectrum-alias-item-height-m) - 2px)}.icon.svelte-1eqnhvn:hover{cursor:pointer;color:var(--spectrum-alias-text-color-hover);background-color:var(--spectrum-global-color-gray-50);border-color:var(--spectrum-alias-border-color-hover)}label.svelte-6ovcw8{padding:0;white-space:nowrap;color:var(--spectrum-global-color-gray-700)}.muted.svelte-6ovcw8{opacity:0.5}.page.svelte-1musq3v{position:relative}.page.svelte-1musq3v,.main.svelte-1musq3v{display:flex;flex-direction:row;justify-content:flex-start;align-items:stretch;flex:1 1 auto;overflow-x:hidden}.main.svelte-1musq3v{overflow-y:auto}.content.svelte-1musq3v{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;max-width:1080px;margin:0 auto;flex:1 1 auto;padding:50px 50px 0 50px;z-index:1}.content.noPadding.svelte-1musq3v{padding:0}.fix-scroll-padding.svelte-1musq3v{content:"";display:block;flex:0 0 50px}.content.wide.svelte-1musq3v{max-width:none}.content.narrow.svelte-1musq3v{max-width:840px}.content.narrower.svelte-1musq3v{max-width:700px}#side-panel.svelte-1musq3v{position:absolute;right:0;top:0;padding:24px;background:var(--background);border-left:var(--border-light);width:320px;max-width:calc(100vw - 48px - 48px);overflow:auto;overflow-x:hidden;transform:translateX(100%);transition:transform 130ms ease-out;height:calc(100% - 48px);z-index:2}#side-panel.visible.svelte-1musq3v{transform:translateX(0)}@media(max-width: 640px){.content.svelte-1musq3v{padding:24px;max-width:calc(100vw - 48px) !important;width:calc(100vw - 48px) !important;overflow:auto}}.title.svelte-glsrm{margin-bottom:6px}.list-items.svelte-glsrm{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch}.list-item.svelte-1ha8ivo.svelte-1ha8ivo{padding:var(--spacing-m) var(--spacing-l);background:var(--spectrum-global-color-gray-75);display:flex;flex-direction:row;justify-content:space-between;border:1px solid var(--spectrum-global-color-gray-300);transition:background 130ms ease-out,
      border-color 130ms ease-out;gap:var(--spacing-m);color:var(--spectrum-global-color-gray-800);cursor:pointer;position:relative;box-sizing:border-box}.list-item.svelte-1ha8ivo.svelte-1ha8ivo:not(:first-child){border-top:none}.list-item.svelte-1ha8ivo.svelte-1ha8ivo:first-child{border-top-left-radius:4px;border-top-right-radius:4px}.list-item.svelte-1ha8ivo.svelte-1ha8ivo:last-child{border-bottom-left-radius:4px;border-bottom-right-radius:4px}.hoverable.svelte-1ha8ivo.svelte-1ha8ivo:hover{cursor:pointer}.hoverable.svelte-1ha8ivo.svelte-1ha8ivo:not(.selected):hover{background:var(--spectrum-global-color-gray-200);border-color:var(--spectrum-global-color-gray-400)}.selected.svelte-1ha8ivo.svelte-1ha8ivo{background:var(--spectrum-global-color-blue-100)}.list-item.selected.svelte-1ha8ivo.svelte-1ha8ivo{background-color:var(--spectrum-global-color-blue-100);border:none}.list-item.selected.svelte-1ha8ivo.svelte-1ha8ivo:after{content:"";position:absolute;height:100%;width:100%;border:1px solid var(--spectrum-global-color-blue-400);pointer-events:none;top:0;left:0;border-radius:inherit;box-sizing:border-box;z-index:1;opacity:0.5}.list-item.large.svelte-1ha8ivo .list-item__icon.svelte-1ha8ivo{background-color:var(--spectrum-global-color-gray-200);padding:4px;border-radius:4px;border:1px solid var(--spectrum-global-color-gray-300);transition:background-color 130ms ease-out,
      border-color 130ms ease-out,
      color 130ms ease-out}.list-item.large.hoverable.svelte-1ha8ivo:not(.selected):hover .list-item__icon.svelte-1ha8ivo{background-color:var(--spectrum-global-color-gray-300)}.list-item.large.selected.svelte-1ha8ivo .list-item__icon.svelte-1ha8ivo{background-color:var(--spectrum-global-color-blue-400);color:white;border-color:var(--spectrum-global-color-blue-100)}.list-item__left.svelte-1ha8ivo.svelte-1ha8ivo,.list-item__right.svelte-1ha8ivo.svelte-1ha8ivo{display:flex;flex-direction:row;align-items:center;gap:var(--spacing-m)}.list-item.large.svelte-1ha8ivo .list-item__left.svelte-1ha8ivo,.list-item.large.svelte-1ha8ivo .list-item__right.svelte-1ha8ivo{gap:var(--spacing-m)}.list-item__left.svelte-1ha8ivo.svelte-1ha8ivo{width:0;flex:1 1 auto}.list-item__right.svelte-1ha8ivo.svelte-1ha8ivo{flex:0 0 auto;color:var(--spectrum-global-color-gray-600)}.list-item__text.svelte-1ha8ivo.svelte-1ha8ivo{flex:1 1 auto;width:0}.list-item__title.svelte-1ha8ivo.svelte-1ha8ivo,.list-item__subtitle.svelte-1ha8ivo.svelte-1ha8ivo{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.list-item__subtitle.svelte-1ha8ivo.svelte-1ha8ivo{color:var(--spectrum-global-color-gray-700);font-size:12px}.markdown-viewer.svelte-12nifb7{overflow:auto}.markdown-viewer.svelte-12nifb7 :first-child{margin-top:0}.markdown-viewer.svelte-12nifb7 :last-child{margin-bottom:0}.markdown-viewer.svelte-12nifb7 pre{background:var(--spectrum-global-color-gray-200);padding:4px;border-radius:4px}.markdown-viewer.svelte-12nifb7 code{color:#e83e8c}.markdown-viewer.svelte-12nifb7 pre code{color:var(--spectrum-alias-text-color)}.markdown-viewer.svelte-12nifb7 blockquote{border-left:4px solid var(--spectrum-global-color-gray-400);color:var(--spectrum-global-color-gray-700);margin-left:0;padding-left:20px}.markdown-viewer.svelte-12nifb7 hr{background-color:var(--spectrum-global-color-gray-300);border:none;height:2px}.markdown-viewer.svelte-12nifb7 td,.markdown-viewer.svelte-12nifb7 th{border-color:var(--spectrum-alias-border-color) !important}.markdown-viewer.svelte-12nifb7 a{color:var(--primaryColor)}.markdown-viewer.svelte-12nifb7 a:hover{color:var(--primaryColorHover)}.spectrum-Modal {

  visibility: hidden;

  opacity: 0;

  transition: transform var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
              opacity var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
              visibility 0ms linear var(--spectrum-global-animation-duration-100, 130ms);

  pointer-events: none;
}

.spectrum-Modal.is-open {
  visibility: visible;

  opacity: 1;

  transition-delay: 0ms;

  pointer-events: auto;
}

.spectrum-Modal {
  --spectrum-dialog-confirm-exit-animation-delay: 0ms;
  --spectrum-dialog-fullscreen-margin: 32px;
  --spectrum-dialog-max-height: 90vh;
}

.spectrum-Modal-wrapper {
  position: fixed;
  left: 0;
  top: 0;

  display: -ms-flexbox;

  display: flex;
  -ms-flex-align: center;
      align-items: center;
  -ms-flex-pack: center;
      justify-content: center;

  box-sizing: border-box;
  width: 100vw;
  height: 100vh;
  height: -webkit-fill-available;
  height: fill-available;

  visibility: hidden;
  pointer-events: none;
  z-index: 2;
  transition: visibility 0ms linear
    var(--spectrum-global-animation-duration-100, 130ms);
}

.spectrum-Modal-wrapper.is-open {
    visibility: visible;
  }

.spectrum-Modal {
  transform: translateY(
    var(--spectrum-dialog-confirm-entry-animation-distance, var(--spectrum-global-dimension-size-250))
  );
  z-index: 2;
  max-height: var(--spectrum-dialog-max-height);

  border-radius: var(--spectrum-dialog-confirm-border-radius, var(--spectrum-global-dimension-size-50));
  overflow: hidden;
  outline: none;
  pointer-events: auto;
  transition: opacity var(--spectrum-dialog-confirm-exit-animation-duration, var(--spectrum-global-animation-duration-100))
      cubic-bezier(0.5, 0, 1, 1)
      var(--spectrum-dialog-confirm-exit-animation-delay, 0ms),
    visibility 0ms linear
      calc(var(--spectrum-dialog-confirm-exit-animation-delay, 0ms) + var(--spectrum-dialog-confirm-exit-animation-duration, var(--spectrum-global-animation-duration-100))),
    transform 0ms linear
      calc(var(--spectrum-dialog-confirm-exit-animation-delay, 0ms) + var(--spectrum-dialog-confirm-exit-animation-duration, var(--spectrum-global-animation-duration-100)));
}

.spectrum-Modal.is-open {
    transition: transform
        var(--spectrum-dialog-confirm-entry-animation-duration, var(--spectrum-global-animation-duration-500))
        cubic-bezier(0, 0, 0.4, 1)
        var(--spectrum-dialog-confirm-entry-animation-delay, var(--spectrum-global-animation-duration-200)),
      opacity var(--spectrum-dialog-confirm-entry-animation-duration, var(--spectrum-global-animation-duration-500))
        cubic-bezier(0, 0, 0.4, 1)
        var(--spectrum-dialog-confirm-entry-animation-delay, var(--spectrum-global-animation-duration-200));

    transform: translateY(0);
  }

@media only screen and (max-device-width: 400px), only screen and (max-device-height: 350px) {
  .spectrum-Modal--responsive {
    width: 100%;
    height: 100%;
    max-width: 100%;
    max-height: 100%;
    border-radius: 0;
  }
    .spectrum-Modal-wrapper .spectrum-Modal--responsive {
      margin-top: 0;
    }
}

.spectrum-Modal--fullscreen {
  position: fixed;
  left: var(--spectrum-dialog-fullscreen-margin);
  top: var(--spectrum-dialog-fullscreen-margin);
  right: var(--spectrum-dialog-fullscreen-margin);
  bottom: var(--spectrum-dialog-fullscreen-margin);
  max-width: none;
  max-height: none;
}

.spectrum-Modal--fullscreenTakeover {
  position: fixed;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  max-width: none;
  max-height: none;

  box-sizing: border-box;
  border: none;
  border-radius: 0;
}

.spectrum-Modal--fullscreenTakeover,
  .spectrum-Modal--fullscreenTakeover.is-open {
    transform: none;
  }

.spectrum-Modal {
  background: var(--spectrum-dialog-confirm-background-color, var(--spectrum-alias-background-color-default));
}
.spectrum-Underlay {

  visibility: hidden;

  opacity: 0;

  transition: transform var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
              opacity var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
              visibility 0ms linear var(--spectrum-global-animation-duration-100, 130ms);

  pointer-events: none;
}

.spectrum-Underlay.is-open {
  visibility: visible;

  opacity: 1;

  transition-delay: 0ms;

  pointer-events: auto;
}

.spectrum-Underlay {
  --spectrum-dialog-confirm-background-entry-animation-delay: 0ms;
  --spectrum-dialog-confirm-background-exit-animation-ease: cubic-bezier(0.5, 0, 1, 1);
  --spectrum-dialog-confirm-background-entry-animation-ease: cubic-bezier(0, 0, 0.40, 1);
}

.spectrum-Underlay {

  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 1;

  overflow: hidden;
  transition: opacity var(--spectrum-dialog-confirm-background-exit-animation-duration, var(--spectrum-global-animation-duration-300)) var(--spectrum-dialog-confirm-background-exit-animation-ease, var(--spectrum-global-animation-linear)) var(--spectrum-dialog-confirm-background-exit-animation-delay, var(--spectrum-global-animation-duration-200)),
              visibility 0ms linear calc(var(--spectrum-dialog-confirm-background-exit-animation-delay, var(--spectrum-global-animation-duration-200)) + var(--spectrum-dialog-confirm-background-exit-animation-duration, var(--spectrum-global-animation-duration-300)));
}

.spectrum-Underlay.is-open {
  transition: opacity var(--spectrum-dialog-confirm-background-entry-animation-duration, var(--spectrum-global-animation-duration-600)) var(--spectrum-dialog-confirm-background-entry-animation-ease, var(--spectrum-global-animation-linear)) var(--spectrum-dialog-confirm-background-entry-animation-delay, 0ms);
}

.spectrum-Underlay {
  background: var(--spectrum-dialog-confirm-overlay-background-color, var(--spectrum-alias-background-color-modal-overlay));
}
.spectrum-Underlay.svelte-em5khd{display:flex;flex-direction:row;justify-content:center;align-items:center;overflow:auto;overflow-x:hidden;background:transparent}.background.svelte-em5khd{background:var(--modal-background, rgba(0, 0, 0, 0.75));opacity:0.65;position:fixed;top:0;left:0;height:100vh;width:100vw;pointer-events:none}.modal-wrapper.svelte-em5khd{flex:1 1 auto;display:flex;flex-direction:row;-moz-box-pack:center;justify-content:center;align-items:flex-start;max-height:100%}.modal-inner-wrapper.svelte-em5khd{padding:40px;flex:1 1 auto;display:flex;flex-direction:row;-moz-box-pack:center;justify-content:center;align-items:flex-start;width:0;position:relative}.spectrum-Modal.svelte-em5khd{border:2px solid var(--spectrum-global-color-gray-200);overflow:visible;max-height:none;transform:none;--spectrum-dialog-confirm-border-radius:var(
      --spectrum-global-dimension-size-100
    );max-width:100%}.spectrum--lightest .spectrum-Modal.inline{border:var(--border-light)}.portal.svelte-em5khd,.portal.svelte-em5khd > div{display:contents}.spectrum-Dialog {
  --spectrum-dialog-fullscreen-header-text-size: 28px;

  --spectrum-dialog-confirm-small-width: 400px;
  --spectrum-dialog-confirm-medium-width: 480px;
  --spectrum-dialog-confirm-large-width: 640px;
  --spectrum-dialog-error-width: var(--spectrum-dialog-confirm-medium-width);

  --spectrum-dialog-confirm-hero-height: var(
    --spectrum-global-dimension-size-1600
  );
  --spectrum-dialog-confirm-description-padding: var(
    --spectrum-global-dimension-size-25
  );
  --spectrum-dialog-confirm-description-margin: calc(var(--spectrum-global-dimension-size-25) * -1);
  --spectrum-dialog-confirm-footer-padding-top: var(--spectrum-global-dimension-static-size-500, 40px);
  --spectrum-dialog-confirm-gap-size: var(--spectrum-global-dimension-size-200);
  --spectrum-dialog-confirm-buttongroup-padding-top: var(--spectrum-global-dimension-static-size-500, 40px);
  --spectrum-dialog-confirm-close-button-size: var(
    --spectrum-global-dimension-size-400
  );
  --spectrum-dialog-confirm-close-button-padding: calc(26px - var(--spectrum-global-dimension-size-175));
  --spectrum-dialog-confirm-divider-height: var(--spectrum-global-dimension-static-size-25, 2px);
}

.spectrum-Dialog {
  display: -ms-flexbox;
  display: flex;
  box-sizing: border-box;
  width: -webkit-fit-content;
  width: fit-content;
  min-width: var(--spectrum-dialog-confirm-min-width, var(--spectrum-global-dimension-static-size-3600));
  max-width: 100%;

  max-height: inherit;

  outline: none;
}

.spectrum-Dialog--small {
  width: var(--spectrum-dialog-confirm-small-width);
}

.spectrum-Dialog--medium {
  width: var(--spectrum-dialog-confirm-medium-width);
}

.spectrum-Dialog--large {
  width: var(--spectrum-dialog-confirm-large-width);
}

.spectrum-Dialog-hero {
  grid-area: hero;
  height: var(--spectrum-dialog-confirm-hero-height);

  border-top-left-radius: var(--spectrum-dialog-confirm-border-radius, var(--spectrum-global-dimension-size-50));
  border-top-right-radius: var(--spectrum-dialog-confirm-border-radius, var(--spectrum-global-dimension-size-50));

  background-size: cover;
  background-position: center center;
  overflow: hidden;
}

.spectrum-Dialog .spectrum-Dialog-grid {
  display: -ms-grid;
  display: grid;
  -ms-grid-columns:
    var(--spectrum-dialog-confirm-padding) auto 1fr auto minmax(0, auto)
    var(--spectrum-dialog-confirm-padding);
      grid-template-columns:
    var(--spectrum-dialog-confirm-padding) auto 1fr auto minmax(0, auto)
    var(--spectrum-dialog-confirm-padding);
  -ms-grid-rows: auto var(--spectrum-dialog-confirm-padding) auto auto 1fr auto var(
      --spectrum-dialog-confirm-padding
    );
      grid-template-rows: auto var(--spectrum-dialog-confirm-padding) auto auto 1fr auto var(
      --spectrum-dialog-confirm-padding
    );
  grid-template-areas:
    "hero hero    hero    hero        hero        hero"
    ".    .       .       .           .           ."
    ".    heading header  header      typeIcon    ."
    ".    divider divider divider     divider     ."
    ".    content content content     content     ."
    ".    footer  footer  buttonGroup buttonGroup ."
    ".    .       .       .           .           .";
  width: 100%;
}

[dir="ltr"] .spectrum-Dialog-heading {

  padding-right: var(--spectrum-dialog-confirm-gap-size);
}

[dir="rtl"] .spectrum-Dialog-heading {

  padding-left: var(--spectrum-dialog-confirm-gap-size);
}

.spectrum-Dialog-heading {
  grid-area: heading;

  margin: 0;

  font-size: var(--spectrum-dialog-confirm-title-text-size);
  font-weight: var(--spectrum-dialog-confirm-title-text-font-weight, var(--spectrum-global-font-weight-bold));
  line-height: var(--spectrum-dialog-confirm-title-text-line-height, var(--spectrum-alias-heading-text-line-height));

  outline: none;
}

[dir="ltr"] .spectrum-Dialog-heading.spectrum-Dialog-heading--noHeader {
    padding-right: 0;
}

[dir="rtl"] .spectrum-Dialog-heading.spectrum-Dialog-heading--noHeader {
    padding-left: 0;
}

.spectrum-Dialog-heading.spectrum-Dialog-heading--noHeader {
    grid-area: heading-start / heading-start / header-end / header-end;
  }

.spectrum-Dialog-header {
  grid-area: header;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-align: center;
      align-items: center;
  -ms-flex-pack: end;
      justify-content: flex-end;

  box-sizing: border-box;

  outline: none;
}

.spectrum-Dialog-typeIcon {
  grid-area: typeIcon;
}

.spectrum-Dialog .spectrum-Dialog-divider {
  grid-area: divider;
  width: 100%;
  margin-top: var(--spectrum-dialog-confirm-divider-margin-top, var(--spectrum-global-dimension-static-size-150));
  margin-bottom: var(--spectrum-dialog-confirm-divider-margin-bottom, var(--spectrum-global-dimension-static-size-200));
}

.spectrum-Dialog--noDivider .spectrum-Dialog-divider {
    display: none;
  }

.spectrum-Dialog--noDivider .spectrum-Dialog-heading {
    padding-bottom: calc(var(--spectrum-dialog-confirm-divider-margin-top, var(--spectrum-global-dimension-static-size-150)) + var(--spectrum-dialog-confirm-divider-margin-bottom, var(--spectrum-global-dimension-static-size-200)) + var(--spectrum-dialog-confirm-divider-height));
  }

.spectrum-Dialog-content {
  grid-area: content;
  box-sizing: border-box;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;

  outline: none;

  font-size: var(--spectrum-dialog-confirm-description-text-size);
  font-weight: var(--spectrum-dialog-confirm-description-text-font-weight, var(--spectrum-global-font-weight-regular));
  line-height: var(--spectrum-dialog-confirm-description-text-line-height, var(--spectrum-alias-component-text-line-height));
  padding: 0 var(--spectrum-dialog-confirm-description-padding);
  margin: 0 var(--spectrum-dialog-confirm-description-margin);
}

.spectrum-Dialog-footer {
  grid-area: footer;
  padding-top: var(--spectrum-dialog-confirm-footer-padding-top);

  display: -ms-flexbox;

  display: flex;
  -ms-flex-wrap: wrap;
      flex-wrap: wrap;

  outline: none;
}

.spectrum-Dialog-footer > *,
  .spectrum-Dialog-footer > .spectrum-Button + .spectrum-Button {
    margin-bottom: 0;
  }

[dir="ltr"] .spectrum-Dialog-buttonGroup {
  padding-left: var(--spectrum-dialog-confirm-gap-size);
}

[dir="rtl"] .spectrum-Dialog-buttonGroup {
  padding-right: var(--spectrum-dialog-confirm-gap-size);
}

.spectrum-Dialog-buttonGroup {
  grid-area: buttonGroup;
  padding-top: var(--spectrum-dialog-confirm-buttongroup-padding-top);
  display: -ms-flexbox;
  display: flex;
  -ms-flex-pack: end;
      justify-content: flex-end;
}

.spectrum-Dialog-buttonGroup.spectrum-Dialog-buttonGroup--noFooter {
    grid-area: footer-start / footer-start / buttonGroup-end / buttonGroup-end;
  }

.spectrum-Dialog.spectrum-Dialog--dismissable .spectrum-Dialog-grid {
  -ms-grid-columns:
    var(--spectrum-dialog-confirm-padding) auto 1fr auto minmax(0, auto)
    minmax(0, var(--spectrum-dialog-confirm-close-button-size)) var(--spectrum-dialog-confirm-padding);
      grid-template-columns:
    var(--spectrum-dialog-confirm-padding) auto 1fr auto minmax(0, auto)
    minmax(0, var(--spectrum-dialog-confirm-close-button-size)) var(--spectrum-dialog-confirm-padding);
  -ms-grid-rows: auto var(--spectrum-dialog-confirm-padding) auto auto 1fr auto var(
      --spectrum-dialog-confirm-padding
    );
      grid-template-rows: auto var(--spectrum-dialog-confirm-padding) auto auto 1fr auto var(
      --spectrum-dialog-confirm-padding
    );
  grid-template-areas:
    "hero hero    hero    hero        hero        hero        hero"
    ".    .       .       .           .           closeButton closeButton"
    ".    heading header  header      typeIcon    closeButton closeButton"
    ".    divider divider divider     divider     divider     ."
    ".    content content content     content     content     ."
    ".    footer  footer  buttonGroup buttonGroup buttonGroup ."
    ".    .       .       .           .           .           .";
}

.spectrum-Dialog.spectrum-Dialog--dismissable .spectrum-Dialog-grid .spectrum-Dialog-buttonGroup {
    display: none;
  }

.spectrum-Dialog.spectrum-Dialog--dismissable .spectrum-Dialog-grid .spectrum-Dialog-footer {
    grid-area: footer / footer/ buttonGroup / buttonGroup;
  }

[dir="ltr"] .spectrum-Dialog-closeButton {

  margin-right: var(--spectrum-dialog-confirm-close-button-padding);
}

[dir="rtl"] .spectrum-Dialog-closeButton {

  margin-left: var(--spectrum-dialog-confirm-close-button-padding);
}

.spectrum-Dialog-closeButton {
  grid-area: closeButton;
  -ms-flex-item-align: start;
      -ms-grid-row-align: start;
      align-self: start;
  justify-self: end;
  margin-top: var(--spectrum-dialog-confirm-close-button-padding);
}

.spectrum-Dialog--error {
  width: var(--spectrum-dialog-error-width, 90%);
}

.spectrum-Dialog--fullscreen {
  width: 100%;
  height: 100%;
}

.spectrum-Dialog--fullscreenTakeover {
  width: 100%;
  height: 100%;

  border-radius: 0;
}

.spectrum-Dialog--fullscreen,
.spectrum-Dialog--fullscreenTakeover {
  max-height: none;
  max-width: none;
}

.spectrum-Dialog--fullscreen.spectrum-Dialog .spectrum-Dialog-grid, .spectrum-Dialog--fullscreenTakeover.spectrum-Dialog .spectrum-Dialog-grid {
    display: -ms-grid;
    display: grid;
    -ms-grid-columns: var(--spectrum-dialog-confirm-padding) 1fr auto auto var(
        --spectrum-dialog-confirm-padding
      );
        grid-template-columns: var(--spectrum-dialog-confirm-padding) 1fr auto auto var(
        --spectrum-dialog-confirm-padding
      );
    -ms-grid-rows: var(--spectrum-dialog-confirm-padding) auto auto 1fr var(
        --spectrum-dialog-confirm-padding
      );
        grid-template-rows: var(--spectrum-dialog-confirm-padding) auto auto 1fr var(
        --spectrum-dialog-confirm-padding
      );
    grid-template-areas:
      ".    .       .       .            ."
      ".    heading header  buttonGroup  ."
      ".    divider divider divider      ."
      ".    content content content      ."
      ".    .       .       .            .";
  }

.spectrum-Dialog--fullscreen .spectrum-Dialog-heading, .spectrum-Dialog--fullscreenTakeover .spectrum-Dialog-heading {
    font-size: var(--spectrum-dialog-fullscreen-header-text-size);
  }

.spectrum-Dialog--fullscreen .spectrum-Dialog-content, .spectrum-Dialog--fullscreenTakeover .spectrum-Dialog-content {
    max-height: none;
  }

.spectrum-Dialog--fullscreen .spectrum-Dialog-footer,
  .spectrum-Dialog--fullscreen .spectrum-Dialog-buttonGroup,
  .spectrum-Dialog--fullscreenTakeover .spectrum-Dialog-footer,
  .spectrum-Dialog--fullscreenTakeover .spectrum-Dialog-buttonGroup {
    padding-top: 0px;
  }

.spectrum-Dialog--fullscreen .spectrum-Dialog-footer, .spectrum-Dialog--fullscreenTakeover .spectrum-Dialog-footer {
    display: none;
  }

.spectrum-Dialog--fullscreen .spectrum-Dialog-buttonGroup, .spectrum-Dialog--fullscreenTakeover .spectrum-Dialog-buttonGroup {
    grid-area: buttonGroup;
    -ms-flex-item-align: start;
        -ms-grid-row-align: start;
        align-self: start;
  }

@media screen and (max-inline-size: 700px) {
  .spectrum-Dialog .spectrum-Dialog-grid {
    -ms-grid-columns:
      var(--spectrum-dialog-confirm-padding) auto 1fr auto minmax(0, auto)
      var(--spectrum-dialog-confirm-padding);
        grid-template-columns:
      var(--spectrum-dialog-confirm-padding) auto 1fr auto minmax(0, auto)
      var(--spectrum-dialog-confirm-padding);
    -ms-grid-rows: auto var(--spectrum-dialog-confirm-padding) auto auto auto 1fr auto var(
        --spectrum-dialog-confirm-padding
      );
        grid-template-rows: auto var(--spectrum-dialog-confirm-padding) auto auto auto 1fr auto var(
        --spectrum-dialog-confirm-padding
      );
    grid-template-areas:
      "hero hero    hero    hero        hero        hero"
      ".    .       .       .           .           ."
      ".    heading heading heading     typeIcon    ."
      ".    header  header  header      header      ."
      ".    divider divider divider     divider     ."
      ".    content content content     content     ."
      ".    footer  footer  buttonGroup buttonGroup ."
      ".    .       .       .           .           .";
  }

  .spectrum-Dialog.spectrum-Dialog--dismissable .spectrum-Dialog-grid {
    -ms-grid-columns:
      var(--spectrum-dialog-confirm-padding) auto 1fr auto minmax(0, auto)
      minmax(0, var(--spectrum-dialog-confirm-close-button-size)) var(--spectrum-dialog-confirm-padding);
        grid-template-columns:
      var(--spectrum-dialog-confirm-padding) auto 1fr auto minmax(0, auto)
      minmax(0, var(--spectrum-dialog-confirm-close-button-size)) var(--spectrum-dialog-confirm-padding);
    -ms-grid-rows: auto var(--spectrum-dialog-confirm-padding) auto auto auto 1fr auto var(
        --spectrum-dialog-confirm-padding
      );
        grid-template-rows: auto var(--spectrum-dialog-confirm-padding) auto auto auto 1fr auto var(
        --spectrum-dialog-confirm-padding
      );
    grid-template-areas:
      "hero hero    hero    hero        hero        hero        hero"
      ".    .       .       .           .           closeButton closeButton"
      ".    heading heading heading     typeIcon    closeButton closeButton"
      ".    header  header  header      header      header      ."
      ".    divider divider divider     divider     divider     ."
      ".    content content content     content     content     ."
      ".    footer  footer  buttonGroup buttonGroup buttonGroup ."
      ".    .       .       .           .           .           .";
  }

  .spectrum-Dialog .spectrum-Dialog-header {
    -ms-flex-pack: start;
        justify-content: flex-start;
  }
    .spectrum-Dialog--fullscreen.spectrum-Dialog .spectrum-Dialog-grid, .spectrum-Dialog--fullscreenTakeover.spectrum-Dialog .spectrum-Dialog-grid {
      display: -ms-grid;
      display: grid;
      -ms-grid-columns: var(--spectrum-dialog-confirm-padding) 1fr var(
          --spectrum-dialog-confirm-padding
        );
          grid-template-columns: var(--spectrum-dialog-confirm-padding) 1fr var(
          --spectrum-dialog-confirm-padding
        );
      -ms-grid-rows: var(--spectrum-dialog-confirm-padding) auto auto auto 1fr auto var(
          --spectrum-dialog-confirm-padding
        );
          grid-template-rows: var(--spectrum-dialog-confirm-padding) auto auto auto 1fr auto var(
          --spectrum-dialog-confirm-padding
        );
      grid-template-areas:
        ".    .            ."
        ".    heading      ."
        ".    header       ."
        ".    divider      ."
        ".    content      ."
        ".    buttonGroup  ."
        ".    .            .";
    }

    .spectrum-Dialog--fullscreen .spectrum-Dialog-buttonGroup, .spectrum-Dialog--fullscreenTakeover .spectrum-Dialog-buttonGroup {
      padding-top: var(
        --spectrum-dialog-confirm-buttongroup-padding-top
      );
    }

    .spectrum-Dialog--fullscreen .spectrum-Dialog-heading, .spectrum-Dialog--fullscreenTakeover .spectrum-Dialog-heading {
      font-size: var(--spectrum-dialog-confirm-title-text-size);
    }
}

@media (forced-colors: active) {
  .spectrum-Dialog {
    border: solid;
  }
}

.spectrum-Dialog-heading {
  color: var(--spectrum-dialog-confirm-title-text-color, var(--spectrum-global-color-gray-900));
}

.spectrum-Dialog-content {
  color: var(--spectrum-dialog-confirm-description-text-color, var(--spectrum-global-color-gray-800));
}

.spectrum-Dialog-typeIcon {
  color: var(--spectrum-dialog-confirm-icon-color, var(--spectrum-global-color-gray-900));
}

.spectrum-Dialog--error .spectrum-Dialog-typeIcon {
    color: var(--spectrum-dialog-error-icon-color, var(--spectrum-semantic-negative-color-icon));
  }
.spectrum-Dialog--extraLarge.svelte-n0k36s.svelte-n0k36s{width:1000px}.spectrum-Dialog--medium.svelte-n0k36s.svelte-n0k36s{width:540px}.content-grid.svelte-n0k36s.svelte-n0k36s{display:grid;position:relative;gap:var(--spacing-xl)}.spectrum-Dialog-content.svelte-n0k36s.svelte-n0k36s{overflow:visible}.no-grid.svelte-n0k36s .spectrum-Dialog-content.svelte-n0k36s{border-top:2px solid var(--spectrum-global-color-gray-200);border-bottom:2px solid var(--spectrum-global-color-gray-200)}.spectrum-Dialog-heading.svelte-n0k36s.svelte-n0k36s{font-size:24px}.no-grid.svelte-n0k36s .spectrum-Dialog-heading.svelte-n0k36s{margin-top:12px;margin-left:12px}.spectrum-Dialog.no-grid.svelte-n0k36s.svelte-n0k36s{width:100%}.spectrum-Dialog.no-grid.svelte-n0k36s .spectrum-Dialog-buttonGroup.svelte-n0k36s{padding:12px}.spectrum-Dialog-heading.svelte-n0k36s.svelte-n0k36s{font-family:var(--font-accent);font-weight:600}.spectrum-Dialog-heading.noDivider.svelte-n0k36s.svelte-n0k36s{margin-bottom:12px}.spectrum-Dialog-buttonGroup.svelte-n0k36s.svelte-n0k36s{gap:var(--spectrum-global-dimension-static-size-200)}.close-icon.svelte-n0k36s.svelte-n0k36s{position:absolute;top:15px;right:15px;font-size:var(--font-size-m)}.close-icon.svelte-n0k36s svg{margin-right:0}.header-spacing.svelte-n0k36s.svelte-n0k36s{display:flex;justify-content:space-between}.secondary-action.svelte-n0k36s.svelte-n0k36s{margin-right:auto}.spectrum-Dialog-buttonGroup.svelte-n0k36s.svelte-n0k36s{padding-left:0}.confirm-wrap.svelte-n0k36s .spectrum-Button-label{display:contents}.wrap.svelte-9ckj1m{overflow-wrap:anywhere}.spectrum-Toast.svelte-9ckj1m{pointer-events:all}.wide.svelte-9ckj1m{width:100%}.actionBody.svelte-9ckj1m{justify-content:space-between;display:flex;width:100%;align-items:center}.toast-icon.svelte-9ckj1m{margin:0 10px 0 -4px;display:grid;place-items:center}.notifications.svelte-1m17u8b{position:fixed;bottom:40px;left:0;right:0;margin:0 auto;padding:0;z-index:9999;display:flex;flex-direction:column;justify-content:flex-start;align-items:center;pointer-events:none;gap:10px}.spectrum-Pagination--explicit,
.spectrum-Pagination--listing {
  display: -ms-flexbox;
  display: flex;
  -ms-flex-direction: row;
      flex-direction: row;
  -ms-flex-align: center;
      align-items: center;
}

.spectrum-Pagination-textfield {
  width: var(--spectrum-pagination-textfield-width, var(--spectrum-global-dimension-size-600));
  min-width: var(--spectrum-pagination-textfield-width, var(--spectrum-global-dimension-size-600));
}

[dir="ltr"] .spectrum-Pagination-counter {
  margin-left: var(--spectrum-pagination-counter-margin-left, var(--spectrum-global-dimension-size-65));
}

[dir="rtl"] .spectrum-Pagination-counter {
  margin-right: var(--spectrum-pagination-counter-margin-left, var(--spectrum-global-dimension-size-65));
}

[dir="ltr"] .spectrum-Pagination-prevButton {
  margin-right: var(--spectrum-pagination-page-button-margin-horizontal, var(--spectrum-global-dimension-size-65));
}

[dir="rtl"] .spectrum-Pagination-prevButton {
  margin-left: var(--spectrum-pagination-page-button-margin-horizontal, var(--spectrum-global-dimension-size-65));
}

[dir="ltr"] .spectrum-Pagination-nextButton {
  margin-left: var(--spectrum-pagination-page-button-margin-horizontal, var(--spectrum-global-dimension-size-65));
}

[dir="rtl"] .spectrum-Pagination-nextButton {
  margin-right: var(--spectrum-pagination-page-button-margin-horizontal, var(--spectrum-global-dimension-size-65));
}

[dir="rtl"] .spectrum-Pagination-prevButton .spectrum-Icon,[dir="rtl"]  .spectrum-Pagination-nextButton .spectrum-Icon { transform: matrix(-1, 0, 0, 1, 0, 0) ; }

.spectrum-Pagination-pageButton:hover {
    background-color: var(--spectrum-pagination-page-button-background-color-hover, var(--spectrum-alias-background-color-hover-overlay));
  }

.spectrum-Pagination-pageButton:focus {
    border-color: var(--spectrum-pagination-page-button-border-color-key-focus, var(--spectrum-alias-focus-color));
  }

.spectrum-Pagination-pageButton.is-selected {
    background-color: var(--spectrum-pagination-page-button-background-color-down, var(--spectrum-global-color-gray-800));
    color: var(--spectrum-pagination-page-button-text-color-down, var(--spectrum-global-color-static-white));
  }

.spectrum-Pagination-counter {
  color: var(--spectrum-alias-label-text-color, var(--spectrum-global-color-gray-700));
}
.spectrum-Pagination-counter.svelte-1w0vi9g{margin-left:0;user-select:none}.is-disabled.svelte-1w0vi9g:hover{cursor:initial}.preview.svelte-1mbca3e{display:flex;gap:8px}.popover.svelte-1mbca3e{padding:var(--spacing-s) var(--spacing-l) var(--spacing-m) var(--spacing-l);display:flex;flex-direction:column;gap:var(--spacing-l)}.icons.svelte-1mbca3e{display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr;gap:var(--spacing-m)}.icon.svelte-1mbca3e{padding:4px;border-radius:4px;transition:background-color 130ms ease-out}.icon.selected.svelte-1mbca3e{color:var(--spectrum-global-color-blue-600)}.icon.svelte-1mbca3e:hover{cursor:pointer;background-color:var(--spectrum-global-color-gray-100)}.spectrum-ProgressBar--sizeS {
  --spectrum-progressbar-border-radius: var(--spectrum-progressbar-s-border-radius);
  --spectrum-progressbar-label-gap-y: var(--spectrum-progressbar-s-label-gap-y, var(--spectrum-global-dimension-size-50));
  --spectrum-progressbar-height: var(--spectrum-progressbar-s-height, var(--spectrum-global-dimension-size-50));
  --spectrum-progressbar-width: var(--spectrum-progressbar-s-width, var(--spectrum-global-dimension-static-size-2400));
  --spectrum-progressbar-indeterminate-fill-width: var(--spectrum-progressbar-s-indeterminate-fill-width, var(--spectrum-global-dimension-size-1700));
  --spectrum-progressbar-indeterminate-duration: var(--spectrum-progressbar-s-indeterminate-duration, var(--spectrum-global-animation-duration-2000));
  --spectrum-fieldlabel-side-padding-right: var(--spectrum-fieldlabel-side-s-padding-right, var(--spectrum-global-dimension-size-130));
}

.spectrum-ProgressBar--sizeM {
  --spectrum-progressbar-border-radius: var(--spectrum-progressbar-m-border-radius);
  --spectrum-progressbar-label-gap-y: var(--spectrum-progressbar-m-label-gap-y, var(--spectrum-global-dimension-size-50));
  --spectrum-progressbar-height: var(--spectrum-progressbar-m-height, var(--spectrum-global-dimension-size-75));
  --spectrum-progressbar-width: var(--spectrum-progressbar-m-width, var(--spectrum-global-dimension-static-size-2400));
  --spectrum-progressbar-indeterminate-fill-width: var(--spectrum-progressbar-m-indeterminate-fill-width, var(--spectrum-global-dimension-size-1700));
  --spectrum-progressbar-indeterminate-duration: var(--spectrum-progressbar-m-indeterminate-duration, var(--spectrum-global-animation-duration-2000));
  --spectrum-fieldlabel-side-padding-right: var(--spectrum-fieldlabel-side-m-padding-right, var(--spectrum-global-dimension-size-150));
}

.spectrum-ProgressBar--sizeL {
  --spectrum-progressbar-label-gap-y: var(--spectrum-progressbar-l-label-gap-y, var(--spectrum-global-dimension-size-50));
  --spectrum-progressbar-height: var(--spectrum-progressbar-l-height, var(--spectrum-global-dimension-size-100));
  --spectrum-progressbar-border-radius: var(--spectrum-progressbar-l-border-radius, var(--spectrum-global-dimension-size-50));
  --spectrum-progressbar-width: var(--spectrum-progressbar-l-width, var(--spectrum-global-dimension-static-size-2500));
  --spectrum-progressbar-indeterminate-fill-width: var(--spectrum-progressbar-l-indeterminate-fill-width, var(--spectrum-global-dimension-size-1800));
  --spectrum-progressbar-indeterminate-duration: var(--spectrum-progressbar-l-indeterminate-duration, var(--spectrum-global-animation-duration-2000));
  --spectrum-fieldlabel-side-padding-right: var(--spectrum-fieldlabel-side-l-padding-right, var(--spectrum-global-dimension-size-175));
}

.spectrum-ProgressBar--sizeXL {
  --spectrum-progressbar-border-radius: var(--spectrum-progressbar-xl-border-radius);
  --spectrum-progressbar-label-gap-y: var(--spectrum-progressbar-xl-label-gap-y, var(--spectrum-global-dimension-size-50));
  --spectrum-progressbar-height: var(--spectrum-progressbar-xl-height, var(--spectrum-global-dimension-size-125));
  --spectrum-progressbar-width: var(--spectrum-progressbar-xl-width, var(--spectrum-global-dimension-static-size-2800));
  --spectrum-progressbar-indeterminate-fill-width: var(--spectrum-progressbar-xl-indeterminate-fill-width, var(--spectrum-global-dimension-size-2000));
  --spectrum-progressbar-indeterminate-duration: var(--spectrum-progressbar-xl-indeterminate-duration, var(--spectrum-global-animation-duration-2000));
  --spectrum-fieldlabel-side-padding-right: var(--spectrum-fieldlabel-side-xl-padding-right, var(--spectrum-global-dimension-size-185));
}

.spectrum-ProgressBar {
  position: relative;
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-flow: row wrap;
      flex-flow: row wrap;
  -ms-flex-pack: justify;
      justify-content: space-between;
  -ms-flex-align: center;
      align-items: center;
  width: var(--spectrum-progressbar-width);
  vertical-align: top;
}

.spectrum-ProgressBar-track {
  overflow: hidden;
  width: 100%;
  height: var(--spectrum-progressbar-height);
  border-radius: var(--spectrum-progressbar-border-radius);
  z-index: 1;
}

.spectrum-ProgressBar-fill {
  border: none;
  height: var(--spectrum-progressbar-height);

  transition: width 1s;
}

[dir="ltr"] .spectrum-ProgressBar-label,[dir="ltr"] 
.spectrum-ProgressBar-percentage {
  text-align: left;
}

[dir="rtl"] .spectrum-ProgressBar-label,[dir="rtl"] 
.spectrum-ProgressBar-percentage {
  text-align: right;
}

.spectrum-ProgressBar-label,
.spectrum-ProgressBar-percentage {
  margin-bottom: var(--spectrum-progressbar-label-gap-y);
}

.spectrum-ProgressBar-label {
  -ms-flex: 1 1 0%;
      flex: 1 1 0%;
}

[dir="ltr"] .spectrum-ProgressBar-percentage {
  margin-left: var(--spectrum-fieldlabel-side-padding-right);
}

[dir="rtl"] .spectrum-ProgressBar-percentage {
  margin-right: var(--spectrum-fieldlabel-side-padding-right);
}

.spectrum-ProgressBar-percentage {
  -ms-flex-item-align: start;
      align-self: flex-start;
}

.spectrum-ProgressBar--sideLabel {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-flow: row;
      flex-flow: row;
  -ms-flex-pack: justify;
      justify-content: space-between;
  width: auto;
}

.spectrum-ProgressBar--sideLabel .spectrum-ProgressBar-track {
    min-width: var(--spectrum-progressbar-width);
    -ms-flex: 1 1 var(--spectrum-progressbar-width);
        flex: 1 1 var(--spectrum-progressbar-width);
  }

[dir="ltr"] .spectrum-ProgressBar--sideLabel .spectrum-ProgressBar-label {
    margin-right: var(--spectrum-fieldlabel-side-padding-right);
}

[dir="rtl"] .spectrum-ProgressBar--sideLabel .spectrum-ProgressBar-label {
    margin-left: var(--spectrum-fieldlabel-side-padding-right);
}

.spectrum-ProgressBar--sideLabel .spectrum-ProgressBar-label {
    -ms-flex-positive: 0;
        flex-grow: 0;
    margin-bottom: 0;
  }

[dir="ltr"] .spectrum-ProgressBar--sideLabel .spectrum-ProgressBar-percentage {
    text-align: right;
}

[dir="rtl"] .spectrum-ProgressBar--sideLabel .spectrum-ProgressBar-percentage {
    text-align: left;
}

[dir="ltr"] .spectrum-ProgressBar--sideLabel .spectrum-ProgressBar-percentage {
    margin-left: var(--spectrum-fieldlabel-side-padding-right);
}

[dir="rtl"] .spectrum-ProgressBar--sideLabel .spectrum-ProgressBar-percentage {
    margin-right: var(--spectrum-fieldlabel-side-padding-right);
}

.spectrum-ProgressBar--sideLabel .spectrum-ProgressBar-percentage {
    -ms-flex-order: 3;
        order: 3;
    margin-bottom: 0;
  }

.spectrum-ProgressBar--indeterminate .spectrum-ProgressBar-fill {
  width: var(--spectrum-progressbar-indeterminate-fill-width);
  position: relative;
  animation-timing-function: var(
    --spectrum-progressbar-indeterminate-animation-ease
  );
  will-change: transform;
}

[dir="ltr"] .spectrum-ProgressBar--indeterminate .spectrum-ProgressBar-fill {
  animation: indeterminate-loop-ltr
    var(--spectrum-progressbar-indeterminate-duration) infinite;
}

[dir="rtl"] .spectrum-ProgressBar--indeterminate .spectrum-ProgressBar-fill {
  animation: indeterminate-loop-rtl
    var(--spectrum-progressbar-indeterminate-duration) infinite;
}

@keyframes indeterminate-loop-ltr {
  from {
    transform: translate(
      calc(-1 * var(--spectrum-progressbar-indeterminate-fill-width))
    );
  }
  to {
    transform: translate(var(--spectrum-progressbar-width));
  }
}

@keyframes indeterminate-loop-rtl {
  from {
    transform: translate(var(--spectrum-progressbar-width));
  }
  to {
    transform: translate(calc(-1 * var(--spectrum-progressbar-width)));
  }
}

.spectrum-ProgressBar .spectrum-ProgressBar-fill {
    background: var(--spectrum-progressbar-m-track-fill-color, var(--spectrum-global-color-blue-500));
  }

.spectrum-ProgressBar .spectrum-ProgressBar-track {
    background-color: var(--spectrum-progressbar-m-track-color, var(--spectrum-alias-track-color-default));
  }

.spectrum-ProgressBar.spectrum-ProgressBar--overBackground .spectrum-ProgressBar-fill {
      background: var(--spectrum-progressbar-m-over-background-track-fill-color, var(--spectrum-global-color-static-white));
    }

.spectrum-ProgressBar.spectrum-ProgressBar--overBackground .spectrum-ProgressBar-label,
    .spectrum-ProgressBar.spectrum-ProgressBar--overBackground .spectrum-ProgressBar-percentage {
      color: var(--spectrum-progressbar-m-over-background-track-fill-color, var(--spectrum-global-color-static-white));
    }

.spectrum-ProgressBar.spectrum-ProgressBar--overBackground .spectrum-ProgressBar-track {
      background-color: var(--spectrum-progressbar-m-over-background-track-color, var(--spectrum-alias-track-color-over-background));
    }

.spectrum-ProgressBar.is-positive .spectrum-ProgressBar-fill {
      background: var(--spectrum-meter-positive-m-track-fill-color, var(--spectrum-semantic-positive-color-status));
    }

.spectrum-ProgressBar.is-notice .spectrum-ProgressBar-fill {
      background: var(--spectrum-meter-notice-m-track-fill-color, var(--spectrum-semantic-notice-color-status));
    }

.spectrum-ProgressBar.is-negative .spectrum-ProgressBar-fill {
      background: var(--spectrum-meter-negative-m-track-fill-color, var(--spectrum-semantic-negative-color-status));
    }

.spectrum-ProgressBar-label,
.spectrum-ProgressBar-percentage {
  color: var(--spectrum-fieldlabel-m-text-color, var(--spectrum-alias-label-text-color));
}

.spectrum-ProgressBar-label,
.spectrum-ProgressBar-percentage {
  color: var(--spectrum-fieldlabel-m-text-color, var(--spectrum-alias-label-text-color));
}

.spectrum-ProgressBar-label,
.spectrum-ProgressBar-percentage {
  color: var(--spectrum-fieldlabel-m-text-color, var(--spectrum-alias-label-text-color));
}
.color-green.svelte-1nu3ola{background:#009562}.color-red.svelte-1nu3ola{background:#dd2019}.spectrum-ProgressBar-fill.svelte-1nu3ola{transition:width var(--duration) ease-out}.view-mode-toggle.svelte-1v7uptw.svelte-1v7uptw{display:flex;gap:var(--spacing-l);flex-shrink:0}.view-mode-toggle.svelte-1v7uptw .group.svelte-1v7uptw{border-radius:12px;display:flex;flex-direction:row;background:var(--spectrum-global-color-gray-100);padding:2px;border:1px solid var(--spectrum-global-color-gray-300)}.right.svelte-1v7uptw *{border-radius:0 10px 10px 0}.left.svelte-1v7uptw *{border-radius:10px 0 0 10px}.wrapper.svelte-1v7uptw.svelte-1v7uptw{position:relative}.notification.svelte-1v7uptw.svelte-1v7uptw{position:absolute;right:-6px;top:-6px;background:var(--spectrum-global-color-static-red-600);color:white;border-radius:8px;padding:0 4px;z-index:2;font-size:0.8em;cursor:pointer}.disabled.svelte-1v7uptw.svelte-1v7uptw{opacity:0.8}.spectrum-Table {
  border-collapse: separate;
  border-spacing: 0;
}

[dir="ltr"] .spectrum-Table-sortedIcon {
  margin-left: var(--spectrum-table-header-sort-icon-gap, var(--spectrum-global-dimension-size-125));
}

[dir="rtl"] .spectrum-Table-sortedIcon {
  margin-right: var(--spectrum-table-header-sort-icon-gap, var(--spectrum-global-dimension-size-125));
}

.spectrum-Table-sortedIcon {
  display: none;

  vertical-align: middle;

  transition: transform var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
}

[dir="ltr"] .spectrum-Table-headCell {
  text-align: left;
}

[dir="rtl"] .spectrum-Table-headCell {
  text-align: right;
}

.spectrum-Table-headCell {
  box-sizing: border-box;
  font-size: var(--spectrum-table-header-text-size, var(--spectrum-global-dimension-font-size-50));
  font-weight: var(--spectrum-table-header-text-font-weight, var(--spectrum-global-font-weight-bold));
  line-height: var(--spectrum-table-header-text-line-height, var(--spectrum-alias-heading-text-line-height));
  min-height: var(--spectrum-table-header-min-height, var(--spectrum-global-dimension-size-150));
  letter-spacing: var(--spectrum-table-header-text-letter-spacing, var(--spectrum-global-font-letter-spacing-medium));
  text-transform: uppercase;
  padding-top: var(--spectrum-table-header-padding-y, var(--spectrum-global-dimension-static-size-125));
  padding-bottom: var(--spectrum-table-header-padding-y, var(--spectrum-global-dimension-static-size-125));
  padding-left: var(--spectrum-table-header-padding-x, var(--spectrum-global-dimension-size-200));
  padding-right: var(--spectrum-table-header-padding-x, var(--spectrum-global-dimension-size-200));
  transition: color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
  cursor: default;
  outline: 0;
  border-radius: var(--spectrum-table-header-border-radius, 0px);
}

.spectrum-Table-headCell.is-sortable {
    cursor: pointer;
  }

.spectrum-Table-headCell.is-sorted-asc .spectrum-Table-sortedIcon, .spectrum-Table-headCell.is-sorted-desc .spectrum-Table-sortedIcon {
      display: inline-block;
      margin-top: calc(var(--spectrum-global-dimension-size-25) * -1);
    }

.spectrum-Table-headCell.is-sorted-asc .spectrum-Table-sortedIcon {
      transform: rotateZ(-90deg);
    }

.spectrum-Table-cell--alignCenter {
  text-align: center;
}

[dir="ltr"] .spectrum-Table-cell--alignRight {
  text-align: right;
}

[dir="rtl"] .spectrum-Table-cell--alignRight {
  text-align: left;
}

[dir="ltr"] .spectrum-Table-body.is-drop-target::before,[dir="ltr"] 
.spectrum-Table-row.is-drop-target::before {
    left: 0;
}

[dir="rtl"] .spectrum-Table-body.is-drop-target::before,[dir="rtl"] 
.spectrum-Table-row.is-drop-target::before {
    right: 0;
}

[dir="ltr"] .spectrum-Table-body.is-drop-target::before,[dir="ltr"] 
.spectrum-Table-row.is-drop-target::before {
    right: 0;
}

[dir="rtl"] .spectrum-Table-body.is-drop-target::before,[dir="rtl"] 
.spectrum-Table-row.is-drop-target::before {
    left: 0;
}

.spectrum-Table-body.is-drop-target::before,
.spectrum-Table-row.is-drop-target::before {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    z-index: 1;
  }

.spectrum-Table-body {
  position: relative;

  border-width: var(--spectrum-table-border-size, var(--spectrum-alias-border-size-thin));
  border-radius: var(--spectrum-table-border-radius, var(--spectrum-alias-border-radius-regular));
  overflow: auto;
  vertical-align: var(--spectrum-table-cell-vertical-alignment, top);
}

.spectrum-Table:not(.spectrum-Table--quiet) tbody.spectrum-Table-body {
    border-width: var(--spectrum-table-border-size, var(--spectrum-alias-border-size-thin));
    border-radius: var(--spectrum-table-border-radius, var(--spectrum-alias-border-radius-regular));
  }

[dir="ltr"] .spectrum-Table:not(.spectrum-Table--quiet) tbody.spectrum-Table-body .spectrum-Table-row:first-child .spectrum-Table-cell:first-child {
      border-top-left-radius: var(--spectrum-table-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-Table:not(.spectrum-Table--quiet) tbody.spectrum-Table-body .spectrum-Table-row:first-child .spectrum-Table-cell:first-child {
      border-top-right-radius: var(--spectrum-table-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="ltr"] .spectrum-Table:not(.spectrum-Table--quiet) tbody.spectrum-Table-body .spectrum-Table-row:first-child .spectrum-Table-cell:last-child {
      border-top-right-radius: var(--spectrum-table-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-Table:not(.spectrum-Table--quiet) tbody.spectrum-Table-body .spectrum-Table-row:first-child .spectrum-Table-cell:last-child {
      border-top-left-radius: var(--spectrum-table-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="ltr"] .spectrum-Table:not(.spectrum-Table--quiet) tbody.spectrum-Table-body .spectrum-Table-row:last-child .spectrum-Table-cell:first-child {
      border-bottom-left-radius: var(--spectrum-table-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-Table:not(.spectrum-Table--quiet) tbody.spectrum-Table-body .spectrum-Table-row:last-child .spectrum-Table-cell:first-child {
      border-bottom-right-radius: var(--spectrum-table-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="ltr"] .spectrum-Table:not(.spectrum-Table--quiet) tbody.spectrum-Table-body .spectrum-Table-row:last-child .spectrum-Table-cell:last-child {
      border-bottom-right-radius: var(--spectrum-table-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-Table:not(.spectrum-Table--quiet) tbody.spectrum-Table-body .spectrum-Table-row:last-child .spectrum-Table-cell:last-child {
      border-bottom-left-radius: var(--spectrum-table-border-radius, var(--spectrum-alias-border-radius-regular));
}

.spectrum-Table-cell {
  box-sizing: border-box;
  font-size: var(--spectrum-table-cell-text-size, var(--spectrum-alias-font-size-default));
  font-weight: var(--spectrum-table-cell-text-font-weight, var(--spectrum-global-font-weight-regular));
  line-height: var(--spectrum-table-cell-text-line-height, var(--spectrum-alias-component-text-line-height));
  padding-top: var(--spectrum-table-cell-padding-y, var(--spectrum-global-dimension-size-175));
  padding-bottom: var(--spectrum-table-cell-padding-y, var(--spectrum-global-dimension-size-175));
  padding-left: var(--spectrum-table-cell-padding-x, var(--spectrum-global-dimension-size-200));
  padding-right: var(--spectrum-table-cell-padding-x, var(--spectrum-global-dimension-size-200));
  min-height: calc(var(--spectrum-table-cell-min-height, var(--spectrum-global-dimension-size-600)) - var(--spectrum-table-cell-padding-y, var(--spectrum-global-dimension-size-175)) * 2);
}

.spectrum-Table-cell,
.spectrum-Table-headCell {
  position: relative;
}

.spectrum-Table-cell.focus-ring,
  .spectrum-Table-cell.is-focused,
  .spectrum-Table-headCell.focus-ring,
  .spectrum-Table-headCell.is-focused {
    outline: none;
  }

[dir="ltr"] .spectrum-Table-cell.focus-ring::before,[dir="ltr"]  .spectrum-Table-cell.is-focused::before,[dir="ltr"]  .spectrum-Table-headCell.focus-ring::before,[dir="ltr"]  .spectrum-Table-headCell.is-focused::before {
      right: 0;
}

[dir="rtl"] .spectrum-Table-cell.focus-ring::before,[dir="rtl"]  .spectrum-Table-cell.is-focused::before,[dir="rtl"]  .spectrum-Table-headCell.focus-ring::before,[dir="rtl"]  .spectrum-Table-headCell.is-focused::before {
      left: 0;
}

[dir="ltr"] .spectrum-Table-cell.focus-ring::before,[dir="ltr"]  .spectrum-Table-cell.is-focused::before,[dir="ltr"]  .spectrum-Table-headCell.focus-ring::before,[dir="ltr"]  .spectrum-Table-headCell.is-focused::before {
      left: 0;
}

[dir="rtl"] .spectrum-Table-cell.focus-ring::before,[dir="rtl"]  .spectrum-Table-cell.is-focused::before,[dir="rtl"]  .spectrum-Table-headCell.focus-ring::before,[dir="rtl"]  .spectrum-Table-headCell.is-focused::before {
      right: 0;
}

.spectrum-Table-cell.focus-ring::before, .spectrum-Table-cell.is-focused::before, .spectrum-Table-headCell.focus-ring::before, .spectrum-Table-headCell.is-focused::before {
      content: '';
      z-index: 1;
      position: absolute;

      top: 0;
      bottom: 0;

      border-radius: calc(var(--spectrum-table-cell-border-radius-key-focus, var(--spectrum-alias-border-radius-regular)) - 1px);
    }

[dir="ltr"] .spectrum-Table-headCell.focus-ring::before,[dir="ltr"]  .spectrum-Table-headCell.is-focused::before {
      right: var(--spectrum-table-border-size, var(--spectrum-alias-border-size-thin));
}

[dir="rtl"] .spectrum-Table-headCell.focus-ring::before,[dir="rtl"]  .spectrum-Table-headCell.is-focused::before {
      left: var(--spectrum-table-border-size, var(--spectrum-alias-border-size-thin));
}

[dir="ltr"] .spectrum-Table-headCell.focus-ring::before,[dir="ltr"]  .spectrum-Table-headCell.is-focused::before {
      left: var(--spectrum-table-border-size, var(--spectrum-alias-border-size-thin));
}

[dir="rtl"] .spectrum-Table-headCell.focus-ring::before,[dir="rtl"]  .spectrum-Table-headCell.is-focused::before {
      right: var(--spectrum-table-border-size, var(--spectrum-alias-border-size-thin));
}

.spectrum-Table-headCell.focus-ring::before, .spectrum-Table-headCell.is-focused::before {
      top: var(--spectrum-table-border-size, var(--spectrum-alias-border-size-thin));
      bottom: var(--spectrum-table-border-size, var(--spectrum-alias-border-size-thin));
    }

[dir="ltr"] .spectrum-Table-cell--divider {
  border-right-width: var(--spectrum-table-divider-border-size, var(--spectrum-alias-border-size-thin));
}

[dir="rtl"] .spectrum-Table-cell--divider {
  border-left-width: var(--spectrum-table-divider-border-size, var(--spectrum-alias-border-size-thin));
}

.spectrum-Table-row {
  position: relative;
  cursor: pointer;
  transition: background-color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
}

.spectrum-Table-row:focus {
    outline: 0;
  }

.spectrum-Table > .spectrum-Table-body > .spectrum-Table-row:last-of-type {
  border-bottom-style: none;
}

.spectrum-Table--quiet .spectrum-Table-body {
    border-radius: var(--spectrum-table-quiet-border-radius, 0px);
  }

.spectrum-Table--quiet .spectrum-Table-body.is-drop-target::before, .spectrum-Table--quiet .spectrum-Table-row.is-drop-target::before {
        border-radius: var(--spectrum-alias-border-radius-regular, var(--spectrum-global-dimension-size-50));
      }

[dir="ltr"] .spectrum-Table-checkboxCell {
  padding-right: var(--spectrum-table-cell-checkbox-padding-right, var(--spectrum-global-dimension-size-100));
}

[dir="rtl"] .spectrum-Table-checkboxCell {
  padding-left: var(--spectrum-table-cell-checkbox-padding-right, var(--spectrum-global-dimension-size-100));
}

.spectrum-Table-checkboxCell {
  padding-top: 0px;
  padding-bottom: 0px;
  vertical-align: var(--spectrum-table-cell-checkbox-vertical-alignment, middle);
}

.spectrum-Table-checkbox {
  vertical-align: super;
}

.spectrum-Table-headCell {
  color: var(--spectrum-table-header-text-color, var(--spectrum-alias-label-text-color));
  background-color: var(--spectrum-table-header-background-color, var(--spectrum-alias-background-color-transparent));
}

.spectrum-Table-headCell.is-sortable .spectrum-Table-sortedIcon {
      color: var(--spectrum-table-header-sort-icon-color, var(--spectrum-global-color-gray-600));
    }

.spectrum-Table-headCell.is-sortable:hover {
      color: var(--spectrum-table-header-text-color-hover, var(--spectrum-alias-text-color-hover));
    }

.spectrum-Table-headCell.is-sortable:hover .spectrum-Table-sortedIcon {
        color: var(--spectrum-table-header-sort-icon-color-hover, var(--spectrum-alias-icon-color-hover));
      }

.spectrum-Table-headCell.is-sortable.focus-ring,
    .spectrum-Table-headCell.is-sortable.is-focused {
      color: var(--spectrum-table-header-text-color-key-focus, var(--spectrum-alias-text-color-hover));
    }

.spectrum-Table-headCell.is-sortable.focus-ring .spectrum-Table-sortedIcon, .spectrum-Table-headCell.is-sortable.is-focused .spectrum-Table-sortedIcon {
        color: var(--spectrum-table-header-sort-icon-color-key-focus, var(--spectrum-alias-icon-color-focus));
      }

.spectrum-Table-headCell.is-sortable:active {
      color: var(--spectrum-table-header-text-color-down, var(--spectrum-alias-text-color-down));
    }

.spectrum-Table-headCell.is-sortable:active .spectrum-Table-sortedIcon {
        color: var(--spectrum-table-header-sort-icon-color-down, var(--spectrum-alias-icon-color-down));
      }

.spectrum-Table-cell.focus-ring::before, .spectrum-Table-cell.is-focused::before, .spectrum-Table-headCell.focus-ring::before, .spectrum-Table-headCell.is-focused::before {
      box-shadow: inset 0 0 0 2px
        var(--spectrum-table-cell-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    }

.spectrum-Table-body {
  border-style: solid;
  border-color: var(--spectrum-table-border-color, var(--spectrum-alias-border-color-mid));
  background-color: var(--spectrum-table-background-color, var(--spectrum-global-color-gray-50));
}

.spectrum-Table-body.is-drop-target {
    border-color: var(--spectrum-alias-border-color-focus, var(--spectrum-global-color-blue-400));
    box-shadow: 0 0 0 1px var(--spectrum-alias-border-color-focus, var(--spectrum-global-color-blue-400));
  }

.spectrum-Table-body.is-drop-target::before {
      background-color: var(--spectrum-alias-highlight-selected);
    }

tbody.spectrum-Table-body {
  border: none;
}

tbody.spectrum-Table-body .spectrum-Table-row {
    border-top: none;
  }

tbody.spectrum-Table-body .spectrum-Table-cell {
    border-top: 1px solid var(--spectrum-table-border-color, var(--spectrum-alias-border-color-mid));
  }

[dir="ltr"] tbody.spectrum-Table-body .spectrum-Table-row .spectrum-Table-cell:first-child {
    border-left: 1px solid var(--spectrum-table-border-color, var(--spectrum-alias-border-color-mid));
}

[dir="rtl"] tbody.spectrum-Table-body .spectrum-Table-row .spectrum-Table-cell:first-child {
    border-right: 1px solid var(--spectrum-table-border-color, var(--spectrum-alias-border-color-mid));
}

[dir="ltr"] tbody.spectrum-Table-body .spectrum-Table-row .spectrum-Table-cell:last-child {
    border-right: 1px solid var(--spectrum-table-border-color, var(--spectrum-alias-border-color-mid));
}

[dir="rtl"] tbody.spectrum-Table-body .spectrum-Table-row .spectrum-Table-cell:last-child {
    border-left: 1px solid var(--spectrum-table-border-color, var(--spectrum-alias-border-color-mid));
}

tbody.spectrum-Table-body .spectrum-Table-row:last-child .spectrum-Table-cell {
    border-bottom: 1px solid var(--spectrum-table-border-color, var(--spectrum-alias-border-color-mid));
  }

.spectrum-Table-row {
  border-bottom: 1px solid var(--spectrum-table-border-color, var(--spectrum-alias-border-color-mid));
  background-color: var(--spectrum-table-row-background-color, var(--spectrum-alias-background-color-transparent));
}

.spectrum-Table-row:hover {
    background-color: var(--spectrum-table-row-background-color-hover, var(--spectrum-alias-highlight-hover));
  }

.spectrum-Table-row.focus-ring,
  .spectrum-Table-row.is-focused {
    background-color: var(--spectrum-table-row-background-color-hover, var(--spectrum-alias-highlight-hover));
  }

.spectrum-Table-row:active {
    background-color: var(--spectrum-table-row-background-color-down, var(--spectrum-alias-highlight-active));
  }

.spectrum-Table-row.is-selected {
    background-color: var(--spectrum-table-row-background-color-selected, var(--spectrum-alias-highlight-selected));
  }

.spectrum-Table-row.is-selected:hover {
      background-color: var(--spectrum-table-row-background-color-selected-hover, var(--spectrum-alias-highlight-selected-hover));
    }

.spectrum-Table-row.is-selected.focus-ring,
    .spectrum-Table-row.is-selected.is-focused {
      background-color: var(--spectrum-table-row-background-color-selected-key-focus, var(--spectrum-alias-highlight-selected-hover));
    }

.spectrum-Table-row.is-drop-target::before {
      box-shadow: inset 0 0 0 2px var(--spectrum-alias-border-color-focus, var(--spectrum-global-color-blue-400));
      background-color: var(--spectrum-alias-highlight-selected);
    }

.spectrum-Table-cell {
  color: var(--spectrum-table-cell-text-color, var(--spectrum-alias-text-color));
  background-color: var(--spectrum-table-cell-background-color, var(--spectrum-alias-background-color-transparent));
}

[dir="ltr"] .spectrum-Table-cell--divider {
  border-right-style: solid;
}

[dir="rtl"] .spectrum-Table-cell--divider {
  border-left-style: solid;
}

[dir="ltr"] .spectrum-Table-cell--divider {
  border-right-color: var(--spectrum-table-divider-border-color, var(--spectrum-alias-border-color-mid));
}

[dir="rtl"] .spectrum-Table-cell--divider {
  border-left-color: var(--spectrum-table-divider-border-color, var(--spectrum-alias-border-color-mid));
}

.spectrum-Table--quiet .spectrum-Table-body {
    border-width: 1px 0;
    background-color: var(--spectrum-table-quiet-cell-background-color, var(--spectrum-alias-background-color-transparent));
  }

.spectrum-Table--quiet .spectrum-Table-body.is-drop-target {
      box-shadow: none;
      border-color: transparent;
    }

.spectrum-Table--quiet .spectrum-Table-body.is-drop-target::before {
        box-shadow: inset 0 0 0 2px var(--spectrum-alias-border-color-focus, var(--spectrum-global-color-blue-400));
      }

.spectrum-Table--quiet .spectrum-Table-row {
    background-color: var(--spectrum-table-quiet-row-background-color, var(--spectrum-alias-background-color-transparent));
  }

.spectrum-Table--quiet .spectrum-Table-row:hover {
      background-color: var(--spectrum-table-quiet-row-background-color-hover, var(--spectrum-alias-highlight-hover));
    }

.spectrum-Table--quiet .spectrum-Table-row.focus-ring,
    .spectrum-Table--quiet .spectrum-Table-row.is-focused {
      background-color: var(--spectrum-table-quiet-row-background-color-hover, var(--spectrum-alias-highlight-hover));
    }

.spectrum-Table--quiet .spectrum-Table-row:active {
      background-color: var(--spectrum-table-quiet-row-background-color-down, var(--spectrum-alias-highlight-active));
    }

.spectrum-Table--quiet .spectrum-Table-row.is-selected {
      background-color: var(--spectrum-table-quiet-row-background-color-selected, var(--spectrum-alias-highlight-selected));
    }

.spectrum-Table--quiet .spectrum-Table-row.is-selected:hover {
        background-color: var(--spectrum-table-quiet-row-background-color-selected-hover, var(--spectrum-alias-highlight-selected-hover));
      }

.spectrum-Table--quiet .spectrum-Table-row.is-selected.focus-ring,
      .spectrum-Table--quiet .spectrum-Table-row.is-selected.is-focused {
        background-color: var(--spectrum-table-quiet-row-background-color-selected-key-focus, var(--spectrum-alias-highlight-selected-hover));
      }

[dir="ltr"] .spectrum-Table--quiet tbody.spectrum-Table-body .spectrum-Table-row .spectrum-Table-cell:first-child,[dir="ltr"] 
    .spectrum-Table--quiet tbody.spectrum-Table-body .spectrum-Table-row .spectrum-Table-cell:last-child {
      border-left: none;
}

[dir="rtl"] .spectrum-Table--quiet tbody.spectrum-Table-body .spectrum-Table-row .spectrum-Table-cell:first-child,[dir="rtl"] 
    .spectrum-Table--quiet tbody.spectrum-Table-body .spectrum-Table-row .spectrum-Table-cell:last-child {
      border-right: none;
}

[dir="ltr"] .spectrum-Table--quiet tbody.spectrum-Table-body .spectrum-Table-row .spectrum-Table-cell:first-child,[dir="ltr"] 
    .spectrum-Table--quiet tbody.spectrum-Table-body .spectrum-Table-row .spectrum-Table-cell:last-child {
      border-right: none;
}

[dir="rtl"] .spectrum-Table--quiet tbody.spectrum-Table-body .spectrum-Table-row .spectrum-Table-cell:first-child,[dir="rtl"] 
    .spectrum-Table--quiet tbody.spectrum-Table-body .spectrum-Table-row .spectrum-Table-cell:last-child {
      border-left: none;
}
div.svelte-1acrdjg{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:var(--max-cell-width);width:0;flex:1 1 auto}div.capitalise.svelte-1acrdjg{text-transform:capitalize}.spectrum-Checkbox.svelte-ww1lnr{min-height:0}.spectrum-Checkbox-box.svelte-ww1lnr{margin:0}div.svelte-1abuiv5{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}img.svelte-1abirxi{height:32px;max-width:64px}.center.svelte-1abirxi,.file.svelte-1abirxi{display:flex;flex-direction:row;justify-content:flex-start;align-items:center}.file.svelte-1abirxi{height:32px;padding:0 8px;color:var(--spectrum-global-color-gray-800);border:1px solid var(--spectrum-global-color-gray-300);border-radius:4px;text-transform:uppercase;font-weight:600;font-size:11px}div.svelte-16j2cvj{display:contents}div.svelte-1fa8hd3{display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:var(--spacing-m)}.wrapper.svelte-qx6w80.svelte-qx6w80{position:relative;--table-bg:var(--spectrum-global-color-gray-50);--table-border:1px solid var(--spectrum-alias-border-color-mid);--cell-padding:var(--spectrum-global-dimension-size-250);overflow:auto;display:contents}.wrapper--quiet.svelte-qx6w80.svelte-qx6w80{--table-bg:var(--spectrum-alias-background-color-transparent)}.wrapper--compact.svelte-qx6w80.svelte-qx6w80{--cell-padding:var(--spectrum-global-dimension-size-150)}.loading.svelte-qx6w80.svelte-qx6w80{display:flex;align-items:center;min-height:100px;justify-content:center}.spectrum-Table.svelte-qx6w80.svelte-qx6w80{width:100%;border-radius:0;display:grid;overflow:auto}.spectrum-Table.no-scroll.svelte-qx6w80.svelte-qx6w80{overflow:visible}.spectrum-Table-head.svelte-qx6w80.svelte-qx6w80{display:contents}.spectrum-Table-head.svelte-qx6w80>.svelte-qx6w80:first-child{border-left:1px solid transparent;padding-left:var(--cell-padding)}.spectrum-Table-head.svelte-qx6w80>.spectrum-Table-headCell--edit.svelte-qx6w80:first-child{padding-left:calc(var(--cell-padding) / 1.33);padding-right:calc(var(--cell-padding) / 1.33 + 1px)}.spectrum-Table-head.svelte-qx6w80>.svelte-qx6w80:last-child{border-right:1px solid transparent;padding-right:var(--cell-padding)}.spectrum-Table-headCell.svelte-qx6w80.svelte-qx6w80{height:var(--header-height);position:sticky;top:0;text-overflow:ellipsis;white-space:nowrap;background-color:var(--spectrum-alias-background-color-secondary);z-index:2;border-bottom:var(--table-border);padding:0 calc(var(--cell-padding) / 1.33);display:flex;flex-direction:row;justify-content:flex-start;align-items:center;user-select:none;border-top:var(--table-border)}.spectrum-Table-headCell.svelte-qx6w80.svelte-qx6w80:first-of-type{border-left:var(--table-border)}.spectrum-Table-headCell.svelte-qx6w80.svelte-qx6w80:last-of-type{border-right:var(--table-border)}.noBorderHeader.svelte-qx6w80.svelte-qx6w80{border-top:none !important;border-right:none !important;border-left:none !important}.noBorderCheckbox.svelte-qx6w80.svelte-qx6w80{border-top:none !important;border-right:none !important}.spectrum-Table-headCell--alignCenter.svelte-qx6w80.svelte-qx6w80{justify-content:center}.spectrum-Table-headCell--alignRight.svelte-qx6w80.svelte-qx6w80{justify-content:flex-end}.spectrum-Table-headCell--edit.svelte-qx6w80.svelte-qx6w80{position:sticky;left:0;z-index:3;justify-content:center;padding-left:calc(var(--cell-padding) / 1.33);padding-right:calc(var(--cell-padding) / 1.33)}.spectrum-Table-headCell.svelte-qx6w80 .title.svelte-qx6w80{overflow:visible;text-overflow:ellipsis;display:flex;gap:4px}.spectrum-Table-headCell.svelte-qx6w80 .icon{margin-left:var(
      --spectrum-table-header-sort-icon-gap,
      var(--spectrum-global-dimension-size-125)
    )}.spectrum-Table-row.svelte-qx6w80.svelte-qx6w80{display:contents;cursor:auto}.spectrum-Table-row.clickable.svelte-qx6w80.svelte-qx6w80{cursor:pointer}.spectrum-Table-row.clickable.svelte-qx6w80:hover .spectrum-Table-cell.svelte-qx6w80{background-color:var(--spectrum-global-color-gray-100)}.wrapper--quiet.svelte-qx6w80 .spectrum-Table-row.svelte-qx6w80{border-left:none;border-right:none}.spectrum-Table-row.svelte-qx6w80>.svelte-qx6w80:first-child{border-left:var(--table-border);padding-left:var(--cell-padding)}.spectrum-Table-row.svelte-qx6w80>.spectrum-Table-cell--edit.svelte-qx6w80:first-child{padding-left:calc(var(--cell-padding) / 1.33)}.spectrum-Table-row.svelte-qx6w80>.svelte-qx6w80:last-child{border-right:var(--table-border);padding-right:var(--cell-padding)}.spectrum-Table-cell.svelte-qx6w80.svelte-qx6w80{flex:1 1 auto;padding:0 calc(var(--cell-padding) / 1.33);border-top:none;border-bottom:none;border-radius:0;text-overflow:ellipsis;white-space:nowrap;height:var(--row-height);display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:4px;border-bottom:1px solid var(--spectrum-alias-border-color-mid);background-color:var(--table-bg);z-index:auto;transition:background-color 130ms ease-out}.spectrum-Table-cell--edit.svelte-qx6w80.svelte-qx6w80{position:sticky;left:0;z-index:2;justify-content:center;padding-left:calc(var(--cell-padding) / 1.33);padding-right:calc(var(--cell-padding) / 1.33)}.placeholder.svelte-qx6w80.svelte-qx6w80{display:flex;flex-direction:row;justify-content:center;align-items:center;border:var(--table-border);border-top:none;grid-column:1 / -1;background-color:var(--table-bg);padding:40px}.placeholder--no-fields.svelte-qx6w80.svelte-qx6w80{border-top:var(--table-border)}.placeholder--custom.svelte-qx6w80.svelte-qx6w80{justify-content:flex-start}.wrapper--quiet.svelte-qx6w80 .placeholder.svelte-qx6w80{border-left:none;border-right:none}.placeholder-content.svelte-qx6w80.svelte-qx6w80{display:flex;flex-direction:column;justify-content:center;align-items:center;color:var(
      --spectrum-table-cell-text-color,
      var(--spectrum-alias-text-color)
    )}.placeholder-content.svelte-qx6w80 div.svelte-qx6w80{margin-top:10px;font-size:var(
      --spectrum-table-cell-text-size,
      var(--spectrum-alias-font-size-default)
    );text-align:center}.emphasized.svelte-msdyh4{color:var(--spectrum-global-color-blue-600)}.spectrum-Tabs-item.svelte-msdyh4{color:var(--spectrum-global-color-gray-600)}.spectrum-Tabs-item.is-selected.svelte-msdyh4,.spectrum-Tabs-item.svelte-msdyh4:hover{color:var(--spectrum-global-color-gray-900)}.link.svelte-msdyh4{user-select:none}.spectrum-Tabs--sizeS {
  --spectrum-tabs-quiet-textonly-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-s-quiet-textonly-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-quiet-textonly-divider-background-color: var(--spectrum-tabs-s-quiet-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-quiet));
  --spectrum-tabs-quiet-textonly-tabitem-icon-gap: var(--spectrum-tabs-s-quiet-textonly-tabitem-icon-gap, var(--spectrum-global-dimension-size-85));
  --spectrum-tabs-quiet-textonly-tabitem-focus-ring-padding-x: var(--spectrum-tabs-s-quiet-textonly-tabitem-focus-ring-padding-x, var(--spectrum-global-dimension-size-85));
  --spectrum-tabs-quiet-textonly-tabitem-height: var(--spectrum-tabs-s-quiet-textonly-tabitem-height, var(--spectrum-global-dimension-size-500));
  --spectrum-tabs-quiet-textonly-divider-size: var(--spectrum-tabs-s-quiet-textonly-divider-size, var(--spectrum-alias-border-size-thick));
  --spectrum-tabs-emphasized-texticon-tabitem-icon-color-selected: var(--spectrum-tabs-s-emphasized-texticon-tabitem-icon-color-selected, var(--spectrum-alias-tabitem-text-color-emphasized-selected-default));
  --spectrum-tabs-emphasized-texticon-tabitem-text-color-selected: var(--spectrum-tabs-s-emphasized-texticon-tabitem-text-color-selected, var(--spectrum-alias-tabitem-text-color-emphasized-selected-default));
  --spectrum-tabs-emphasized-texticon-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-s-emphasized-texticon-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-selection-indicator-color-emphasized));
  --spectrum-tabs-emphasized-textonly-divider-background-color: var(--spectrum-tabs-s-emphasized-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-default));
  --spectrum-tabs-texticon-tabitem-text-size: var(--spectrum-tabs-s-texticon-tabitem-text-size, var(--spectrum-global-dimension-font-size-75));
  --spectrum-tabs-texticon-tabitem-selection-indicator-animation-duration: var(--spectrum-tabs-s-texticon-tabitem-selection-indicator-animation-duration, var(--spectrum-global-animation-duration-100));
  --spectrum-tabs-texticon-tabitem-selection-indicator-animation-ease: var(--spectrum-tabs-s-texticon-tabitem-selection-indicator-animation-ease, var(--spectrum-global-animation-ease-in-out));
  --spectrum-tabs-textonly-tabitem-icon-color-selected: var(--spectrum-tabs-s-textonly-tabitem-icon-color-selected, var(--spectrum-alias-tabitem-icon-color-selected));
  --spectrum-tabs-textonly-tabitem-text-color-selected: var(--spectrum-tabs-s-textonly-tabitem-text-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-textonly-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-s-textonly-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-textonly-tabitem-icon-color-selected-key-focus: var(--spectrum-tabs-s-textonly-tabitem-icon-color-selected-key-focus, var(--spectrum-alias-tabitem-icon-color-selected));
  --spectrum-tabs-textonly-tabitem-text-color-selected-key-focus: var(--spectrum-tabs-s-textonly-tabitem-text-color-selected-key-focus, var(--spectrum-alias-tabitem-text-color-selected-key-focus));
  --spectrum-tabs-textonly-tabitem-icon-color-disabled: var(--spectrum-tabs-s-textonly-tabitem-icon-color-disabled, var(--spectrum-alias-tabitem-icon-color-disabled));
  --spectrum-tabs-textonly-tabitem-text-color-disabled: var(--spectrum-tabs-s-textonly-tabitem-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  --spectrum-tabs-textonly-tabitem-icon-color: var(--spectrum-tabs-s-textonly-tabitem-icon-color, var(--spectrum-alias-tabitem-icon-color-default));
  --spectrum-tabs-textonly-tabitem-text-color: var(--spectrum-tabs-s-textonly-tabitem-text-color, var(--spectrum-alias-tabitem-text-color-default));
  --spectrum-tabs-textonly-tabitem-icon-color-hover: var(--spectrum-tabs-s-textonly-tabitem-icon-color-hover, var(--spectrum-alias-tabitem-icon-color-hover));
  --spectrum-tabs-textonly-tabitem-text-color-hover: var(--spectrum-tabs-s-textonly-tabitem-text-color-hover, var(--spectrum-alias-tabitem-text-color-hover));
  --spectrum-tabs-textonly-tabitem-focus-ring-border-color-key-focus: var(--spectrum-tabs-s-textonly-tabitem-focus-ring-border-color-key-focus, var(--spectrum-alias-focus-ring-color));
  --spectrum-tabs-textonly-divider-background-color: var(--spectrum-tabs-s-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-default));
  --spectrum-tabs-textonly-tabitem-text-font-weight: var(--spectrum-tabs-s-textonly-tabitem-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-tabs-textonly-tabitem-focus-ring-size: var(--spectrum-tabs-s-textonly-tabitem-focus-ring-size, var(--spectrum-alias-focus-ring-size));
  --spectrum-tabs-textonly-tabitem-focus-ring-height: var(--spectrum-tabs-s-textonly-tabitem-focus-ring-height, var(--spectrum-global-dimension-size-300));
  --spectrum-tabs-textonly-tabitem-focus-ring-padding-x: var(--spectrum-tabs-s-textonly-tabitem-focus-ring-padding-x, var(--spectrum-global-dimension-size-85));
  --spectrum-tabs-textonly-tabitem-focus-ring-border-radius: var(--spectrum-tabs-s-textonly-tabitem-focus-ring-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-tabs-textonly-tabitem-margin-right: var(--spectrum-tabs-s-textonly-tabitem-margin-right, var(--spectrum-global-dimension-size-300));
  --spectrum-tabs-textonly-divider-border-radius: var(--spectrum-tabs-s-textonly-divider-border-radius, var(--spectrum-global-dimension-static-size-10));
  --spectrum-tabs-vertical-quiet-textonly-divider-background-color: var(--spectrum-tabs-s-vertical-quiet-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-quiet));
  --spectrum-tabs-vertical-textonly-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-s-vertical-textonly-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-vertical-textonly-divider-background-color: var(--spectrum-tabs-s-vertical-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-default));
  --spectrum-tabs-vertical-textonly-tabitem-height: var(--spectrum-tabs-s-vertical-textonly-tabitem-height, var(--spectrum-global-dimension-size-450));
  --spectrum-tabs-vertical-textonly-tabitem-gap: var(--spectrum-tabs-s-vertical-textonly-tabitem-gap, var(--spectrum-global-dimension-size-85));
  --spectrum-tabs-compact-textonly-divider-size: var(--spectrum-tabs-s-compact-textonly-divider-size, var(--spectrum-alias-border-size-thick));
  --spectrum-tabs-compact-textonly-height: var(--spectrum-tabs-s-compact-textonly-height, var(--spectrum-global-dimension-size-300));
  --spectrum-tabs-compact-vertical-textonly-tabitem-height: var(--spectrum-tabs-s-compact-vertical-textonly-tabitem-height, var(--spectrum-global-dimension-size-300));
  --spectrum-tabs-compact-vertical-textonly-tabitem-gap: var(--spectrum-tabs-s-compact-vertical-textonly-tabitem-gap, var(--spectrum-global-dimension-size-85));
}

.spectrum-Tabs--sizeM {
  --spectrum-tabs-quiet-textonly-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-m-quiet-textonly-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-quiet-textonly-divider-background-color: var(--spectrum-tabs-m-quiet-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-quiet));
  --spectrum-tabs-quiet-textonly-tabitem-icon-gap: var(--spectrum-tabs-m-quiet-textonly-tabitem-icon-gap, var(--spectrum-global-dimension-size-100));
  --spectrum-tabs-quiet-textonly-tabitem-focus-ring-padding-x: var(--spectrum-tabs-m-quiet-textonly-tabitem-focus-ring-padding-x, var(--spectrum-global-dimension-size-100));
  --spectrum-tabs-quiet-textonly-tabitem-height: var(--spectrum-tabs-m-quiet-textonly-tabitem-height, var(--spectrum-global-dimension-size-600));
  --spectrum-tabs-quiet-textonly-divider-size: var(--spectrum-tabs-m-quiet-textonly-divider-size, var(--spectrum-alias-border-size-thick));
  --spectrum-tabs-emphasized-texticon-tabitem-icon-color-selected: var(--spectrum-tabs-m-emphasized-texticon-tabitem-icon-color-selected, var(--spectrum-alias-tabitem-text-color-emphasized-selected-default));
  --spectrum-tabs-emphasized-texticon-tabitem-text-color-selected: var(--spectrum-tabs-m-emphasized-texticon-tabitem-text-color-selected, var(--spectrum-alias-tabitem-text-color-emphasized-selected-default));
  --spectrum-tabs-emphasized-texticon-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-m-emphasized-texticon-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-selection-indicator-color-emphasized));
  --spectrum-tabs-emphasized-textonly-divider-background-color: var(--spectrum-tabs-m-emphasized-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-default));
  --spectrum-tabs-texticon-tabitem-text-size: var(--spectrum-tabs-m-texticon-tabitem-text-size, var(--spectrum-global-dimension-font-size-100));
  --spectrum-tabs-texticon-tabitem-selection-indicator-animation-duration: var(--spectrum-tabs-m-texticon-tabitem-selection-indicator-animation-duration, var(--spectrum-global-animation-duration-100));
  --spectrum-tabs-texticon-tabitem-selection-indicator-animation-ease: var(--spectrum-tabs-m-texticon-tabitem-selection-indicator-animation-ease, var(--spectrum-global-animation-ease-in-out));
  --spectrum-tabs-textonly-tabitem-icon-color-selected: var(--spectrum-tabs-m-textonly-tabitem-icon-color-selected, var(--spectrum-alias-tabitem-icon-color-selected));
  --spectrum-tabs-textonly-tabitem-text-color-selected: var(--spectrum-tabs-m-textonly-tabitem-text-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-textonly-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-m-textonly-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-textonly-tabitem-icon-color-selected-key-focus: var(--spectrum-tabs-m-textonly-tabitem-icon-color-selected-key-focus, var(--spectrum-alias-tabitem-icon-color-selected));
  --spectrum-tabs-textonly-tabitem-text-color-selected-key-focus: var(--spectrum-tabs-m-textonly-tabitem-text-color-selected-key-focus, var(--spectrum-alias-tabitem-text-color-selected-key-focus));
  --spectrum-tabs-textonly-tabitem-icon-color-disabled: var(--spectrum-tabs-m-textonly-tabitem-icon-color-disabled, var(--spectrum-alias-tabitem-icon-color-disabled));
  --spectrum-tabs-textonly-tabitem-text-color-disabled: var(--spectrum-tabs-m-textonly-tabitem-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  --spectrum-tabs-textonly-tabitem-icon-color: var(--spectrum-tabs-m-textonly-tabitem-icon-color, var(--spectrum-alias-tabitem-icon-color-default));
  --spectrum-tabs-textonly-tabitem-text-color: var(--spectrum-tabs-m-textonly-tabitem-text-color, var(--spectrum-alias-tabitem-text-color-default));
  --spectrum-tabs-textonly-tabitem-icon-color-hover: var(--spectrum-tabs-m-textonly-tabitem-icon-color-hover, var(--spectrum-alias-tabitem-icon-color-hover));
  --spectrum-tabs-textonly-tabitem-text-color-hover: var(--spectrum-tabs-m-textonly-tabitem-text-color-hover, var(--spectrum-alias-tabitem-text-color-hover));
  --spectrum-tabs-textonly-tabitem-focus-ring-border-color-key-focus: var(--spectrum-tabs-m-textonly-tabitem-focus-ring-border-color-key-focus, var(--spectrum-alias-focus-ring-color));
  --spectrum-tabs-textonly-divider-background-color: var(--spectrum-tabs-m-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-default));
  --spectrum-tabs-textonly-tabitem-text-font-weight: var(--spectrum-tabs-m-textonly-tabitem-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-tabs-textonly-tabitem-focus-ring-size: var(--spectrum-tabs-m-textonly-tabitem-focus-ring-size, var(--spectrum-alias-focus-ring-size));
  --spectrum-tabs-textonly-tabitem-focus-ring-height: var(--spectrum-tabs-m-textonly-tabitem-focus-ring-height, var(--spectrum-global-dimension-size-400));
  --spectrum-tabs-textonly-tabitem-focus-ring-padding-x: var(--spectrum-tabs-m-textonly-tabitem-focus-ring-padding-x, var(--spectrum-global-dimension-size-100));
  --spectrum-tabs-textonly-tabitem-focus-ring-border-radius: var(--spectrum-tabs-m-textonly-tabitem-focus-ring-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-tabs-textonly-tabitem-margin-right: var(--spectrum-tabs-m-textonly-tabitem-margin-right, var(--spectrum-global-dimension-size-300));
  --spectrum-tabs-textonly-divider-border-radius: var(--spectrum-tabs-m-textonly-divider-border-radius, var(--spectrum-global-dimension-static-size-10));
  --spectrum-tabs-vertical-quiet-textonly-divider-background-color: var(--spectrum-tabs-m-vertical-quiet-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-quiet));
  --spectrum-tabs-vertical-textonly-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-m-vertical-textonly-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-vertical-textonly-divider-background-color: var(--spectrum-tabs-m-vertical-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-default));
  --spectrum-tabs-vertical-textonly-tabitem-height: var(--spectrum-tabs-m-vertical-textonly-tabitem-height, var(--spectrum-global-dimension-size-550));
  --spectrum-tabs-vertical-textonly-tabitem-gap: var(--spectrum-tabs-m-vertical-textonly-tabitem-gap, var(--spectrum-global-dimension-size-100));
  --spectrum-tabs-compact-textonly-divider-size: var(--spectrum-tabs-m-compact-textonly-divider-size, var(--spectrum-alias-border-size-thick));
  --spectrum-tabs-compact-textonly-height: var(--spectrum-tabs-m-compact-textonly-height, var(--spectrum-global-dimension-size-400));
  --spectrum-tabs-compact-vertical-textonly-tabitem-height: var(--spectrum-tabs-m-compact-vertical-textonly-tabitem-height, var(--spectrum-global-dimension-size-400));
  --spectrum-tabs-compact-vertical-textonly-tabitem-gap: var(--spectrum-tabs-m-compact-vertical-textonly-tabitem-gap, var(--spectrum-global-dimension-size-100));
}

.spectrum-Tabs--sizeL {
  --spectrum-tabs-quiet-textonly-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-l-quiet-textonly-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-quiet-textonly-divider-background-color: var(--spectrum-tabs-l-quiet-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-quiet));
  --spectrum-tabs-quiet-textonly-tabitem-icon-gap: var(--spectrum-tabs-l-quiet-textonly-tabitem-icon-gap, var(--spectrum-global-dimension-size-115));
  --spectrum-tabs-quiet-textonly-tabitem-focus-ring-padding-x: var(--spectrum-tabs-l-quiet-textonly-tabitem-focus-ring-padding-x, var(--spectrum-global-dimension-size-115));
  --spectrum-tabs-quiet-textonly-tabitem-height: var(--spectrum-tabs-l-quiet-textonly-tabitem-height, var(--spectrum-global-dimension-size-700));
  --spectrum-tabs-quiet-textonly-divider-size: var(--spectrum-tabs-l-quiet-textonly-divider-size, var(--spectrum-alias-border-size-thick));
  --spectrum-tabs-emphasized-texticon-tabitem-icon-color-selected: var(--spectrum-tabs-l-emphasized-texticon-tabitem-icon-color-selected, var(--spectrum-alias-tabitem-text-color-emphasized-selected-default));
  --spectrum-tabs-emphasized-texticon-tabitem-text-color-selected: var(--spectrum-tabs-l-emphasized-texticon-tabitem-text-color-selected, var(--spectrum-alias-tabitem-text-color-emphasized-selected-default));
  --spectrum-tabs-emphasized-texticon-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-l-emphasized-texticon-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-selection-indicator-color-emphasized));
  --spectrum-tabs-emphasized-textonly-divider-background-color: var(--spectrum-tabs-l-emphasized-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-default));
  --spectrum-tabs-texticon-tabitem-text-size: var(--spectrum-tabs-l-texticon-tabitem-text-size, var(--spectrum-global-dimension-font-size-200));
  --spectrum-tabs-texticon-tabitem-selection-indicator-animation-duration: var(--spectrum-tabs-l-texticon-tabitem-selection-indicator-animation-duration, var(--spectrum-global-animation-duration-100));
  --spectrum-tabs-texticon-tabitem-selection-indicator-animation-ease: var(--spectrum-tabs-l-texticon-tabitem-selection-indicator-animation-ease, var(--spectrum-global-animation-ease-in-out));
  --spectrum-tabs-textonly-tabitem-icon-color-selected: var(--spectrum-tabs-l-textonly-tabitem-icon-color-selected, var(--spectrum-alias-tabitem-icon-color-selected));
  --spectrum-tabs-textonly-tabitem-text-color-selected: var(--spectrum-tabs-l-textonly-tabitem-text-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-textonly-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-l-textonly-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-textonly-tabitem-icon-color-selected-key-focus: var(--spectrum-tabs-l-textonly-tabitem-icon-color-selected-key-focus, var(--spectrum-alias-tabitem-icon-color-selected));
  --spectrum-tabs-textonly-tabitem-text-color-selected-key-focus: var(--spectrum-tabs-l-textonly-tabitem-text-color-selected-key-focus, var(--spectrum-alias-tabitem-text-color-selected-key-focus));
  --spectrum-tabs-textonly-tabitem-icon-color-disabled: var(--spectrum-tabs-l-textonly-tabitem-icon-color-disabled, var(--spectrum-alias-tabitem-icon-color-disabled));
  --spectrum-tabs-textonly-tabitem-text-color-disabled: var(--spectrum-tabs-l-textonly-tabitem-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  --spectrum-tabs-textonly-tabitem-icon-color: var(--spectrum-tabs-l-textonly-tabitem-icon-color, var(--spectrum-alias-tabitem-icon-color-default));
  --spectrum-tabs-textonly-tabitem-text-color: var(--spectrum-tabs-l-textonly-tabitem-text-color, var(--spectrum-alias-tabitem-text-color-default));
  --spectrum-tabs-textonly-tabitem-icon-color-hover: var(--spectrum-tabs-l-textonly-tabitem-icon-color-hover, var(--spectrum-alias-tabitem-icon-color-hover));
  --spectrum-tabs-textonly-tabitem-text-color-hover: var(--spectrum-tabs-l-textonly-tabitem-text-color-hover, var(--spectrum-alias-tabitem-text-color-hover));
  --spectrum-tabs-textonly-tabitem-focus-ring-border-color-key-focus: var(--spectrum-tabs-l-textonly-tabitem-focus-ring-border-color-key-focus, var(--spectrum-alias-focus-ring-color));
  --spectrum-tabs-textonly-divider-background-color: var(--spectrum-tabs-l-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-default));
  --spectrum-tabs-textonly-tabitem-text-font-weight: var(--spectrum-tabs-l-textonly-tabitem-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-tabs-textonly-tabitem-focus-ring-size: var(--spectrum-tabs-l-textonly-tabitem-focus-ring-size, var(--spectrum-alias-focus-ring-size));
  --spectrum-tabs-textonly-tabitem-focus-ring-height: var(--spectrum-tabs-l-textonly-tabitem-focus-ring-height, var(--spectrum-global-dimension-size-500));
  --spectrum-tabs-textonly-tabitem-focus-ring-padding-x: var(--spectrum-tabs-l-textonly-tabitem-focus-ring-padding-x, var(--spectrum-global-dimension-size-115));
  --spectrum-tabs-textonly-tabitem-focus-ring-border-radius: var(--spectrum-tabs-l-textonly-tabitem-focus-ring-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-tabs-textonly-tabitem-margin-right: var(--spectrum-tabs-l-textonly-tabitem-margin-right, var(--spectrum-global-dimension-size-300));
  --spectrum-tabs-textonly-divider-border-radius: var(--spectrum-tabs-l-textonly-divider-border-radius, var(--spectrum-global-dimension-static-size-10));
  --spectrum-tabs-vertical-quiet-textonly-divider-background-color: var(--spectrum-tabs-l-vertical-quiet-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-quiet));
  --spectrum-tabs-vertical-textonly-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-l-vertical-textonly-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-vertical-textonly-divider-background-color: var(--spectrum-tabs-l-vertical-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-default));
  --spectrum-tabs-vertical-textonly-tabitem-height: var(--spectrum-tabs-l-vertical-textonly-tabitem-height, var(--spectrum-global-dimension-size-650));
  --spectrum-tabs-vertical-textonly-tabitem-gap: var(--spectrum-tabs-l-vertical-textonly-tabitem-gap, var(--spectrum-global-dimension-size-115));
  --spectrum-tabs-compact-textonly-divider-size: var(--spectrum-tabs-l-compact-textonly-divider-size, var(--spectrum-alias-border-size-thick));
  --spectrum-tabs-compact-textonly-height: var(--spectrum-tabs-l-compact-textonly-height, var(--spectrum-global-dimension-size-500));
  --spectrum-tabs-compact-vertical-textonly-tabitem-height: var(--spectrum-tabs-l-compact-vertical-textonly-tabitem-height, var(--spectrum-global-dimension-size-500));
  --spectrum-tabs-compact-vertical-textonly-tabitem-gap: var(--spectrum-tabs-l-compact-vertical-textonly-tabitem-gap, var(--spectrum-global-dimension-size-115));
}

.spectrum-Tabs--sizeXL {
  --spectrum-tabs-quiet-textonly-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-xl-quiet-textonly-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-quiet-textonly-divider-background-color: var(--spectrum-tabs-xl-quiet-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-quiet));
  --spectrum-tabs-quiet-textonly-tabitem-icon-gap: var(--spectrum-tabs-xl-quiet-textonly-tabitem-icon-gap, var(--spectrum-global-dimension-size-125));
  --spectrum-tabs-quiet-textonly-tabitem-focus-ring-padding-x: var(--spectrum-tabs-xl-quiet-textonly-tabitem-focus-ring-padding-x, var(--spectrum-global-dimension-size-125));
  --spectrum-tabs-quiet-textonly-tabitem-height: var(--spectrum-tabs-xl-quiet-textonly-tabitem-height, var(--spectrum-global-dimension-size-800));
  --spectrum-tabs-quiet-textonly-divider-size: var(--spectrum-tabs-xl-quiet-textonly-divider-size, var(--spectrum-alias-border-size-thick));
  --spectrum-tabs-emphasized-texticon-tabitem-icon-color-selected: var(--spectrum-tabs-xl-emphasized-texticon-tabitem-icon-color-selected, var(--spectrum-alias-tabitem-text-color-emphasized-selected-default));
  --spectrum-tabs-emphasized-texticon-tabitem-text-color-selected: var(--spectrum-tabs-xl-emphasized-texticon-tabitem-text-color-selected, var(--spectrum-alias-tabitem-text-color-emphasized-selected-default));
  --spectrum-tabs-emphasized-texticon-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-xl-emphasized-texticon-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-selection-indicator-color-emphasized));
  --spectrum-tabs-emphasized-textonly-divider-background-color: var(--spectrum-tabs-xl-emphasized-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-default));
  --spectrum-tabs-texticon-tabitem-text-size: var(--spectrum-tabs-xl-texticon-tabitem-text-size, var(--spectrum-global-dimension-font-size-300));
  --spectrum-tabs-texticon-tabitem-selection-indicator-animation-duration: var(--spectrum-tabs-xl-texticon-tabitem-selection-indicator-animation-duration, var(--spectrum-global-animation-duration-100));
  --spectrum-tabs-texticon-tabitem-selection-indicator-animation-ease: var(--spectrum-tabs-xl-texticon-tabitem-selection-indicator-animation-ease, var(--spectrum-global-animation-ease-in-out));
  --spectrum-tabs-textonly-tabitem-icon-color-selected: var(--spectrum-tabs-xl-textonly-tabitem-icon-color-selected, var(--spectrum-alias-tabitem-icon-color-selected));
  --spectrum-tabs-textonly-tabitem-text-color-selected: var(--spectrum-tabs-xl-textonly-tabitem-text-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-textonly-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-xl-textonly-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-textonly-tabitem-icon-color-selected-key-focus: var(--spectrum-tabs-xl-textonly-tabitem-icon-color-selected-key-focus, var(--spectrum-alias-tabitem-icon-color-selected));
  --spectrum-tabs-textonly-tabitem-text-color-selected-key-focus: var(--spectrum-tabs-xl-textonly-tabitem-text-color-selected-key-focus, var(--spectrum-alias-tabitem-text-color-selected-key-focus));
  --spectrum-tabs-textonly-tabitem-icon-color-disabled: var(--spectrum-tabs-xl-textonly-tabitem-icon-color-disabled, var(--spectrum-alias-tabitem-icon-color-disabled));
  --spectrum-tabs-textonly-tabitem-text-color-disabled: var(--spectrum-tabs-xl-textonly-tabitem-text-color-disabled, var(--spectrum-alias-text-color-disabled));
  --spectrum-tabs-textonly-tabitem-icon-color: var(--spectrum-tabs-xl-textonly-tabitem-icon-color, var(--spectrum-alias-tabitem-icon-color-default));
  --spectrum-tabs-textonly-tabitem-text-color: var(--spectrum-tabs-xl-textonly-tabitem-text-color, var(--spectrum-alias-tabitem-text-color-default));
  --spectrum-tabs-textonly-tabitem-icon-color-hover: var(--spectrum-tabs-xl-textonly-tabitem-icon-color-hover, var(--spectrum-alias-tabitem-icon-color-hover));
  --spectrum-tabs-textonly-tabitem-text-color-hover: var(--spectrum-tabs-xl-textonly-tabitem-text-color-hover, var(--spectrum-alias-tabitem-text-color-hover));
  --spectrum-tabs-textonly-tabitem-focus-ring-border-color-key-focus: var(--spectrum-tabs-xl-textonly-tabitem-focus-ring-border-color-key-focus, var(--spectrum-alias-focus-ring-color));
  --spectrum-tabs-textonly-divider-background-color: var(--spectrum-tabs-xl-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-default));
  --spectrum-tabs-textonly-tabitem-text-font-weight: var(--spectrum-tabs-xl-textonly-tabitem-text-font-weight, var(--spectrum-alias-body-text-font-weight));
  --spectrum-tabs-textonly-tabitem-focus-ring-size: var(--spectrum-tabs-xl-textonly-tabitem-focus-ring-size, var(--spectrum-alias-focus-ring-size));
  --spectrum-tabs-textonly-tabitem-focus-ring-height: var(--spectrum-tabs-xl-textonly-tabitem-focus-ring-height, var(--spectrum-global-dimension-size-600));
  --spectrum-tabs-textonly-tabitem-focus-ring-padding-x: var(--spectrum-tabs-xl-textonly-tabitem-focus-ring-padding-x, var(--spectrum-global-dimension-size-125));
  --spectrum-tabs-textonly-tabitem-focus-ring-border-radius: var(--spectrum-tabs-xl-textonly-tabitem-focus-ring-border-radius, var(--spectrum-alias-border-radius-regular));
  --spectrum-tabs-textonly-tabitem-margin-right: var(--spectrum-tabs-xl-textonly-tabitem-margin-right, var(--spectrum-global-dimension-size-300));
  --spectrum-tabs-textonly-divider-border-radius: var(--spectrum-tabs-xl-textonly-divider-border-radius, var(--spectrum-global-dimension-static-size-10));
  --spectrum-tabs-vertical-quiet-textonly-divider-background-color: var(--spectrum-tabs-xl-vertical-quiet-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-quiet));
  --spectrum-tabs-vertical-textonly-tabitem-selection-indicator-background-color-selected: var(--spectrum-tabs-xl-vertical-textonly-tabitem-selection-indicator-background-color-selected, var(--spectrum-alias-tabitem-text-color-selected-default));
  --spectrum-tabs-vertical-textonly-divider-background-color: var(--spectrum-tabs-xl-vertical-textonly-divider-background-color, var(--spectrum-alias-tabs-divider-background-color-default));
  --spectrum-tabs-vertical-textonly-tabitem-height: var(--spectrum-tabs-xl-vertical-textonly-tabitem-height, var(--spectrum-global-dimension-size-750));
  --spectrum-tabs-vertical-textonly-tabitem-gap: var(--spectrum-tabs-xl-vertical-textonly-tabitem-gap, var(--spectrum-global-dimension-size-125));
  --spectrum-tabs-compact-textonly-divider-size: var(--spectrum-tabs-xl-compact-textonly-divider-size, var(--spectrum-alias-border-size-thick));
  --spectrum-tabs-compact-textonly-height: var(--spectrum-tabs-xl-compact-textonly-height, var(--spectrum-global-dimension-size-600));
  --spectrum-tabs-compact-vertical-textonly-tabitem-height: var(--spectrum-tabs-xl-compact-vertical-textonly-tabitem-height, var(--spectrum-global-dimension-size-600));
  --spectrum-tabs-compact-vertical-textonly-tabitem-gap: var(--spectrum-tabs-xl-compact-vertical-textonly-tabitem-gap, var(--spectrum-global-dimension-size-125));
}

.spectrum-Tabs {
  --spectrum-tabs-compact-item-height: calc(var(--spectrum-tabs-compact-textonly-height) - var(--spectrum-tabs-compact-textonly-divider-size));
}

.spectrum-Tabs {
  display: -ms-flexbox;
  display: flex;
  position: relative;
  z-index: 0;

  margin: 0;
  padding-top: 0;
  padding-bottom: 0;
  vertical-align: top;
}

.spectrum-Tabs-item {
  position: relative;

  box-sizing: border-box;

  height: var(--spectrum-tabs-quiet-textonly-tabitem-height);
  line-height: var(--spectrum-tabs-quiet-textonly-tabitem-height);
  z-index: 1;

  text-decoration: none;
  white-space: nowrap;

  transition: color var(--spectrum-tabs-texticon-tabitem-selection-indicator-animation-duration) ease-out;
  cursor: pointer;
  outline: none;
}

.spectrum-Tabs-item.is-disabled {
    cursor: default;
  }

.spectrum-Tabs-item.is-disabled .spectrum-Tabs-itemLabel {
      cursor: default;
    }

.spectrum-Tabs-item .spectrum-Icon {
    height: var(--spectrum-tabs-quiet-textonly-tabitem-height);
  }

[dir="ltr"] .spectrum-Tabs-item .spectrum-Icon + .spectrum-Tabs-itemLabel {
      margin-left: calc(var(--spectrum-tabs-quiet-textonly-tabitem-icon-gap) - var(--spectrum-global-dimension-size-40));
}

[dir="rtl"] .spectrum-Tabs-item .spectrum-Icon + .spectrum-Tabs-itemLabel {
      margin-right: calc(var(--spectrum-tabs-quiet-textonly-tabitem-icon-gap) - var(--spectrum-global-dimension-size-40));
}

[dir="ltr"] .spectrum-Tabs-item::before {

    left: calc(-1 * var(--spectrum-tabs-textonly-tabitem-focus-ring-padding-x));
}

[dir="rtl"] .spectrum-Tabs-item::before {

    right: calc(-1 * var(--spectrum-tabs-textonly-tabitem-focus-ring-padding-x));
}

[dir="ltr"] .spectrum-Tabs-item::before {
    right: calc(-1 * var(--spectrum-tabs-textonly-tabitem-focus-ring-padding-x));
}

[dir="rtl"] .spectrum-Tabs-item::before {
    left: calc(-1 * var(--spectrum-tabs-textonly-tabitem-focus-ring-padding-x));
}

.spectrum-Tabs-item::before {
    content: '';
    position: absolute;
    top: 50%;

    box-sizing: border-box;

    height: var(--spectrum-tabs-textonly-tabitem-focus-ring-height);
    margin-top: calc(var(--spectrum-tabs-textonly-tabitem-focus-ring-height) / -2);
    
    border: var(--spectrum-tabs-textonly-tabitem-focus-ring-size) solid transparent;
    border-radius: var(--spectrum-tabs-textonly-tabitem-focus-ring-border-radius);

    pointer-events: none;
  }

.spectrum-Tabs-itemLabel {
  cursor: pointer;
  vertical-align: top;
  display: inline-block;

  font-size: var(--spectrum-tabs-texticon-tabitem-text-size);
  font-weight: var(--spectrum-tabs-textonly-tabitem-text-font-weight);
  text-decoration: none;
}

.spectrum-Tabs-itemLabel:empty {
    display: none;
  }

[dir="ltr"] .spectrum-Tabs-selectionIndicator {
  left: 0;
}

[dir="rtl"] .spectrum-Tabs-selectionIndicator {
  right: 0;
}

.spectrum-Tabs-selectionIndicator {
  position: absolute;
  z-index: 0;
  
  transition: transform var(--spectrum-tabs-texticon-tabitem-selection-indicator-animation-duration) var(--spectrum-tabs-texticon-tabitem-selection-indicator-animation-ease);
  transform-origin: top left;

  border-radius: var(--spectrum-tabs-textonly-divider-border-radius);
}

.spectrum-Tabs--compact .spectrum-Tabs-item {
    height: var(--spectrum-tabs-compact-item-height);
    line-height: var(--spectrum-tabs-compact-item-height);
  }

.spectrum-Tabs--compact .spectrum-Tabs-item .spectrum-Icon {
      height: var(--spectrum-tabs-compact-item-height);
    }

.spectrum-Tabs--horizontal {
  -ms-flex-align: center;
      align-items: center;

  border-bottom: var(--spectrum-tabs-quiet-textonly-divider-size) solid;
}

.spectrum-Tabs--horizontal .spectrum-Tabs-item {
    vertical-align: top;
  }

[dir="ltr"] .spectrum-Tabs--horizontal .spectrum-Tabs-item + *:not(.spectrum-Tabs-selectionIndicator) {
      margin-left: var(--spectrum-tabs-textonly-tabitem-margin-right);
}

[dir="rtl"] .spectrum-Tabs--horizontal .spectrum-Tabs-item + *:not(.spectrum-Tabs-selectionIndicator) {
      margin-right: var(--spectrum-tabs-textonly-tabitem-margin-right);
}

.spectrum-Tabs--horizontal .spectrum-Tabs-selectionIndicator {
    position: absolute;
    bottom: 0;
    height: var(--spectrum-tabs-quiet-textonly-divider-size);

    bottom: calc(-1 * var(--spectrum-tabs-quiet-textonly-divider-size));
  }

.spectrum-Tabs--horizontal.spectrum-Tabs--compact {
    box-sizing: content-box;
    height: var(--spectrum-tabs-compact-item-height);
    -ms-flex-align: end;
        align-items: end;
  }

.spectrum-Tabs--quiet {
  display: -ms-inline-flexbox;
  display: inline-flex;
}

[dir="ltr"] .spectrum-Tabs--vertical {
  border-left: var(--spectrum-tabs-quiet-textonly-divider-size) solid;
}

[dir="rtl"] .spectrum-Tabs--vertical {
  border-right: var(--spectrum-tabs-quiet-textonly-divider-size) solid;
}

.spectrum-Tabs--vertical {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-direction: column;
      flex-direction: column;
  padding: 0;
}

[dir="ltr"] .spectrum-Tabs--vertical .spectrum-Tabs-item {
    margin-left: calc(var(--spectrum-tabs-vertical-textonly-tabitem-gap) / 2);
}

[dir="rtl"] .spectrum-Tabs--vertical .spectrum-Tabs-item {
    margin-right: calc(var(--spectrum-tabs-vertical-textonly-tabitem-gap) / 2);
}

.spectrum-Tabs--vertical .spectrum-Tabs-item {
    height: var(--spectrum-tabs-vertical-textonly-tabitem-height);
    line-height: var(--spectrum-tabs-vertical-textonly-tabitem-height);
    padding-top: 0;
    padding-bottom: 0;
    padding-left: var(--spectrum-tabs-quiet-textonly-tabitem-focus-ring-padding-x);
    padding-right: var(--spectrum-tabs-quiet-textonly-tabitem-focus-ring-padding-x);
    
    margin-bottom: var(--spectrum-tabs-vertical-textonly-tabitem-gap);
  }

[dir="ltr"] .spectrum-Tabs--vertical .spectrum-Tabs-item::before {
      left: calc(-1 * var(--spectrum-tabs-textonly-tabitem-focus-ring-size));
}

[dir="rtl"] .spectrum-Tabs--vertical .spectrum-Tabs-item::before {
      right: calc(-1 * var(--spectrum-tabs-textonly-tabitem-focus-ring-size));
}

[dir="ltr"] .spectrum-Tabs--vertical .spectrum-Tabs-item::before {
      right: calc(-1 * var(--spectrum-tabs-textonly-tabitem-focus-ring-size));
}

[dir="rtl"] .spectrum-Tabs--vertical .spectrum-Tabs-item::before {
      left: calc(-1 * var(--spectrum-tabs-textonly-tabitem-focus-ring-size));
}

.spectrum-Tabs--vertical .spectrum-Icon {
    height: var(--spectrum-tabs-vertical-textonly-tabitem-height);
    line-height: var(--spectrum-tabs-vertical-textonly-tabitem-height);
  }

.spectrum-Tabs--vertical.spectrum-Tabs--compact .spectrum-Tabs-item {
      height: var(--spectrum-tabs-compact-vertical-textonly-tabitem-height);
      line-height: var(--spectrum-tabs-compact-vertical-textonly-tabitem-height);
      margin-bottom: var(--spectrum-tabs-compact-vertical-textonly-tabitem-gap);
    }

.spectrum-Tabs--vertical.spectrum-Tabs--compact .spectrum-Tabs-item .spectrum-Icon {
        height: var(--spectrum-tabs-compact-vertical-textonly-tabitem-height);
      }

[dir="ltr"] .spectrum-Tabs--vertical .spectrum-Tabs-selectionIndicator {
    left: 0px;
}

[dir="rtl"] .spectrum-Tabs--vertical .spectrum-Tabs-selectionIndicator {
    right: 0px;
}

[dir="ltr"] .spectrum-Tabs--vertical .spectrum-Tabs-selectionIndicator {

    left: calc(-1 * var(--spectrum-tabs-quiet-textonly-divider-size));
}

[dir="rtl"] .spectrum-Tabs--vertical .spectrum-Tabs-selectionIndicator {

    right: calc(-1 * var(--spectrum-tabs-quiet-textonly-divider-size));
}

.spectrum-Tabs--vertical .spectrum-Tabs-selectionIndicator {
    position: absolute;
    width: var(--spectrum-tabs-quiet-textonly-divider-size);
  }

.spectrum-Tabs {
  border-bottom-color: var(--spectrum-tabs-textonly-divider-background-color);
}

[dir="ltr"] .spectrum-Tabs--vertical {
  border-left-color: var(--spectrum-tabs-vertical-textonly-divider-background-color);
}

[dir="rtl"] .spectrum-Tabs--vertical {
  border-right-color: var(--spectrum-tabs-vertical-textonly-divider-background-color);
}

.spectrum-Tabs-selectionIndicator {
  background-color: var(--spectrum-tabs-textonly-tabitem-selection-indicator-background-color-selected);
}

.spectrum-Tabs--emphasized .spectrum-Tabs-selectionIndicator {
    background-color: var(--spectrum-tabs-emphasized-texticon-tabitem-selection-indicator-background-color-selected);
  }

.spectrum-Tabs-item {
  color: var(--spectrum-tabs-textonly-tabitem-text-color);
}

.spectrum-Tabs-item .spectrum-Icon {
    color: var(--spectrum-tabs-textonly-tabitem-icon-color)
  }

.spectrum-Tabs-item:hover {
    color: var(--spectrum-tabs-textonly-tabitem-text-color-hover);
  }

.spectrum-Tabs-item:hover .spectrum-Icon {
      color: var(--spectrum-tabs-textonly-tabitem-icon-color-hover)
    }

.spectrum-Tabs-item.is-selected {
    color: var(--spectrum-tabs-textonly-tabitem-text-color-selected);
  }

.spectrum-Tabs-item.is-selected .spectrum-Icon {
      color: var(--spectrum-tabs-textonly-tabitem-icon-color-selected);
    }

.spectrum-Tabs-item.focus-ring {
    color: var(--spectrum-tabs-textonly-tabitem-text-color-selected-key-focus);
  }

.spectrum-Tabs-item.focus-ring::before {
      border-color: var(--spectrum-tabs-textonly-tabitem-focus-ring-border-color-key-focus);
    }

.spectrum-Tabs-item.focus-ring .spectrum-Icon {
      color: var(--spectrum-tabs-textonly-tabitem-icon-color-selected-key-focus)
    }

.spectrum-Tabs-item.is-disabled {
    color: var(--spectrum-tabs-textonly-tabitem-text-color-disabled);
  }

.spectrum-Tabs-item.is-disabled .spectrum-Icon {
      color: var(--spectrum-tabs-textonly-tabitem-icon-color-disabled)
    }

.spectrum-Tabs--emphasized .spectrum-Tabs-item.is-selected {
      color: var(--spectrum-tabs-emphasized-texticon-tabitem-text-color-selected);
    }

.spectrum-Tabs--emphasized .spectrum-Tabs-item.is-selected .spectrum-Icon {
        color: var(--spectrum-tabs-emphasized-texticon-tabitem-icon-color-selected);
      }

.spectrum-Tabs--quiet {
  border-bottom-color: var(--spectrum-tabs-quiet-textonly-divider-background-color);
}

.spectrum-Tabs--quiet .spectrum-Tabs-selectionIndicator {
    background-color: var(--spectrum-tabs-quiet-textonly-tabitem-selection-indicator-background-color-selected);
  }

.spectrum-Tabs--quiet.spectrum-Tabs--emphasized .spectrum-Tabs-selectionIndicator {
      background-color: var(--spectrum-tabs-emphasized-texticon-tabitem-selection-indicator-background-color-selected);
    }

[dir="ltr"] .spectrum-Tabs--vertical.spectrum-Tabs--quiet,[dir="ltr"] 
  .spectrum-Tabs--vertical.spectrum-Tabs--compact {
    border-left-color: var(--spectrum-tabs-vertical-quiet-textonly-divider-background-color);
}

[dir="rtl"] .spectrum-Tabs--vertical.spectrum-Tabs--quiet,[dir="rtl"] 
  .spectrum-Tabs--vertical.spectrum-Tabs--compact {
    border-right-color: var(--spectrum-tabs-vertical-quiet-textonly-divider-background-color);
}

.spectrum-Tabs--vertical.spectrum-Tabs--quiet .spectrum-Tabs-selectionIndicator, .spectrum-Tabs--vertical.spectrum-Tabs--compact .spectrum-Tabs-selectionIndicator {
      background-color: var(--spectrum-tabs-vertical-textonly-tabitem-selection-indicator-background-color-selected);
    }

[dir="ltr"] .spectrum-Tabs--vertical.spectrum-Tabs--emphasized {
    border-left-color: var(--spectrum-tabs-emphasized-textonly-divider-background-color);
}

[dir="rtl"] .spectrum-Tabs--vertical.spectrum-Tabs--emphasized {
    border-right-color: var(--spectrum-tabs-emphasized-textonly-divider-background-color);
}

.spectrum-Tabs--vertical.spectrum-Tabs--emphasized .spectrum-Tabs-selectionIndicator {
      background-color: var(--spectrum-tabs-emphasized-texticon-tabitem-selection-indicator-background-color-selected);
    }

@media (forced-colors: active) {
  .spectrum-Tabs {
    --spectrum-tabs-emphasized-texticon-tabitem-icon-color-selected: HighlightText;
    --spectrum-tabs-emphasized-texticon-tabitem-selection-indicator-background-color-selected: Highlight;
    --spectrum-tabs-emphasized-texticon-tabitem-text-color-selected: HighlightText;
    --spectrum-tabs-emphasized-textonly-divider-background-color: transparent;
    --spectrum-tabs-quiet-textonly-divider-background-color: transparent;
    --spectrum-tabs-quiet-textonly-tabitem-selection-indicator-background-color-selected: Highlight;
    --spectrum-tabs-textonly-divider-background-color: transparent;
    --spectrum-tabs-textonly-tabitem-focus-ring-border-color-key-focus: ButtonText;
    --spectrum-tabs-textonly-tabitem-icon-color-disabled: GrayText;
    --spectrum-tabs-textonly-tabitem-icon-color-hover: ButtonText;
    --spectrum-tabs-textonly-tabitem-icon-color-selected-key-focus: ButtonText;
    --spectrum-tabs-textonly-tabitem-icon-color-selected: HighlightText;
    --spectrum-tabs-textonly-tabitem-selection-indicator-background-color-selected: Highlight;
    --spectrum-tabs-textonly-tabitem-text-color-disabled: GrayText;
    --spectrum-tabs-textonly-tabitem-text-color-hover: ButtonText;
    --spectrum-tabs-textonly-tabitem-text-color-selected-key-focus: ButtonText;
    --spectrum-tabs-textonly-tabitem-text-color-selected: HighlightText;
    --spectrum-tabs-textonly-tabitem-text-color: ButtonText;
    --spectrum-tabs-vertical-quiet-textonly-divider-background-color: transparent;
    --spectrum-tabs-vertical-textonly-divider-background-color: transparent;
    --spectrum-tabs-vertical-textonly-tabitem-selection-indicator-background-color-selected: Highlight;
    forced-color-adjust: none;
  }
      .spectrum-Tabs .spectrum-Tabs-item:before {
        background-color: ButtonFace;
      }

      .spectrum-Tabs .spectrum-Tabs-item .spectrum-Icon {
        z-index: 1;
        position: relative;
      }

      .spectrum-Tabs .spectrum-Tabs-item .spectrum-Tabs-itemLabel {
        position: relative;
        z-index: 1;
      }

    .spectrum-Tabs .is-selected {
      color: HighlightText;
    }

      .spectrum-Tabs .is-selected .spectrum-Icon {
        color: HighlightText;
      }

      .spectrum-Tabs .is-selected:before {
        background-color: Highlight;
        color: HighlightText;
      }

      .spectrum-Tabs .is-selected .spectrum-Tabs-itemLabel {
        color: HighlightText;
      }
        .spectrum-Tabs.spectrum-Tabs--emphasized .spectrum-Tabs-item:before {
          background-color: ButtonFace;
        }

        .spectrum-Tabs.spectrum-Tabs--emphasized .spectrum-Tabs-item .spectrum-Icon {
          z-index: 1;
          position: relative;
        }

        .spectrum-Tabs.spectrum-Tabs--emphasized .spectrum-Tabs-item .spectrum-Tabs-itemLabel {
          position: relative;
          z-index: 1;
        }

      .spectrum-Tabs.spectrum-Tabs--emphasized .is-selected {
        color: HighlightText;
      }

        .spectrum-Tabs.spectrum-Tabs--emphasized .is-selected .spectrum-Icon {
          color: HighlightText;
        }

        .spectrum-Tabs.spectrum-Tabs--emphasized .is-selected:before {
          background-color: Highlight;
          color: HighlightText;
        }

        .spectrum-Tabs.spectrum-Tabs--emphasized .is-selected .spectrum-Tabs-itemLabel {
          color: HighlightText;
        }
}
.spectrum-Tabs--quiet.svelte-1chmmw5{border-bottom:none !important}.spectrum-Tabs.svelte-1chmmw5{padding-left:var(--spacing-xl);padding-right:var(--spacing-xl);position:relative;border-bottom-color:var(--spectrum-global-color-gray-200)}.spectrum-Tabs-content.svelte-1chmmw5{margin-top:var(--spectrum-global-dimension-static-size-150)}.spectrum-Tabs-selectionIndicator.svelte-1chmmw5{transition:all 200ms;background-color:var(--spectrum-global-color-gray-900)}.spectrum-Tabs-selectionIndicator.emphasized.svelte-1chmmw5{background-color:var(--spectrum-global-color-blue-400)}.noHorizPadding.svelte-1chmmw5{padding:0}.noPadding.svelte-1chmmw5{margin:0}.onTop.svelte-1chmmw5{z-index:100}.wrapper.svelte-pfvtvx{background-color:var(--spectrum-global-color-gray-100);box-shadow:2px 2px 5px 0px rgba(0, 0, 0, 0.42);opacity:0;overflow:hidden;border-radius:5px;box-sizing:border-box;border:1px solid var(--grey-4);position:absolute;pointer-events:none;z-index:1000}.visible.svelte-pfvtvx{opacity:1;pointer-events:auto}.spectrum-TreeView {
  --spectrum-treeview-item-min-height: var(--spectrum-global-dimension-size-400);
  --spectrum-treeview-item-padding-y: var(--spectrum-global-dimension-size-75);
  --spectrum-treeview-item-icon-margin-right: var(--spectrum-global-dimension-size-125);
  --spectrum-treeview-item-affordance-width: var(--spectrum-global-dimension-size-400);
  --spectrum-treeview-item-indentation: var(--spectrum-global-dimension-size-200);
  --spectrum-treeview-heading-font-weight: var(--spectrum-global-font-weight-bold, 700);
  --spectrum-treeview-item-hover-offset: var(--spectrum-global-dimension-size-25);
  --spectrum-treeview-item-border-size-selected: var(--spectrum-alias-border-size-thin, var(--spectrum-global-dimension-static-size-10));

  --spectrum-treeview-item-height-layers: var(--spectrum-global-dimension-size-550);
}

.spectrum-TreeView {
  display: block;
  position: relative;

  padding: 0;

  list-style: none;
  outline: none;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
}

.spectrum-TreeView-item {
  overflow: hidden;
}

[dir="ltr"] .spectrum-TreeView-item.is-open > .spectrum-TreeView-itemLink > .spectrum-TreeView-itemIndicator { transform: rotate(90deg); }

[dir="rtl"] .spectrum-TreeView-item.is-open > .spectrum-TreeView-itemLink > .spectrum-TreeView-itemIndicator { transform: matrix(-1, 0, 0, 1, 0, 0) rotate(90deg); }

.spectrum-TreeView-item.is-open > .spectrum-TreeView {
      height: auto;
      visibility: visible;
    }

.spectrum-TreeView-item.is-drop-target .spectrum-TreeView-itemLink:before {
        border-width: var(--spectrum-treeview-item-border-size, var(--spectrum-global-dimension-static-size-25));
      }

.spectrum-TreeView-item.is-selected .spectrum-TreeView-itemLink:not(.focus-ring):before {
        border-width: var(--spectrum-treeview-item-border-size-selected);
      }

.spectrum-TreeView-itemLabel {
  overflow: hidden;
  text-overflow: ellipsis;
}

.spectrum-TreeView-itemLink {
  display: -ms-flexbox;
  display: flex;
  -ms-flex-direction: row;
      flex-direction: row;
  -ms-flex-align: center;
      align-items: center;

  box-sizing: border-box;
  cursor: pointer;

  padding-top: var(--spectrum-treeview-item-padding-y, var(--spectrum-global-dimension-static-size-100));

  padding-bottom: var(--spectrum-treeview-item-padding-y, var(--spectrum-global-dimension-static-size-100));
  padding-left: var(--spectrum-treeview-item-affordance-width);
  padding-right: var(--spectrum-treeview-item-affordance-width);

  text-decoration: none;

  height: var(--spectrum-treeview-item-min-height);
  white-space: nowrap;
  overflow: hidden;

  outline: none;
}

[dir="ltr"] .spectrum-TreeView-itemLink .spectrum-TreeView-itemIcon {
    margin-right: var(--spectrum-treeview-item-icon-margin-right);
}

[dir="rtl"] .spectrum-TreeView-itemLink .spectrum-TreeView-itemIcon {
    margin-left: var(--spectrum-treeview-item-icon-margin-right);
}

.spectrum-TreeView-itemLink .spectrum-TreeView-itemIcon {
    vertical-align: top;
  }

[dir="ltr"] .spectrum-TreeView-itemLink:before {
    left: var(--spectrum-treeview-item-border-size, var(--spectrum-global-dimension-static-size-25));
}

[dir="rtl"] .spectrum-TreeView-itemLink:before {
    right: var(--spectrum-treeview-item-border-size, var(--spectrum-global-dimension-static-size-25));
}

[dir="ltr"] .spectrum-TreeView-itemLink:before {
    right: 0;
}

[dir="rtl"] .spectrum-TreeView-itemLink:before {
    left: 0;
}

.spectrum-TreeView-itemLink:before {
    content: '';

    box-sizing: border-box;

    position: absolute;

    height: calc(var(--spectrum-treeview-item-height, var(--spectrum-global-dimension-size-450)) - var(--spectrum-treeview-item-hover-offset) * 2);

    border-style: solid;
    border-color: transparent;
    border-width: var(--spectrum-treeview-item-border-size, var(--spectrum-global-dimension-static-size-25)) 0 var(--spectrum-treeview-item-border-size, var(--spectrum-global-dimension-static-size-25)) 0;
    background-color: transparent;
  }

.spectrum-TreeView-itemLink.focus-ring:before {
      border-width: var(--spectrum-treeview-item-border-size, var(--spectrum-global-dimension-static-size-25));
    }

.spectrum-TreeView--standalone .spectrum-TreeView-itemLink:before {
      border-radius: var(--spectrum-treeview-item-border-radius, var(--spectrum-alias-border-radius-regular));
      border-width: var(--spectrum-treeview-item-border-size, var(--spectrum-global-dimension-static-size-25));
    }

[dir="ltr"] .spectrum-TreeView--thumbnail .spectrum-TreeView-itemThumbnail {
    margin-right: var(--spectrum-treeview-item-icon-margin-right);
}

[dir="rtl"] .spectrum-TreeView--thumbnail .spectrum-TreeView-itemThumbnail {
    margin-left: var(--spectrum-treeview-item-icon-margin-right);
}

.spectrum-TreeView--thumbnail .spectrum-TreeView-itemLink {
    height: var(--spectrum-treeview-item-height-layers);
  }

.spectrum-TreeView--thumbnail .spectrum-TreeView-itemLink:before {
      height: var(--spectrum-treeview-item-height-layers);
    }

[dir="ltr"] .spectrum-TreeView-itemIndicator {

  float: left;
}

[dir="rtl"] .spectrum-TreeView-itemIndicator {

  float: right;
}

[dir="ltr"] .spectrum-TreeView-itemIndicator {

  left: var(--spectrum-global-dimension-size-125);
}

[dir="rtl"] .spectrum-TreeView-itemIndicator {

  right: var(--spectrum-global-dimension-size-125);
}

[dir="ltr"] .spectrum-TreeView-itemIndicator {
  margin-left: calc(-1 * var(--spectrum-global-dimension-size-500));
}

[dir="rtl"] .spectrum-TreeView-itemIndicator {
  margin-right: calc(-1 * var(--spectrum-global-dimension-size-500));
}

[dir="ltr"] .spectrum-TreeView-itemIndicator {
  margin-right: var(--spectrum-global-dimension-size-85);
}

[dir="rtl"] .spectrum-TreeView-itemIndicator {
  margin-left: var(--spectrum-global-dimension-size-85);
}

[dir="rtl"] .spectrum-TreeView-itemIndicator { transform: matrix(-1, 0, 0, 1, 0, 0) ; }

.spectrum-TreeView-itemIndicator {
  display: block;
  box-sizing: content-box;
  position: relative;
  z-index: 1;
  top: calc(-1 * var(--spectrum-global-dimension-size-65));
  margin-bottom: calc(-1 * var(--spectrum-global-dimension-size-125));

  padding-left: var(--spectrum-global-dimension-size-150);

  padding-right: var(--spectrum-global-dimension-size-150);
  padding-top: var(--spectrum-global-dimension-size-125);
  padding-bottom: var(--spectrum-global-dimension-size-125);
  transition: transform ease var(--spectrum-global-animation-duration-100, 130ms);

  pointer-events: all !important;
}

[dir="ltr"] .spectrum-TreeView .spectrum-TreeView {

  padding-left: var(--spectrum-treeview-item-indentation);
}

[dir="rtl"] .spectrum-TreeView .spectrum-TreeView {

  padding-right: var(--spectrum-treeview-item-indentation);
}

.spectrum-TreeView .spectrum-TreeView {
  position: static;
  height: 0;
  visibility: hidden;
}

[dir="ltr"] .spectrum-TreeView-item--indent1 {
  padding-left: var(--spectrum-treeview-item-indentation);
}

[dir="rtl"] .spectrum-TreeView-item--indent1 {
  padding-right: var(--spectrum-treeview-item-indentation);
}

[dir="ltr"] .spectrum-TreeView-item--indent2 {
  padding-left: calc(2 * var(--spectrum-treeview-item-indentation));
}

[dir="rtl"] .spectrum-TreeView-item--indent2 {
  padding-right: calc(2 * var(--spectrum-treeview-item-indentation));
}

[dir="ltr"] .spectrum-TreeView-item--indent3 {
  padding-left: calc(3 * var(--spectrum-treeview-item-indentation));
}

[dir="rtl"] .spectrum-TreeView-item--indent3 {
  padding-right: calc(3 * var(--spectrum-treeview-item-indentation));
}

[dir="ltr"] .spectrum-TreeView-item--indent4 {
  padding-left: calc(4 * var(--spectrum-treeview-item-indentation));
}

[dir="rtl"] .spectrum-TreeView-item--indent4 {
  padding-right: calc(4 * var(--spectrum-treeview-item-indentation));
}

[dir="ltr"] .spectrum-TreeView-item--indent5 {
  padding-left: calc(5 * var(--spectrum-treeview-item-indentation));
}

[dir="rtl"] .spectrum-TreeView-item--indent5 {
  padding-right: calc(5 * var(--spectrum-treeview-item-indentation));
}

[dir="ltr"] .spectrum-TreeView-item--indent6 {
  padding-left: calc(6 * var(--spectrum-treeview-item-indentation));
}

[dir="rtl"] .spectrum-TreeView-item--indent6 {
  padding-right: calc(6 * var(--spectrum-treeview-item-indentation));
}

[dir="ltr"] .spectrum-TreeView-item--indent7 {
  padding-left: calc(7 * var(--spectrum-treeview-item-indentation));
}

[dir="rtl"] .spectrum-TreeView-item--indent7 {
  padding-right: calc(7 * var(--spectrum-treeview-item-indentation));
}

[dir="ltr"] .spectrum-TreeView-item--indent8 {
  padding-left: calc(8 * var(--spectrum-treeview-item-indentation));
}

[dir="rtl"] .spectrum-TreeView-item--indent8 {
  padding-right: calc(8 * var(--spectrum-treeview-item-indentation));
}

[dir="ltr"] .spectrum-TreeView-item--indent9 {
  padding-left: calc(9 * var(--spectrum-treeview-item-indentation));
}

[dir="rtl"] .spectrum-TreeView-item--indent9 {
  padding-right: calc(9 * var(--spectrum-treeview-item-indentation));
}

[dir="ltr"] .spectrum-TreeView-item--indent10 {
  padding-left: calc(10 * var(--spectrum-treeview-item-indentation));
}

[dir="rtl"] .spectrum-TreeView-item--indent10 {
  padding-right: calc(10 * var(--spectrum-treeview-item-indentation));
}

.spectrum-TreeView-heading {
  padding: var(--spectrum-treeview-item-padding-y, var(--spectrum-global-dimension-static-size-100));
  font-weight: var(--spectrum-treeview-heading-font-weight);
}

.spectrum-TreeView-heading:not(:first-child) {
    margin-top: var(--spectrum-global-dimension-size-200);
  }

.spectrum-TreeView {
  --spectrum-treeview-item-background-color-selected: var(--spectrum-alias-highlight-selected);

  --spectrum-treeview-item-background-color-quiet-selected: var(--spectrum-alias-highlight-hover);
  --spectrum-treeview-item-icon-color: var(--spectrum-alias-icon-color, var(--spectrum-global-color-gray-700));
  --spectrum-treeview-item-icon-color-hover: var(--spectrum-alias-icon-color-hover, var(--spectrum-global-color-gray-900));
  --spectrum-treeview-item-icon-color-focus: var(--spectrum-alias-icon-color-focus, var(--spectrum-global-color-gray-900));
  --spectrum-treeview-item-icon-color-selected: var(--spectrum-alias-icon-color-selected-neutral, var(--spectrum-global-color-gray-900));
  --spectrum-treeview-item-icon-color-disabled: var(--spectrum-alias-icon-color-disabled, var(--spectrum-global-color-gray-400));
  --spectrum-treeview-item-text-color-focus: var(--spectrum-alias-text-color-down, var(--spectrum-global-color-gray-900));
  --spectrum-treeview-item-text-color-selected: var(--spectrum-alias-text-color-selected-neutral, var(--spectrum-global-color-gray-900));
  --spectrum-treeview-item-text-color-disabled: var(--spectrum-alias-text-color-disabled, var(--spectrum-global-color-gray-500));
}

.spectrum-TreeView-item.is-disabled > .spectrum-TreeView-itemLink {
      color: var(--spectrum-treeview-item-text-color-disabled);
    }

.spectrum-TreeView-item.is-disabled > .spectrum-TreeView-itemLink .spectrum-Icon {
        color: var(--spectrum-treeview-item-icon-color-disabled);
      }

.spectrum-TreeView-item.is-selected > .spectrum-TreeView-itemLink {
      color: var(--spectrum-treeview-item-text-color-selected);
    }

.spectrum-TreeView-item.is-selected > .spectrum-TreeView-itemLink:before {
        background-color: var(--spectrum-treeview-item-background-color-selected);
        border-color: var(--spectrum-treeview-item-border-color-key-focus, var(--spectrum-alias-focus-color));
      }

.spectrum-TreeView-item.is-selected > .spectrum-TreeView-itemLink .spectrum-TreeView-itemIcon {
        color: var(--spectrum-treeview-item-icon-color-selected);
      }

.spectrum-TreeView-item.is-drop-target > .spectrum-TreeView-itemLink:before {
        background-color: var(--spectrum-alias-highlight-selected);
        border-color: var(--spectrum-treeview-item-border-color-key-focus, var(--spectrum-alias-focus-color));
      }

.spectrum-TreeView--quiet .spectrum-TreeView-item.is-selected > .spectrum-TreeView-itemLink:before {
          background-color: var(--spectrum-treeview-item-background-color-quiet-selected);
          border-color: transparent;
        }

.spectrum-TreeView--quiet .spectrum-TreeView-item.is-selected > .spectrum-TreeView-itemLink.focus-ring:before {
            border-color: var(--spectrum-treeview-item-border-color-key-focus, var(--spectrum-alias-focus-color));
          }

.spectrum-TreeView-itemIcon {
  color: var(--spectrum-treeview-item-icon-color);
}

.spectrum-TreeView-itemLink {
  color: var(--spectrum-treeview-item-text-color, var(--spectrum-global-color-gray-800));
}

.spectrum-TreeView-itemLink:hover {
    color: var(--spectrum-treeview-item-text-color-hover, var(--spectrum-global-color-gray-900));
  }

.spectrum-TreeView-itemLink:hover:before {
      background-color: var(--spectrum-treeview-item-background-color-hover, var(--spectrum-alias-background-color-hover-overlay));
    }

.spectrum-TreeView-itemLink:hover .spectrum-TreeView-itemIcon {
      color: var(--spectrum-treeview-item-icon-color-hover);
    }

.spectrum-TreeView-itemLink.focus-ring {
    color: var(--spectrum-treeview-item-text-color-focus);
  }

.spectrum-TreeView-itemLink.focus-ring::before {
      background-color: var(--spectrum-treeview-item-background-color-key-focus, var(--spectrum-alias-background-color-hover-overlay));

      border-color: var(--spectrum-treeview-item-border-color-key-focus, var(--spectrum-alias-focus-color));
    }

.spectrum-TreeView-itemLink.focus-ring .spectrum-TreeView-itemIcon {
      color: var(--spectrum-treeview-item-icon-color-focus);
    }
.bold.svelte-9amtlb{font-weight:bold;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:var(--max-cell-width)}code.svelte-e82i3{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:var(--max-cell-width)}p.svelte-1asmvv2{text-wrap:pretty;letter-spacing:-0.01em !important;text-rendering:optimizelegibility}h1.svelte-1m70x3z{text-wrap:balance;letter-spacing:-0.02em;font-weight:600;line-height:24px}.split-page.svelte-63esek.svelte-63esek{height:100%;display:grid;grid-template-columns:max(50%, 380px) 1fr;justify-content:stretch;overflow:hidden}.left.svelte-63esek.svelte-63esek{background:var(--background);display:grid;place-items:center;padding:40px;overflow-y:auto}.right.svelte-63esek.svelte-63esek{overflow:hidden;position:relative}.right.svelte-63esek img.svelte-63esek{position:absolute;top:0;left:0;height:100%;width:100%}.content.svelte-63esek.svelte-63esek{width:100%;max-width:400px;min-height:480px}@media(max-width: 740px){.split-page.svelte-63esek.svelte-63esek{grid-template-columns:1fr}.left.svelte-63esek.svelte-63esek{padding:20px}.right.svelte-63esek.svelte-63esek{display:none}}.signature-wrap.svelte-1jbgrys{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;background-color:var(--spectrum-global-color-gray-50);color:var(--spectrum-alias-text-color);box-sizing:border-box;position:relative}.avatars.svelte-1wnz660{display:flex}span.svelte-1wnz660:not(:first-of-type){margin-left:-6px}.avatars.svelte-1wnz660 .spectrum-Avatar{border:2px solid var(--avatars-background, var(--background))}.loading.svelte-1kjb5e.svelte-1kjb5e{display:flex;justify-content:center;flex-direction:column;gap:var(--spacing-l);height:100vh;text-align:center;font-size:18px}.header.svelte-1kjb5e.svelte-1kjb5e{font-weight:700}.timeout.svelte-1kjb5e .header.svelte-1kjb5e{color:rgb(196, 46, 46)}.subtext.svelte-1kjb5e.svelte-1kjb5e{font-size:16px;color:var(--grey-7)}.subtext.svelte-1kjb5e a.svelte-1kjb5e{color:var(--grey-7);font-weight:700}.outer.svelte-i68dpr{min-width:100%;min-height:100%;height:100%;width:100%;max-height:100%;max-width:100%;overflow:hidden}.inner.svelte-i68dpr{position:absolute}.cell.svelte-om663h.svelte-om663h{height:var(--row-height);border-bottom:var(--cell-border);border-right:var(--cell-border);display:flex;flex-direction:row;justify-content:flex-start;align-items:flex-start;color:var(--cell-font-color);font-size:var(--cell-font-size);gap:var(--cell-spacing);background:var(--cell-background);position:relative;width:0;--cell-color:transparent}.cell.alt.svelte-om663h.svelte-om663h{--cell-background:var(--cell-background-alt)}.cell.default-height.svelte-om663h.svelte-om663h{height:var(--default-row-height)}.cell.center.svelte-om663h.svelte-om663h{align-items:center}.cell.hidden.svelte-om663h.svelte-om663h{content-visibility:hidden}.cell.focused.svelte-om663h.svelte-om663h::after,.cell.error.svelte-om663h.svelte-om663h::after,.cell.selected-other.svelte-om663h.svelte-om663h:not(.focused)::after{content:" ";position:absolute;top:0;left:0;height:100%;width:100%;border:2px solid var(--cell-color);pointer-events:none;border-radius:2px;box-sizing:border-box}.cell.selected.svelte-om663h.svelte-om663h::before{content:" ";position:absolute;top:0;left:0;pointer-events:none;box-sizing:border-box;height:calc(100% + 1px);width:calc(100% + 1px);opacity:0.16;background:var(--spectrum-global-color-blue-400);z-index:2}.cell.error.svelte-om663h.svelte-om663h::after{border-radius:0 2px 2px 2px}.cell.top.error.svelte-om663h.svelte-om663h::after{border-radius:2px 2px 2px 0}.cell.selected-other.svelte-om663h.svelte-om663h:not(.focused)::after{border-radius:2px}.cell.error.svelte-om663h.svelte-om663h,.cell.selected-other.svelte-om663h.svelte-om663h:not(.focused){z-index:1}.cell.focused.svelte-om663h.svelte-om663h{z-index:2}.cell.selected-other.svelte-om663h.svelte-om663h:hover{z-index:2}.cell.svelte-om663h.svelte-om663h:not(.focused){user-select:none;-webkit-user-select:none}.cell.svelte-om663h.svelte-om663h:hover{cursor:default}.cell.selected-other.svelte-om663h.svelte-om663h{--cell-color:var(--user-color)}.cell.focused.svelte-om663h.svelte-om663h{--cell-color:var(--accent-color)}.cell.error.svelte-om663h.svelte-om663h{--cell-color:var(--spectrum-global-color-red-500)}.cell.focused.readonly.svelte-om663h.svelte-om663h{--cell-color:var(--spectrum-global-color-gray-600)}.cell.highlighted.svelte-om663h.svelte-om663h:not(.focused):not(.selected),.cell.focused.readonly.svelte-om663h.svelte-om663h{--cell-background:var(--cell-background-hover)}.label.svelte-om663h.svelte-om663h{position:absolute;bottom:100%;left:0;padding:1px 4px 3px 4px;margin:0 0 -2px 0;background:var(--cell-color);border-radius:2px;display:block;color:white;font-size:12px;font-weight:600;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;user-select:none}.cell.top.svelte-om663h .label.svelte-om663h{bottom:auto;top:100%;padding:2px 4px 2px 4px;margin:-2px 0 0 0}.error.svelte-om663h .label.svelte-om663h{background:var(--spectrum-global-color-red-500)}.selected-other.svelte-om663h:not(.error) .label.svelte-om663h{display:none}.selected-other.svelte-om663h:not(.error):hover .label.svelte-om663h{display:block}.grid-popover-container .spectrum-Popover{background:var(--grid-background);min-width:none;max-width:none;overflow:hidden}.grid-popover-contents.svelte-5gc6hw{overflow-y:auto;overflow-x:hidden;display:flex;flex-direction:column}.container.svelte-14lr9ae.svelte-14lr9ae{display:flex;flex-direction:row;justify-content:space-between;align-items:flex-start;align-self:stretch;flex:1 1 auto;overflow:hidden}.container.editable.svelte-14lr9ae.svelte-14lr9ae:hover{cursor:pointer}.values.svelte-14lr9ae.svelte-14lr9ae{display:flex;flex-direction:row;justify-content:flex-start;align-items:flex-start;flex:1 1 auto;grid-column-gap:var(--cell-spacing);grid-row-gap:var(--cell-padding);overflow:hidden;padding:var(--cell-padding);flex-wrap:nowrap}.values.wrap.svelte-14lr9ae.svelte-14lr9ae{flex-wrap:wrap}.text.svelte-14lr9ae.svelte-14lr9ae{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.multi.svelte-14lr9ae .text.svelte-14lr9ae{flex:0 0 auto}.badge.svelte-14lr9ae.svelte-14lr9ae{padding:0 var(--cell-padding);background:var(--color);border-radius:var(--cell-padding);user-select:none;display:flex;align-items:center;gap:var(--cell-spacing);height:20px;max-width:100%}.badge.svelte-14lr9ae span.svelte-14lr9ae{text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.arrow.svelte-14lr9ae.svelte-14lr9ae{position:absolute;right:0;top:0;height:100%;bottom:2px;padding:0 6px 0 16px;display:grid;place-items:center;background:linear-gradient(
      to right,
      transparent 0%,
      var(--cell-background) 40%
    )}.options.svelte-14lr9ae.svelte-14lr9ae{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch}.option.svelte-14lr9ae.svelte-14lr9ae{flex:0 0 var(--default-row-height);padding:0 var(--cell-padding);display:flex;flex-direction:row;justify-content:space-between;align-items:center;gap:var(--cell-spacing)}.option.svelte-14lr9ae.svelte-14lr9ae:hover,.option.focused.svelte-14lr9ae.svelte-14lr9ae{background-color:var(--grid-background-alt);cursor:pointer}.container.svelte-17mmumr{padding:var(--cell-padding);display:flex;flex-direction:row;justify-content:space-between;align-items:center;flex:1 1 auto;gap:var(--cell-spacing);user-select:none}.container.editable.svelte-17mmumr:hover{cursor:pointer}.value.svelte-17mmumr{flex:1 1 auto;width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:20px;height:20px}.text-cell.svelte-6ynh9c.svelte-6ynh9c{flex:1 1 auto;padding:var(--cell-padding);align-self:stretch;display:flex;align-items:flex-start;overflow:hidden}.text-cell.number.svelte-6ynh9c.svelte-6ynh9c{justify-content:flex-end}.value.svelte-6ynh9c.svelte-6ynh9c{display:-webkit-box;-webkit-line-clamp:var(--content-lines);line-clamp:var(--content-lines);-webkit-box-orient:vertical;overflow:hidden;line-height:20px}.number.svelte-6ynh9c .value.svelte-6ynh9c{-webkit-line-clamp:1;line-clamp:1}input.svelte-6ynh9c.svelte-6ynh9c{flex:1 1 auto;width:0;border:none;padding:var(--cell-padding);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;background:none;font-size:var(--cell-font-size);font-family:var(--font-sans);color:inherit;line-height:20px}input.svelte-6ynh9c.svelte-6ynh9c:focus{outline:none}input[type="number"].svelte-6ynh9c.svelte-6ynh9c{text-align:right}input.svelte-6ynh9c.svelte-6ynh9c::-webkit-outer-spin-button,input.svelte-6ynh9c.svelte-6ynh9c::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}input[type="number"].svelte-6ynh9c.svelte-6ynh9c{-moz-appearance:textfield;appearance:textfield}.wrapper.svelte-4yl685.svelte-4yl685{flex:1 1 auto;align-self:flex-start;min-height:var(--row-height);max-height:var(--row-height);overflow:hidden}.wrapper.focused.svelte-4yl685.svelte-4yl685{position:absolute;top:0;left:0;width:100%;background:var(--cell-background);z-index:1;max-height:none;overflow:visible}.container.svelte-4yl685.svelte-4yl685{min-height:var(--row-height);overflow:hidden;display:flex;align-items:flex-start}.focused.svelte-4yl685 .container.svelte-4yl685{overflow-y:auto;border-radius:2px}.focused.svelte-4yl685 .container.svelte-4yl685:after{content:" ";position:absolute;top:0;left:0;height:100%;width:100%;border:2px solid var(--cell-color);pointer-events:none;border-radius:2px;box-sizing:border-box}.values.svelte-4yl685.svelte-4yl685{display:flex;flex-direction:row;justify-content:flex-start;align-items:flex-start;flex:1 1 auto;grid-column-gap:var(--cell-spacing);grid-row-gap:var(--cell-padding);overflow:hidden;padding:var(--cell-padding);flex-wrap:nowrap}.values.disabled.svelte-4yl685.svelte-4yl685{pointer-events:none}.values.wrap.svelte-4yl685.svelte-4yl685{flex-wrap:wrap}.count.svelte-4yl685.svelte-4yl685{display:none;position:absolute;top:0;right:0;color:var(--spectrum-global-color-gray-500);padding:var(--cell-padding) var(--cell-padding) var(--cell-padding) 20px;background:linear-gradient(
      to right,
      transparent 0%,
      var(--cell-background) 40%
    )}.wrapper.svelte-4yl685:hover:not(.focused) .count.svelte-4yl685{display:block}.badge.svelte-4yl685.svelte-4yl685{flex:0 0 auto;padding:0 var(--cell-padding);background:var(--color);border-radius:var(--cell-padding);user-select:none;display:flex;align-items:center;gap:var(--cell-spacing);height:20px;max-width:100%}.values.wrap.svelte-4yl685 .badge.extra-info.svelte-4yl685:hover{filter:brightness(1.25);cursor:pointer}.badge.svelte-4yl685 span.svelte-4yl685{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.add.svelte-4yl685.svelte-4yl685{background:var(--spectrum-global-color-gray-200);padding:3px;border-radius:4px}.add.svelte-4yl685.svelte-4yl685:hover{background:var(--spectrum-global-color-gray-300);cursor:pointer}.dropdown.svelte-4yl685.svelte-4yl685{display:flex;flex-direction:column;align-items:stretch}.searching.svelte-4yl685.svelte-4yl685{padding:var(--cell-padding);display:flex;justify-content:center}.results.svelte-4yl685.svelte-4yl685{overflow-y:auto;overflow-x:hidden;display:flex;flex-direction:column;align-items:stretch}.result.svelte-4yl685.svelte-4yl685{padding:0 var(--cell-padding);flex:0 0 var(--default-row-height);display:flex;gap:var(--cell-spacing);justify-content:space-between;align-items:center}.result.candidate.svelte-4yl685.svelte-4yl685{background-color:var(--spectrum-global-color-gray-200);cursor:pointer}.result.svelte-4yl685 .badge.svelte-4yl685{flex:1 1 auto;overflow:hidden}.search.svelte-4yl685.svelte-4yl685{flex:0 0 calc(var(--default-row-height) - 1px);display:flex;align-items:center;margin:4px var(--cell-padding)}.search.svelte-4yl685 .spectrum-Textfield{min-width:0;width:100%}.search.svelte-4yl685 .spectrum-Textfield-input{font-size:13px}.search.svelte-4yl685 .spectrum-Form-item{flex:1 1 auto}.long-form-cell.svelte-w9nhoo{flex:1 1 auto;padding:var(--cell-padding);align-self:stretch;display:flex;align-items:flex-start;overflow:hidden}.long-form-cell.editable.svelte-w9nhoo:hover{cursor:text}.value.svelte-w9nhoo{display:-webkit-box;-webkit-line-clamp:var(--content-lines);line-clamp:var(--content-lines);-webkit-box-orient:vertical;overflow:hidden;line-height:20px}textarea.svelte-w9nhoo{border:none;width:320px;flex:1 1 auto;height:var(--max-cell-render-overflow);padding:var(--cell-padding);margin:0;background:var(--cell-background);font-size:var(--cell-font-size);font-family:var(--font-sans);color:inherit;z-index:1;resize:none;line-height:20px;overflow:auto}textarea.svelte-w9nhoo:focus{outline:none}.boolean-cell.svelte-1l7j6r7{padding:2px var(--cell-padding);pointer-events:none;flex:1 1 auto;display:flex;justify-content:center}.boolean-cell.editable.svelte-1l7j6r7{pointer-events:all}.long-form-cell.svelte-13x28l0{flex:1 1 auto;padding:var(--cell-padding);align-self:stretch;display:flex;align-items:flex-start;overflow:hidden}.value.svelte-13x28l0{display:-webkit-box;-webkit-line-clamp:var(--content-lines);line-clamp:var(--content-lines);-webkit-box-orient:vertical;overflow:hidden;line-height:20px}textarea.svelte-13x28l0{border:none;width:320px;flex:1 1 auto;height:var(--max-cell-render-overflow);padding:var(--cell-padding);margin:0;background:var(--cell-background);font-size:var(--cell-font-size);font-family:var(--font-sans);color:inherit;z-index:1;resize:none;line-height:20px;overflow:auto}textarea.svelte-13x28l0:focus{outline:none}.attachment-cell.svelte-1iu2dac.svelte-1iu2dac{flex:1 1 auto;display:flex;flex-direction:row;align-items:stretch;padding:var(--cell-padding);flex-wrap:nowrap;gap:var(--cell-spacing);align-self:stretch;overflow:hidden;user-select:none}.attachment-cell.editable.svelte-1iu2dac.svelte-1iu2dac:hover{cursor:pointer}.file.svelte-1iu2dac.svelte-1iu2dac{display:flex;flex-direction:row;justify-content:flex-start;align-items:center;padding:0 10px;color:var(--spectrum-global-color-gray-700);border:1px solid var(--spectrum-global-color-gray-300);border-radius:4px;text-transform:uppercase;font-weight:600;font-size:12px;user-select:none}.dropzone.svelte-1iu2dac.svelte-1iu2dac{background:var(--grid-background-alt);width:320px;padding:var(--cell-padding)}.attachment-cell.svelte-1iu2dac img.light.svelte-1iu2dac{-webkit-filter:invert(100%);filter:invert(100%)}.signature.svelte-34a6jk.svelte-34a6jk{min-width:320px;padding:var(--cell-padding);background:var(--grid-background-alt);border:var(--cell-border)}.signature.empty.svelte-34a6jk.svelte-34a6jk{width:100%;min-width:unset}.signature-cell.svelte-34a6jk img.svelte-34a6jk{max-width:100%;max-height:100%;object-fit:contain}.signature-cell.light.svelte-34a6jk img.svelte-34a6jk{-webkit-filter:invert(100%);filter:invert(100%)}.signature-cell.svelte-34a6jk.svelte-34a6jk{flex:1 1 auto;display:flex;flex-direction:row;align-items:stretch;max-width:320px;padding-left:var(--cell-padding);padding-right:var(--cell-padding);flex-wrap:nowrap;align-self:stretch;overflow:hidden;user-select:none}.signature-cell.editable.svelte-34a6jk.svelte-34a6jk:hover{cursor:pointer}.signature-wrap.svelte-34a6jk.svelte-34a6jk{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;background-color:var(--spectrum-global-color-gray-50);color:var(--spectrum-alias-text-color);box-sizing:border-box;position:relative}.role-cell.svelte-7aaju2{flex:1 1 auto;padding:var(--cell-padding);align-self:stretch;display:flex;align-items:flex-start;overflow:hidden;gap:var(--cell-padding)}.light.svelte-7aaju2{height:20px;display:grid;place-items:center}.value.svelte-7aaju2{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:20px}.row.svelte-1507qm8{width:0;display:flex;height:var(--row-height)}.button-column.svelte-1oqghfp{display:flex;flex-direction:column;background:var(--cell-background);position:absolute;top:0}.button-column.hidden.svelte-1oqghfp{opacity:0}.content.svelte-1oqghfp{position:relative;flex:1 1 auto}.row.svelte-1oqghfp{display:flex;flex-direction:row;justify-content:flex-start;align-items:stretch}.buttons.svelte-1oqghfp{display:flex;align-items:center;padding:0 var(--cell-padding);gap:var(--cell-padding);height:inherit}.buttons.offset.svelte-1oqghfp{padding-right:calc(var(--cell-padding) + 2 * var(--scroll-bar-size) - 2px)}.buttons.svelte-1oqghfp .spectrum-Button-Label{display:flex;align-items:center;gap:4px}.button-placeholder.svelte-1oqghfp{min-width:60px;height:32px}.button-placeholder-collapsed.svelte-1oqghfp{min-width:70px;height:32px;visibility:hidden}.blank.svelte-1oqghfp .cell:hover{cursor:pointer}.button-column.svelte-1oqghfp .cell{border-left:var(--cell-border)}.grid-body.svelte-17lftvb{display:block;position:relative;cursor:default;overflow:hidden;flex:1 1 auto}.row.svelte-17lftvb{display:flex;flex-direction:row;justify-content:flex-start;align-items:stretch}.blank.svelte-17lftvb .cell:hover{cursor:pointer}.resize-slider.svelte-be62xg{position:absolute;top:0;height:var(--default-row-height);opacity:0;padding:0 8px;transform:translateX(-50%);user-select:none}.resize-slider.svelte-be62xg:hover,.resize-slider.visible.svelte-be62xg{cursor:col-resize;opacity:1}.resize-indicator.svelte-be62xg{margin-left:-1px;width:2px;height:100%;background:var(--accent-color)}.reorder-wrapper.svelte-1e4eaad{position:absolute;top:0;left:0;height:100%;width:100%;pointer-events:none}.reorder-overlay.svelte-1e4eaad{position:absolute;top:0;width:2px;background:var(--accent-color);margin-left:-2px}.grid-popover-container.svelte-ws1j1t{position:fixed;top:0;left:0}.add.svelte-13f8h1i{height:var(--default-row-height);display:grid;place-items:center;width:40px;position:absolute;top:0;border-left:var(--cell-border);border-right:var(--cell-border);border-bottom:var(--cell-border);background:var(--grid-background-alt);z-index:1}.add.svelte-13f8h1i:hover{background:var(--spectrum-global-color-gray-200);cursor:pointer}.content.svelte-13f8h1i{padding:20px;display:flex;flex-direction:column;gap:20px;z-index:2;background:var(--spectrum-alias-background-color-secondary)}.header-cell.svelte-1l2zxuu.svelte-1l2zxuu{display:flex}.header-cell.svelte-1l2zxuu.svelte-1l2zxuu:not(.sticky):hover,.header-cell.svelte-1l2zxuu:not(.sticky) .cell:hover{cursor:grab}.header-cell.disabled.svelte-1l2zxuu.svelte-1l2zxuu{pointer-events:none}.header-cell.svelte-1l2zxuu .cell{padding:0 var(--cell-padding);gap:calc(1.5 * var(--cell-spacing));background:var(--header-cell-background)}.header-cell.svelte-1l2zxuu .icon{color:var(--spectrum-global-color-gray-600)}.header-cell.svelte-1l2zxuu .icon.hoverable:hover{color:var(--spectrum-global-color-gray-800) !important;cursor:pointer}.column-icon.svelte-1l2zxuu.svelte-1l2zxuu{width:18px}.search-icon.svelte-1l2zxuu.svelte-1l2zxuu{display:none;width:18px}.clear-icon.svelte-1l2zxuu.svelte-1l2zxuu{z-index:99}.header-cell.searchable.svelte-1l2zxuu:not(.open):hover .search-icon.svelte-1l2zxuu,.header-cell.searchable.searching.svelte-1l2zxuu .search-icon.svelte-1l2zxuu{display:block}.header-cell.searchable.svelte-1l2zxuu:not(.open):hover .column-icon.svelte-1l2zxuu,.header-cell.searchable.searching.svelte-1l2zxuu .column-icon.svelte-1l2zxuu{display:none}.name.svelte-1l2zxuu.svelte-1l2zxuu{flex:1 1 auto;width:0;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-weight:500}.header-cell.searching.svelte-1l2zxuu .name.svelte-1l2zxuu{opacity:0;pointer-events:none}input.svelte-1l2zxuu.svelte-1l2zxuu{display:none;font-family:var(--font-sans);outline:none;border:1px solid transparent;background:transparent;color:var(--spectrum-global-color-gray-800);position:absolute;top:0;left:0;width:100%;height:100%;padding:0 30px;border-radius:2px}input.svelte-1l2zxuu.svelte-1l2zxuu:focus{border:1px solid var(--accent-color)}input.svelte-1l2zxuu.svelte-1l2zxuu:not(:focus){background:var(--spectrum-global-color-gray-200)}.header-cell.searching.svelte-1l2zxuu input.svelte-1l2zxuu{display:block}.more-icon.svelte-1l2zxuu.svelte-1l2zxuu{display:none;padding:4px;margin:0 -4px}.header-cell.open.svelte-1l2zxuu .more-icon.svelte-1l2zxuu,.header-cell.svelte-1l2zxuu:hover .more-icon.svelte-1l2zxuu{display:block}.header-cell.open.svelte-1l2zxuu .sort-indicator.svelte-1l2zxuu,.header-cell.svelte-1l2zxuu:hover .sort-indicator.svelte-1l2zxuu{display:none}.content.svelte-1l2zxuu.svelte-1l2zxuu{width:360px;padding:20px;display:flex;flex-direction:column;gap:20px;background:var(--spectrum-alias-background-color-secondary)}.header.svelte-1rne7xg{background:var(--header-cell-background);border-bottom:var(--cell-border);position:relative;height:var(--default-row-height)}.row.svelte-1rne7xg{display:flex}div.svelte-sio5lm{position:absolute;background:var(--spectrum-global-color-gray-500);opacity:0.35;border-radius:4px;transition:opacity 130ms ease-out}div.svelte-sio5lm:hover,div.dragging.svelte-sio5lm{opacity:0.8}.v-scrollbar.svelte-sio5lm{width:var(--scroll-bar-size);right:var(--scroll-bar-size)}.h-scrollbar.svelte-sio5lm{height:var(--scroll-bar-size);bottom:var(--scroll-bar-size)}.menu-anchor.svelte-825iyj{opacity:0;pointer-events:none;position:absolute}.gutter.svelte-g7itl0.svelte-g7itl0{flex:1 1 auto;display:grid;align-items:center;padding:var(--cell-padding);grid-template-columns:1fr auto;gap:var(--cell-spacing)}.checkbox.svelte-g7itl0.svelte-g7itl0,.number.svelte-g7itl0.svelte-g7itl0{display:none;flex-direction:row;justify-content:center;align-items:center}.checkbox.svelte-g7itl0 .spectrum-Checkbox{min-height:0;height:20px}.checkbox.svelte-g7itl0 .spectrum-Checkbox-box{margin:3px 0 0 0}.number.svelte-g7itl0.svelte-g7itl0{color:var(--spectrum-global-color-gray-500)}.delete.svelte-g7itl0.svelte-g7itl0,.expand.svelte-g7itl0.svelte-g7itl0{margin-right:4px}.expand.svelte-g7itl0.svelte-g7itl0:not(.visible),.expand.svelte-g7itl0:not(.visible) *{opacity:0;pointer-events:none !important}.delete.svelte-g7itl0.svelte-g7itl0:hover{cursor:pointer}.delete.svelte-g7itl0:hover .icon{color:var(--spectrum-global-color-red-600) !important}.gutter.selectable.svelte-g7itl0 .checkbox.visible.svelte-g7itl0,.number.visible.svelte-g7itl0.svelte-g7itl0,.gutter.svelte-g7itl0:not(.selectable) .number.svelte-g7itl0{display:flex}.keys.svelte-uhg3e3.svelte-uhg3e3{display:flex;flex-direction:row;gap:3px}.keys.padded.svelte-uhg3e3.svelte-uhg3e3{padding:var(--cell-padding)}.key.svelte-uhg3e3.svelte-uhg3e3{padding:2px 6px;font-size:12px;font-weight:600;background-color:var(--spectrum-global-color-gray-300);color:var(--spectrum-global-color-gray-700);border-radius:4px;text-align:center;display:grid;place-items:center;text-transform:uppercase}.overlay.svelte-uhg3e3 .key.svelte-uhg3e3{background:rgba(255, 255, 255, 0.2);color:#eee}.sticky-column.svelte-15yu3r0{display:flex;flex-direction:column;position:relative;z-index:2;background:var(--cell-background)}.sticky-column.svelte-15yu3r0:before{position:absolute;content:"";width:0;height:100%;left:calc(100% - 1px);top:0;border-left:var(--cell-border)}.sticky-column.scrolled.svelte-15yu3r0:after{position:absolute;content:"";width:8px;height:100%;left:100%;top:0;opacity:1;background:linear-gradient(to right, var(--drop-shadow), transparent);z-index:-1}.sticky-column.svelte-15yu3r0 .cell:not(:last-child){border-right-color:transparent}.header.svelte-15yu3r0{z-index:1}.header.svelte-15yu3r0 .cell{background:var(--header-cell-background)}.header.svelte-15yu3r0 .cell::before{display:none}.row.svelte-15yu3r0{display:flex;flex-direction:row;justify-content:flex-start;align-items:stretch}.blank.svelte-15yu3r0 .cell:hover{cursor:pointer}.users.svelte-1ex8wrg{display:flex;flex-direction:row;gap:4px}.new-row-fab.svelte-8ib1kg{position:absolute;top:var(--default-row-height);left:calc(var(--gutter-width) / 2);transform:translateX(6px) translateY(-50%);background:var(--cell-background);padding:4px;border-radius:50%;border:var(--cell-border);z-index:10}.new-row-fab.svelte-8ib1kg:hover{background:var(--cell-background-hover);cursor:pointer}.new-row-fab.offset.svelte-8ib1kg{margin-left:-6px}.new-row.svelte-8ib1kg{position:absolute;top:var(--default-row-height);left:0;width:100%;height:100%;display:flex;flex-direction:row;align-items:stretch}.new-row.svelte-8ib1kg .cell{--cell-background:var(--spectrum-global-color-gray-75) !important}.new-row.floating.svelte-8ib1kg .cell{height:calc(var(--row-height) + 1px);border-top:var(--cell-border)}.underlay.svelte-8ib1kg{position:absolute;content:"";left:0;top:0;height:100%;width:100%;background:var(--cell-background);opacity:0.8}.underlay.sticky.svelte-8ib1kg{z-index:2;width:var(--sticky-width)}.buttons.svelte-8ib1kg{display:flex;flex-direction:row;gap:8px;pointer-events:all;z-index:3;position:absolute;top:calc(
      var(--row-height) + var(--offset) + var(--default-row-height) / 2
    );left:calc(var(--default-row-height) / 2)}.button-with-keys.svelte-8ib1kg{display:flex;gap:6px;align-items:center}.button-with-keys.svelte-8ib1kg > div{padding-top:2px}.buttons.flip.svelte-8ib1kg{top:calc(var(--offset) - 36px - var(--default-row-height) / 2)}.sticky-column.svelte-8ib1kg{display:flex;z-index:4;position:relative;align-self:flex-start;flex:0 0 var(--sticky-width)}.sticky-column.svelte-8ib1kg .cell:not(:last-child){border-right:none}.sticky-column.svelte-8ib1kg,.normal-columns.svelte-8ib1kg{margin-top:var(--offset)}.row.svelte-8ib1kg{width:0;display:flex}.readonly-overlay.svelte-8ib1kg{position:absolute;top:0;left:0;height:var(--row-height);width:100%;padding:var(--cell-padding);font-style:italic;color:var(--spectrum-global-color-gray-600);z-index:1;user-select:none;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.loading-overlay.svelte-8ib1kg{position:absolute;top:0;left:0;height:var(--row-height);width:100%;z-index:1;background:var(--spectrum-global-color-gray-400);opacity:0.25}.grid.svelte-fdk5zl{--accent-color:var(--primaryColor, var(--spectrum-global-color-blue-400));--grid-background:var(--spectrum-global-color-gray-50);--grid-background-alt:var(--spectrum-global-color-gray-100);--header-cell-background:var(
      --custom-header-cell-background,
      var(--spectrum-global-color-gray-100)
    );--cell-background:var(--grid-background);--cell-background-hover:var(--grid-background-alt);--cell-background-alt:var(--cell-background);--cell-padding:8px;--cell-spacing:4px;--cell-border:1px solid var(--spectrum-global-color-gray-200);--cell-font-size:14px;--cell-font-color:var(--spectrum-global-color-gray-800);flex:1 1 auto;display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;position:relative;overflow:hidden;background:var(--grid-background);min-height:var(--min-height);font-weight:500}.grid.svelte-fdk5zl,.grid.svelte-fdk5zl *{box-sizing:border-box}.grid.is-resizing.svelte-fdk5zl *{cursor:col-resize !important}.grid.is-reordering.svelte-fdk5zl *{cursor:grabbing !important}.grid.stripe.svelte-fdk5zl{--cell-background-alt:var(
      --custom-stripe-cell-background,
      var(--spectrum-global-color-gray-75)
    )}.grid-data-outer.svelte-fdk5zl,.grid-data-inner.svelte-fdk5zl{flex:1 1 auto;display:flex;justify-items:flex-start;align-items:stretch;overflow:hidden}.grid-data-outer.svelte-fdk5zl{height:0;flex-direction:column}.grid-data-inner.svelte-fdk5zl{flex-direction:row;position:relative}.grid-data-content.svelte-fdk5zl{flex:1 1 auto;overflow:hidden;display:flex;flex-direction:column}.controls.svelte-fdk5zl{height:var(--controls-height);display:flex;flex-direction:row;justify-content:space-between;align-items:center;border-bottom:var(--border-light);padding:var(--cell-padding);gap:var(--cell-spacing);background:var(--grid-background-alt);z-index:2}.controls-left.svelte-fdk5zl,.controls-right.svelte-fdk5zl{display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:var(--cell-spacing)}.controls-right.svelte-fdk5zl{gap:12px}.overlays.svelte-fdk5zl{z-index:10}.grid-loading.svelte-fdk5zl{position:absolute;width:100%;height:100%;display:grid;place-items:center;z-index:100}.grid-loading.svelte-fdk5zl:before{content:"";position:absolute;top:0;left:0;width:100%;height:100%;background:var(--grid-background-alt);opacity:0.3}.grid-error.svelte-fdk5zl{position:absolute;width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;gap:8px}.grid-error-title.svelte-fdk5zl{font-size:18px;font-weight:600}.grid-error-subtitle.svelte-fdk5zl{font-size:16px}.grid-data-outer.svelte-fdk5zl .spectrum-Checkbox-box:before,.grid-data-outer.svelte-fdk5zl .spectrum-Checkbox-box:after,.grid-data-outer.svelte-fdk5zl .spectrum-Checkbox-checkmark,.grid-data-outer.svelte-fdk5zl .spectrum-Checkbox-partialCheckmark{transition:none}.grid.quiet.svelte-fdk5zl .grid-data-content .row > .cell:not(:last-child),.grid.quiet.svelte-fdk5zl .sticky-column .row .cell,.grid.quiet.svelte-fdk5zl .new-row .row > .cell:not(:last-child),.grid.quiet.svelte-fdk5zl .header-cell:not(:last-child) .cell{border-right:none}.grid.quiet.svelte-fdk5zl .sticky-column:before{display:none}.grid.quiet.svelte-fdk5zl:not(.stripe){--header-cell-background:var(
      --custom-header-cell-background,
      var(--grid-background)
    )}.skeleton.svelte-1hc8b9o.svelte-1hc8b9o{position:relative;height:100%;display:flex;flex-direction:column;overflow:hidden;background-color:var(--spectrum-global-color-gray-200)}.animation.svelte-1hc8b9o.svelte-1hc8b9o{position:absolute;height:100%;width:100%;background:linear-gradient(
      to right,
      transparent 0%,
      var(--spectrum-global-color-gray-300) 20%,
      transparent 40%,
      transparent 100%
    );animation-duration:1.3s;animation-fill-mode:forwards;animation-iteration-count:infinite;animation-name:svelte-1hc8b9o-shimmer;animation-timing-function:linear}.noAnimation.svelte-1hc8b9o.svelte-1hc8b9o{animation-name:none;background:transparent}.devTools.svelte-1hc8b9o.svelte-1hc8b9o{display:flex;box-sizing:border-box;background-color:black;height:60px;padding:1px 24px 1px 20px;display:flex;align-items:center;z-index:1;flex-shrink:0;color:white;mix-blend-mode:multiply;background:rgb(0 0 0);font-size:30px;font-family:Source Sans 3;-webkit-font-smoothing:antialiased}.main.svelte-1hc8b9o.svelte-1hc8b9o{height:100%;display:flex;flex-direction:column}@media(max-width: 720px){#clientAppSkeletonLoader.svelte-1hc8b9o .main.svelte-1hc8b9o{flex-direction:column;width:initial}}@container (max-width: 720px){#clientAppSkeletonLoader.svelte-1hc8b9o .main.svelte-1hc8b9o{flex-direction:column;width:initial}}.sideNav.svelte-1hc8b9o .main.svelte-1hc8b9o{flex-direction:row;width:100%}.nav.svelte-1hc8b9o.svelte-1hc8b9o{flex-shrink:0;width:100%;height:141px;background-color:transparent}@media(max-width: 720px){#clientAppSkeletonLoader.svelte-1hc8b9o .nav.svelte-1hc8b9o{height:61px;width:initial}}@container (max-width: 720px){#clientAppSkeletonLoader.svelte-1hc8b9o .nav.svelte-1hc8b9o{height:61px;width:initial}}.sideNav.svelte-1hc8b9o .nav.svelte-1hc8b9o{height:100%;width:251px}.body.svelte-1hc8b9o.svelte-1hc8b9o{z-index:2;display:flex;flex-direction:column;height:100%;position:relative}@media(max-width: 720px){#clientAppSkeletonLoader.svelte-1hc8b9o .body.svelte-1hc8b9o{width:initial;height:100%}}@container (max-width: 720px){#clientAppSkeletonLoader.svelte-1hc8b9o .body.svelte-1hc8b9o{width:initial;height:100%}}.sideNav.svelte-1hc8b9o .body.svelte-1hc8b9o{width:100%;height:initial}.body.svelte-1hc8b9o svg > rect{fill:var(--spectrum-alias-background-color-primary)}.body.svelte-1hc8b9o svg{flex-shrink:0}.bodyHorizontal.svelte-1hc8b9o.svelte-1hc8b9o{display:flex;flex-shrink:0}.bodyHorizontalPadding.svelte-1hc8b9o.svelte-1hc8b9o{height:100%;flex-grow:1;background-color:var(--spectrum-alias-background-color-primary)}.bodyVerticalPadding.svelte-1hc8b9o.svelte-1hc8b9o{width:100%;flex-grow:1;background-color:var(--spectrum-alias-background-color-primary)}.footer.svelte-1hc8b9o.svelte-1hc8b9o{flex-shrink:0;box-sizing:border-box;z-index:1;height:52px;width:100%}@media(max-width: 720px){#clientAppSkeletonLoader.svelte-1hc8b9o .footer.svelte-1hc8b9o{border-top:none}}@container (max-width: 720px){#clientAppSkeletonLoader.svelte-1hc8b9o .footer.svelte-1hc8b9o{border-top:none}}.sideNav.svelte-1hc8b9o .footer.svelte-1hc8b9o{border-top:3px solid var(--spectrum-alias-background-color-primary)}@keyframes svelte-1hc8b9o-shimmer{0%{left:-170%}100%{left:170%}}.field-wrap.svelte-u5a0ap.svelte-u5a0ap{display:flex}.field.svelte-u5a0ap.svelte-u5a0ap{flex:1}.field-wrap.bindings.svelte-u5a0ap .field.svelte-u5a0ap .spectrum-Form-itemField,.field-wrap.bindings.svelte-u5a0ap .field.svelte-u5a0ap input,.field-wrap.bindings.svelte-u5a0ap .field.svelte-u5a0ap .spectrum-Picker{border-top-right-radius:0px;border-bottom-right-radius:0px}.field-wrap.bindings.svelte-u5a0ap .field.svelte-u5a0ap .spectrum-InputGroup.spectrum-Datepicker{min-width:unset;border-radius:0px}.field-wrap.bindings.svelte-u5a0ap .field.svelte-u5a0ap 
      .spectrum-InputGroup.spectrum-Datepicker
        .spectrum-Textfield-input.spectrum-InputGroup-input
    {width:100%}.binding-control.svelte-u5a0ap .icon.svelte-u5a0ap{border:1px solid
      var(
        --spectrum-textfield-m-border-color,
        var(--spectrum-alias-border-color)
      );border-left:0px;border-top-right-radius:4px;border-bottom-right-radius:4px;justify-content:center;align-items:center;display:flex;flex-direction:row;box-sizing:border-box;width:31px;color:var(--spectrum-alias-text-color);background-color:var(--spectrum-global-color-gray-75);transition:background-color var(--spectrum-global-animation-duration-100, 130ms),
      box-shadow var(--spectrum-global-animation-duration-100, 130ms),
      border-color var(--spectrum-global-animation-duration-100, 130ms);height:calc(var(--spectrum-alias-item-height-m))}.binding-control.svelte-u5a0ap .icon.svelte-u5a0ap:hover{cursor:pointer;background-color:var(--spectrum-global-color-gray-50);border-color:var(--spectrum-alias-border-color-hover);color:var(--spectrum-alias-text-color-hover)}.field-wrap.svelte-eaqops.svelte-eaqops{display:flex}.field.svelte-eaqops.svelte-eaqops{flex:1}.field-wrap.bindings.svelte-eaqops .field.svelte-eaqops .spectrum-Form-itemField,.field-wrap.bindings.svelte-eaqops .field.svelte-eaqops input,.field-wrap.bindings.svelte-eaqops .field.svelte-eaqops .spectrum-Picker{border-top-right-radius:0px;border-bottom-right-radius:0px}.field-wrap.bindings.svelte-eaqops .field.svelte-eaqops .spectrum-InputGroup.spectrum-Datepicker{min-width:unset;border-radius:0px}.field-wrap.bindings.svelte-eaqops .field.svelte-eaqops 
      .spectrum-InputGroup.spectrum-Datepicker
        .spectrum-Textfield-input.spectrum-InputGroup-input
    {width:100%}.binding-control.svelte-eaqops .icon.svelte-eaqops{border:1px solid
      var(
        --spectrum-textfield-m-border-color,
        var(--spectrum-alias-border-color)
      );border-left:0px;border-top-right-radius:4px;border-bottom-right-radius:4px;justify-content:center;align-items:center;display:flex;flex-direction:row;box-sizing:border-box;width:31px;color:var(--spectrum-alias-text-color);background-color:var(--spectrum-global-color-gray-75);transition:background-color var(--spectrum-global-animation-duration-100, 130ms),
      box-shadow var(--spectrum-global-animation-duration-100, 130ms),
      border-color var(--spectrum-global-animation-duration-100, 130ms);height:calc(var(--spectrum-alias-item-height-m))}.binding-control.svelte-eaqops .icon.svelte-eaqops:hover{cursor:pointer;background-color:var(--spectrum-global-color-gray-50);border-color:var(--spectrum-alias-border-color-hover);color:var(--spectrum-alias-text-color-hover)}.binding-control.svelte-eaqops .icon.binding.svelte-eaqops:hover{color:var(--yellow)}.group-actions.svelte-lrj6l{display:flex;gap:var(--spacing-m)}.global-filter-header.svelte-lrj6l,.empty-filter.svelte-lrj6l,.group-options.svelte-lrj6l{display:flex;gap:var(--spacing-m);align-items:center}.group-header.svelte-lrj6l{display:flex;justify-content:space-between;align-items:center}.operator-picker.svelte-lrj6l{width:74px}.empty-filter-picker.svelte-lrj6l{width:92px}.filter-groups.svelte-lrj6l{display:flex;flex-direction:column;gap:var(--spacing-xl)}.group.svelte-lrj6l{display:flex;flex-direction:column;gap:var(--spacing-l);border:1px solid var(--spectrum-global-color-gray-400);border-radius:4px;padding:var(--spacing-xl)}.filters.svelte-lrj6l{display:flex;flex-direction:column;gap:var(--spacing-l)}.filter.svelte-lrj6l{display:grid;gap:var(--spacing-l);grid-template-columns:minmax(150px, 1fr) 170px minmax(200px, 1fr) 40px 40px}.filters-footer.svelte-lrj6l{display:flex;gap:var(--spacing-xl);flex-direction:column}.add-group.svelte-lrj6l{display:flex;gap:var(--spacing-m);align-items:center}.container.svelte-lrj6l{width:100%}.spectrum {  /* spectrum-animationGlobals.css */
  --spectrum-global-animation-duration-0: 0ms;
  --spectrum-global-animation-duration-100: 130ms;
  --spectrum-global-animation-duration-200: 160ms;
  --spectrum-global-animation-duration-300: 190ms;
  --spectrum-global-animation-duration-400: 220ms;
  --spectrum-global-animation-duration-500: 250ms;
  --spectrum-global-animation-duration-600: 300ms;
  --spectrum-global-animation-duration-700: 350ms;
  --spectrum-global-animation-duration-800: 400ms;
  --spectrum-global-animation-duration-900: 450ms;
  --spectrum-global-animation-duration-1000: 500ms;
  --spectrum-global-animation-duration-2000: 1000ms;
  --spectrum-global-animation-duration-4000: 2000ms;
  --spectrum-global-animation-ease-in-out: cubic-bezier(.45, 0, .40, 1);
  --spectrum-global-animation-ease-in: cubic-bezier(.50, 0, 1, 1);
  --spectrum-global-animation-ease-out: cubic-bezier(0, 0, 0.40, 1);
  --spectrum-global-animation-linear: cubic-bezier(0, 0, 1, 1);


  /* spectrum-colorGlobals.css */
  --spectrum-global-color-status: Verified;
  --spectrum-global-color-version: 5.0.1;
  --spectrum-global-color-static-black: rgb(0, 0, 0);
  --spectrum-global-color-static-white: rgb(255, 255, 255);
  --spectrum-global-color-static-blue: rgb(20, 115, 230);
  --spectrum-global-color-static-gray-50: rgb(255, 255, 255);
  --spectrum-global-color-static-gray-75: rgb(255, 255, 255);
  --spectrum-global-color-static-gray-100: rgb(255, 255, 255);
  --spectrum-global-color-static-gray-200: rgb(244, 244, 244);
  --spectrum-global-color-static-gray-300: rgb(234, 234, 234);
  --spectrum-global-color-static-gray-400: rgb(211, 211, 211);
  --spectrum-global-color-static-gray-500: rgb(188, 188, 188);
  --spectrum-global-color-static-gray-600: rgb(149, 149, 149);
  --spectrum-global-color-static-gray-700: rgb(116, 116, 116);
  --spectrum-global-color-static-gray-800: rgb(80, 80, 80);
  --spectrum-global-color-static-gray-900: rgb(50, 50, 50);
  --spectrum-global-color-static-blue-200: rgb(90, 169, 250);
  --spectrum-global-color-static-blue-300: rgb(75, 156, 245);
  --spectrum-global-color-static-blue-400: rgb(55, 142, 240);
  --spectrum-global-color-static-blue-500: rgb(38, 128, 235);
  --spectrum-global-color-static-blue-600: rgb(20, 115, 230);
  --spectrum-global-color-static-blue-700: rgb(13, 102, 208);
  --spectrum-global-color-static-blue-800: rgb(9, 90, 186);
  --spectrum-global-color-static-red-400: rgb(236, 91, 98);
  --spectrum-global-color-static-red-500: rgb(227, 72, 80);
  --spectrum-global-color-static-red-600: rgb(215, 55, 63);
  --spectrum-global-color-static-red-700: rgb(201, 37, 45);
  --spectrum-global-color-static-red-800: rgb(187, 18, 26);
  --spectrum-global-color-static-orange-400: rgb(242, 148, 35);
  --spectrum-global-color-static-orange-500: rgb(230, 134, 25);
  --spectrum-global-color-static-orange-600: rgb(218, 123, 17);
  --spectrum-global-color-static-orange-700: rgb(203, 111, 16);
  --spectrum-global-color-static-orange-800: rgb(189, 100, 13);
  --spectrum-global-color-static-green-400: rgb(51, 171, 132);
  --spectrum-global-color-static-green-500: rgb(45, 157, 120);
  --spectrum-global-color-static-green-600: rgb(38, 142, 108);
  --spectrum-global-color-static-green-700: rgb(18, 128, 92);
  --spectrum-global-color-static-green-800: rgb(16, 113, 84);
  --spectrum-global-color-static-celery-200: rgb(88, 224, 111);
  --spectrum-global-color-static-celery-300: rgb(81, 210, 103);
  --spectrum-global-color-static-celery-400: rgb(75, 195, 95);
  --spectrum-global-color-static-celery-500: rgb(68, 181, 86);
  --spectrum-global-color-static-celery-600: rgb(61, 167, 78);
  --spectrum-global-color-static-celery-700: rgb(55, 153, 71);
  --spectrum-global-color-static-celery-800: rgb(49, 139, 64);
  --spectrum-global-color-static-chartreuse-300: rgb(155, 236, 84);
  --spectrum-global-color-static-chartreuse-400: rgb(142, 222, 73);
  --spectrum-global-color-static-chartreuse-500: rgb(133, 208, 68);
  --spectrum-global-color-static-chartreuse-600: rgb(124, 195, 63);
  --spectrum-global-color-static-chartreuse-700: rgb(115, 181, 58);
  --spectrum-global-color-static-chartreuse-800: rgb(106, 168, 52);
  --spectrum-global-color-static-yellow-200: rgb(255, 226, 46);
  --spectrum-global-color-static-yellow-300: rgb(250, 217, 0);
  --spectrum-global-color-static-yellow-400: rgb(237, 204, 0);
  --spectrum-global-color-static-yellow-500: rgb(223, 191, 0);
  --spectrum-global-color-static-yellow-600: rgb(210, 178, 0);
  --spectrum-global-color-static-yellow-700: rgb(196, 166, 0);
  --spectrum-global-color-static-yellow-800: rgb(183, 153, 0);
  --spectrum-global-color-static-magenta-200: rgb(245, 107, 183);
  --spectrum-global-color-static-magenta-300: rgb(236, 90, 170);
  --spectrum-global-color-static-magenta-400: rgb(226, 73, 157);
  --spectrum-global-color-static-magenta-500: rgb(216, 55, 144);
  --spectrum-global-color-static-magenta-600: rgb(202, 41, 130);
  --spectrum-global-color-static-magenta-700: rgb(188, 28, 116);
  --spectrum-global-color-static-magenta-800: rgb(174, 14, 102);
  --spectrum-global-color-static-fuchsia-400: rgb(207, 62, 220);
  --spectrum-global-color-static-fuchsia-500: rgb(192, 56, 204);
  --spectrum-global-color-static-fuchsia-600: rgb(177, 48, 189);
  --spectrum-global-color-static-fuchsia-700: rgb(162, 40, 173);
  --spectrum-global-color-static-fuchsia-800: rgb(147, 33, 158);
  --spectrum-global-color-static-purple-400: rgb(157, 100, 225);
  --spectrum-global-color-static-purple-500: rgb(146, 86, 217);
  --spectrum-global-color-static-purple-600: rgb(134, 76, 204);
  --spectrum-global-color-static-purple-700: rgb(122, 66, 191);
  --spectrum-global-color-static-purple-800: rgb(111, 56, 177);
  --spectrum-global-color-static-indigo-200: rgb(144, 144, 250);
  --spectrum-global-color-static-indigo-300: rgb(130, 130, 246);
  --spectrum-global-color-static-indigo-400: rgb(117, 117, 241);
  --spectrum-global-color-static-indigo-500: rgb(103, 103, 236);
  --spectrum-global-color-static-indigo-600: rgb(92, 92, 224);
  --spectrum-global-color-static-indigo-700: rgb(81, 81, 211);
  --spectrum-global-color-static-indigo-800: rgb(70, 70, 198);
  --spectrum-global-color-static-seafoam-200: rgb(38, 192, 199);
  --spectrum-global-color-static-seafoam-300: rgb(35, 178, 184);
  --spectrum-global-color-static-seafoam-400: rgb(32, 163, 168);
  --spectrum-global-color-static-seafoam-500: rgb(27, 149, 154);
  --spectrum-global-color-static-seafoam-600: rgb(22, 135, 140);
  --spectrum-global-color-static-seafoam-700: rgb(15, 121, 125);
  --spectrum-global-color-static-seafoam-800: rgb(9, 108, 111);
  --spectrum-global-color-opacity-100: 1;
  --spectrum-global-color-opacity-90: 0.9;
  --spectrum-global-color-opacity-80: 0.8;
  --spectrum-global-color-opacity-60: 0.6;
  --spectrum-global-color-opacity-50: 0.5;
  --spectrum-global-color-opacity-42: 0.42;
  --spectrum-global-color-opacity-40: 0.4;
  --spectrum-global-color-opacity-30: 0.3;
  --spectrum-global-color-opacity-25: 0.25;
  --spectrum-global-color-opacity-20: 0.2;
  --spectrum-global-color-opacity-15: 0.15;
  --spectrum-global-color-opacity-10: 0.1;
  --spectrum-global-color-opacity-8: 0.08;
  --spectrum-global-color-opacity-7: 0.07;
  --spectrum-global-color-opacity-6: 0.06;
  --spectrum-global-color-opacity-5: 0.05;
  --spectrum-global-color-opacity-4: 0.04;


  /* spectrum-colorSemantics.css */
  --spectrum-semantic-negative-color-background: var(--spectrum-global-color-static-red-700);
  --spectrum-semantic-negative-color-default: var(--spectrum-global-color-red-500);
  --spectrum-semantic-negative-color-state-hover: var(--spectrum-global-color-red-600);
  --spectrum-semantic-negative-color-dark: var(--spectrum-global-color-red-600);
  --spectrum-semantic-negative-color-border: var(--spectrum-global-color-red-400);
  --spectrum-semantic-negative-color-icon: var(--spectrum-global-color-red-600);
  --spectrum-semantic-negative-color-status: var(--spectrum-global-color-red-400);
  --spectrum-semantic-negative-color-text-large: var(--spectrum-global-color-red-500);
  --spectrum-semantic-negative-color-text-small: var(--spectrum-global-color-red-600);
  --spectrum-semantic-negative-color-state-down: var(--spectrum-global-color-red-700);
  --spectrum-semantic-negative-color-state-focus: var(--spectrum-global-color-red-400);
  --spectrum-semantic-negative-background-color-default: var(--spectrum-global-color-static-red-600);
  --spectrum-semantic-negative-background-color-hover: var(--spectrum-global-color-static-red-700);
  --spectrum-semantic-negative-background-color-down: var(--spectrum-global-color-static-red-800);
  --spectrum-semantic-negative-background-color-key-focus: var(--spectrum-global-color-static-red-700);
  --spectrum-semantic-notice-color-background: var(--spectrum-global-color-static-orange-700);
  --spectrum-semantic-notice-color-default: var(--spectrum-global-color-orange-500);
  --spectrum-semantic-notice-color-dark: var(--spectrum-global-color-orange-600);
  --spectrum-semantic-notice-color-border: var(--spectrum-global-color-orange-400);
  --spectrum-semantic-notice-color-icon: var(--spectrum-global-color-orange-600);
  --spectrum-semantic-notice-color-status: var(--spectrum-global-color-orange-400);
  --spectrum-semantic-notice-color-text-large: var(--spectrum-global-color-orange-500);
  --spectrum-semantic-notice-color-text-small: var(--spectrum-global-color-orange-600);
  --spectrum-semantic-notice-color-state-down: var(--spectrum-global-color-orange-700);
  --spectrum-semantic-notice-color-state-focus: var(--spectrum-global-color-orange-400);
  --spectrum-semantic-notice-background-color-default: var(--spectrum-global-color-static-orange-600);
  --spectrum-semantic-notice-background-color-hover: var(--spectrum-global-color-static-orange-700);
  --spectrum-semantic-notice-background-color-down: var(--spectrum-global-color-static-orange-800);
  --spectrum-semantic-notice-background-color-key-focus: var(--spectrum-global-color-static-orange-700);
  --spectrum-semantic-positive-color-background: var(--spectrum-global-color-static-green-700);
  --spectrum-semantic-positive-color-default: var(--spectrum-global-color-green-500);
  --spectrum-semantic-positive-color-dark: var(--spectrum-global-color-green-600);
  --spectrum-semantic-positive-color-border: var(--spectrum-global-color-green-400);
  --spectrum-semantic-positive-color-icon: var(--spectrum-global-color-green-600);
  --spectrum-semantic-positive-color-status: var(--spectrum-global-color-green-400);
  --spectrum-semantic-positive-color-text-large: var(--spectrum-global-color-green-500);
  --spectrum-semantic-positive-color-text-small: var(--spectrum-global-color-green-600);
  --spectrum-semantic-positive-color-state-down: var(--spectrum-global-color-green-700);
  --spectrum-semantic-positive-color-state-focus: var(--spectrum-global-color-green-400);
  --spectrum-semantic-positive-background-color-default: var(--spectrum-global-color-static-green-600);
  --spectrum-semantic-positive-background-color-hover: var(--spectrum-global-color-static-green-700);
  --spectrum-semantic-positive-background-color-down: var(--spectrum-global-color-static-green-800);
  --spectrum-semantic-positive-background-color-key-focus: var(--spectrum-global-color-static-green-700);
  --spectrum-semantic-informative-color-background: var(--spectrum-global-color-static-blue-700);
  --spectrum-semantic-informative-color-default: var(--spectrum-global-color-blue-500);
  --spectrum-semantic-informative-color-dark: var(--spectrum-global-color-blue-600);
  --spectrum-semantic-informative-color-border: var(--spectrum-global-color-blue-400);
  --spectrum-semantic-informative-color-icon: var(--spectrum-global-color-blue-600);
  --spectrum-semantic-informative-color-status: var(--spectrum-global-color-blue-400);
  --spectrum-semantic-informative-color-text-large: var(--spectrum-global-color-blue-500);
  --spectrum-semantic-informative-color-text-small: var(--spectrum-global-color-blue-600);
  --spectrum-semantic-informative-color-state-down: var(--spectrum-global-color-blue-700);
  --spectrum-semantic-informative-color-state-focus: var(--spectrum-global-color-blue-400);
  --spectrum-semantic-informative-background-color-default: var(--spectrum-global-color-static-blue-600);
  --spectrum-semantic-informative-background-color-hover: var(--spectrum-global-color-static-blue-700);
  --spectrum-semantic-informative-background-color-down: var(--spectrum-global-color-static-blue-800);
  --spectrum-semantic-informative-background-color-key-focus: var(--spectrum-global-color-static-blue-700);
  --spectrum-semantic-cta-color-background-default: var(--spectrum-global-color-static-blue-600);
  --spectrum-semantic-cta-color-background-hover: var(--spectrum-global-color-static-blue-700);
  --spectrum-semantic-cta-color-background-down: var(--spectrum-global-color-static-blue-800);
  --spectrum-semantic-cta-color-background-key-focus: var(--spectrum-global-color-static-blue-600);
  --spectrum-semantic-neutral-background-color-default: var(--spectrum-global-color-static-gray-700);
  --spectrum-semantic-neutral-background-color-hover: var(--spectrum-global-color-static-gray-800);
  --spectrum-semantic-neutral-background-color-down: var(--spectrum-global-color-static-gray-900);
  --spectrum-semantic-neutral-background-color-key-focus: var(--spectrum-global-color-static-gray-800);
  --spectrum-semantic-presence-color-1: var(--spectrum-global-color-static-red-500);
  --spectrum-semantic-presence-color-2: var(--spectrum-global-color-static-orange-400);
  --spectrum-semantic-presence-color-3: var(--spectrum-global-color-static-yellow-400);
  --spectrum-semantic-presence-color-4: rgb(75, 204, 162);
  --spectrum-semantic-presence-color-5: rgb(0, 199, 255);
  --spectrum-semantic-presence-color-6: rgb(0, 140, 184);
  --spectrum-semantic-presence-color-7: rgb(126, 75, 243);
  --spectrum-semantic-presence-color-8: var(--spectrum-global-color-static-fuchsia-600);


  /* spectrum-dimensionGlobals.css */
  --spectrum-global-dimension-static-size-0: 0px;
  --spectrum-global-dimension-static-size-10: 1px;
  --spectrum-global-dimension-static-size-25: 2px;
  --spectrum-global-dimension-static-size-40: 3px;
  --spectrum-global-dimension-static-size-50: 4px;
  --spectrum-global-dimension-static-size-65: 5px;
  --spectrum-global-dimension-static-size-75: 6px;
  --spectrum-global-dimension-static-size-85: 7px;
  --spectrum-global-dimension-static-size-100: 8px;
  --spectrum-global-dimension-static-size-115: 9px;
  --spectrum-global-dimension-static-size-125: 10px;
  --spectrum-global-dimension-static-size-130: 11px;
  --spectrum-global-dimension-static-size-150: 12px;
  --spectrum-global-dimension-static-size-160: 13px;
  --spectrum-global-dimension-static-size-175: 14px;
  --spectrum-global-dimension-static-size-200: 16px;
  --spectrum-global-dimension-static-size-225: 18px;
  --spectrum-global-dimension-static-size-250: 20px;
  --spectrum-global-dimension-static-size-275: 22px;
  --spectrum-global-dimension-static-size-300: 24px;
  --spectrum-global-dimension-static-size-325: 26px;
  --spectrum-global-dimension-static-size-400: 32px;
  --spectrum-global-dimension-static-size-450: 36px;
  --spectrum-global-dimension-static-size-500: 40px;
  --spectrum-global-dimension-static-size-550: 44px;
  --spectrum-global-dimension-static-size-600: 48px;
  --spectrum-global-dimension-static-size-700: 56px;
  --spectrum-global-dimension-static-size-800: 64px;
  --spectrum-global-dimension-static-size-900: 72px;
  --spectrum-global-dimension-static-size-1000: 80px;
  --spectrum-global-dimension-static-size-1200: 96px;
  --spectrum-global-dimension-static-size-1700: 136px;
  --spectrum-global-dimension-static-size-2400: 192px;
  --spectrum-global-dimension-static-size-2500: 200px;
  --spectrum-global-dimension-static-size-2600: 208px;
  --spectrum-global-dimension-static-size-2800: 224px;
  --spectrum-global-dimension-static-size-3200: 256px;
  --spectrum-global-dimension-static-size-3400: 272px;
  --spectrum-global-dimension-static-size-3500: 280px;
  --spectrum-global-dimension-static-size-3600: 288px;
  --spectrum-global-dimension-static-size-3800: 304px;
  --spectrum-global-dimension-static-size-4600: 368px;
  --spectrum-global-dimension-static-size-5000: 400px;
  --spectrum-global-dimension-static-size-6000: 480px;
  --spectrum-global-dimension-static-size-16000: 1280px;
  --spectrum-global-dimension-static-font-size-50: 11px;
  --spectrum-global-dimension-static-font-size-75: 12px;
  --spectrum-global-dimension-static-font-size-100: 14px;
  --spectrum-global-dimension-static-font-size-150: 15px;
  --spectrum-global-dimension-static-font-size-200: 16px;
  --spectrum-global-dimension-static-font-size-300: 18px;
  --spectrum-global-dimension-static-font-size-400: 20px;
  --spectrum-global-dimension-static-font-size-500: 22px;
  --spectrum-global-dimension-static-font-size-600: 25px;
  --spectrum-global-dimension-static-font-size-700: 28px;
  --spectrum-global-dimension-static-font-size-800: 32px;
  --spectrum-global-dimension-static-font-size-900: 36px;
  --spectrum-global-dimension-static-font-size-1000: 40px;
  --spectrum-global-dimension-static-percent-50: 50%;
  --spectrum-global-dimension-static-percent-100: 100%;
  --spectrum-global-dimension-static-breakpoint-xsmall: 304px;
  --spectrum-global-dimension-static-breakpoint-small: 768px;
  --spectrum-global-dimension-static-breakpoint-medium: 1280px;
  --spectrum-global-dimension-static-breakpoint-large: 1768px;
  --spectrum-global-dimension-static-breakpoint-xlarge: 2160px;
  --spectrum-global-dimension-static-grid-columns: 12;
  --spectrum-global-dimension-static-grid-fluid-width: 100%;
  --spectrum-global-dimension-static-grid-fixed-max-width: 1280px;


  /* spectrum-fontGlobals.css */
  --spectrum-global-font-family-base: adobe-clean, 'Source Sans Pro', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Trebuchet MS', 'Lucida Grande', sans-serif;
  --spectrum-global-font-family-serif: adobe-clean-serif, 'Source Serif Pro', Georgia, serif;
  --spectrum-global-font-family-code: 'Source Code Pro', Monaco, monospace;
  --spectrum-global-font-weight-thin: 100;
  --spectrum-global-font-weight-ultra-light: 200;
  --spectrum-global-font-weight-light: 300;
  --spectrum-global-font-weight-regular: 400;
  --spectrum-global-font-weight-medium: 500;
  --spectrum-global-font-weight-semi-bold: 600;
  --spectrum-global-font-weight-bold: 700;
  --spectrum-global-font-weight-extra-bold: 800;
  --spectrum-global-font-weight-black: 900;
  --spectrum-global-font-style-regular: normal;
  --spectrum-global-font-style-italic: italic;
  --spectrum-global-font-letter-spacing-none: 0;
  --spectrum-global-font-letter-spacing-small: 0.0125em;
  --spectrum-global-font-letter-spacing-han: 0.05em;
  --spectrum-global-font-letter-spacing-medium: 0.06em;
  --spectrum-global-font-line-height-large: 1.7;
  --spectrum-global-font-line-height-medium: 1.5;
  --spectrum-global-font-line-height-small: 1.3;
  --spectrum-global-font-multiplier-25: 0.25em;
  --spectrum-global-font-multiplier-75: 0.75em;


  /* spectrum-staticAliases.css */
  --spectrum-alias-border-size-thin: var(--spectrum-global-dimension-static-size-10);
  --spectrum-alias-border-size-thick: var(--spectrum-global-dimension-static-size-25);
  --spectrum-alias-border-size-thicker: var(--spectrum-global-dimension-static-size-50);
  --spectrum-alias-border-size-thickest: var(--spectrum-global-dimension-static-size-100);
  --spectrum-alias-border-offset-thin: var(--spectrum-global-dimension-static-size-25);
  --spectrum-alias-border-offset-thick: var(--spectrum-global-dimension-static-size-50);
  --spectrum-alias-border-offset-thicker: var(--spectrum-global-dimension-static-size-100);
  --spectrum-alias-border-offset-thickest: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-grid-baseline: var(--spectrum-global-dimension-static-size-100);
  --spectrum-alias-grid-gutter-xsmall: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-grid-gutter-small: var(--spectrum-global-dimension-static-size-300);
  --spectrum-alias-grid-gutter-medium: var(--spectrum-global-dimension-static-size-400);
  --spectrum-alias-grid-gutter-large: var(--spectrum-global-dimension-static-size-500);
  --spectrum-alias-grid-gutter-xlarge: var(--spectrum-global-dimension-static-size-600);
  --spectrum-alias-grid-margin-xsmall: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-grid-margin-small: var(--spectrum-global-dimension-static-size-300);
  --spectrum-alias-grid-margin-medium: var(--spectrum-global-dimension-static-size-400);
  --spectrum-alias-grid-margin-large: var(--spectrum-global-dimension-static-size-500);
  --spectrum-alias-grid-margin-xlarge: var(--spectrum-global-dimension-static-size-600);
  --spectrum-alias-grid-layout-region-margin-bottom-xsmall: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-grid-layout-region-margin-bottom-small: var(--spectrum-global-dimension-static-size-300);
  --spectrum-alias-grid-layout-region-margin-bottom-medium: var(--spectrum-global-dimension-static-size-400);
  --spectrum-alias-grid-layout-region-margin-bottom-large: var(--spectrum-global-dimension-static-size-500);
  --spectrum-alias-grid-layout-region-margin-bottom-xlarge: var(--spectrum-global-dimension-static-size-600);
  --spectrum-alias-radial-reaction-size-default: var(--spectrum-global-dimension-static-size-550);
  --spectrum-alias-font-family-ar: myriad-arabic, adobe-clean, 'Source Sans Pro', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Trebuchet MS', 'Lucida Grande', sans-serif;
  --spectrum-alias-font-family-he: myriad-hebrew, adobe-clean, 'Source Sans Pro', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Trebuchet MS', 'Lucida Grande', sans-serif;
  --spectrum-alias-font-family-zh: adobe-clean-han-traditional, source-han-traditional, 'MingLiu', 'Heiti TC Light','sans-serif';
  --spectrum-alias-font-family-zhhans: adobe-clean-han-simplified-c, source-han-simplified-c, 'SimSun', 'Heiti SC Light', 'sans-serif';
  --spectrum-alias-font-family-ko: adobe-clean-han-korean, source-han-korean, 'Malgun Gothic', 'Apple Gothic', 'sans-serif';
  --spectrum-alias-font-family-ja: adobe-clean-han-japanese, source-han-japanese, 'Yu Gothic', '\\30E1 \\30A4 \\30EA \\30AA', '\\30D2 \\30E9 \\30AE \\30CE \\89D2 \\30B4  Pro W3', 'Hiragino Kaku Gothic Pro W3', 'Osaka', '\\FF2D \\FF33 \\FF30 \\30B4 \\30B7 \\30C3 \\30AF', 'MS PGothic', 'sans-serif';
  --spectrum-alias-font-family-condensed: adobe-clean-han-traditional, source-han-traditional, 'MingLiu', 'Heiti TC Light', adobe-clean, 'Source Sans Pro', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Trebuchet MS', 'Lucida Grande', sans-serif;
  --spectrum-alias-body-text-font-family: var(--spectrum-global-font-family-base);
  --spectrum-alias-body-text-line-height: var(--spectrum-global-font-line-height-medium);
  --spectrum-alias-body-text-font-weight: var(--spectrum-global-font-weight-regular);
  --spectrum-alias-body-text-font-weight-strong: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-button-text-line-height: var(--spectrum-global-font-line-height-small);
  --spectrum-alias-component-text-line-height: var(--spectrum-global-font-line-height-small);
  --spectrum-alias-han-component-text-line-height: var(--spectrum-global-font-line-height-medium);
  --spectrum-alias-heading-text-line-height: var(--spectrum-global-font-line-height-small);
  --spectrum-alias-heading-text-font-weight-regular: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-heading-text-font-weight-regular-strong: var(--spectrum-global-font-weight-black);
  --spectrum-alias-heading-text-font-weight-quiet: var(--spectrum-global-font-weight-light);
  --spectrum-alias-heading-text-font-weight-quiet-strong: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-heading-text-font-weight-strong: var(--spectrum-global-font-weight-black);
  --spectrum-alias-heading-text-font-weight-strong-strong: var(--spectrum-global-font-weight-black);
  --spectrum-alias-subheading-text-font-weight: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-subheading-text-font-weight-strong: var(--spectrum-global-font-weight-black);
  --spectrum-alias-detail-text-font-weight: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-detail-text-font-weight-light: var(--spectrum-global-font-weight-regular);
  --spectrum-alias-detail-text-font-weight-strong: var(--spectrum-global-font-weight-black);
  --spectrum-alias-serif-text-font-family: var(--spectrum-global-font-family-serif);
  --spectrum-alias-article-body-text-font-weight: var(--spectrum-global-font-weight-regular);
  --spectrum-alias-article-body-text-font-weight-strong: var(--spectrum-global-font-weight-black);
  --spectrum-alias-article-heading-text-font-weight: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-article-heading-text-font-weight-strong: var(--spectrum-global-font-weight-black);
  --spectrum-alias-article-heading-text-font-weight-quiet: var(--spectrum-global-font-weight-regular);
  --spectrum-alias-article-heading-text-font-weight-quiet-strong: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-article-subheading-text-font-weight: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-article-subheading-text-font-weight-strong: var(--spectrum-global-font-weight-black);
  --spectrum-alias-article-detail-text-font-weight: var(--spectrum-global-font-weight-regular);
  --spectrum-alias-article-detail-text-font-weight-strong: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-code-text-font-family: var(--spectrum-global-font-family-code);
  --spectrum-alias-han-heading-text-line-height: var(--spectrum-global-font-line-height-medium);
  --spectrum-alias-han-heading-text-font-weight-regular: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-han-heading-text-font-weight-regular-emphasis: var(--spectrum-global-font-weight-extra-bold);
  --spectrum-alias-han-heading-text-font-weight-regular-strong: var(--spectrum-global-font-weight-black);
  --spectrum-alias-han-heading-text-font-weight-quiet-strong: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-han-heading-text-font-weight-light: var(--spectrum-global-font-weight-light);
  --spectrum-alias-han-heading-text-font-weight-light-emphasis: var(--spectrum-global-font-weight-regular);
  --spectrum-alias-han-heading-text-font-weight-light-strong: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-han-heading-text-font-weight-heavy: var(--spectrum-global-font-weight-black);
  --spectrum-alias-han-heading-text-font-weight-heavy-emphasis: var(--spectrum-global-font-weight-black);
  --spectrum-alias-han-heading-text-font-weight-heavy-strong: var(--spectrum-global-font-weight-black);
  --spectrum-alias-han-body-text-line-height: var(--spectrum-global-font-line-height-large);
  --spectrum-alias-han-body-text-font-weight-regular: var(--spectrum-global-font-weight-regular);
  --spectrum-alias-han-body-text-font-weight-emphasis: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-han-body-text-font-weight-strong: var(--spectrum-global-font-weight-black);
  --spectrum-alias-han-subheading-text-font-weight-regular: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-han-subheading-text-font-weight-emphasis: var(--spectrum-global-font-weight-extra-bold);
  --spectrum-alias-han-subheading-text-font-weight-strong: var(--spectrum-global-font-weight-black);
  --spectrum-alias-han-detail-text-font-weight: var(--spectrum-global-font-weight-regular);
  --spectrum-alias-han-detail-text-font-weight-emphasis: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-han-detail-text-font-weight-strong: var(--spectrum-global-font-weight-black);
  --spectrum-alias-code-text-font-weight-regular: var(--spectrum-global-font-weight-regular);
  --spectrum-alias-code-text-font-weight-strong: var(--spectrum-global-font-weight-bold);
  --spectrum-alias-code-text-line-height: var(--spectrum-global-font-line-height-medium);
  --spectrum-alias-heading-margin-bottom: var(--spectrum-global-font-multiplier-25);
  --spectrum-alias-body-margin-bottom: var(--spectrum-global-font-multiplier-75);
  --spectrum-alias-focus-ring-gap: var(--spectrum-global-dimension-static-size-25);
  --spectrum-alias-focus-ring-size: var(--spectrum-global-dimension-static-size-25);
  --spectrum-alias-loupe-entry-animation-duration: var(--spectrum-global-animation-duration-300);
  --spectrum-alias-loupe-exit-animation-duration: var(--spectrum-global-animation-duration-300);

}

.spectrum--medium,
.spectrum--large {
  /* spectrum-dimensionAliases.css */
  --spectrum-alias-dropshadow-blur: var(--spectrum-global-dimension-size-50);
  --spectrum-alias-dropshadow-offset-y: var(--spectrum-global-dimension-size-10);
  --spectrum-alias-font-size-default: var(--spectrum-global-dimension-font-size-100);
  --spectrum-alias-layout-label-gap-size: var(--spectrum-global-dimension-size-100);
  --spectrum-alias-pill-button-text-size: var(--spectrum-global-dimension-font-size-100);
  --spectrum-alias-pill-button-text-baseline: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-border-radius-xsmall: var(--spectrum-global-dimension-size-10);
  --spectrum-alias-border-radius-small: var(--spectrum-global-dimension-size-25);
  --spectrum-alias-border-radius-regular: var(--spectrum-global-dimension-size-50);
  --spectrum-alias-border-radius-medium: var(--spectrum-global-dimension-size-100);
  --spectrum-alias-border-radius-large: var(--spectrum-global-dimension-size-200);
  --spectrum-alias-single-line-height: var(--spectrum-global-dimension-size-400);
  --spectrum-alias-single-line-width: var(--spectrum-global-dimension-size-2400);
  --spectrum-alias-item-height-s: var(--spectrum-global-dimension-size-300);
  --spectrum-alias-item-height-m: var(--spectrum-global-dimension-size-400);
  --spectrum-alias-item-height-l: var(--spectrum-global-dimension-size-500);
  --spectrum-alias-item-height-xl: var(--spectrum-global-dimension-size-600);
  --spectrum-alias-item-rounded-border-radius-s: var(--spectrum-global-dimension-size-150);
  --spectrum-alias-item-rounded-border-radius-m: var(--spectrum-global-dimension-size-200);
  --spectrum-alias-item-rounded-border-radius-l: var(--spectrum-global-dimension-size-250);
  --spectrum-alias-item-rounded-border-radius-xl: var(--spectrum-global-dimension-size-300);
  --spectrum-alias-item-text-size-s: var(--spectrum-global-dimension-font-size-75);
  --spectrum-alias-item-text-size-m: var(--spectrum-global-dimension-font-size-100);
  --spectrum-alias-item-text-size-l: var(--spectrum-global-dimension-font-size-200);
  --spectrum-alias-item-text-size-xl: var(--spectrum-global-dimension-font-size-300);
  --spectrum-alias-item-text-padding-top-s: var(--spectrum-global-dimension-static-size-50);
  --spectrum-alias-item-text-padding-top-m: var(--spectrum-global-dimension-size-75);
  --spectrum-alias-item-text-padding-top-xl: var(--spectrum-global-dimension-size-150);
  --spectrum-alias-item-text-padding-bottom-m: var(--spectrum-global-dimension-size-115);
  --spectrum-alias-item-text-padding-bottom-l: var(--spectrum-global-dimension-size-130);
  --spectrum-alias-item-text-padding-bottom-xl: var(--spectrum-global-dimension-size-175);
  --spectrum-alias-item-icon-padding-top-s: var(--spectrum-global-dimension-size-50);
  --spectrum-alias-item-icon-padding-top-m: var(--spectrum-global-dimension-size-85);
  --spectrum-alias-item-icon-padding-top-l: var(--spectrum-global-dimension-size-125);
  --spectrum-alias-item-icon-padding-top-xl: var(--spectrum-global-dimension-size-160);
  --spectrum-alias-item-icon-padding-bottom-s: var(--spectrum-global-dimension-size-50);
  --spectrum-alias-item-icon-padding-bottom-m: var(--spectrum-global-dimension-size-85);
  --spectrum-alias-item-icon-padding-bottom-l: var(--spectrum-global-dimension-size-125);
  --spectrum-alias-item-icon-padding-bottom-xl: var(--spectrum-global-dimension-size-160);
  --spectrum-alias-item-mark-padding-top-s: var(--spectrum-global-dimension-size-40);
  --spectrum-alias-item-mark-padding-top-l: var(--spectrum-global-dimension-size-115);
  --spectrum-alias-item-mark-padding-top-xl: var(--spectrum-global-dimension-size-130);
  --spectrum-alias-item-mark-padding-bottom-s: var(--spectrum-global-dimension-size-40);
  --spectrum-alias-item-mark-padding-bottom-l: var(--spectrum-global-dimension-size-115);
  --spectrum-alias-item-mark-padding-bottom-xl: var(--spectrum-global-dimension-size-130);
  --spectrum-alias-item-padding-s: var(--spectrum-global-dimension-size-115);
  --spectrum-alias-item-padding-m: var(--spectrum-global-dimension-size-150);
  --spectrum-alias-item-padding-l: var(--spectrum-global-dimension-size-185);
  --spectrum-alias-item-padding-xl: var(--spectrum-global-dimension-size-225);
  --spectrum-alias-item-rounded-padding-s: var(--spectrum-global-dimension-size-150);
  --spectrum-alias-item-rounded-padding-m: var(--spectrum-global-dimension-size-200);
  --spectrum-alias-item-rounded-padding-l: var(--spectrum-global-dimension-size-250);
  --spectrum-alias-item-rounded-padding-xl: var(--spectrum-global-dimension-size-300);
  --spectrum-alias-item-icononly-padding-s: var(--spectrum-global-dimension-size-50);
  --spectrum-alias-item-icononly-padding-m: var(--spectrum-global-dimension-size-85);
  --spectrum-alias-item-icononly-padding-l: var(--spectrum-global-dimension-size-125);
  --spectrum-alias-item-icononly-padding-xl: var(--spectrum-global-dimension-size-160);
  --spectrum-alias-item-workflow-padding-left-s: var(--spectrum-global-dimension-size-85);
  --spectrum-alias-item-workflow-padding-left-l: var(--spectrum-global-dimension-size-160);
  --spectrum-alias-item-workflow-padding-left-xl: var(--spectrum-global-dimension-size-185);
  --spectrum-alias-item-rounded-workflow-padding-left-s: var(--spectrum-global-dimension-size-125);
  --spectrum-alias-item-rounded-workflow-padding-left-l: var(--spectrum-global-dimension-size-225);
  --spectrum-alias-item-mark-padding-left-s: var(--spectrum-global-dimension-size-85);
  --spectrum-alias-item-mark-padding-left-l: var(--spectrum-global-dimension-size-160);
  --spectrum-alias-item-mark-padding-left-xl: var(--spectrum-global-dimension-size-185);
  --spectrum-alias-item-control-1-size-s: var(--spectrum-global-dimension-static-size-100);
  --spectrum-alias-item-control-1-size-m: var(--spectrum-global-dimension-size-100);
  --spectrum-alias-item-control-2-size-m: var(--spectrum-global-dimension-size-175);
  --spectrum-alias-item-control-2-size-l: var(--spectrum-global-dimension-size-200);
  --spectrum-alias-item-control-2-size-xl: var(--spectrum-global-dimension-size-225);
  --spectrum-alias-item-control-2-size-xxl: var(--spectrum-global-dimension-size-250);
  --spectrum-alias-item-control-3-height-m: var(--spectrum-global-dimension-size-175);
  --spectrum-alias-item-control-3-height-l: var(--spectrum-global-dimension-size-200);
  --spectrum-alias-item-control-3-height-xl: var(--spectrum-global-dimension-size-225);
  --spectrum-alias-item-mark-size-s: var(--spectrum-global-dimension-size-225);
  --spectrum-alias-item-mark-size-l: var(--spectrum-global-dimension-size-275);
  --spectrum-alias-item-mark-size-xl: var(--spectrum-global-dimension-size-325);
  --spectrum-alias-workflow-icon-size-s: var(--spectrum-global-dimension-size-200);
  --spectrum-alias-workflow-icon-size-m: var(--spectrum-global-dimension-size-225);
  --spectrum-alias-workflow-icon-size-xl: var(--spectrum-global-dimension-size-275);
  --spectrum-alias-ui-icon-alert-size-75: var(--spectrum-global-dimension-size-200);
  --spectrum-alias-ui-icon-alert-size-100: var(--spectrum-global-dimension-size-225);
  --spectrum-alias-ui-icon-alert-size-200: var(--spectrum-global-dimension-size-250);
  --spectrum-alias-ui-icon-alert-size-300: var(--spectrum-global-dimension-size-275);
  --spectrum-alias-ui-icon-triplegripper-size-100-height: var(--spectrum-global-dimension-size-100);
  --spectrum-alias-ui-icon-doublegripper-size-100-width: var(--spectrum-global-dimension-size-200);
  --spectrum-alias-ui-icon-singlegripper-size-100-width: var(--spectrum-global-dimension-size-300);
  --spectrum-alias-ui-icon-cornertriangle-size-75: var(--spectrum-global-dimension-size-65);
  --spectrum-alias-ui-icon-cornertriangle-size-200: var(--spectrum-global-dimension-size-75);
  --spectrum-alias-ui-icon-asterisk-size-75: var(--spectrum-global-dimension-static-size-100);
  --spectrum-alias-ui-icon-asterisk-size-100: var(--spectrum-global-dimension-size-100);
  --spectrum-alias-item-control-gap-s: var(--spectrum-global-dimension-size-115);
  --spectrum-alias-item-control-gap-m: var(--spectrum-global-dimension-size-125);
  --spectrum-alias-item-control-gap-l: var(--spectrum-global-dimension-size-130);
  --spectrum-alias-item-control-gap-xl: var(--spectrum-global-dimension-size-160);
  --spectrum-alias-item-workflow-icon-gap-s: var(--spectrum-global-dimension-size-85);
  --spectrum-alias-item-workflow-icon-gap-m: var(--spectrum-global-dimension-size-100);
  --spectrum-alias-item-workflow-icon-gap-l: var(--spectrum-global-dimension-size-115);
  --spectrum-alias-item-workflow-icon-gap-xl: var(--spectrum-global-dimension-size-125);
  --spectrum-alias-item-mark-gap-s: var(--spectrum-global-dimension-size-85);
  --spectrum-alias-item-mark-gap-m: var(--spectrum-global-dimension-size-100);
  --spectrum-alias-item-mark-gap-l: var(--spectrum-global-dimension-size-115);
  --spectrum-alias-item-mark-gap-xl: var(--spectrum-global-dimension-size-125);
  --spectrum-alias-item-ui-icon-gap-s: var(--spectrum-global-dimension-size-85);
  --spectrum-alias-item-ui-icon-gap-m: var(--spectrum-global-dimension-size-100);
  --spectrum-alias-item-ui-icon-gap-l: var(--spectrum-global-dimension-size-115);
  --spectrum-alias-item-ui-icon-gap-xl: var(--spectrum-global-dimension-size-125);
  --spectrum-alias-item-clearbutton-gap-s: var(--spectrum-global-dimension-size-50);
  --spectrum-alias-item-clearbutton-gap-m: var(--spectrum-global-dimension-size-85);
  --spectrum-alias-item-clearbutton-gap-l: var(--spectrum-global-dimension-size-125);
  --spectrum-alias-item-clearbutton-gap-xl: var(--spectrum-global-dimension-size-150);
  --spectrum-alias-heading-xxxl-text-size: var(--spectrum-global-dimension-font-size-1300);
  --spectrum-alias-heading-han-xxxl-text-size: var(--spectrum-global-dimension-font-size-1300);
  --spectrum-alias-heading-han-xxxl-margin-top: var(--spectrum-global-dimension-font-size-1200);
  --spectrum-alias-heading-xxxl-margin-top: var(--spectrum-global-dimension-font-size-1200);
  --spectrum-alias-heading-xxl-text-size: var(--spectrum-global-dimension-font-size-1100);
  --spectrum-alias-heading-xxl-margin-top: var(--spectrum-global-dimension-font-size-900);
  --spectrum-alias-heading-han-xxl-text-size: var(--spectrum-global-dimension-font-size-900);
  --spectrum-alias-heading-han-xxl-margin-top: var(--spectrum-global-dimension-font-size-800);
  --spectrum-alias-heading-xl-text-size: var(--spectrum-global-dimension-font-size-900);
  --spectrum-alias-heading-xl-margin-top: var(--spectrum-global-dimension-font-size-800);
  --spectrum-alias-heading-han-xl-text-size: var(--spectrum-global-dimension-font-size-800);
  --spectrum-alias-heading-han-xl-margin-top: var(--spectrum-global-dimension-font-size-700);
  --spectrum-alias-heading-l-text-size: var(--spectrum-global-dimension-font-size-700);
  --spectrum-alias-heading-l-margin-top: var(--spectrum-global-dimension-font-size-600);
  --spectrum-alias-heading-han-l-text-size: var(--spectrum-global-dimension-font-size-600);
  --spectrum-alias-heading-han-l-margin-top: var(--spectrum-global-dimension-font-size-500);
  --spectrum-alias-heading-m-text-size: var(--spectrum-global-dimension-font-size-500);
  --spectrum-alias-heading-m-margin-top: var(--spectrum-global-dimension-font-size-400);
  --spectrum-alias-heading-han-m-text-size: var(--spectrum-global-dimension-font-size-400);
  --spectrum-alias-heading-han-m-margin-top: var(--spectrum-global-dimension-font-size-300);
  --spectrum-alias-heading-s-text-size: var(--spectrum-global-dimension-font-size-300);
  --spectrum-alias-heading-s-margin-top: var(--spectrum-global-dimension-font-size-200);
  --spectrum-alias-heading-xs-text-size: var(--spectrum-global-dimension-font-size-200);
  --spectrum-alias-heading-xs-margin-top: var(--spectrum-global-dimension-font-size-100);
  --spectrum-alias-heading-xxs-text-size: var(--spectrum-global-dimension-font-size-100);
  --spectrum-alias-heading-xxs-margin-top: var(--spectrum-global-dimension-font-size-75);
  --spectrum-alias-avatar-size-50: var(--spectrum-global-dimension-size-200);
  --spectrum-alias-avatar-size-75: var(--spectrum-global-dimension-size-225);
  --spectrum-alias-avatar-size-200: var(--spectrum-global-dimension-size-275);
  --spectrum-alias-avatar-size-300: var(--spectrum-global-dimension-size-325);
  --spectrum-alias-avatar-size-500: var(--spectrum-global-dimension-size-400);
  --spectrum-alias-avatar-size-700: var(--spectrum-global-dimension-size-500);
}

.spectrum--darkest,
.spectrum--dark,
.spectrum--light,
.spectrum--lightest {
  /* spectrum-colorAliases.css */
  --spectrum-alias-background-color-default: var(--spectrum-global-color-gray-100);
  --spectrum-alias-background-color-disabled: var(--spectrum-global-color-gray-200);
  --spectrum-alias-background-color-transparent: transparent;
  --spectrum-alias-background-color-over-background-down: rgba(255,255,255,0.2);
  --spectrum-alias-background-color-quickactions-overlay: rgba(0,0,0,0.2);
  --spectrum-alias-placeholder-text-color: var(--spectrum-global-color-gray-800);
  --spectrum-alias-placeholder-text-color-hover: var(--spectrum-global-color-gray-900);
  --spectrum-alias-placeholder-text-color-down: var(--spectrum-global-color-gray-900);
  --spectrum-alias-placeholder-text-color-selected: var(--spectrum-global-color-gray-800);
  --spectrum-alias-label-text-color: var(--spectrum-global-color-gray-700);
  --spectrum-alias-text-color: var(--spectrum-global-color-gray-800);
  --spectrum-alias-text-color-hover: var(--spectrum-global-color-gray-900);
  --spectrum-alias-text-color-down: var(--spectrum-global-color-gray-900);
  --spectrum-alias-text-color-key-focus: var(--spectrum-global-color-blue-600);
  --spectrum-alias-text-color-mouse-focus: var(--spectrum-global-color-blue-600);
  --spectrum-alias-text-color-disabled: var(--spectrum-global-color-gray-500);
  --spectrum-alias-text-color-invalid: var(--spectrum-global-color-red-500);
  --spectrum-alias-text-color-selected: var(--spectrum-global-color-blue-600);
  --spectrum-alias-text-color-selected-neutral: var(--spectrum-global-color-gray-900);
  --spectrum-alias-text-color-over-background: var(--spectrum-global-color-static-white);
  --spectrum-alias-text-color-over-background-disabled: rgba(255,255,255,0.2);
  --spectrum-alias-heading-text-color: var(--spectrum-global-color-gray-900);
  --spectrum-alias-border-color: var(--spectrum-global-color-gray-400);
  --spectrum-alias-border-color-hover: var(--spectrum-global-color-gray-500);
  --spectrum-alias-border-color-down: var(--spectrum-global-color-gray-500);
  --spectrum-alias-border-color-focus: var(--spectrum-global-color-blue-400);
  --spectrum-alias-border-color-mouse-focus: var(--spectrum-global-color-blue-500);
  --spectrum-alias-border-color-disabled: var(--spectrum-global-color-gray-200);
  --spectrum-alias-border-color-extralight: var(--spectrum-global-color-gray-100);
  --spectrum-alias-border-color-light: var(--spectrum-global-color-gray-200);
  --spectrum-alias-border-color-mid: var(--spectrum-global-color-gray-300);
  --spectrum-alias-border-color-dark: var(--spectrum-global-color-gray-400);
  --spectrum-alias-border-color-darker-default: var(--spectrum-global-color-gray-600);
  --spectrum-alias-border-color-darker-hover: var(--spectrum-global-color-gray-900);
  --spectrum-alias-border-color-darker-down: var(--spectrum-global-color-gray-900);
  --spectrum-alias-border-color-transparent: transparent;
  --spectrum-alias-border-color-translucent-dark: rgba(0,0,0,0.05);
  --spectrum-alias-border-color-translucent-darker: rgba(0,0,0,0.1);
  --spectrum-alias-focus-color: var(--spectrum-global-color-blue-400);
  --spectrum-alias-focus-ring-color: var(--spectrum-alias-focus-color);
  --spectrum-alias-track-color-default: var(--spectrum-global-color-gray-300);
  --spectrum-alias-track-color-disabled: var(--spectrum-global-color-gray-300);
  --spectrum-alias-track-color-over-background: rgba(255,255,255,0.2);
  --spectrum-alias-icon-color: var(--spectrum-global-color-gray-700);
  --spectrum-alias-icon-color-over-background: var(--spectrum-global-color-static-white);
  --spectrum-alias-icon-color-hover: var(--spectrum-global-color-gray-900);
  --spectrum-alias-icon-color-down: var(--spectrum-global-color-gray-900);
  --spectrum-alias-icon-color-focus: var(--spectrum-global-color-gray-900);
  --spectrum-alias-icon-color-disabled: var(--spectrum-global-color-gray-400);
  --spectrum-alias-icon-color-over-background-disabled: rgba(255,255,255,0.2);
  --spectrum-alias-icon-color-selected-neutral: var(--spectrum-global-color-gray-900);
  --spectrum-alias-icon-color-selected: var(--spectrum-global-color-blue-500);
  --spectrum-alias-icon-color-selected-hover: var(--spectrum-global-color-blue-600);
  --spectrum-alias-icon-color-selected-down: var(--spectrum-global-color-blue-700);
  --spectrum-alias-icon-color-selected-focus: var(--spectrum-global-color-blue-600);
  --spectrum-alias-image-opacity-disabled: var(--spectrum-global-color-opacity-30);
  --spectrum-alias-toolbar-background-color: var(--spectrum-global-color-gray-100);
  --spectrum-alias-colorhandle-outer-border-color: rgba(0,0,0,0.42);
  --spectrum-alias-code-highlight-color-default: var(--spectrum-global-color-gray-800);
  --spectrum-alias-code-highlight-color-background: var(--spectrum-global-color-gray-75);
  --spectrum-alias-code-highlight-color-keyword: var(--spectrum-global-color-fuchsia-600);
  --spectrum-alias-code-highlight-color-section: var(--spectrum-global-color-red-600);
  --spectrum-alias-code-highlight-color-literal: var(--spectrum-global-color-blue-600);
  --spectrum-alias-code-highlight-color-attribute: var(--spectrum-global-color-seafoam-600);
  --spectrum-alias-code-highlight-color-class: var(--spectrum-global-color-magenta-600);
  --spectrum-alias-code-highlight-color-variable: var(--spectrum-global-color-purple-600);
  --spectrum-alias-code-highlight-color-title: var(--spectrum-global-color-indigo-600);
  --spectrum-alias-code-highlight-color-string: var(--spectrum-global-color-fuchsia-600);
  --spectrum-alias-code-highlight-color-function: var(--spectrum-global-color-blue-600);
  --spectrum-alias-code-highlight-color-comment: var(--spectrum-global-color-gray-700);
  --spectrum-alias-categorical-color-1: var(--spectrum-global-color-static-seafoam-200);
  --spectrum-alias-categorical-color-2: var(--spectrum-global-color-static-indigo-700);
  --spectrum-alias-categorical-color-3: var(--spectrum-global-color-static-orange-500);
  --spectrum-alias-categorical-color-4: var(--spectrum-global-color-static-magenta-500);
  --spectrum-alias-categorical-color-5: var(--spectrum-global-color-static-indigo-200);
  --spectrum-alias-categorical-color-6: var(--spectrum-global-color-static-celery-200);
  --spectrum-alias-categorical-color-7: var(--spectrum-global-color-static-blue-500);
  --spectrum-alias-categorical-color-8: var(--spectrum-global-color-static-purple-800);
  --spectrum-alias-categorical-color-9: var(--spectrum-global-color-static-yellow-500);
  --spectrum-alias-categorical-color-10: var(--spectrum-global-color-static-orange-700);
  --spectrum-alias-categorical-color-11: var(--spectrum-global-color-static-green-600);
  --spectrum-alias-categorical-color-12: var(--spectrum-global-color-static-chartreuse-300);
  --spectrum-alias-categorical-color-13: var(--spectrum-global-color-static-blue-200);
  --spectrum-alias-categorical-color-14: var(--spectrum-global-color-static-fuchsia-500);
  --spectrum-alias-categorical-color-15: var(--spectrum-global-color-static-magenta-200);
  --spectrum-alias-categorical-color-16: var(--spectrum-global-color-static-yellow-200);
}
.spectrum--medium {
  --spectrum-global-dimension-scale-factor: 1;
  --spectrum-global-dimension-size-0: 0px;
  --spectrum-global-dimension-size-10: 1px;
  --spectrum-global-dimension-size-25: 2px;
  --spectrum-global-dimension-size-40: 3px;
  --spectrum-global-dimension-size-50: 4px;
  --spectrum-global-dimension-size-65: 5px;
  --spectrum-global-dimension-size-75: 6px;
  --spectrum-global-dimension-size-85: 7px;
  --spectrum-global-dimension-size-100: 8px;
  --spectrum-global-dimension-size-115: 9px;
  --spectrum-global-dimension-size-125: 10px;
  --spectrum-global-dimension-size-130: 11px;
  --spectrum-global-dimension-size-150: 12px;
  --spectrum-global-dimension-size-160: 13px;
  --spectrum-global-dimension-size-175: 14px;
  --spectrum-global-dimension-size-185: 15px;
  --spectrum-global-dimension-size-200: 16px;
  --spectrum-global-dimension-size-225: 18px;
  --spectrum-global-dimension-size-250: 20px;
  --spectrum-global-dimension-size-275: 22px;
  --spectrum-global-dimension-size-300: 24px;
  --spectrum-global-dimension-size-325: 26px;
  --spectrum-global-dimension-size-350: 28px;
  --spectrum-global-dimension-size-400: 32px;
  --spectrum-global-dimension-size-450: 36px;
  --spectrum-global-dimension-size-500: 40px;
  --spectrum-global-dimension-size-550: 44px;
  --spectrum-global-dimension-size-600: 48px;
  --spectrum-global-dimension-size-650: 52px;
  --spectrum-global-dimension-size-675: 54px;
  --spectrum-global-dimension-size-700: 56px;
  --spectrum-global-dimension-size-750: 60px;
  --spectrum-global-dimension-size-800: 64px;
  --spectrum-global-dimension-size-900: 72px;
  --spectrum-global-dimension-size-1000: 80px;
  --spectrum-global-dimension-size-1125: 90px;
  --spectrum-global-dimension-size-1200: 96px;
  --spectrum-global-dimension-size-1250: 100px;
  --spectrum-global-dimension-size-1600: 128px;
  --spectrum-global-dimension-size-1700: 136px;
  --spectrum-global-dimension-size-1800: 144px;
  --spectrum-global-dimension-size-2000: 160px;
  --spectrum-global-dimension-size-2400: 192px;
  --spectrum-global-dimension-size-2500: 200px;
  --spectrum-global-dimension-size-3000: 240px;
  --spectrum-global-dimension-size-3400: 272px;
  --spectrum-global-dimension-size-3600: 288px;
  --spectrum-global-dimension-size-4600: 368px;
  --spectrum-global-dimension-size-5000: 400px;
  --spectrum-global-dimension-size-6000: 480px;
  --spectrum-global-dimension-font-size-25: 10px;
  --spectrum-global-dimension-font-size-50: 11px;
  --spectrum-global-dimension-font-size-75: 12px;
  --spectrum-global-dimension-font-size-100: 14px;
  --spectrum-global-dimension-font-size-150: 15px;
  --spectrum-global-dimension-font-size-200: 16px;
  --spectrum-global-dimension-font-size-300: 18px;
  --spectrum-global-dimension-font-size-400: 20px;
  --spectrum-global-dimension-font-size-500: 22px;
  --spectrum-global-dimension-font-size-600: 25px;
  --spectrum-global-dimension-font-size-700: 28px;
  --spectrum-global-dimension-font-size-800: 32px;
  --spectrum-global-dimension-font-size-900: 36px;
  --spectrum-global-dimension-font-size-1000: 40px;
  --spectrum-global-dimension-font-size-1100: 45px;
  --spectrum-global-dimension-font-size-1200: 50px;
  --spectrum-global-dimension-font-size-1300: 60px;
  --spectrum-alias-focus-ring-radius-default: var(--spectrum-global-dimension-static-size-100);
  --spectrum-alias-item-text-padding-top-l: var(--spectrum-global-dimension-size-115);
  --spectrum-alias-item-text-padding-bottom-s: var(--spectrum-global-dimension-static-size-65);
  --spectrum-alias-item-mark-padding-top-m: var(--spectrum-global-dimension-static-size-75);
  --spectrum-alias-item-mark-padding-bottom-m: var(--spectrum-global-dimension-static-size-75);
  --spectrum-alias-item-workflow-padding-left-m: var(--spectrum-global-dimension-size-125);
  --spectrum-alias-item-rounded-workflow-padding-left-m: var(--spectrum-global-dimension-size-175);
  --spectrum-alias-item-rounded-workflow-padding-left-xl: 21px;
  --spectrum-alias-item-mark-padding-left-m: var(--spectrum-global-dimension-size-125);
  --spectrum-alias-item-control-1-size-l: var(--spectrum-global-dimension-size-125);
  --spectrum-alias-item-control-1-size-xl: var(--spectrum-global-dimension-size-125);
  --spectrum-alias-item-control-2-size-s: var(--spectrum-global-dimension-size-150);
  --spectrum-alias-item-control-3-height-s: var(--spectrum-global-dimension-size-150);
  --spectrum-alias-item-control-3-width-s: 23px;
  --spectrum-alias-item-control-3-width-m: var(--spectrum-global-dimension-static-size-325);
  --spectrum-alias-item-control-3-width-l: 29px;
  --spectrum-alias-item-control-3-width-xl: 33px;
  --spectrum-alias-item-mark-size-m: var(--spectrum-global-dimension-size-250);
  --spectrum-alias-workflow-icon-size-l: var(--spectrum-global-dimension-static-size-250);
  --spectrum-alias-ui-icon-chevron-size-75: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-chevron-size-100: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-chevron-size-200: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-chevron-size-300: var(--spectrum-global-dimension-static-size-175);
  --spectrum-alias-ui-icon-chevron-size-400: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-chevron-size-500: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-checkmark-size-50: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-checkmark-size-75: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-checkmark-size-100: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-checkmark-size-200: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-checkmark-size-300: var(--spectrum-global-dimension-static-size-175);
  --spectrum-alias-ui-icon-checkmark-size-400: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-checkmark-size-500: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-checkmark-size-600: var(--spectrum-global-dimension-static-size-225);
  --spectrum-alias-ui-icon-dash-size-50: var(--spectrum-global-dimension-static-size-100);
  --spectrum-alias-ui-icon-dash-size-75: var(--spectrum-global-dimension-static-size-100);
  --spectrum-alias-ui-icon-dash-size-100: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-dash-size-200: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-dash-size-300: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-dash-size-400: var(--spectrum-global-dimension-static-size-175);
  --spectrum-alias-ui-icon-dash-size-500: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-dash-size-600: var(--spectrum-global-dimension-static-size-225);
  --spectrum-alias-ui-icon-cross-size-75: var(--spectrum-global-dimension-static-size-100);
  --spectrum-alias-ui-icon-cross-size-100: var(--spectrum-global-dimension-static-size-100);
  --spectrum-alias-ui-icon-cross-size-200: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-cross-size-300: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-cross-size-400: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-cross-size-500: var(--spectrum-global-dimension-static-size-175);
  --spectrum-alias-ui-icon-cross-size-600: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-arrow-size-75: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-arrow-size-100: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-arrow-size-200: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-arrow-size-300: var(--spectrum-global-dimension-static-size-175);
  --spectrum-alias-ui-icon-arrow-size-400: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-arrow-size-500: var(--spectrum-global-dimension-static-size-225);
  --spectrum-alias-ui-icon-arrow-size-600: var(--spectrum-global-dimension-static-size-250);
  --spectrum-alias-ui-icon-triplegripper-size-100-width: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-doublegripper-size-100-height: var(--spectrum-global-dimension-static-size-50);
  --spectrum-alias-ui-icon-singlegripper-size-100-height: var(--spectrum-global-dimension-static-size-25);
  --spectrum-alias-ui-icon-cornertriangle-size-100: var(--spectrum-global-dimension-static-size-65);
  --spectrum-alias-ui-icon-cornertriangle-size-300: var(--spectrum-global-dimension-static-size-85);
  --spectrum-alias-ui-icon-asterisk-size-200: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-asterisk-size-300: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-avatar-size-100: var(--spectrum-global-dimension-size-250);
  --spectrum-alias-avatar-size-400: var(--spectrum-global-dimension-size-350);
  --spectrum-alias-avatar-size-600: var(--spectrum-global-dimension-size-450);
  --spectrum-actionbutton-l-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-quiet-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-quiet-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-quiet-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-quiet-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-quiet-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-quiet-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-quiet-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-quiet-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-quiet-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-quiet-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-quiet-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-quiet-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-quiet-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-quiet-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-quiet-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-quiet-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-quiet-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-quiet-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-quiet-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-quiet-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-quiet-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-quiet-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-quiet-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-quiet-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-quiet-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-quiet-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-quiet-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-quiet-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-quiet-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-quiet-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-quiet-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-quiet-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-quiet-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-quiet-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-quiet-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-quiet-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-quiet-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-quiet-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-quiet-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-quiet-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-quiet-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-quiet-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-quiet-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-quiet-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-quiet-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-quiet-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-quiet-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-quiet-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-actionbutton-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-breadcrumb-compact-item-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-breadcrumb-compact-button-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-breadcrumb-item-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-breadcrumb-button-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-breadcrumb-multiline-item-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-breadcrumb-multiline-button-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-m-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-cta-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-m-textonly-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-cta-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-cta-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-m-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-over-background-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-m-textonly-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-over-background-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-over-background-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-m-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-quiet-over-background-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-m-textonly-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-quiet-over-background-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-over-background-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-m-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-primary-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-m-textonly-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-primary-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-primary-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-m-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-quiet-primary-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-m-textonly-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-quiet-primary-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-primary-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-m-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-quiet-secondary-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-m-textonly-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-quiet-secondary-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-secondary-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-m-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-secondary-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-m-textonly-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-secondary-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-secondary-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-m-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-quiet-warning-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-m-textonly-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-quiet-warning-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-quiet-warning-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-m-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-warning-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-m-textonly-min-width: var(--spectrum-global-dimension-size-900);
  --spectrum-button-warning-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-button-warning-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-checkbox-l-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-checkbox-m-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-checkbox-s-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-checkbox-xl-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-checkbox-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-checkbox-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-checkbox-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-checkbox-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-colorloupe-colorhandle-gap: var(--spectrum-global-dimension-static-size-125);
  --spectrum-colorslider-touch-hit-y: var(--spectrum-global-dimension-size-150);
  --spectrum-colorslider-vertical-touch-hit-x: var(--spectrum-global-dimension-size-150);
  --spectrum-colorwheel-min-size: var(--spectrum-global-dimension-size-2400);
  --spectrum-colorwheel-touch-hit-outer: var(--spectrum-global-dimension-size-150);
  --spectrum-colorwheel-touch-hit-inner: var(--spectrum-global-dimension-size-150);
  --spectrum-cyclebutton-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-cyclebutton-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-dialog-confirm-max-width: var(--spectrum-global-dimension-static-size-6000);
  --spectrum-dialog-confirm-title-text-size: var(--spectrum-global-dimension-font-size-300);
  --spectrum-dialog-confirm-description-text-size: var(--spectrum-global-dimension-font-size-100);
  --spectrum-dialog-confirm-padding: var(--spectrum-global-dimension-static-size-500);
  --spectrum-dialog-confirm-description-margin-bottom: var(--spectrum-global-dimension-static-size-600);
  --spectrum-dialog-destructive-max-width: var(--spectrum-global-dimension-static-size-6000);
  --spectrum-dialog-destructive-title-text-size: var(--spectrum-global-dimension-font-size-300);
  --spectrum-dialog-destructive-description-text-size: var(--spectrum-global-dimension-font-size-100);
  --spectrum-dialog-destructive-padding: var(--spectrum-global-dimension-static-size-500);
  --spectrum-dialog-destructive-description-margin-bottom: var(--spectrum-global-dimension-static-size-600);
  --spectrum-dialog-error-max-width: var(--spectrum-global-dimension-static-size-6000);
  --spectrum-dialog-error-title-text-size: var(--spectrum-global-dimension-font-size-300);
  --spectrum-dialog-error-description-text-size: var(--spectrum-global-dimension-font-size-100);
  --spectrum-dialog-error-padding: var(--spectrum-global-dimension-static-size-500);
  --spectrum-dialog-error-description-margin-bottom: var(--spectrum-global-dimension-static-size-600);
  --spectrum-dialog-info-max-width: var(--spectrum-global-dimension-static-size-6000);
  --spectrum-dialog-info-title-text-size: var(--spectrum-global-dimension-font-size-300);
  --spectrum-dialog-info-description-text-size: var(--spectrum-global-dimension-font-size-100);
  --spectrum-dialog-info-padding: var(--spectrum-global-dimension-static-size-500);
  --spectrum-dialog-info-description-margin-bottom: var(--spectrum-global-dimension-static-size-600);
  --spectrum-icon-arrow-down-small-height: var(--spectrum-global-dimension-size-125);
  --spectrum-icon-arrow-left-medium-height: var(--spectrum-global-dimension-size-125);
  --spectrum-icon-checkmark-medium-width: var(--spectrum-global-dimension-size-150);
  --spectrum-icon-checkmark-medium-height: var(--spectrum-global-dimension-size-150);
  --spectrum-icon-checkmark-small-width: var(--spectrum-global-dimension-size-125);
  --spectrum-icon-checkmark-small-height: var(--spectrum-global-dimension-size-125);
  --spectrum-icon-chevron-down-medium-width: var(--spectrum-global-dimension-size-125);
  --spectrum-icon-chevron-left-large-width: var(--spectrum-global-dimension-size-150);
  --spectrum-icon-chevron-left-medium-height: var(--spectrum-global-dimension-size-125);
  --spectrum-icon-chevron-right-large-width: var(--spectrum-global-dimension-size-150);
  --spectrum-icon-chevron-right-medium-height: var(--spectrum-global-dimension-size-125);
  --spectrum-icon-cross-large-width: var(--spectrum-global-dimension-size-150);
  --spectrum-icon-cross-large-height: var(--spectrum-global-dimension-size-150);
  --spectrum-icon-dash-small-width: var(--spectrum-global-dimension-size-125);
  --spectrum-icon-dash-small-height: var(--spectrum-global-dimension-size-125);
  --spectrum-icon-skip-left-width: 9px;
  --spectrum-icon-skip-left-height: var(--spectrum-global-dimension-size-125);
  --spectrum-icon-skip-right-width: 9px;
  --spectrum-icon-skip-right-height: var(--spectrum-global-dimension-size-125);
  --spectrum-icon-triplegripper-width: var(--spectrum-global-dimension-size-125);
  --spectrum-meter-negative-m-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-meter-negative-m-over-background-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-meter-negative-s-border-radius: var(--spectrum-global-dimension-static-size-25);
  --spectrum-meter-negative-s-over-background-border-radius: var(--spectrum-global-dimension-static-size-25);
  --spectrum-meter-negative-xl-border-radius: var(--spectrum-global-dimension-static-size-65);
  --spectrum-meter-negative-xl-over-background-border-radius: var(--spectrum-global-dimension-static-size-65);
  --spectrum-meter-notice-m-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-meter-notice-m-over-background-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-meter-notice-s-border-radius: var(--spectrum-global-dimension-static-size-25);
  --spectrum-meter-notice-s-over-background-border-radius: var(--spectrum-global-dimension-static-size-25);
  --spectrum-meter-notice-xl-border-radius: var(--spectrum-global-dimension-static-size-65);
  --spectrum-meter-notice-xl-over-background-border-radius: var(--spectrum-global-dimension-static-size-65);
  --spectrum-meter-positive-m-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-meter-positive-m-over-background-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-meter-positive-s-over-background-border-radius: var(--spectrum-global-dimension-static-size-25);
  --spectrum-meter-positive-xl-border-radius: var(--spectrum-global-dimension-static-size-65);
  --spectrum-meter-positive-xl-over-background-border-radius: var(--spectrum-global-dimension-static-size-65);
  --spectrum-pagination-page-button-line-height: 26px;
  --spectrum-panel-l-header-height: var(--spectrum-global-dimension-size-600);
  --spectrum-panel-l-collapsible-header-height: var(--spectrum-global-dimension-size-600);
  --spectrum-panel-s-header-height: var(--spectrum-global-dimension-size-600);
  --spectrum-panel-s-collapsible-header-height: var(--spectrum-global-dimension-size-600);
  --spectrum-picker-quiet-l-touch-hit-y: var(--spectrum-global-dimension-static-size-400);
  --spectrum-picker-quiet-l-min-width: var(--spectrum-global-dimension-size-250);
  --spectrum-picker-quiet-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-400);
  --spectrum-picker-quiet-l-textonly-min-width: var(--spectrum-global-dimension-size-250);
  --spectrum-picker-quiet-m-touch-hit-y: var(--spectrum-global-dimension-static-size-400);
  --spectrum-picker-quiet-m-min-width: var(--spectrum-global-dimension-size-225);
  --spectrum-picker-quiet-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-400);
  --spectrum-picker-quiet-m-textonly-min-width: var(--spectrum-global-dimension-size-225);
  --spectrum-picker-quiet-s-touch-hit-y: var(--spectrum-global-dimension-static-size-400);
  --spectrum-picker-quiet-s-min-width: var(--spectrum-global-dimension-size-200);
  --spectrum-picker-quiet-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-400);
  --spectrum-picker-quiet-s-textonly-min-width: var(--spectrum-global-dimension-size-200);
  --spectrum-picker-quiet-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-400);
  --spectrum-picker-quiet-xl-min-width: var(--spectrum-global-dimension-size-275);
  --spectrum-picker-quiet-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-400);
  --spectrum-picker-quiet-xl-textonly-min-width: var(--spectrum-global-dimension-size-275);
  --spectrum-picker-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-picker-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-progressbar-m-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-progressbar-m-over-background-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-progressbar-s-border-radius: var(--spectrum-global-dimension-static-size-25);
  --spectrum-progressbar-s-over-background-border-radius: var(--spectrum-global-dimension-static-size-25);
  --spectrum-progressbar-xl-border-radius: var(--spectrum-global-dimension-static-size-65);
  --spectrum-progressbar-xl-over-background-border-radius: var(--spectrum-global-dimension-static-size-65);
  --spectrum-progressbar-m-indeterminate-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-progressbar-m-indeterminate-over-background-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-progressbar-s-indeterminate-border-radius: var(--spectrum-global-dimension-static-size-25);
  --spectrum-progressbar-s-indeterminate-over-background-border-radius: var(--spectrum-global-dimension-static-size-25);
  --spectrum-progressbar-xl-indeterminate-border-radius: var(--spectrum-global-dimension-static-size-65);
  --spectrum-progressbar-xl-indeterminate-over-background-border-radius: var(--spectrum-global-dimension-static-size-65);
  --spectrum-progresscircle-medium-border-size: 3px;
  --spectrum-progresscircle-medium-over-background-border-size: 3px;
  --spectrum-progresscircle-small-border-size: var(--spectrum-global-dimension-static-size-25);
  --spectrum-progresscircle-small-indeterminate-border-size: var(--spectrum-global-dimension-static-size-25);
  --spectrum-progresscircle-small-over-background-border-size: var(--spectrum-global-dimension-static-size-25);
  --spectrum-progresscircle-medium-indeterminate-border-size: 3px;
  --spectrum-radio-l-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-radio-m-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-radio-s-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-radio-xl-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-radio-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-radio-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-radio-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-radio-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-rating-icon-width: 24px;
  --spectrum-rating-indicator-width: 16px;
  --spectrum-rating-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-rating-emphasized-icon-width: 24px;
  --spectrum-rating-emphasized-indicator-width: 16px;
  --spectrum-rating-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-quiet-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-quiet-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-quiet-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-quiet-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-quiet-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-quiet-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-quiet-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-quiet-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-search-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-sidenav-item-touch-hit-bottom: var(--spectrum-global-dimension-static-size-25);
  --spectrum-sidenav-multilevel-item-touch-hit-bottom: var(--spectrum-global-dimension-static-size-25);
  --spectrum-slider-l-track-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-slider-l-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-l-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-m-track-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-slider-m-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-m-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-s-track-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-slider-s-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-s-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-xl-track-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-slider-xl-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-xl-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-editable-track-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-slider-editable-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-editable-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-tick-l-track-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-slider-tick-l-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-tick-l-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-tick-m-track-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-slider-tick-m-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-tick-m-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-tick-s-track-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-slider-tick-s-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-tick-s-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-tick-xl-track-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-slider-tick-xl-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-200);
  --spectrum-slider-tick-xl-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-200);
  --spectrum-switch-l-emphasized-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-l-emphasized-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-l-emphasized-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-l-emphasized-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-l-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-switch-l-emphasized-handle-border-radius: 7px;
  --spectrum-switch-m-emphasized-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-m-emphasized-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-m-emphasized-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-m-emphasized-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-m-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-switch-m-emphasized-handle-border-radius: 7px;
  --spectrum-switch-s-emphasized-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-s-emphasized-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-s-emphasized-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-s-emphasized-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-s-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-switch-s-emphasized-handle-border-radius: 7px;
  --spectrum-switch-xl-emphasized-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-xl-emphasized-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-xl-emphasized-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-xl-emphasized-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-xl-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-switch-xl-emphasized-handle-border-radius: 7px;
  --spectrum-switch-l-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-l-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-l-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-l-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-switch-l-handle-border-radius: 7px;
  --spectrum-switch-m-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-m-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-m-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-m-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-switch-m-handle-border-radius: 7px;
  --spectrum-switch-s-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-s-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-s-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-s-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-switch-s-handle-border-radius: 7px;
  --spectrum-switch-xl-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-xl-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-xl-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-xl-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-130);
  --spectrum-switch-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-switch-xl-handle-border-radius: 7px;
  --spectrum-tabs-quiet-s-compact-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-s-compact-emphasized-margin-left: -7px;
  --spectrum-tabs-quiet-s-compact-emphasized-margin-right: -7px;
  --spectrum-tabs-quiet-s-compact-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-s-compact-margin-left: -7px;
  --spectrum-tabs-quiet-s-compact-margin-right: -7px;
  --spectrum-tabs-quiet-s-compact-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-s-compact-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-s-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-s-emphasized-margin-left: -7px;
  --spectrum-tabs-quiet-s-emphasized-margin-right: -7px;
  --spectrum-tabs-quiet-s-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-s-margin-left: -7px;
  --spectrum-tabs-quiet-s-margin-right: -7px;
  --spectrum-tabs-quiet-s-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-s-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-m-compact-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-m-compact-emphasized-margin-left: -8px;
  --spectrum-tabs-quiet-m-compact-emphasized-margin-right: -8px;
  --spectrum-tabs-quiet-m-compact-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-m-compact-margin-left: -8px;
  --spectrum-tabs-quiet-m-compact-margin-right: -8px;
  --spectrum-tabs-quiet-m-compact-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-m-compact-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-m-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-m-emphasized-margin-left: -8px;
  --spectrum-tabs-quiet-m-emphasized-margin-right: -8px;
  --spectrum-tabs-quiet-m-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-m-margin-left: -8px;
  --spectrum-tabs-quiet-m-margin-right: -8px;
  --spectrum-tabs-quiet-m-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-m-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-l-compact-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-l-compact-emphasized-margin-left: -9px;
  --spectrum-tabs-quiet-l-compact-emphasized-margin-right: -9px;
  --spectrum-tabs-quiet-l-compact-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-l-compact-margin-left: -9px;
  --spectrum-tabs-quiet-l-compact-margin-right: -9px;
  --spectrum-tabs-quiet-l-compact-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-l-compact-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-l-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-l-emphasized-margin-left: -9px;
  --spectrum-tabs-quiet-l-emphasized-margin-right: -9px;
  --spectrum-tabs-quiet-l-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-l-margin-left: -9px;
  --spectrum-tabs-quiet-l-margin-right: -9px;
  --spectrum-tabs-quiet-l-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-l-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-xl-compact-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-xl-compact-emphasized-margin-left: -10px;
  --spectrum-tabs-quiet-xl-compact-emphasized-margin-right: -10px;
  --spectrum-tabs-quiet-xl-compact-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-xl-compact-margin-left: -10px;
  --spectrum-tabs-quiet-xl-compact-margin-right: -10px;
  --spectrum-tabs-quiet-xl-compact-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-xl-compact-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-xl-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-xl-emphasized-margin-left: -10px;
  --spectrum-tabs-quiet-xl-emphasized-margin-right: -10px;
  --spectrum-tabs-quiet-xl-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-xl-margin-left: -10px;
  --spectrum-tabs-quiet-xl-margin-right: -10px;
  --spectrum-tabs-quiet-xl-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-quiet-xl-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-s-compact-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-s-compact-emphasized-margin-left: -7px;
  --spectrum-tabs-s-compact-emphasized-margin-right: -7px;
  --spectrum-tabs-s-compact-focus-ring-border-radius: 5px;
  --spectrum-tabs-s-compact-margin-left: -7px;
  --spectrum-tabs-s-compact-margin-right: -7px;
  --spectrum-tabs-s-compact-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-s-compact-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-s-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-s-emphasized-margin-left: -7px;
  --spectrum-tabs-s-emphasized-margin-right: -7px;
  --spectrum-tabs-s-focus-ring-border-radius: 5px;
  --spectrum-tabs-s-margin-left: -7px;
  --spectrum-tabs-s-margin-right: -7px;
  --spectrum-tabs-s-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-s-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-m-compact-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-m-compact-emphasized-margin-left: -8px;
  --spectrum-tabs-m-compact-emphasized-margin-right: -8px;
  --spectrum-tabs-m-compact-focus-ring-border-radius: 5px;
  --spectrum-tabs-m-compact-margin-left: -8px;
  --spectrum-tabs-m-compact-margin-right: -8px;
  --spectrum-tabs-m-compact-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-m-compact-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-m-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-m-emphasized-margin-left: -8px;
  --spectrum-tabs-m-emphasized-margin-right: -8px;
  --spectrum-tabs-m-focus-ring-border-radius: 5px;
  --spectrum-tabs-m-margin-left: -8px;
  --spectrum-tabs-m-margin-right: -8px;
  --spectrum-tabs-m-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-m-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-l-compact-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-l-compact-emphasized-margin-left: -9px;
  --spectrum-tabs-l-compact-emphasized-margin-right: -9px;
  --spectrum-tabs-l-compact-focus-ring-border-radius: 5px;
  --spectrum-tabs-l-compact-margin-left: -9px;
  --spectrum-tabs-l-compact-margin-right: -9px;
  --spectrum-tabs-l-compact-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-l-compact-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-l-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-l-emphasized-margin-left: -9px;
  --spectrum-tabs-l-emphasized-margin-right: -9px;
  --spectrum-tabs-l-focus-ring-border-radius: 5px;
  --spectrum-tabs-l-margin-left: -9px;
  --spectrum-tabs-l-margin-right: -9px;
  --spectrum-tabs-l-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-l-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-xl-compact-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-xl-compact-emphasized-margin-left: -10px;
  --spectrum-tabs-xl-compact-emphasized-margin-right: -10px;
  --spectrum-tabs-xl-compact-focus-ring-border-radius: 5px;
  --spectrum-tabs-xl-compact-margin-left: -10px;
  --spectrum-tabs-xl-compact-margin-right: -10px;
  --spectrum-tabs-xl-compact-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-xl-compact-vertical-focus-ring-border-radius: 5px;
  --spectrum-tabs-xl-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-xl-emphasized-margin-left: -10px;
  --spectrum-tabs-xl-emphasized-margin-right: -10px;
  --spectrum-tabs-xl-focus-ring-border-radius: 5px;
  --spectrum-tabs-xl-margin-left: -10px;
  --spectrum-tabs-xl-margin-right: -10px;
  --spectrum-tabs-xl-vertical-emphasized-focus-ring-border-radius: 5px;
  --spectrum-tabs-xl-vertical-focus-ring-border-radius: 5px;
  --spectrum-textarea-quiet-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-quiet-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-quiet-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-quiet-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-quiet-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-quiet-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-quiet-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-quiet-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textarea-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-quiet-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-quiet-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-quiet-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-quiet-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-quiet-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-quiet-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-quiet-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-quiet-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-l-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-l-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-m-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-m-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-s-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-s-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-100);
  --spectrum-textfield-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-100);
  --spectrum-tooltip-info-padding-bottom: 5px;
  --spectrum-tooltip-negative-padding-bottom: 5px;
  --spectrum-tooltip-padding-bottom: 5px;
  --spectrum-tooltip-positive-padding-bottom: 5px;
}
.spectrum--large {
  --spectrum-global-dimension-scale-factor: 1.25;
  --spectrum-global-dimension-size-0: 0px;
  --spectrum-global-dimension-size-10: 1px;
  --spectrum-global-dimension-size-25: 2px;
  --spectrum-global-dimension-size-40: 4px;
  --spectrum-global-dimension-size-50: 5px;
  --spectrum-global-dimension-size-65: 6px;
  --spectrum-global-dimension-size-75: 8px;
  --spectrum-global-dimension-size-85: 9px;
  --spectrum-global-dimension-size-100: 10px;
  --spectrum-global-dimension-size-115: 11px;
  --spectrum-global-dimension-size-125: 13px;
  --spectrum-global-dimension-size-130: 14px;
  --spectrum-global-dimension-size-150: 15px;
  --spectrum-global-dimension-size-160: 16px;
  --spectrum-global-dimension-size-175: 18px;
  --spectrum-global-dimension-size-185: 19px;
  --spectrum-global-dimension-size-200: 20px;
  --spectrum-global-dimension-size-225: 22px;
  --spectrum-global-dimension-size-250: 25px;
  --spectrum-global-dimension-size-275: 28px;
  --spectrum-global-dimension-size-300: 30px;
  --spectrum-global-dimension-size-325: 32px;
  --spectrum-global-dimension-size-350: 35px;
  --spectrum-global-dimension-size-400: 40px;
  --spectrum-global-dimension-size-450: 45px;
  --spectrum-global-dimension-size-500: 50px;
  --spectrum-global-dimension-size-550: 56px;
  --spectrum-global-dimension-size-600: 60px;
  --spectrum-global-dimension-size-650: 65px;
  --spectrum-global-dimension-size-675: 68px;
  --spectrum-global-dimension-size-700: 70px;
  --spectrum-global-dimension-size-750: 75px;
  --spectrum-global-dimension-size-800: 80px;
  --spectrum-global-dimension-size-900: 90px;
  --spectrum-global-dimension-size-1000: 100px;
  --spectrum-global-dimension-size-1125: 112px;
  --spectrum-global-dimension-size-1200: 120px;
  --spectrum-global-dimension-size-1250: 125px;
  --spectrum-global-dimension-size-1600: 160px;
  --spectrum-global-dimension-size-1700: 170px;
  --spectrum-global-dimension-size-1800: 180px;
  --spectrum-global-dimension-size-2000: 200px;
  --spectrum-global-dimension-size-2400: 240px;
  --spectrum-global-dimension-size-2500: 250px;
  --spectrum-global-dimension-size-3000: 300px;
  --spectrum-global-dimension-size-3400: 340px;
  --spectrum-global-dimension-size-3600: 360px;
  --spectrum-global-dimension-size-4600: 460px;
  --spectrum-global-dimension-size-5000: 500px;
  --spectrum-global-dimension-size-6000: 600px;
  --spectrum-global-dimension-font-size-25: 12px;
  --spectrum-global-dimension-font-size-50: 13px;
  --spectrum-global-dimension-font-size-75: 15px;
  --spectrum-global-dimension-font-size-100: 17px;
  --spectrum-global-dimension-font-size-150: 18px;
  --spectrum-global-dimension-font-size-200: 19px;
  --spectrum-global-dimension-font-size-300: 22px;
  --spectrum-global-dimension-font-size-400: 24px;
  --spectrum-global-dimension-font-size-500: 27px;
  --spectrum-global-dimension-font-size-600: 31px;
  --spectrum-global-dimension-font-size-700: 34px;
  --spectrum-global-dimension-font-size-800: 39px;
  --spectrum-global-dimension-font-size-900: 44px;
  --spectrum-global-dimension-font-size-1000: 49px;
  --spectrum-global-dimension-font-size-1100: 55px;
  --spectrum-global-dimension-font-size-1200: 62px;
  --spectrum-global-dimension-font-size-1300: 70px;
  --spectrum-alias-focus-ring-radius-default: var(--spectrum-global-dimension-static-size-115);
  --spectrum-alias-item-text-padding-top-l: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-item-text-padding-bottom-s: var(--spectrum-global-dimension-static-size-85);
  --spectrum-alias-item-mark-padding-top-m: var(--spectrum-global-dimension-static-size-85);
  --spectrum-alias-item-mark-padding-bottom-m: var(--spectrum-global-dimension-static-size-85);
  --spectrum-alias-item-workflow-padding-left-m: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-item-rounded-workflow-padding-left-m: 17px;
  --spectrum-alias-item-rounded-workflow-padding-left-xl: 27px;
  --spectrum-alias-item-mark-padding-left-m: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-item-control-1-size-l: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-item-control-1-size-xl: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-item-control-2-size-s: var(--spectrum-global-dimension-size-160);
  --spectrum-alias-item-control-3-height-s: var(--spectrum-global-dimension-size-160);
  --spectrum-alias-item-control-3-width-s: var(--spectrum-global-dimension-size-325);
  --spectrum-alias-item-control-3-width-m: var(--spectrum-global-dimension-static-size-450);
  --spectrum-alias-item-control-3-width-l: 41px;
  --spectrum-alias-item-control-3-width-xl: 46px;
  --spectrum-alias-item-mark-size-m: var(--spectrum-global-dimension-static-size-325);
  --spectrum-alias-workflow-icon-size-l: var(--spectrum-global-dimension-static-size-300);
  --spectrum-alias-ui-icon-chevron-size-75: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-chevron-size-100: var(--spectrum-global-dimension-static-size-175);
  --spectrum-alias-ui-icon-chevron-size-200: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-chevron-size-300: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-chevron-size-400: var(--spectrum-global-dimension-static-size-225);
  --spectrum-alias-ui-icon-chevron-size-500: var(--spectrum-global-dimension-static-size-250);
  --spectrum-alias-ui-icon-checkmark-size-50: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-checkmark-size-75: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-checkmark-size-100: var(--spectrum-global-dimension-static-size-175);
  --spectrum-alias-ui-icon-checkmark-size-200: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-checkmark-size-300: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-checkmark-size-400: var(--spectrum-global-dimension-static-size-225);
  --spectrum-alias-ui-icon-checkmark-size-500: var(--spectrum-global-dimension-static-size-250);
  --spectrum-alias-ui-icon-checkmark-size-600: var(--spectrum-global-dimension-static-size-300);
  --spectrum-alias-ui-icon-dash-size-50: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-dash-size-75: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-dash-size-100: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-dash-size-200: var(--spectrum-global-dimension-static-size-175);
  --spectrum-alias-ui-icon-dash-size-300: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-dash-size-400: var(--spectrum-global-dimension-static-size-225);
  --spectrum-alias-ui-icon-dash-size-500: var(--spectrum-global-dimension-static-size-250);
  --spectrum-alias-ui-icon-dash-size-600: var(--spectrum-global-dimension-static-size-275);
  --spectrum-alias-ui-icon-cross-size-75: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-cross-size-100: var(--spectrum-global-dimension-static-size-125);
  --spectrum-alias-ui-icon-cross-size-200: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-cross-size-300: var(--spectrum-global-dimension-static-size-175);
  --spectrum-alias-ui-icon-cross-size-400: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-cross-size-500: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-cross-size-600: var(--spectrum-global-dimension-static-size-225);
  --spectrum-alias-ui-icon-arrow-size-75: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-arrow-size-100: var(--spectrum-global-dimension-static-size-175);
  --spectrum-alias-ui-icon-arrow-size-200: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-arrow-size-300: var(--spectrum-global-dimension-static-size-200);
  --spectrum-alias-ui-icon-arrow-size-400: var(--spectrum-global-dimension-static-size-225);
  --spectrum-alias-ui-icon-arrow-size-500: var(--spectrum-global-dimension-static-size-275);
  --spectrum-alias-ui-icon-arrow-size-600: var(--spectrum-global-dimension-static-size-300);
  --spectrum-alias-ui-icon-triplegripper-size-100-width: var(--spectrum-global-dimension-static-size-175);
  --spectrum-alias-ui-icon-doublegripper-size-100-height: var(--spectrum-global-dimension-static-size-75);
  --spectrum-alias-ui-icon-singlegripper-size-100-height: var(--spectrum-global-dimension-static-size-50);
  --spectrum-alias-ui-icon-cornertriangle-size-100: var(--spectrum-global-dimension-static-size-85);
  --spectrum-alias-ui-icon-cornertriangle-size-300: var(--spectrum-global-dimension-static-size-100);
  --spectrum-alias-ui-icon-asterisk-size-200: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-ui-icon-asterisk-size-300: var(--spectrum-global-dimension-static-size-150);
  --spectrum-alias-avatar-size-100: 26px;
  --spectrum-alias-avatar-size-400: 36px;
  --spectrum-alias-avatar-size-600: 46px;
  --spectrum-actionbutton-l-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-quiet-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-quiet-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-quiet-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-quiet-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-quiet-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-quiet-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-quiet-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-quiet-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-quiet-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-quiet-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-quiet-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-quiet-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-quiet-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-quiet-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-quiet-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-quiet-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-quiet-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-quiet-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-quiet-emphasized-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-quiet-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-quiet-emphasized-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-quiet-emphasized-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-quiet-emphasized-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-quiet-emphasized-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-quiet-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-quiet-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-quiet-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-quiet-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-quiet-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-quiet-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-quiet-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-quiet-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-quiet-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-quiet-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-quiet-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-quiet-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-quiet-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-quiet-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-quiet-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-quiet-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-quiet-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-quiet-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-quiet-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-quiet-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-quiet-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-quiet-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-quiet-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-quiet-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-icononly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-icononly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-actionbutton-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-breadcrumb-compact-item-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-breadcrumb-compact-button-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-breadcrumb-item-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-breadcrumb-button-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-breadcrumb-multiline-item-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-breadcrumb-multiline-button-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-m-min-width: 90px;
  --spectrum-button-cta-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-m-textonly-min-width: 90px;
  --spectrum-button-cta-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-cta-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-m-min-width: 90px;
  --spectrum-button-over-background-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-m-textonly-min-width: 90px;
  --spectrum-button-over-background-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-over-background-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-m-min-width: 90px;
  --spectrum-button-quiet-over-background-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-m-textonly-min-width: 90px;
  --spectrum-button-quiet-over-background-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-over-background-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-m-min-width: 90px;
  --spectrum-button-primary-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-m-textonly-min-width: 90px;
  --spectrum-button-primary-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-primary-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-m-min-width: 90px;
  --spectrum-button-quiet-primary-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-m-textonly-min-width: 90px;
  --spectrum-button-quiet-primary-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-primary-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-m-min-width: 90px;
  --spectrum-button-quiet-secondary-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-m-textonly-min-width: 90px;
  --spectrum-button-quiet-secondary-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-secondary-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-m-min-width: 90px;
  --spectrum-button-secondary-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-m-textonly-min-width: 90px;
  --spectrum-button-secondary-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-secondary-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-m-min-width: 90px;
  --spectrum-button-quiet-warning-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-m-textonly-min-width: 90px;
  --spectrum-button-quiet-warning-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-quiet-warning-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-m-min-width: 90px;
  --spectrum-button-warning-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-m-textonly-min-width: 90px;
  --spectrum-button-warning-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-button-warning-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-checkbox-l-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-checkbox-m-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-checkbox-s-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-checkbox-xl-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-checkbox-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-checkbox-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-checkbox-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-checkbox-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-colorloupe-colorhandle-gap: var(--spectrum-global-dimension-static-size-100);
  --spectrum-colorslider-touch-hit-y: var(--spectrum-global-dimension-size-85);
  --spectrum-colorslider-vertical-touch-hit-x: var(--spectrum-global-dimension-size-85);
  --spectrum-colorwheel-min-size: var(--spectrum-global-dimension-static-size-2600);
  --spectrum-colorwheel-touch-hit-outer: var(--spectrum-global-dimension-size-85);
  --spectrum-colorwheel-touch-hit-inner: var(--spectrum-global-dimension-size-85);
  --spectrum-cyclebutton-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-cyclebutton-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-dialog-confirm-max-width: var(--spectrum-global-dimension-static-size-5000);
  --spectrum-dialog-confirm-title-text-size: var(--spectrum-global-dimension-font-size-200);
  --spectrum-dialog-confirm-description-text-size: var(--spectrum-global-dimension-font-size-75);
  --spectrum-dialog-confirm-padding: var(--spectrum-global-dimension-static-size-300);
  --spectrum-dialog-confirm-description-margin-bottom: var(--spectrum-global-dimension-static-size-500);
  --spectrum-dialog-destructive-max-width: var(--spectrum-global-dimension-static-size-5000);
  --spectrum-dialog-destructive-title-text-size: var(--spectrum-global-dimension-font-size-200);
  --spectrum-dialog-destructive-description-text-size: var(--spectrum-global-dimension-font-size-75);
  --spectrum-dialog-destructive-padding: var(--spectrum-global-dimension-static-size-300);
  --spectrum-dialog-destructive-description-margin-bottom: var(--spectrum-global-dimension-static-size-500);
  --spectrum-dialog-error-max-width: var(--spectrum-global-dimension-static-size-5000);
  --spectrum-dialog-error-title-text-size: var(--spectrum-global-dimension-font-size-200);
  --spectrum-dialog-error-description-text-size: var(--spectrum-global-dimension-font-size-75);
  --spectrum-dialog-error-padding: var(--spectrum-global-dimension-static-size-300);
  --spectrum-dialog-error-description-margin-bottom: var(--spectrum-global-dimension-static-size-500);
  --spectrum-dialog-info-max-width: var(--spectrum-global-dimension-static-size-5000);
  --spectrum-dialog-info-title-text-size: var(--spectrum-global-dimension-font-size-200);
  --spectrum-dialog-info-description-text-size: var(--spectrum-global-dimension-font-size-75);
  --spectrum-dialog-info-padding: var(--spectrum-global-dimension-static-size-300);
  --spectrum-dialog-info-description-margin-bottom: var(--spectrum-global-dimension-static-size-500);
  --spectrum-icon-arrow-down-small-height: 12px;
  --spectrum-icon-arrow-left-medium-height: 12px;
  --spectrum-icon-checkmark-medium-width: 16px;
  --spectrum-icon-checkmark-medium-height: 16px;
  --spectrum-icon-checkmark-small-width: 12px;
  --spectrum-icon-checkmark-small-height: 12px;
  --spectrum-icon-chevron-down-medium-width: 12px;
  --spectrum-icon-chevron-left-large-width: 16px;
  --spectrum-icon-chevron-left-medium-height: 12px;
  --spectrum-icon-chevron-right-large-width: 16px;
  --spectrum-icon-chevron-right-medium-height: 12px;
  --spectrum-icon-cross-large-width: 16px;
  --spectrum-icon-cross-large-height: 16px;
  --spectrum-icon-dash-small-width: 12px;
  --spectrum-icon-dash-small-height: 12px;
  --spectrum-icon-skip-left-width: 10px;
  --spectrum-icon-skip-left-height: 12px;
  --spectrum-icon-skip-right-width: 10px;
  --spectrum-icon-skip-right-height: 12px;
  --spectrum-icon-triplegripper-width: 12px;
  --spectrum-meter-negative-m-border-radius: var(--spectrum-global-dimension-static-size-50);
  --spectrum-meter-negative-m-over-background-border-radius: var(--spectrum-global-dimension-static-size-50);
  --spectrum-meter-negative-s-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-meter-negative-s-over-background-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-meter-negative-xl-border-radius: var(--spectrum-global-dimension-static-size-75);
  --spectrum-meter-negative-xl-over-background-border-radius: var(--spectrum-global-dimension-static-size-75);
  --spectrum-meter-notice-m-border-radius: var(--spectrum-global-dimension-static-size-50);
  --spectrum-meter-notice-m-over-background-border-radius: var(--spectrum-global-dimension-static-size-50);
  --spectrum-meter-notice-s-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-meter-notice-s-over-background-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-meter-notice-xl-border-radius: var(--spectrum-global-dimension-static-size-75);
  --spectrum-meter-notice-xl-over-background-border-radius: var(--spectrum-global-dimension-static-size-75);
  --spectrum-meter-positive-m-border-radius: var(--spectrum-global-dimension-static-size-50);
  --spectrum-meter-positive-m-over-background-border-radius: var(--spectrum-global-dimension-static-size-50);
  --spectrum-meter-positive-s-over-background-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-meter-positive-xl-border-radius: var(--spectrum-global-dimension-static-size-75);
  --spectrum-meter-positive-xl-over-background-border-radius: var(--spectrum-global-dimension-static-size-75);
  --spectrum-pagination-page-button-line-height: 32px;
  --spectrum-panel-l-header-height: var(--spectrum-global-dimension-size-550);
  --spectrum-panel-l-collapsible-header-height: var(--spectrum-global-dimension-size-550);
  --spectrum-panel-s-header-height: var(--spectrum-global-dimension-size-550);
  --spectrum-panel-s-collapsible-header-height: var(--spectrum-global-dimension-size-550);
  --spectrum-picker-quiet-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-quiet-l-min-width: var(--spectrum-global-dimension-size-225);
  --spectrum-picker-quiet-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-quiet-l-textonly-min-width: var(--spectrum-global-dimension-size-225);
  --spectrum-picker-quiet-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-quiet-m-min-width: var(--spectrum-global-dimension-size-200);
  --spectrum-picker-quiet-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-quiet-m-textonly-min-width: var(--spectrum-global-dimension-size-200);
  --spectrum-picker-quiet-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-quiet-s-min-width: var(--spectrum-global-dimension-size-175);
  --spectrum-picker-quiet-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-quiet-s-textonly-min-width: var(--spectrum-global-dimension-size-175);
  --spectrum-picker-quiet-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-quiet-xl-min-width: var(--spectrum-global-dimension-size-250);
  --spectrum-picker-quiet-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-quiet-xl-textonly-min-width: var(--spectrum-global-dimension-size-250);
  --spectrum-picker-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-l-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-l-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-m-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-m-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-s-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-s-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-xl-textonly-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-picker-xl-textonly-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-progressbar-m-border-radius: var(--spectrum-global-dimension-static-size-50);
  --spectrum-progressbar-m-over-background-border-radius: var(--spectrum-global-dimension-static-size-50);
  --spectrum-progressbar-s-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-progressbar-s-over-background-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-progressbar-xl-border-radius: var(--spectrum-global-dimension-static-size-75);
  --spectrum-progressbar-xl-over-background-border-radius: var(--spectrum-global-dimension-static-size-75);
  --spectrum-progressbar-m-indeterminate-border-radius: var(--spectrum-global-dimension-static-size-50);
  --spectrum-progressbar-m-indeterminate-over-background-border-radius: var(--spectrum-global-dimension-static-size-50);
  --spectrum-progressbar-s-indeterminate-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-progressbar-s-indeterminate-over-background-border-radius: var(--spectrum-global-dimension-static-size-40);
  --spectrum-progressbar-xl-indeterminate-border-radius: var(--spectrum-global-dimension-static-size-75);
  --spectrum-progressbar-xl-indeterminate-over-background-border-radius: var(--spectrum-global-dimension-static-size-75);
  --spectrum-progresscircle-medium-border-size: var(--spectrum-global-dimension-static-size-50);
  --spectrum-progresscircle-medium-over-background-border-size: var(--spectrum-global-dimension-static-size-50);
  --spectrum-progresscircle-small-border-size: 3px;
  --spectrum-progresscircle-small-indeterminate-border-size: 3px;
  --spectrum-progresscircle-small-over-background-border-size: 3px;
  --spectrum-progresscircle-medium-indeterminate-border-size: var(--spectrum-global-dimension-static-size-50);
  --spectrum-radio-l-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-radio-m-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-radio-s-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-radio-xl-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-radio-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-radio-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-radio-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-radio-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-rating-icon-width: 30px;
  --spectrum-rating-indicator-width: 20px;
  --spectrum-rating-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-rating-emphasized-icon-width: 30px;
  --spectrum-rating-emphasized-indicator-width: 20px;
  --spectrum-rating-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-quiet-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-quiet-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-quiet-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-quiet-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-quiet-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-quiet-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-quiet-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-quiet-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-search-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-sidenav-item-touch-hit-bottom: 3px;
  --spectrum-sidenav-multilevel-item-touch-hit-bottom: 3px;
  --spectrum-slider-l-track-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-slider-l-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-l-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-m-track-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-slider-m-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-m-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-s-track-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-slider-s-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-s-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-xl-track-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-slider-xl-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-xl-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-editable-track-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-slider-editable-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-editable-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-tick-l-track-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-slider-tick-l-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-tick-l-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-tick-m-track-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-slider-tick-m-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-tick-m-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-tick-s-track-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-slider-tick-s-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-tick-s-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-tick-xl-track-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-slider-tick-xl-handle-touch-hit-x: var(--spectrum-global-dimension-static-size-175);
  --spectrum-slider-tick-xl-handle-touch-hit-y: var(--spectrum-global-dimension-static-size-175);
  --spectrum-switch-l-emphasized-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-l-emphasized-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-l-emphasized-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-l-emphasized-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-l-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-switch-l-emphasized-handle-border-radius: 9px;
  --spectrum-switch-m-emphasized-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-m-emphasized-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-m-emphasized-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-m-emphasized-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-m-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-switch-m-emphasized-handle-border-radius: 9px;
  --spectrum-switch-s-emphasized-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-s-emphasized-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-s-emphasized-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-s-emphasized-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-s-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-switch-s-emphasized-handle-border-radius: 9px;
  --spectrum-switch-xl-emphasized-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-xl-emphasized-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-xl-emphasized-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-xl-emphasized-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-xl-emphasized-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-switch-xl-emphasized-handle-border-radius: 9px;
  --spectrum-switch-l-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-l-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-l-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-l-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-switch-l-handle-border-radius: 9px;
  --spectrum-switch-m-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-m-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-m-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-m-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-switch-m-handle-border-radius: 9px;
  --spectrum-switch-s-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-s-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-s-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-s-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-switch-s-handle-border-radius: 9px;
  --spectrum-switch-xl-focus-ring-border-radius-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-xl-focus-ring-border-radius-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-xl-focus-ring-border-radius-error-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-xl-focus-ring-border-radius-error-selected-key-focus: var(--spectrum-global-dimension-static-size-160);
  --spectrum-switch-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-switch-xl-handle-border-radius: 9px;
  --spectrum-tabs-quiet-s-compact-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-s-compact-emphasized-margin-left: -9px;
  --spectrum-tabs-quiet-s-compact-emphasized-margin-right: -9px;
  --spectrum-tabs-quiet-s-compact-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-s-compact-margin-left: -9px;
  --spectrum-tabs-quiet-s-compact-margin-right: -9px;
  --spectrum-tabs-quiet-s-compact-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-s-compact-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-s-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-s-emphasized-margin-left: -9px;
  --spectrum-tabs-quiet-s-emphasized-margin-right: -9px;
  --spectrum-tabs-quiet-s-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-s-margin-left: -9px;
  --spectrum-tabs-quiet-s-margin-right: -9px;
  --spectrum-tabs-quiet-s-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-s-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-m-compact-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-m-compact-emphasized-margin-left: -11px;
  --spectrum-tabs-quiet-m-compact-emphasized-margin-right: -11px;
  --spectrum-tabs-quiet-m-compact-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-m-compact-margin-left: -11px;
  --spectrum-tabs-quiet-m-compact-margin-right: -11px;
  --spectrum-tabs-quiet-m-compact-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-m-compact-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-m-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-m-emphasized-margin-left: -11px;
  --spectrum-tabs-quiet-m-emphasized-margin-right: -11px;
  --spectrum-tabs-quiet-m-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-m-margin-left: -11px;
  --spectrum-tabs-quiet-m-margin-right: -11px;
  --spectrum-tabs-quiet-m-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-m-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-l-compact-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-l-compact-emphasized-margin-left: -11px;
  --spectrum-tabs-quiet-l-compact-emphasized-margin-right: -11px;
  --spectrum-tabs-quiet-l-compact-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-l-compact-margin-left: -11px;
  --spectrum-tabs-quiet-l-compact-margin-right: -11px;
  --spectrum-tabs-quiet-l-compact-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-l-compact-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-l-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-l-emphasized-margin-left: -11px;
  --spectrum-tabs-quiet-l-emphasized-margin-right: -11px;
  --spectrum-tabs-quiet-l-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-l-margin-left: -11px;
  --spectrum-tabs-quiet-l-margin-right: -11px;
  --spectrum-tabs-quiet-l-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-l-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-xl-compact-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-xl-compact-emphasized-margin-left: -12px;
  --spectrum-tabs-quiet-xl-compact-emphasized-margin-right: -12px;
  --spectrum-tabs-quiet-xl-compact-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-xl-compact-margin-left: -12px;
  --spectrum-tabs-quiet-xl-compact-margin-right: -12px;
  --spectrum-tabs-quiet-xl-compact-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-xl-compact-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-xl-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-xl-emphasized-margin-left: -12px;
  --spectrum-tabs-quiet-xl-emphasized-margin-right: -12px;
  --spectrum-tabs-quiet-xl-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-xl-margin-left: -12px;
  --spectrum-tabs-quiet-xl-margin-right: -12px;
  --spectrum-tabs-quiet-xl-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-quiet-xl-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-s-compact-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-s-compact-emphasized-margin-left: -9px;
  --spectrum-tabs-s-compact-emphasized-margin-right: -9px;
  --spectrum-tabs-s-compact-focus-ring-border-radius: 6px;
  --spectrum-tabs-s-compact-margin-left: -9px;
  --spectrum-tabs-s-compact-margin-right: -9px;
  --spectrum-tabs-s-compact-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-s-compact-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-s-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-s-emphasized-margin-left: -9px;
  --spectrum-tabs-s-emphasized-margin-right: -9px;
  --spectrum-tabs-s-focus-ring-border-radius: 6px;
  --spectrum-tabs-s-margin-left: -9px;
  --spectrum-tabs-s-margin-right: -9px;
  --spectrum-tabs-s-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-s-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-m-compact-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-m-compact-emphasized-margin-left: -11px;
  --spectrum-tabs-m-compact-emphasized-margin-right: -11px;
  --spectrum-tabs-m-compact-focus-ring-border-radius: 6px;
  --spectrum-tabs-m-compact-margin-left: -11px;
  --spectrum-tabs-m-compact-margin-right: -11px;
  --spectrum-tabs-m-compact-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-m-compact-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-m-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-m-emphasized-margin-left: -11px;
  --spectrum-tabs-m-emphasized-margin-right: -11px;
  --spectrum-tabs-m-focus-ring-border-radius: 6px;
  --spectrum-tabs-m-margin-left: -11px;
  --spectrum-tabs-m-margin-right: -11px;
  --spectrum-tabs-m-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-m-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-l-compact-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-l-compact-emphasized-margin-left: -11px;
  --spectrum-tabs-l-compact-emphasized-margin-right: -11px;
  --spectrum-tabs-l-compact-focus-ring-border-radius: 6px;
  --spectrum-tabs-l-compact-margin-left: -11px;
  --spectrum-tabs-l-compact-margin-right: -11px;
  --spectrum-tabs-l-compact-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-l-compact-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-l-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-l-emphasized-margin-left: -11px;
  --spectrum-tabs-l-emphasized-margin-right: -11px;
  --spectrum-tabs-l-focus-ring-border-radius: 6px;
  --spectrum-tabs-l-margin-left: -11px;
  --spectrum-tabs-l-margin-right: -11px;
  --spectrum-tabs-l-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-l-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-xl-compact-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-xl-compact-emphasized-margin-left: -12px;
  --spectrum-tabs-xl-compact-emphasized-margin-right: -12px;
  --spectrum-tabs-xl-compact-focus-ring-border-radius: 6px;
  --spectrum-tabs-xl-compact-margin-left: -12px;
  --spectrum-tabs-xl-compact-margin-right: -12px;
  --spectrum-tabs-xl-compact-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-xl-compact-vertical-focus-ring-border-radius: 6px;
  --spectrum-tabs-xl-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-xl-emphasized-margin-left: -12px;
  --spectrum-tabs-xl-emphasized-margin-right: -12px;
  --spectrum-tabs-xl-focus-ring-border-radius: 6px;
  --spectrum-tabs-xl-margin-left: -12px;
  --spectrum-tabs-xl-margin-right: -12px;
  --spectrum-tabs-xl-vertical-emphasized-focus-ring-border-radius: 6px;
  --spectrum-tabs-xl-vertical-focus-ring-border-radius: 6px;
  --spectrum-textarea-quiet-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-quiet-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-quiet-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-quiet-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-quiet-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-quiet-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-quiet-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-quiet-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textarea-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-quiet-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-quiet-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-quiet-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-quiet-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-quiet-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-quiet-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-quiet-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-quiet-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-l-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-l-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-m-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-m-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-s-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-s-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-xl-touch-hit-x: var(--spectrum-global-dimension-static-size-50);
  --spectrum-textfield-xl-touch-hit-y: var(--spectrum-global-dimension-static-size-50);
  --spectrum-tooltip-info-padding-bottom: 6px;
  --spectrum-tooltip-negative-padding-bottom: 6px;
  --spectrum-tooltip-padding-bottom: 6px;
  --spectrum-tooltip-positive-padding-bottom: 6px;
}
.spectrum--darkest {
  --spectrum-global-color-status: Verified;
  --spectrum-global-color-version: 5.0.1;
  --spectrum-global-color-celery-400: rgb(61, 167, 78);
  --spectrum-global-color-celery-500: rgb(68, 181, 86);
  --spectrum-global-color-celery-600: rgb(75, 195, 95);
  --spectrum-global-color-celery-700: rgb(81, 210, 103);
  --spectrum-global-color-chartreuse-400: rgb(124, 195, 63);
  --spectrum-global-color-chartreuse-500: rgb(133, 208, 68);
  --spectrum-global-color-chartreuse-600: rgb(142, 222, 73);
  --spectrum-global-color-chartreuse-700: rgb(155, 236, 84);
  --spectrum-global-color-yellow-400: rgb(210, 178, 0);
  --spectrum-global-color-yellow-500: rgb(223, 191, 0);
  --spectrum-global-color-yellow-600: rgb(237, 204, 0);
  --spectrum-global-color-yellow-700: rgb(250, 217, 0);
  --spectrum-global-color-magenta-400: rgb(202, 41, 150);
  --spectrum-global-color-magenta-500: rgb(216, 55, 144);
  --spectrum-global-color-magenta-600: rgb(226, 73, 157);
  --spectrum-global-color-magenta-700: rgb(236, 90, 170);
  --spectrum-global-color-fuchsia-400: rgb(177, 48, 189);
  --spectrum-global-color-fuchsia-500: rgb(192, 56, 204);
  --spectrum-global-color-fuchsia-600: rgb(207, 62, 220);
  --spectrum-global-color-fuchsia-700: rgb(217, 81, 229);
  --spectrum-global-color-purple-400: rgb(134, 76, 204);
  --spectrum-global-color-purple-500: rgb(146, 86, 217);
  --spectrum-global-color-purple-600: rgb(157, 100, 225);
  --spectrum-global-color-purple-700: rgb(168, 115, 223);
  --spectrum-global-color-indigo-400: rgb(92, 92, 224);
  --spectrum-global-color-indigo-500: rgb(103, 103, 236);
  --spectrum-global-color-indigo-600: rgb(117, 117, 241);
  --spectrum-global-color-indigo-700: rgb(130, 130, 246);
  --spectrum-global-color-seafoam-400: rgb(22, 135, 140);
  --spectrum-global-color-seafoam-500: rgb(27, 149, 154);
  --spectrum-global-color-seafoam-600: rgb(32, 163, 168);
  --spectrum-global-color-seafoam-700: rgb(35, 178, 184);
  --spectrum-global-color-red-400: rgb(215, 55, 63);
  --spectrum-global-color-red-500: rgb(227, 72, 80);
  --spectrum-global-color-red-600: rgb(236, 91, 98);
  --spectrum-global-color-red-700: rgb(247, 109, 116);
  --spectrum-global-color-orange-400: rgb(218, 123, 17);
  --spectrum-global-color-orange-500: rgb(230, 134, 25);
  --spectrum-global-color-orange-600: rgb(242, 148, 35);
  --spectrum-global-color-orange-700: rgb(249, 164, 63);
  --spectrum-global-color-green-400: rgb(38, 142, 108);
  --spectrum-global-color-green-500: rgb(45, 157, 120);
  --spectrum-global-color-green-600: rgb(51, 171, 132);
  --spectrum-global-color-green-700: rgb(57, 185, 144);
  --spectrum-global-color-blue-400: rgb(20, 115, 230);
  --spectrum-global-color-blue-500: rgb(38, 128, 235);
  --spectrum-global-color-blue-600: rgb(55, 142, 240);
  --spectrum-global-color-blue-700: rgb(75, 156, 245);
  --spectrum-global-color-gray-50: rgb(8, 8, 8);
  --spectrum-global-color-gray-75: rgb(26, 26, 26);
  --spectrum-global-color-gray-100: rgb(30, 30, 30);
  --spectrum-global-color-gray-200: rgb(44, 44, 44);
  --spectrum-global-color-gray-300: rgb(57, 57, 57);
  --spectrum-global-color-gray-400: rgb(73, 73, 73);
  --spectrum-global-color-gray-500: rgb(92, 92, 92);
  --spectrum-global-color-gray-600: rgb(124, 124, 124);
  --spectrum-global-color-gray-700: rgb(162, 162, 162);
  --spectrum-global-color-gray-800: rgb(200, 200, 200);
  --spectrum-global-color-gray-900: rgb(239, 239, 239);
  --spectrum-alias-background-color-primary: var(--spectrum-global-color-gray-100);
  --spectrum-alias-background-color-secondary: var(--spectrum-global-color-gray-75);
  --spectrum-alias-background-color-tertiary: var(--spectrum-global-color-gray-50);
  --spectrum-alias-background-color-modal-overlay: rgba(0,0,0,0.6);
  --spectrum-alias-dropshadow-color: rgba(0,0,0,0.8);
  --spectrum-alias-background-color-hover-overlay: rgba(239,239,239,0.08);
  --spectrum-alias-highlight-hover: rgba(239,239,239,0.08);
  --spectrum-alias-highlight-active: rgba(239,239,239,0.15);
  --spectrum-alias-highlight-selected: rgba(38,128,235,0.2);
  --spectrum-alias-highlight-selected-hover: rgba(38,128,235,0.3);
  --spectrum-alias-text-highlight-color: rgba(38,128,235,0.3);
  --spectrum-alias-background-color-quickactions: rgba(30,30,30,0.9);
  --spectrum-alias-border-color-selected: var(--spectrum-global-color-blue-600);
  --spectrum-alias-radial-reaction-color-default: rgba(200,200,200,0.6);
  --spectrum-alias-pasteboard-background-color: var(--spectrum-global-color-gray-50);
  --spectrum-alias-appframe-border-color: var(--spectrum-global-color-gray-50);
  --spectrum-alias-appframe-separator-color: var(--spectrum-global-color-gray-50);
  --spectrum-colorarea-border-color: rgba(239,239,239,0.1);
  --spectrum-colorarea-border-color-hover: rgba(239,239,239,0.1);
  --spectrum-colorarea-border-color-down: rgba(239,239,239,0.1);
  --spectrum-colorarea-border-color-key-focus: rgba(239,239,239,0.1);
  --spectrum-colorslider-border-color: rgba(239,239,239,0.1);
  --spectrum-colorslider-border-color-hover: rgba(239,239,239,0.1);
  --spectrum-colorslider-border-color-down: rgba(239,239,239,0.1);
  --spectrum-colorslider-border-color-key-focus: rgba(239,239,239,0.1);
  --spectrum-colorslider-vertical-border-color: rgba(239,239,239,0.1);
  --spectrum-colorslider-vertical-border-color-hover: rgba(239,239,239,0.1);
  --spectrum-colorslider-vertical-border-color-down: rgba(239,239,239,0.1);
  --spectrum-colorslider-vertical-border-color-key-focus: rgba(239,239,239,0.1);
  --spectrum-colorwheel-border-color: rgba(239,239,239,0.1);
  --spectrum-colorwheel-border-color-hover: rgba(239,239,239,0.1);
  --spectrum-colorwheel-border-color-down: rgba(239,239,239,0.1);
  --spectrum-colorwheel-border-color-key-focus: rgba(239,239,239,0.1);
  --spectrum-miller-column-item-background-color-selected: rgba(38,128,235,0.1);
  --spectrum-miller-column-item-background-color-selected-hover: rgba(38,128,235,0.2);
  --spectrum-well-background-color: rgba(200,200,200,0.02);
  --spectrum-well-border-color: rgba(239,239,239,0.05);
}
.spectrum--dark {
  --spectrum-global-color-status: Verified;
  --spectrum-global-color-version: 5.0.1;
  --spectrum-global-color-celery-400: rgb(68, 181, 86);
  --spectrum-global-color-celery-500: rgb(75, 195, 95);
  --spectrum-global-color-celery-600: rgb(81, 210, 103);
  --spectrum-global-color-celery-700: rgb(88, 224, 111);
  --spectrum-global-color-chartreuse-400: rgb(133, 208, 68);
  --spectrum-global-color-chartreuse-500: rgb(142, 222, 73);
  --spectrum-global-color-chartreuse-600: rgb(155, 236, 84);
  --spectrum-global-color-chartreuse-700: rgb(163, 248, 88);
  --spectrum-global-color-yellow-400: rgb(223, 191, 0);
  --spectrum-global-color-yellow-500: rgb(237, 204, 0);
  --spectrum-global-color-yellow-600: rgb(250, 217, 0);
  --spectrum-global-color-yellow-700: rgb(255, 226, 46);
  --spectrum-global-color-magenta-400: rgb(216, 55, 144);
  --spectrum-global-color-magenta-500: rgb(226, 73, 157);
  --spectrum-global-color-magenta-600: rgb(236, 90, 170);
  --spectrum-global-color-magenta-700: rgb(245, 107, 183);
  --spectrum-global-color-fuchsia-400: rgb(192, 56, 204);
  --spectrum-global-color-fuchsia-500: rgb(207, 62, 220);
  --spectrum-global-color-fuchsia-600: rgb(217, 81, 229);
  --spectrum-global-color-fuchsia-700: rgb(227, 102, 239);
  --spectrum-global-color-purple-400: rgb(146, 86, 217);
  --spectrum-global-color-purple-500: rgb(157, 100, 225);
  --spectrum-global-color-purple-600: rgb(168, 115, 233);
  --spectrum-global-color-purple-700: rgb(180, 131, 240);
  --spectrum-global-color-indigo-400: rgb(103, 103, 236);
  --spectrum-global-color-indigo-500: rgb(117, 117, 241);
  --spectrum-global-color-indigo-600: rgb(130, 130, 246);
  --spectrum-global-color-indigo-700: rgb(144, 144, 250);
  --spectrum-global-color-seafoam-400: rgb(27, 149, 154);
  --spectrum-global-color-seafoam-500: rgb(32, 163, 168);
  --spectrum-global-color-seafoam-600: rgb(35, 178, 184);
  --spectrum-global-color-seafoam-700: rgb(38, 192, 199);
  --spectrum-global-color-red-400: rgb(227, 72, 80);
  --spectrum-global-color-red-500: rgb(236, 91, 98);
  --spectrum-global-color-red-600: rgb(247, 109, 116);
  --spectrum-global-color-red-700: rgb(255, 123, 130);
  --spectrum-global-color-orange-400: rgb(230, 134, 25);
  --spectrum-global-color-orange-500: rgb(242, 148, 35);
  --spectrum-global-color-orange-600: rgb(249, 164, 63);
  --spectrum-global-color-orange-700: rgb(255, 181, 91);
  --spectrum-global-color-green-400: rgb(45, 157, 120);
  --spectrum-global-color-green-500: rgb(51, 171, 132);
  --spectrum-global-color-green-600: rgb(57, 185, 144);
  --spectrum-global-color-green-700: rgb(63, 200, 156);
  --spectrum-global-color-blue-400: rgb(38, 128, 235);
  --spectrum-global-color-blue-500: rgb(55, 142, 240);
  --spectrum-global-color-blue-600: rgb(75, 156, 245);
  --spectrum-global-color-blue-700: rgb(90, 169, 250);
  --spectrum-global-color-gray-50: rgb(37, 37, 37);
  --spectrum-global-color-gray-75: rgb(47, 47, 47);
  --spectrum-global-color-gray-100: rgb(50, 50, 50);
  --spectrum-global-color-gray-200: rgb(62, 62, 62);
  --spectrum-global-color-gray-300: rgb(74, 74, 74);
  --spectrum-global-color-gray-400: rgb(90, 90, 90);
  --spectrum-global-color-gray-500: rgb(110, 110, 110);
  --spectrum-global-color-gray-600: rgb(144, 144, 144);
  --spectrum-global-color-gray-700: rgb(185, 185, 185);
  --spectrum-global-color-gray-800: rgb(227, 227, 227);
  --spectrum-global-color-gray-900: rgb(255, 255, 255);
  --spectrum-alias-background-color-primary: var(--spectrum-global-color-gray-100);
  --spectrum-alias-background-color-secondary: var(--spectrum-global-color-gray-75);
  --spectrum-alias-background-color-tertiary: var(--spectrum-global-color-gray-50);
  --spectrum-alias-background-color-modal-overlay: rgba(0,0,0,0.5);
  --spectrum-alias-dropshadow-color: rgba(0,0,0,0.5);
  --spectrum-alias-background-color-hover-overlay: rgba(255,255,255,0.06);
  --spectrum-alias-highlight-hover: rgba(255,255,255,0.07);
  --spectrum-alias-highlight-active: rgba(255,255,255,0.1);
  --spectrum-alias-highlight-selected: rgba(55,142,240,0.15);
  --spectrum-alias-highlight-selected-hover: rgba(55,142,240,0.25);
  --spectrum-alias-text-highlight-color: rgba(55,142,240,0.25);
  --spectrum-alias-background-color-quickactions: rgba(50,50,50,0.9);
  --spectrum-alias-border-color-selected: var(--spectrum-global-color-blue-600);
  --spectrum-alias-radial-reaction-color-default: rgba(227,227,227,0.6);
  --spectrum-alias-pasteboard-background-color: var(--spectrum-global-color-gray-50);
  --spectrum-alias-appframe-border-color: var(--spectrum-global-color-gray-50);
  --spectrum-alias-appframe-separator-color: var(--spectrum-global-color-gray-50);
  --spectrum-miller-column-item-background-color-selected: rgba(55,142,240,0.1);
  --spectrum-miller-column-item-background-color-selected-hover: rgba(55,142,240,0.2);
  --spectrum-well-background-color: rgba(227,227,227,0.02);
  --spectrum-colorarea-border-color: rgba(255,255,255,0.1);
  --spectrum-colorarea-border-color-hover: rgba(255,255,255,0.1);
  --spectrum-colorarea-border-color-down: rgba(255,255,255,0.1);
  --spectrum-colorarea-border-color-key-focus: rgba(255,255,255,0.1);
  --spectrum-colorslider-border-color: rgba(255,255,255,0.1);
  --spectrum-colorslider-border-color-hover: rgba(255,255,255,0.1);
  --spectrum-colorslider-border-color-down: rgba(255,255,255,0.1);
  --spectrum-colorslider-border-color-key-focus: rgba(255,255,255,0.1);
  --spectrum-colorslider-vertical-border-color: rgba(255,255,255,0.1);
  --spectrum-colorslider-vertical-border-color-hover: rgba(255,255,255,0.1);
  --spectrum-colorslider-vertical-border-color-down: rgba(255,255,255,0.1);
  --spectrum-colorslider-vertical-border-color-key-focus: rgba(255,255,255,0.1);
  --spectrum-colorwheel-border-color: rgba(255,255,255,0.1);
  --spectrum-colorwheel-border-color-hover: rgba(255,255,255,0.1);
  --spectrum-colorwheel-border-color-down: rgba(255,255,255,0.1);
  --spectrum-colorwheel-border-color-key-focus: rgba(255,255,255,0.1);
  --spectrum-well-border-color: rgba(255,255,255,0.05);
}
.spectrum--light {
  --spectrum-global-color-status: Verified;
  --spectrum-global-color-version: 5.0.1;
  --spectrum-global-color-celery-400: rgb(68, 181, 86);
  --spectrum-global-color-celery-500: rgb(61, 167, 78);
  --spectrum-global-color-celery-600: rgb(55, 153, 71);
  --spectrum-global-color-celery-700: rgb(49, 139, 64);
  --spectrum-global-color-chartreuse-400: rgb(133, 208, 68);
  --spectrum-global-color-chartreuse-500: rgb(124, 195, 63);
  --spectrum-global-color-chartreuse-600: rgb(115, 181, 58);
  --spectrum-global-color-chartreuse-700: rgb(106, 168, 52);
  --spectrum-global-color-yellow-400: rgb(223, 191, 0);
  --spectrum-global-color-yellow-500: rgb(210, 178, 0);
  --spectrum-global-color-yellow-600: rgb(196, 166, 0);
  --spectrum-global-color-yellow-700: rgb(183, 153, 0);
  --spectrum-global-color-magenta-400: rgb(216, 55, 144);
  --spectrum-global-color-magenta-500: rgb(206, 39, 131);
  --spectrum-global-color-magenta-600: rgb(188, 28, 116);
  --spectrum-global-color-magenta-700: rgb(174, 14, 102);
  --spectrum-global-color-fuchsia-400: rgb(192, 56, 204);
  --spectrum-global-color-fuchsia-500: rgb(177, 48, 189);
  --spectrum-global-color-fuchsia-600: rgb(162, 40, 173);
  --spectrum-global-color-fuchsia-700: rgb(147, 33, 158);
  --spectrum-global-color-purple-400: rgb(146, 86, 217);
  --spectrum-global-color-purple-500: rgb(134, 76, 204);
  --spectrum-global-color-purple-600: rgb(122, 66, 191);
  --spectrum-global-color-purple-700: rgb(111, 56, 177);
  --spectrum-global-color-indigo-400: rgb(103, 103, 236);
  --spectrum-global-color-indigo-500: rgb(92, 92, 224);
  --spectrum-global-color-indigo-600: rgb(81, 81, 211);
  --spectrum-global-color-indigo-700: rgb(70, 70, 198);
  --spectrum-global-color-seafoam-400: rgb(27, 149, 154);
  --spectrum-global-color-seafoam-500: rgb(22, 135, 140);
  --spectrum-global-color-seafoam-600: rgb(15, 121, 125);
  --spectrum-global-color-seafoam-700: rgb(9, 108, 111);
  --spectrum-global-color-red-400: rgb(227, 72, 80);
  --spectrum-global-color-red-500: rgb(215, 55, 63);
  --spectrum-global-color-red-600: rgb(201, 37, 45);
  --spectrum-global-color-red-700: rgb(187, 18, 26);
  --spectrum-global-color-orange-400: rgb(230, 134, 25);
  --spectrum-global-color-orange-500: rgb(218, 123, 17);
  --spectrum-global-color-orange-600: rgb(203, 111, 16);
  --spectrum-global-color-orange-700: rgb(189, 100, 13);
  --spectrum-global-color-green-400: rgb(45, 157, 120);
  --spectrum-global-color-green-500: rgb(38, 142, 108);
  --spectrum-global-color-green-600: rgb(18, 128, 92);
  --spectrum-global-color-green-700: rgb(16, 113, 84);
  --spectrum-global-color-blue-400: rgb(38, 128, 235);
  --spectrum-global-color-blue-500: rgb(20, 115, 230);
  --spectrum-global-color-blue-600: rgb(13, 102, 208);
  --spectrum-global-color-blue-700: rgb(9, 90, 186);
  --spectrum-global-color-gray-50: rgb(255, 255, 255);
  --spectrum-global-color-gray-75: rgb(250, 250, 250);
  --spectrum-global-color-gray-100: rgb(245, 245, 245);
  --spectrum-global-color-gray-200: rgb(234, 234, 234);
  --spectrum-global-color-gray-300: rgb(225, 225, 225);
  --spectrum-global-color-gray-400: rgb(202, 202, 202);
  --spectrum-global-color-gray-500: rgb(179, 179, 179);
  --spectrum-global-color-gray-600: rgb(142, 142, 142);
  --spectrum-global-color-gray-700: rgb(110, 110, 110);
  --spectrum-global-color-gray-800: rgb(75, 75, 75);
  --spectrum-global-color-gray-900: rgb(44, 44, 44);
  --spectrum-alias-background-color-primary: var(--spectrum-global-color-gray-50);
  --spectrum-alias-background-color-secondary: var(--spectrum-global-color-gray-100);
  --spectrum-alias-background-color-tertiary: var(--spectrum-global-color-gray-300);
  --spectrum-alias-background-color-modal-overlay: rgba(0,0,0,0.4);
  --spectrum-alias-dropshadow-color: rgba(0,0,0,0.15);
  --spectrum-alias-background-color-hover-overlay: rgba(44,44,44,0.04);
  --spectrum-alias-highlight-hover: rgba(44,44,44,0.06);
  --spectrum-alias-highlight-active: rgba(44,44,44,0.1);
  --spectrum-alias-highlight-selected: rgba(20,115,230,0.1);
  --spectrum-alias-highlight-selected-hover: rgba(20,115,230,0.2);
  --spectrum-alias-text-highlight-color: rgba(20,115,230,0.2);
  --spectrum-alias-background-color-quickactions: rgba(245,245,245,0.9);
  --spectrum-alias-border-color-selected: var(--spectrum-global-color-blue-500);
  --spectrum-alias-radial-reaction-color-default: rgba(75,75,75,0.6);
  --spectrum-alias-pasteboard-background-color: var(--spectrum-global-color-gray-300);
  --spectrum-alias-appframe-border-color: var(--spectrum-global-color-gray-300);
  --spectrum-alias-appframe-separator-color: var(--spectrum-global-color-gray-300);
  --spectrum-colorarea-border-color: rgba(44,44,44,0.1);
  --spectrum-colorarea-border-color-hover: rgba(44,44,44,0.1);
  --spectrum-colorarea-border-color-down: rgba(44,44,44,0.1);
  --spectrum-colorarea-border-color-key-focus: rgba(44,44,44,0.1);
  --spectrum-colorslider-border-color: rgba(44,44,44,0.1);
  --spectrum-colorslider-border-color-hover: rgba(44,44,44,0.1);
  --spectrum-colorslider-border-color-down: rgba(44,44,44,0.1);
  --spectrum-colorslider-border-color-key-focus: rgba(44,44,44,0.1);
  --spectrum-colorslider-vertical-border-color: rgba(44,44,44,0.1);
  --spectrum-colorslider-vertical-border-color-hover: rgba(44,44,44,0.1);
  --spectrum-colorslider-vertical-border-color-down: rgba(44,44,44,0.1);
  --spectrum-colorslider-vertical-border-color-key-focus: rgba(44,44,44,0.1);
  --spectrum-colorwheel-border-color: rgba(44,44,44,0.1);
  --spectrum-colorwheel-border-color-hover: rgba(44,44,44,0.1);
  --spectrum-colorwheel-border-color-down: rgba(44,44,44,0.1);
  --spectrum-colorwheel-border-color-key-focus: rgba(44,44,44,0.1);
  --spectrum-miller-column-item-background-color-selected: rgba(20,115,230,0.1);
  --spectrum-miller-column-item-background-color-selected-hover: rgba(20,115,230,0.2);
  --spectrum-well-background-color: rgba(75,75,75,0.02);
  --spectrum-well-border-color: rgba(44,44,44,0.05);
}
.spectrum--lightest {
  --spectrum-global-color-status: Verified;
  --spectrum-global-color-version: 5.0.1;
  --spectrum-global-color-celery-400: rgb(75, 195, 95);
  --spectrum-global-color-celery-500: rgb(68, 181, 86);
  --spectrum-global-color-celery-600: rgb(61, 167, 78);
  --spectrum-global-color-celery-700: rgb(55, 153, 71);
  --spectrum-global-color-chartreuse-400: rgb(142, 222, 73);
  --spectrum-global-color-chartreuse-500: rgb(133, 208, 68);
  --spectrum-global-color-chartreuse-600: rgb(124, 195, 63);
  --spectrum-global-color-chartreuse-700: rgb(115, 181, 58);
  --spectrum-global-color-yellow-400: rgb(237, 204, 0);
  --spectrum-global-color-yellow-500: rgb(223, 191, 0);
  --spectrum-global-color-yellow-600: rgb(210, 178, 0);
  --spectrum-global-color-yellow-700: rgb(196, 166, 0);
  --spectrum-global-color-magenta-400: rgb(226, 73, 157);
  --spectrum-global-color-magenta-500: rgb(216, 55, 144);
  --spectrum-global-color-magenta-600: rgb(202, 41, 130);
  --spectrum-global-color-magenta-700: rgb(188, 28, 116);
  --spectrum-global-color-fuchsia-400: rgb(207, 62, 220);
  --spectrum-global-color-fuchsia-500: rgb(192, 56, 204);
  --spectrum-global-color-fuchsia-600: rgb(177, 48, 189);
  --spectrum-global-color-fuchsia-700: rgb(162, 40, 173);
  --spectrum-global-color-purple-400: rgb(157, 100, 225);
  --spectrum-global-color-purple-500: rgb(146, 86, 217);
  --spectrum-global-color-purple-600: rgb(134, 76, 204);
  --spectrum-global-color-purple-700: rgb(122, 66, 191);
  --spectrum-global-color-indigo-400: rgb(117, 117, 241);
  --spectrum-global-color-indigo-500: rgb(103, 103, 236);
  --spectrum-global-color-indigo-600: rgb(92, 92, 224);
  --spectrum-global-color-indigo-700: rgb(81, 81, 211);
  --spectrum-global-color-seafoam-400: rgb(32, 163, 168);
  --spectrum-global-color-seafoam-500: rgb(27, 149, 154);
  --spectrum-global-color-seafoam-600: rgb(22, 135, 140);
  --spectrum-global-color-seafoam-700: rgb(15, 121, 125);
  --spectrum-global-color-red-400: rgb(236, 91, 98);
  --spectrum-global-color-red-500: rgb(227, 72, 80);
  --spectrum-global-color-red-600: rgb(215, 55, 63);
  --spectrum-global-color-red-700: rgb(201, 37, 45);
  --spectrum-global-color-orange-400: rgb(242, 148, 35);
  --spectrum-global-color-orange-500: rgb(230, 134, 25);
  --spectrum-global-color-orange-600: rgb(218, 123, 17);
  --spectrum-global-color-orange-700: rgb(203, 111, 16);
  --spectrum-global-color-green-400: rgb(51, 171, 132);
  --spectrum-global-color-green-500: rgb(45, 157, 120);
  --spectrum-global-color-green-600: rgb(38, 142, 108);
  --spectrum-global-color-green-700: rgb(18, 128, 92);
  --spectrum-global-color-blue-400: rgb(55, 142, 240);
  --spectrum-global-color-blue-500: rgb(38, 128, 235);
  --spectrum-global-color-blue-600: rgb(20, 115, 230);
  --spectrum-global-color-blue-700: rgb(13, 102, 208);
  --spectrum-global-color-gray-50: rgb(255, 255, 255);
  --spectrum-global-color-gray-75: rgb(255, 255, 255);
  --spectrum-global-color-gray-100: rgb(255, 255, 255);
  --spectrum-global-color-gray-200: rgb(244, 244, 244);
  --spectrum-global-color-gray-300: rgb(234, 234, 234);
  --spectrum-global-color-gray-400: rgb(211, 211, 211);
  --spectrum-global-color-gray-500: rgb(188, 188, 188);
  --spectrum-global-color-gray-600: rgb(149, 149, 149);
  --spectrum-global-color-gray-700: rgb(116, 116, 116);
  --spectrum-global-color-gray-800: rgb(80, 80, 80);
  --spectrum-global-color-gray-900: rgb(50, 50, 50);
  --spectrum-alias-background-color-primary: var(--spectrum-global-color-gray-50);
  --spectrum-alias-background-color-secondary: var(--spectrum-global-color-gray-100);
  --spectrum-alias-background-color-tertiary: var(--spectrum-global-color-gray-300);
  --spectrum-alias-background-color-modal-overlay: rgba(0,0,0,0.4);
  --spectrum-alias-dropshadow-color: rgba(0,0,0,0.15);
  --spectrum-alias-background-color-hover-overlay: rgba(50,50,50,0.04);
  --spectrum-alias-highlight-hover: rgba(50,50,50,0.06);
  --spectrum-alias-highlight-active: rgba(50,50,50,0.1);
  --spectrum-alias-highlight-selected: rgba(38,128,235,0.1);
  --spectrum-alias-highlight-selected-hover: rgba(38,128,235,0.2);
  --spectrum-alias-text-highlight-color: rgba(38,128,235,0.2);
  --spectrum-alias-background-color-quickactions: rgba(255,255,255,0.9);
  --spectrum-alias-border-color-selected: var(--spectrum-global-color-blue-500);
  --spectrum-alias-radial-reaction-color-default: rgba(80,80,80,0.6);
  --spectrum-alias-pasteboard-background-color: var(--spectrum-global-color-gray-300);
  --spectrum-alias-appframe-border-color: var(--spectrum-global-color-gray-300);
  --spectrum-alias-appframe-separator-color: var(--spectrum-global-color-gray-300);
  --spectrum-colorarea-border-color: rgba(50,50,50,0.1);
  --spectrum-colorarea-border-color-hover: rgba(50,50,50,0.1);
  --spectrum-colorarea-border-color-down: rgba(50,50,50,0.1);
  --spectrum-colorarea-border-color-key-focus: rgba(50,50,50,0.1);
  --spectrum-colorslider-border-color: rgba(50,50,50,0.1);
  --spectrum-colorslider-border-color-hover: rgba(50,50,50,0.1);
  --spectrum-colorslider-border-color-down: rgba(50,50,50,0.1);
  --spectrum-colorslider-border-color-key-focus: rgba(50,50,50,0.1);
  --spectrum-colorslider-vertical-border-color: rgba(50,50,50,0.1);
  --spectrum-colorslider-vertical-border-color-hover: rgba(50,50,50,0.1);
  --spectrum-colorslider-vertical-border-color-down: rgba(50,50,50,0.1);
  --spectrum-colorslider-vertical-border-color-key-focus: rgba(50,50,50,0.1);
  --spectrum-colorwheel-border-color: rgba(50,50,50,0.1);
  --spectrum-colorwheel-border-color-hover: rgba(50,50,50,0.1);
  --spectrum-colorwheel-border-color-down: rgba(50,50,50,0.1);
  --spectrum-colorwheel-border-color-key-focus: rgba(50,50,50,0.1);
  --spectrum-miller-column-item-background-color-selected: rgba(38,128,235,0.1);
  --spectrum-miller-column-item-background-color-selected-hover: rgba(38,128,235,0.2);
  --spectrum-well-background-color: rgba(80,80,80,0.02);
  --spectrum-well-border-color: rgba(50,50,50,0.05);
}
.spectrum--nord {
  --spectrum-global-color-red-400: #bf616a;
  --spectrum-global-color-red-500: #c26971;
  --spectrum-global-color-red-600: #c57179;
  --spectrum-global-color-red-700: #c97980;
  --spectrum-global-color-static-red-400: #bf616a;
  --spectrum-global-color-static-red-500: #c26971;
  --spectrum-global-color-static-red-600: #c57179;
  --spectrum-global-color-static-red-700: #c97980;

  --spectrum-global-color-green-400: #719453;
  --spectrum-global-color-green-500: #789d58;
  --spectrum-global-color-green-600: #7fa55e;
  --spectrum-global-color-green-700: #86aa67;
  --spectrum-global-color-static-green-400: #719453;
  --spectrum-global-color-static-green-500: #789d58;
  --spectrum-global-color-static-green-600: #7fa55e;
  --spectrum-global-color-static-green-700: #86aa67;

  --spectrum-global-color-blue-400: #5680b4;
  --spectrum-global-color-blue-500: #5e86b8;
  --spectrum-global-color-blue-600: #668dbb;
  --spectrum-global-color-blue-700: #6f93bf;
  --spectrum-global-color-static-blue-200: #7799c4;
  --spectrum-global-color-static-blue-300: #6f93bf;
  --spectrum-global-color-static-blue-400: #668dbb;
  --spectrum-global-color-static-blue-500: #5e86b8;
  --spectrum-global-color-static-blue-600: #5680b4;
  --spectrum-global-color-static-blue-700: #4e79af;
  --spectrum-global-color-static-blue-800: #4a73a6;
  --spectrum-global-color-static-blue: var(--spectrum-global-color-blue-600);

  --spectrum-global-color-gray-50: #2e3440;
  --spectrum-global-color-gray-75: #353b4a;
  --spectrum-global-color-gray-100: #3b4252;
  --spectrum-global-color-gray-200: #424a5c;
  --spectrum-global-color-gray-300: #4c566a;
  --spectrum-global-color-gray-400: #5a657d;
  --spectrum-global-color-gray-500: #677590;
  --spectrum-global-color-gray-600: #79869f;
  --spectrum-global-color-gray-700: #a9b1c1;
  --spectrum-global-color-gray-800: #bac1cd;
  --spectrum-global-color-gray-900: #eceff4;

  --spectrum-alias-highlight-hover: rgba(169, 177, 193, 0.1);
  --spectrum-alias-highlight-active: rgba(169, 177, 193, 0.1);
  --spectrum-alias-background-color-hover-overlay: rgba(169, 177, 193, 0.1);

  /* Custom additions */
  --modal-background: var(--spectrum-global-color-gray-50);
  --drop-shadow: rgba(0, 0, 0, 0.15) !important;
  --spectrum-global-color-blue-100: hsl(213, 36%, 30%) !important;
  --translucent-grey: hsla(213, 36%, 80%, 0.11) !important;
}
.spectrum--midnight {
  --hue: 220;
  --sat: 10%;
  --spectrum-global-color-gray-50: hsl(var(--hue), var(--sat), 12%);
  --spectrum-global-color-gray-75: hsl(var(--hue), var(--sat), 15%);
  --spectrum-global-color-gray-100: hsl(var(--hue), var(--sat), 17%);
  --spectrum-global-color-gray-200: hsl(var(--hue), var(--sat), 20%);
  --spectrum-global-color-gray-300: hsl(var(--hue), var(--sat), 24%);
  --spectrum-global-color-gray-400: hsl(var(--hue), var(--sat), 32%);
  --spectrum-global-color-gray-500: hsl(var(--hue), var(--sat), 40%);
  --spectrum-global-color-gray-600: hsl(var(--hue), var(--sat), 60%);
  --spectrum-global-color-gray-700: hsl(var(--hue), var(--sat), 70%);
  --spectrum-global-color-gray-800: hsl(var(--hue), var(--sat), 85%);
  --spectrum-global-color-gray-900: hsl(var(--hue), var(--sat), 95%);

  /* Custom additions */
  --modal-background: var(--spectrum-global-color-gray-50);
  --drop-shadow: rgba(0, 0, 0, 0.25) !important;
  --spectrum-global-color-blue-100: hsl(var(--hue), 48%, 24%) !important;
  --translucent-grey: rgba(255, 255, 255, 0.075) !important;
}
.spectrum {
  background-color: var(--spectrum-alias-background-color-default, var(--spectrum-global-color-gray-100));
  -webkit-tap-highlight-color: rgba(0,0,0,0);
}
div.svelte-u3ivhz{position:relative}div.svelte-u3ivhz > .component > *{flex:1 1 auto}.component-placeholder.svelte-1uv9ndz{display:flex;flex-direction:row;justify-content:flex-start;align-items:flex-start;color:var(--spectrum-global-color-gray-600);font-size:var(--font-size-s);gap:var(--spacing-s);grid-column:1 / -1;grid-row:1 / -1}.placeholder.svelte-1bc7j1u{display:flex;flex-direction:column;justify-content:center;align-items:center;gap:var(--spacing-s);flex:1 1 auto;grid-column:1 / -1;grid-row:1 / -1}.placeholder.svelte-1bc7j1u .spectrum-Button{margin-top:var(--spacing-m)}.component-placeholder.svelte-129t83p{display:flex;flex-direction:row;justify-content:center;align-items:center;color:var(--spectrum-global-color-gray-600);font-size:var(--font-size-s);padding:var(--spacing-xs);gap:var(--spacing-s)}.component-placeholder.svelte-129t83p mark{background-color:var(--spectrum-global-color-gray-400);padding:0 4px;border-radius:2px}.component-placeholder.svelte-129t83p .spectrum-Link{cursor:pointer}.component.svelte-d44q0m{display:contents}.component.pad.svelte-d44q0m > *{padding:var(--spacing-m) !important;gap:var(--spacing-m) !important;border:2px dashed var(--spectrum-global-color-gray-400) !important;border-radius:4px !important;transition:padding 260ms ease-out,
      border 260ms ease-out}.interactive.svelte-d44q0m{cursor:default !important}.notifications.svelte-o2yltz{position:fixed;top:20px;bottom:40px;left:0;right:0;margin:0 auto;padding:0;z-index:9999;display:flex;flex-direction:column;justify-content:flex-start;align-items:center;pointer-events:none;gap:10px}.notifications.svelte-o2yltz .spectrum-Toast{width:400px;max-width:100vw}iframe.svelte-gbetw2{margin:-40px;border:none;width:calc(100% + 80px);height:640px;max-height:calc(100vh - 120px);transition:width 1s ease,
      height 1s ease,
      top 1s ease,
      left 1s ease;border-radius:var(--spectrum-global-dimension-size-100)}.actions.svelte-gbetw2{display:flex;flex-direction:row;justify-content:flex-end;align-items:center;position:absolute;top:0;width:640px;max-width:100%}.install-prompt.svelte-z0e6e1{position:fixed;bottom:5px;right:10px;z-index:1000}.openMenu.svelte-z0e6e1{cursor:pointer;background-color:var(--bb-indigo);border-radius:100px;color:white;border:none;font-size:13px;font-weight:600;padding:10px 18px;transition:background-color 130ms ease-out}.openMenu.svelte-z0e6e1:hover{background-color:var(--bb-indigo-light)}div.svelte-1p3obm1{padding:6px;border-radius:2px;color:var(--spectrum-global-color-gray-700);display:flex;transition:color 0.13s ease-in-out,
      background-color 0.13s ease-in-out}div.svelte-1p3obm1:hover{background-color:var(--spectrum-global-color-gray-200);cursor:pointer}.active.svelte-1p3obm1,.active.svelte-1p3obm1:hover{background-color:rgba(13, 102, 208, 0.1);color:var(--spectrum-global-color-blue-600)}.disabled.svelte-1p3obm1{pointer-events:none;color:var(--spectrum-global-color-gray-400)}div.svelte-ih88f7{padding:6px;border-radius:2px;color:var(--spectrum-global-color-gray-700);display:flex;transition:color 0.13s ease-in-out,
      background-color 0.13s ease-in-out}div.svelte-ih88f7:hover{background-color:var(--spectrum-global-color-gray-200);cursor:pointer}.active.svelte-ih88f7,.active.svelte-ih88f7:hover{background-color:rgba(13, 102, 208, 0.1);color:var(--spectrum-global-color-blue-600)}div.svelte-2tavi5{padding:0 4px}div.disabled.svelte-2tavi5{pointer-events:none}div.svelte-y2na4k{padding:0 4px}.bar.svelte-zwufuk{display:flex;position:absolute;z-index:930;padding:6px 8px;opacity:0;flex-direction:row;background:var(--spectrum-alias-background-color-primary);justify-content:center;align-items:center;border-radius:4px;box-shadow:0 2px 8px rgba(0, 0, 0, 0.2);gap:2px;transition:opacity 0.13s ease-in-out}.visible.svelte-zwufuk{opacity:1}.divider.svelte-zwufuk{flex:0 0 1px;align-self:stretch;margin:0 4px;background-color:var(--spectrum-global-color-gray-300)}.spectrum--dark .bar.svelte-zwufuk,.spectrum--darkest .bar.svelte-zwufuk{background:var(--spectrum-global-color-gray-200)}.spectrum--dark .divider.svelte-zwufuk,.spectrum--darkest .divider.svelte-zwufuk{background:var(--spectrum-global-color-gray-400)}.indicator.svelte-1qt4i99.svelte-1qt4i99{right:0;position:absolute;z-index:var(--zIndex);border:2px solid var(--color);pointer-events:none;border-radius:4px;background:var(--bg)}.indicator.withText.svelte-1qt4i99.svelte-1qt4i99{border-top-left-radius:0}.indicator.withText.flipped.svelte-1qt4i99.svelte-1qt4i99{border-top-left-radius:4px}.indicator.line.svelte-1qt4i99.svelte-1qt4i99{border-radius:4px !important}.indicator.animate.svelte-1qt4i99.svelte-1qt4i99{transition:all 130ms ease-out}.label.svelte-1qt4i99.svelte-1qt4i99{background-color:var(--color);position:absolute;top:0;left:-2px;height:24px;padding:0 6px 0 6px;transform:translateY(-100%);border-top-left-radius:4px;border-top-right-radius:4px;border-bottom-right-radius:4px;white-space:nowrap;display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:6px;pointer-events:all}.label.line.svelte-1qt4i99.svelte-1qt4i99{transform:translateY(-50%);border-radius:4px}.label.flipped.svelte-1qt4i99.svelte-1qt4i99{border-radius:4px;transform:translateY(0%);top:-1px}.label.right.svelte-1qt4i99.svelte-1qt4i99{right:-2px;left:auto}.text.svelte-1qt4i99.svelte-1qt4i99{color:white;font-size:11px;font-weight:600}.anchor.svelte-1qt4i99.svelte-1qt4i99{--size:20px;position:absolute;width:var(--size);height:var(--size);pointer-events:all;display:grid;place-items:center;border-radius:50%;transform:translateX(-50%) translateY(-50%)}.anchor-inner.svelte-1qt4i99.svelte-1qt4i99{width:calc(var(--size) / 2);height:calc(var(--size) / 2);background:white;border:2px solid var(--color);pointer-events:none;border-radius:2px}.anchor.right.svelte-1qt4i99.svelte-1qt4i99,.anchor.left.svelte-1qt4i99.svelte-1qt4i99{height:calc(var(--size) * 2)}.anchor.top.svelte-1qt4i99.svelte-1qt4i99,.anchor.bottom.svelte-1qt4i99.svelte-1qt4i99{width:calc(var(--size) * 2)}.anchor.right.svelte-1qt4i99 .anchor-inner.svelte-1qt4i99,.anchor.left.svelte-1qt4i99 .anchor-inner.svelte-1qt4i99{height:calc(var(--size) * 1.2);width:calc(var(--size) * 0.3)}.anchor.top.svelte-1qt4i99 .anchor-inner.svelte-1qt4i99,.anchor.bottom.svelte-1qt4i99 .anchor-inner.svelte-1qt4i99{width:calc(var(--size) * 1.2);height:calc(var(--size) * 0.3)}.indicator.hCompact.svelte-1qt4i99 .anchor.top.svelte-1qt4i99,.indicator.hCompact.svelte-1qt4i99 .anchor.bottom.svelte-1qt4i99,.indicator.vCompact.svelte-1qt4i99 .anchor.left.svelte-1qt4i99,.indicator.vCompact.svelte-1qt4i99 .anchor.right.svelte-1qt4i99{display:none}.anchor.right.svelte-1qt4i99.svelte-1qt4i99{left:calc(100% + 1px);top:50%;cursor:e-resize}.anchor.left.svelte-1qt4i99.svelte-1qt4i99{left:-1px;top:50%;cursor:w-resize}.anchor.bottom.svelte-1qt4i99.svelte-1qt4i99{left:50%;top:calc(100% + 1px);cursor:s-resize}.anchor.top.svelte-1qt4i99.svelte-1qt4i99{left:50%;top:-1px;cursor:n-resize}.anchor.bottom-right.svelte-1qt4i99.svelte-1qt4i99{top:100%;left:100%;cursor:se-resize}.anchor.bottom-left.svelte-1qt4i99.svelte-1qt4i99{left:0;top:100%;cursor:sw-resize}.anchor.top-right.svelte-1qt4i99.svelte-1qt4i99{left:100%;top:0;cursor:ne-resize}.anchor.top-left.svelte-1qt4i99.svelte-1qt4i99{left:0;top:0;cursor:nw-resize}div.svelte-11fpj2n{display:contents}div.svelte-11fpj2n{--spectrum-semantic-cta-color-background-default:var(--primaryColor);--spectrum-semantic-cta-color-background-hover:var(--primaryColorHover);--spectrum-semantic-cta-color-background-down:var(--primaryColorHover);--spectrum-button-primary-s-border-radius:calc(
      var(--buttonBorderRadius) * 0.9
    );--spectrum-button-primary-m-border-radius:var(--buttonBorderRadius);--spectrum-button-primary-l-border-radius:calc(
      var(--buttonBorderRadius) * 1.25
    );--spectrum-button-primary-xl-border-radius:calc(
      var(--buttonBorderRadius) * 1.5
    );--spectrum-progresscircle-medium-track-fill-color:var(--primaryColor);--spectrum-alias-border-color-mouse-focus:var(--primaryColor);--spectrum-alias-border-color-focus:var(--primaryColor);--spectrum-radio-m-emphasized-circle-border-color-selected:var(
      --primaryColor
    );--spectrum-radio-m-emphasized-circle-border-color-selected-hover:var(
      --primaryColorHover
    );--spectrum-checkbox-m-emphasized-box-border-color-selected:var(
      --primaryColor
    );--spectrum-checkbox-m-emphasized-box-border-color-selected-hover:var(
      --primaryColorHover
    );--spectrum-alias-icon-color-selected:var(--primaryColor);--spectrum-alias-icon-color-selected-hover:var(--primaryColorHover);--spectrum-link-primary-m-text-color:var(--primaryColor);--spectrum-link-primary-m-text-color-hover:var(--primaryColorHover)}::-webkit-scrollbar{width:8px;height:8px}::-webkit-scrollbar-track{background:var(--spectrum-alias-background-color-default)}::-webkit-scrollbar-thumb{background-color:var(--spectrum-global-color-gray-400);border-radius:4px}::-webkit-scrollbar-corner{background:var(--spectrum-alias-background-color-default)}*{scrollbar-width:thin;scrollbar-color:var(--spectrum-global-color-gray-400)
      var(--spectrum-alias-background-color-default)}*[contenteditable="true"]:focus{outline:none}.dev-preview-header.svelte-14133vr{flex:0 0 60px;background-color:black;padding:0 var(--spacing-xl);display:flex;align-items:center;gap:var(--spacing-xl)}.dev-preview-header.svelte-14133vr .spectrum-Heading{flex:1 1 auto}.dev-preview-header.mobile.svelte-14133vr{grid-template-columns:1fr auto auto}.dev-preview-header.svelte-14133vr .spectrum-Heading,.dev-preview-header.svelte-14133vr .spectrum-Picker-menuIcon,.dev-preview-header.svelte-14133vr .icon,.dev-preview-header.svelte-14133vr .spectrum-Picker-label,.dev-preview-header.svelte-14133vr .spectrum-ActionButton{font-weight:600;color:white}.dev-preview-header.svelte-14133vr .spectrum-Picker{padding-left:8px;padding-right:8px;transition:background 130ms ease-out;border-radius:4px}.dev-preview-header.svelte-14133vr .spectrum-ActionButton:hover,.dev-preview-header.svelte-14133vr .spectrum-Picker:hover,.dev-preview-header.svelte-14133vr .spectrum-Picker.is-open{background:rgba(255, 255, 255, 0.1)}.dev-preview-header.svelte-14133vr .spectrum-ActionButton:active{background:rgba(255, 255, 255, 0.2)}@media print{.dev-preview-header.svelte-14133vr{display:none}}.stat.svelte-da3g1f{display:flex;flex-direction:row;justify-content:space-between;align-items:center;gap:var(--spacing-xl)}.stat-label.svelte-da3g1f{font-size:var(--font-size-xs);color:var(--spectrum-global-color-gray-600);text-transform:uppercase;flex:0 0 auto;width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.stat-value.svelte-da3g1f{flex:1 1 auto;width:0;text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;transition:color var(--spectrum-global-animation-duration-100, 130ms)
      ease-in-out}.stat-value.empty.svelte-da3g1f{color:var(--spectrum-global-color-gray-500)}.stat-value.copyable.svelte-da3g1f:hover{color:var(--spectrum-global-color-blue-600);cursor:pointer}.buttons.svelte-1rbkjdg{display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:var(--spacing-xs)}.data.svelte-1rbkjdg{margin:0 calc(-1 * var(--spacing-xl))}.data.svelte-1rbkjdg .spectrum-Textfield-input{min-height:200px !important;white-space:pre;font-size:var(--font-size-s)}.tab-content.svelte-1rbkjdg{padding:0 var(--spacing-xl)}.devtools.svelte-1aby6jg{background:var(--spectrum-alias-background-color-primary);flex:0 0 320px;border-left:1px solid var(--spectrum-global-color-gray-300);overflow:auto;transition:margin-right 300ms ease;margin-right:0}.devtools.hidden.svelte-1aby6jg{margin-right:-320px}.devtools.mobile.svelte-1aby6jg{display:none}.header.svelte-1aby6jg{padding:var(--spacing-xl) var(--spacing-xl) 0 var(--spacing-xl);display:flex;flex-direction:row;justify-content:space-between;align-items:center}.tab-content.svelte-1aby6jg{padding:0 var(--spacing-xl)}@media print{.devtools.svelte-1aby6jg{display:none}}.free-footer.svelte-zvk6ne{min-height:51px;flex:0 0 auto;padding:16px 20px;border-top:1px solid var(--spectrum-global-color-gray-300);background:var(--spectrum-alias-background-color-primary);display:flex;justify-content:flex-end}.free-footer.svelte-zvk6ne .spectrum-Link{text-decoration:none;color:var(--spectrum-global-color-gray-900);transition:color 130ms ease-out}.free-footer.svelte-zvk6ne .spectrum-Link:hover{color:var(--spectrum-global-color-blue-400)}span.svelte-zvk6ne{font-weight:bold}.content.svelte-vj0fu7{max-width:700px;margin:auto;height:100vh;display:flex;flex-direction:row;align-items:center;justify-content:center;padding:var(--spacing-l)}@media(max-width: 640px){.content.svelte-vj0fu7{justify-content:flex-start;align-items:flex-start}}.wrapper.svelte-hjse25{display:flex;flex-direction:column;gap:var(--spacing-l);align-items:center}#spectrum-root.svelte-usa5gl{height:0;visibility:hidden;padding:0;margin:0;overflow:clip;width:100%;display:flex;flex-direction:row;justify-content:center;align-items:center}#spectrum-root.builder.svelte-usa5gl{background:transparent}#clip-root.svelte-usa5gl{max-width:100%;max-height:100%;width:100%;height:100%;position:relative;overflow:clip;background-color:transparent}#spectrum-root.show.svelte-usa5gl{height:100%;visibility:visible}#app-root.svelte-usa5gl{overflow:clip;height:100%;width:100%;display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch}#app-body.svelte-usa5gl{flex:1 1 auto;display:flex;flex-direction:row;justify-content:flex-start;align-items:stretch;overflow:hidden;position:relative}.error.svelte-usa5gl{width:100%;height:100%;display:grid;place-items:center;z-index:1;text-align:center;padding:20px}.error.svelte-usa5gl svg{fill:var(--spectrum-global-color-gray-500);width:80px;height:80px}.error.svelte-usa5gl h1,.error.svelte-usa5gl p{color:var(--spectrum-global-color-gray-800)}.error.svelte-usa5gl p{font-style:italic;margin-top:-0.5em}.error.svelte-usa5gl h1{font-weight:400}#clip-root.preview.svelte-usa5gl{padding:6px}#clip-root.tablet-preview.svelte-usa5gl{width:calc(1024px + 12px);height:calc(768px + 12px)}#clip-root.mobile-preview.svelte-usa5gl{width:calc(390px + 12px);height:calc(844px + 12px)}@media print{#spectrum-root.svelte-usa5gl,#clip-root.svelte-usa5gl,#app-root.svelte-usa5gl,#app-body.svelte-usa5gl{overflow:visible !important}}.container.svelte-1w67a05{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch}.loading.svelte-1w67a05{display:flex;flex-direction:row;justify-content:center;align-items:center;height:100px}.pagination.svelte-1w67a05{display:flex;flex-direction:row;justify-content:flex-end;align-items:center;margin-top:var(--spacing-xl)}div.svelte-ku38cm{display:flex !important;flex-direction:column !important;justify-content:center !important;align-items:center !important;padding:32px !important;text-align:center !important}h1.svelte-ku38cm{color:var(--spectrum-alias-text-color)}span.svelte-ku38cm{font-size:var(--font-size-s);color:var(--spectrum-global-color-gray-600)}.noRows.svelte-1lkne36.svelte-1lkne36{color:var(--spectrum-global-color-gray-600);font-size:var(--font-size-s);padding:var(--spacing-l);display:grid;place-items:center;grid-column:1 / -1}.noRows.svelte-1lkne36 i.svelte-1lkne36{margin-bottom:var(--spacing-m);font-size:1.5rem;color:var(--spectrum-global-color-gray-600)}a.svelte-xz09vf.svelte-xz09vf,.dropdown.svelte-xz09vf .text.svelte-xz09vf{padding:4px 8px;border-radius:4px;display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:var(--spacing-s)}a.svelte-xz09vf.svelte-xz09vf,.text.svelte-xz09vf span.svelte-xz09vf{opacity:0.75;color:var(--navTextColor);font-size:var(--spectrum-global-dimension-font-size-150);transition:opacity 130ms ease-out;user-select:none;overflow:hidden;text-overflow:ellipsis}a.active.svelte-xz09vf.svelte-xz09vf:not(.sublink),a.builderActive.svelte-xz09vf.svelte-xz09vf:not(.sublink),.dropdown.left.svelte-xz09vf a.sublink.active.svelte-xz09vf,.dropdown.left.svelte-xz09vf a.sublink.builderActive.svelte-xz09vf{background:rgba(0, 0, 0, 0.15);opacity:1}a.svelte-xz09vf.svelte-xz09vf:hover,.text.svelte-xz09vf:hover span.svelte-xz09vf{cursor:pointer;opacity:1}.dropdown.svelte-xz09vf.svelte-xz09vf{position:relative}.sublinks-wrapper.svelte-xz09vf.svelte-xz09vf{position:absolute;top:100%;display:none;padding-top:var(--spacing-s)}.dropdown.svelte-xz09vf:hover .sublinks-wrapper.svelte-xz09vf{display:block}.sublinks.svelte-xz09vf.svelte-xz09vf{display:flex;flex-direction:column;justify-content:stretch;align-items:flex-start;background:var(--spectrum-global-color-gray-50);border-radius:6px;border:1px solid var(--spectrum-global-color-gray-300);min-width:150px;max-width:250px;padding:10px 0;overflow:hidden}.sublinks.svelte-xz09vf a.svelte-xz09vf{padding:6px var(--spacing-l);font-weight:400;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%}.dropdown.svelte-xz09vf:not(.left) .sublinks a.svelte-xz09vf{color:var(--spectrum-alias-text-color)}.dropdown.left.svelte-xz09vf .sublinks-wrapper.svelte-xz09vf{display:none}.dropdown.left.svelte-xz09vf.svelte-xz09vf,.dropdown.left.expanded.svelte-xz09vf .sublinks-wrapper.svelte-xz09vf,.dropdown.dropdown.left.expanded.svelte-xz09vf .sublinks.svelte-xz09vf{display:contents}.container.svelte-1f32c0v{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:var(--spacing-xs);transition:filter 130ms ease-out;overflow:hidden}.text.svelte-1f32c0v{flex-direction:column;align-items:flex-start;justify-content:center;color:var(--navTextColor);display:flex;margin-left:var(--spacing-xs);overflow:hidden}.name.svelte-1f32c0v{font-weight:600;font-size:14px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;width:100%}.container.svelte-1f32c0v:hover{cursor:pointer;filter:brightness(110%)}img.svelte-17w40j6{height:var(--logoHeight)}.layout.svelte-1r1yuqu.svelte-1r1yuqu{height:100%;flex:1 1 auto;display:flex;flex-direction:row;justify-content:center;align-items:stretch;z-index:1;overflow:hidden;position:relative;--grid-spacing:4}.component.svelte-1r1yuqu.svelte-1r1yuqu{display:contents}.layout-body.svelte-1r1yuqu.svelte-1r1yuqu{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;flex:1 1 auto;overflow:auto;overflow-x:hidden;position:relative;background:var(--spectrum-alias-background-color-secondary)}.nav-wrapper.svelte-1r1yuqu.svelte-1r1yuqu{display:flex;flex-direction:row;justify-content:center;align-items:stretch;background:var(--navBackground);z-index:2}.nav-wrapper.clickable.svelte-1r1yuqu.svelte-1r1yuqu{cursor:pointer}.nav-wrapper.clickable.svelte-1r1yuqu .nav.svelte-1r1yuqu{pointer-events:none}.nav-wrapper.hidden.svelte-1r1yuqu.svelte-1r1yuqu{display:none}.layout--top.svelte-1r1yuqu .nav-wrapper.sticky.svelte-1r1yuqu{position:sticky;top:0;left:0}.nav.svelte-1r1yuqu.svelte-1r1yuqu{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;padding:18px 32px 18px 32px;max-width:100%;gap:var(--spacing-xs)}.nav.svelte-1r1yuqu .icon{color:var(--navTextColor);opacity:0.75}.nav.svelte-1r1yuqu .icon:hover{color:var(--navTextColor);opacity:1}.nav.svelte-1r1yuqu h1{color:var(--navTextColor)}.nav-header.svelte-1r1yuqu.svelte-1r1yuqu{flex:0 0 auto;display:flex;flex-direction:row;justify-content:space-between;align-items:center;gap:var(--spacing-xl)}#side-panel-container.svelte-1r1yuqu.svelte-1r1yuqu{max-width:calc(100vw - 40px);background:var(--spectrum-global-color-gray-50);z-index:3;padding:var(--spacing-xl);display:flex;flex-direction:column;gap:30px;overflow-y:auto;overflow-x:hidden;transition:transform 130ms ease-out;position:absolute;width:400px;right:0;transform:translateX(100%);height:100%}#side-panel-container.builder.svelte-1r1yuqu.svelte-1r1yuqu{transform:translateX(0);opacity:0;pointer-events:none}#side-panel-container.open.svelte-1r1yuqu.svelte-1r1yuqu{transform:translateX(0);box-shadow:0 0 40px 10px rgba(0, 0, 0, 0.1)}#side-panel-container.builder.open.svelte-1r1yuqu.svelte-1r1yuqu{opacity:1;pointer-events:all}.side-panel-header.svelte-1r1yuqu.svelte-1r1yuqu{display:flex;flex-direction:row;justify-content:flex-end}.main-wrapper.svelte-1r1yuqu.svelte-1r1yuqu{display:flex;flex-direction:row;justify-content:center;align-items:stretch;flex:1 1 auto;z-index:1}.main.svelte-1r1yuqu.svelte-1r1yuqu{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;max-width:100%;position:relative;padding:32px}.main.svelte-1r1yuqu.svelte-1r1yuqu:not(.size--max):has(.screenslot-dom > .component > .grid){padding:calc(32px - var(--grid-spacing) * 2px)}.layout--none.svelte-1r1yuqu .main.svelte-1r1yuqu{padding:0}.size--xs.svelte-1r1yuqu.svelte-1r1yuqu{width:400px}.size--s.svelte-1r1yuqu.svelte-1r1yuqu{width:800px}.size--m.svelte-1r1yuqu.svelte-1r1yuqu{width:1100px}.size--l.svelte-1r1yuqu.svelte-1r1yuqu{width:1400px}.size--max.svelte-1r1yuqu.svelte-1r1yuqu{width:100%}.main.size--max.svelte-1r1yuqu.svelte-1r1yuqu{padding:0}.burger.svelte-1r1yuqu.svelte-1r1yuqu{display:none}.logo.svelte-1r1yuqu.svelte-1r1yuqu{display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:var(--spacing-m);flex:1 1 auto}.logo.svelte-1r1yuqu h1{font-weight:600;flex:1 1 auto;width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.links.svelte-1r1yuqu.svelte-1r1yuqu{flex:1 0 auto;display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:var(--spacing-xl);margin-top:var(--spacing-xl)}.mobile-click-handler.svelte-1r1yuqu.svelte-1r1yuqu{display:none}.nav--left.svelte-1r1yuqu.svelte-1r1yuqu{overflow-y:auto}.desktop.layout--left.svelte-1r1yuqu .layout-body.svelte-1r1yuqu{flex-direction:row;overflow:hidden}.desktop.layout--left.svelte-1r1yuqu .main-wrapper.svelte-1r1yuqu{height:100%;overflow:auto}.desktop.svelte-1r1yuqu .nav--left.svelte-1r1yuqu{width:250px;padding:var(--spacing-xl)}.desktop.svelte-1r1yuqu .nav--left .links.svelte-1r1yuqu{margin-top:var(--spacing-m);flex-direction:column;justify-content:flex-start;align-items:stretch;gap:var(--spacing-xs)}.desktop.svelte-1r1yuqu .nav--left .user.top.svelte-1r1yuqu,.desktop.svelte-1r1yuqu .nav--top .user.left.svelte-1r1yuqu{display:none}.mobile.svelte-1r1yuqu .nav-wrapper.svelte-1r1yuqu{position:sticky;top:0;left:0;box-shadow:0 0 8px -1px rgba(0, 0, 0, 0.075)}.user.left.svelte-1r1yuqu.svelte-1r1yuqu{display:flex;flex-direction:column;gap:var(--spacing-m)}.mobile.svelte-1r1yuqu .user.left.svelte-1r1yuqu{display:none}.mobile.svelte-1r1yuqu .nav.svelte-1r1yuqu{padding:var(--spacing-m) 16px}.mobile.svelte-1r1yuqu .burger.svelte-1r1yuqu{display:grid;place-items:center}.mobile.svelte-1r1yuqu .logo.svelte-1r1yuqu{flex:0 0 auto}.mobile.svelte-1r1yuqu .logo.svelte-1r1yuqu h1{display:none}.mobile.svelte-1r1yuqu:not(.layout--none) .main.svelte-1r1yuqu{padding:16px}.mobile.svelte-1r1yuqu:not(.layout--none) .main.svelte-1r1yuqu:not(.size--max):has(.screenslot-dom > .component > .grid){padding:6px}.mobile.svelte-1r1yuqu .main.size--max.svelte-1r1yuqu{padding:0}.mobile.svelte-1r1yuqu .links.svelte-1r1yuqu{margin-top:0;position:absolute;top:0;left:-250px;transform:translateX(0);width:250px;max-width:75%;transition:transform 0.26s ease-in-out,
      opacity 0.26s ease-in-out;height:var(--height);opacity:0;background:var(--navBackground);z-index:999;flex-direction:column;justify-content:flex-start;align-items:stretch;padding:var(--spacing-xl);overflow-y:auto;gap:var(--spacing-xs)}.mobile.svelte-1r1yuqu .links.svelte-1r1yuqu a{flex:0 0 auto}.mobile.svelte-1r1yuqu .links.visible.svelte-1r1yuqu{opacity:1;transform:translateX(250px);box-shadow:0 0 80px 20px rgba(0, 0, 0, 0.3)}.mobile.svelte-1r1yuqu .mobile-click-handler.visible.svelte-1r1yuqu{position:absolute;display:block;top:0;left:0;width:var(--width);height:var(--height);z-index:998}@media print{.layout.svelte-1r1yuqu.svelte-1r1yuqu,.main-wrapper.svelte-1r1yuqu.svelte-1r1yuqu{overflow:visible !important}.nav-wrapper.svelte-1r1yuqu.svelte-1r1yuqu{display:none !important}.layout.svelte-1r1yuqu.svelte-1r1yuqu{flex-direction:column !important;justify-content:flex-start !important;align-items:stretch !important}}a.svelte-1dqdd23,div.svelte-1dqdd23{color:var(--spectrum-alias-text-color);transition:color 130ms ease-in-out}a.svelte-1dqdd23:not(.placeholder):hover{color:var(--spectrum-link-primary-m-text-color-hover) !important}.placeholder.svelte-1dqdd23{font-style:italic;color:var(--spectrum-global-color-gray-600)}.bold.svelte-1dqdd23{font-weight:600}.italic.svelte-1dqdd23{font-style:italic}.underline.svelte-1dqdd23{text-decoration:underline}.size--S.svelte-1dqdd23{font-size:14px}.size--M.svelte-1dqdd23{font-size:16px}.size--L.svelte-1dqdd23{font-size:18px}.align--left.svelte-1dqdd23{text-align:left}.align--center.svelte-1dqdd23{text-align:center}.align--right.svelte-1dqdd23{text-align:right}.align-justify.svelte-1dqdd23{text-align:justify}.placeholder.svelte-1d46lef{display:grid;place-items:center}.embed.svelte-nd6hd8{position:relative}.embed.svelte-nd6hd8 > *{width:100%;height:100%}@media(hover: hover){.hoverable.svelte-1ghy1wa:hover{color:var(--spectrum-alias-icon-color-selected-hover) !important;cursor:pointer}}.hoverable.svelte-1ghy1wa:active{color:var(--spectrum-alias-icon-color-selected-hover) !important}@media(hover: hover){.hoverable.svelte-1ghy1wa:hover{color:var(--spectrum-alias-icon-color-selected-hover) !important;cursor:pointer}}.hoverable.svelte-1ghy1wa:active{color:var(--spectrum-alias-icon-color-selected-hover) !important}.outer.svelte-1ovy8gu{position:relative;width:100%;height:400px}.inner.svelte-1ovy8gu{position:absolute;height:100%;width:100%;background-repeat:no-repeat;background-size:cover;background-position:center center}.container.svelte-13s6ero{min-width:260px;width:max-content;border:1px solid var(--spectrum-global-color-gray-300);border-radius:0.3rem}.title.svelte-13s6ero{font-size:0.85rem;color:var(--spectrum-global-color-gray-600);font-weight:600;margin:1rem 1.5rem 0.5rem 1.5rem;white-space:pre-wrap}.value.svelte-13s6ero{font-size:2rem;font-weight:600;margin:0 1.5rem 1.5rem 1.5rem;color:var(--spectrum-link-primary-m-text-color);white-space:pre-wrap}.label.svelte-13s6ero{font-size:0.85rem;font-weight:400;color:var(--spectrum-global-color-gray-600);margin:1rem 1.5rem;white-space:pre-wrap}.spectrum-Card {
  position: relative;

  display: -ms-inline-flexbox;

  display: inline-flex;
  -ms-flex-direction: column;
      flex-direction: column;

  box-sizing: border-box;
  min-width: var(--spectrum-card-min-width, var(--spectrum-global-dimension-size-3000));

  border: var(--spectrum-card-border-size, var(--spectrum-alias-border-size-thin)) solid transparent;
  border-radius: var(--spectrum-card-border-radius, var(--spectrum-alias-border-radius-regular));

  text-decoration: none;
}

.spectrum-Card:focus {
    outline: none;
  }

.spectrum-Card.is-focused .spectrum-Card-quickActions,
    .spectrum-Card.is-focused .spectrum-Card-actions,
    .spectrum-Card.is-selected .spectrum-Card-quickActions,
    .spectrum-Card.is-selected .spectrum-Card-actions,
    .spectrum-Card:focus .spectrum-Card-quickActions,
    .spectrum-Card:focus .spectrum-Card-actions,
    .spectrum-Card:hover .spectrum-Card-quickActions,
    .spectrum-Card:hover .spectrum-Card-actions {
      visibility: visible;
      opacity: 1;
      pointer-events: all;
    }

[dir="ltr"] .spectrum-Card-actions {
  right: var(--spectrum-card-actions-margin, var(--spectrum-global-dimension-size-125));
}

[dir="rtl"] .spectrum-Card-actions {
  left: var(--spectrum-card-actions-margin, var(--spectrum-global-dimension-size-125));
}

.spectrum-Card-actions {
  position: absolute;
  top: var(--spectrum-card-actions-margin, var(--spectrum-global-dimension-size-125));
  height: var(--spectrum-quickactions-height, var(--spectrum-global-dimension-size-500));
  visibility: hidden;
}

[dir="ltr"] .spectrum-Card-quickActions {
  left: var(--spectrum-card-checkbox-margin, var(--spectrum-global-dimension-size-200));
}

[dir="rtl"] .spectrum-Card-quickActions {
  right: var(--spectrum-card-checkbox-margin, var(--spectrum-global-dimension-size-200));
}

.spectrum-Card-quickActions {
  position: absolute;
  top: var(--spectrum-card-checkbox-margin, var(--spectrum-global-dimension-size-200));

  width: var(--spectrum-quickactions-height, var(--spectrum-global-dimension-size-500));
  height: var(--spectrum-quickactions-height, var(--spectrum-global-dimension-size-500));

  visibility: hidden;
}

[dir="ltr"] .spectrum-Card-quickActions .spectrum-Checkbox,[dir="rtl"] 
  .spectrum-Card-quickActions .spectrum-Checkbox {
    margin: 0;
  }

.spectrum-Card-coverPhoto {
  height: var(--spectrum-card-coverphoto-height, var(--spectrum-global-dimension-size-1700));
  box-sizing: border-box;

  display: -ms-flexbox;

  display: flex;
  -ms-flex-align: center;
      align-items: center;
  -ms-flex-pack: center;
      justify-content: center;

  border-bottom: var(--spectrum-card-coverphoto-border-bottom-size, var(--spectrum-alias-border-size-thin)) solid transparent;
  border-top-left-radius: calc(var(--spectrum-card-border-radius, var(--spectrum-alias-border-radius-regular)) - 1px);
  border-top-right-radius: calc(var(--spectrum-card-border-radius, var(--spectrum-alias-border-radius-regular)) - 1px);
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;

  background-size: cover;
  background-position: center center;
}

[dir="ltr"] .spectrum-Card-body {
  padding-right: var(--spectrum-card-body-padding-right, var(--spectrum-global-dimension-size-300));
}

[dir="rtl"] .spectrum-Card-body {
  padding-left: var(--spectrum-card-body-padding-right, var(--spectrum-global-dimension-size-300));
}

[dir="ltr"] .spectrum-Card-body {
  padding-left: var(--spectrum-card-body-padding-left, var(--spectrum-global-dimension-size-300));
}

[dir="rtl"] .spectrum-Card-body {
  padding-right: var(--spectrum-card-body-padding-left, var(--spectrum-global-dimension-size-300));
}

.spectrum-Card-body {
  padding-top: var(--spectrum-card-body-padding-top, var(--spectrum-global-dimension-size-250));
  padding-bottom: var(--spectrum-card-body-padding-bottom, var(--spectrum-global-dimension-size-250));
}

.spectrum-Card-body:last-child {
    border-top-left-radius: 0;
    border-top-right-radius: 0;
    border-bottom-right-radius: var(--spectrum-card-border-radius, var(--spectrum-alias-border-radius-regular));
    border-bottom-left-radius: var(--spectrum-card-border-radius, var(--spectrum-alias-border-radius-regular));
  }

.spectrum-Card-preview {
  overflow: hidden;
  border-top-left-radius: calc(var(--spectrum-card-border-radius, var(--spectrum-alias-border-radius-regular)) - 1px);
  border-top-right-radius: calc(var(--spectrum-card-border-radius, var(--spectrum-alias-border-radius-regular)) - 1px);
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}

.spectrum-Card-header {
  height: var(--spectrum-card-body-header-height, var(--spectrum-global-dimension-size-225));
}

.spectrum-Card-content {
  display: -ms-flexbox;
  display: flex;
  height: var(--spectrum-card-body-content-height, var(--spectrum-global-dimension-size-175));
  margin-top: var(--spectrum-card-body-content-margin-top, var(--spectrum-global-dimension-size-75));
}

[dir="ltr"] .spectrum-Card-title {
  padding-right: var(--spectrum-card-title-padding-right, var(--spectrum-global-dimension-size-100));
}

[dir="rtl"] .spectrum-Card-title {
  padding-left: var(--spectrum-card-title-padding-right, var(--spectrum-global-dimension-size-100));
}

.spectrum-Card-title {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

[dir="ltr"] .spectrum-Card-subtitle {
  padding-right: var(--spectrum-card-subtitle-padding-right, var(--spectrum-global-dimension-size-100));
}

[dir="rtl"] .spectrum-Card-subtitle {
  padding-left: var(--spectrum-card-subtitle-padding-right, var(--spectrum-global-dimension-size-100));
}

.spectrum-Card-description {
  font-size: var(--spectrum-card-subtitle-text-size, var(--spectrum-global-dimension-font-size-50));
}

[dir="ltr"] .spectrum-Card-subtitle + .spectrum-Card-description:before {
  padding-right: var(--spectrum-card-subtitle-padding-right, var(--spectrum-global-dimension-size-100));
}

[dir="rtl"] .spectrum-Card-subtitle + .spectrum-Card-description:before {
  padding-left: var(--spectrum-card-subtitle-padding-right, var(--spectrum-global-dimension-size-100));
}

.spectrum-Card-subtitle + .spectrum-Card-description:before {
  content: "•";
}

[dir="ltr"] .spectrum-Card-footer {
  margin-right: var(--spectrum-card-body-padding-right, var(--spectrum-global-dimension-size-300));
}

[dir="rtl"] .spectrum-Card-footer {
  margin-left: var(--spectrum-card-body-padding-right, var(--spectrum-global-dimension-size-300));
}

[dir="ltr"] .spectrum-Card-footer {
  margin-left: var(--spectrum-card-body-padding-left, var(--spectrum-global-dimension-size-300));
}

[dir="rtl"] .spectrum-Card-footer {
  margin-right: var(--spectrum-card-body-padding-left, var(--spectrum-global-dimension-size-300));
}

.spectrum-Card-footer {
  padding-top: var(--spectrum-card-footer-padding-top, var(--spectrum-global-dimension-size-175));
  padding-bottom: var(--spectrum-card-body-padding-bottom, var(--spectrum-global-dimension-size-250));

  border-top: var(--spectrum-card-footer-border-top-size, var(--spectrum-global-dimension-size-10)) solid;
}

.spectrum-Card-header {
  display: -ms-flexbox;
  display: flex;
  -ms-flex-align: baseline;
      align-items: baseline;
}

.spectrum-Card-actionButton {
  -ms-flex: 1;
      flex: 1;
  -ms-flex-item-align: center;
      align-self: center;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-pack: end;
      justify-content: flex-end;
}

.spectrum-Card--quiet .spectrum-Card-preview {
    min-height: var(--spectrum-card-quiet-min-size, var(--spectrum-global-dimension-size-1700));
  }

.spectrum-Card--quiet,
.spectrum-Card--gallery {
  width: 100%;
  height: 100%;
  min-width: var(--spectrum-card-quiet-min-size, var(--spectrum-global-dimension-size-1700));
  border-width: 0;
  border-radius: 0;
  overflow: visible;
}

.spectrum-Card--quiet .spectrum-Card-preview, .spectrum-Card--gallery .spectrum-Card-preview {
    width: 100%;
    -ms-flex: 1;
        flex: 1;
    padding: var(--spectrum-card-quiet-preview-padding, var(--spectrum-global-dimension-size-250));
    margin: 0 auto;
    box-sizing: border-box;
    border-radius: var(--spectrum-card-quiet-border-radius, var(--spectrum-alias-border-radius-regular));
    position: relative;
    transition: background-color var(--spectrum-global-animation-duration-100, 130ms);
    overflow: visible;
  }

[dir="ltr"] .spectrum-Card--quiet .spectrum-Card-preview:before,[dir="ltr"]  .spectrum-Card--gallery .spectrum-Card-preview:before {
      left: 0;
}

[dir="rtl"] .spectrum-Card--quiet .spectrum-Card-preview:before,[dir="rtl"]  .spectrum-Card--gallery .spectrum-Card-preview:before {
      right: 0;
}

.spectrum-Card--quiet .spectrum-Card-preview:before, .spectrum-Card--gallery .spectrum-Card-preview:before {
      content: '';
      position: absolute;
      top: 0;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      border-radius: inherit;
      border: var(--spectrum-card-quiet-border-size, var(--spectrum-alias-border-size-thin)) solid transparent;
    }

.spectrum-Card--quiet.is-drop-target .spectrum-Card-preview, .spectrum-Card--gallery.is-drop-target .spectrum-Card-preview {
      transition: none;
    }

.spectrum-Card--quiet .spectrum-Card-header, .spectrum-Card--gallery .spectrum-Card-header {
    height: var(--spectrum-card-quiet-body-header-height, var(--spectrum-global-dimension-size-225));
    margin-top: var(--spectrum-card-quiet-body-header-margin-top, var(--spectrum-global-dimension-size-175));
  }

.spectrum-Card--quiet .spectrum-Card-body, .spectrum-Card--gallery .spectrum-Card-body {
    padding: 0;
  }

.spectrum-Card--small {
  min-width: var(--spectrum-card-quiet-small-min-size, var(--spectrum-global-dimension-size-900));
}

[dir="ltr"] .spectrum-Card--small .spectrum-Card-quickActions {
    left: var(--spectrum-card-quiet-small-checkbox-margin, var(--spectrum-global-dimension-size-125));
}

[dir="rtl"] .spectrum-Card--small .spectrum-Card-quickActions {
    right: var(--spectrum-card-quiet-small-checkbox-margin, var(--spectrum-global-dimension-size-125));
}

.spectrum-Card--small .spectrum-Card-quickActions {
    top: var(--spectrum-card-quiet-small-checkbox-margin, var(--spectrum-global-dimension-size-125));
  }

.spectrum-Card--small .spectrum-Card-preview {
    padding: var(--spectrum-card-quiet-small-preview-padding, var(--spectrum-global-dimension-size-150));
    min-height: var(--spectrum-card-quiet-small-min-size, var(--spectrum-global-dimension-size-900));
  }

.spectrum-Card--small .spectrum-Card-header {
    margin-top: var(--spectrum-card-quiet-small-body-margin-top, var(--spectrum-global-dimension-size-100));
    height: var(--spectrum-card-quiet-small-body-header-height, var(--spectrum-global-dimension-size-150));
  }

.spectrum-Card--small .spectrum-Card-title {
    font-size: var(--spectrum-card-quiet-small-title-text-size, var(--spectrum-global-dimension-font-size-100));
  }

.spectrum-Card--horizontal {
  -ms-flex-direction: row;
      flex-direction: row;
}

[dir="ltr"] .spectrum-Card--horizontal .spectrum-Card-preview {

    border-top-left-radius: var(--spectrum-card-quiet-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-Card--horizontal .spectrum-Card-preview {

    border-top-right-radius: var(--spectrum-card-quiet-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="ltr"] .spectrum-Card--horizontal .spectrum-Card-preview {
    border-top-right-radius: 0;
}

[dir="rtl"] .spectrum-Card--horizontal .spectrum-Card-preview {
    border-top-left-radius: 0;
}

[dir="ltr"] .spectrum-Card--horizontal .spectrum-Card-preview {
    border-bottom-left-radius: var(--spectrum-card-quiet-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="rtl"] .spectrum-Card--horizontal .spectrum-Card-preview {
    border-bottom-right-radius: var(--spectrum-card-quiet-border-radius, var(--spectrum-alias-border-radius-regular));
}

[dir="ltr"] .spectrum-Card--horizontal .spectrum-Card-preview {
    border-bottom-right-radius: 0;
}

[dir="rtl"] .spectrum-Card--horizontal .spectrum-Card-preview {
    border-bottom-left-radius: 0;
}

[dir="ltr"] .spectrum-Card--horizontal .spectrum-Card-preview {

    border-right: var(--spectrum-card-border-size, var(--spectrum-alias-border-size-thin)) solid transparent;
}

[dir="rtl"] .spectrum-Card--horizontal .spectrum-Card-preview {

    border-left: var(--spectrum-card-border-size, var(--spectrum-alias-border-size-thin)) solid transparent;
}

.spectrum-Card--horizontal .spectrum-Card-preview {
    -ms-flex-negative: 0;
        flex-shrink: 0;
    min-height: 0;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-align: center;
        align-items: center;
    -ms-flex-pack: center;
        justify-content: center;

    padding: var(--spectrum-global-dimension-size-175);
  }

.spectrum-Card--horizontal .spectrum-Card-header,
  .spectrum-Card--horizontal .spectrum-Card-content {
    margin-top: 0;
    height: auto;
  }

[dir="ltr"] .spectrum-Card--horizontal .spectrum-Card-title {
    padding-right: 0;
}

[dir="rtl"] .spectrum-Card--horizontal .spectrum-Card-title {
    padding-left: 0;
}

.spectrum-Card--horizontal .spectrum-Card-body {
    -ms-flex-negative: 0;
        flex-shrink: 0;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-pack: center;
        justify-content: center;
    -ms-flex-direction: column;
        flex-direction: column;

    padding-top: 0;

    padding-bottom: 0;
    padding-left: var(--spectrum-global-dimension-size-200);
    padding-right: var(--spectrum-global-dimension-size-200);
  }

.spectrum-Card--gallery {
  min-width: 0;
}

.spectrum-Card--gallery .spectrum-Card-preview {
    padding: 0;
    border-radius: 0;
  }

.spectrum-Card {
  border-color: var(--spectrum-card-border-color, var(--spectrum-global-color-gray-200));
  background-color: var(--spectrum-card-background-color, var(--spectrum-global-color-gray-50));
}

.spectrum-Card:hover {
    border-color: var(--spectrum-card-border-color-hover, var(--spectrum-global-color-gray-400));
  }

.spectrum-Card.is-selected,
  .spectrum-Card.focus-ring {
    border-color: var(--spectrum-card-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    box-shadow: 0 0 0 1px var(--spectrum-card-border-color-key-focus, var(--spectrum-alias-border-color-focus));
  }

.spectrum-Card.is-drop-target {
    border-color: var(--spectrum-card-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    box-shadow: 0 0 0 1px var(--spectrum-card-border-color-key-focus, var(--spectrum-alias-border-color-focus));
    background-color: var(--spectrum-alias-highlight-selected);
  }

.spectrum-Card .spectrum-Card-subtitle {
    color: var(--spectrum-card-description-text-color, var(--spectrum-global-color-gray-700));
  }

.spectrum-Card-description {
  color: var(--spectrum-card-description-text-color, var(--spectrum-global-color-gray-700));
}

.spectrum-Card-coverPhoto {
  background-color: var(--spectrum-card-coverphoto-background-color, var(--spectrum-global-color-gray-200));
  border-bottom-color: var(--spectrum-card-coverphoto-border-color, var(--spectrum-global-color-gray-200));
}

.spectrum-Card-footer {
  border-color: var(--spectrum-card-border-color, var(--spectrum-global-color-gray-200));
}

.spectrum-Card--quiet,
.spectrum-Card--gallery {
  border-color: transparent;
  background-color: transparent;
}

.spectrum-Card--quiet .spectrum-Card-preview, .spectrum-Card--gallery .spectrum-Card-preview {
    background-color: var(--spectrum-card-quiet-preview-background-color, var(--spectrum-global-color-gray-200));
  }

.spectrum-Card--quiet:hover, .spectrum-Card--gallery:hover {
    border-color: transparent;
  }

.spectrum-Card--quiet:hover .spectrum-Card-preview, .spectrum-Card--gallery:hover .spectrum-Card-preview {
      background-color: var(--spectrum-card-quiet-preview-background-color-hover, var(--spectrum-global-color-gray-300));
    }

.spectrum-Card--quiet.is-selected,
  .spectrum-Card--quiet.focus-ring,
  .spectrum-Card--gallery.is-selected,
  .spectrum-Card--gallery.focus-ring {
    border-color: transparent;
    box-shadow: none;
  }

.spectrum-Card--quiet.is-selected .spectrum-Card-preview, .spectrum-Card--quiet.focus-ring .spectrum-Card-preview, .spectrum-Card--gallery.is-selected .spectrum-Card-preview, .spectrum-Card--gallery.focus-ring .spectrum-Card-preview {
      background-color: var(--spectrum-card-quiet-preview-background-color, var(--spectrum-global-color-gray-200));
    }

.spectrum-Card--quiet.is-selected .spectrum-Card-preview:before, .spectrum-Card--quiet.focus-ring .spectrum-Card-preview:before, .spectrum-Card--gallery.is-selected .spectrum-Card-preview:before, .spectrum-Card--gallery.focus-ring .spectrum-Card-preview:before {
        border-color: var(--spectrum-card-quiet-border-color-selected, var(--spectrum-global-color-blue-500));
        box-shadow: 0 0 0 1px var(--spectrum-card-quiet-border-color-selected, var(--spectrum-global-color-blue-500));
      }

.spectrum-Card--quiet.is-drop-target, .spectrum-Card--gallery.is-drop-target {
    border-color: transparent;
    background-color: transparent;
    box-shadow: none;
  }

.spectrum-Card--quiet.is-drop-target .spectrum-Card-preview, .spectrum-Card--gallery.is-drop-target .spectrum-Card-preview {
      background-color: var(--spectrum-alias-highlight-selected);
    }

.spectrum-Card--quiet.is-drop-target .spectrum-Card-preview:before, .spectrum-Card--gallery.is-drop-target .spectrum-Card-preview:before {
        border-color: var(--spectrum-card-quiet-border-color-selected, var(--spectrum-global-color-blue-500));
        box-shadow: 0 0 0 1px var(--spectrum-card-quiet-border-color-selected, var(--spectrum-global-color-blue-500));
      }

.spectrum-Card--quiet.is-drop-target .spectrum-Asset-folderBackground,
    .spectrum-Card--quiet.is-drop-target .spectrum-Asset-fileBackground,
    .spectrum-Card--gallery.is-drop-target .spectrum-Asset-folderBackground,
    .spectrum-Card--gallery.is-drop-target .spectrum-Asset-fileBackground {
      fill: var(--spectrum-alias-highlight-selected);
    }

.spectrum-Card--quiet.is-drop-target .spectrum-Asset-folderOutline,
    .spectrum-Card--quiet.is-drop-target .spectrum-Asset-fileOutline,
    .spectrum-Card--gallery.is-drop-target .spectrum-Asset-folderOutline,
    .spectrum-Card--gallery.is-drop-target .spectrum-Asset-fileOutline {
      fill: var(--spectrum-card-quiet-border-color-selected, var(--spectrum-global-color-blue-500));
    }

.spectrum-Card--quiet .spectrum-Card-title, .spectrum-Card--gallery .spectrum-Card-title {
    color: var(--spectrum-card-quiet-title-text-color, var(--spectrum-global-color-gray-800));
  }

.spectrum-Card--quiet .spectrum-Card-subtitle, .spectrum-Card--gallery .spectrum-Card-subtitle {
    color: var(--spectrum-card-quiet-subtitle-text-color, var(--spectrum-global-color-gray-700));
  }

.spectrum-Card--horizontal:hover .spectrum-Card-preview {
      border-color: var(--spectrum-card-border-color-hover, var(--spectrum-global-color-gray-400));
    }

.spectrum-Card--horizontal .spectrum-Card-preview {
    background-color: var(--spectrum-card-quiet-preview-background-color, var(--spectrum-global-color-gray-200));

    border-color: var(--spectrum-card-border-color, var(--spectrum-global-color-gray-200));
  }
.spectrum-Card.svelte-1jgsopy.svelte-1jgsopy{width:300px;border-color:var(--spectrum-global-color-gray-300) !important;display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;transition:border-color 130ms ease-out}.spectrum-Card.clickable.svelte-1jgsopy.svelte-1jgsopy:hover{cursor:pointer;border-color:var(--spectrum-global-color-gray-500) !important}.spectrum-Card.horizontal.svelte-1jgsopy.svelte-1jgsopy{flex-direction:row;width:420px}.spectrum-Card-container.svelte-1jgsopy.svelte-1jgsopy{padding:var(--spectrum-global-dimension-size-50) 0}.spectrum-Card-title.link.svelte-1jgsopy.svelte-1jgsopy{transition:color 130ms ease-out}.spectrum-Card-title.link.svelte-1jgsopy.svelte-1jgsopy:hover{cursor:pointer;color:var(--spectrum-link-primary-m-text-color-hover)}.spectrum-Card-subtitle.svelte-1jgsopy.svelte-1jgsopy{text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.spectrum-Card-footer.svelte-1jgsopy.svelte-1jgsopy{word-wrap:break-word;white-space:pre-wrap}.horizontal.svelte-1jgsopy .spectrum-Card-coverPhoto.svelte-1jgsopy{flex:0 0 160px;height:auto;border-bottom-left-radius:calc(
      var(--spectrum-alias-border-radius-regular) - 1px
    );border-top-right-radius:0}.horizontal.svelte-1jgsopy .spectrum-Card-container.svelte-1jgsopy{width:0;flex:1 1 auto}.spectrum-Card-footer.svelte-1jgsopy.svelte-1jgsopy{border-top:none;padding-top:0;padding-bottom:0;margin-top:-8px;margin-bottom:var(
      --spectrum-card-body-padding-bottom,
      var(--spectrum-global-dimension-size-300)
    );display:-webkit-box;line-clamp:2;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;word-break:break-all}.button-container.svelte-1jgsopy.svelte-1jgsopy{margin-bottom:var(--spectrum-global-dimension-size-300)}.spectrum-Tag--sizeS {
  --spectrum-tag-texticon-padding-left: var(--spectrum-tag-s-texticon-padding-left, var(--spectrum-global-dimension-size-85));
  --spectrum-tag-texticon-padding-right: var(--spectrum-tag-s-texticon-padding-right, var(--spectrum-global-dimension-size-115));
  --spectrum-tag-texticon-text-size: var(--spectrum-tag-s-texticon-text-size, var(--spectrum-global-dimension-font-size-75));
  --spectrum-tag-texticon-icon-gap: var(--spectrum-tag-s-texticon-icon-gap, var(--spectrum-global-dimension-size-85));
  --spectrum-tag-texticon-focus-ring-size: var(--spectrum-tag-s-texticon-focus-ring-size, var(--spectrum-alias-focus-ring-size));
  --spectrum-tag-texticon-border-size: var(--spectrum-tag-s-texticon-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-tag-texticon-height: var(--spectrum-tag-s-texticon-height, var(--spectrum-global-dimension-size-300));
}

.spectrum-Tag--sizeM {
  --spectrum-tag-texticon-padding-left: var(--spectrum-tag-m-texticon-padding-left);
  --spectrum-tag-texticon-padding-right: var(--spectrum-tag-m-texticon-padding-right, var(--spectrum-global-dimension-size-150));
  --spectrum-tag-texticon-text-size: var(--spectrum-tag-m-texticon-text-size, var(--spectrum-global-dimension-font-size-100));
  --spectrum-tag-texticon-icon-gap: var(--spectrum-tag-m-texticon-icon-gap, var(--spectrum-global-dimension-size-100));
  --spectrum-tag-texticon-focus-ring-size: var(--spectrum-tag-m-texticon-focus-ring-size, var(--spectrum-alias-focus-ring-size));
  --spectrum-tag-texticon-border-size: var(--spectrum-tag-m-texticon-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-tag-texticon-height: var(--spectrum-tag-m-texticon-height, var(--spectrum-global-dimension-size-400));
}

.spectrum-Tag--sizeL {
  --spectrum-tag-texticon-padding-left: var(--spectrum-tag-l-texticon-padding-left, var(--spectrum-global-dimension-size-160));
  --spectrum-tag-texticon-padding-right: var(--spectrum-tag-l-texticon-padding-right, var(--spectrum-global-dimension-size-185));
  --spectrum-tag-texticon-text-size: var(--spectrum-tag-l-texticon-text-size, var(--spectrum-global-dimension-font-size-200));
  --spectrum-tag-texticon-icon-gap: var(--spectrum-tag-l-texticon-icon-gap, var(--spectrum-global-dimension-size-115));
  --spectrum-tag-texticon-focus-ring-size: var(--spectrum-tag-l-texticon-focus-ring-size, var(--spectrum-alias-focus-ring-size));
  --spectrum-tag-texticon-border-size: var(--spectrum-tag-l-texticon-border-size, var(--spectrum-alias-border-size-thin));
  --spectrum-tag-texticon-height: var(--spectrum-tag-l-texticon-height, var(--spectrum-global-dimension-size-500));
}

.spectrum-Tag {
  --spectrum-tag-texticon-avatar-padding-x: var(--spectrum-tag-texticon-icon-gap);
}

[dir="ltr"] .spectrum-Tag {
  padding-left: calc(var(--spectrum-tag-texticon-padding-left) - var(--spectrum-tag-texticon-border-size));
}

[dir="rtl"] .spectrum-Tag {
  padding-right: calc(var(--spectrum-tag-texticon-padding-left) - var(--spectrum-tag-texticon-border-size));
}

[dir="ltr"] .spectrum-Tag {
  padding-right: calc(var(--spectrum-tag-texticon-padding-right) - var(--spectrum-tag-texticon-border-size));
}

[dir="rtl"] .spectrum-Tag {
  padding-left: calc(var(--spectrum-tag-texticon-padding-right) - var(--spectrum-tag-texticon-border-size));
}

.spectrum-Tag {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-align: center;
      align-items: center;
  box-sizing: border-box;
  vertical-align: bottom;

  padding-top: 0;

  padding-bottom: 0;
  height: var(--spectrum-tag-texticon-height);
  max-width: 100%;

  border-width: var(--spectrum-tag-texticon-border-size);
  border-style: solid;
  border-radius: var(--spectrum-alias-border-radius-regular, var(--spectrum-global-dimension-size-50));
  outline: none;
  -webkit-user-select: none;
      -ms-user-select: none;
          user-select: none;

  transition: border-color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
    color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
    box-shadow var(--spectrum-global-animation-duration-100, 130ms) ease-in-out,
    background-color var(--spectrum-global-animation-duration-100, 130ms) ease-in-out;
}

.spectrum-Tag.is-disabled {
    pointer-events: none;
  }

[dir="ltr"] .spectrum-Tag > .spectrum-Icon,[dir="ltr"] 
  .spectrum-Tag > .spectrum-Avatar {
    margin-right: var(--spectrum-tag-texticon-icon-gap);
}

[dir="rtl"] .spectrum-Tag > .spectrum-Icon,[dir="rtl"] 
  .spectrum-Tag > .spectrum-Avatar {
    margin-left: var(--spectrum-tag-texticon-icon-gap);
}

[dir="ltr"] .spectrum-Tag > .spectrum-Icon,[dir="ltr"] 
  .spectrum-Tag > .spectrum-Avatar {
    margin-left: calc(var(--spectrum-tag-texticon-avatar-padding-x) - var(--spectrum-tag-texticon-padding-left));
}

[dir="rtl"] .spectrum-Tag > .spectrum-Icon,[dir="rtl"] 
  .spectrum-Tag > .spectrum-Avatar {
    margin-right: calc(var(--spectrum-tag-texticon-avatar-padding-x) - var(--spectrum-tag-texticon-padding-left));
}

[dir="ltr"] .spectrum-Tag > .spectrum-Icon ~ .spectrum-Tag-label,[dir="ltr"]  .spectrum-Tag > .spectrum-Avatar ~ .spectrum-Tag-label {
      margin-right: calc(var(--spectrum-tag-texticon-avatar-padding-x) - var(--spectrum-tag-texticon-padding-right));
}

[dir="rtl"] .spectrum-Tag > .spectrum-Icon ~ .spectrum-Tag-label,[dir="rtl"]  .spectrum-Tag > .spectrum-Avatar ~ .spectrum-Tag-label {
      margin-left: calc(var(--spectrum-tag-texticon-avatar-padding-x) - var(--spectrum-tag-texticon-padding-right));
}

[dir="ltr"] .spectrum-Tag .spectrum-ClearButton {
    margin-right: calc(-1 * var(--spectrum-tag-texticon-padding-right));
}

[dir="rtl"] .spectrum-Tag .spectrum-ClearButton {
    margin-left: calc(-1 * var(--spectrum-tag-texticon-padding-right));
}

.spectrum-Tag-label {
  height: 100%;
  line-height: calc(var(--spectrum-tag-texticon-height) - var(--spectrum-tag-texticon-border-size) * 2);
  -ms-flex: 1 1 auto;
      flex: 1 1 auto;
  font-size: var(--spectrum-tag-texticon-text-size);
  cursor: default;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.spectrum-Tag.is-selected.focus-ring:after, .spectrum-Tag.is-selected.is-focused:after {
      box-shadow: 0 0 0 var(--spectrum-tag-texticon-focus-ring-size) var(--spectrum-tag-m-texticon-focus-ring-color-key-focus, var(--spectrum-alias-focus-ring-color));
    }

.spectrum-Tag {
  color: var(--spectrum-tag-s-texticon-text-color, var(--spectrum-alias-label-text-color));
  background-color: var(--spectrum-tag-s-texticon-background-color, var(--spectrum-global-color-gray-75));
  border-color: var(--spectrum-tag-s-texticon-border-color, var(--spectrum-alias-border-color-darker-default));
}

.spectrum-Tag .spectrum-ClearButton {
    color: var(--spectrum-tag-s-removable-texticon-icon-color, var(--spectrum-alias-icon-color));
  }

.spectrum-Tag:hover {
    background-color: var(--spectrum-tag-s-texticon-background-color-hover, var(--spectrum-global-color-gray-75));
    color: var(--spectrum-tag-s-texticon-text-color-hover, var(--spectrum-alias-text-color-hover));
    border-color: var(--spectrum-tag-s-texticon-border-color-hover, var(--spectrum-alias-border-color-darker-hover));
  }

.spectrum-Tag:hover .spectrum-ClearButton {
      color: var(--spectrum-tag-s-removable-texticon-icon-color-hover, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-Tag.focus-ring {
    background-color: var(--spectrum-tag-s-texticon-background-color-key-focus, var(--spectrum-global-color-gray-75));
    border-color: var(--spectrum-tag-s-texticon-border-color-key-focus, var(--spectrum-alias-border-color-key-focus));
    box-shadow: 0 0 0 var(--spectrum-tag-s-texticon-focus-ring-size, var(--spectrum-alias-focus-ring-size)) var(--spectrum-tag-s-texticon-focus-ring-color-key-focus, var(--spectrum-alias-focus-ring-color));
    color: var(--spectrum-tag-s-texticon-text-color-key-focus, var(--spectrum-alias-text-color-hover));

  }

.spectrum-Tag.focus-ring .spectrum-ClearButton {
      color: var(--spectrum-tag-s-removable-texticon-icon-color-key-focus, var(--spectrum-alias-icon-color-key-focus));
    }

.spectrum-Tag.is-selected {
    background-color: var(--spectrum-tag-s-texticon-background-color-selected, var(--spectrum-global-color-gray-700));
    color: var(--spectrum-tag-s-texticon-text-color-selected, var(--spectrum-alias-text-color-overbackground));
    border-color: var(--spectrum-tag-s-texticon-border-color-selected, var(--spectrum-global-color-gray-700));
  }

.spectrum-Tag.is-selected .spectrum-TagIcon {
      color: var(--spectrum-tag-s-texticon-icon-color-selected, var(--spectrum-alias-icon-color-overbackground));
    }

.spectrum-Tag.is-selected .spectrum-ClearButton {
      color: var(--spectrum-tag-s-removable-texticon-icon-color-selected, var(--spectrum-alias-icon-color-overbackground));
    }

.spectrum-Tag.is-selected:hover {
      background-color: var(--spectrum-tag-s-texticon-background-color-selected-hover, var(--spectrum-global-color-gray-800));
    }

.spectrum-Tag.is-selected:hover .spectrum-ClearButton {
        color: var(--spectrum-tag-s-removable-texticon-icon-color-selected-hover, var(--spectrum-alias-icon-color-overbackground));
      }

.spectrum-Tag.is-selected.focus-ring {
      box-shadow: 0 0 0 var(--spectrum-alias-focus-ring-size, var(--spectrum-global-dimension-static-size-25)) var(--spectrum-tag-s-texticon-focus-ring-color-selected-key-focus, var(--spectrum-alias-focus-ring-color));
      border-color: var(--spectrum-tag-s-texticon-text-color-selected-key-focus, var(--spectrum-alias-text-color-overbackground));
    }

.spectrum-Tag.is-selected.focus-ring .spectrum-ClearButton {
        color: var(--spectrum-tag-s-removable-texticon-icon-color-selected-key-focus, var(--spectrum-alias-icon-color-overbackground));
      }

.spectrum-Tag.is-selected.is-invalid {
      border-color: var(--spectrum-tag-s-texticon-border-color-error-selected, var(--spectrum-semantic-negative-background-color-default));
      background-color: var(--spectrum-tag-s-texticon-background-color-error-selected, var(--spectrum-semantic-negative-background-color-default));
    }

.spectrum-Tag.is-selected.is-invalid .spectrum-Tag-icon,
      .spectrum-Tag.is-selected.is-invalid .spectrum-Tag-label,
      .spectrum-Tag.is-selected.is-invalid .spectrum-Tag-clearButton {
        color: var(--spectrum-tag-s-removable-texticon-icon-color-error-selected, var(--spectrum-alias-icon-color-overbackground));
      }

.spectrum-Tag.is-selected.is-invalid.focus-ring {
        box-shadow: 0 0 0 var(--spectrum-alias-focus-ring-size, var(--spectrum-global-dimension-static-size-25)) var(--spectrum-tag-s-texticon-border-color-error-selected-key-focus, var(--spectrum-semantic-negative-background-color-key-focus));
        border-color: var(--spectrum-tag-s-texticon-text-color-selected-key-focus, var(--spectrum-alias-text-color-overbackground));
      }

.spectrum-Tag.is-selected.is-invalid:hover {
        border-color: var(--spectrum-tag-s-texticon-border-color-error-selected-hover, var(--spectrum-semantic-negative-background-color-hover));
        background-color: var(--spectrum-tag-s-texticon-background-color-error-selected-hover, var(--spectrum-semantic-negative-background-color-hover));
      }

.spectrum-Tag.is-selected.is-invalid:hover .spectrum-Tag-icon,
        .spectrum-Tag.is-selected.is-invalid:hover .spectrum-Tag-label,
        .spectrum-Tag.is-selected.is-invalid:hover .spectrum-Tag-clearButton {
          color: var(--spectrum-tag-s-texticon-icon-color-error-selected-hover, var(--spectrum-alias-icon-color-overbackground));
        }

.spectrum-Tag.is-invalid {
    color: var(--spectrum-tag-s-texticon-icon-color-error, var(--spectrum-semantic-negative-icon-color));
    border-color: var(--spectrum-tag-s-texticon-border-color-error, var(--spectrum-semantic-negative-color-default));

  }

.spectrum-Tag.is-invalid:hover {
      color: var(--spectrum-tag-s-texticon-icon-color-error-hover, var(--spectrum-semantic-negative-icon-color));
      border-color: var(--spectrum-tag-s-texticon-border-color-error-hover, var(--spectrum-semantic-negative-color-hover));
    }

.spectrum-Tag.is-invalid:hover .spectrum-Tag-icon,
      .spectrum-Tag.is-invalid:hover .spectrum-Tag-clearButton {
        color: var(--spectrum-tag-s-texticon-icon-color-error-hover, var(--spectrum-semantic-negative-icon-color));
      }

.spectrum-Tag.is-invalid.focus-ring {
      color: var(--spectrum-tag-s-texticon-icon-color-error-hover, var(--spectrum-semantic-negative-icon-color));
      border-color: var(--spectrum-tag-s-texticon-border-color-key-focus, var(--spectrum-alias-border-color-key-focus));
      box-shadow: 0 0 0 var(--spectrum-alias-focus-ring-size, var(--spectrum-global-dimension-static-size-25)) var(--spectrum-tag-s-texticon-border-color-key-focus, var(--spectrum-alias-border-color-key-focus));
    }

.spectrum-Tag.is-invalid .spectrum-Tag-icon,
    .spectrum-Tag.is-invalid .spectrum-Tag-clearButton {
      color: var(--spectrum-tag-s-texticon-icon-color-error, var(--spectrum-semantic-negative-icon-color));
    }

.spectrum-Tag.is-invalid .spectrum-ClearButton {
      color: var(--spectrum-tag-s-removable-texticon-icon-color-error, var(--spectrum-semantic-negative-icon-color));
    }

.spectrum-Tag.is-disabled {
    color: var(--spectrum-tag-s-texticon-text-color-disabled, var(--spectrum-alias-text-color-disabled));
    background-color: var(--spectrum-tag-s-texticon-background-color-disabled, var(--spectrum-alias-background-color-disabled));
    border-color: var(--spectrum-tag-s-texticon-border-color-disabled, var(--spectrum-alias-border-color-disabled));
  }

.spectrum-Tag.is-disabled .spectrum-Avatar {
      opacity: var(--spectrum-avatar-size-100-opacity-disabled, var(--spectrum-global-color-opacity-30));
    }

.spectrum-Tag.is-disabled .spectrum-Tag-icon {
      color: var(--spectrum-tag-s-texticon-icon-color-disabled, var(--spectrum-alias-icon-color-disabled));
    }

.spectrum-Tag.is-disabled .spectrum-ClearButton {
      color: var(--spectrum-tag-s-removable-texticon-icon-color-disabled, var(--spectrum-alias-icon-color-disabled));
    }

.spectrum-Tag--removable:hover {
    color: var(--spectrum-tag-s-removable-texticon-text-color-hover, var(--spectrum-alias-text-color-hover));
  }

.spectrum-Tag--removable:hover .spectrum-ClearButton {
      color: var(--spectrum-tag-s-removable-texticon-icon-color-hover, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-Tag--removable:active {
    color: var(--spectrum-tag-s-removable-texticon-text-color-down, var(--spectrum-alias-text-color-down));
  }

.spectrum-Tag--removable:active .spectrum-ClearButton {
      color: var(--spectrum-tag-s-removable-texticon-icon-color-down, var(--spectrum-alias-icon-color-down));
    }

.spectrum-Tag--removable.is-invalid:hover {
      border-color: var(--spectrum-tag-s-removable-texticon-border-color-error-hover, var(--spectrum-semantic-negative-color-hover));
      color: var(--spectrum-tag-s-removable-texticon-text-color-error-hover, var(--spectrum-semantic-negative-color-down));
    }

.spectrum-Tag--removable.is-invalid:hover .spectrum-ClearButton {
        color: var(--spectrum-tag-s-removable-texticon-icon-color-error-hover, var(--spectrum-semantic-negative-icon-color));
      }

.spectrum-Tag--removable.is-invalid:active {
      border-color: var(--spectrum-tag-s-removable-texticon-border-color-error-down, var(--spectrum-semantic-negative-color-down));
      color: var(--spectrum-tag-s-removable-texticon-text-color-error-down, var(--spectrum-semantic-negative-color-down));
    }

.spectrum-Tag--removable.is-invalid:active .spectrum-ClearButton {
        color: var(--spectrum-tag-s-removable-texticon-icon-color-error-down, var(--spectrum-semantic-negative-icon-color));
      }

.spectrum-Tag--removable.focus-ring {
    color: var(--spectrum-tag-s-removable-texticon-text-color-key-focus, var(--spectrum-alias-text-color-hover));
  }

.spectrum-Tag--removable.focus-ring .spectrum-ClearButton {
      color: var(--spectrum-tag-s-removable-texticon-icon-color-key-focus, var(--spectrum-alias-icon-color-key-focus));
    }

.spectrum-Tag--removable.is-selected {
    color: var(--spectrum-tag-s-removable-texticon-text-color-selected, var(--spectrum-alias-text-color-overbackground));
  }

.spectrum-Tag--removable.is-selected.is-focused {
       color: var(--spectrum-tag-s-removable-texticon-text-color-selected-key-focus, var(--spectrum-alias-text-color-overbackground));
    }

.spectrum-Tag--removable.is-selected .spectrum-Tag-clearButton {
      color: var(--spectrum-tag-s-removable-texticon-button-icon-color-selected, var(--spectrum-alias-icon-color-overbackground));
    }

.spectrum-Tag--removable.is-selected .spectrum-Tag-clearButton:hover {
         color: var(--spectrum-tag-s-removable-texticon-button-icon-color-selected-hover, var(--spectrum-alias-icon-color-overbackground));
      }

.spectrum-Tag--removable.is-selected.is-invalid {
      color: var(--spectrum-tag-s-removable-texticon-text-color-error-key-focus, var(--spectrum-semantic-negative-color-down));
    }

.spectrum-Tag--removable .spectrum-Tag-clearButton.is-focused {
      border-color: var(--spectrum-tag-s-removable-texticon-border-color-key-focus, var(--spectrum-alias-border-color-key-focus));
      background-color: var(--spectrum-tag-s-removable-texticon-button-background-color-key-focus, var(--spectrum-global-color-gray-75));
      color: var(--spectrum-tag-s-removable-texticon-button-icon-color-key-focus, var(--spectrum-alias-icon-color-key-focus));
    }

.spectrum-Tag--removable .spectrum-Tag-clearButton:hover {
      color: var(--spectrum-tag-s-removable-texticon-button-icon-color-hover, var(--spectrum-alias-icon-color-hover));
    }

.spectrum-Tag--removable .spectrum-Tag-clearButton:active {
      background-color: var(--spectrum-tag-s-removable-texticon-button-background-color-hover, var(--spectrum-global-color-gray-75));
    }
.spectrum-Tag--sizeS.svelte-jml011,.spectrum-Tag--sizeM.svelte-jml011{padding:0 var(--spectrum-global-dimension-size-100)}.spectrum-Tag--sizeL.svelte-jml011{padding:0 var(--spectrum-global-dimension-size-150)}.spectrum-Tag-label.svelte-jml011{height:auto}/* required styles */\r
\r
.leaflet-pane,\r
.leaflet-tile,\r
.leaflet-marker-icon,\r
.leaflet-marker-shadow,\r
.leaflet-tile-container,\r
.leaflet-pane > svg,\r
.leaflet-pane > canvas,\r
.leaflet-zoom-box,\r
.leaflet-image-layer,\r
.leaflet-layer {\r
	position: absolute;\r
	left: 0;\r
	top: 0;\r
	}\r
.leaflet-container {\r
	overflow: hidden;\r
	}\r
.leaflet-tile,\r
.leaflet-marker-icon,\r
.leaflet-marker-shadow {\r
	-webkit-user-select: none;\r
	   -moz-user-select: none;\r
	        user-select: none;\r
	  -webkit-user-drag: none;\r
	}\r
/* Prevents IE11 from highlighting tiles in blue */\r
.leaflet-tile::selection {\r
	background: transparent;\r
}\r
/* Safari renders non-retina tile on retina better with this, but Chrome is worse */\r
.leaflet-safari .leaflet-tile {\r
	image-rendering: -webkit-optimize-contrast;\r
	}\r
/* hack that prevents hw layers "stretching" when loading new tiles */\r
.leaflet-safari .leaflet-tile-container {\r
	width: 1600px;\r
	height: 1600px;\r
	-webkit-transform-origin: 0 0;\r
	}\r
.leaflet-marker-icon,\r
.leaflet-marker-shadow {\r
	display: block;\r
	}\r
/* .leaflet-container svg: reset svg max-width decleration shipped in Joomla! (joomla.org) 3.x */\r
/* .leaflet-container img: map is broken in FF if you have max-width: 100% on tiles */\r
.leaflet-container .leaflet-overlay-pane svg {\r
	max-width: none !important;\r
	max-height: none !important;\r
	}\r
.leaflet-container .leaflet-marker-pane img,\r
.leaflet-container .leaflet-shadow-pane img,\r
.leaflet-container .leaflet-tile-pane img,\r
.leaflet-container img.leaflet-image-layer,\r
.leaflet-container .leaflet-tile {\r
	max-width: none !important;\r
	max-height: none !important;\r
	width: auto;\r
	padding: 0;\r
	}\r
\r
.leaflet-container img.leaflet-tile {\r
	/* See: https://bugs.chromium.org/p/chromium/issues/detail?id=600120 */\r
	mix-blend-mode: plus-lighter;\r
}\r
\r
.leaflet-container.leaflet-touch-zoom {\r
	-ms-touch-action: pan-x pan-y;\r
	touch-action: pan-x pan-y;\r
	}\r
.leaflet-container.leaflet-touch-drag {\r
	-ms-touch-action: pinch-zoom;\r
	/* Fallback for FF which doesn't support pinch-zoom */\r
	touch-action: none;\r
	touch-action: pinch-zoom;\r
}\r
.leaflet-container.leaflet-touch-drag.leaflet-touch-zoom {\r
	-ms-touch-action: none;\r
	touch-action: none;\r
}\r
.leaflet-container {\r
	-webkit-tap-highlight-color: transparent;\r
}\r
.leaflet-container a {\r
	-webkit-tap-highlight-color: rgba(51, 181, 229, 0.4);\r
}\r
.leaflet-tile {\r
	filter: inherit;\r
	visibility: hidden;\r
	}\r
.leaflet-tile-loaded {\r
	visibility: inherit;\r
	}\r
.leaflet-zoom-box {\r
	width: 0;\r
	height: 0;\r
	-moz-box-sizing: border-box;\r
	     box-sizing: border-box;\r
	z-index: 800;\r
	}\r
/* workaround for https://bugzilla.mozilla.org/show_bug.cgi?id=888319 */\r
.leaflet-overlay-pane svg {\r
	-moz-user-select: none;\r
	}\r
\r
.leaflet-pane         { z-index: 400; }\r
\r
.leaflet-tile-pane    { z-index: 200; }\r
.leaflet-overlay-pane { z-index: 400; }\r
.leaflet-shadow-pane  { z-index: 500; }\r
.leaflet-marker-pane  { z-index: 600; }\r
.leaflet-tooltip-pane   { z-index: 650; }\r
.leaflet-popup-pane   { z-index: 700; }\r
\r
.leaflet-map-pane canvas { z-index: 100; }\r
.leaflet-map-pane svg    { z-index: 200; }\r
\r
.leaflet-vml-shape {\r
	width: 1px;\r
	height: 1px;\r
	}\r
.lvml {\r
	behavior: url(#default#VML);\r
	display: inline-block;\r
	position: absolute;\r
	}\r
\r
\r
/* control positioning */\r
\r
.leaflet-control {\r
	position: relative;\r
	z-index: 800;\r
	pointer-events: visiblePainted; /* IE 9-10 doesn't have auto */\r
	pointer-events: auto;\r
	}\r
.leaflet-top,\r
.leaflet-bottom {\r
	position: absolute;\r
	z-index: 1000;\r
	pointer-events: none;\r
	}\r
.leaflet-top {\r
	top: 0;\r
	}\r
.leaflet-right {\r
	right: 0;\r
	}\r
.leaflet-bottom {\r
	bottom: 0;\r
	}\r
.leaflet-left {\r
	left: 0;\r
	}\r
.leaflet-control {\r
	float: left;\r
	clear: both;\r
	}\r
.leaflet-right .leaflet-control {\r
	float: right;\r
	}\r
.leaflet-top .leaflet-control {\r
	margin-top: 10px;\r
	}\r
.leaflet-bottom .leaflet-control {\r
	margin-bottom: 10px;\r
	}\r
.leaflet-left .leaflet-control {\r
	margin-left: 10px;\r
	}\r
.leaflet-right .leaflet-control {\r
	margin-right: 10px;\r
	}\r
\r
\r
/* zoom and fade animations */\r
\r
.leaflet-fade-anim .leaflet-popup {\r
	opacity: 0;\r
	-webkit-transition: opacity 0.2s linear;\r
	   -moz-transition: opacity 0.2s linear;\r
	        transition: opacity 0.2s linear;\r
	}\r
.leaflet-fade-anim .leaflet-map-pane .leaflet-popup {\r
	opacity: 1;\r
	}\r
.leaflet-zoom-animated {\r
	-webkit-transform-origin: 0 0;\r
	    -ms-transform-origin: 0 0;\r
	        transform-origin: 0 0;\r
	}\r
svg.leaflet-zoom-animated {\r
	will-change: transform;\r
}\r
\r
.leaflet-zoom-anim .leaflet-zoom-animated {\r
	-webkit-transition: -webkit-transform 0.25s cubic-bezier(0,0,0.25,1);\r
	   -moz-transition:    -moz-transform 0.25s cubic-bezier(0,0,0.25,1);\r
	        transition:         transform 0.25s cubic-bezier(0,0,0.25,1);\r
	}\r
.leaflet-zoom-anim .leaflet-tile,\r
.leaflet-pan-anim .leaflet-tile {\r
	-webkit-transition: none;\r
	   -moz-transition: none;\r
	        transition: none;\r
	}\r
\r
.leaflet-zoom-anim .leaflet-zoom-hide {\r
	visibility: hidden;\r
	}\r
\r
\r
/* cursors */\r
\r
.leaflet-interactive {\r
	cursor: pointer;\r
	}\r
.leaflet-grab {\r
	cursor: -webkit-grab;\r
	cursor:    -moz-grab;\r
	cursor:         grab;\r
	}\r
.leaflet-crosshair,\r
.leaflet-crosshair .leaflet-interactive {\r
	cursor: crosshair;\r
	}\r
.leaflet-popup-pane,\r
.leaflet-control {\r
	cursor: auto;\r
	}\r
.leaflet-dragging .leaflet-grab,\r
.leaflet-dragging .leaflet-grab .leaflet-interactive,\r
.leaflet-dragging .leaflet-marker-draggable {\r
	cursor: move;\r
	cursor: -webkit-grabbing;\r
	cursor:    -moz-grabbing;\r
	cursor:         grabbing;\r
	}\r
\r
/* marker & overlays interactivity */\r
.leaflet-marker-icon,\r
.leaflet-marker-shadow,\r
.leaflet-image-layer,\r
.leaflet-pane > svg path,\r
.leaflet-tile-container {\r
	pointer-events: none;\r
	}\r
\r
.leaflet-marker-icon.leaflet-interactive,\r
.leaflet-image-layer.leaflet-interactive,\r
.leaflet-pane > svg path.leaflet-interactive,\r
svg.leaflet-image-layer.leaflet-interactive path {\r
	pointer-events: visiblePainted; /* IE 9-10 doesn't have auto */\r
	pointer-events: auto;\r
	}\r
\r
/* visual tweaks */\r
\r
.leaflet-container {\r
	background: #ddd;\r
	outline-offset: 1px;\r
	}\r
.leaflet-container a {\r
	color: #0078A8;\r
	}\r
.leaflet-zoom-box {\r
	border: 2px dotted #38f;\r
	background: rgba(255,255,255,0.5);\r
	}\r
\r
\r
/* general typography */\r
.leaflet-container {\r
	font-family: "Helvetica Neue", Arial, Helvetica, sans-serif;\r
	font-size: 12px;\r
	font-size: 0.75rem;\r
	line-height: 1.5;\r
	}\r
\r
\r
/* general toolbar styles */\r
\r
.leaflet-bar {\r
	box-shadow: 0 1px 5px rgba(0,0,0,0.65);\r
	border-radius: 4px;\r
	}\r
.leaflet-bar a {\r
	background-color: #fff;\r
	border-bottom: 1px solid #ccc;\r
	width: 26px;\r
	height: 26px;\r
	line-height: 26px;\r
	display: block;\r
	text-align: center;\r
	text-decoration: none;\r
	color: black;\r
	}\r
.leaflet-bar a,\r
.leaflet-control-layers-toggle {\r
	background-position: 50% 50%;\r
	background-repeat: no-repeat;\r
	display: block;\r
	}\r
.leaflet-bar a:hover,\r
.leaflet-bar a:focus {\r
	background-color: #f4f4f4;\r
	}\r
.leaflet-bar a:first-child {\r
	border-top-left-radius: 4px;\r
	border-top-right-radius: 4px;\r
	}\r
.leaflet-bar a:last-child {\r
	border-bottom-left-radius: 4px;\r
	border-bottom-right-radius: 4px;\r
	border-bottom: none;\r
	}\r
.leaflet-bar a.leaflet-disabled {\r
	cursor: default;\r
	background-color: #f4f4f4;\r
	color: #bbb;\r
	}\r
\r
.leaflet-touch .leaflet-bar a {\r
	width: 30px;\r
	height: 30px;\r
	line-height: 30px;\r
	}\r
.leaflet-touch .leaflet-bar a:first-child {\r
	border-top-left-radius: 2px;\r
	border-top-right-radius: 2px;\r
	}\r
.leaflet-touch .leaflet-bar a:last-child {\r
	border-bottom-left-radius: 2px;\r
	border-bottom-right-radius: 2px;\r
	}\r
\r
/* zoom control */\r
\r
.leaflet-control-zoom-in,\r
.leaflet-control-zoom-out {\r
	font: bold 18px 'Lucida Console', Monaco, monospace;\r
	text-indent: 1px;\r
	}\r
\r
.leaflet-touch .leaflet-control-zoom-in, .leaflet-touch .leaflet-control-zoom-out  {\r
	font-size: 22px;\r
	}\r
\r
\r
/* layers control */\r
\r
.leaflet-control-layers {\r
	box-shadow: 0 1px 5px rgba(0,0,0,0.4);\r
	background: #fff;\r
	border-radius: 5px;\r
	}\r
.leaflet-control-layers-toggle {\r
	background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAQAAAADQ4RFAAACf0lEQVR4AY1UM3gkARTePdvdoTxXKc+qTl3aU5U6b2Kbkz3Gtq3Zw6ziLGNPzrYx7946Tr6/ee/XeCQ4D3ykPtL5tHno4n0d/h3+xfuWHGLX81cn7r0iTNzjr7LrlxCqPtkbTQEHeqOrTy4Yyt3VCi/IOB0v7rVC7q45Q3Gr5K6jt+3Gl5nCoDD4MtO+j96Wu8atmhGqcNGHObuf8OM/x3AMx38+4Z2sPqzCxRFK2aF2e5Jol56XTLyggAMTL56XOMoS1W4pOyjUcGGQdZxU6qRh7B9Zp+PfpOFlqt0zyDZckPi1ttmIp03jX8gyJ8a/PG2yutpS/Vol7peZIbZcKBAEEheEIAgFbDkz5H6Zrkm2hVWGiXKiF4Ycw0RWKdtC16Q7qe3X4iOMxruonzegJzWaXFrU9utOSsLUmrc0YjeWYjCW4PDMADElpJSSQ0vQvA1Tm6/JlKnqFs1EGyZiFCqnRZTEJJJiKRYzVYzJck2Rm6P4iH+cmSY0YzimYa8l0EtTODFWhcMIMVqdsI2uiTvKmTisIDHJ3od5GILVhBCarCfVRmo4uTjkhrhzkiBV7SsaqS+TzrzM1qpGGUFt28pIySQHR6h7F6KSwGWm97ay+Z+ZqMcEjEWebE7wxCSQwpkhJqoZA5ivCdZDjJepuJ9IQjGGUmuXJdBFUygxVqVsxFsLMbDe8ZbDYVCGKxs+W080max1hFCarCfV+C1KATwcnvE9gRRuMP2prdbWGowm1KB1y+zwMMENkM755cJ2yPDtqhTI6ED1M/82yIDtC/4j4BijjeObflpO9I9MwXTCsSX8jWAFeHr05WoLTJ5G8IQVS/7vwR6ohirYM7f6HzYpogfS3R2OAAAAAElFTkSuQmCC);\r
	width: 36px;\r
	height: 36px;\r
	}\r
.leaflet-retina .leaflet-control-layers-toggle {\r
	background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAA0CAQAAABvcdNgAAAEsklEQVR4AWL4TydIhpZK1kpWOlg0w3ZXP6D2soBtG42jeI6ZmQTHzAxiTbSJsYLjO9HhP+WOmcuhciVnmHVQcJnp7DFvScowZorad/+V/fVzMdMT2g9Cv9guXGv/7pYOrXh2U+RRR3dSd9JRx6bIFc/ekqHI29JC6pJ5ZEh1yWkhkbcFeSjxgx3L2m1cb1C7bceyxA+CNjT/Ifff+/kDk2u/w/33/IeCMOSaWZ4glosqT3DNnNZQ7Cs58/3Ce5HL78iZH/vKVIaYlqzfdLu8Vi7dnvUbEza5Idt36tquZFldl6N5Z/POLof0XLK61mZCmJSWjVF9tEjUluu74IUXvgttuVIHE7YxSkaYhJZam7yiM9Pv82JYfl9nptxZaxMJE4YSPty+vF0+Y2up9d3wwijfjZbabqm/3bZ9ecKHsiGmRflnn1MW4pjHf9oLufyn2z3y1D6n8g8TZhxyzipLNPnAUpsOiuWimg52psrTZYnOWYNDTMuWBWa0tJb4rgq1UvmutpaYEbZlwU3CLJm/ayYjHW5/h7xWLn9Hh1vepDkyf7dE7MtT5LR4e7yYpHrkhOUpEfssBLq2pPhAqoSWKUkk7EDqkmK6RrCEzqDjhNDWNE+XSMvkJRDWlZTmCW0l0PHQGRZY5t1L83kT0Y3l2SItk5JAWHl2dCOBm+fPu3fo5/3v61RMCO9Jx2EEYYhb0rmNQMX/vm7gqOEJLcXTGw3CAuRNeyaPWwjR8PRqKQ1PDA/dpv+on9Shox52WFnx0KY8onHayrJzm87i5h9xGw/tfkev0jGsQizqezUKjk12hBMKJ4kbCqGPVNXudyyrShovGw5CgxsRICxF6aRmSjlBnHRzg7Gx8fKqEubI2rahQYdR1YgDIRQO7JvQyD52hoIQx0mxa0ODtW2Iozn1le2iIRdzwWewedyZzewidueOGqlsn1MvcnQpuVwLGG3/IR1hIKxCjelIDZ8ldqWz25jWAsnldEnK0Zxro19TGVb2ffIZEsIO89EIEDvKMPrzmBOQcKQ+rroye6NgRRxqR4U8EAkz0CL6uSGOm6KQCdWjvjRiSP1BPalCRS5iQYiEIvxuBMJEWgzSoHADcVMuN7IuqqTeyUPq22qFimFtxDyBBJEwNyt6TM88blFHao/6tWWhuuOM4SAK4EI4QmFHA+SEyWlp4EQoJ13cYGzMu7yszEIBOm2rVmHUNqwAIQabISNMRstmdhNWcFLsSm+0tjJH1MdRxO5Nx0WDMhCtgD6OKgZeljJqJKc9po8juskR9XN0Y1lZ3mWjLR9JCO1jRDMd0fpYC2VnvjBSEFg7wBENc0R9HFlb0xvF1+TBEpF68d+DHR6IOWVv2BECtxo46hOFUBd/APU57WIoEwJhIi2CdpyZX0m93BZicktMj1AS9dClteUFAUNUIEygRZCtik5zSxI9MubTBH1GOiHsiLJ3OCoSZkILa9PxiN0EbvhsAo8tdAf9Seepd36lGWHmtNANTv5Jd0z4QYyeo/UEJqxKRpg5LZx6btLPsOaEmdMyxYdlc8LMaJnikDlhclqmPiQnTEpLUIZEwkRagjYkEibQErwhkTAKCLQEbUgkzJQWc/0PstHHcfEdQ+UAAAAASUVORK5CYII=);\r
	background-size: 26px 26px;\r
	}\r
.leaflet-touch .leaflet-control-layers-toggle {\r
	width: 44px;\r
	height: 44px;\r
	}\r
.leaflet-control-layers .leaflet-control-layers-list,\r
.leaflet-control-layers-expanded .leaflet-control-layers-toggle {\r
	display: none;\r
	}\r
.leaflet-control-layers-expanded .leaflet-control-layers-list {\r
	display: block;\r
	position: relative;\r
	}\r
.leaflet-control-layers-expanded {\r
	padding: 6px 10px 6px 6px;\r
	color: #333;\r
	background: #fff;\r
	}\r
.leaflet-control-layers-scrollbar {\r
	overflow-y: scroll;\r
	overflow-x: hidden;\r
	padding-right: 5px;\r
	}\r
.leaflet-control-layers-selector {\r
	margin-top: 2px;\r
	position: relative;\r
	top: 1px;\r
	}\r
.leaflet-control-layers label {\r
	display: block;\r
	font-size: 13px;\r
	font-size: 1.08333em;\r
	}\r
.leaflet-control-layers-separator {\r
	height: 0;\r
	border-top: 1px solid #ddd;\r
	margin: 5px -10px 5px -6px;\r
	}\r
\r
/* Default icon URLs */\r
.leaflet-default-icon-path { /* used only in path-guessing heuristic, see L.Icon.Default */\r
	background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAApCAYAAADAk4LOAAAFgUlEQVR4Aa1XA5BjWRTN2oW17d3YaZtr2962HUzbDNpjszW24mRt28p47v7zq/bXZtrp/lWnXr337j3nPCe85NcypgSFdugCpW5YoDAMRaIMqRi6aKq5E3YqDQO3qAwjVWrD8Ncq/RBpykd8oZUb/kaJutow8r1aP9II0WmLKLIsJyv1w/kqw9Ch2MYdB++12Onxee/QMwvf4/Dk/Lfp/i4nxTXtOoQ4pW5Aj7wpici1A9erdAN2OH64x8OSP9j3Ft3b7aWkTg/Fm91siTra0f9on5sQr9INejH6CUUUpavjFNq1B+Oadhxmnfa8RfEmN8VNAsQhPqF55xHkMzz3jSmChWU6f7/XZKNH+9+hBLOHYozuKQPxyMPUKkrX/K0uWnfFaJGS1QPRtZsOPtr3NsW0uyh6NNCOkU3Yz+bXbT3I8G3xE5EXLXtCXbbqwCO9zPQYPRTZ5vIDXD7U+w7rFDEoUUf7ibHIR4y6bLVPXrz8JVZEql13trxwue/uDivd3fkWRbS6/IA2bID4uk0UpF1N8qLlbBlXs4Ee7HLTfV1j54APvODnSfOWBqtKVvjgLKzF5YdEk5ewRkGlK0i33Eofffc7HT56jD7/6U+qH3Cx7SBLNntH5YIPvODnyfIXZYRVDPqgHtLs5ABHD3YzLuespb7t79FY34DjMwrVrcTuwlT55YMPvOBnRrJ4VXTdNnYug5ucHLBjEpt30701A3Ts+HEa73u6dT3FNWwflY86eMHPk+Yu+i6pzUpRrW7SNDg5JHR4KapmM5Wv2E8Tfcb1HoqqHMHU+uWDD7zg54mz5/2BSnizi9T1Dg4QQXLToGNCkb6tb1NU+QAlGr1++eADrzhn/u8Q2YZhQVlZ5+CAOtqfbhmaUCS1ezNFVm2imDbPmPng5wmz+gwh+oHDce0eUtQ6OGDIyR0uUhUsoO3vfDmmgOezH0mZN59x7MBi++WDL1g/eEiU3avlidO671bkLfwbw5XV2P8Pzo0ydy4t2/0eu33xYSOMOD8hTf4CrBtGMSoXfPLchX+J0ruSePw3LZeK0juPJbYzrhkH0io7B3k164hiGvawhOKMLkrQLyVpZg8rHFW7E2uHOL888IBPlNZ1FPzstSJM694fWr6RwpvcJK60+0HCILTBzZLFNdtAzJaohze60T8qBzyh5ZuOg5e7uwQppofEmf2++DYvmySqGBuKaicF1blQjhuHdvCIMvp8whTTfZzI7RldpwtSzL+F1+wkdZ2TBOW2gIF88PBTzD/gpeREAMEbxnJcaJHNHrpzji0gQCS6hdkEeYt9DF/2qPcEC8RM28Hwmr3sdNyht00byAut2k3gufWNtgtOEOFGUwcXWNDbdNbpgBGxEvKkOQsxivJx33iow0Vw5S6SVTrpVq11ysA2Rp7gTfPfktc6zhtXBBC+adRLshf6sG2RfHPZ5EAc4sVZ83yCN00Fk/4kggu40ZTvIEm5g24qtU4KjBrx/BTTH8ifVASAG7gKrnWxJDcU7x8X6Ecczhm3o6YicvsLXWfh3Ch1W0k8x0nXF+0fFxgt4phz8QvypiwCCFKMqXCnqXExjq10beH+UUA7+nG6mdG/Pu0f3LgFcGrl2s0kNNjpmoJ9o4B29CMO8dMT4Q5ox8uitF6fqsrJOr8qnwNbRzv6hSnG5wP+64C7h9lp30hKNtKdWjtdkbuPA19nJ7Tz3zR/ibgARbhb4AlhavcBebmTHcFl2fvYEnW0ox9xMxKBS8btJ+KiEbq9zA4RthQXDhPa0T9TEe69gWupwc6uBUphquXgf+/FrIjweHQS4/pduMe5ERUMHUd9xv8ZR98CxkS4F2n3EUrUZ10EYNw7BWm9x1GiPssi3GgiGRDKWRYZfXlON+dfNbM+GgIwYdwAAAAASUVORK5CYII=);\r
	}\r
\r
\r
/* attribution and scale controls */\r
\r
.leaflet-container .leaflet-control-attribution {\r
	background: #fff;\r
	background: rgba(255, 255, 255, 0.8);\r
	margin: 0;\r
	}\r
.leaflet-control-attribution,\r
.leaflet-control-scale-line {\r
	padding: 0 5px;\r
	color: #333;\r
	line-height: 1.4;\r
	}\r
.leaflet-control-attribution a {\r
	text-decoration: none;\r
	}\r
.leaflet-control-attribution a:hover,\r
.leaflet-control-attribution a:focus {\r
	text-decoration: underline;\r
	}\r
.leaflet-attribution-flag {\r
	display: inline !important;\r
	vertical-align: baseline !important;\r
	width: 1em;\r
	height: 0.6669em;\r
	}\r
.leaflet-left .leaflet-control-scale {\r
	margin-left: 5px;\r
	}\r
.leaflet-bottom .leaflet-control-scale {\r
	margin-bottom: 5px;\r
	}\r
.leaflet-control-scale-line {\r
	border: 2px solid #777;\r
	border-top: none;\r
	line-height: 1.1;\r
	padding: 2px 5px 1px;\r
	white-space: nowrap;\r
	-moz-box-sizing: border-box;\r
	     box-sizing: border-box;\r
	background: rgba(255, 255, 255, 0.8);\r
	text-shadow: 1px 1px #fff;\r
	}\r
.leaflet-control-scale-line:not(:first-child) {\r
	border-top: 2px solid #777;\r
	border-bottom: none;\r
	margin-top: -2px;\r
	}\r
.leaflet-control-scale-line:not(:first-child):not(:last-child) {\r
	border-bottom: 2px solid #777;\r
	}\r
\r
.leaflet-touch .leaflet-control-attribution,\r
.leaflet-touch .leaflet-control-layers,\r
.leaflet-touch .leaflet-bar {\r
	box-shadow: none;\r
	}\r
.leaflet-touch .leaflet-control-layers,\r
.leaflet-touch .leaflet-bar {\r
	border: 2px solid rgba(0,0,0,0.2);\r
	background-clip: padding-box;\r
	}\r
\r
\r
/* popup */\r
\r
.leaflet-popup {\r
	position: absolute;\r
	text-align: center;\r
	margin-bottom: 20px;\r
	}\r
.leaflet-popup-content-wrapper {\r
	padding: 1px;\r
	text-align: left;\r
	border-radius: 12px;\r
	}\r
.leaflet-popup-content {\r
	margin: 13px 24px 13px 20px;\r
	line-height: 1.3;\r
	font-size: 13px;\r
	font-size: 1.08333em;\r
	min-height: 1px;\r
	}\r
.leaflet-popup-content p {\r
	margin: 17px 0;\r
	margin: 1.3em 0;\r
	}\r
.leaflet-popup-tip-container {\r
	width: 40px;\r
	height: 20px;\r
	position: absolute;\r
	left: 50%;\r
	margin-top: -1px;\r
	margin-left: -20px;\r
	overflow: hidden;\r
	pointer-events: none;\r
	}\r
.leaflet-popup-tip {\r
	width: 17px;\r
	height: 17px;\r
	padding: 1px;\r
\r
	margin: -10px auto 0;\r
	pointer-events: auto;\r
\r
	-webkit-transform: rotate(45deg);\r
	   -moz-transform: rotate(45deg);\r
	    -ms-transform: rotate(45deg);\r
	        transform: rotate(45deg);\r
	}\r
.leaflet-popup-content-wrapper,\r
.leaflet-popup-tip {\r
	background: white;\r
	color: #333;\r
	box-shadow: 0 3px 14px rgba(0,0,0,0.4);\r
	}\r
.leaflet-container a.leaflet-popup-close-button {\r
	position: absolute;\r
	top: 0;\r
	right: 0;\r
	border: none;\r
	text-align: center;\r
	width: 24px;\r
	height: 24px;\r
	font: 16px/24px Tahoma, Verdana, sans-serif;\r
	color: #757575;\r
	text-decoration: none;\r
	background: transparent;\r
	}\r
.leaflet-container a.leaflet-popup-close-button:hover,\r
.leaflet-container a.leaflet-popup-close-button:focus {\r
	color: #585858;\r
	}\r
.leaflet-popup-scrolled {\r
	overflow: auto;\r
	}\r
\r
.leaflet-oldie .leaflet-popup-content-wrapper {\r
	-ms-zoom: 1;\r
	}\r
.leaflet-oldie .leaflet-popup-tip {\r
	width: 24px;\r
	margin: 0 auto;\r
\r
	-ms-filter: "progid:DXImageTransform.Microsoft.Matrix(M11=0.70710678, M12=0.70710678, M21=-0.70710678, M22=0.70710678)";\r
	filter: progid:DXImageTransform.Microsoft.Matrix(M11=0.70710678, M12=0.70710678, M21=-0.70710678, M22=0.70710678);\r
	}\r
\r
.leaflet-oldie .leaflet-control-zoom,\r
.leaflet-oldie .leaflet-control-layers,\r
.leaflet-oldie .leaflet-popup-content-wrapper,\r
.leaflet-oldie .leaflet-popup-tip {\r
	border: 1px solid #999;\r
	}\r
\r
\r
/* div icon */\r
\r
.leaflet-div-icon {\r
	background: #fff;\r
	border: 1px solid #666;\r
	}\r
\r
\r
/* Tooltip */\r
/* Base styles for the element that has a tooltip */\r
.leaflet-tooltip {\r
	position: absolute;\r
	padding: 6px;\r
	background-color: #fff;\r
	border: 1px solid #fff;\r
	border-radius: 3px;\r
	color: #222;\r
	white-space: nowrap;\r
	-webkit-user-select: none;\r
	-moz-user-select: none;\r
	-ms-user-select: none;\r
	user-select: none;\r
	pointer-events: none;\r
	box-shadow: 0 1px 3px rgba(0,0,0,0.4);\r
	}\r
.leaflet-tooltip.leaflet-interactive {\r
	cursor: pointer;\r
	pointer-events: auto;\r
	}\r
.leaflet-tooltip-top:before,\r
.leaflet-tooltip-bottom:before,\r
.leaflet-tooltip-left:before,\r
.leaflet-tooltip-right:before {\r
	position: absolute;\r
	pointer-events: none;\r
	border: 6px solid transparent;\r
	background: transparent;\r
	content: "";\r
	}\r
\r
/* Directions */\r
\r
.leaflet-tooltip-bottom {\r
	margin-top: 6px;\r
}\r
.leaflet-tooltip-top {\r
	margin-top: -6px;\r
}\r
.leaflet-tooltip-bottom:before,\r
.leaflet-tooltip-top:before {\r
	left: 50%;\r
	margin-left: -6px;\r
	}\r
.leaflet-tooltip-top:before {\r
	bottom: 0;\r
	margin-bottom: -12px;\r
	border-top-color: #fff;\r
	}\r
.leaflet-tooltip-bottom:before {\r
	top: 0;\r
	margin-top: -12px;\r
	margin-left: -6px;\r
	border-bottom-color: #fff;\r
	}\r
.leaflet-tooltip-left {\r
	margin-left: -6px;\r
}\r
.leaflet-tooltip-right {\r
	margin-left: 6px;\r
}\r
.leaflet-tooltip-left:before,\r
.leaflet-tooltip-right:before {\r
	top: 50%;\r
	margin-top: -6px;\r
	}\r
.leaflet-tooltip-left:before {\r
	right: 0;\r
	margin-right: -12px;\r
	border-left-color: #fff;\r
	}\r
.leaflet-tooltip-right:before {\r
	left: 0;\r
	margin-left: -12px;\r
	border-right-color: #fff;\r
	}\r
\r
/* Printing */\r
\r
@media print {\r
	/* Prevent printers from removing background-images of controls. */\r
	.leaflet-control {\r
		-webkit-print-color-adjust: exact;\r
		print-color-adjust: exact;\r
		}\r
	}\r
.embedded-map-wrapper.svelte-1kf8258{background-color:#f1f1f1;height:320px}.map-default.svelte-1kf8258{min-height:180px;min-width:200px}.embedded-map.svelte-1kf8258 a.map-svg-button{display:flex;justify-content:center;align-items:center}.embedded-map.svelte-1kf8258 .leaflet-top,.embedded-map.svelte-1kf8258 .leaflet-bottom{z-index:998}.embedded-map.svelte-1kf8258 .embedded-map-marker{color:#ee3b35}.embedded-map.svelte-1kf8258 .embedded-map-marker--candidate{color:var(--primaryColor)}.embedded-map.svelte-1kf8258 .embedded-map-control{font-size:22px}.embedded-map.svelte-1kf8258{height:100%;width:100%}.button-container.svelte-1kf8258{display:flex;flex-direction:row;justify-content:center;align-items:center;gap:var(--spacing-xl);margin-top:var(--spacing-xl)}.side-panel.svelte-l1y86g{flex:1 1 auto;display:none;flex-direction:column;justify-content:flex-start;align-items:stretch;gap:var(--spacing-xl)}.side-panel.open.svelte-l1y86g{display:flex}.side-panel.svelte-l1y86g .component > *{max-width:100%}.modal-content.svelte-3ffq1h{display:flex;flex-direction:column;max-width:100%;box-sizing:border-box;padding:12px 0px 40px}.small.svelte-3ffq1h{width:400px;min-height:200px}.medium.svelte-3ffq1h{width:600px;min-height:400px}.large.svelte-3ffq1h{width:800px;min-height:600px}.fullscreen.svelte-3ffq1h{width:calc(100vw - 80px);min-height:calc(100vh - 80px)}.modal-header.svelte-3ffq1h{display:flex;flex-direction:row;justify-content:flex-end;flex-shrink:0;flex-grow:0;padding:0 12px 12px;box-sizing:border-box}.modal-main.svelte-3ffq1h{padding:0 40px;flex-grow:1;display:flex;flex-direction:column}.modal-main.svelte-3ffq1h .component > *{max-width:100%}.modal-main-inner.svelte-3ffq1h{flex-grow:1;display:flex;flex-direction:column;word-break:break-word}.modal-main-inner.svelte-3ffq1h:empty{border-radius:3px;border:2px dashed var(--spectrum-global-color-gray-400)}div.svelte-1yk90l6{display:flex;flex-direction:column;align-items:stretch;border:1px solid var(--spectrum-global-color-gray-200);border-radius:4px;overflow:hidden;height:410px}div.in-builder.svelte-1yk90l6 > *{pointer-events:none !important}div.svelte-rl4qpz img{max-width:100%}div.svelte-rl4qpz .editor-preview-full{height:auto}div.svelte-rl4qpz h1,div.svelte-rl4qpz h2,div.svelte-rl4qpz h3,div.svelte-rl4qpz h4,div.svelte-rl4qpz h5,div.svelte-rl4qpz h6{font-weight:600}div.svelte-rl4qpz h1{font-size:1.8em}.operator.svelte-y8gc31{display:flex}.operator.svelte-y8gc31 .spectrum-Picker{height:auto}.filter-popover.svelte-y8gc31{background-color:var(--spectrum-alias-background-color-primary)}.filter-popover-body.svelte-y8gc31{padding:var(--spacing-m);display:flex;flex-direction:column;align-items:stretch;gap:var(--spacing-m)}.toggle-wrap.svelte-1ohvvxo.svelte-1ohvvxo{z-index:1}.filter-button-wrap.inactive.svelte-1ohvvxo .spectrum-Button.svelte-1ohvvxo .icon{color:var(--grey-6)}.spectrum-Button.svelte-1ohvvxo.svelte-1ohvvxo{position:relative;display:flex;gap:var(--spacing-xs)}.spectrum-Button--sizeM.svelte-1ohvvxo.svelte-1ohvvxo,.spectrum-Button--sizeL.svelte-1ohvvxo.svelte-1ohvvxo{gap:var(--spacing-s)}.spectrum-Button--sizeL.svelte-1ohvvxo.svelte-1ohvvxo{padding-left:calc(1em * 0.9);padding-right:calc(1em * 0.9)}.spectrum-Button.is-disabled.svelte-1ohvvxo.svelte-1ohvvxo{cursor:default}.filter-button-wrap.inactive.svelte-1ohvvxo .spectrum-Button.svelte-1ohvvxo{background:var(--spectrum-global-color-gray-50);border:1px dashed var(--spectrum-global-color-gray-200)}.spectrum-Button-label.truncate.svelte-1ohvvxo.svelte-1ohvvxo{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px}.spectrum-Button-label.svelte-1ohvvxo .display.svelte-1ohvvxo{color:var(--spectrum-global-color-blue-600)}.spectrum-Button--secondary.new-styles.svelte-1ohvvxo.svelte-1ohvvxo{background:var(--spectrum-global-color-gray-200);border:none;border-color:transparent;color:var(--spectrum-global-color-gray-900)}.spectrum-Button--secondary.new-styles.svelte-1ohvvxo.svelte-1ohvvxo:not(.is-disabled):hover{background:var(--spectrum-global-color-gray-300)}.spectrum-Button--secondary.new-styles.is-disabled.svelte-1ohvvxo.svelte-1ohvvxo{color:var(--spectrum-global-color-gray-500)}.spectrum-Button.svelte-1ohvvxo .spectrum-Button-label.svelte-1ohvvxo{padding:0px}.filters.svelte-u18njk{display:flex;gap:var(--spacing-m)}.grid.svelte-ch5mko,.underlay-h.svelte-ch5mko,.underlay-v.svelte-ch5mko{height:var(--height) !important;min-height:var(--min-height) !important;max-height:none !important;display:grid;gap:0;grid-template-rows:repeat(var(--rows), calc(var(--row-size) * 1px));grid-template-columns:repeat(var(--cols), calc(var(--col-size) * 1px));position:relative}.clickable.svelte-ch5mko{cursor:pointer}.underlay-h.svelte-ch5mko,.underlay-v.svelte-ch5mko{z-index:0;display:none;position:absolute;top:0;left:0;width:100%;height:100%;opacity:0.1;pointer-events:none}.placeholder-h.svelte-ch5mko{border-bottom:1px solid var(--spectrum-global-color-gray-900);grid-column:1 / -1}.placeholder-h.svelte-ch5mko:first-child{border-top:1px solid var(--spectrum-global-color-gray-900)}.placeholder-v.svelte-ch5mko{border-right:1px solid var(--spectrum-global-color-gray-900);grid-row:1 / -1}.placeholder-v.svelte-ch5mko:first-child{border-left:1px solid var(--spectrum-global-color-gray-900)}.grid.highlight > .underlay-h,.grid.highlight > .underlay-v{display:grid}.grid.highlight > .component:not(.dragging){outline:2px solid var(--spectrum-global-color-static-blue-200);pointer-events:none !important}.grid.highlight > .component.dragging{z-index:999 !important}.grid.svelte-ch5mko > .component:not(.ignores-layout){display:flex;overflow:auto;pointer-events:all;position:relative;padding:calc(var(--grid-spacing) * 1px);margin:calc(var(--grid-spacing) * 1px);--col-start:var(--grid-desktop-col-start, var(--grid-mobile-col-start));--col-end:var(--grid-desktop-col-end, var(--grid-mobile-col-end));--row-start:var(--grid-desktop-row-start, var(--grid-mobile-row-start));--row-end:var(--grid-desktop-row-end, var(--grid-mobile-row-end));--h-align:var(--grid-desktop-h-align, var(--grid-mobile-h-align));--v-align:var(--grid-desktop-v-align, var(--grid-mobile-v-align));grid-column-start:min(max(1, var(--col-start)), var(--cols)) !important;grid-column-end:min(
      max(2, var(--col-end)),
      calc(var(--cols) + 1)
    ) !important;grid-row-start:max(1, var(--row-start)) !important;grid-row-end:max(2, var(--row-end)) !important;flex-direction:column;align-items:var(--h-align);justify-content:var(--v-align)}.grid.mobile.svelte-ch5mko > .component{--col-start:var(--grid-mobile-col-start, var(--grid-desktop-col-start));--col-end:var(--grid-mobile-col-end, var(--grid-desktop-col-end));--row-start:var(--grid-mobile-row-start, var(--grid-desktop-row-start));--row-end:var(--grid-mobile-row-end, var(--grid-desktop-row-end));--h-align:var(--grid-mobile-h-align, var(--grid-desktop-h-align));--v-align:var(--grid-mobile-v-align, var(--grid-desktop-v-align))}.grid.svelte-ch5mko > .component > *{flex:0 0 auto !important}.grid.svelte-ch5mko:not(.mobile) > .component[data-grid-desktop-v-align="stretch"] > *{flex:1 1 0 !important;height:0 !important}.grid.mobile.svelte-ch5mko > .component[data-grid-mobile-v-align="stretch"] > *{flex:1 1 0 !important;height:0 !important}.grid.svelte-ch5mko > .component > img{object-fit:contain;max-height:100%}.flex-container.svelte-h3y7aq{display:flex;max-width:100%}.flex-container.svelte-h3y7aq .component > *{max-width:100%}.direction-row.svelte-h3y7aq{flex-direction:row}.direction-column.svelte-h3y7aq{flex-direction:column}.direction-row.svelte-h3y7aq > .component > .size-grow{width:0}.size-shrink.svelte-h3y7aq{flex:0 1 auto}.size-grow.svelte-h3y7aq{flex:1 1 auto}.direction-row.hAlign-left.svelte-h3y7aq,.direction-column.vAlign-top.svelte-h3y7aq{justify-content:flex-start}.direction-row.hAlign-center.svelte-h3y7aq,.direction-column.vAlign-middle.svelte-h3y7aq{justify-content:center}.direction-row.hAlign-right.svelte-h3y7aq,.direction-column.vAlign-bottom.svelte-h3y7aq{justify-content:flex-end}.direction-row.hAlign-stretch.svelte-h3y7aq,.direction-column.vAlign-stretch.svelte-h3y7aq{justify-content:space-between}.direction-row.vAlign-top.svelte-h3y7aq,.direction-column.hAlign-left.svelte-h3y7aq{align-items:flex-start}.direction-row.vAlign-middle.svelte-h3y7aq,.direction-column.hAlign-center.svelte-h3y7aq{align-items:center}.direction-row.vAlign-bottom.svelte-h3y7aq,.direction-column.hAlign-right.svelte-h3y7aq{align-items:flex-end}.direction-row.vAlign-stretch.svelte-h3y7aq,.direction-column.hAlign-stretch.svelte-h3y7aq{align-items:stretch}.gap-S.svelte-h3y7aq{gap:8px}.gap-M.svelte-h3y7aq{gap:16px}.gap-L.svelte-h3y7aq{gap:32px}.wrap.svelte-h3y7aq{flex-wrap:wrap}.clickable.svelte-h3y7aq{cursor:pointer}.clickable.svelte-h3y7aq *{pointer-events:none}div.svelte-1ccs8qd{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch}.overall.svelte-1foui59.svelte-1foui59{display:flex;flex-direction:row;justify-content:center}.qr-value.svelte-1foui59.svelte-1foui59{word-wrap:break-word;overflow-wrap:break-word;text-align:center}.qr-container.svelte-1foui59.svelte-1foui59{display:flex;flex-direction:column;align-items:center}.barcode-container.svelte-1foui59.svelte-1foui59{max-width:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;overflow:hidden;padding:12px;background-color:white}.logo-and-barcode.svelte-1foui59.svelte-1foui59{display:flex;flex-direction:row;align-items:center;justify-content:center;overflow:hidden}.logo-and-barcode.svelte-1foui59 img.svelte-1foui59{margin-left:10px}.barcode-value.svelte-1foui59 p.svelte-1foui59{margin:0;color:black}.nav.svelte-1ggxdm7.svelte-1ggxdm7{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch}.nav__top.svelte-1ggxdm7.svelte-1ggxdm7{display:flex;flex-direction:row;justify-content:space-between;align-items:center;margin-bottom:40px}.nav__top.svelte-1ggxdm7 img.svelte-1ggxdm7{margin-right:16px}.nav__menu.svelte-1ggxdm7.svelte-1ggxdm7{display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:16px}.nav__menu > a{font-size:1.5em;text-decoration:none}.container.svelte-140q71n{height:100%;max-width:var(--cardWidth);display:flex !important;text-align:left}.image.svelte-140q71n{width:var(--imageWidth);height:var(--imageHeight);vertical-align:middle}.content.svelte-140q71n{display:flex;flex-direction:column;justify-content:space-between;width:100%;padding:0.85rem 1.5rem}.heading.svelte-140q71n{font-size:1rem;font-weight:700;margin:0;white-space:pre-wrap}.text.svelte-140q71n{font-size:0.85rem;margin:0.5rem 0 0 0;font-weight:400;line-height:1.25rem;white-space:pre-wrap}footer.svelte-140q71n{display:flex;justify-content:space-between;align-items:baseline}.subtext.svelte-140q71n{font-size:0.85rem;margin:0;font-weight:400;color:#757575;white-space:pre-wrap}a.svelte-140q71n{margin:0.5rem 0 0 0;text-decoration:none;color:var(--linkColor);font-weight:600;font-size:0.85rem;white-space:pre-wrap}a.svelte-140q71n:hover{color:var(--linkHoverColor)}div.svelte-16hk7sb{color:var(--spectrum-global-color-gray-600);font-size:var(--font-size-s)}button.svelte-1033xd6{width:fit-content;width:-moz-fit-content;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}button.custom.svelte-1033xd6{transition:filter 130ms ease-out;border-width:0}button.custom.svelte-1033xd6:hover{filter:brightness(1.1)}.spectrum-Button--overBackground.svelte-1033xd6:hover{color:#555}.spectrum-Button.svelte-1033xd6::after{display:none}.active.svelte-1033xd6{color:var(--spectrum-global-color-blue-600)}.gap-S.svelte-1033xd6{gap:8px}.gap-M.svelte-1033xd6{gap:16px}.gap-L.svelte-1033xd6{gap:32px}.form-block .spectrum-Form-item.span-2{grid-column:span 2}.form-block .spectrum-Form-item.span-3{grid-column:span 3}.form-block .spectrum-Form-item.span-6{grid-column:span 6}.spectrum-Form-item.above.svelte-87iude.svelte-87iude{display:flex;flex-direction:column}label.svelte-87iude.svelte-87iude{word-wrap:break-word}label.hidden.svelte-87iude.svelte-87iude{padding:0}.spectrum-Form-itemField.svelte-87iude.svelte-87iude{position:relative;width:100%}.error.svelte-87iude svg,.helpText.svelte-87iude svg{width:13px;margin-right:6px}.error.svelte-87iude.svelte-87iude{display:flex;margin-top:var(--spectrum-global-dimension-size-75);align-items:center}.error.svelte-87iude svg{color:var(
      --spectrum-semantic-negative-color-default,
      var(--spectrum-global-color-red-500)
    )}.error.svelte-87iude span.svelte-87iude{color:var(
      --spectrum-semantic-negative-color-default,
      var(--spectrum-global-color-red-500)
    );font-size:var(--spectrum-global-dimension-font-size-75)}.helpText.svelte-87iude.svelte-87iude{display:flex;margin-top:var(--spectrum-global-dimension-size-75);align-items:center}.helpText.svelte-87iude svg{color:var(--spectrum-global-color-gray-600)}.helpText.svelte-87iude span.svelte-87iude{color:var(--spectrum-global-color-gray-800);font-size:var(--spectrum-global-dimension-font-size-75)}.spectrum-FieldLabel--right.svelte-87iude.svelte-87iude,.spectrum-FieldLabel--left.svelte-87iude.svelte-87iude{padding-right:var(--spectrum-global-dimension-size-200)}.readonly.svelte-87iude.svelte-87iude{pointer-events:none}a.svelte-scr5w{text-decoration:none;color:inherit;cursor:pointer}.container.svelte-scr5w{padding:1rem 1.5rem;min-height:3rem;display:block;align-items:flex-start}.stackedlist.svelte-scr5w{display:flex;flex-direction:row;overflow:hidden;max-width:100%}.subheading.svelte-scr5w{opacity:0.6;white-space:pre-wrap}.content.svelte-scr5w{min-width:0;max-width:100%;flex:1 1 auto}.heading.svelte-scr5w{font-weight:600;white-space:pre-wrap}.image-block.svelte-scr5w{display:flex;flex:0 0 auto;margin-right:1.5rem;color:inherit;text-decoration:none}.image.svelte-scr5w{display:block;overflow:hidden;width:3rem;max-width:100%;-webkit-user-select:none;user-select:none;border-radius:99px}.container.svelte-9mr74r{width:var(--cardWidth);overflow:hidden !important;height:auto}.image.svelte-9mr74r{width:100% !important;max-width:100%;height:var(--imageHeight);vertical-align:middle}.content.svelte-9mr74r{padding:1.5rem;display:flex;flex-direction:column;gap:1rem}.heading.svelte-9mr74r{font-size:1.25rem;font-weight:700;margin:0;white-space:pre-wrap}.text.svelte-9mr74r{font-size:1rem;margin:0;font-weight:400;line-height:1.5rem;white-space:pre-wrap}a.svelte-9mr74r{margin:0.5rem 0;text-decoration:none;color:var(--linkColor);font-weight:600;white-space:pre-wrap}a.svelte-9mr74r:hover{color:var(--linkHoverColor)}div.svelte-4l2zvi{display:grid;--gap:16px;grid-gap:var(--gap)}.mainSidebar.svelte-4l2zvi{grid-template-columns:calc((100% - var(--gap)) / 4 * 3) /* 75% */
      calc((100% - var(--gap)) / 4)}.sidebarMain.svelte-4l2zvi{grid-template-columns:calc((100% - var(--gap)) / 4) /* 25% */
      calc((100% - var(--gap)) / 4 * 3)}.oneColumn.svelte-4l2zvi,.columns-1.svelte-4l2zvi{grid-template-columns:1fr}.twoColumns.svelte-4l2zvi,.columns-2.svelte-4l2zvi{grid-template-columns:repeat(2, calc((100% - var(--gap)) / 2))}.threeColumns.svelte-4l2zvi{grid-template-columns:repeat(3, calc((100% - var(--gap)) / 3))}.placeholder.svelte-4l2zvi{border:2px dashed var(--spectrum-global-color-gray-600);padding:var(--spacing-l)}p.svelte-1bo4sd3{display:inline-block;white-space:pre-wrap;margin:0}.placeholder.svelte-1bo4sd3{font-style:italic;color:var(--spectrum-global-color-gray-600)}.bold.svelte-1bo4sd3{font-weight:600}.italic.svelte-1bo4sd3{font-style:italic}.underline.svelte-1bo4sd3{text-decoration:underline}.align--left.svelte-1bo4sd3{text-align:left}.align--center.svelte-1bo4sd3{text-align:center}.align--right.svelte-1bo4sd3{text-align:right}.align--justify.svelte-1bo4sd3{text-align:justify}h1.svelte-7cr7ya{white-space:pre-wrap;font-weight:600}.placeholder.svelte-7cr7ya{font-style:italic;color:var(--spectrum-global-color-gray-600)}.bold.svelte-7cr7ya{font-weight:700}.italic.svelte-7cr7ya{font-style:italic}.underline.svelte-7cr7ya{text-decoration:underline}.align--left.svelte-7cr7ya{text-align:left}.align--center.svelte-7cr7ya{text-align:center}.align--right.svelte-7cr7ya{text-align:right}.align-justify.svelte-7cr7ya{text-align:justify}.fields.svelte-1gdgv0g{display:grid;grid-template-columns:repeat(6, 1fr);gap:8px 16px}.fields.mobile.svelte-1gdgv0g .spectrum-Form-item{grid-column:span 6 !important}.fields.svelte-1gdgv0g{display:grid;grid-template-columns:repeat(6, 1fr);gap:8px 16px}.fields.mobile.svelte-1gdgv0g .spectrum-Form-item{grid-column:span 6 !important}.hide.svelte-sniduo{display:none}div.svelte-sniduo .apexcharts-legend-series{display:flex !important;text-transform:capitalize}div.svelte-sniduo .apexcharts-text.apexcharts-xaxis-title-text,div.svelte-sniduo .apexcharts-text.apexcharts-yaxis-title-text,div.svelte-sniduo .apexcharts-text.apexcharts-xaxis-label,div.svelte-sniduo .apexcharts-text.apexcharts-yaxis-label,div.svelte-sniduo .apexcharts-title-text{fill:var(--spectrum-global-color-gray-600)}div.svelte-sniduo .apexcharts-gridline{stroke:var(--spectrum-global-color-gray-600)}div.svelte-sniduo .apexcharts-legend-text{color:var(--spectrum-global-color-gray-700) !important}div.svelte-sniduo .apexcharts-datalabel{fill:white}div.svelte-sniduo .apexcharts-tooltip{background-color:var(--spectrum-global-color-gray-200) !important;border-color:var(--spectrum-global-color-gray-300) !important;box-shadow:2px 2px 6px -4px rgba(0, 0, 0, 0.1) !important}div.svelte-sniduo .apexcharts-tooltip-title{background-color:var(--spectrum-global-color-gray-100) !important;border-color:var(--spectrum-global-color-gray-300) !important}div.svelte-sniduo .apexcharts-theme-dark .apexcharts-tooltip-text{color:white}div.svelte-sniduo 
      .apexcharts-theme-dark .apexcharts-tooltip-series-group.apexcharts-active
    {padding-bottom:0}.component-placeholder.svelte-sniduo{display:flex;flex-direction:row;justify-content:flex-start;align-items:center;color:var(--spectrum-global-color-gray-600);font-size:var(--font-size-s);padding:var(--spacing-xs);gap:var(--spacing-s)}.component-placeholder.svelte-sniduo mark{background-color:var(--spectrum-global-color-gray-400);padding:0 4px;border-radius:2px}.component-placeholder.svelte-sniduo .spectrum-Link{cursor:pointer}.wrapper.svelte-ct1cyj{width:100%;position:relative}.spectrum-Form.svelte-ct1cyj{width:100%}.spectrum-Form--labelsAbove.svelte-ct1cyj{gap:var(--spectrum-global-dimension-size-100)}.spectrum-Form-itemField .spectrum-Textfield--multiline{min-height:calc(var(--height) - 24px)}
    .spectrum-Form--labelsAbove
      .spectrum-Form-itemField
      .spectrum-Textfield--multiline
  {min-height:calc(var(--height) - 24px)}.content.builder.svelte-1f67xpj .spectrum-Dropzone{pointer-events:none}.content.svelte-1f67xpj{position:relative}.overlay.svelte-1f67xpj,.loading.svelte-1f67xpj{position:absolute;top:0;height:100%;width:100%;display:grid;place-items:center}.overlay.svelte-1f67xpj{background-color:var(--spectrum-global-color-gray-50);opacity:0.5}#reader.svelte-1jyd4la video{border-radius:4px;border:2px solid var(--spectrum-global-color-gray-300);overflow:hidden}.field-display.svelte-1jyd4la .spectrum-Tags-item{margin:0px}.footer-buttons.svelte-1jyd4la{display:flex;grid-area:buttonGroup;gap:var(--spectrum-global-dimension-static-size-200)}.scanner-value.svelte-1jyd4la{display:flex}.field-display.svelte-1jyd4la{padding-top:var(
      --spectrum-fieldlabel-side-m-padding-top,
      var(--spectrum-global-dimension-size-100)
    );margin-bottom:var(--spacing-m)}.camera-placeholder.svelte-1jyd4la{display:flex;align-items:center;justify-content:center;border-radius:4px;border:2px solid var(--spectrum-global-color-gray-300);background-color:var(--spectrum-global-color-gray-200);flex-direction:column;gap:var(--spectrum-global-dimension-static-size-200)}.container.svelte-1jyd4la,.camera-placeholder.svelte-1jyd4la{width:100%;min-height:240px}.manual-input.svelte-1jyd4la{padding-bottom:var(--spacing-m)}.signature-field.svelte-1v3n4b5{min-height:50px;justify-content:center;width:100%;display:flex;flex-direction:column;background-color:var(--spectrum-global-color-gray-50);box-sizing:border-box;border:var(--spectrum-alias-border-size-thin)
      var(--spectrum-alias-border-color) solid;border-radius:var(--spectrum-alias-border-radius-regular)}.rating-container.svelte-1sxxz0v{display:inline-flex;align-items:center;flex-wrap:nowrap;overflow:hidden}.rating-icon-wrapper.svelte-1sxxz0v{cursor:pointer;display:flex;align-items:center;background:none;border:none;flex:0 0 auto}.rating-icon-wrapper.disabled.svelte-1sxxz0v{cursor:default;opacity:0.75}.icon-container.svelte-1sxxz0v{position:relative;display:flex;align-items:center;justify-content:center}.icon-container.hover-preview.svelte-1sxxz0v i{opacity:0.2;filter:contrast(0.5)}.wrapper.svelte-jaf3i5{width:100%;height:100%;padding:64px;display:flex;flex-direction:row;justify-content:center;align-items:flex-start}.container.svelte-jaf3i5{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;width:595.28pt;gap:var(--spacing-xl);align-self:center}.title.svelte-jaf3i5{display:flex;flex-direction:row;justify-content:space-between;align-items:center}.page.svelte-jaf3i5{width:595.28pt;min-height:var(--height);padding:var(--margin);background-color:white;flex:0 0 auto;display:flex;justify-content:flex-start;align-items:stretch;box-shadow:2px 2px 10px 0 rgba(0, 0, 0, 0.1);flex-direction:column;margin:0 auto;position:relative}.pageContent.svelte-jaf3i5{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;background:white}.divider.svelte-jaf3i5{width:100%;height:2px;background:var(--spectrum-global-color-static-gray-400);position:absolute;left:0;top:var(--top);transform:translateY(-50%)}.divider.last.svelte-jaf3i5{top:calc(var(--top) + var(--margin));background:transparent}.vars.svelte-y4fs9{display:contents;--border-color:var(--spectrum-global-color-gray-300)}.table.svelte-y4fs9{display:grid;grid-template-columns:repeat(var(--cols), minmax(40px, auto));grid-template-rows:repeat(var(--rows), max-content);overflow:hidden;background:var(--spectrum-global-color-gray-50)}.table.valid.svelte-y4fs9{border-left:1px solid var(--border-color);border-top:1px solid var(--border-color)}.cell.svelte-y4fs9{border-right:1px solid var(--border-color);border-bottom:1px solid var(--border-color);padding:var(--spacing-xs) var(--spacing-s);overflow:hidden;word-break:break-word;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;line-clamp:3}.cell.header.svelte-y4fs9{font-weight:600}div.svelte-9e4ofs{background-color:var(--spectrum-alias-background-color-secondary)}.row-count.svelte-9e4ofs{margin-top:var(--spacing-l)}`));
      document.head.appendChild(elementStyle);
    }
  } catch (e) {
    console.error("vite-plugin-css-injected-by-js", e);
  }
})();
import "./chunks/index-a0738cd3.js";
