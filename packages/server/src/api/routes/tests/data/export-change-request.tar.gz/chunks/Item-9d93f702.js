import { S as SvelteComponent, i as init, s as safe_not_equal, F as create_slot, e as element, b as attr, f as insert, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, k as transition_in, n as transition_out, o as detach, a as space, d as toggle_class, g as append, l as listen, h as is_function, z as group_outros, A as check_outros, r as run_all, au as compute_slots, Y as createEventDispatcher, u as getContext, I as Icon, c as create_component, al as set_style, m as mount_component, p as destroy_component, N as ensure_array_like, O as destroy_each, V as bubble, t as text, j as set_data, B as noop } from "./index-a0738cd3.js";
function create_fragment$1(ctx) {
  let ul;
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[1].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[0],
    null
  );
  return {
    c() {
      ul = element("ul");
      if (default_slot)
        default_slot.c();
      attr(ul, "class", "spectrum-Menu");
      attr(ul, "role", "menu");
    },
    m(target, anchor) {
      insert(target, ul, anchor);
      if (default_slot) {
        default_slot.m(ul, null);
      }
      current = true;
    },
    p(ctx2, [dirty]) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        1)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[0],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[0]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[0],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(ul);
      }
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  $$self.$$set = ($$props2) => {
    if ("$$scope" in $$props2)
      $$invalidate(0, $$scope = $$props2.$$scope);
  };
  return [$$scope, slots];
}
class Menu extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, {});
  }
}
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[17] = list[i];
  return child_ctx;
}
const get_right_slot_changes = (dirty) => ({});
const get_right_slot_context = (ctx) => ({});
function create_if_block_2(ctx) {
  let div;
  let icon_1;
  let current;
  icon_1 = new Icon({
    props: {
      name: (
        /*icon*/
        ctx[0]
      ),
      weight: (
        /*iconWeight*/
        ctx[1]
      ),
      size: "S",
      color: (
        /*iconColour*/
        ctx[2] || "var(--spectrum-global-color-gray-700)"
      )
    }
  });
  return {
    c() {
      div = element("div");
      create_component(icon_1.$$.fragment);
      attr(div, "class", "icon svelte-b9x87s");
      set_style(
        div,
        "align-self",
        /*iconAlign*/
        ctx[4]
      );
      toggle_class(
        div,
        "iconHidden",
        /*iconHidden*/
        ctx[3]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon_1, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const icon_1_changes = {};
      if (dirty & /*icon*/
      1)
        icon_1_changes.name = /*icon*/
        ctx2[0];
      if (dirty & /*iconWeight*/
      2)
        icon_1_changes.weight = /*iconWeight*/
        ctx2[1];
      if (dirty & /*iconColour*/
      4)
        icon_1_changes.color = /*iconColour*/
        ctx2[2] || "var(--spectrum-global-color-gray-700)";
      icon_1.$set(icon_1_changes);
      if (!current || dirty & /*iconAlign*/
      16) {
        set_style(
          div,
          "align-self",
          /*iconAlign*/
          ctx2[4]
        );
      }
      if (!current || dirty & /*iconHidden*/
      8) {
        toggle_class(
          div,
          "iconHidden",
          /*iconHidden*/
          ctx2[3]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon_1);
    }
  };
}
function create_if_block(ctx) {
  let div;
  let t;
  let current;
  const right_slot_template = (
    /*#slots*/
    ctx[12].right
  );
  const right_slot = create_slot(
    right_slot_template,
    ctx,
    /*$$scope*/
    ctx[11],
    get_right_slot_context
  );
  let each_value = ensure_array_like(
    /*keys*/
    ctx[6]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      div = element("div");
      if (right_slot)
        right_slot.c();
      t = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "keys svelte-b9x87s");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (right_slot) {
        right_slot.m(div, null);
      }
      append(div, t);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (right_slot) {
        if (right_slot.p && (!current || dirty & /*$$scope*/
        2048)) {
          update_slot_base(
            right_slot,
            right_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[11],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[11]
            ) : get_slot_changes(
              right_slot_template,
              /*$$scope*/
              ctx2[11],
              dirty,
              get_right_slot_changes
            ),
            get_right_slot_context
          );
        }
      }
      if (dirty & /*iconWeight, keys*/
      66) {
        each_value = ensure_array_like(
          /*keys*/
          ctx2[6]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div, null);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(right_slot, local);
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      transition_out(right_slot, local);
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (right_slot)
        right_slot.d(detaching);
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_else_block(ctx) {
  let t_value = (
    /*key*/
    ctx[17] + ""
  );
  let t;
  return {
    c() {
      t = text(t_value);
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*keys*/
      64 && t_value !== (t_value = /*key*/
      ctx2[17] + ""))
        set_data(t, t_value);
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_1(ctx) {
  let icon_1;
  let current;
  icon_1 = new Icon({
    props: {
      size: "XS",
      weight: (
        /*iconWeight*/
        ctx[1]
      ),
      name: (
        /*key*/
        ctx[17].split("!")[1]
      )
    }
  });
  return {
    c() {
      create_component(icon_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(icon_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const icon_1_changes = {};
      if (dirty & /*iconWeight*/
      2)
        icon_1_changes.weight = /*iconWeight*/
        ctx2[1];
      if (dirty & /*keys*/
      64)
        icon_1_changes.name = /*key*/
        ctx2[17].split("!")[1];
      icon_1.$set(icon_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(icon_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(icon_1, detaching);
    }
  };
}
function create_each_block(ctx) {
  let div;
  let show_if;
  let current_block_type_index;
  let if_block;
  let t;
  let current;
  const if_block_creators = [create_if_block_1, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (dirty & /*keys*/
    64)
      show_if = null;
    if (show_if == null)
      show_if = !!/*key*/
      ctx2[17].startsWith("!");
    if (show_if)
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx, -1);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      div = element("div");
      if_block.c();
      t = space();
      attr(div, "class", "key svelte-b9x87s");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      append(div, t);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2, dirty);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div, t);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
    }
  };
}
function create_fragment(ctx) {
  var _a;
  let li;
  let t0;
  let span;
  let t1;
  let current;
  let mounted;
  let dispose;
  let if_block0 = (
    /*icon*/
    ctx[0] && create_if_block_2(ctx)
  );
  const default_slot_template = (
    /*#slots*/
    ctx[12].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[11],
    null
  );
  let if_block1 = (
    /*keys*/
    (((_a = ctx[6]) == null ? void 0 : _a.length) || /*$$slots*/
    ctx[8].right) && create_if_block(ctx)
  );
  return {
    c() {
      li = element("li");
      if (if_block0)
        if_block0.c();
      t0 = space();
      span = element("span");
      if (default_slot)
        default_slot.c();
      t1 = space();
      if (if_block1)
        if_block1.c();
      attr(span, "class", "spectrum-Menu-itemLabel svelte-b9x87s");
      attr(li, "class", "spectrum-Menu-item svelte-b9x87s");
      attr(li, "role", "menuitem");
      attr(li, "tabindex", "0");
      toggle_class(
        li,
        "is-disabled",
        /*disabled*/
        ctx[5]
      );
    },
    m(target, anchor) {
      insert(target, li, anchor);
      if (if_block0)
        if_block0.m(li, null);
      append(li, t0);
      append(li, span);
      if (default_slot) {
        default_slot.m(span, null);
      }
      append(li, t1);
      if (if_block1)
        if_block1.m(li, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(li, "click", function() {
            if (is_function(
              /*disabled*/
              ctx[5] ? null : (
                /*onClick*/
                ctx[7]
              )
            ))
              /*disabled*/
              (ctx[5] ? null : (
                /*onClick*/
                ctx[7]
              )).apply(this, arguments);
          }),
          listen(
            li,
            "auxclick",
            /*auxclick_handler*/
            ctx[13]
          )
        ];
        mounted = true;
      }
    },
    p(new_ctx, [dirty]) {
      var _a2;
      ctx = new_ctx;
      if (
        /*icon*/
        ctx[0]
      ) {
        if (if_block0) {
          if_block0.p(ctx, dirty);
          if (dirty & /*icon*/
          1) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_2(ctx);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(li, t0);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        2048)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx,
            /*$$scope*/
            ctx[11],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx[11]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx[11],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (
        /*keys*/
        ((_a2 = ctx[6]) == null ? void 0 : _a2.length) || /*$$slots*/
        ctx[8].right
      ) {
        if (if_block1) {
          if_block1.p(ctx, dirty);
          if (dirty & /*keys, $$slots*/
          320) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block(ctx);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(li, null);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if (!current || dirty & /*disabled*/
      32) {
        toggle_class(
          li,
          "is-disabled",
          /*disabled*/
          ctx[5]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(default_slot, local);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(default_slot, local);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(li);
      }
      if (if_block0)
        if_block0.d();
      if (default_slot)
        default_slot.d(detaching);
      if (if_block1)
        if_block1.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let keys;
  let { $$slots: slots = {}, $$scope } = $$props;
  const $$slots = compute_slots(slots);
  const dispatch = createEventDispatcher();
  const actionMenu = getContext("actionMenu");
  let { icon = void 0 } = $$props;
  let { iconWeight = "regular" } = $$props;
  let { iconColour = void 0 } = $$props;
  let { iconHidden = false } = $$props;
  let { iconAlign = "center" } = $$props;
  let { disabled = void 0 } = $$props;
  let { noClose = false } = $$props;
  let { keyBind = void 0 } = $$props;
  const getKeys = (keyBind2) => {
    let keys2 = (keyBind2 == null ? void 0 : keyBind2.split("+")) || [];
    for (let i = 0; i < keys2.length; i++) {
      if (keys2[i].toLowerCase() === "ctrl" && navigator.platform.startsWith("Mac")) {
        keys2[i] = "⌘";
      }
    }
    return keys2;
  };
  const onClick = () => {
    if (actionMenu && !noClose) {
      actionMenu.hideAll();
    }
    dispatch("click");
  };
  function auxclick_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("icon" in $$props2)
      $$invalidate(0, icon = $$props2.icon);
    if ("iconWeight" in $$props2)
      $$invalidate(1, iconWeight = $$props2.iconWeight);
    if ("iconColour" in $$props2)
      $$invalidate(2, iconColour = $$props2.iconColour);
    if ("iconHidden" in $$props2)
      $$invalidate(3, iconHidden = $$props2.iconHidden);
    if ("iconAlign" in $$props2)
      $$invalidate(4, iconAlign = $$props2.iconAlign);
    if ("disabled" in $$props2)
      $$invalidate(5, disabled = $$props2.disabled);
    if ("noClose" in $$props2)
      $$invalidate(9, noClose = $$props2.noClose);
    if ("keyBind" in $$props2)
      $$invalidate(10, keyBind = $$props2.keyBind);
    if ("$$scope" in $$props2)
      $$invalidate(11, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*keyBind*/
    1024) {
      $$invalidate(6, keys = getKeys(keyBind));
    }
  };
  return [
    icon,
    iconWeight,
    iconColour,
    iconHidden,
    iconAlign,
    disabled,
    keys,
    onClick,
    $$slots,
    noClose,
    keyBind,
    $$scope,
    slots,
    auxclick_handler
  ];
}
class Item extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      icon: 0,
      iconWeight: 1,
      iconColour: 2,
      iconHidden: 3,
      iconAlign: 4,
      disabled: 5,
      noClose: 9,
      keyBind: 10
    });
  }
}
export {
  Item as I,
  Menu as M
};
