import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, k as transition_in, z as group_outros, n as transition_out, A as check_outros, o as detach, u as getContext, K as Block, c as create_component, m as mount_component, p as destroy_component, M as BlockComponent, W as binding_callbacks, a0 as bind, a1 as add_flush_callback, az as get_store_value, bV as makePropSafe, a as space, N as ensure_array_like, bX as update_keyed_each, bY as outro_and_destroy_block } from "./index-a0738cd3.js";
import { e as enrichSearchColumns, a as enrichFilter } from "./blocks-37916d2a.js";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[46] = list[i];
  child_ctx[48] = i;
  return child_ctx;
}
function create_if_block(ctx) {
  let block;
  let current;
  block = new Block({
    props: {
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(block.$$.fragment);
    },
    m(target, anchor) {
      mount_component(block, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const block_changes = {};
      if (dirty[0] & /*dataSource, formId, enrichedFilter, sortColumn, sortOrder, paginate, limit, autoRefresh, dataProviderId, noRowsMessage, cardWidth, repeaterId, cardTitle, cardSubtitle, cardDescription, cardImageURL, cardHorizontal, showCardButton, cardButtonText, cardButtonOnClick, fullCardURL, cardPeek, titleButtonAction, titleButtonText, enrichedSearchColumns, showTitleButton, title*/
      260046847 | dirty[1] & /*$$scope*/
      262144) {
        block_changes.$$scope = { dirty, ctx: ctx2 };
      }
      block.$set(block_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(block.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(block.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(block, detaching);
    }
  };
}
function create_if_block_1(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "container",
      props: {
        direction: "row",
        hAlign: "stretch",
        vAlign: "middle",
        gap: "M",
        wrap: true
      },
      styles: { normal: { "margin-bottom": "20px" } },
      order: 0,
      $$slots: { default: [create_default_slot_4] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*titleButtonAction, titleButtonText, enrichedSearchColumns, showTitleButton, title*/
      18874561 | dirty[1] & /*$$scope*/
      262144) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_if_block_3(ctx) {
  let each_blocks = [];
  let each_1_lookup = /* @__PURE__ */ new Map();
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(
    /*enrichedSearchColumns*/
    ctx[21]
  );
  const get_key = (ctx2) => (
    /*column*/
    ctx2[46].name
  );
  for (let i = 0; i < each_value.length; i += 1) {
    let child_ctx = get_each_context(ctx, each_value, i);
    let key = get_key(child_ctx);
    each_1_lookup.set(key, each_blocks[i] = create_each_block(key, child_ctx));
  }
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*enrichedSearchColumns*/
      2097152) {
        each_value = ensure_array_like(
          /*enrichedSearchColumns*/
          ctx2[21]
        );
        group_outros();
        each_blocks = update_keyed_each(each_blocks, dirty, get_key, 1, ctx2, each_value, each_1_lookup, each_1_anchor.parentNode, outro_and_destroy_block, create_each_block, each_1_anchor, get_each_context);
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].d(detaching);
      }
    }
  };
}
function create_each_block(key_1, ctx) {
  let first;
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: (
        /*column*/
        ctx[46].componentType
      ),
      props: {
        field: (
          /*column*/
          ctx[46].name
        ),
        placeholder: (
          /*column*/
          ctx[46].name
        ),
        text: (
          /*column*/
          ctx[46].name
        ),
        autoWidth: true
      },
      order: (
        /*idx*/
        ctx[48]
      ),
      styles: { normal: { width: "192px" } }
    }
  });
  return {
    key: key_1,
    first: null,
    c() {
      first = empty();
      create_component(blockcomponent.$$.fragment);
      this.first = first;
    },
    m(target, anchor) {
      insert(target, first, anchor);
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const blockcomponent_changes = {};
      if (dirty[0] & /*enrichedSearchColumns*/
      2097152)
        blockcomponent_changes.type = /*column*/
        ctx[46].componentType;
      if (dirty[0] & /*enrichedSearchColumns*/
      2097152)
        blockcomponent_changes.props = {
          field: (
            /*column*/
            ctx[46].name
          ),
          placeholder: (
            /*column*/
            ctx[46].name
          ),
          text: (
            /*column*/
            ctx[46].name
          ),
          autoWidth: true
        };
      if (dirty[0] & /*enrichedSearchColumns*/
      2097152)
        blockcomponent_changes.order = /*idx*/
        ctx[48];
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(first);
      }
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_if_block_2(ctx) {
  var _a;
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "button",
      props: {
        onClick: (
          /*titleButtonAction*/
          ctx[24]
        ),
        text: (
          /*titleButtonText*/
          ctx[7]
        ),
        type: "cta"
      },
      order: (
        /*enrichedSearchColumns*/
        ((_a = ctx[21]) == null ? void 0 : _a.length) ?? 0
      )
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      const blockcomponent_changes = {};
      if (dirty[0] & /*titleButtonAction, titleButtonText*/
      16777344)
        blockcomponent_changes.props = {
          onClick: (
            /*titleButtonAction*/
            ctx2[24]
          ),
          text: (
            /*titleButtonText*/
            ctx2[7]
          ),
          type: "cta"
        };
      if (dirty[0] & /*enrichedSearchColumns*/
      2097152)
        blockcomponent_changes.order = /*enrichedSearchColumns*/
        ((_a2 = ctx2[21]) == null ? void 0 : _a2.length) ?? 0;
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_5(ctx) {
  var _a;
  let t;
  let if_block1_anchor;
  let current;
  let if_block0 = (
    /*enrichedSearchColumns*/
    ((_a = ctx[21]) == null ? void 0 : _a.length) && create_if_block_3(ctx)
  );
  let if_block1 = (
    /*showTitleButton*/
    ctx[6] && create_if_block_2(ctx)
  );
  return {
    c() {
      if (if_block0)
        if_block0.c();
      t = space();
      if (if_block1)
        if_block1.c();
      if_block1_anchor = empty();
    },
    m(target, anchor) {
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, if_block1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      if (
        /*enrichedSearchColumns*/
        (_a2 = ctx2[21]) == null ? void 0 : _a2.length
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty[0] & /*enrichedSearchColumns*/
          2097152) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_3(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(t.parentNode, t);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (
        /*showTitleButton*/
        ctx2[6]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty[0] & /*showTitleButton*/
          64) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_2(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(if_block1_anchor.parentNode, if_block1_anchor);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block1_anchor);
      }
      if (if_block0)
        if_block0.d(detaching);
      if (if_block1)
        if_block1.d(detaching);
    }
  };
}
function create_default_slot_4(ctx) {
  let blockcomponent0;
  let t;
  let blockcomponent1;
  let current;
  blockcomponent0 = new BlockComponent({
    props: {
      type: "textv2",
      props: {
        text: (
          /*title*/
          ctx[0] ? `## ${/*title*/
          ctx[0]}` : ""
        )
      },
      order: 0
    }
  });
  blockcomponent1 = new BlockComponent({
    props: {
      type: "container",
      props: {
        direction: "row",
        hAlign: "left",
        vAlign: "middle",
        gap: "M",
        wrap: true
      },
      order: 1,
      $$slots: { default: [create_default_slot_5] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent0.$$.fragment);
      t = space();
      create_component(blockcomponent1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent0, target, anchor);
      insert(target, t, anchor);
      mount_component(blockcomponent1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent0_changes = {};
      if (dirty[0] & /*title*/
      1)
        blockcomponent0_changes.props = {
          text: (
            /*title*/
            ctx2[0] ? `## ${/*title*/
            ctx2[0]}` : ""
          )
        };
      blockcomponent0.$set(blockcomponent0_changes);
      const blockcomponent1_changes = {};
      if (dirty[0] & /*titleButtonAction, titleButtonText, enrichedSearchColumns, showTitleButton*/
      18874560 | dirty[1] & /*$$scope*/
      262144) {
        blockcomponent1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent1.$set(blockcomponent1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent0.$$.fragment, local);
      transition_in(blockcomponent1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent0.$$.fragment, local);
      transition_out(blockcomponent1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(blockcomponent0, detaching);
      destroy_component(blockcomponent1, detaching);
    }
  };
}
function create_default_slot_3(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "spectrumcard",
      props: {
        title: (
          /*cardTitle*/
          ctx[8]
        ),
        subtitle: (
          /*cardSubtitle*/
          ctx[9]
        ),
        description: (
          /*cardDescription*/
          ctx[10]
        ),
        imageURL: (
          /*cardImageURL*/
          ctx[11]
        ),
        horizontal: (
          /*cardHorizontal*/
          ctx[13]
        ),
        showButton: (
          /*showCardButton*/
          ctx[14]
        ),
        buttonText: (
          /*cardButtonText*/
          ctx[15]
        ),
        buttonOnClick: (
          /*cardButtonOnClick*/
          ctx[16]
        ),
        linkURL: (
          /*fullCardURL*/
          ctx[25]
        ),
        linkPeek: (
          /*cardPeek*/
          ctx[12]
        )
      },
      styles: { normal: { width: "auto" } },
      order: 0
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*cardTitle, cardSubtitle, cardDescription, cardImageURL, cardHorizontal, showCardButton, cardButtonText, cardButtonOnClick, fullCardURL, cardPeek*/
      33685248)
        blockcomponent_changes.props = {
          title: (
            /*cardTitle*/
            ctx2[8]
          ),
          subtitle: (
            /*cardSubtitle*/
            ctx2[9]
          ),
          description: (
            /*cardDescription*/
            ctx2[10]
          ),
          imageURL: (
            /*cardImageURL*/
            ctx2[11]
          ),
          horizontal: (
            /*cardHorizontal*/
            ctx2[13]
          ),
          showButton: (
            /*showCardButton*/
            ctx2[14]
          ),
          buttonText: (
            /*cardButtonText*/
            ctx2[15]
          ),
          buttonOnClick: (
            /*cardButtonOnClick*/
            ctx2[16]
          ),
          linkURL: (
            /*fullCardURL*/
            ctx2[25]
          ),
          linkPeek: (
            /*cardPeek*/
            ctx2[12]
          )
        };
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_2(ctx) {
  let blockcomponent;
  let updating_id;
  let current;
  function blockcomponent_id_binding(value) {
    ctx[37](value);
  }
  let blockcomponent_props = {
    type: "repeater",
    context: "repeater",
    props: {
      dataProvider: `{{ literal ${makePropSafe(
        /*dataProviderId*/
        ctx[22]
      )} }}`,
      direction: "row",
      hAlign: "stretch",
      vAlign: "top",
      gap: "M",
      noRowsMessage: (
        /*noRowsMessage*/
        ctx[17] || "No rows found"
      )
    },
    styles: {
      custom: `display: grid;
grid-template-columns: repeat(auto-fill, minmax(min(${/*cardWidth*/
      ctx[26]}px, 100%), 1fr));`
    },
    order: 0,
    $$slots: { default: [create_default_slot_3] },
    $$scope: { ctx }
  };
  if (
    /*repeaterId*/
    ctx[20] !== void 0
  ) {
    blockcomponent_props.id = /*repeaterId*/
    ctx[20];
  }
  blockcomponent = new BlockComponent({ props: blockcomponent_props });
  binding_callbacks.push(() => bind(blockcomponent, "id", blockcomponent_id_binding));
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*dataProviderId, noRowsMessage*/
      4325376)
        blockcomponent_changes.props = {
          dataProvider: `{{ literal ${makePropSafe(
            /*dataProviderId*/
            ctx2[22]
          )} }}`,
          direction: "row",
          hAlign: "stretch",
          vAlign: "top",
          gap: "M",
          noRowsMessage: (
            /*noRowsMessage*/
            ctx2[17] || "No rows found"
          )
        };
      if (dirty[0] & /*cardWidth*/
      67108864)
        blockcomponent_changes.styles = {
          custom: `display: grid;
grid-template-columns: repeat(auto-fill, minmax(min(${/*cardWidth*/
          ctx2[26]}px, 100%), 1fr));`
        };
      if (dirty[0] & /*cardTitle, cardSubtitle, cardDescription, cardImageURL, cardHorizontal, showCardButton, cardButtonText, cardButtonOnClick, fullCardURL, cardPeek*/
      33685248 | dirty[1] & /*$$scope*/
      262144) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_id && dirty[0] & /*repeaterId*/
      1048576) {
        updating_id = true;
        blockcomponent_changes.id = /*repeaterId*/
        ctx2[20];
        add_flush_callback(() => updating_id = false);
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  var _a;
  let t;
  let blockcomponent;
  let updating_id;
  let current;
  let if_block = (
    /*title*/
    (ctx[0] || /*enrichedSearchColumns*/
    ((_a = ctx[21]) == null ? void 0 : _a.length) || /*showTitleButton*/
    ctx[6]) && create_if_block_1(ctx)
  );
  function blockcomponent_id_binding_1(value) {
    ctx[38](value);
  }
  let blockcomponent_props = {
    type: "dataprovider",
    props: {
      dataSource: (
        /*dataSource*/
        ctx[1]
      ),
      filter: (
        /*enrichedFilter*/
        ctx[27]
      ),
      sortColumn: (
        /*sortColumn*/
        ctx[2]
      ),
      sortOrder: (
        /*sortOrder*/
        ctx[3]
      ),
      paginate: (
        /*paginate*/
        ctx[4]
      ),
      limit: (
        /*limit*/
        ctx[5]
      ),
      autoRefresh: (
        /*autoRefresh*/
        ctx[18]
      )
    },
    order: 1,
    $$slots: { default: [create_default_slot_2] },
    $$scope: { ctx }
  };
  if (
    /*dataProviderId*/
    ctx[22] !== void 0
  ) {
    blockcomponent_props.id = /*dataProviderId*/
    ctx[22];
  }
  blockcomponent = new BlockComponent({ props: blockcomponent_props });
  binding_callbacks.push(() => bind(blockcomponent, "id", blockcomponent_id_binding_1));
  return {
    c() {
      if (if_block)
        if_block.c();
      t = space();
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, t, anchor);
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      if (
        /*title*/
        ctx2[0] || /*enrichedSearchColumns*/
        ((_a2 = ctx2[21]) == null ? void 0 : _a2.length) || /*showTitleButton*/
        ctx2[6]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*title, enrichedSearchColumns, showTitleButton*/
          2097217) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(t.parentNode, t);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      const blockcomponent_changes = {};
      if (dirty[0] & /*dataSource, enrichedFilter, sortColumn, sortOrder, paginate, limit, autoRefresh*/
      134479934)
        blockcomponent_changes.props = {
          dataSource: (
            /*dataSource*/
            ctx2[1]
          ),
          filter: (
            /*enrichedFilter*/
            ctx2[27]
          ),
          sortColumn: (
            /*sortColumn*/
            ctx2[2]
          ),
          sortOrder: (
            /*sortOrder*/
            ctx2[3]
          ),
          paginate: (
            /*paginate*/
            ctx2[4]
          ),
          limit: (
            /*limit*/
            ctx2[5]
          ),
          autoRefresh: (
            /*autoRefresh*/
            ctx2[18]
          )
        };
      if (dirty[0] & /*dataProviderId, noRowsMessage, cardWidth, repeaterId, cardTitle, cardSubtitle, cardDescription, cardImageURL, cardHorizontal, showCardButton, cardButtonText, cardButtonOnClick, fullCardURL, cardPeek*/
      106168064 | dirty[1] & /*$$scope*/
      262144) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_id && dirty[0] & /*dataProviderId*/
      4194304) {
        updating_id = true;
        blockcomponent_changes.id = /*dataProviderId*/
        ctx2[22];
        add_flush_callback(() => updating_id = false);
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      if (if_block)
        if_block.d(detaching);
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let blockcomponent;
  let updating_id;
  let current;
  function blockcomponent_id_binding_2(value) {
    ctx[39](value);
  }
  let blockcomponent_props = {
    type: "form",
    props: {
      dataSource: (
        /*dataSource*/
        ctx[1]
      ),
      disableSchemaValidation: true
    },
    $$slots: { default: [create_default_slot_1] },
    $$scope: { ctx }
  };
  if (
    /*formId*/
    ctx[19] !== void 0
  ) {
    blockcomponent_props.id = /*formId*/
    ctx[19];
  }
  blockcomponent = new BlockComponent({ props: blockcomponent_props });
  binding_callbacks.push(() => bind(blockcomponent, "id", blockcomponent_id_binding_2));
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*dataSource*/
      2)
        blockcomponent_changes.props = {
          dataSource: (
            /*dataSource*/
            ctx2[1]
          ),
          disableSchemaValidation: true
        };
      if (dirty[0] & /*dataSource, enrichedFilter, sortColumn, sortOrder, paginate, limit, autoRefresh, dataProviderId, noRowsMessage, cardWidth, repeaterId, cardTitle, cardSubtitle, cardDescription, cardImageURL, cardHorizontal, showCardButton, cardButtonText, cardButtonOnClick, fullCardURL, cardPeek, titleButtonAction, titleButtonText, enrichedSearchColumns, showTitleButton, title*/
      259522559 | dirty[1] & /*$$scope*/
      262144) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_id && dirty[0] & /*formId*/
      524288) {
        updating_id = true;
        blockcomponent_changes.id = /*formId*/
        ctx2[19];
        add_flush_callback(() => updating_id = false);
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_fragment(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*schemaLoaded*/
    ctx[23] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*schemaLoaded*/
        ctx2[23]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*schemaLoaded*/
          8388608) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let enrichedFilter;
  let cardWidth;
  let fullCardURL;
  let titleButtonAction;
  let { title } = $$props;
  let { dataSource } = $$props;
  let { searchColumns } = $$props;
  let { filter } = $$props;
  let { sortColumn } = $$props;
  let { sortOrder } = $$props;
  let { paginate } = $$props;
  let { limit } = $$props;
  let { showTitleButton } = $$props;
  let { titleButtonText } = $$props;
  let { titleButtonURL } = $$props;
  let { titleButtonPeek } = $$props;
  let { cardTitle } = $$props;
  let { cardSubtitle } = $$props;
  let { cardDescription } = $$props;
  let { cardImageURL } = $$props;
  let { linkCardTitle } = $$props;
  let { cardURL } = $$props;
  let { cardPeek } = $$props;
  let { cardHorizontal } = $$props;
  let { showCardButton } = $$props;
  let { cardButtonText } = $$props;
  let { cardButtonOnClick } = $$props;
  let { linkColumn } = $$props;
  let { noRowsMessage } = $$props;
  let { autoRefresh } = $$props;
  const context = getContext("context");
  const { fetchDatasourceSchema, generateGoldenSample } = getContext("sdk");
  const component = getContext("component");
  let formId;
  let dataProviderId;
  let repeaterId;
  let schema;
  let enrichedSearchColumns;
  let schemaLoaded = false;
  const getAdditionalDataContext = () => {
    var _a;
    const rows = ((_a = get_store_value(context)[dataProviderId]) == null ? void 0 : _a.rows) || [];
    const goldenRow = generateGoldenSample(rows);
    const id = get_store_value(component).id;
    return { [`${id}-repeater`]: goldenRow };
  };
  const buildFullCardUrl = (link, url, repeaterId2, linkColumn2) => {
    if (!link || !url || !repeaterId2) {
      return null;
    }
    const col = linkColumn2 || "_id";
    const split = url.split("/:");
    if (split.length > 1) {
      return `${split[0]}/{{ ${makePropSafe(repeaterId2)}.${makePropSafe(col)} }}`;
    }
    return url;
  };
  const fetchSchema = async (dataSource2) => {
    if (dataSource2) {
      $$invalidate(36, schema = await fetchDatasourceSchema(dataSource2, { enrichRelationships: true }));
    }
    $$invalidate(23, schemaLoaded = true);
  };
  function blockcomponent_id_binding(value) {
    repeaterId = value;
    $$invalidate(20, repeaterId);
  }
  function blockcomponent_id_binding_1(value) {
    dataProviderId = value;
    $$invalidate(22, dataProviderId);
  }
  function blockcomponent_id_binding_2(value) {
    formId = value;
    $$invalidate(19, formId);
  }
  $$self.$$set = ($$props2) => {
    if ("title" in $$props2)
      $$invalidate(0, title = $$props2.title);
    if ("dataSource" in $$props2)
      $$invalidate(1, dataSource = $$props2.dataSource);
    if ("searchColumns" in $$props2)
      $$invalidate(28, searchColumns = $$props2.searchColumns);
    if ("filter" in $$props2)
      $$invalidate(29, filter = $$props2.filter);
    if ("sortColumn" in $$props2)
      $$invalidate(2, sortColumn = $$props2.sortColumn);
    if ("sortOrder" in $$props2)
      $$invalidate(3, sortOrder = $$props2.sortOrder);
    if ("paginate" in $$props2)
      $$invalidate(4, paginate = $$props2.paginate);
    if ("limit" in $$props2)
      $$invalidate(5, limit = $$props2.limit);
    if ("showTitleButton" in $$props2)
      $$invalidate(6, showTitleButton = $$props2.showTitleButton);
    if ("titleButtonText" in $$props2)
      $$invalidate(7, titleButtonText = $$props2.titleButtonText);
    if ("titleButtonURL" in $$props2)
      $$invalidate(30, titleButtonURL = $$props2.titleButtonURL);
    if ("titleButtonPeek" in $$props2)
      $$invalidate(31, titleButtonPeek = $$props2.titleButtonPeek);
    if ("cardTitle" in $$props2)
      $$invalidate(8, cardTitle = $$props2.cardTitle);
    if ("cardSubtitle" in $$props2)
      $$invalidate(9, cardSubtitle = $$props2.cardSubtitle);
    if ("cardDescription" in $$props2)
      $$invalidate(10, cardDescription = $$props2.cardDescription);
    if ("cardImageURL" in $$props2)
      $$invalidate(11, cardImageURL = $$props2.cardImageURL);
    if ("linkCardTitle" in $$props2)
      $$invalidate(32, linkCardTitle = $$props2.linkCardTitle);
    if ("cardURL" in $$props2)
      $$invalidate(33, cardURL = $$props2.cardURL);
    if ("cardPeek" in $$props2)
      $$invalidate(12, cardPeek = $$props2.cardPeek);
    if ("cardHorizontal" in $$props2)
      $$invalidate(13, cardHorizontal = $$props2.cardHorizontal);
    if ("showCardButton" in $$props2)
      $$invalidate(14, showCardButton = $$props2.showCardButton);
    if ("cardButtonText" in $$props2)
      $$invalidate(15, cardButtonText = $$props2.cardButtonText);
    if ("cardButtonOnClick" in $$props2)
      $$invalidate(16, cardButtonOnClick = $$props2.cardButtonOnClick);
    if ("linkColumn" in $$props2)
      $$invalidate(34, linkColumn = $$props2.linkColumn);
    if ("noRowsMessage" in $$props2)
      $$invalidate(17, noRowsMessage = $$props2.noRowsMessage);
    if ("autoRefresh" in $$props2)
      $$invalidate(18, autoRefresh = $$props2.autoRefresh);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*dataSource*/
    2) {
      fetchSchema(dataSource);
    }
    if ($$self.$$.dirty[0] & /*searchColumns*/
    268435456 | $$self.$$.dirty[1] & /*schema*/
    32) {
      enrichSearchColumns(searchColumns, schema).then((val) => $$invalidate(21, enrichedSearchColumns = val));
    }
    if ($$self.$$.dirty[0] & /*filter, enrichedSearchColumns, formId*/
    539492352) {
      $$invalidate(27, enrichedFilter = enrichFilter(filter, enrichedSearchColumns, formId));
    }
    if ($$self.$$.dirty[0] & /*cardHorizontal*/
    8192) {
      $$invalidate(26, cardWidth = cardHorizontal ? 420 : 300);
    }
    if ($$self.$$.dirty[0] & /*repeaterId*/
    1048576 | $$self.$$.dirty[1] & /*linkCardTitle, cardURL, linkColumn*/
    14) {
      $$invalidate(25, fullCardURL = buildFullCardUrl(linkCardTitle, cardURL, repeaterId, linkColumn));
    }
    if ($$self.$$.dirty[0] & /*titleButtonURL*/
    1073741824 | $$self.$$.dirty[1] & /*titleButtonPeek*/
    1) {
      $$invalidate(24, titleButtonAction = [
        {
          "##eventHandlerType": "Navigate To",
          parameters: {
            peek: titleButtonPeek,
            url: titleButtonURL
          }
        }
      ]);
    }
  };
  return [
    title,
    dataSource,
    sortColumn,
    sortOrder,
    paginate,
    limit,
    showTitleButton,
    titleButtonText,
    cardTitle,
    cardSubtitle,
    cardDescription,
    cardImageURL,
    cardPeek,
    cardHorizontal,
    showCardButton,
    cardButtonText,
    cardButtonOnClick,
    noRowsMessage,
    autoRefresh,
    formId,
    repeaterId,
    enrichedSearchColumns,
    dataProviderId,
    schemaLoaded,
    titleButtonAction,
    fullCardURL,
    cardWidth,
    enrichedFilter,
    searchColumns,
    filter,
    titleButtonURL,
    titleButtonPeek,
    linkCardTitle,
    cardURL,
    linkColumn,
    getAdditionalDataContext,
    schema,
    blockcomponent_id_binding,
    blockcomponent_id_binding_1,
    blockcomponent_id_binding_2
  ];
}
class CardsBlock extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        title: 0,
        dataSource: 1,
        searchColumns: 28,
        filter: 29,
        sortColumn: 2,
        sortOrder: 3,
        paginate: 4,
        limit: 5,
        showTitleButton: 6,
        titleButtonText: 7,
        titleButtonURL: 30,
        titleButtonPeek: 31,
        cardTitle: 8,
        cardSubtitle: 9,
        cardDescription: 10,
        cardImageURL: 11,
        linkCardTitle: 32,
        cardURL: 33,
        cardPeek: 12,
        cardHorizontal: 13,
        showCardButton: 14,
        cardButtonText: 15,
        cardButtonOnClick: 16,
        linkColumn: 34,
        noRowsMessage: 17,
        autoRefresh: 18,
        getAdditionalDataContext: 35
      },
      null,
      [-1, -1]
    );
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[35];
  }
}
export {
  CardsBlock as default
};
