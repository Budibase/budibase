import { ad as API, bV as makePropSafe, a_ as BasicOperator, aZ as UILogicalOperator, ca as OnEmptyFilter } from "./index-a0738cd3.js";
const schemaComponentMap = {
  string: "stringfield",
  options: "optionsfield",
  number: "numberfield",
  bigint: "bigintfield",
  datetime: "datetimefield",
  boolean: "booleanfield",
  formula: "stringfield"
};
const enrichSearchColumns = async (searchColumns, schema) => {
  var _a, _b, _c;
  if (!(searchColumns == null ? void 0 : searchColumns.length) || !schema) {
    return [];
  }
  let enrichedColumns = [];
  for (let column of searchColumns) {
    let schemaType = (_a = schema[column]) == null ? void 0 : _a.type;
    if (column.includes(".")) {
      const split = column.split(".");
      const sourceField = split[0];
      const linkField = split.slice(1).join(".");
      const linkSchema = schema[sourceField];
      if ((linkSchema == null ? void 0 : linkSchema.type) === "link") {
        const linkedDef = await API.fetchTableDefinition(linkSchema.tableId);
        schemaType = (_c = (_b = linkedDef == null ? void 0 : linkedDef.schema) == null ? void 0 : _b[linkField]) == null ? void 0 : _c.type;
      }
    }
    const componentType = schemaComponentMap[schemaType];
    if (componentType) {
      enrichedColumns.push({
        name: column,
        componentType,
        type: schemaType
      });
    }
  }
  return enrichedColumns.slice(0, 5);
};
const enrichFilter = (filter, columns, formId) => {
  if (!(columns == null ? void 0 : columns.length)) {
    return filter;
  }
  const newFilters = [];
  columns == null ? void 0 : columns.forEach((column) => {
    const safePath = column.name.split(".").map(makePropSafe).join(".");
    const stringType = column.type === "string" || column.type === "formula";
    const dateType = column.type === "datetime";
    const binding = `${makePropSafe(formId)}.${safePath}`;
    if (dateType) {
      newFilters.push({
        field: column.name,
        type: column.type,
        operator: "rangeLow",
        valueType: "Binding",
        value: `{{ ${binding} }}`
      });
      const format = "YYYY-MM-DDTHH:mm:ss.SSSZ";
      let hbs = `{{ date (add (date ${binding} "x") 86399999) "${format}" }}`;
      hbs = `{{#if ${binding} }}${hbs}{{/if}}`;
      newFilters.push({
        field: column.name,
        type: column.type,
        operator: "rangeHigh",
        valueType: "Binding",
        value: hbs
      });
    } else {
      newFilters.push({
        field: column.name,
        type: column.type,
        operator: stringType ? BasicOperator.STRING : BasicOperator.EQUAL,
        valueType: "Binding",
        value: `{{ ${binding} }}`
      });
    }
  });
  return {
    logicalOperator: UILogicalOperator.ALL,
    onEmptyFilter: OnEmptyFilter.RETURN_ALL,
    groups: [
      ...(filter == null ? void 0 : filter.groups) || [],
      {
        logicalOperator: UILogicalOperator.ALL,
        filters: newFilters
      }
    ]
  };
};
export {
  enrichFilter as a,
  enrichSearchColumns as e
};
