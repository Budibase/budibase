import { S as SvelteComponent, i as init, s as safe_not_equal, K as Block, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component, u as getContext, v as component_subscribe, M as BlockComponent, W as binding_callbacks, a0 as bind, a1 as add_flush_callback, az as get_store_value, y as empty, f as insert, z as group_outros, A as check_outros, o as detach, bV as makePropSafe, B as noop, F as create_slot, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes } from "./index-a0738cd3.js";
import Placeholder from "./Placeholder-31706623.js";
function create_else_block(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "repeater",
      context: "repeater",
      containsSlot: true,
      props: {
        dataProvider: `{{ literal ${makePropSafe(
          /*providerId*/
          ctx[12]
        )} }}`,
        noRowsMessage: (
          /*noRowsMessage*/
          ctx[6]
        ),
        direction: (
          /*direction*/
          ctx[7]
        ),
        hAlign: (
          /*hAlign*/
          ctx[8]
        ),
        vAlign: (
          /*vAlign*/
          ctx[9]
        ),
        gap: (
          /*gap*/
          ctx[10]
        )
      },
      $$slots: { default: [create_default_slot_2] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*providerId, noRowsMessage, direction, hAlign, vAlign, gap*/
      6080)
        blockcomponent_changes.props = {
          dataProvider: `{{ literal ${makePropSafe(
            /*providerId*/
            ctx2[12]
          )} }}`,
          noRowsMessage: (
            /*noRowsMessage*/
            ctx2[6]
          ),
          direction: (
            /*direction*/
            ctx2[7]
          ),
          hAlign: (
            /*hAlign*/
            ctx2[8]
          ),
          vAlign: (
            /*vAlign*/
            ctx2[9]
          ),
          gap: (
            /*gap*/
            ctx2[10]
          )
        };
      if (dirty & /*$$scope*/
      262144) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_if_block(ctx) {
  let placeholder;
  let current;
  placeholder = new Placeholder({});
  return {
    c() {
      create_component(placeholder.$$.fragment);
    },
    m(target, anchor) {
      mount_component(placeholder, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(placeholder.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(placeholder.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(placeholder, detaching);
    }
  };
}
function create_default_slot_2(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[16].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[18],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        262144)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[18],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[18]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[18],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*$component*/
      ctx2[13].empty
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_default_slot(ctx) {
  let blockcomponent;
  let updating_id;
  let current;
  function blockcomponent_id_binding(value) {
    ctx[17](value);
  }
  let blockcomponent_props = {
    type: "dataprovider",
    context: "provider",
    props: {
      dataSource: (
        /*dataSource*/
        ctx[0]
      ),
      filter: (
        /*filter*/
        ctx[1]
      ),
      sortColumn: (
        /*sortColumn*/
        ctx[2]
      ),
      sortOrder: (
        /*sortOrder*/
        ctx[3]
      ),
      limit: (
        /*limit*/
        ctx[4]
      ),
      paginate: (
        /*paginate*/
        ctx[5]
      ),
      autoRefresh: (
        /*autoRefresh*/
        ctx[11]
      )
    },
    $$slots: { default: [create_default_slot_1] },
    $$scope: { ctx }
  };
  if (
    /*providerId*/
    ctx[12] !== void 0
  ) {
    blockcomponent_props.id = /*providerId*/
    ctx[12];
  }
  blockcomponent = new BlockComponent({ props: blockcomponent_props });
  binding_callbacks.push(() => bind(blockcomponent, "id", blockcomponent_id_binding));
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*dataSource, filter, sortColumn, sortOrder, limit, paginate, autoRefresh*/
      2111)
        blockcomponent_changes.props = {
          dataSource: (
            /*dataSource*/
            ctx2[0]
          ),
          filter: (
            /*filter*/
            ctx2[1]
          ),
          sortColumn: (
            /*sortColumn*/
            ctx2[2]
          ),
          sortOrder: (
            /*sortOrder*/
            ctx2[3]
          ),
          limit: (
            /*limit*/
            ctx2[4]
          ),
          paginate: (
            /*paginate*/
            ctx2[5]
          ),
          autoRefresh: (
            /*autoRefresh*/
            ctx2[11]
          )
        };
      if (dirty & /*$$scope, $component, providerId, noRowsMessage, direction, hAlign, vAlign, gap*/
      276416) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_id && dirty & /*providerId*/
      4096) {
        updating_id = true;
        blockcomponent_changes.id = /*providerId*/
        ctx2[12];
        add_flush_callback(() => updating_id = false);
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_fragment(ctx) {
  let block;
  let current;
  block = new Block({
    props: {
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(block.$$.fragment);
    },
    m(target, anchor) {
      mount_component(block, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const block_changes = {};
      if (dirty & /*$$scope, dataSource, filter, sortColumn, sortOrder, limit, paginate, autoRefresh, providerId, $component, noRowsMessage, direction, hAlign, vAlign, gap*/
      278527) {
        block_changes.$$scope = { dirty, ctx: ctx2 };
      }
      block.$set(block_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(block.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(block.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(block, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $component;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { dataSource } = $$props;
  let { filter } = $$props;
  let { sortColumn } = $$props;
  let { sortOrder } = $$props;
  let { limit } = $$props;
  let { paginate } = $$props;
  let { noRowsMessage } = $$props;
  let { direction } = $$props;
  let { hAlign } = $$props;
  let { vAlign } = $$props;
  let { gap } = $$props;
  let { autoRefresh } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(13, $component = value));
  const context = getContext("context");
  const { generateGoldenSample } = getContext("sdk");
  let providerId;
  const getAdditionalDataContext = () => {
    var _a;
    const rows = ((_a = get_store_value(context)[providerId]) == null ? void 0 : _a.rows) || [];
    const goldenRow = generateGoldenSample(rows);
    const id = get_store_value(component).id;
    return { [`${id}-repeater`]: goldenRow };
  };
  function blockcomponent_id_binding(value) {
    providerId = value;
    $$invalidate(12, providerId);
  }
  $$self.$$set = ($$props2) => {
    if ("dataSource" in $$props2)
      $$invalidate(0, dataSource = $$props2.dataSource);
    if ("filter" in $$props2)
      $$invalidate(1, filter = $$props2.filter);
    if ("sortColumn" in $$props2)
      $$invalidate(2, sortColumn = $$props2.sortColumn);
    if ("sortOrder" in $$props2)
      $$invalidate(3, sortOrder = $$props2.sortOrder);
    if ("limit" in $$props2)
      $$invalidate(4, limit = $$props2.limit);
    if ("paginate" in $$props2)
      $$invalidate(5, paginate = $$props2.paginate);
    if ("noRowsMessage" in $$props2)
      $$invalidate(6, noRowsMessage = $$props2.noRowsMessage);
    if ("direction" in $$props2)
      $$invalidate(7, direction = $$props2.direction);
    if ("hAlign" in $$props2)
      $$invalidate(8, hAlign = $$props2.hAlign);
    if ("vAlign" in $$props2)
      $$invalidate(9, vAlign = $$props2.vAlign);
    if ("gap" in $$props2)
      $$invalidate(10, gap = $$props2.gap);
    if ("autoRefresh" in $$props2)
      $$invalidate(11, autoRefresh = $$props2.autoRefresh);
    if ("$$scope" in $$props2)
      $$invalidate(18, $$scope = $$props2.$$scope);
  };
  return [
    dataSource,
    filter,
    sortColumn,
    sortOrder,
    limit,
    paginate,
    noRowsMessage,
    direction,
    hAlign,
    vAlign,
    gap,
    autoRefresh,
    providerId,
    $component,
    component,
    getAdditionalDataContext,
    slots,
    blockcomponent_id_binding,
    $$scope
  ];
}
class RepeaterBlock extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      dataSource: 0,
      filter: 1,
      sortColumn: 2,
      sortOrder: 3,
      limit: 4,
      paginate: 5,
      noRowsMessage: 6,
      direction: 7,
      hAlign: 8,
      vAlign: 9,
      gap: 10,
      autoRefresh: 11,
      getAdditionalDataContext: 15
    });
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[15];
  }
}
export {
  RepeaterBlock as default
};
