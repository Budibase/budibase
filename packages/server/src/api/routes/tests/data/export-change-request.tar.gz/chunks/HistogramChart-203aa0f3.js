import { S as SvelteComponent, i as init, s as safe_not_equal, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component } from "./index-a0738cd3.js";
import { A as ApexChart, p as parsePalette } from "./ApexChart-39eab0fb.js";
function create_fragment(ctx) {
  let apexchart;
  let current;
  apexchart = new ApexChart({ props: { options: (
    /*options*/
    ctx[0]
  ) } });
  return {
    c() {
      create_component(apexchart.$$.fragment);
    },
    m(target, anchor) {
      mount_component(apexchart, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const apexchart_changes = {};
      if (dirty & /*options*/
      1)
        apexchart_changes.options = /*options*/
        ctx2[0];
      apexchart.$set(apexchart_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(apexchart.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(apexchart.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(apexchart, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let series;
  let xAxisFormatter;
  let yAxisFormatter;
  let options;
  let { dataProvider } = $$props;
  let { valueColumn } = $$props;
  let { title } = $$props;
  let { xAxisLabel } = $$props;
  let { yAxisLabel } = $$props;
  let { height } = $$props;
  let { width } = $$props;
  let { dataLabels } = $$props;
  let { animate } = $$props;
  let { stacked } = $$props;
  let { palette } = $$props;
  let { c1, c2, c3, c4, c5 } = $$props;
  let { horizontal } = $$props;
  let { bucketCount = 10 } = $$props;
  let { onClick } = $$props;
  function handleBucketClick(rowsInBucket, lowerLimit, upperLimit) {
    onClick == null ? void 0 : onClick({ rowsInBucket, lowerLimit, upperLimit });
  }
  const getSeries = (dataProvider2, valueColumn2, bucketCount2) => {
    const rows = dataProvider2.rows ?? [];
    const values = rows.map((row) => parseFloat(row[valueColumn2])).filter((value) => !isNaN(value));
    const [min, max] = getValuesRange(values);
    const buckets = getBuckets(min, max, bucketCount2);
    const counts = Array(bucketCount2).fill(0);
    values.forEach((value) => {
      const bucketIndex = buckets.findIndex((bucket) => bucket.min <= value && value <= bucket.max);
      counts[bucketIndex]++;
    });
    const series2 = buckets.map((bucket, index) => ({
      x: `${bucket.min} – ${bucket.max}`,
      y: counts[index]
    }));
    return [{ data: series2 }];
  };
  const getValuesRange = (values) => {
    const min = Math.floor(Math.min(...values));
    const max = Math.ceil(Math.max(...values));
    return [min, max];
  };
  const getBuckets = (min, max, bucketCount2) => {
    var _a;
    bucketCount2 = bucketCount2 < 2 ? 2 : Math.floor(bucketCount2);
    const range = max - min;
    const bucketSize = Math.floor(range / bucketCount2);
    const bucketRemainder = range - bucketSize * bucketCount2;
    const buckets = [];
    for (let i = 0; i < bucketCount2; i++) {
      const lastBucketMax = ((_a = buckets == null ? void 0 : buckets[buckets.length - 1]) == null ? void 0 : _a.max) ?? min;
      const remainderPadding = i < bucketRemainder ? 1 : 0;
      buckets.push({
        min: lastBucketMax,
        max: lastBucketMax + bucketSize + remainderPadding
      });
    }
    return buckets;
  };
  const getFormatter = (horizontal2, axis) => {
    if (horizontal2 && axis === "x" || !horizontal2 && axis === "y") {
      return (value) => {
        if (Math.floor(value) === value) {
          return value;
        }
        return " ";
      };
    }
    return (value) => value;
  };
  $$self.$$set = ($$props2) => {
    if ("dataProvider" in $$props2)
      $$invalidate(1, dataProvider = $$props2.dataProvider);
    if ("valueColumn" in $$props2)
      $$invalidate(2, valueColumn = $$props2.valueColumn);
    if ("title" in $$props2)
      $$invalidate(3, title = $$props2.title);
    if ("xAxisLabel" in $$props2)
      $$invalidate(4, xAxisLabel = $$props2.xAxisLabel);
    if ("yAxisLabel" in $$props2)
      $$invalidate(5, yAxisLabel = $$props2.yAxisLabel);
    if ("height" in $$props2)
      $$invalidate(6, height = $$props2.height);
    if ("width" in $$props2)
      $$invalidate(7, width = $$props2.width);
    if ("dataLabels" in $$props2)
      $$invalidate(8, dataLabels = $$props2.dataLabels);
    if ("animate" in $$props2)
      $$invalidate(9, animate = $$props2.animate);
    if ("stacked" in $$props2)
      $$invalidate(10, stacked = $$props2.stacked);
    if ("palette" in $$props2)
      $$invalidate(11, palette = $$props2.palette);
    if ("c1" in $$props2)
      $$invalidate(12, c1 = $$props2.c1);
    if ("c2" in $$props2)
      $$invalidate(13, c2 = $$props2.c2);
    if ("c3" in $$props2)
      $$invalidate(14, c3 = $$props2.c3);
    if ("c4" in $$props2)
      $$invalidate(15, c4 = $$props2.c4);
    if ("c5" in $$props2)
      $$invalidate(16, c5 = $$props2.c5);
    if ("horizontal" in $$props2)
      $$invalidate(17, horizontal = $$props2.horizontal);
    if ("bucketCount" in $$props2)
      $$invalidate(18, bucketCount = $$props2.bucketCount);
    if ("onClick" in $$props2)
      $$invalidate(19, onClick = $$props2.onClick);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*dataProvider, valueColumn, bucketCount*/
    262150) {
      $$invalidate(22, series = getSeries(dataProvider, valueColumn, bucketCount));
    }
    if ($$self.$$.dirty & /*horizontal*/
    131072) {
      $$invalidate(21, xAxisFormatter = getFormatter(horizontal, "x"));
    }
    if ($$self.$$.dirty & /*horizontal*/
    131072) {
      $$invalidate(20, yAxisFormatter = getFormatter(horizontal, "y"));
    }
    if ($$self.$$.dirty & /*series, palette, c1, c2, c3, c4, c5, title, dataLabels, height, width, stacked, animate, dataProvider, valueColumn, bucketCount, horizontal, xAxisLabel, xAxisFormatter, yAxisLabel, yAxisFormatter*/
    7864318) {
      $$invalidate(0, options = {
        series,
        colors: palette === "Custom" ? [c1, c2, c3, c4, c5] : [],
        theme: { palette: parsePalette(palette) },
        title: { text: title },
        dataLabels: {
          enabled: dataLabels,
          dropShadow: { enabled: true }
        },
        chart: {
          height: height == null || height === "" ? "auto" : height,
          width: width == null || width === "" ? "100%" : width,
          type: "bar",
          stacked,
          animations: { enabled: animate },
          toolbar: { show: false },
          zoom: { enabled: false },
          events: {
            // Clicking on a bucket
            dataPointSelection(event, chartContext, opts) {
              const bucketIndex = opts.dataPointIndex;
              const rows = dataProvider.rows || [];
              const values = rows.map((row, i) => ({
                row,
                value: parseFloat(row[valueColumn]),
                i
              })).filter((obj) => !isNaN(obj.value));
              const [min, max] = getValuesRange(values.map((obj) => obj.value));
              const buckets = getBuckets(min, max, bucketCount);
              const bucket = buckets[bucketIndex];
              const rowsInBucket = values.filter((obj) => obj.value >= bucket.min && obj.value <= bucket.max).map((obj) => obj.row);
              handleBucketClick(rowsInBucket, bucket.min, bucket.max);
            }
          }
        },
        plotOptions: { bar: { horizontal } },
        xaxis: {
          type: "category",
          title: { text: xAxisLabel },
          labels: { formatter: xAxisFormatter }
        },
        yaxis: {
          decimalsInFloat: 0,
          title: { text: yAxisLabel },
          labels: { formatter: yAxisFormatter }
        }
      });
    }
  };
  return [
    options,
    dataProvider,
    valueColumn,
    title,
    xAxisLabel,
    yAxisLabel,
    height,
    width,
    dataLabels,
    animate,
    stacked,
    palette,
    c1,
    c2,
    c3,
    c4,
    c5,
    horizontal,
    bucketCount,
    onClick,
    yAxisFormatter,
    xAxisFormatter,
    series
  ];
}
class HistogramChart extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      dataProvider: 1,
      valueColumn: 2,
      title: 3,
      xAxisLabel: 4,
      yAxisLabel: 5,
      height: 6,
      width: 7,
      dataLabels: 8,
      animate: 9,
      stacked: 10,
      palette: 11,
      c1: 12,
      c2: 13,
      c3: 14,
      c4: 15,
      c5: 16,
      horizontal: 17,
      bucketCount: 18,
      onClick: 19
    });
  }
}
export {
  HistogramChart as default
};
