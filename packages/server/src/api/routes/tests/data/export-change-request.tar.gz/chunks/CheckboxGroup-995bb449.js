import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, a as space, b as attr, am as null_to_empty, f as insert, g as append, k as transition_in, z as group_outros, n as transition_out, A as check_outros, o as detach, Y as createEventDispatcher, I as Icon, c as create_component, t as text, d as toggle_class, m as mount_component, l as listen, j as set_data, p as destroy_component, N as ensure_array_like, y as empty, O as destroy_each } from "./index-a0738cd3.js";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[16] = list[i];
  const constants_0 = (
    /*getOptionValue*/
    child_ctx[6](
      /*option*/
      child_ctx[16]
    )
  );
  child_ctx[17] = constants_0;
  const constants_1 = (
    /*value*/
    child_ctx[1].includes(
      /*optionValue*/
      child_ctx[17]
    )
  );
  child_ctx[18] = constants_1;
  return child_ctx;
}
function create_if_block_1(ctx) {
  let div;
  let label;
  let input;
  let t0;
  let span1;
  let span0;
  let icon;
  let t1;
  let span2;
  let t2;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({
    props: {
      name: (
        /*indeterminate*/
        ctx[10] ? "minus" : "check"
      ),
      weight: "bold",
      color: "var(--spectrum-global-color-gray-50)"
    }
  });
  return {
    c() {
      div = element("div");
      label = element("label");
      input = element("input");
      t0 = space();
      span1 = element("span");
      span0 = element("span");
      create_component(icon.$$.fragment);
      t1 = space();
      span2 = element("span");
      t2 = text(
        /*selectAllText*/
        ctx[8]
      );
      attr(input, "type", "checkbox");
      attr(input, "class", "spectrum-Checkbox-input svelte-hnsjoe");
      input.checked = /*allSelected*/
      ctx[9];
      input.disabled = /*disabled*/
      ctx[3];
      attr(span0, "class", "icon svelte-hnsjoe");
      toggle_class(
        span0,
        "checked",
        /*allSelected*/
        ctx[9] || /*indeterminate*/
        ctx[10]
      );
      attr(span1, "class", "spectrum-Checkbox-box");
      attr(span2, "class", "spectrum-Checkbox-label");
      attr(label, "class", "spectrum-Checkbox spectrum-Checkbox--sizeM spectrum-FieldGroup-item svelte-hnsjoe");
      attr(
        div,
        "title",
        /*selectAllText*/
        ctx[8]
      );
      attr(div, "class", "spectrum-Checkbox spectrum-FieldGroup-item select-all-checkbox svelte-hnsjoe");
      toggle_class(
        div,
        "readonly",
        /*readonly*/
        ctx[4]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, label);
      append(label, input);
      append(label, t0);
      append(label, span1);
      append(span1, span0);
      mount_component(icon, span0, null);
      append(label, t1);
      append(label, span2);
      append(span2, t2);
      current = true;
      if (!mounted) {
        dispose = listen(
          input,
          "change",
          /*toggleSelectAll*/
          ctx[12]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (!current || dirty & /*allSelected*/
      512) {
        input.checked = /*allSelected*/
        ctx2[9];
      }
      if (!current || dirty & /*disabled*/
      8) {
        input.disabled = /*disabled*/
        ctx2[3];
      }
      const icon_changes = {};
      if (dirty & /*indeterminate*/
      1024)
        icon_changes.name = /*indeterminate*/
        ctx2[10] ? "minus" : "check";
      icon.$set(icon_changes);
      if (!current || dirty & /*allSelected, indeterminate*/
      1536) {
        toggle_class(
          span0,
          "checked",
          /*allSelected*/
          ctx2[9] || /*indeterminate*/
          ctx2[10]
        );
      }
      if (!current || dirty & /*selectAllText*/
      256)
        set_data(
          t2,
          /*selectAllText*/
          ctx2[8]
        );
      if (!current || dirty & /*selectAllText*/
      256) {
        attr(
          div,
          "title",
          /*selectAllText*/
          ctx2[8]
        );
      }
      if (!current || dirty & /*readonly*/
      16) {
        toggle_class(
          div,
          "readonly",
          /*readonly*/
          ctx2[4]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block(ctx) {
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(
    /*options*/
    ctx[2]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*getOptionLabel, options, readonly, value, getOptionValue, disabled, onChange*/
      2174) {
        each_value = ensure_array_like(
          /*options*/
          ctx2[2]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_each_block(ctx) {
  let div;
  let label;
  let input;
  let input_checked_value;
  let t0;
  let span1;
  let span0;
  let icon;
  let t1;
  let span2;
  let t2_value = (
    /*getOptionLabel*/
    ctx[5](
      /*option*/
      ctx[16]
    ) + ""
  );
  let t2;
  let t3;
  let div_title_value;
  let current;
  let mounted;
  let dispose;
  function change_handler() {
    return (
      /*change_handler*/
      ctx[14](
        /*optionValue*/
        ctx[17]
      )
    );
  }
  icon = new Icon({
    props: {
      name: "check",
      weight: "bold",
      color: "var(--spectrum-global-color-gray-50)"
    }
  });
  return {
    c() {
      div = element("div");
      label = element("label");
      input = element("input");
      t0 = space();
      span1 = element("span");
      span0 = element("span");
      create_component(icon.$$.fragment);
      t1 = space();
      span2 = element("span");
      t2 = text(t2_value);
      t3 = space();
      attr(input, "type", "checkbox");
      attr(input, "class", "spectrum-Checkbox-input svelte-hnsjoe");
      input.checked = input_checked_value = /*checked*/
      ctx[18];
      input.disabled = /*disabled*/
      ctx[3];
      attr(span0, "class", "icon svelte-hnsjoe");
      toggle_class(
        span0,
        "checked",
        /*checked*/
        ctx[18]
      );
      attr(span1, "class", "spectrum-Checkbox-box");
      attr(span2, "class", "spectrum-Checkbox-label");
      attr(label, "class", "spectrum-Checkbox spectrum-Checkbox--sizeM spectrum-FieldGroup-item svelte-hnsjoe");
      attr(div, "title", div_title_value = /*getOptionLabel*/
      ctx[5](
        /*option*/
        ctx[16]
      ));
      attr(div, "class", "spectrum-Checkbox spectrum-FieldGroup-item svelte-hnsjoe");
      toggle_class(
        div,
        "readonly",
        /*readonly*/
        ctx[4]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, label);
      append(label, input);
      append(label, t0);
      append(label, span1);
      append(span1, span0);
      mount_component(icon, span0, null);
      append(label, t1);
      append(label, span2);
      append(span2, t2);
      append(div, t3);
      current = true;
      if (!mounted) {
        dispose = listen(input, "change", change_handler);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (!current || dirty & /*value, getOptionValue, options*/
      70 && input_checked_value !== (input_checked_value = /*checked*/
      ctx[18])) {
        input.checked = input_checked_value;
      }
      if (!current || dirty & /*disabled*/
      8) {
        input.disabled = /*disabled*/
        ctx[3];
      }
      if (!current || dirty & /*value, getOptionValue, options*/
      70) {
        toggle_class(
          span0,
          "checked",
          /*checked*/
          ctx[18]
        );
      }
      if ((!current || dirty & /*getOptionLabel, options*/
      36) && t2_value !== (t2_value = /*getOptionLabel*/
      ctx[5](
        /*option*/
        ctx[16]
      ) + ""))
        set_data(t2, t2_value);
      if (!current || dirty & /*getOptionLabel, options*/
      36 && div_title_value !== (div_title_value = /*getOptionLabel*/
      ctx[5](
        /*option*/
        ctx[16]
      ))) {
        attr(div, "title", div_title_value);
      }
      if (!current || dirty & /*readonly*/
      16) {
        toggle_class(
          div,
          "readonly",
          /*readonly*/
          ctx[4]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
      mounted = false;
      dispose();
    }
  };
}
function create_fragment(ctx) {
  var _a;
  let div;
  let t;
  let show_if = (
    /*options*/
    ctx[2] && Array.isArray(
      /*options*/
      ctx[2]
    )
  );
  let div_class_value;
  let current;
  let if_block0 = (
    /*showSelectAll*/
    ctx[7] && /*options*/
    ((_a = ctx[2]) == null ? void 0 : _a.length) > 0 && create_if_block_1(ctx)
  );
  let if_block1 = show_if && create_if_block(ctx);
  return {
    c() {
      div = element("div");
      if (if_block0)
        if_block0.c();
      t = space();
      if (if_block1)
        if_block1.c();
      attr(div, "class", div_class_value = null_to_empty(`spectrum-FieldGroup spectrum-FieldGroup--${/*direction*/
      ctx[0]}`) + " svelte-hnsjoe");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block0)
        if_block0.m(div, null);
      append(div, t);
      if (if_block1)
        if_block1.m(div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      var _a2;
      if (
        /*showSelectAll*/
        ctx2[7] && /*options*/
        ((_a2 = ctx2[2]) == null ? void 0 : _a2.length) > 0
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty & /*showSelectAll, options*/
          132) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_1(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(div, t);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (dirty & /*options*/
      4)
        show_if = /*options*/
        ctx2[2] && Array.isArray(
          /*options*/
          ctx2[2]
        );
      if (show_if) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty & /*options*/
          4) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div, null);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if (!current || dirty & /*direction*/
      1 && div_class_value !== (div_class_value = null_to_empty(`spectrum-FieldGroup spectrum-FieldGroup--${/*direction*/
      ctx2[0]}`) + " svelte-hnsjoe")) {
        attr(div, "class", div_class_value);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let allSelected;
  let noneSelected;
  let indeterminate;
  let { direction = "vertical" } = $$props;
  let { value = [] } = $$props;
  let { options = [] } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { getOptionLabel = (option) => `${option}` } = $$props;
  let { getOptionValue = (option) => option } = $$props;
  let { showSelectAll = false } = $$props;
  let { selectAllText = "Select all" } = $$props;
  const dispatch = createEventDispatcher();
  const onChange = (optionValue) => {
    if (!value.includes(optionValue)) {
      dispatch("change", [...value, optionValue]);
    } else {
      dispatch("change", value.filter((x) => x !== optionValue));
    }
  };
  const toggleSelectAll = () => {
    if (allSelected) {
      dispatch("change", []);
    } else {
      const allValues = options.map((option) => getOptionValue(option));
      dispatch("change", allValues);
    }
  };
  const change_handler = (optionValue) => onChange(optionValue);
  $$self.$$set = ($$props2) => {
    if ("direction" in $$props2)
      $$invalidate(0, direction = $$props2.direction);
    if ("value" in $$props2)
      $$invalidate(1, value = $$props2.value);
    if ("options" in $$props2)
      $$invalidate(2, options = $$props2.options);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(4, readonly = $$props2.readonly);
    if ("getOptionLabel" in $$props2)
      $$invalidate(5, getOptionLabel = $$props2.getOptionLabel);
    if ("getOptionValue" in $$props2)
      $$invalidate(6, getOptionValue = $$props2.getOptionValue);
    if ("showSelectAll" in $$props2)
      $$invalidate(7, showSelectAll = $$props2.showSelectAll);
    if ("selectAllText" in $$props2)
      $$invalidate(8, selectAllText = $$props2.selectAllText);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*options, value, getOptionValue*/
    70) {
      $$invalidate(9, allSelected = options.length > 0 && options.every((option) => value.includes(getOptionValue(option))));
    }
    if ($$self.$$.dirty & /*options, value, getOptionValue*/
    70) {
      $$invalidate(13, noneSelected = options.length === 0 || options.every((option) => !value.includes(getOptionValue(option))));
    }
    if ($$self.$$.dirty & /*allSelected, noneSelected*/
    8704) {
      $$invalidate(10, indeterminate = !allSelected && !noneSelected);
    }
  };
  return [
    direction,
    value,
    options,
    disabled,
    readonly,
    getOptionLabel,
    getOptionValue,
    showSelectAll,
    selectAllText,
    allSelected,
    indeterminate,
    onChange,
    toggleSelectAll,
    noneSelected,
    change_handler
  ];
}
class CheckboxGroup extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      direction: 0,
      value: 1,
      options: 2,
      disabled: 3,
      readonly: 4,
      getOptionLabel: 5,
      getOptionValue: 6,
      showSelectAll: 7,
      selectAllText: 8
    });
  }
}
export {
  CheckboxGroup as C
};
