import { S as SvelteComponent, i as init, s as safe_not_equal, c6 as Picker, W as binding_callbacks, a0 as bind, c as create_component, m as mount_component, a1 as add_flush_callback, k as transition_in, n as transition_out, p as destroy_component, Y as createEventDispatcher, V as bubble } from "./index-a0738cd3.js";
function create_fragment(ctx) {
  let picker;
  let updating_searchTerm;
  let updating_open;
  let current;
  function picker_searchTerm_binding(value) {
    ctx[29](value);
  }
  function picker_open_binding(value) {
    ctx[30](value);
  }
  let picker_props = {
    id: (
      /*id*/
      ctx[2]
    ),
    disabled: (
      /*disabled*/
      ctx[3]
    ),
    readonly: (
      /*readonly*/
      ctx[7]
    ),
    fieldText: (
      /*fieldText*/
      ctx[21]
    ),
    options: (
      /*options*/
      ctx[4]
    ),
    isPlaceholder: !/*arrayValue*/
    ctx[18].length,
    autocomplete: (
      /*autocomplete*/
      ctx[8]
    ),
    isOptionSelected: (
      /*isOptionSelected*/
      ctx[20]
    ),
    getOptionLabel: (
      /*getOptionLabel*/
      ctx[5]
    ),
    getOptionValue: (
      /*getOptionValue*/
      ctx[6]
    ),
    onSelectOption: (
      /*toggleOption*/
      ctx[19]
    ),
    sort: (
      /*sort*/
      ctx[9]
    ),
    autoWidth: (
      /*autoWidth*/
      ctx[10]
    ),
    customPopoverHeight: (
      /*customPopoverHeight*/
      ctx[11]
    ),
    loading: (
      /*loading*/
      ctx[12]
    ),
    onOptionMouseenter: (
      /*onOptionMouseenter*/
      ctx[13]
    ),
    onOptionMouseleave: (
      /*onOptionMouseleave*/
      ctx[14]
    ),
    showSelectAll: (
      /*showSelectAll*/
      ctx[15]
    ),
    selectAllText: (
      /*selectAllText*/
      ctx[16]
    ),
    indeterminate: (
      /*indeterminate*/
      ctx[22]
    ),
    allSelected: (
      /*allSelected*/
      ctx[17]
    ),
    toggleSelectAll: (
      /*toggleSelectAll*/
      ctx[23]
    )
  };
  if (
    /*searchTerm*/
    ctx[0] !== void 0
  ) {
    picker_props.searchTerm = /*searchTerm*/
    ctx[0];
  }
  if (
    /*open*/
    ctx[1] !== void 0
  ) {
    picker_props.open = /*open*/
    ctx[1];
  }
  picker = new Picker({ props: picker_props });
  binding_callbacks.push(() => bind(picker, "searchTerm", picker_searchTerm_binding));
  binding_callbacks.push(() => bind(picker, "open", picker_open_binding));
  picker.$on(
    "loadMore",
    /*loadMore_handler*/
    ctx[31]
  );
  return {
    c() {
      create_component(picker.$$.fragment);
    },
    m(target, anchor) {
      mount_component(picker, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const picker_changes = {};
      if (dirty[0] & /*id*/
      4)
        picker_changes.id = /*id*/
        ctx2[2];
      if (dirty[0] & /*disabled*/
      8)
        picker_changes.disabled = /*disabled*/
        ctx2[3];
      if (dirty[0] & /*readonly*/
      128)
        picker_changes.readonly = /*readonly*/
        ctx2[7];
      if (dirty[0] & /*fieldText*/
      2097152)
        picker_changes.fieldText = /*fieldText*/
        ctx2[21];
      if (dirty[0] & /*options*/
      16)
        picker_changes.options = /*options*/
        ctx2[4];
      if (dirty[0] & /*arrayValue*/
      262144)
        picker_changes.isPlaceholder = !/*arrayValue*/
        ctx2[18].length;
      if (dirty[0] & /*autocomplete*/
      256)
        picker_changes.autocomplete = /*autocomplete*/
        ctx2[8];
      if (dirty[0] & /*isOptionSelected*/
      1048576)
        picker_changes.isOptionSelected = /*isOptionSelected*/
        ctx2[20];
      if (dirty[0] & /*getOptionLabel*/
      32)
        picker_changes.getOptionLabel = /*getOptionLabel*/
        ctx2[5];
      if (dirty[0] & /*getOptionValue*/
      64)
        picker_changes.getOptionValue = /*getOptionValue*/
        ctx2[6];
      if (dirty[0] & /*toggleOption*/
      524288)
        picker_changes.onSelectOption = /*toggleOption*/
        ctx2[19];
      if (dirty[0] & /*sort*/
      512)
        picker_changes.sort = /*sort*/
        ctx2[9];
      if (dirty[0] & /*autoWidth*/
      1024)
        picker_changes.autoWidth = /*autoWidth*/
        ctx2[10];
      if (dirty[0] & /*customPopoverHeight*/
      2048)
        picker_changes.customPopoverHeight = /*customPopoverHeight*/
        ctx2[11];
      if (dirty[0] & /*loading*/
      4096)
        picker_changes.loading = /*loading*/
        ctx2[12];
      if (dirty[0] & /*onOptionMouseenter*/
      8192)
        picker_changes.onOptionMouseenter = /*onOptionMouseenter*/
        ctx2[13];
      if (dirty[0] & /*onOptionMouseleave*/
      16384)
        picker_changes.onOptionMouseleave = /*onOptionMouseleave*/
        ctx2[14];
      if (dirty[0] & /*showSelectAll*/
      32768)
        picker_changes.showSelectAll = /*showSelectAll*/
        ctx2[15];
      if (dirty[0] & /*selectAllText*/
      65536)
        picker_changes.selectAllText = /*selectAllText*/
        ctx2[16];
      if (dirty[0] & /*indeterminate*/
      4194304)
        picker_changes.indeterminate = /*indeterminate*/
        ctx2[22];
      if (dirty[0] & /*allSelected*/
      131072)
        picker_changes.allSelected = /*allSelected*/
        ctx2[17];
      if (!updating_searchTerm && dirty[0] & /*searchTerm*/
      1) {
        updating_searchTerm = true;
        picker_changes.searchTerm = /*searchTerm*/
        ctx2[0];
        add_flush_callback(() => updating_searchTerm = false);
      }
      if (!updating_open && dirty[0] & /*open*/
      2) {
        updating_open = true;
        picker_changes.open = /*open*/
        ctx2[1];
        add_flush_callback(() => updating_open = false);
      }
      picker.$set(picker_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(picker.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(picker.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(picker, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let arrayValue;
  let selectedLookupMap;
  let optionLookupMap;
  let allSelected;
  let noneSelected;
  let indeterminate;
  let fieldText;
  let isOptionSelected;
  let toggleOption;
  let { value = [] } = $$props;
  let { id = void 0 } = $$props;
  let { placeholder = null } = $$props;
  let { disabled = false } = $$props;
  let { options = [] } = $$props;
  let { getOptionLabel = (option, _index) => option } = $$props;
  let { getOptionValue = (option, _index) => option } = $$props;
  let { readonly = false } = $$props;
  let { autocomplete = false } = $$props;
  let { sort = false } = $$props;
  let { autoWidth = false } = $$props;
  let { searchTerm = null } = $$props;
  let { customPopoverHeight = void 0 } = $$props;
  let { open = false } = $$props;
  let { loading = false } = $$props;
  let { onOptionMouseenter = () => {
  } } = $$props;
  let { onOptionMouseleave = () => {
  } } = $$props;
  let { showSelectAll = false } = $$props;
  let { selectAllText = "Select all" } = $$props;
  const dispatch = createEventDispatcher();
  const getFieldText = (value2, map, placeholder2) => {
    if (Array.isArray(value2) && value2.length > 0) {
      if (!map) {
        return "";
      }
      const vals = value2.map((v) => {
        const str = typeof v === "string" ? v : v.toString();
        return map[str] || v;
      }).join(", ");
      return `(${value2.length}) ${vals}`;
    } else {
      return placeholder2 || "Choose some options";
    }
  };
  const getSelectedLookupMap = (value2) => {
    const map = {};
    if (Array.isArray(value2) && value2.length > 0) {
      value2.forEach((v) => {
        if (v) {
          const str = typeof v === "string" ? v : v.toString();
          map[str] = true;
        }
      });
    }
    return map;
  };
  const getOptionLookupMap = (options2) => {
    if (!(options2 == null ? void 0 : options2.length)) {
      return null;
    }
    const map = {};
    options2.forEach((option, idx) => {
      const optionValue = getOptionValue(option, idx);
      if (optionValue != null) {
        map[optionValue] = getOptionLabel(option, idx) || "";
      }
    });
    return map;
  };
  const makeToggleOption = (map, value2) => {
    return (optionValue) => {
      if (map[optionValue]) {
        const filtered = value2.filter((option) => option.toString() !== optionValue.toString());
        dispatch("change", filtered);
      } else {
        dispatch("change", [...value2, optionValue]);
      }
    };
  };
  const toggleSelectAll = () => {
    if (allSelected) {
      dispatch("change", []);
    } else {
      const allValues = options.map((option) => getOptionValue(option));
      dispatch("change", allValues);
    }
  };
  function picker_searchTerm_binding(value2) {
    searchTerm = value2;
    $$invalidate(0, searchTerm);
  }
  function picker_open_binding(value2) {
    open = value2;
    $$invalidate(1, open);
  }
  function loadMore_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(24, value = $$props2.value);
    if ("id" in $$props2)
      $$invalidate(2, id = $$props2.id);
    if ("placeholder" in $$props2)
      $$invalidate(25, placeholder = $$props2.placeholder);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("options" in $$props2)
      $$invalidate(4, options = $$props2.options);
    if ("getOptionLabel" in $$props2)
      $$invalidate(5, getOptionLabel = $$props2.getOptionLabel);
    if ("getOptionValue" in $$props2)
      $$invalidate(6, getOptionValue = $$props2.getOptionValue);
    if ("readonly" in $$props2)
      $$invalidate(7, readonly = $$props2.readonly);
    if ("autocomplete" in $$props2)
      $$invalidate(8, autocomplete = $$props2.autocomplete);
    if ("sort" in $$props2)
      $$invalidate(9, sort = $$props2.sort);
    if ("autoWidth" in $$props2)
      $$invalidate(10, autoWidth = $$props2.autoWidth);
    if ("searchTerm" in $$props2)
      $$invalidate(0, searchTerm = $$props2.searchTerm);
    if ("customPopoverHeight" in $$props2)
      $$invalidate(11, customPopoverHeight = $$props2.customPopoverHeight);
    if ("open" in $$props2)
      $$invalidate(1, open = $$props2.open);
    if ("loading" in $$props2)
      $$invalidate(12, loading = $$props2.loading);
    if ("onOptionMouseenter" in $$props2)
      $$invalidate(13, onOptionMouseenter = $$props2.onOptionMouseenter);
    if ("onOptionMouseleave" in $$props2)
      $$invalidate(14, onOptionMouseleave = $$props2.onOptionMouseleave);
    if ("showSelectAll" in $$props2)
      $$invalidate(15, showSelectAll = $$props2.showSelectAll);
    if ("selectAllText" in $$props2)
      $$invalidate(16, selectAllText = $$props2.selectAllText);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*value*/
    16777216) {
      $$invalidate(18, arrayValue = Array.isArray(value) ? value : [value].filter((x) => !!x));
    }
    if ($$self.$$.dirty[0] & /*arrayValue*/
    262144) {
      $$invalidate(26, selectedLookupMap = getSelectedLookupMap(arrayValue));
    }
    if ($$self.$$.dirty[0] & /*options*/
    16) {
      $$invalidate(27, optionLookupMap = getOptionLookupMap(options));
    }
    if ($$self.$$.dirty[0] & /*options, arrayValue, getOptionValue*/
    262224) {
      $$invalidate(17, allSelected = options.length > 0 && options.every((option) => arrayValue.includes(getOptionValue(option))));
    }
    if ($$self.$$.dirty[0] & /*options, arrayValue, getOptionValue*/
    262224) {
      $$invalidate(28, noneSelected = options.length === 0 || options.every((option) => !arrayValue.includes(getOptionValue(option))));
    }
    if ($$self.$$.dirty[0] & /*allSelected, noneSelected*/
    268566528) {
      $$invalidate(22, indeterminate = !allSelected && !noneSelected);
    }
    if ($$self.$$.dirty[0] & /*arrayValue, optionLookupMap, placeholder*/
    168034304) {
      $$invalidate(21, fieldText = getFieldText(arrayValue, optionLookupMap, placeholder));
    }
    if ($$self.$$.dirty[0] & /*selectedLookupMap*/
    67108864) {
      $$invalidate(20, isOptionSelected = (optionValue) => selectedLookupMap[optionValue] === true);
    }
    if ($$self.$$.dirty[0] & /*selectedLookupMap, arrayValue*/
    67371008) {
      $$invalidate(19, toggleOption = makeToggleOption(selectedLookupMap, arrayValue));
    }
  };
  return [
    searchTerm,
    open,
    id,
    disabled,
    options,
    getOptionLabel,
    getOptionValue,
    readonly,
    autocomplete,
    sort,
    autoWidth,
    customPopoverHeight,
    loading,
    onOptionMouseenter,
    onOptionMouseleave,
    showSelectAll,
    selectAllText,
    allSelected,
    arrayValue,
    toggleOption,
    isOptionSelected,
    fieldText,
    indeterminate,
    toggleSelectAll,
    value,
    placeholder,
    selectedLookupMap,
    optionLookupMap,
    noneSelected,
    picker_searchTerm_binding,
    picker_open_binding,
    loadMore_handler
  ];
}
class Multiselect extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        value: 24,
        id: 2,
        placeholder: 25,
        disabled: 3,
        options: 4,
        getOptionLabel: 5,
        getOptionValue: 6,
        readonly: 7,
        autocomplete: 8,
        sort: 9,
        autoWidth: 10,
        searchTerm: 0,
        customPopoverHeight: 11,
        open: 1,
        loading: 12,
        onOptionMouseenter: 13,
        onOptionMouseleave: 14,
        showSelectAll: 15,
        selectAllText: 16
      },
      null,
      [-1, -1]
    );
  }
}
export {
  Multiselect as M
};
