import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, t as text, a as space, b as attr, f as insert, g as append, q as action_destroyer, j as set_data, h as is_function, B as noop, o as detach, u as getContext, v as component_subscribe } from "./index-a0738cd3.js";
const CardStat_svelte_svelte_type_style_lang = "";
function create_fragment(ctx) {
  let div;
  let p0;
  let t0;
  let t1;
  let h3;
  let t2;
  let t3;
  let p1;
  let t4;
  let styleable_action;
  let mounted;
  let dispose;
  return {
    c() {
      div = element("div");
      p0 = element("p");
      t0 = text(
        /*title*/
        ctx[0]
      );
      t1 = space();
      h3 = element("h3");
      t2 = text(
        /*value*/
        ctx[1]
      );
      t3 = space();
      p1 = element("p");
      t4 = text(
        /*label*/
        ctx[2]
      );
      attr(p0, "class", "title svelte-13s6ero");
      attr(h3, "class", "value svelte-13s6ero");
      attr(p1, "class", "label svelte-13s6ero");
      attr(div, "class", "container svelte-13s6ero");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, p0);
      append(p0, t0);
      append(div, t1);
      append(div, h3);
      append(h3, t2);
      append(div, t3);
      append(div, p1);
      append(p1, t4);
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[4].call(
          null,
          div,
          /*$component*/
          ctx[3].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & /*title*/
      1)
        set_data(
          t0,
          /*title*/
          ctx2[0]
        );
      if (dirty & /*value*/
      2)
        set_data(
          t2,
          /*value*/
          ctx2[1]
        );
      if (dirty & /*label*/
      4)
        set_data(
          t4,
          /*label*/
          ctx2[2]
        );
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      8)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[3].styles
        );
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $component;
  const { styleable } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value2) => $$invalidate(3, $component = value2));
  const className = "";
  let { title = "" } = $$props;
  let { value = "" } = $$props;
  let { label = "" } = $$props;
  $$self.$$set = ($$props2) => {
    if ("title" in $$props2)
      $$invalidate(0, title = $$props2.title);
    if ("value" in $$props2)
      $$invalidate(1, value = $$props2.value);
    if ("label" in $$props2)
      $$invalidate(2, label = $$props2.label);
  };
  return [title, value, label, $component, styleable, component, className];
}
class CardStat extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      className: 6,
      title: 0,
      value: 1,
      label: 2
    });
  }
  get className() {
    return this.$$.ctx[6];
  }
}
export {
  CardStat as default
};
