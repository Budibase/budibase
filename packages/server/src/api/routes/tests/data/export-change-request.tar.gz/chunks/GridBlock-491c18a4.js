import { S as SvelteComponent, i as init, s as safe_not_equal, I as Icon, F as create_slot, e as element, c as create_component, a as space, t as text, b as attr, f as insert, m as mount_component, g as append, j as set_data, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, k as transition_in, z as group_outros, n as transition_out, A as check_outros, o as detach, p as destroy_component, N as ensure_array_like, y as empty, O as destroy_each, ap as Button, h as is_function, al as set_style, d as toggle_class, au as compute_slots, av as AbsTooltip, w as onDestroy, aw as isDeprecatedSingleUserColumn, ax as TypeIconMap, Y as createEventDispatcher, a2 as derived, a3 as writable, ay as GutterWidth, az as get_store_value, aA as DefaultColumnWidth, aB as CellIDSeparator, aC as GeneratedIDPrefix, at as uuid, aD as MinColumnWidth, aE as getRelatedTableValues, aF as tick, D as fetchData, aG as RowPageSize, aH as NewRowID, aI as sleep, aJ as capitalise, aK as FieldType, aL as VPadding, aM as FocusedCellMinOffset, aN as HPadding, aO as ScrollBarSize, aP as DefaultRowHeight, aQ as LargeRowHeight, aR as MediumRowHeight, aS as getUserColor, aT as getUserLabel, aU as copyToClipboard, aV as ViewV2Type, aW as derivedMemo, aX as memo, aY as SortOrder, aZ as UILogicalOperator, a_ as BasicOperator, a$ as ArrayOperator, a6 as notifications, b0 as getDatasourceSchema, b1 as enrichSchemaWithRelColumns, b2 as getDatasourceDefinition, b3 as cloneDeep, b4 as Conditions, ac as Modal, u as getContext, v as component_subscribe, U as onMount, W as binding_callbacks, a4 as ModalContent, l as listen, b5 as self, r as run_all, b6 as domDebounce, V as bubble, b7 as TextCell, b8 as getCellRenderer, b9 as construct_svelte_component, a0 as bind, a1 as add_flush_callback, B as noop, C as subscribe, ba as set_store_value, bb as BlankRowID, bc as GridPopover, a7 as Input, bd as ValidColumnNameRegex, be as FormulaType, bf as debounce, bg as set_input_value, bh as TableNames, bi as TooltipType, bj as Checkbox_1, Q as add_render_callback, R as create_bidirectional_transition, _ as fade, Z as create_in_transition, bk as createWebsocket, bl as SocketEvent, bm as GridSocketEvent, bn as MaxCellRenderOverflow, bo as ControlsHeight, bp as createAPIClient, bq as Constants, br as SmallRowHeight, X as setContext, bs as assign, bt as exclude_internal_props, P as ProgressCircle, q as action_destroyer, af as clickOutside, bu as featuresStore, E as EmptyFilterOption, bv as processStringSync, bw as readable } from "./index-a0738cd3.js";
import { C as CollapsedButtonGroup } from "./CollapsedButtonGroup-2dfcf354.js";
import { c as canBeSortColumn, a as canBeDisplayColumn } from "./table-a8827bda.js";
import { M as Menu$1, I as Item } from "./Item-9d93f702.js";
import { U as UserAvatar } from "./UserAvatar-be3a991a.js";
function get_each_context$9(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[12] = list[i];
  return child_ctx;
}
function create_each_block$9(ctx) {
  let div;
  let t_value = (
    /*splitMsg*/
    ctx[12] + ""
  );
  let t;
  return {
    c() {
      div = element("div");
      t = text(t_value);
      attr(div, "class", "spectrum-InLineAlert-content");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*split*/
      128 && t_value !== (t_value = /*splitMsg*/
      ctx2[12] + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function fallback_block(ctx) {
  let each_1_anchor;
  let each_value = ensure_array_like(
    /*split*/
    ctx[7]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$9(get_each_context$9(ctx, each_value, i));
  }
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*split*/
      128) {
        each_value = ensure_array_like(
          /*split*/
          ctx2[7]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$9(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$9(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_if_block_1$c(ctx) {
  let div;
  let button;
  let current;
  button = new Button({
    props: {
      cta: (
        /*cta*/
        ctx[4]
      ),
      secondary: (
        /*cta*/
        ctx[4] ? false : true
      ),
      $$slots: { default: [create_default_slot$g] },
      $$scope: { ctx }
    }
  });
  button.$on("click", function() {
    if (is_function(
      /*onConfirm*/
      ctx[2]
    ))
      ctx[2].apply(this, arguments);
  });
  return {
    c() {
      div = element("div");
      create_component(button.$$.fragment);
      attr(div, "class", "spectrum-InLineAlert-footer button svelte-1399oda");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(button, div, null);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const button_changes = {};
      if (dirty & /*cta*/
      16)
        button_changes.cta = /*cta*/
        ctx[4];
      if (dirty & /*cta*/
      16)
        button_changes.secondary = /*cta*/
        ctx[4] ? false : true;
      if (dirty & /*$$scope, buttonText*/
      2056) {
        button_changes.$$scope = { dirty, ctx };
      }
      button.$set(button_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(button.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(button.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(button);
    }
  };
}
function create_default_slot$g(ctx) {
  let t_value = (
    /*buttonText*/
    (ctx[3] || "OK") + ""
  );
  let t;
  return {
    c() {
      t = text(t_value);
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*buttonText*/
      8 && t_value !== (t_value = /*buttonText*/
      (ctx2[3] || "OK") + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block$j(ctx) {
  let div;
  let a;
  let t0;
  let t1;
  let icon_1;
  let current;
  icon_1 = new Icon({
    props: { name: "arrow-square-out", size: "XS" }
  });
  return {
    c() {
      div = element("div");
      a = element("a");
      t0 = text(
        /*linkText*/
        ctx[6]
      );
      t1 = space();
      create_component(icon_1.$$.fragment);
      attr(
        a,
        "href",
        /*link*/
        ctx[5]
      );
      attr(a, "target", "_blank");
      attr(a, "rel", "noopener noreferrer");
      attr(a, "class", "docs-link svelte-1399oda");
      attr(div, "id", "docs-link");
      attr(div, "class", "svelte-1399oda");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, a);
      append(a, t0);
      append(a, t1);
      mount_component(icon_1, a, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (!current || dirty & /*linkText*/
      64)
        set_data(
          t0,
          /*linkText*/
          ctx2[6]
        );
      if (!current || dirty & /*link*/
      32) {
        attr(
          a,
          "href",
          /*link*/
          ctx2[5]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon_1);
    }
  };
}
function create_fragment$r(ctx) {
  let div1;
  let icon_1;
  let t0;
  let div0;
  let t1;
  let t2;
  let t3;
  let t4;
  let div1_class_value;
  let current;
  icon_1 = new Icon({
    props: { name: (
      /*icon*/
      ctx[8]
    ), size: "M" }
  });
  const default_slot_template = (
    /*#slots*/
    ctx[10].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[11],
    null
  );
  const default_slot_or_fallback = default_slot || fallback_block(ctx);
  let if_block0 = (
    /*onConfirm*/
    ctx[2] && create_if_block_1$c(ctx)
  );
  let if_block1 = (
    /*link*/
    ctx[5] && /*linkText*/
    ctx[6] && create_if_block$j(ctx)
  );
  return {
    c() {
      div1 = element("div");
      create_component(icon_1.$$.fragment);
      t0 = space();
      div0 = element("div");
      t1 = text(
        /*header*/
        ctx[1]
      );
      t2 = space();
      if (default_slot_or_fallback)
        default_slot_or_fallback.c();
      t3 = space();
      if (if_block0)
        if_block0.c();
      t4 = space();
      if (if_block1)
        if_block1.c();
      attr(div0, "class", "spectrum-InLineAlert-header");
      attr(div1, "class", div1_class_value = "spectrum-InLineAlert spectrum-InLineAlert--" + /*type*/
      ctx[0] + " svelte-1399oda");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      mount_component(icon_1, div1, null);
      append(div1, t0);
      append(div1, div0);
      append(div0, t1);
      append(div1, t2);
      if (default_slot_or_fallback) {
        default_slot_or_fallback.m(div1, null);
      }
      append(div1, t3);
      if (if_block0)
        if_block0.m(div1, null);
      append(div1, t4);
      if (if_block1)
        if_block1.m(div1, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      const icon_1_changes = {};
      if (dirty & /*icon*/
      256)
        icon_1_changes.name = /*icon*/
        ctx2[8];
      icon_1.$set(icon_1_changes);
      if (!current || dirty & /*header*/
      2)
        set_data(
          t1,
          /*header*/
          ctx2[1]
        );
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        2048)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[11],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[11]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[11],
              dirty,
              null
            ),
            null
          );
        }
      } else {
        if (default_slot_or_fallback && default_slot_or_fallback.p && (!current || dirty & /*split*/
        128)) {
          default_slot_or_fallback.p(ctx2, !current ? -1 : dirty);
        }
      }
      if (
        /*onConfirm*/
        ctx2[2]
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty & /*onConfirm*/
          4) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_1$c(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(div1, t4);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (
        /*link*/
        ctx2[5] && /*linkText*/
        ctx2[6]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty & /*link, linkText*/
          96) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block$j(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div1, null);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if (!current || dirty & /*type*/
      1 && div1_class_value !== (div1_class_value = "spectrum-InLineAlert spectrum-InLineAlert--" + /*type*/
      ctx2[0] + " svelte-1399oda")) {
        attr(div1, "class", div1_class_value);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon_1.$$.fragment, local);
      transition_in(default_slot_or_fallback, local);
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(icon_1.$$.fragment, local);
      transition_out(default_slot_or_fallback, local);
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      destroy_component(icon_1);
      if (default_slot_or_fallback)
        default_slot_or_fallback.d(detaching);
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
    }
  };
}
function selectIcon(alertType) {
  switch (alertType) {
    case "error":
    case "negative":
      return "warning";
    case "success":
      return "check-circle";
    case "help":
      return "question";
    default:
      return "info";
  }
}
function instance$r($$self, $$props, $$invalidate) {
  let icon;
  let split;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { type = "info" } = $$props;
  let { header = "" } = $$props;
  let { message = "" } = $$props;
  let { onConfirm = void 0 } = $$props;
  let { buttonText = "" } = $$props;
  let { cta = false } = $$props;
  let { link = "" } = $$props;
  let { linkText = "" } = $$props;
  $$self.$$set = ($$props2) => {
    if ("type" in $$props2)
      $$invalidate(0, type = $$props2.type);
    if ("header" in $$props2)
      $$invalidate(1, header = $$props2.header);
    if ("message" in $$props2)
      $$invalidate(9, message = $$props2.message);
    if ("onConfirm" in $$props2)
      $$invalidate(2, onConfirm = $$props2.onConfirm);
    if ("buttonText" in $$props2)
      $$invalidate(3, buttonText = $$props2.buttonText);
    if ("cta" in $$props2)
      $$invalidate(4, cta = $$props2.cta);
    if ("link" in $$props2)
      $$invalidate(5, link = $$props2.link);
    if ("linkText" in $$props2)
      $$invalidate(6, linkText = $$props2.linkText);
    if ("$$scope" in $$props2)
      $$invalidate(11, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*type*/
    1) {
      $$invalidate(8, icon = selectIcon(type));
    }
    if ($$self.$$.dirty & /*message*/
    512) {
      $$invalidate(7, split = message.split("\n"));
    }
  };
  return [
    type,
    header,
    onConfirm,
    buttonText,
    cta,
    link,
    linkText,
    split,
    icon,
    message,
    slots,
    $$scope
  ];
}
class InlineAlert extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$r, create_fragment$r, safe_not_equal, {
      type: 0,
      header: 1,
      message: 9,
      onConfirm: 2,
      buttonText: 3,
      cta: 4,
      link: 5,
      linkText: 6
    });
  }
}
function create_if_block_1$b(ctx) {
  let div;
  let div_class_value;
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[9].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[8],
    null
  );
  return {
    c() {
      div = element("div");
      if (default_slot)
        default_slot.c();
      attr(div, "class", div_class_value = "spectrum-FieldLabel spectrum-ProgressBar-label spectrum-FieldLabel--size" + /*size*/
      ctx[6] + " svelte-1nu3ola");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (default_slot) {
        default_slot.m(div, null);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        256)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[8],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[8]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[8],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*size*/
      64 && div_class_value !== (div_class_value = "spectrum-FieldLabel spectrum-ProgressBar-label spectrum-FieldLabel--size" + /*size*/
      ctx2[6] + " svelte-1nu3ola")) {
        attr(div, "class", div_class_value);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_if_block$i(ctx) {
  let div;
  let t0_value = Math.round(Number(
    /*value*/
    ctx[0]
  )) + "";
  let t0;
  let t1;
  let div_class_value;
  return {
    c() {
      div = element("div");
      t0 = text(t0_value);
      t1 = text("%");
      attr(div, "class", div_class_value = "spectrum-FieldLabel spectrum-ProgressBar-percentage spectrum-FieldLabel--size" + /*size*/
      ctx[6] + " svelte-1nu3ola");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t0);
      append(div, t1);
    },
    p(ctx2, dirty) {
      if (dirty & /*value*/
      1 && t0_value !== (t0_value = Math.round(Number(
        /*value*/
        ctx2[0]
      )) + ""))
        set_data(t0, t0_value);
      if (dirty & /*size*/
      64 && div_class_value !== (div_class_value = "spectrum-FieldLabel spectrum-ProgressBar-percentage spectrum-FieldLabel--size" + /*size*/
      ctx2[6] + " svelte-1nu3ola")) {
        attr(div, "class", div_class_value);
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_fragment$q(ctx) {
  let div3;
  let t0;
  let t1;
  let div1;
  let div0;
  let t2;
  let div2;
  let div3_class_value;
  let div3_aria_valuenow_value;
  let div3_style_value;
  let current;
  let if_block0 = (
    /*$$slots*/
    ctx[7] && create_if_block_1$b(ctx)
  );
  let if_block1 = !/*hidePercentage*/
  ctx[4] && /*value*/
  (ctx[0] || /*value*/
  ctx[0] === 0) && create_if_block$i(ctx);
  return {
    c() {
      div3 = element("div");
      if (if_block0)
        if_block0.c();
      t0 = space();
      if (if_block1)
        if_block1.c();
      t1 = space();
      div1 = element("div");
      div0 = element("div");
      t2 = space();
      div2 = element("div");
      attr(div0, "class", "spectrum-ProgressBar-fill svelte-1nu3ola");
      set_style(div0, "width", (typeof /*value*/
      ctx[0] === "number" ? (
        /*value*/
        ctx[0]
      ) : 0) + "%");
      set_style(
        div0,
        "--duration",
        /*duration*/
        ctx[1] + "ms"
      );
      toggle_class(
        div0,
        "color-green",
        /*color*/
        ctx[5] === "green"
      );
      toggle_class(
        div0,
        "color-red",
        /*color*/
        ctx[5] === "red"
      );
      attr(div1, "class", "spectrum-ProgressBar-track");
      attr(div2, "class", "spectrum-ProgressBar-label");
      div2.hidden = false;
      attr(div3, "class", div3_class_value = "spectrum-ProgressBar spectrum-ProgressBar--size" + /*size*/
      ctx[6] + " svelte-1nu3ola");
      attr(div3, "role", "progressbar");
      attr(div3, "aria-valuenow", div3_aria_valuenow_value = typeof /*value*/
      ctx[0] === "number" ? (
        /*value*/
        ctx[0]
      ) : void 0);
      attr(div3, "aria-valuemin", "0");
      attr(div3, "aria-valuemax", "100");
      attr(div3, "style", div3_style_value = /*width*/
      ctx[2] ? `width: ${typeof /*width*/
      ctx[2] === "string" ? (
        /*width*/
        ctx[2]
      ) : ""};` : "");
      toggle_class(div3, "spectrum-ProgressBar--indeterminate", !/*value*/
      ctx[0] && /*value*/
      ctx[0] !== 0);
      toggle_class(
        div3,
        "spectrum-ProgressBar--sideLabel",
        /*sideLabel*/
        ctx[3]
      );
    },
    m(target, anchor) {
      insert(target, div3, anchor);
      if (if_block0)
        if_block0.m(div3, null);
      append(div3, t0);
      if (if_block1)
        if_block1.m(div3, null);
      append(div3, t1);
      append(div3, div1);
      append(div1, div0);
      append(div3, t2);
      append(div3, div2);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (
        /*$$slots*/
        ctx2[7]
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty & /*$$slots*/
          128) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_1$b(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(div3, t0);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (!/*hidePercentage*/
      ctx2[4] && /*value*/
      (ctx2[0] || /*value*/
      ctx2[0] === 0)) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
        } else {
          if_block1 = create_if_block$i(ctx2);
          if_block1.c();
          if_block1.m(div3, t1);
        }
      } else if (if_block1) {
        if_block1.d(1);
        if_block1 = null;
      }
      if (!current || dirty & /*value*/
      1) {
        set_style(div0, "width", (typeof /*value*/
        ctx2[0] === "number" ? (
          /*value*/
          ctx2[0]
        ) : 0) + "%");
      }
      if (!current || dirty & /*duration*/
      2) {
        set_style(
          div0,
          "--duration",
          /*duration*/
          ctx2[1] + "ms"
        );
      }
      if (!current || dirty & /*color*/
      32) {
        toggle_class(
          div0,
          "color-green",
          /*color*/
          ctx2[5] === "green"
        );
      }
      if (!current || dirty & /*color*/
      32) {
        toggle_class(
          div0,
          "color-red",
          /*color*/
          ctx2[5] === "red"
        );
      }
      if (!current || dirty & /*size*/
      64 && div3_class_value !== (div3_class_value = "spectrum-ProgressBar spectrum-ProgressBar--size" + /*size*/
      ctx2[6] + " svelte-1nu3ola")) {
        attr(div3, "class", div3_class_value);
      }
      if (!current || dirty & /*value*/
      1 && div3_aria_valuenow_value !== (div3_aria_valuenow_value = typeof /*value*/
      ctx2[0] === "number" ? (
        /*value*/
        ctx2[0]
      ) : void 0)) {
        attr(div3, "aria-valuenow", div3_aria_valuenow_value);
      }
      if (!current || dirty & /*width*/
      4 && div3_style_value !== (div3_style_value = /*width*/
      ctx2[2] ? `width: ${typeof /*width*/
      ctx2[2] === "string" ? (
        /*width*/
        ctx2[2]
      ) : ""};` : "")) {
        attr(div3, "style", div3_style_value);
      }
      if (!current || dirty & /*size, value*/
      65) {
        toggle_class(div3, "spectrum-ProgressBar--indeterminate", !/*value*/
        ctx2[0] && /*value*/
        ctx2[0] !== 0);
      }
      if (!current || dirty & /*size, sideLabel*/
      72) {
        toggle_class(
          div3,
          "spectrum-ProgressBar--sideLabel",
          /*sideLabel*/
          ctx2[3]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div3);
      }
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
    }
  };
}
function instance$q($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  const $$slots = compute_slots(slots);
  let { value = false } = $$props;
  let { duration: duration2 = 1e3 } = $$props;
  let { width = false } = $$props;
  let { sideLabel = false } = $$props;
  let { hidePercentage = true } = $$props;
  let { color = void 0 } = $$props;
  let { size = "M" } = $$props;
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("duration" in $$props2)
      $$invalidate(1, duration2 = $$props2.duration);
    if ("width" in $$props2)
      $$invalidate(2, width = $$props2.width);
    if ("sideLabel" in $$props2)
      $$invalidate(3, sideLabel = $$props2.sideLabel);
    if ("hidePercentage" in $$props2)
      $$invalidate(4, hidePercentage = $$props2.hidePercentage);
    if ("color" in $$props2)
      $$invalidate(5, color = $$props2.color);
    if ("size" in $$props2)
      $$invalidate(6, size = $$props2.size);
    if ("$$scope" in $$props2)
      $$invalidate(8, $$scope = $$props2.$$scope);
  };
  return [
    value,
    duration2,
    width,
    sideLabel,
    hidePercentage,
    color,
    size,
    $$slots,
    $$scope,
    slots
  ];
}
class ProgressBar extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$q, create_fragment$q, safe_not_equal, {
      value: 0,
      duration: 1,
      width: 2,
      sideLabel: 3,
      hidePercentage: 4,
      color: 5,
      size: 6
    });
  }
}
function create_default_slot$f(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[6].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[7],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        128)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[7],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[7]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[7],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_fragment$p(ctx) {
  let abstooltip;
  let current;
  abstooltip = new AbsTooltip({
    props: {
      position: (
        /*position*/
        ctx[1]
      ),
      type: (
        /*type*/
        ctx[2]
      ),
      text: (
        /*visible*/
        ctx[3] ? (
          /*text*/
          ctx[0]
        ) : null
      ),
      fixed: (
        /*visible*/
        ctx[3]
      ),
      $$slots: { default: [create_default_slot$f] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(abstooltip.$$.fragment);
    },
    m(target, anchor) {
      mount_component(abstooltip, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const abstooltip_changes = {};
      if (dirty & /*position*/
      2)
        abstooltip_changes.position = /*position*/
        ctx2[1];
      if (dirty & /*type*/
      4)
        abstooltip_changes.type = /*type*/
        ctx2[2];
      if (dirty & /*visible, text*/
      9)
        abstooltip_changes.text = /*visible*/
        ctx2[3] ? (
          /*text*/
          ctx2[0]
        ) : null;
      if (dirty & /*visible*/
      8)
        abstooltip_changes.fixed = /*visible*/
        ctx2[3];
      if (dirty & /*$$scope*/
      128) {
        abstooltip_changes.$$scope = { dirty, ctx: ctx2 };
      }
      abstooltip.$set(abstooltip_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(abstooltip.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(abstooltip.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(abstooltip, detaching);
    }
  };
}
function instance$p($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { text: text2 = null } = $$props;
  let { condition = true } = $$props;
  let { duration: duration2 = 5e3 } = $$props;
  let { position } = $$props;
  let { type } = $$props;
  let visible = false;
  let timeout;
  const showTooltip = () => {
    $$invalidate(3, visible = true);
    timeout = setTimeout(
      () => {
        $$invalidate(3, visible = false);
      },
      duration2
    );
  };
  const hideTooltip = () => {
    $$invalidate(3, visible = false);
    clearTimeout(timeout);
  };
  onDestroy(hideTooltip);
  $$self.$$set = ($$props2) => {
    if ("text" in $$props2)
      $$invalidate(0, text2 = $$props2.text);
    if ("condition" in $$props2)
      $$invalidate(4, condition = $$props2.condition);
    if ("duration" in $$props2)
      $$invalidate(5, duration2 = $$props2.duration);
    if ("position" in $$props2)
      $$invalidate(1, position = $$props2.position);
    if ("type" in $$props2)
      $$invalidate(2, type = $$props2.type);
    if ("$$scope" in $$props2)
      $$invalidate(7, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*condition*/
    16) {
      {
        if (condition) {
          showTooltip();
        } else {
          hideTooltip();
        }
      }
    }
  };
  return [text2, position, type, visible, condition, duration2, slots, $$scope];
}
class TempTooltip extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$p, create_fragment$p, safe_not_equal, {
      text: 0,
      condition: 4,
      duration: 5,
      position: 1,
      type: 2
    });
  }
}
const getColumnIcon = (column) => {
  if (column.schema.icon && !column.schema.icon.startsWith("ri-")) {
    return column.schema.icon;
  }
  if (column.calculationType) {
    return "calculator";
  }
  if (column.schema.autocolumn) {
    return "shapes";
  }
  if (isDeprecatedSingleUserColumn(column.schema)) {
    return "user";
  }
  const { type, subtype } = column.schema;
  const result = typeof TypeIconMap[type] === "object" && subtype ? TypeIconMap[type][subtype] : TypeIconMap[type];
  return result || "article";
};
const createEventManagers = () => {
  const svelteDispatch = createEventDispatcher();
  let subscribers = {};
  const dispatch = (event, payload) => {
    svelteDispatch(event, payload);
    const subs = subscribers[event] || [];
    for (let i = 0; i < subs.length; i++) {
      subs[i](payload);
    }
  };
  const subscribe2 = (event, callback) => {
    const subs = subscribers[event] || [];
    subscribers[event] = [...subs, callback];
    return () => {
      subscribers[event] = subscribers[event].filter((cb) => cb !== callback);
    };
  };
  return { dispatch, subscribe: subscribe2 };
};
const createStores$f = () => {
  const bounds = writable({
    left: 0,
    top: 0,
    width: 0,
    height: 0
  });
  const width = derived(bounds, ($bounds) => $bounds.width, 0);
  const height = derived(bounds, ($bounds) => $bounds.height, 0);
  return { bounds, height, width };
};
const Bounds = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createStores: createStores$f
}, Symbol.toStringTag, { value: "Module" }));
const createStores$e = () => {
  const columns = writable([]);
  const enrichedColumns = derived(columns, ($columns) => {
    let offset = GutterWidth;
    let idx = 0;
    return $columns.map((col) => {
      const enriched = {
        ...col,
        __idx: idx,
        __left: offset
      };
      if (col.visible) {
        idx++;
        offset += col.width ?? 0;
      }
      return enriched;
    });
  });
  return {
    columns: {
      ...columns,
      subscribe: enrichedColumns.subscribe
    }
  };
};
const deriveStores$a = (context) => {
  const { columns } = context;
  const columnLookupMap = derived(columns, ($columns) => {
    let map = {};
    $columns.forEach((column) => {
      map[column.name] = column;
    });
    return map;
  });
  const tableColumns = derived(columns, ($columns) => {
    return $columns.filter((col) => !col.related);
  });
  const visibleColumns = derived(columns, ($columns) => {
    return $columns.filter((col) => col.visible);
  });
  const displayColumn = derived(visibleColumns, ($visibleColumns) => {
    return $visibleColumns.find((col) => col.primaryDisplay);
  });
  const scrollableColumns = derived(visibleColumns, ($visibleColumns) => {
    return $visibleColumns.filter((col) => !col.primaryDisplay);
  });
  const hasNonAutoColumn = derived(columns, ($columns) => {
    const normalCols = $columns.filter((column) => {
      var _a;
      return !((_a = column.schema) == null ? void 0 : _a.autocolumn);
    });
    return normalCols.length > 0;
  });
  return {
    tableColumns,
    displayColumn,
    columnLookupMap,
    visibleColumns,
    scrollableColumns,
    hasNonAutoColumn
  };
};
const createActions$e = (context) => {
  const { columns, datasource } = context;
  const changeAllColumnWidths = async (width) => {
    const $columns = get_store_value(columns);
    $columns.forEach((column) => {
      const { related } = column;
      const mutation = { width };
      if (!related) {
        datasource.actions.addSchemaMutation(column.name, mutation);
      } else {
        datasource.actions.addSubSchemaMutation(
          related.subField,
          related.field,
          mutation
        );
      }
    });
    await datasource.actions.saveSchemaMutations();
  };
  const isReadonly = (column) => {
    if (!(column == null ? void 0 : column.schema)) {
      return false;
    }
    return column.schema.autocolumn || column.schema.disabled || column.schema.type === "formula" || column.schema.type === "ai" || column.schema.readonly;
  };
  return {
    columns: {
      ...columns,
      actions: {
        changeAllColumnWidths,
        isReadonly
      }
    }
  };
};
const initialise$b = (context) => {
  const { definition, columns, displayColumn, enrichedSchema } = context;
  const processColumns = ($enrichedSchema) => {
    const $definition = get_store_value(definition);
    if (!$enrichedSchema || !$definition) {
      columns.set([]);
      return;
    }
    const $displayColumn = get_store_value(displayColumn);
    let primaryDisplay;
    const candidatePD = $definition.primaryDisplay || ($displayColumn == null ? void 0 : $displayColumn.name);
    if (candidatePD && $enrichedSchema[candidatePD]) {
      primaryDisplay = candidatePD;
    }
    columns.set(
      Object.keys($enrichedSchema).map((field) => {
        const fieldSchema = $enrichedSchema[field];
        const column = {
          type: fieldSchema.type,
          name: field,
          label: fieldSchema.displayName || field,
          schema: fieldSchema,
          width: fieldSchema.width || DefaultColumnWidth,
          visible: fieldSchema.visible ?? true,
          readonly: fieldSchema.readonly,
          order: fieldSchema.order,
          conditions: fieldSchema.conditions,
          related: fieldSchema.related,
          calculationType: fieldSchema.calculationType,
          format: fieldSchema.format,
          __left: void 0,
          // TODO
          __idx: void 0
          // TODO
        };
        if (field === primaryDisplay) {
          column.order = 0;
          column.primaryDisplay = true;
        }
        return column;
      }).sort((a, b) => {
        var _a, _b;
        if (a.name === primaryDisplay) {
          return -1;
        } else if (b.name === primaryDisplay) {
          return 1;
        }
        const orderA = a.order;
        const orderB = b.order;
        if (orderA != null && orderB != null) {
          return orderA < orderB ? -1 : 1;
        } else if (orderA != null) {
          return -1;
        } else if (orderB != null) {
          return 1;
        }
        const autoColA = (_a = a.schema) == null ? void 0 : _a.autocolumn;
        const autoColB = (_b = b.schema) == null ? void 0 : _b.autocolumn;
        if (autoColA === autoColB) {
          return 0;
        }
        return autoColA ? 1 : -1;
      })
    );
  };
  enrichedSchema.subscribe(processColumns);
};
const Columns = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$e,
  createStores: createStores$e,
  deriveStores: deriveStores$a,
  initialise: initialise$b
}, Symbol.toStringTag, { value: "Module" }));
const parseCellID = (cellId) => {
  if (!cellId) {
    return { rowId: void 0, field: void 0 };
  }
  const parts = cellId.split(CellIDSeparator);
  const field = parts.pop();
  return { rowId: parts.join(CellIDSeparator), field };
};
const getCellID = (rowId, fieldName) => {
  return `${rowId}${CellIDSeparator}${fieldName}`;
};
const parseEventLocation = (event) => {
  var _a, _b, _c, _d;
  const e = event;
  return {
    x: e.clientX ?? ((_b = (_a = e.touches) == null ? void 0 : _a[0]) == null ? void 0 : _b.clientX),
    y: e.clientY ?? ((_d = (_c = e.touches) == null ? void 0 : _c[0]) == null ? void 0 : _d.clientY)
  };
};
const generateRowID = () => {
  return `${GeneratedIDPrefix}${uuid()}`;
};
const isGeneratedRowID = (id) => {
  return id == null ? void 0 : id.startsWith(GeneratedIDPrefix);
};
const createStores$d = () => {
  const menu = writable({
    left: 0,
    top: 0,
    visible: false,
    multiRowMode: false,
    multiCellMode: false
  });
  return {
    menu
  };
};
const createActions$d = (context) => {
  const {
    menu,
    focusedCellId,
    gridID,
    selectedRows,
    selectedRowCount,
    selectedCellMap,
    selectedCellCount
  } = context;
  const open = (cellId, e) => {
    var _a;
    e.preventDefault();
    e.stopPropagation();
    const gridNode = document.getElementById(gridID);
    const dataNode = (_a = gridNode == null ? void 0 : gridNode.getElementsByClassName("grid-data-outer")) == null ? void 0 : _a[0];
    if (!dataNode) {
      return;
    }
    const targetBounds = e.target.getBoundingClientRect();
    const dataBounds = dataNode.getBoundingClientRect();
    let multiRowMode = false;
    if (get_store_value(selectedRowCount) > 1) {
      const { rowId } = parseCellID(cellId);
      if (rowId !== void 0 && get_store_value(selectedRows)[rowId]) {
        multiRowMode = true;
      }
    }
    let multiCellMode = false;
    if (!multiRowMode && get_store_value(selectedCellCount) > 1) {
      if (get_store_value(selectedCellMap)[cellId]) {
        multiCellMode = true;
      }
    }
    if (!multiRowMode && !multiCellMode) {
      focusedCellId.set(cellId);
    }
    menu.set({
      left: targetBounds.left - dataBounds.left + e.offsetX,
      top: targetBounds.top - dataBounds.top + e.offsetY,
      visible: true,
      multiRowMode,
      multiCellMode
    });
  };
  const close = () => {
    menu.update((state) => ({
      ...state,
      visible: false
    }));
  };
  return {
    menu: {
      ...menu,
      actions: {
        open,
        close
      }
    }
  };
};
const Menu = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$d,
  createStores: createStores$d
}, Symbol.toStringTag, { value: "Module" }));
const initialise$a = (context) => {
  const { scrolledRowCount, rows, visualRowCapacity } = context;
  const rowCount = derived(rows, ($rows) => $rows.length, 0);
  const remainingRows = derived(
    [scrolledRowCount, rowCount, visualRowCapacity],
    ([$scrolledRowCount, $rowCount, $visualRowCapacity]) => {
      return Math.max(0, $rowCount - $scrolledRowCount - $visualRowCapacity);
    }
  );
  const needsNewPage = derived(
    [remainingRows, rowCount],
    ([$remainingRows, $rowCount]) => {
      return $remainingRows < 25 && $rowCount;
    }
  );
  needsNewPage.subscribe(($needsNewPage) => {
    if ($needsNewPage) {
      rows.actions.loadNextPage();
    }
  });
};
const Pagination = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  initialise: initialise$a
}, Symbol.toStringTag, { value: "Module" }));
const reorderInitialState = {
  sourceColumn: null,
  targetColumn: null,
  insertAfter: false,
  breakpoints: [],
  gridLeft: 0,
  width: 0,
  increment: 0
};
const createStores$c = () => {
  const reorder = writable(reorderInitialState);
  const isReordering = derived(
    reorder,
    ($reorder) => !!$reorder.sourceColumn,
    false
  );
  return {
    reorder,
    isReordering
  };
};
const createActions$c = (context) => {
  const {
    reorder,
    columns,
    columnLookupMap,
    scrollableColumns,
    scroll,
    bounds,
    visibleColumns,
    datasource,
    stickyWidth,
    width,
    scrollLeft,
    maxScrollLeft
  } = context;
  let latestX = 0;
  let autoScrollInterval;
  let isAutoScrolling;
  const startReordering = (column, e) => {
    const $scrollableColumns = get_store_value(scrollableColumns);
    const $bounds = get_store_value(bounds);
    const $stickyWidth = get_store_value(stickyWidth);
    const breakpoints = $scrollableColumns.map((col) => ({
      x: col.__left - $stickyWidth,
      column: col.name,
      insertAfter: false
    }));
    const lastCol = $scrollableColumns[$scrollableColumns.length - 1];
    if (lastCol) {
      breakpoints.push({
        x: lastCol.__left + lastCol.width - $stickyWidth,
        column: lastCol.name,
        insertAfter: true
      });
    }
    reorder.set({
      sourceColumn: column,
      targetColumn: null,
      breakpoints,
      gridLeft: $bounds.left,
      width: $bounds.width
    });
    document.addEventListener("mousemove", onReorderMouseMove);
    document.addEventListener("mouseup", stopReordering);
    document.addEventListener("touchmove", onReorderMouseMove);
    document.addEventListener("touchend", stopReordering);
    document.addEventListener("touchcancel", stopReordering);
    onReorderMouseMove(e);
  };
  const onReorderMouseMove = (e) => {
    const { x } = parseEventLocation(e);
    latestX = x;
    considerReorderPosition();
    const $scrollLeft = get_store_value(scrollLeft);
    const $maxScrollLeft = get_store_value(maxScrollLeft);
    const $reorder = get_store_value(reorder);
    const proximityCutoff = Math.min(140, get_store_value(width) / 6);
    const speedFactor = 16;
    const rightProximity = Math.max(0, $reorder.gridLeft + $reorder.width - x);
    const leftProximity = Math.max(0, x - $reorder.gridLeft);
    if (rightProximity < proximityCutoff && $scrollLeft < $maxScrollLeft) {
      const weight = proximityCutoff - rightProximity;
      const increment = weight / proximityCutoff * speedFactor;
      reorder.update((state) => ({ ...state, increment }));
      startAutoScroll();
    } else if (leftProximity < proximityCutoff && $scrollLeft > 0) {
      const weight = -1 * (proximityCutoff - leftProximity);
      const increment = weight / proximityCutoff * speedFactor;
      reorder.update((state) => ({ ...state, increment }));
      startAutoScroll();
    } else {
      stopAutoScroll();
    }
  };
  const considerReorderPosition = () => {
    const $reorder = get_store_value(reorder);
    const $scrollLeft = get_store_value(scrollLeft);
    let breakpoint;
    let minDistance = Number.MAX_SAFE_INTEGER;
    const mouseX = latestX - $reorder.gridLeft + $scrollLeft;
    $reorder.breakpoints.forEach((point) => {
      const distance = Math.abs(point.x - mouseX);
      if (distance < minDistance) {
        minDistance = distance;
        breakpoint = point;
      }
    });
    if (breakpoint && (breakpoint.column !== $reorder.targetColumn || breakpoint.insertAfter !== $reorder.insertAfter)) {
      reorder.update((state) => ({
        ...state,
        targetColumn: breakpoint.column,
        insertAfter: breakpoint.insertAfter
      }));
    }
  };
  const startAutoScroll = () => {
    if (isAutoScrolling) {
      return;
    }
    isAutoScrolling = true;
    autoScrollInterval = setInterval(() => {
      const $maxLeft = get_store_value(maxScrollLeft);
      const { increment } = get_store_value(reorder);
      scroll.update((state) => ({
        ...state,
        left: Math.max(0, Math.min($maxLeft, state.left + increment))
      }));
      considerReorderPosition();
    }, 10);
  };
  const stopAutoScroll = () => {
    isAutoScrolling = false;
    clearInterval(autoScrollInterval);
  };
  const stopReordering = async () => {
    stopAutoScroll();
    document.removeEventListener("mousemove", onReorderMouseMove);
    document.removeEventListener("mouseup", stopReordering);
    document.removeEventListener("touchmove", onReorderMouseMove);
    document.removeEventListener("touchend", stopReordering);
    document.removeEventListener("touchcancel", stopReordering);
    const { sourceColumn, targetColumn, insertAfter } = get_store_value(reorder);
    reorder.set(reorderInitialState);
    if (sourceColumn !== targetColumn) {
      await moveColumn({
        sourceColumn,
        targetColumn,
        insertAfter
      });
    }
  };
  const moveColumn = async ({
    sourceColumn,
    targetColumn,
    insertAfter = false
  }) => {
    const $columns = get_store_value(columns);
    let sourceIdx = $columns.findIndex((col) => col.name === sourceColumn);
    let targetIdx = $columns.findIndex((col) => col.name === targetColumn);
    if (insertAfter) {
      targetIdx++;
    }
    columns.update((state) => {
      const removed = state.splice(sourceIdx, 1);
      if (--targetIdx < sourceIdx) {
        targetIdx++;
      }
      return state.toSpliced(targetIdx, 0, removed[0]);
    });
    get_store_value(columns).forEach((column, idx) => {
      const { related } = column;
      const mutation = { order: idx };
      if (!related) {
        datasource.actions.addSchemaMutation(column.name, mutation);
      } else {
        datasource.actions.addSubSchemaMutation(
          related.subField,
          related.field,
          mutation
        );
      }
    });
    await datasource.actions.saveSchemaMutations();
  };
  const moveColumnLeft = async (column) => {
    var _a;
    const $visibleColumns = get_store_value(visibleColumns);
    const $columnLookupMap = get_store_value(columnLookupMap);
    const sourceIdx = $columnLookupMap[column].__idx;
    await moveColumn({
      sourceColumn: column,
      targetColumn: (_a = $visibleColumns[sourceIdx - 1]) == null ? void 0 : _a.name
    });
  };
  const moveColumnRight = async (column) => {
    var _a;
    const $visibleColumns = get_store_value(visibleColumns);
    const $columnLookupMap = get_store_value(columnLookupMap);
    const sourceIdx = $columnLookupMap[column].__idx;
    if (sourceIdx === $visibleColumns.length - 1) {
      return;
    }
    await moveColumn({
      sourceColumn: column,
      targetColumn: (_a = $visibleColumns[sourceIdx + 1]) == null ? void 0 : _a.name,
      insertAfter: true
    });
  };
  return {
    reorder: {
      ...reorder,
      actions: {
        startReordering,
        stopReordering,
        moveColumnLeft,
        moveColumnRight
      }
    }
  };
};
const Reorder = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$c,
  createStores: createStores$c
}, Symbol.toStringTag, { value: "Module" }));
const initialState = {
  initialMouseX: null,
  initialWidth: null,
  column: null,
  width: 0,
  left: 0
};
const createStores$b = () => {
  const resize = writable(initialState);
  const isResizing = derived(resize, ($resize) => $resize.column != null, false);
  return {
    resize,
    isResizing
  };
};
const createActions$b = (context) => {
  const { resize, ui, datasource } = context;
  const startResizing = (column, e) => {
    const { x } = parseEventLocation(e);
    e.stopPropagation();
    e.preventDefault();
    ui.actions.blur();
    resize.set({
      width: column.width,
      left: column.__left,
      initialWidth: column.width,
      initialMouseX: x,
      column: column.name,
      related: column.related
    });
    document.addEventListener("mousemove", onResizeMouseMove);
    document.addEventListener("mouseup", stopResizing);
    document.addEventListener("touchmove", onResizeMouseMove);
    document.addEventListener("touchend", stopResizing);
    document.addEventListener("touchcancel", stopResizing);
  };
  const onResizeMouseMove = (e) => {
    const { initialMouseX, initialWidth, width, column, related } = get_store_value(resize);
    const { x } = parseEventLocation(e);
    const dx = x - initialMouseX;
    const newWidth = Math.round(Math.max(MinColumnWidth, initialWidth + dx));
    if (Math.abs(width - newWidth) < 5) {
      return;
    }
    if (!related) {
      datasource.actions.addSchemaMutation(column, { width });
    } else {
      datasource.actions.addSubSchemaMutation(related.subField, related.field, {
        width
      });
    }
    resize.update((state) => ({
      ...state,
      width: newWidth
    }));
  };
  const stopResizing = async () => {
    const $resize = get_store_value(resize);
    resize.set(initialState);
    document.removeEventListener("mousemove", onResizeMouseMove);
    document.removeEventListener("mouseup", stopResizing);
    document.removeEventListener("touchmove", onResizeMouseMove);
    document.removeEventListener("touchend", stopResizing);
    document.removeEventListener("touchcancel", stopResizing);
    if ($resize.width !== $resize.initialWidth) {
      await datasource.actions.saveSchemaMutations();
    }
  };
  const resetSize = async (column) => {
    datasource.actions.addSchemaMutation(column.name, {
      width: DefaultColumnWidth
    });
    await datasource.actions.saveSchemaMutations();
  };
  return {
    resize: {
      ...resize,
      actions: {
        startResizing,
        resetSize
      }
    }
  };
};
const Resize = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$b,
  createStores: createStores$b
}, Symbol.toStringTag, { value: "Module" }));
const createStores$a = () => {
  const rows = writable([]);
  const loading = writable(false);
  const loaded = writable(false);
  const refreshing = writable(false);
  const rowChangeCache = writable({});
  const inProgressChanges = writable({});
  const hasNextPage = writable(false);
  const error = writable(null);
  const definitionMissing = writable(false);
  const fetch = writable(null);
  let hasStartedLoading = false;
  loading.subscribe(($loading) => {
    if ($loading) {
      hasStartedLoading = true;
    } else if (hasStartedLoading) {
      loaded.set(true);
    }
  });
  return {
    rows,
    fetch,
    loaded,
    refreshing,
    loading,
    rowChangeCache,
    inProgressChanges,
    hasNextPage,
    error,
    definitionMissing
  };
};
const deriveStores$9 = (context) => {
  const { rows, enrichedSchema } = context;
  const enrichedRows = derived(
    [rows, enrichedSchema],
    ([$rows, $enrichedSchema]) => {
      const cols = Object.values($enrichedSchema || {});
      const relatedColumns = cols.filter((col) => col.related);
      const formattedColumns = cols.filter((col) => col.format);
      return $rows.map((row, idx) => {
        const relatedValues = relatedColumns.reduce(
          (map, column) => {
            const fromField = $enrichedSchema[column.related.field];
            map[column.name] = getRelatedTableValues(
              row,
              { ...column, related: column.related },
              fromField
            );
            return map;
          },
          {}
        );
        const formattedValues = formattedColumns.reduce(
          (map, column) => {
            map[column.name] = column.format(row);
            return map;
          },
          {}
        );
        return {
          ...row,
          ...relatedValues,
          __formatted: formattedValues,
          __idx: idx
        };
      });
    }
  );
  const rowLookupMap = derived(enrichedRows, ($enrichedRows) => {
    let map = {};
    for (let i = 0; i < $enrichedRows.length; i++) {
      map[$enrichedRows[i]._id] = $enrichedRows[i];
    }
    return map;
  });
  return {
    rows: {
      ...rows,
      subscribe: enrichedRows.subscribe
    },
    rowLookupMap
  };
};
const createActions$a = (context) => {
  const {
    rows,
    rowLookupMap,
    definition,
    allFilters,
    loading,
    sort,
    datasource,
    API,
    scroll,
    validation,
    focusedCellId,
    columns,
    rowChangeCache,
    inProgressChanges,
    hasNextPage,
    error,
    definitionMissing,
    notifications: notifications2,
    fetch,
    hasBudibaseIdentifiers,
    refreshing,
    columnLookupMap
  } = context;
  const instanceLoaded = writable(false);
  let rowCacheMap = {};
  let unsubscribe = null;
  let lastResetKey = null;
  datasource.subscribe(async ($datasource) => {
    unsubscribe == null ? void 0 : unsubscribe();
    unsubscribe = null;
    fetch.set(null);
    instanceLoaded.set(false);
    loading.set(true);
    if (!datasource.actions.isDatasourceValid($datasource)) {
      error.set("Datasource is invalid");
      return;
    }
    await tick();
    const $allFilters = get_store_value(allFilters);
    const $sort = get_store_value(sort);
    const newFetch = fetchData({
      API,
      datasource: $datasource,
      options: {
        filter: $allFilters,
        sortColumn: $sort.column,
        sortOrder: $sort.order,
        limit: RowPageSize,
        paginate: true,
        // Disable client side limiting, so that for queries and custom data
        // sources we don't impose fake row limits. We want all the data.
        clientSideLimiting: false
      }
    });
    unsubscribe = newFetch.subscribe(async ($fetch) => {
      if ($fetch.error) {
        let message = "An unknown error occurred";
        if ($fetch.error.status === 403) {
          message = "You don't have access to this data";
        } else if ($fetch.error.status === 404 && $fetch.error.url && $fetch.error.url.includes("/api/tables/") || $fetch.error.url.includes("/api/v2/views/")) {
          definitionMissing.set(true);
          message = $fetch.error.message;
        } else if ($fetch.error.message) {
          message = $fetch.error.message;
        }
        error.set(message);
      } else if ($fetch.loaded && !$fetch.loading) {
        error.set(null);
        hasNextPage.set($fetch.hasNextPage);
        const $instanceLoaded = get_store_value(instanceLoaded);
        const resetRows = $fetch.resetKey !== lastResetKey;
        const previousResetKey = lastResetKey;
        lastResetKey = $fetch.resetKey;
        if (!$instanceLoaded && previousResetKey) {
          rows.set([]);
          await tick();
        }
        if (!$instanceLoaded || resetRows) {
          definition.set($fetch.definition ?? null);
        }
        if (!$instanceLoaded) {
          instanceLoaded.set(true);
          scroll.set({ top: 0, left: 0 });
        } else if (resetRows) {
          scroll.update((state) => ({ ...state, top: 0 }));
        }
        handleNewRows($fetch.rows, resetRows);
        loading.set(false);
      }
      refreshing.set($fetch.loading);
    });
    fetch.set(newFetch);
  });
  const handleValidationError = (rowId, error2) => {
    var _a, _b;
    let errorString;
    if (typeof error2 === "string") {
      errorString = error2;
    } else if (typeof (error2 == null ? void 0 : error2.message) === "string") {
      errorString = error2.message;
    }
    if (typeof error2 !== "string" && !((_a = error2 == null ? void 0 : error2.json) == null ? void 0 : _a.validationErrors) && errorString) {
      const { field: focusedColumn } = parseCellID(get_store_value(focusedCellId));
      if (focusedColumn) {
        error2 = {
          json: {
            validationErrors: {
              [focusedColumn]: error2.message
            }
          }
        };
      }
    }
    if (typeof error2 !== "string" && ((_b = error2 == null ? void 0 : error2.json) == null ? void 0 : _b.validationErrors)) {
      const keys = Object.keys(error2.json.validationErrors);
      const $columns = get_store_value(columns);
      let erroredColumns = [];
      let missingColumns = [];
      for (let column of keys) {
        if (datasource.actions.canUseColumn(column)) {
          erroredColumns.push(column);
        } else {
          missingColumns.push(column);
        }
      }
      const { json } = error2;
      for (let column of erroredColumns) {
        let err = json.validationErrors[column];
        if (Array.isArray(err)) {
          err = err[0];
        }
        if (typeof err !== "string" || !err.length) {
          error2 = "Something went wrong";
        }
        validation.actions.setError(
          getCellID(rowId, column),
          capitalise(err)
        );
        const index = $columns.findIndex((x) => x.name === column);
        if (index !== -1 && !$columns[index].visible) {
          columns.update((state) => {
            state[index].visible = true;
            return state.slice();
          });
        }
      }
      for (let column of missingColumns) {
        get_store_value(notifications2).error(`${column} is required but is missing`);
      }
    } else {
      get_store_value(notifications2).error(errorString || "An unknown error occurred");
    }
  };
  const addRow = async ({
    row,
    idx,
    bubble: bubble2 = false,
    notify = true
  }) => {
    try {
      const newRow = await datasource.actions.addRow(row);
      if (idx != null) {
        rowCacheMap[newRow._id] = true;
        rows.update((state) => {
          state.splice(idx, 0, newRow);
          return state.slice();
        });
      } else {
        handleNewRows([newRow]);
      }
      if (notify) {
        get_store_value(notifications2).success("Row created successfully");
      }
      return newRow;
    } catch (error2) {
      if (bubble2) {
        throw error2;
      } else {
        handleValidationError(NewRowID, error2);
        validation.actions.focusFirstRowError(NewRowID);
      }
    }
  };
  const duplicateRow = async (row) => {
    let clone = cleanRow(row);
    delete clone._id;
    delete clone._rev;
    try {
      const duped = await addRow({
        row: clone,
        idx: row.__idx + 1,
        bubble: true,
        notify: false
      });
      get_store_value(notifications2).success("Duplicated 1 row");
      return duped;
    } catch (error2) {
      handleValidationError(row._id, error2);
      validation.actions.focusFirstRowError(row._id);
    }
  };
  const bulkDuplicate = async (rowsToDupe, progressCallback) => {
    const $rowLookupMap = get_store_value(rowLookupMap);
    const indices = rowsToDupe.map((row) => {
      var _a;
      return (_a = $rowLookupMap[row._id]) == null ? void 0 : _a.__idx;
    });
    const index = Math.max(...indices);
    const count = rowsToDupe.length;
    const clones = rowsToDupe.map((row) => {
      let clone = cleanRow(row);
      delete clone._id;
      delete clone._rev;
      return clone;
    });
    let saved = [];
    let failed = 0;
    for (let i = 0; i < count; i++) {
      try {
        const newRow = await datasource.actions.addRow(clones[i]);
        saved.push(newRow);
        rowCacheMap[newRow._id] = true;
        await sleep(50);
      } catch (error2) {
        failed++;
        console.error("Duplicating row failed", error2);
      }
      progressCallback == null ? void 0 : progressCallback((i + 1) / count);
    }
    if (saved.length) {
      rows.update((state) => {
        return state.toSpliced(index + 1, 0, ...saved);
      });
    }
    if (failed) {
      get_store_value(notifications2).error(`Failed to duplicate ${failed} of ${count} rows`);
    } else if (saved.length) {
      get_store_value(notifications2).success(`Duplicated ${saved.length} rows`);
    }
    return saved;
  };
  const replaceRow = (id, row) => {
    var _a;
    const $rows = get_store_value(rows);
    const $rowLookupMap = get_store_value(rowLookupMap);
    const index = (_a = $rowLookupMap[id]) == null ? void 0 : _a.__idx;
    if (row) {
      if (index != null) {
        rows.update((state) => {
          state[index] = { ...row };
          return state;
        });
      } else {
        handleNewRows([row]);
      }
    } else if (index != null) {
      handleRemoveRows([$rows[index]]);
    }
  };
  const refreshRow = async (id) => {
    try {
      const row = await datasource.actions.getRow(id);
      replaceRow(id, row);
    } catch {
    }
  };
  const refreshData = async () => {
    var _a;
    await ((_a = get_store_value(fetch)) == null ? void 0 : _a.getInitialData());
  };
  const changesAreValid = (row, changes) => {
    const columns2 = Object.keys(changes || {});
    if (!row || !columns2.length) {
      return false;
    }
    return columns2.some((column) => row[column] !== changes[column]);
  };
  const stashRowChanges = (rowId, changes) => {
    var _a, _b;
    const $rowLookupMap = get_store_value(rowLookupMap);
    const $columnLookupMap = get_store_value(columnLookupMap);
    const row = $rowLookupMap[rowId];
    for (let column of Object.keys(changes || {})) {
      const type = (_b = (_a = $columnLookupMap[column]) == null ? void 0 : _a.schema) == null ? void 0 : _b.type;
      if (type === FieldType.STRING || type == FieldType.LONGFORM) {
        if (changes[column] != null && typeof changes[column] !== "string") {
          changes[column] = JSON.stringify(changes[column]);
        }
      }
    }
    if (!row || !changesAreValid(row, changes)) {
      return false;
    }
    rowChangeCache.update((state) => ({
      ...state,
      [rowId]: {
        ...state[rowId],
        ...changes
      }
    }));
    return true;
  };
  const applyRowChanges = async ({
    rowId,
    changes = null,
    updateState = true,
    handleErrors = true
  }) => {
    const $rowLookupMap = get_store_value(rowLookupMap);
    const row = $rowLookupMap[rowId];
    if (row == null) {
      return;
    }
    let savedRow = void 0;
    try {
      inProgressChanges.update((state) => ({
        ...state,
        [rowId]: (state[rowId] || 0) + 1
      }));
      const stashedChanges = get_store_value(rowChangeCache)[rowId];
      const newRow = { ...cleanRow(row), ...stashedChanges, ...changes };
      savedRow = await datasource.actions.updateRow(newRow);
      if (savedRow == null ? void 0 : savedRow._id) {
        if (updateState) {
          rows.update((state) => {
            state[row.__idx] = savedRow;
            return state.slice();
          });
        }
      } else if (savedRow == null ? void 0 : savedRow.id) {
        await refreshRow(savedRow.id);
      }
      const liveChanges = get_store_value(rowChangeCache)[rowId];
      rowChangeCache.update((state) => {
        Object.keys(stashedChanges || {}).forEach((key) => {
          if (stashedChanges[key] === (liveChanges == null ? void 0 : liveChanges[key])) {
            delete state[rowId][key];
          }
        });
        return state;
      });
    } catch (error2) {
      if (handleErrors) {
        handleValidationError(rowId, error2);
        validation.actions.focusFirstRowError(rowId);
      }
    }
    inProgressChanges.update((state) => ({
      ...state,
      [rowId]: (state[rowId] || 1) - 1
    }));
    return savedRow;
  };
  const updateValue = async ({
    rowId,
    column,
    value,
    apply = true
  }) => {
    const success = stashRowChanges(rowId, { [column]: value });
    if (success && apply) {
      await applyRowChanges({ rowId });
    }
  };
  const bulkUpdate = async (changeMap, progressCallback) => {
    const rowIds = Object.keys(changeMap || {});
    const count = rowIds.length;
    if (!count) {
      return;
    }
    const $columnLookupMap = get_store_value(columnLookupMap);
    let updated = [];
    let failed = 0;
    for (let i = 0; i < count; i++) {
      const rowId = rowIds[i];
      let changes = changeMap[rowId] || {};
      for (let field of Object.keys(changes)) {
        const column = $columnLookupMap[field];
        if (columns.actions.isReadonly(column)) {
          delete changes[field];
        }
      }
      if (!Object.keys(changes).length) {
        progressCallback == null ? void 0 : progressCallback((i + 1) / count);
        continue;
      }
      try {
        const updatedRow = await applyRowChanges({
          rowId,
          changes: changeMap[rowId],
          updateState: false,
          handleErrors: false
        });
        if (updatedRow) {
          updated.push(updatedRow);
        } else {
          failed++;
        }
        await sleep(50);
      } catch (error2) {
        failed++;
        console.error("Failed to update row", error2);
      }
      progressCallback == null ? void 0 : progressCallback((i + 1) / count);
    }
    if (updated.length) {
      const $rowLookupMap = get_store_value(rowLookupMap);
      rows.update((state) => {
        for (let row of updated) {
          const index = $rowLookupMap[row._id].__idx;
          state[index] = row;
        }
        return state.slice();
      });
    }
    if (failed) {
      const unit = `row${count === 1 ? "" : "s"}`;
      get_store_value(notifications2).error(`Failed to update ${failed} of ${count} ${unit}`);
    } else if (updated.length) {
      const unit = `row${updated.length === 1 ? "" : "s"}`;
      get_store_value(notifications2).success(`Updated ${updated.length} ${unit}`);
    }
  };
  const deleteRows = async (rowsToDelete) => {
    if (!(rowsToDelete == null ? void 0 : rowsToDelete.length)) {
      return;
    }
    rowsToDelete.forEach((row) => delete row.__idx);
    await datasource.actions.deleteRows(rowsToDelete);
    handleRemoveRows(rowsToDelete);
  };
  const handleNewRows = (newRows, resetRows) => {
    var _a;
    if (resetRows) {
      rowCacheMap = {};
    }
    let rowsToAppend = [];
    let newRow;
    const $hasBudibaseIdentifiers = get_store_value(hasBudibaseIdentifiers);
    for (let i = 0; i < newRows.length; i++) {
      newRow = newRows[i];
      if (!$hasBudibaseIdentifiers && !((_a = newRow._id) == null ? void 0 : _a.length)) {
        newRow._id = generateRowID();
      }
      if (!rowCacheMap[newRow._id]) {
        rowCacheMap[newRow._id] = true;
        rowsToAppend.push(newRow);
      }
    }
    if (resetRows) {
      rows.set(rowsToAppend);
    } else if (rowsToAppend.length) {
      rows.update((state) => [...state, ...rowsToAppend]);
    }
  };
  const handleRemoveRows = (rowsToRemove) => {
    const deletedIds = rowsToRemove.map((row) => row._id);
    rows.update((state) => {
      return state.filter((row) => !deletedIds.includes(row._id));
    });
  };
  const loadNextPage = () => {
    var _a;
    (_a = get_store_value(fetch)) == null ? void 0 : _a.nextPage();
  };
  const cleanRow = (row) => {
    let clone = { ...row };
    delete clone.__idx;
    delete clone.__metadata;
    delete clone.__formatted;
    if (!get_store_value(hasBudibaseIdentifiers) && isGeneratedRowID(clone._id)) {
      delete clone._id;
    }
    return clone;
  };
  return {
    rows: {
      ...rows,
      actions: {
        addRow,
        duplicateRow,
        bulkDuplicate,
        updateValue,
        applyRowChanges,
        deleteRows,
        loadNextPage,
        refreshRow,
        replaceRow,
        refreshData,
        cleanRow,
        bulkUpdate
      }
    }
  };
};
const initialise$9 = (context) => {
  const {
    rowChangeCache,
    inProgressChanges,
    previousFocusedRowId,
    previousFocusedCellId,
    rows,
    validation
  } = context;
  previousFocusedRowId.subscribe((id) => {
    if (id && !get_store_value(inProgressChanges)[id]) {
      if (Object.keys(get_store_value(rowChangeCache)[id] || {}).length) {
        rowChangeCache.update((state) => {
          delete state[id];
          return state;
        });
      }
    }
  });
  previousFocusedCellId.subscribe(async (id) => {
    if (!id) {
      return;
    }
    let { rowId, field } = parseCellID(id);
    rowId = rowId;
    field = field;
    const hasChanges = field in (get_store_value(rowChangeCache)[rowId] || {});
    const hasErrors = validation.actions.rowHasErrors(rowId);
    const isSavingChanges = get_store_value(inProgressChanges)[rowId];
    if (rowId && !hasErrors && hasChanges && !isSavingChanges) {
      await rows.actions.applyRowChanges({ rowId });
    }
  });
};
const Rows = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$a,
  createStores: createStores$a,
  deriveStores: deriveStores$9,
  initialise: initialise$9
}, Symbol.toStringTag, { value: "Module" }));
const createStores$9 = () => {
  const scroll = writable({
    left: 0,
    top: 0
  });
  const scrollTop = derived(scroll, ($scroll) => Math.round($scroll.top));
  const scrollLeft = derived(scroll, ($scroll) => Math.round($scroll.left));
  return {
    scroll,
    scrollTop,
    scrollLeft
  };
};
const deriveStores$8 = (context) => {
  const {
    rows,
    visibleColumns,
    displayColumn,
    rowHeight,
    width,
    height,
    buttonColumnWidth,
    config
  } = context;
  const stickyWidth = derived(displayColumn, ($displayColumn) => {
    return (($displayColumn == null ? void 0 : $displayColumn.width) || 0) + GutterWidth;
  });
  const contentWidth = derived(
    [visibleColumns, buttonColumnWidth],
    ([$visibleColumns, $buttonColumnWidth]) => {
      let width2 = GutterWidth + Math.max($buttonColumnWidth, HPadding);
      $visibleColumns.forEach((col) => {
        width2 += col.width;
      });
      return width2;
    }
  );
  const screenWidth = derived(
    [width, stickyWidth],
    ([$width, $stickyWidth]) => {
      return $width + $stickyWidth;
    }
  );
  const maxScrollLeft = derived(
    [contentWidth, screenWidth],
    ([$contentWidth, $screenWidth]) => {
      return Math.round(Math.max($contentWidth - $screenWidth, 0));
    }
  );
  const showHScrollbar = derived(
    [contentWidth, screenWidth],
    ([$contentWidth, $screenWidth]) => {
      return $contentWidth > $screenWidth;
    }
  );
  const contentHeight = derived(
    [rows, rowHeight, showHScrollbar, config],
    ([$rows, $rowHeight, $showHScrollbar, $config]) => {
      let height2 = $rows.length * $rowHeight + VPadding;
      if ($showHScrollbar) {
        height2 += ScrollBarSize * 3;
      }
      if ($config.canAddRows) {
        height2 += $rowHeight;
      }
      return height2;
    }
  );
  const maxScrollTop = derived(
    [height, contentHeight],
    ([$height, $contentHeight]) => Math.round(Math.max($contentHeight - $height, 0))
  );
  const showVScrollbar = derived(
    [contentHeight, height],
    ([$contentHeight, $height]) => {
      return $contentHeight > $height;
    }
  );
  return {
    stickyWidth,
    contentHeight,
    contentWidth,
    screenWidth,
    maxScrollTop,
    maxScrollLeft,
    showHScrollbar,
    showVScrollbar
  };
};
const initialise$8 = (context) => {
  const {
    focusedCellId,
    focusedRow,
    scroll,
    bounds,
    rowHeight,
    stickyWidth,
    scrollTop,
    maxScrollTop,
    scrollLeft,
    maxScrollLeft,
    buttonColumnWidth,
    columnLookupMap
  } = context;
  const overscrollTop = derived(
    [scrollTop, maxScrollTop],
    ([$scrollTop, $maxScrollTop]) => $scrollTop > $maxScrollTop,
    false
  );
  const overscrollLeft = derived(
    [scrollLeft, maxScrollLeft],
    ([$scrollLeft, $maxScrollLeft]) => $scrollLeft > $maxScrollLeft,
    false
  );
  overscrollTop.subscribe((overscroll) => {
    if (overscroll) {
      scroll.update((state) => ({
        ...state,
        top: get_store_value(maxScrollTop)
      }));
    }
  });
  overscrollLeft.subscribe((overscroll) => {
    if (overscroll) {
      scroll.update((state) => ({
        ...state,
        left: get_store_value(maxScrollLeft)
      }));
    }
  });
  focusedCellId.subscribe(async ($focusedCellId) => {
    await tick();
    const $focusedRow = get_store_value(focusedRow);
    const $scroll = get_store_value(scroll);
    const $bounds = get_store_value(bounds);
    const $rowHeight = get_store_value(rowHeight);
    if ($focusedRow) {
      const rowYPos = $focusedRow.__idx * $rowHeight;
      const bottomCutoff = $scroll.top + $bounds.height - $rowHeight - FocusedCellMinOffset;
      let delta2 = rowYPos - bottomCutoff;
      if (delta2 > 0) {
        scroll.update((state) => ({
          ...state,
          top: state.top + delta2
        }));
      } else {
        const delta3 = $scroll.top - rowYPos + FocusedCellMinOffset;
        if (delta3 > 0) {
          scroll.update((state) => ({
            ...state,
            top: Math.max(0, state.top - delta3)
          }));
        }
      }
    }
    const { field } = parseCellID($focusedCellId);
    const column = get_store_value(columnLookupMap)[field];
    if (!column || column.primaryDisplay) {
      return;
    }
    const $stickyWidth = get_store_value(stickyWidth);
    let delta = $scroll.left - column.__left + FocusedCellMinOffset + $stickyWidth;
    if (delta > 0) {
      scroll.update((state) => ({
        ...state,
        left: Math.max(0, state.left - delta)
      }));
    } else {
      const $buttonColumnWidth = get_store_value(buttonColumnWidth);
      const rightEdge = column.__left + column.width;
      const rightBound = $bounds.width + $scroll.left - FocusedCellMinOffset - $buttonColumnWidth;
      delta = rightEdge - rightBound - $stickyWidth;
      if (delta > 0) {
        scroll.update((state) => ({
          ...state,
          left: state.left + delta
        }));
      }
    }
  });
};
const Scroll = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createStores: createStores$9,
  deriveStores: deriveStores$8,
  initialise: initialise$8
}, Symbol.toStringTag, { value: "Module" }));
const createStores$8 = (context) => {
  const { props } = context;
  const focusedCellId = writable(null);
  const focusedCellAPI = writable(null);
  const selectedRows = writable({});
  const hoveredRowId = writable(null);
  const rowHeight = writable(get_store_value(props).fixedRowHeight || DefaultRowHeight);
  const previousFocusedRowId = writable(null);
  const previousFocusedCellId = writable(null);
  const gridFocused = writable(false);
  const keyboardBlocked = writable(false);
  const isDragging = writable(false);
  const buttonColumnWidth = writable(0);
  const cellSelection = writable({
    active: false,
    sourceCellId: null,
    targetCellId: null
  });
  return {
    focusedCellId,
    focusedCellAPI,
    previousFocusedRowId,
    previousFocusedCellId,
    hoveredRowId,
    rowHeight,
    gridFocused,
    keyboardBlocked,
    isDragging,
    buttonColumnWidth,
    selectedRows,
    cellSelection
  };
};
const deriveStores$7 = (context) => {
  const {
    focusedCellId,
    rows,
    rowLookupMap,
    rowHeight,
    width,
    selectedRows,
    cellSelection,
    columnLookupMap,
    visibleColumns
  } = context;
  const focusedRowId = derived(focusedCellId, ($focusedCellId) => {
    return parseCellID($focusedCellId).rowId ?? null;
  });
  const focusedRow = derived(
    [focusedRowId, rowLookupMap],
    ([$focusedRowId, $rowLookupMap]) => {
      if ($focusedRowId === null) {
        return;
      }
      if ($focusedRowId === NewRowID) {
        return { _id: NewRowID };
      }
      return $rowLookupMap[$focusedRowId];
    }
  );
  const contentLines = derived(rowHeight, ($rowHeight) => {
    if ($rowHeight >= LargeRowHeight) {
      return 3;
    } else if ($rowHeight >= MediumRowHeight) {
      return 2;
    }
    return 1;
  });
  const compact = derived(width, ($width) => {
    return $width < 600;
  });
  const selectedRowCount = derived(selectedRows, ($selectedRows) => {
    return Object.keys($selectedRows).length;
  });
  const isSelectingCells = derived(cellSelection, ($cellSelection) => {
    return $cellSelection.active;
  });
  const selectedCells = derived(
    [cellSelection, rowLookupMap, columnLookupMap],
    ([$cellSelection, $rowLookupMap, $columnLookupMap]) => {
      var _a, _b;
      const { sourceCellId, targetCellId } = $cellSelection;
      if (!sourceCellId || !targetCellId || sourceCellId === targetCellId) {
        return [];
      }
      const $rows = get_store_value(rows);
      const $visibleColumns = get_store_value(visibleColumns);
      const sourceInfo = parseCellID(sourceCellId);
      const targetInfo = parseCellID(targetCellId);
      if (sourceInfo.rowId === NewRowID) {
        return [];
      }
      const sourceRowIndex = (_a = $rowLookupMap[sourceInfo.rowId]) == null ? void 0 : _a.__idx;
      const targetRowIndex = (_b = $rowLookupMap[targetInfo.rowId]) == null ? void 0 : _b.__idx;
      if (sourceRowIndex == null || targetRowIndex == null) {
        return [];
      }
      const lowerRowIndex = Math.min(sourceRowIndex, targetRowIndex);
      let upperRowIndex = Math.max(sourceRowIndex, targetRowIndex);
      upperRowIndex = Math.min(upperRowIndex, lowerRowIndex + 49);
      const sourceColIndex = $columnLookupMap[sourceInfo.field].__idx || 0;
      const targetColIndex = $columnLookupMap[targetInfo.field].__idx || 0;
      const lowerColIndex = Math.min(sourceColIndex, targetColIndex);
      const upperColIndex = Math.max(sourceColIndex, targetColIndex);
      let cells = [];
      let rowId, colName;
      for (let rowIdx = lowerRowIndex; rowIdx <= upperRowIndex; rowIdx++) {
        let rowCells = [];
        for (let colIdx = lowerColIndex; colIdx <= upperColIndex; colIdx++) {
          rowId = $rows[rowIdx]._id;
          colName = $visibleColumns[colIdx].name;
          rowCells.push(getCellID(rowId, colName));
        }
        cells.push(rowCells);
      }
      return cells;
    }
  );
  const selectedCellMap = derived(selectedCells, ($selectedCells) => {
    let map = {};
    for (let row of $selectedCells) {
      for (let cell of row) {
        map[cell] = true;
      }
    }
    return map;
  });
  const selectedCellCount = derived(selectedCellMap, ($selectedCellMap) => {
    return Object.keys($selectedCellMap).length;
  });
  return {
    focusedRowId,
    focusedRow,
    contentLines,
    compact,
    selectedRowCount,
    isSelectingCells,
    selectedCells,
    selectedCellMap,
    selectedCellCount
  };
};
const createActions$9 = (context) => {
  const {
    focusedCellId,
    hoveredRowId,
    selectedRows,
    rowLookupMap,
    rows,
    selectedRowCount,
    cellSelection,
    selectedCells
  } = context;
  let lastSelectedIndex = null;
  const blur = () => {
    focusedCellId.set(null);
    hoveredRowId.set(null);
    clearCellSelection();
  };
  const toggleSelectedRow = (id) => {
    selectedRows.update((state) => {
      let newState = {
        ...state,
        [id]: !state[id]
      };
      if (!newState[id]) {
        delete newState[id];
      } else {
        lastSelectedIndex = get_store_value(rowLookupMap)[id].__idx;
      }
      return newState;
    });
  };
  const bulkSelectRows = (id) => {
    if (!get_store_value(selectedRowCount)) {
      toggleSelectedRow(id);
      return;
    }
    if (lastSelectedIndex == null) {
      return;
    }
    const thisIndex = get_store_value(rowLookupMap)[id].__idx;
    if (lastSelectedIndex === thisIndex) {
      return;
    }
    const from = Math.min(lastSelectedIndex, thisIndex);
    const to = Math.max(lastSelectedIndex, thisIndex);
    const $rows = get_store_value(rows);
    selectedRows.update((state) => {
      for (let i = from; i <= to; i++) {
        state[$rows[i]._id] = true;
      }
      return state;
    });
  };
  const startCellSelection = (sourceCellId) => {
    cellSelection.set({
      active: true,
      sourceCellId,
      targetCellId: sourceCellId
    });
  };
  const updateCellSelection = (targetCellId) => {
    cellSelection.update((state) => ({
      ...state,
      targetCellId
    }));
  };
  const stopCellSelection = () => {
    cellSelection.update((state) => ({
      ...state,
      active: false
    }));
  };
  const selectCellRange = (source, target) => {
    cellSelection.set({
      active: false,
      sourceCellId: source,
      targetCellId: target
    });
  };
  const clearCellSelection = () => {
    cellSelection.set({
      active: false,
      sourceCellId: null,
      targetCellId: null
    });
  };
  return {
    ui: {
      actions: {
        blur
      }
    },
    selectedRows: {
      ...selectedRows,
      actions: {
        toggleRow: toggleSelectedRow,
        bulkSelectRows
      }
    },
    selectedCells: {
      ...selectedCells,
      actions: {
        startSelecting: startCellSelection,
        updateTarget: updateCellSelection,
        stopSelecting: stopCellSelection,
        selectRange: selectCellRange,
        clear: clearCellSelection
      }
    }
  };
};
const initialise$7 = (context) => {
  const {
    focusedRowId,
    previousFocusedRowId,
    previousFocusedCellId,
    rowLookupMap,
    focusedCellId,
    selectedRows,
    hoveredRowId,
    definition,
    rowHeight,
    fixedRowHeight,
    selectedRowCount,
    menu,
    selectedCellCount,
    selectedCells,
    cellSelection
  } = context;
  rowLookupMap.subscribe(async ($rowLookupMap) => {
    await tick();
    const $focusedRowId = get_store_value(focusedRowId);
    const $selectedRows = get_store_value(selectedRows);
    const $hoveredRowId = get_store_value(hoveredRowId);
    const hasRow = (id) => $rowLookupMap[id] != null;
    if ($focusedRowId && !hasRow($focusedRowId)) {
      focusedCellId.set(null);
    }
    if ($hoveredRowId && !hasRow($hoveredRowId)) {
      hoveredRowId.set(null);
    }
    const selectedIds = Object.keys($selectedRows);
    if (selectedIds.length) {
      let newSelectedRows = { ...$selectedRows };
      let selectedRowsNeedsUpdate = false;
      for (let i = 0; i < selectedIds.length; i++) {
        if (!hasRow(selectedIds[i])) {
          delete newSelectedRows[selectedIds[i]];
          selectedRowsNeedsUpdate = true;
        }
      }
      if (selectedRowsNeedsUpdate) {
        selectedRows.set(newSelectedRows);
      }
    }
  });
  let lastFocusedRowId = null;
  focusedRowId.subscribe((id) => {
    previousFocusedRowId.set(lastFocusedRowId);
    lastFocusedRowId = id;
  });
  let lastFocusedCellId = null;
  focusedCellId.subscribe((id) => {
    previousFocusedCellId.set(lastFocusedCellId);
    lastFocusedCellId = id;
    if (id && get_store_value(hoveredRowId)) {
      hoveredRowId.set(null);
    }
    if (id && get_store_value(selectedRowCount)) {
      selectedRows.set({});
    }
    if (id && get_store_value(selectedCellCount)) {
      selectedCells.actions.clear();
    }
    menu.actions.close();
  });
  definition.subscribe(($definition) => {
    if (!get_store_value(fixedRowHeight)) {
      rowHeight.set(($definition == null ? void 0 : $definition.rowHeight) || DefaultRowHeight);
    }
  });
  fixedRowHeight.subscribe((height) => {
    var _a;
    if (height) {
      rowHeight.set(height);
    } else {
      rowHeight.set(((_a = get_store_value(definition)) == null ? void 0 : _a.rowHeight) || DefaultRowHeight);
    }
  });
  selectedRowCount.subscribe((count) => {
    if (count) {
      if (get_store_value(focusedCellId)) {
        focusedCellId.set(null);
      }
      if (get_store_value(selectedCellCount)) {
        selectedCells.actions.clear();
      }
    }
  });
  selectedCellCount.subscribe(($selectedCellCount) => {
    if ($selectedCellCount) {
      if (get_store_value(selectedRowCount)) {
        selectedRows.set({});
      }
    }
  });
  cellSelection.subscribe(async ({ sourceCellId, targetCellId }) => {
    if (sourceCellId && sourceCellId !== targetCellId && get_store_value(focusedCellId) !== sourceCellId) {
      focusedCellId.set(sourceCellId);
    }
  });
};
const UI = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$9,
  createStores: createStores$8,
  deriveStores: deriveStores$7,
  initialise: initialise$7
}, Symbol.toStringTag, { value: "Module" }));
const createStores$7 = () => {
  const users = writable([]);
  const enrichedUsers = derived(users, ($users) => {
    return $users.map((user) => ({
      ...user,
      color: getUserColor(user),
      label: getUserLabel(user)
    }));
  });
  return {
    users: {
      ...users,
      subscribe: enrichedUsers.subscribe
    }
  };
};
const deriveStores$6 = (context) => {
  const { users, focusedCellId } = context;
  const userCellMap = derived(
    [users, focusedCellId],
    ([$users, $focusedCellId]) => {
      let map = {};
      $users.forEach((user) => {
        var _a;
        const cellId = (_a = user.gridMetadata) == null ? void 0 : _a.focusedCellId;
        if (cellId && cellId !== $focusedCellId) {
          map[cellId] = user;
        }
      });
      return map;
    }
  );
  return {
    userCellMap
  };
};
const createActions$8 = (context) => {
  const { users } = context;
  const updateUser = (user) => {
    const $users = get_store_value(users);
    if (!$users.some((x) => x.sessionId === user.sessionId)) {
      users.set([...$users, user]);
    } else {
      users.update((state) => {
        const index = state.findIndex((x) => x.sessionId === user.sessionId);
        state[index] = user;
        return state.slice();
      });
    }
  };
  const removeUser = (sessionId) => {
    users.update((state) => {
      return state.filter((x) => x.sessionId !== sessionId);
    });
  };
  return {
    users: {
      ...users,
      actions: {
        updateUser,
        removeUser
      }
    }
  };
};
const Users = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$8,
  createStores: createStores$7,
  deriveStores: deriveStores$6
}, Symbol.toStringTag, { value: "Module" }));
const createStores$6 = () => {
  const validation = writable({});
  return {
    validation
  };
};
const deriveStores$5 = (context) => {
  const { validation } = context;
  const validationRowLookupMap = derived(validation, ($validation) => {
    const map = {};
    Object.entries($validation).forEach(([key, error]) => {
      if (error) {
        const { rowId } = parseCellID(key);
        if (rowId !== void 0) {
          if (!map[rowId]) {
            map[rowId] = [];
          }
          map[rowId].push(key);
        }
      }
    });
    return map;
  });
  return {
    validationRowLookupMap
  };
};
const createActions$7 = (context) => {
  const { validation, focusedCellId, validationRowLookupMap } = context;
  const setError = (cellId, error) => {
    if (!cellId) {
      return;
    }
    validation.update((state) => ({
      ...state,
      [cellId]: error
    }));
  };
  const rowHasErrors = (rowId) => {
    var _a;
    return ((_a = get_store_value(validationRowLookupMap)[rowId]) == null ? void 0 : _a.length) > 0;
  };
  const focusFirstRowError = (rowId) => {
    const errorCells = get_store_value(validationRowLookupMap)[rowId];
    const cellId = errorCells == null ? void 0 : errorCells[0];
    if (cellId) {
      focusedCellId.set(cellId);
    }
  };
  return {
    validation: {
      ...validation,
      actions: {
        setError,
        rowHasErrors,
        focusFirstRowError
      }
    }
  };
};
const initialise$6 = (context) => {
  const { validation, previousFocusedRowId, validationRowLookupMap } = context;
  previousFocusedRowId.subscribe((id) => {
    if (id) {
      const errorCells = get_store_value(validationRowLookupMap)[id];
      if (errorCells == null ? void 0 : errorCells.length) {
        validation.update((state) => {
          for (let cellId of errorCells) {
            delete state[cellId];
          }
          return state;
        });
      }
    }
  });
};
const Validation = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$7,
  createStores: createStores$6,
  deriveStores: deriveStores$5,
  initialise: initialise$6
}, Symbol.toStringTag, { value: "Module" }));
const deriveStores$4 = (context) => {
  const {
    rowHeight,
    scrollableColumns,
    rows,
    scrollTop,
    scrollLeft,
    width,
    height,
    rowChangeCache,
    metadata
  } = context;
  const scrolledRowCount = derived(
    [scrollTop, rowHeight],
    ([$scrollTop, $rowHeight]) => {
      return Math.floor($scrollTop / $rowHeight);
    }
  );
  const visualRowCapacity = derived(
    [height, rowHeight],
    ([$height, $rowHeight]) => {
      return Math.ceil($height / $rowHeight) + 1;
    }
  );
  const renderedRows = derived(
    [rows, scrolledRowCount, visualRowCapacity, rowChangeCache, metadata],
    ([
      $rows,
      $scrolledRowCount,
      $visualRowCapacity,
      $rowChangeCache,
      $metadata
    ]) => {
      return $rows.slice($scrolledRowCount, $scrolledRowCount + $visualRowCapacity).map((row) => ({
        ...row,
        ...$rowChangeCache[row._id],
        __metadata: $metadata[row._id]
      }));
    }
  );
  const scrollLeftRounded = derived(scrollLeft, ($scrollLeft) => {
    const interval = MinColumnWidth;
    return Math.round($scrollLeft / interval) * interval;
  });
  const columnRenderMap = derived(
    [scrollableColumns, scrollLeftRounded, width],
    ([$scrollableColumns, $scrollLeft, $width]) => {
      if (!$scrollableColumns.length) {
        return {};
      }
      let startColIdx = 0;
      let rightEdge = $scrollableColumns[0].width;
      while (rightEdge < $scrollLeft && startColIdx < $scrollableColumns.length - 1) {
        startColIdx++;
        rightEdge += $scrollableColumns[startColIdx].width;
      }
      let endColIdx = startColIdx + 1;
      let leftEdge = rightEdge;
      while (leftEdge < $width + $scrollLeft && endColIdx < $scrollableColumns.length) {
        leftEdge += $scrollableColumns[endColIdx].width;
        endColIdx++;
      }
      let next = {};
      $scrollableColumns.slice(Math.max(0, startColIdx), endColIdx).forEach((col) => {
        next[col.name] = true;
      });
      return next;
    }
  );
  return {
    scrolledRowCount,
    visualRowCapacity,
    renderedRows,
    columnRenderMap
  };
};
const Viewport = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  deriveStores: deriveStores$4
}, Symbol.toStringTag, { value: "Module" }));
const createStores$5 = (context) => {
  var _a;
  let initialState2;
  if ((_a = context == null ? void 0 : context.externalClipboard) == null ? void 0 : _a.clipboard) {
    const externalState = context.externalClipboard.clipboard.get();
    if (externalState.multiCellCopy) {
      initialState2 = {
        value: externalState.value,
        multiCellCopy: true
      };
    } else {
      initialState2 = {
        value: externalState.value,
        multiCellCopy: false
      };
    }
  } else {
    initialState2 = {
      value: void 0,
      multiCellCopy: false
    };
  }
  const clipboard = writable(initialState2);
  return {
    clipboard
  };
};
const deriveStores$3 = (context) => {
  const {
    clipboard,
    focusedCellAPI,
    selectedCellCount,
    config,
    focusedRowId,
    props
  } = context;
  const copyAllowed = derived(focusedCellAPI, ($focusedCellAPI) => {
    return $focusedCellAPI != null;
  });
  const pasteAllowed = derived(
    [clipboard, focusedCellAPI, selectedCellCount, config, focusedRowId, props],
    ([
      $clipboard,
      $focusedCellAPI,
      $selectedCellCount,
      $config,
      $focusedRowId,
      $props
    ]) => {
      var _a;
      let hasClipboardData = $clipboard.value != null;
      if (!hasClipboardData && ((_a = $props.externalClipboard) == null ? void 0 : _a.clipboard)) {
        const externalState = $props.externalClipboard.clipboard.get();
        hasClipboardData = externalState.value != null;
      }
      if (!hasClipboardData || !$config.canEditRows || !$focusedCellAPI || $focusedRowId === NewRowID) {
        return false;
      }
      const multiCellPaste = $selectedCellCount > 1;
      if (!$clipboard.multiCellCopy && !multiCellPaste && $focusedCellAPI.isReadonly()) {
        return false;
      }
      return true;
    }
  );
  return {
    copyAllowed,
    pasteAllowed
  };
};
const createActions$6 = (context) => {
  const {
    clipboard,
    focusedCellAPI,
    copyAllowed,
    pasteAllowed,
    selectedCells,
    selectedCellCount,
    rowLookupMap,
    rowChangeCache,
    rows,
    focusedCellId,
    columnLookupMap,
    visibleColumns,
    props
  } = context;
  const copy = () => {
    if (!get_store_value(copyAllowed)) {
      return;
    }
    const $selectedCells = get_store_value(selectedCells);
    const $focusedCellAPI = get_store_value(focusedCellAPI);
    const $selectedCellCount = get_store_value(selectedCellCount);
    const multiCellCopy = $selectedCellCount > 1;
    if (multiCellCopy) {
      const $rowLookupMap = get_store_value(rowLookupMap);
      const $rowChangeCache = get_store_value(rowChangeCache);
      const value = [];
      for (const row of $selectedCells) {
        const rowValues = [];
        for (const cellId of row) {
          const { rowId = "", field = "" } = parseCellID(cellId);
          const row2 = {
            ...$rowLookupMap[rowId],
            ...$rowChangeCache[rowId]
          };
          rowValues.push(row2[field]);
        }
        value.push(rowValues);
      }
      clipboard.set({
        value,
        multiCellCopy: true
      });
      const { externalClipboard } = get_store_value(props);
      if (externalClipboard == null ? void 0 : externalClipboard.onCopy) {
        externalClipboard.onCopy({
          value,
          multiCellCopy: true,
          tableId: externalClipboard.tableId,
          viewId: externalClipboard.viewId
        });
      }
    } else {
      const value = $focusedCellAPI == null ? void 0 : $focusedCellAPI.getValue();
      clipboard.set({
        value,
        multiCellCopy
      });
      const { externalClipboard } = get_store_value(props);
      if (externalClipboard == null ? void 0 : externalClipboard.onCopy) {
        externalClipboard.onCopy({
          value,
          multiCellCopy: false,
          tableId: externalClipboard.tableId,
          viewId: externalClipboard.viewId
        });
      }
      let stringified = "";
      if (value != null && value !== "") {
        stringified = typeof value === "object" ? JSON.stringify(value) : value;
      }
      copyToClipboard(stringified);
    }
  };
  const paste = async (progressCallback) => {
    var _a, _b;
    if (!get_store_value(pasteAllowed)) {
      return;
    }
    const { externalClipboard } = get_store_value(props);
    let clipboardData = get_store_value(clipboard);
    if (externalClipboard == null ? void 0 : externalClipboard.clipboard) {
      const externalState = externalClipboard.clipboard.get();
      if (externalState.value !== void 0) {
        if (externalState.multiCellCopy) {
          clipboardData = {
            value: externalState.value,
            multiCellCopy: true
          };
        } else {
          clipboardData = {
            value: externalState.value,
            multiCellCopy: false
          };
        }
      }
    }
    const { value, multiCellCopy } = clipboardData;
    const multiCellPaste = get_store_value(selectedCellCount) > 1;
    if (multiCellCopy) {
      if (multiCellPaste) {
        let newValue = value;
        const $selectedCells = get_store_value(selectedCells);
        const selectedRows = $selectedCells.length;
        const selectedColumns = $selectedCells[0].length;
        const copiedRows = value.length;
        const copiedColumns = value[0].length;
        if (selectedRows > copiedRows && selectedColumns === copiedColumns) {
          newValue = [];
          for (let i = 0; i < selectedRows; i++) {
            newValue.push(value[i % copiedRows]);
          }
        }
        await pasteIntoSelectedCells(newValue, progressCallback);
      } else {
        const $focusedCellId = get_store_value(focusedCellId);
        const { rowId, field } = parseCellID($focusedCellId);
        const $rowLookupMap = get_store_value(rowLookupMap);
        const $columnLookupMap = get_store_value(columnLookupMap);
        const rowIdx = $rowLookupMap[rowId].__idx;
        const colIdx = $columnLookupMap[field].__idx || 0;
        const $rows = get_store_value(rows);
        const $visibleColumns = get_store_value(visibleColumns);
        const colCount = $visibleColumns.length;
        const rowCount = $rows.length;
        const selectedRows = value.length;
        const selectedColumns = value[0].length;
        const rowExtent = Math.min(selectedRows, rowCount - rowIdx) - 1;
        const colExtent = Math.min(selectedColumns, colCount - colIdx) - 1;
        const targetRowId = $rows[rowIdx + rowExtent]._id;
        const targetColName = $visibleColumns[colIdx + colExtent].name;
        const targetCellId = getCellID(targetRowId, targetColName);
        if (targetCellId === $focusedCellId) {
          (_a = get_store_value(focusedCellAPI)) == null ? void 0 : _a.setValue(value[0][0]);
        } else {
          selectedCells.actions.selectRange($focusedCellId, targetCellId);
          await pasteIntoSelectedCells(value, progressCallback);
        }
      }
    } else {
      if (multiCellPaste) {
        const newValue = get_store_value(selectedCells).map((row) => row.map(() => value));
        await pasteIntoSelectedCells(newValue, progressCallback);
      } else {
        (_b = get_store_value(focusedCellAPI)) == null ? void 0 : _b.setValue(value ?? null);
      }
    }
  };
  const pasteIntoSelectedCells = async (value, progressCallback) => {
    const $selectedCells = get_store_value(selectedCells);
    const rowExtent = Math.min(value.length, $selectedCells.length);
    const colExtent = Math.min(value[0].length, $selectedCells[0].length);
    let changeMap = {};
    for (let rowIdx = 0; rowIdx < rowExtent; rowIdx++) {
      for (let colIdx = 0; colIdx < colExtent; colIdx++) {
        const cellId = $selectedCells[rowIdx][colIdx];
        let { rowId, field } = parseCellID(cellId);
        rowId = rowId;
        field = field;
        if (!changeMap[rowId]) {
          changeMap[rowId] = {};
        }
        changeMap[rowId][field] = value[rowIdx][colIdx];
      }
    }
    await rows.actions.bulkUpdate(changeMap, progressCallback);
  };
  return {
    clipboard: {
      ...clipboard,
      actions: {
        copy,
        paste
      }
    }
  };
};
const Clipboard = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$6,
  createStores: createStores$5,
  deriveStores: deriveStores$3
}, Symbol.toStringTag, { value: "Module" }));
const createStores$4 = (context) => {
  const { props } = context;
  const getProp = (prop) => derivedMemo(props, ($props) => $props[prop]);
  const datasource = getProp("datasource");
  const initialSortColumn = getProp("initialSortColumn");
  const initialSortOrder = getProp("initialSortOrder");
  const initialFilter = getProp("initialFilter");
  const fixedRowHeight = getProp("fixedRowHeight");
  const schemaOverrides = getProp("schemaOverrides");
  const notifySuccess = getProp("notifySuccess");
  const notifyError = getProp("notifyError");
  return {
    datasource,
    initialSortColumn,
    initialSortOrder,
    initialFilter,
    fixedRowHeight,
    schemaOverrides,
    notifySuccess,
    notifyError
  };
};
const deriveStores$2 = (context) => {
  const { props, definition, hasNonAutoColumn } = context;
  const config = derived(
    [props, definition, hasNonAutoColumn],
    ([$props, $definition, $hasNonAutoColumn]) => {
      var _a;
      let config2 = { ...$props, canSelectRows: false };
      const type = (_a = $props.datasource) == null ? void 0 : _a.type;
      if (type === "viewV2") {
        config2.canEditColumns = false;
        if (($definition == null ? void 0 : $definition.type) === ViewV2Type.CALCULATION) {
          config2.canAddRows = false;
          config2.canEditRows = false;
          config2.canDeleteRows = false;
          config2.canExpandRows = false;
        }
      }
      if (!$hasNonAutoColumn) {
        config2.canAddRows = false;
      }
      if (type && !["table", "viewV2"].includes(type)) {
        config2.canAddRows = false;
        config2.canEditRows = false;
        config2.canDeleteRows = false;
        config2.canExpandRows = false;
        config2.canSaveSchema = false;
        config2.canEditColumns = false;
      }
      config2.canSelectRows = true;
      return config2;
    }
  );
  return {
    config
  };
};
const Config = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createStores: createStores$4,
  deriveStores: deriveStores$2
}, Symbol.toStringTag, { value: "Module" }));
const createStores$3 = (context) => {
  const { props } = context;
  const $props = get_store_value(props);
  const sort = memo({
    column: $props.initialSortColumn,
    order: $props.initialSortOrder || SortOrder.ASCENDING
  });
  return {
    sort
  };
};
const initialise$5 = (context) => {
  const { sort, initialSortColumn, initialSortOrder, schema } = context;
  initialSortColumn.subscribe((newSortColumn) => {
    sort.update((state) => ({ ...state, column: newSortColumn }));
  });
  initialSortOrder.subscribe((newSortOrder) => {
    sort.update((state) => ({
      ...state,
      order: newSortOrder || SortOrder.ASCENDING
    }));
  });
  const sortColumnExists = derived([sort, schema], ([$sort, $schema]) => {
    if (!($sort == null ? void 0 : $sort.column) || !$schema) {
      return true;
    }
    return $schema[$sort.column] != null;
  });
  sortColumnExists.subscribe((exists) => {
    if (!exists) {
      sort.set({
        column: null,
        order: SortOrder.ASCENDING
      });
    }
  });
};
const Sort = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createStores: createStores$3,
  initialise: initialise$5
}, Symbol.toStringTag, { value: "Module" }));
const createStores$2 = (context) => {
  const { props } = context;
  const filter = memo(get_store_value(props).initialFilter ?? void 0);
  const inlineFilters = memo([]);
  return {
    filter,
    inlineFilters
  };
};
const deriveStores$1 = (context) => {
  const { filter, inlineFilters } = context;
  const allFilters = derived(
    [filter, inlineFilters],
    ([$filter, $inlineFilters]) => {
      var _a;
      if (!($inlineFilters == null ? void 0 : $inlineFilters.length)) {
        return $filter;
      }
      const allFilters2 = {
        logicalOperator: UILogicalOperator.ALL,
        groups: [
          {
            logicalOperator: UILogicalOperator.ALL,
            filters: $inlineFilters
          }
        ]
      };
      if (!((_a = $filter == null ? void 0 : $filter.groups) == null ? void 0 : _a.length)) {
        return allFilters2;
      }
      allFilters2.groups = [...allFilters2.groups, ...$filter.groups];
      return allFilters2;
    }
  );
  return {
    allFilters
  };
};
const createActions$5 = (context) => {
  const { filter, inlineFilters } = context;
  const addInlineFilter = (column, value) => {
    const filterId = `inline-${column.name}`;
    const type = column.schema.type;
    const inlineFilter = {
      field: column.name,
      id: filterId,
      operator: BasicOperator.STRING,
      valueType: "value",
      type,
      value
    };
    if (type === FieldType.NUMBER) {
      inlineFilter.value = parseFloat(value);
      inlineFilter.operator = BasicOperator.EQUAL;
    } else if (type === FieldType.BIGINT) {
      inlineFilter.operator = BasicOperator.EQUAL;
    } else if (type === FieldType.ARRAY) {
      inlineFilter.operator = ArrayOperator.CONTAINS;
    }
    inlineFilters.update(($inlineFilters) => {
      $inlineFilters = $inlineFilters == null ? void 0 : $inlineFilters.filter((x) => x.id !== filterId);
      if (value) {
        $inlineFilters.push(inlineFilter);
      }
      return $inlineFilters;
    });
  };
  return {
    filter: {
      ...filter,
      actions: {
        addInlineFilter
      }
    }
  };
};
const initialise$4 = (context) => {
  const { filter, initialFilter } = context;
  initialFilter.subscribe(
    ($initialFilter) => filter.set($initialFilter ?? void 0)
  );
};
const Filter = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$5,
  createStores: createStores$2,
  deriveStores: deriveStores$1,
  initialise: initialise$4
}, Symbol.toStringTag, { value: "Module" }));
const createStores$1 = (context) => {
  const { notifySuccess, notifyError } = context;
  const notifications$1 = derived(
    [notifySuccess, notifyError],
    ([$notifySuccess, $notifyError]) => {
      return {
        success: $notifySuccess || notifications.success,
        error: $notifyError || notifications.error
      };
    }
  );
  return {
    notifications: notifications$1
  };
};
const Notifications = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createStores: createStores$1
}, Symbol.toStringTag, { value: "Module" }));
const createStores = () => {
  const definition = memo(null);
  const schemaMutations = memo({});
  const subSchemaMutations = memo({});
  return {
    definition,
    schemaMutations,
    subSchemaMutations
  };
};
const deriveStores = (context) => {
  const {
    API,
    definition,
    schemaOverrides,
    datasource,
    schemaMutations,
    subSchemaMutations
  } = context;
  const schema = derived(definition, ($definition) => {
    const schema2 = getDatasourceSchema({
      API,
      datasource: get_store_value(datasource),
      definition: $definition ?? void 0
    });
    if (!schema2) {
      return null;
    }
    Object.keys(schema2).forEach((key) => {
      if (typeof schema2[key] !== "object") {
        schema2[key] = { name: key, type: schema2[key] };
      }
    });
    return schema2;
  });
  const enrichedSchema = derived(
    [schema, schemaOverrides, schemaMutations, subSchemaMutations],
    ([$schema, $schemaOverrides, $schemaMutations, $subSchemaMutations]) => {
      if (!$schema) {
        return null;
      }
      const schemaWithRelatedColumns = enrichSchemaWithRelColumns($schema);
      const enrichedSchema2 = {};
      Object.keys(schemaWithRelatedColumns || {}).forEach((field) => {
        var _a;
        enrichedSchema2[field] = {
          ...schemaWithRelatedColumns == null ? void 0 : schemaWithRelatedColumns[field],
          ...$schemaOverrides == null ? void 0 : $schemaOverrides[field],
          ...$schemaMutations[field]
        };
        if ($subSchemaMutations[field]) {
          (_a = enrichedSchema2[field]).columns ?? (_a.columns = {});
          for (const fieldName of Object.keys($subSchemaMutations[field])) {
            const mutation = $subSchemaMutations[field][fieldName];
            enrichedSchema2[field].columns[fieldName] = {
              ...enrichedSchema2[field].columns[fieldName],
              ...mutation
            };
          }
        }
      });
      return enrichedSchema2;
    }
  );
  const hasBudibaseIdentifiers = derived(
    [datasource, definition],
    ([$datasource, $definition]) => {
      var _a, _b;
      let type = $datasource == null ? void 0 : $datasource.type;
      if (type === "provider") {
        type = (_b = (_a = $datasource.value) == null ? void 0 : _a.datasource) == null ? void 0 : _b.type;
      }
      if (type === "viewV2" && $definition && "type" in $definition && $definition.type === ViewV2Type.CALCULATION) {
        return false;
      }
      return !!type && ["table", "viewV2", "link"].includes(type);
    }
  );
  return {
    schema,
    enrichedSchema,
    hasBudibaseIdentifiers
  };
};
const createActions$4 = (context) => {
  const {
    API,
    datasource,
    definition,
    config,
    dispatch,
    table,
    viewV2,
    nonPlus,
    schemaMutations,
    subSchemaMutations,
    schema,
    notifications: notifications2
  } = context;
  const getAPI = () => {
    const $datasource = get_store_value(datasource);
    const type = $datasource == null ? void 0 : $datasource.type;
    if (!type) {
      return null;
    }
    switch (type) {
      case "table":
        return table;
      case "viewV2":
        return viewV2;
      default:
        return nonPlus;
    }
  };
  const refreshDefinition = async () => {
    const def = await getDatasourceDefinition({
      API,
      datasource: get_store_value(datasource)
    });
    definition.set(def ?? null);
  };
  const saveDefinition = async (newDefinition) => {
    var _a;
    const originalDefinition = get_store_value(definition);
    definition.set(newDefinition);
    if (get_store_value(config).canSaveSchema) {
      try {
        await ((_a = getAPI()) == null ? void 0 : _a.actions.saveDefinition(newDefinition));
        dispatch("updatedatasource", newDefinition);
      } catch (error) {
        const msg = (error == null ? void 0 : error.message) || error || "Unknown error";
        get_store_value(notifications2).error(`Error saving schema: ${msg}`);
        definition.set(originalDefinition);
      }
    }
  };
  const changePrimaryDisplay = async (column) => {
    let newDefinition = cloneDeep(get_store_value(definition));
    newDefinition.primaryDisplay = column;
    if (newDefinition.schema) {
      if (!newDefinition.schema[column].constraints) {
        newDefinition.schema[column].constraints = {};
      }
      newDefinition.schema[column].constraints.presence = { allowEmpty: false };
      if ("default" in newDefinition.schema[column]) {
        delete newDefinition.schema[column].default;
      }
    }
    return await saveDefinition(newDefinition);
  };
  const addSchemaMutation = (field, mutation) => {
    if (!field || !mutation) {
      return;
    }
    schemaMutations.update(($schemaMutations) => {
      return {
        ...$schemaMutations,
        [field]: {
          ...$schemaMutations[field],
          ...mutation
        }
      };
    });
  };
  const addSubSchemaMutation = (field, fromField, mutation) => {
    if (!field || !fromField || !mutation) {
      return;
    }
    subSchemaMutations.update(($subSchemaMutations) => {
      return {
        ...$subSchemaMutations,
        [fromField]: {
          ...$subSchemaMutations[fromField],
          [field]: {
            ...($subSchemaMutations[fromField] || {})[field],
            ...mutation
          }
        }
      };
    });
  };
  const saveSchemaMutations = async () => {
    if (!get_store_value(config).canSaveSchema) {
      return;
    }
    const $definition = get_store_value(definition);
    const $schemaMutations = get_store_value(schemaMutations);
    const $subSchemaMutations = get_store_value(subSchemaMutations);
    const $schema = get_store_value(schema) || {};
    let newSchema = {};
    Object.keys($schema).forEach((column) => {
      var _a;
      newSchema[column] = {
        ...$schema[column],
        ...$schemaMutations[column]
      };
      if ($subSchemaMutations[column]) {
        (_a = newSchema[column]).columns ?? (_a.columns = {});
        for (const fieldName of Object.keys($subSchemaMutations[column])) {
          const mutation = $subSchemaMutations[column][fieldName];
          newSchema[column].columns[fieldName] = {
            ...newSchema[column].columns[fieldName],
            ...mutation
          };
        }
      }
    });
    await saveDefinition({
      ...$definition,
      schema: newSchema
    });
    resetSchemaMutations();
  };
  const resetSchemaMutations = () => {
    schemaMutations.set({});
    subSchemaMutations.set({});
  };
  const addRow = async (row) => {
    var _a;
    return await ((_a = getAPI()) == null ? void 0 : _a.actions.addRow(row));
  };
  const updateRow = async (row) => {
    var _a;
    return await ((_a = getAPI()) == null ? void 0 : _a.actions.updateRow(row));
  };
  const deleteRows = async (rows) => {
    var _a;
    return await ((_a = getAPI()) == null ? void 0 : _a.actions.deleteRows(rows));
  };
  const getRow = async (id) => {
    var _a;
    return await ((_a = getAPI()) == null ? void 0 : _a.actions.getRow(id));
  };
  const isDatasourceValid = (datasource2) => {
    var _a;
    return (_a = getAPI()) == null ? void 0 : _a.actions.isDatasourceValid(datasource2);
  };
  const canUseColumn = (name) => {
    var _a;
    return (_a = getAPI()) == null ? void 0 : _a.actions.canUseColumn(name);
  };
  return {
    datasource: {
      ...datasource,
      actions: {
        refreshDefinition,
        saveDefinition,
        addRow,
        updateRow,
        deleteRows,
        getRow,
        isDatasourceValid,
        canUseColumn,
        changePrimaryDisplay,
        addSchemaMutation,
        addSubSchemaMutation,
        saveSchemaMutations,
        resetSchemaMutations
      }
    }
  };
};
const Datasource = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$4,
  createStores,
  deriveStores
}, Symbol.toStringTag, { value: "Module" }));
const SuppressErrors$1 = true;
const createActions$3 = (context) => {
  const { API, datasource, columns } = context;
  const saveDefinition = async (newDefinition) => {
    await API.saveTable(newDefinition);
  };
  const saveRow = async (row) => {
    var _a;
    row = {
      ...row,
      tableId: (_a = get_store_value(datasource)) == null ? void 0 : _a.tableId
    };
    const newRow = await API.saveRow(row, SuppressErrors$1);
    return { ...newRow, _id: newRow._id };
  };
  const deleteRows = async (rows) => {
    await API.deleteRows(get_store_value(datasource).tableId, rows);
  };
  const isDatasourceValid = (datasource2) => {
    return (datasource2 == null ? void 0 : datasource2.type) === "table" && !!(datasource2 == null ? void 0 : datasource2.tableId);
  };
  const getRow = async (id) => {
    var _a;
    const res = await API.searchTable(get_store_value(datasource).tableId, {
      limit: 1,
      query: {
        equal: {
          _id: id
        }
      },
      paginate: false
    });
    const row = (_a = res == null ? void 0 : res.rows) == null ? void 0 : _a[0];
    if (!row) {
      return;
    }
    return { ...row, _id: row._id };
  };
  const canUseColumn = (name) => {
    return get_store_value(columns).some((col) => col.name === name);
  };
  return {
    table: {
      actions: {
        saveDefinition,
        addRow: saveRow,
        updateRow: saveRow,
        deleteRows,
        getRow,
        isDatasourceValid,
        canUseColumn
      }
    }
  };
};
const initialise$3 = (context) => {
  const {
    datasource,
    fetch,
    filter,
    inlineFilters,
    allFilters,
    sort,
    table,
    initialFilter,
    initialSortColumn,
    initialSortOrder
  } = context;
  let unsubscribers = [];
  datasource.subscribe(($datasource) => {
    unsubscribers == null ? void 0 : unsubscribers.forEach((unsubscribe) => unsubscribe());
    unsubscribers = [];
    if (!table.actions.isDatasourceValid($datasource)) {
      return;
    }
    filter.set(get_store_value(initialFilter) ?? void 0);
    inlineFilters.set([]);
    sort.set({
      column: get_store_value(initialSortColumn),
      order: get_store_value(initialSortOrder) || SortOrder.ASCENDING
    });
    unsubscribers.push(
      allFilters.subscribe(($allFilters) => {
        var _a, _b;
        const $fetch = get_store_value(fetch);
        if (((_b = (_a = $fetch == null ? void 0 : $fetch.options) == null ? void 0 : _a.datasource) == null ? void 0 : _b.tableId) !== $datasource.tableId) {
          return;
        }
        $fetch.update({
          filter: $allFilters
        });
      })
    );
    unsubscribers.push(
      sort.subscribe(($sort) => {
        var _a, _b;
        const $fetch = get_store_value(fetch);
        if (((_b = (_a = $fetch == null ? void 0 : $fetch.options) == null ? void 0 : _a.datasource) == null ? void 0 : _b.tableId) !== $datasource.tableId) {
          return;
        }
        $fetch.update({
          sortOrder: $sort.order || SortOrder.ASCENDING,
          sortColumn: $sort.column ?? void 0
        });
      })
    );
  });
};
const Table = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$3,
  initialise: initialise$3
}, Symbol.toStringTag, { value: "Module" }));
const SuppressErrors = true;
const createActions$2 = (context) => {
  const { API, datasource, columns } = context;
  const saveDefinition = async (newDefinition) => {
    await API.viewV2.update(newDefinition);
  };
  const saveRow = async (row) => {
    const $datasource = get_store_value(datasource);
    row = {
      ...row,
      tableId: $datasource == null ? void 0 : $datasource.tableId,
      _viewId: $datasource == null ? void 0 : $datasource.id
    };
    const newRow = await API.saveRow(row, SuppressErrors);
    return {
      ...newRow,
      _id: newRow._id,
      _viewId: row._viewId
    };
  };
  const deleteRows = async (rows) => {
    await API.deleteRows(get_store_value(datasource).id, rows);
  };
  const getRow = async (id) => {
    var _a;
    const res = await API.viewV2.fetch(get_store_value(datasource).id, {
      limit: 1,
      query: {
        equal: {
          _id: id
        }
      },
      paginate: false
    });
    const row = (_a = res == null ? void 0 : res.rows) == null ? void 0 : _a[0];
    if (!row) {
      return;
    }
    return { ...row, _id: row._id };
  };
  const isDatasourceValid = (datasource2) => {
    return (datasource2 == null ? void 0 : datasource2.type) === "viewV2" && !!(datasource2 == null ? void 0 : datasource2.id) && !!(datasource2 == null ? void 0 : datasource2.tableId);
  };
  const canUseColumn = (name) => {
    return get_store_value(columns).some((col) => col.name === name && col.visible);
  };
  return {
    viewV2: {
      actions: {
        saveDefinition,
        addRow: saveRow,
        updateRow: saveRow,
        deleteRows,
        getRow,
        isDatasourceValid,
        canUseColumn
      }
    }
  };
};
const initialise$2 = (context) => {
  const {
    definition,
    datasource,
    sort,
    rows,
    filter,
    inlineFilters,
    allFilters,
    subscribe: subscribe2,
    viewV2,
    initialFilter,
    initialSortColumn,
    initialSortOrder,
    config,
    fetch
  } = context;
  let unsubscribers = [];
  datasource.subscribe(($datasource) => {
    unsubscribers == null ? void 0 : unsubscribers.forEach((unsubscribe) => unsubscribe());
    unsubscribers = [];
    if (!viewV2.actions.isDatasourceValid($datasource)) {
      return;
    }
    filter.set(get_store_value(initialFilter) ?? void 0);
    inlineFilters.set([]);
    sort.set({
      column: get_store_value(initialSortColumn),
      order: get_store_value(initialSortOrder) || SortOrder.ASCENDING
    });
    unsubscribers.push(
      definition.subscribe(($definition) => {
        var _a, _b;
        if (!get_store_value(config).canSaveSchema) {
          return;
        }
        if (!$definition || !("id" in $definition)) {
          return;
        }
        if (($definition == null ? void 0 : $definition.id) !== $datasource.id) {
          return;
        }
        if (!get_store_value(initialSortColumn)) {
          sort.set({
            column: (_a = $definition.sort) == null ? void 0 : _a.field,
            order: ((_b = $definition.sort) == null ? void 0 : _b.order) || SortOrder.ASCENDING
          });
        }
        if (!get_store_value(initialFilter)) {
          filter.set($definition.queryUI);
        }
      })
    );
    function sortHasChanged(newSort, existingSort) {
      const newColumn = newSort.column ?? null;
      const existingColumn = (existingSort == null ? void 0 : existingSort.field) ?? null;
      if (newColumn !== existingColumn) {
        return true;
      }
      if (!newColumn) {
        return false;
      }
      const newOrder = newSort.order ?? null;
      const existingOrder = (existingSort == null ? void 0 : existingSort.order) ?? null;
      if (newOrder !== existingOrder) {
        return true;
      }
      return false;
    }
    unsubscribers.push(
      sort.subscribe(async ($sort) => {
        var _a, _b;
        const $view = get_store_value(definition);
        if (!$view || !("id" in $view)) {
          return;
        }
        if (($view == null ? void 0 : $view.id) !== $datasource.id) {
          return;
        }
        if (!sortHasChanged($sort, $view.sort)) {
          return;
        }
        if (get_store_value(config).canSaveSchema) {
          await datasource.actions.saveDefinition({
            ...$view,
            sort: {
              field: $sort.column,
              order: $sort.order || SortOrder.ASCENDING
            }
          });
        }
        const $fetch = get_store_value(fetch);
        if (((_b = (_a = $fetch == null ? void 0 : $fetch.options) == null ? void 0 : _a.datasource) == null ? void 0 : _b.id) !== $datasource.id) {
          return;
        }
        $fetch.update({
          sortOrder: $sort.order,
          sortColumn: $sort.column ?? void 0
        });
      })
    );
    unsubscribers == null ? void 0 : unsubscribers.push(
      filter.subscribe(async ($filter) => {
        if (!get_store_value(config).canSaveSchema) {
          return;
        }
        const $view = get_store_value(definition);
        if (!$view || !("id" in $view)) {
          return;
        }
        if (($view == null ? void 0 : $view.id) !== $datasource.id) {
          return;
        }
        if (JSON.stringify($filter) !== JSON.stringify($view.queryUI)) {
          await datasource.actions.saveDefinition({
            ...$view,
            queryUI: $filter
          });
          await rows.actions.refreshData();
        }
      })
    );
    unsubscribers.push(
      inlineFilters.subscribe(($inlineFilters) => {
        var _a, _b;
        if (!get_store_value(config).canSaveSchema) {
          return;
        }
        const $fetch = get_store_value(fetch);
        if (((_b = (_a = $fetch == null ? void 0 : $fetch.options) == null ? void 0 : _a.datasource) == null ? void 0 : _b.id) !== $datasource.id) {
          return;
        }
        $fetch.update({
          filter: $inlineFilters
        });
      })
    );
    unsubscribers.push(
      allFilters.subscribe(($allFilters) => {
        var _a, _b;
        if (get_store_value(config).canSaveSchema) {
          return;
        }
        const $fetch = get_store_value(fetch);
        if (((_b = (_a = $fetch == null ? void 0 : $fetch.options) == null ? void 0 : _a.datasource) == null ? void 0 : _b.id) !== $datasource.id) {
          return;
        }
        $fetch.update({
          filter: $allFilters
        });
      })
    );
    unsubscribers.push(
      subscribe2("show-column", async () => {
        await rows.actions.refreshData();
      })
    );
  });
};
const ViewV2 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$2,
  initialise: initialise$2
}, Symbol.toStringTag, { value: "Module" }));
const createActions$1 = (context) => {
  const { columns, table, viewV2 } = context;
  const saveDefinition = async () => {
    throw "This datasource does not support updating the definition";
  };
  const saveRow = async () => {
    throw "This datasource does not support saving rows";
  };
  const deleteRows = async () => {
    throw "This datasource does not support deleting rows";
  };
  const getRow = () => {
    throw "This datasource does not support fetching individual rows";
  };
  const isDatasourceValid = (datasource) => {
    return !table.actions.isDatasourceValid(datasource) && !viewV2.actions.isDatasourceValid(datasource) && (datasource == null ? void 0 : datasource.type) != null;
  };
  const canUseColumn = (name) => {
    return get_store_value(columns).some((col) => col.name === name);
  };
  return {
    nonPlus: {
      actions: {
        saveDefinition,
        addRow: saveRow,
        updateRow: saveRow,
        deleteRows,
        getRow,
        isDatasourceValid,
        canUseColumn
      }
    }
  };
};
const isSameDatasource = (a, b) => {
  return JSON.stringify(a) === JSON.stringify(b);
};
const initialise$1 = (context) => {
  const {
    datasource,
    sort,
    filter,
    inlineFilters,
    allFilters,
    nonPlus,
    initialFilter,
    initialSortColumn,
    initialSortOrder,
    fetch
  } = context;
  let unsubscribers = [];
  datasource.subscribe(($datasource) => {
    unsubscribers == null ? void 0 : unsubscribers.forEach((unsubscribe) => unsubscribe());
    unsubscribers = [];
    if (!nonPlus.actions.isDatasourceValid($datasource)) {
      return;
    }
    filter.set(get_store_value(initialFilter) ?? void 0);
    inlineFilters.set([]);
    sort.set({
      column: get_store_value(initialSortColumn),
      order: get_store_value(initialSortOrder) || SortOrder.ASCENDING
    });
    unsubscribers.push(
      allFilters.subscribe(($allFilters) => {
        var _a;
        const $fetch = get_store_value(fetch);
        if (!isSameDatasource((_a = $fetch == null ? void 0 : $fetch.options) == null ? void 0 : _a.datasource, $datasource)) {
          return;
        }
        $fetch == null ? void 0 : $fetch.update({
          filter: $allFilters
        });
      })
    );
    unsubscribers.push(
      sort.subscribe(($sort) => {
        var _a;
        const $fetch = get_store_value(fetch);
        if (!isSameDatasource((_a = $fetch == null ? void 0 : $fetch.options) == null ? void 0 : _a.datasource, $datasource)) {
          return;
        }
        $fetch == null ? void 0 : $fetch.update({
          sortOrder: $sort.order || SortOrder.ASCENDING,
          sortColumn: $sort.column ?? void 0
        });
      })
    );
  });
};
const NonPlus = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: createActions$1,
  initialise: initialise$1
}, Symbol.toStringTag, { value: "Module" }));
const createActions = (context) => {
  const { API } = context;
  let tableCache = {};
  const resetCache = () => {
    tableCache = {};
  };
  const fetchTable = async (tableId) => {
    if (!tableCache[tableId]) {
      tableCache[tableId] = API.fetchTableDefinition(tableId);
    }
    return await tableCache[tableId];
  };
  const getPrimaryDisplayForTableId = async (tableId) => {
    var _a, _b;
    const table = await fetchTable(tableId);
    const display = (table == null ? void 0 : table.primaryDisplay) || ((_b = (_a = table == null ? void 0 : table.schema) == null ? void 0 : _a[0]) == null ? void 0 : _b.name);
    return display;
  };
  const getTable = async (tableId) => {
    const table = await fetchTable(tableId);
    return table;
  };
  return {
    cache: {
      actions: {
        getPrimaryDisplayForTableId,
        getTable,
        resetCache
      }
    }
  };
};
const initialise = (context) => {
  const { datasource, cache } = context;
  datasource.subscribe(cache.actions.resetCache);
};
const Cache = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions,
  initialise
}, Symbol.toStringTag, { value: "Module" }));
const DependencyOrderedStores = [
  Sort,
  Filter,
  Bounds,
  Table,
  ViewV2,
  NonPlus,
  Datasource,
  Columns,
  Config,
  Scroll,
  Validation,
  Rows,
  Conditions,
  UI,
  Resize,
  Viewport,
  Reorder,
  Users,
  Menu,
  Pagination,
  Clipboard,
  Notifications,
  Cache
];
const attachStores = (context) => {
  var _a, _b, _c, _d;
  for (let store of DependencyOrderedStores) {
    if ("createStores" in store) {
      context = { ...context, ...(_a = store.createStores) == null ? void 0 : _a.call(store, context) };
    }
  }
  for (let store of DependencyOrderedStores) {
    if ("deriveStores" in store) {
      context = { ...context, ...(_b = store.deriveStores) == null ? void 0 : _b.call(store, context) };
    }
  }
  for (let store of DependencyOrderedStores) {
    if ("createActions" in store) {
      context = { ...context, ...(_c = store.createActions) == null ? void 0 : _c.call(store, context) };
    }
  }
  for (let store of DependencyOrderedStores) {
    if ("initialise" in store) {
      (_d = store.initialise) == null ? void 0 : _d.call(store, context);
    }
  }
  return context;
};
function create_if_block_1$a(ctx) {
  let progressbar;
  let current;
  progressbar = new ProgressBar({
    props: {
      size: "L",
      value: (
        /*progressPercentage*/
        ctx[3]
      ),
      duration: duration$2,
      width: "100%"
    }
  });
  return {
    c() {
      create_component(progressbar.$$.fragment);
    },
    m(target, anchor) {
      mount_component(progressbar, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const progressbar_changes = {};
      if (dirty & /*progressPercentage*/
      8)
        progressbar_changes.value = /*progressPercentage*/
        ctx2[3];
      progressbar.$set(progressbar_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(progressbar.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(progressbar.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(progressbar, detaching);
    }
  };
}
function create_default_slot_3$5(ctx) {
  let t0;
  let t1;
  let t2;
  let if_block_anchor;
  let current;
  let if_block = (
    /*processing*/
    ctx[2] && create_if_block_1$a(ctx)
  );
  return {
    c() {
      t0 = text("Are you sure you want to delete ");
      t1 = text(
        /*promptQuantity*/
        ctx[4]
      );
      t2 = text(" rows?\n    ");
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      insert(target, t2, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (!current || dirty & /*promptQuantity*/
      16)
        set_data(
          t1,
          /*promptQuantity*/
          ctx2[4]
        );
      if (
        /*processing*/
        ctx2[2]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*processing*/
          4) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_1$a(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_default_slot_2$6(ctx) {
  let modalcontent;
  let current;
  modalcontent = new ModalContent({
    props: {
      title: "Delete rows",
      confirmText: "Continue",
      cancelText: "Cancel",
      onConfirm: (
        /*bulkDeleteRows*/
        ctx[12]
      ),
      size: "M",
      $$slots: { default: [create_default_slot_3$5] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(modalcontent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(modalcontent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const modalcontent_changes = {};
      if (dirty & /*$$scope, progressPercentage, processing, promptQuantity*/
      268435484) {
        modalcontent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modalcontent.$set(modalcontent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(modalcontent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(modalcontent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(modalcontent, detaching);
    }
  };
}
function create_if_block$h(ctx) {
  let progressbar;
  let current;
  progressbar = new ProgressBar({
    props: {
      size: "L",
      value: (
        /*progressPercentage*/
        ctx[3]
      ),
      duration: duration$2,
      width: "100%"
    }
  });
  return {
    c() {
      create_component(progressbar.$$.fragment);
    },
    m(target, anchor) {
      mount_component(progressbar, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const progressbar_changes = {};
      if (dirty & /*progressPercentage*/
      8)
        progressbar_changes.value = /*progressPercentage*/
        ctx2[3];
      progressbar.$set(progressbar_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(progressbar.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(progressbar.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(progressbar, detaching);
    }
  };
}
function create_default_slot_1$8(ctx) {
  let t0;
  let t1;
  let t2;
  let if_block_anchor;
  let current;
  let if_block = (
    /*processing*/
    ctx[2] && create_if_block$h(ctx)
  );
  return {
    c() {
      t0 = text("Are you sure you want to delete ");
      t1 = text(
        /*promptQuantity*/
        ctx[4]
      );
      t2 = text(" cells?\n    ");
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      insert(target, t2, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (!current || dirty & /*promptQuantity*/
      16)
        set_data(
          t1,
          /*promptQuantity*/
          ctx2[4]
        );
      if (
        /*processing*/
        ctx2[2]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*processing*/
          4) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$h(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_default_slot$e(ctx) {
  let modalcontent;
  let current;
  modalcontent = new ModalContent({
    props: {
      title: "Delete cells",
      confirmText: "Continue",
      cancelText: "Cancel",
      onConfirm: (
        /*bulkDeleteCells*/
        ctx[13]
      ),
      size: "M",
      $$slots: { default: [create_default_slot_1$8] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(modalcontent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(modalcontent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const modalcontent_changes = {};
      if (dirty & /*$$scope, progressPercentage, processing, promptQuantity*/
      268435484) {
        modalcontent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modalcontent.$set(modalcontent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(modalcontent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(modalcontent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(modalcontent, detaching);
    }
  };
}
function create_fragment$o(ctx) {
  let modal0;
  let t;
  let modal1;
  let current;
  let modal0_props = {
    $$slots: { default: [create_default_slot_2$6] },
    $$scope: { ctx }
  };
  modal0 = new Modal({ props: modal0_props });
  ctx[16](modal0);
  let modal1_props = {
    $$slots: { default: [create_default_slot$e] },
    $$scope: { ctx }
  };
  modal1 = new Modal({ props: modal1_props });
  ctx[17](modal1);
  return {
    c() {
      create_component(modal0.$$.fragment);
      t = space();
      create_component(modal1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(modal0, target, anchor);
      insert(target, t, anchor);
      mount_component(modal1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const modal0_changes = {};
      if (dirty & /*$$scope, progressPercentage, processing, promptQuantity*/
      268435484) {
        modal0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modal0.$set(modal0_changes);
      const modal1_changes = {};
      if (dirty & /*$$scope, progressPercentage, processing, promptQuantity*/
      268435484) {
        modal1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modal1.$set(modal1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(modal0.$$.fragment, local);
      transition_in(modal1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(modal0.$$.fragment, local);
      transition_out(modal1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      ctx[16](null);
      destroy_component(modal0, detaching);
      ctx[17](null);
      destroy_component(modal1, detaching);
    }
  };
}
const duration$2 = 260;
function instance$o($$self, $$props, $$invalidate) {
  let rowsToDelete;
  let $selectedCells;
  let $notifications;
  let $selectedCellCount;
  let $config;
  let $selectedRowCount;
  let $rowLookupMap;
  let $selectedRows;
  const { selectedRows, rows, subscribe: subscribe2, notifications: notifications2, menu, selectedCellCount, selectedRowCount, selectedCells, rowLookupMap, config } = getContext("grid");
  component_subscribe($$self, selectedRows, (value) => $$invalidate(15, $selectedRows = value));
  component_subscribe($$self, notifications2, (value) => $$invalidate(20, $notifications = value));
  component_subscribe($$self, selectedCellCount, (value) => $$invalidate(21, $selectedCellCount = value));
  component_subscribe($$self, selectedRowCount, (value) => $$invalidate(23, $selectedRowCount = value));
  component_subscribe($$self, selectedCells, (value) => $$invalidate(19, $selectedCells = value));
  component_subscribe($$self, rowLookupMap, (value) => $$invalidate(14, $rowLookupMap = value));
  component_subscribe($$self, config, (value) => $$invalidate(22, $config = value));
  let rowsModal;
  let cellsModal;
  let processing = false;
  let progressPercentage = 0;
  let promptQuantity = 0;
  const handleBulkDeleteRequest = () => {
    $$invalidate(3, progressPercentage = 0);
    menu.actions.close();
    if ($selectedRowCount && $config.canDeleteRows) {
      if ($selectedRowCount === 1) {
        bulkDeleteRows();
      } else {
        $$invalidate(4, promptQuantity = $selectedRowCount);
        rowsModal == null ? void 0 : rowsModal.show();
      }
    } else if ($selectedCellCount && $config.canEditRows) {
      $$invalidate(4, promptQuantity = $selectedCellCount);
      cellsModal == null ? void 0 : cellsModal.show();
    }
  };
  const bulkDeleteRows = async () => {
    $$invalidate(2, processing = true);
    const count = rowsToDelete.length;
    await rows.actions.deleteRows(rowsToDelete);
    $$invalidate(3, progressPercentage = 100);
    await sleep(duration$2);
    $notifications.success(`Deleted ${count} row${count === 1 ? "" : "s"}`);
    $$invalidate(2, processing = false);
  };
  const bulkDeleteCells = async () => {
    $$invalidate(2, processing = true);
    let changeMap = {};
    for (let row of $selectedCells) {
      for (let cellId of row) {
        const { rowId, field } = parseCellID(cellId);
        if (!changeMap[rowId]) {
          changeMap[rowId] = {};
        }
        changeMap[rowId][field] = null;
      }
    }
    await rows.actions.bulkUpdate(changeMap, (progress) => {
      $$invalidate(3, progressPercentage = progress * 100);
    });
    await sleep(duration$2);
    $$invalidate(2, processing = false);
  };
  onMount(() => subscribe2("request-bulk-delete", handleBulkDeleteRequest));
  function modal0_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      rowsModal = $$value;
      $$invalidate(0, rowsModal);
    });
  }
  function modal1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      cellsModal = $$value;
      $$invalidate(1, cellsModal);
    });
  }
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$selectedRows, $rowLookupMap*/
    49152) {
      rowsToDelete = Object.keys($selectedRows).map((rowId) => $rowLookupMap[rowId]).filter((x) => x != null);
    }
  };
  return [
    rowsModal,
    cellsModal,
    processing,
    progressPercentage,
    promptQuantity,
    selectedRows,
    notifications2,
    selectedCellCount,
    selectedRowCount,
    selectedCells,
    rowLookupMap,
    config,
    bulkDeleteRows,
    bulkDeleteCells,
    $rowLookupMap,
    $selectedRows,
    modal0_binding,
    modal1_binding
  ];
}
class BulkDeleteHandler extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$o, create_fragment$o, safe_not_equal, {});
  }
}
function create_if_block$g(ctx) {
  let progressbar;
  let current;
  progressbar = new ProgressBar({
    props: {
      size: "L",
      value: (
        /*progressPercentage*/
        ctx[1]
      ),
      duration: duration$1,
      width: "100%"
    }
  });
  return {
    c() {
      create_component(progressbar.$$.fragment);
    },
    m(target, anchor) {
      mount_component(progressbar, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const progressbar_changes = {};
      if (dirty & /*progressPercentage*/
      2)
        progressbar_changes.value = /*progressPercentage*/
        ctx2[1];
      progressbar.$set(progressbar_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(progressbar.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(progressbar.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(progressbar, detaching);
    }
  };
}
function create_default_slot_1$7(ctx) {
  let t0;
  let t1;
  let t2;
  let if_block_anchor;
  let current;
  let if_block = (
    /*processing*/
    ctx[2] && create_if_block$g(ctx)
  );
  return {
    c() {
      t0 = text("Are you sure you want to duplicate ");
      t1 = text(
        /*promptQuantity*/
        ctx[3]
      );
      t2 = text(" rows?\n    ");
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      insert(target, t2, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (!current || dirty & /*promptQuantity*/
      8)
        set_data(
          t1,
          /*promptQuantity*/
          ctx2[3]
        );
      if (
        /*processing*/
        ctx2[2]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*processing*/
          4) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$g(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_default_slot$d(ctx) {
  let modalcontent;
  let current;
  modalcontent = new ModalContent({
    props: {
      title: "Duplicate rows",
      confirmText: "Continue",
      cancelText: "Cancel",
      onConfirm: (
        /*performDuplication*/
        ctx[8]
      ),
      size: "M",
      $$slots: { default: [create_default_slot_1$7] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(modalcontent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(modalcontent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const modalcontent_changes = {};
      if (dirty & /*$$scope, progressPercentage, processing, promptQuantity*/
      262158) {
        modalcontent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modalcontent.$set(modalcontent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(modalcontent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(modalcontent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(modalcontent, detaching);
    }
  };
}
function create_fragment$n(ctx) {
  let modal_1;
  let current;
  let modal_1_props = {
    $$slots: { default: [create_default_slot$d] },
    $$scope: { ctx }
  };
  modal_1 = new Modal({ props: modal_1_props });
  ctx[9](modal_1);
  return {
    c() {
      create_component(modal_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(modal_1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const modal_1_changes = {};
      if (dirty & /*$$scope, progressPercentage, processing, promptQuantity*/
      262158) {
        modal_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modal_1.$set(modal_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(modal_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(modal_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      ctx[9](null);
      destroy_component(modal_1, detaching);
    }
  };
}
const duration$1 = 260;
function instance$n($$self, $$props, $$invalidate) {
  let $selectedRowCount;
  let $visibleColumns;
  let $rowLookupMap;
  let $selectedRows;
  const { selectedRows, rows, subscribe: subscribe2, selectedRowCount, visibleColumns, selectedCells, rowLookupMap } = getContext("grid");
  component_subscribe($$self, selectedRows, (value) => $$invalidate(13, $selectedRows = value));
  component_subscribe($$self, selectedRowCount, (value) => $$invalidate(10, $selectedRowCount = value));
  component_subscribe($$self, visibleColumns, (value) => $$invalidate(11, $visibleColumns = value));
  component_subscribe($$self, rowLookupMap, (value) => $$invalidate(12, $rowLookupMap = value));
  let modal;
  let progressPercentage = 0;
  let processing = false;
  let promptQuantity = 0;
  const performDuplication = async () => {
    $$invalidate(1, progressPercentage = 0);
    $$invalidate(2, processing = true);
    const rowsToDuplicate = Object.keys($selectedRows).map((id) => {
      return $rowLookupMap[id];
    });
    const newRows = await rows.actions.bulkDuplicate(rowsToDuplicate, (progress) => {
      $$invalidate(1, progressPercentage = progress * 100);
    });
    await sleep(duration$1);
    if (newRows.length) {
      const firstRow = newRows[0];
      const lastRow = newRows[newRows.length - 1];
      const firstCol = $visibleColumns[0];
      const lastCol = $visibleColumns[$visibleColumns.length - 1];
      const startCellId = getCellID(firstRow._id, firstCol.name);
      const endCellId = getCellID(lastRow._id, lastCol.name);
      selectedCells.actions.selectRange(startCellId, endCellId);
    }
    $$invalidate(2, processing = false);
  };
  const handleBulkDuplicateRequest = () => {
    $$invalidate(3, promptQuantity = $selectedRowCount);
    modal == null ? void 0 : modal.show();
  };
  onMount(() => subscribe2("request-bulk-duplicate", handleBulkDuplicateRequest));
  function modal_1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      modal = $$value;
      $$invalidate(0, modal);
    });
  }
  return [
    modal,
    progressPercentage,
    processing,
    promptQuantity,
    selectedRows,
    selectedRowCount,
    visibleColumns,
    rowLookupMap,
    performDuplication,
    modal_1_binding
  ];
}
class BulkDuplicationHandler extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$n, create_fragment$n, safe_not_equal, {});
  }
}
function create_if_block$f(ctx) {
  let progressbar;
  let current;
  progressbar = new ProgressBar({
    props: {
      size: "L",
      value: (
        /*progressPercentage*/
        ctx[1]
      ),
      duration,
      width: "100%"
    }
  });
  return {
    c() {
      create_component(progressbar.$$.fragment);
    },
    m(target, anchor) {
      mount_component(progressbar, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const progressbar_changes = {};
      if (dirty & /*progressPercentage*/
      2)
        progressbar_changes.value = /*progressPercentage*/
        ctx2[1];
      progressbar.$set(progressbar_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(progressbar.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(progressbar.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(progressbar, detaching);
    }
  };
}
function create_default_slot_1$6(ctx) {
  let t;
  let if_block_anchor;
  let current;
  let if_block = (
    /*processing*/
    ctx[2] && create_if_block$f(ctx)
  );
  return {
    c() {
      t = text("Are you sure you want to paste? This will update multiple values.\n    ");
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*processing*/
        ctx2[2]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*processing*/
          4) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$f(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_default_slot$c(ctx) {
  let modalcontent;
  let current;
  modalcontent = new ModalContent({
    props: {
      title: "Confirm paste",
      confirmText: "Continue",
      cancelText: "Cancel",
      onConfirm: (
        /*performBulkPaste*/
        ctx[7]
      ),
      size: "M",
      $$slots: { default: [create_default_slot_1$6] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(modalcontent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(modalcontent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const modalcontent_changes = {};
      if (dirty & /*$$scope, progressPercentage, processing*/
      131078) {
        modalcontent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modalcontent.$set(modalcontent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(modalcontent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(modalcontent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(modalcontent, detaching);
    }
  };
}
function create_fragment$m(ctx) {
  let modal_1;
  let current;
  let modal_1_props = {
    $$slots: { default: [create_default_slot$c] },
    $$scope: { ctx }
  };
  modal_1 = new Modal({ props: modal_1_props });
  ctx[8](modal_1);
  return {
    c() {
      create_component(modal_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(modal_1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const modal_1_changes = {};
      if (dirty & /*$$scope, progressPercentage, processing*/
      131078) {
        modal_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modal_1.$set(modal_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(modal_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(modal_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      ctx[8](null);
      destroy_component(modal_1, detaching);
    }
  };
}
const duration = 260;
function instance$m($$self, $$props, $$invalidate) {
  let $clipboard;
  let $selectedCellCount;
  let $pasteAllowed;
  let $copyAllowed;
  const { clipboard, subscribe: subscribe2, copyAllowed, pasteAllowed, selectedCellCount, focusedCellAPI } = getContext("grid");
  component_subscribe($$self, clipboard, (value) => $$invalidate(9, $clipboard = value));
  component_subscribe($$self, copyAllowed, (value) => $$invalidate(12, $copyAllowed = value));
  component_subscribe($$self, pasteAllowed, (value) => $$invalidate(11, $pasteAllowed = value));
  component_subscribe($$self, selectedCellCount, (value) => $$invalidate(10, $selectedCellCount = value));
  let modal;
  let progressPercentage = 0;
  let processing = false;
  const handleCopyRequest = () => {
    if (!$copyAllowed) {
      return;
    }
    clipboard.actions.copy();
  };
  const handlePasteRequest = async () => {
    var _a;
    if ((_a = get_store_value(focusedCellAPI)) == null ? void 0 : _a.isActive()) {
      return;
    }
    $$invalidate(1, progressPercentage = 0);
    if (!$pasteAllowed) {
      return;
    }
    const multiCellPaste = $selectedCellCount > 1;
    const prompt = $clipboard.multiCellCopy || multiCellPaste;
    if (prompt) {
      modal == null ? void 0 : modal.show();
    } else {
      clipboard.actions.paste();
    }
  };
  const performBulkPaste = async () => {
    $$invalidate(2, processing = true);
    await clipboard.actions.paste((progress) => {
      $$invalidate(1, progressPercentage = progress * 100);
    });
    await sleep(duration);
    $$invalidate(2, processing = false);
  };
  onMount(() => subscribe2("copy", handleCopyRequest));
  onMount(() => subscribe2("paste", handlePasteRequest));
  function modal_1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      modal = $$value;
      $$invalidate(0, modal);
    });
  }
  return [
    modal,
    progressPercentage,
    processing,
    clipboard,
    copyAllowed,
    pasteAllowed,
    selectedCellCount,
    performBulkPaste,
    modal_1_binding
  ];
}
class ClipboardHandler extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$m, create_fragment$m, safe_not_equal, {});
  }
}
function create_fragment$l(ctx) {
  let div1;
  let div0;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[23].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[22],
    null
  );
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      if (default_slot)
        default_slot.c();
      attr(
        div0,
        "style",
        /*style*/
        ctx[2]
      );
      attr(div0, "class", "inner svelte-i68dpr");
      attr(div1, "class", "outer svelte-i68dpr");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      if (default_slot) {
        default_slot.m(div0, null);
      }
      ctx[24](div0);
      current = true;
      if (!mounted) {
        dispose = [
          listen(div1, "wheel", function() {
            if (is_function(
              /*attachHandlers*/
              ctx[1] ? (
                /*handleWheel*/
                ctx[14]
              ) : null
            ))
              /*attachHandlers*/
              (ctx[1] ? (
                /*handleWheel*/
                ctx[14]
              ) : null).apply(this, arguments);
          }),
          listen(div1, "touchstart", function() {
            if (is_function(
              /*attachHandlers*/
              ctx[1] ? (
                /*handleTouchStart*/
                ctx[15]
              ) : null
            ))
              /*attachHandlers*/
              (ctx[1] ? (
                /*handleTouchStart*/
                ctx[15]
              ) : null).apply(this, arguments);
          }),
          listen(div1, "touchmove", function() {
            if (is_function(
              /*attachHandlers*/
              ctx[1] ? (
                /*handleTouchMove*/
                ctx[16]
              ) : null
            ))
              /*attachHandlers*/
              (ctx[1] ? (
                /*handleTouchMove*/
                ctx[16]
              ) : null).apply(this, arguments);
          }),
          listen(div1, "click", self(
            /*ui*/
            ctx[5].actions.blur
          ))
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (default_slot) {
        if (default_slot.p && (!current || dirty[0] & /*$$scope*/
        4194304)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx,
            /*$$scope*/
            ctx[22],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx[22]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx[22],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty[0] & /*style*/
      4) {
        attr(
          div0,
          "style",
          /*style*/
          ctx[2]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if (default_slot)
        default_slot.d(detaching);
      ctx[24](null);
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance$l($$self, $$props, $$invalidate) {
  let style;
  let $rowHeight;
  let $renderedRows;
  let $bounds;
  let $maxScrollLeft;
  let $maxScrollTop;
  let $scroll;
  let $menu;
  let $focusedCellAPI;
  let $scrollTop;
  let $scrollLeft;
  let { $$slots: slots = {}, $$scope } = $$props;
  const { rowHeight, scroll, ui, renderedRows, maxScrollTop, maxScrollLeft, bounds, hoveredRowId, menu, focusedCellAPI, scrollTop, scrollLeft } = getContext("grid");
  component_subscribe($$self, rowHeight, (value) => $$invalidate(19, $rowHeight = value));
  component_subscribe($$self, scroll, (value) => $$invalidate(31, $scroll = value));
  component_subscribe($$self, renderedRows, (value) => $$invalidate(27, $renderedRows = value));
  component_subscribe($$self, maxScrollTop, (value) => $$invalidate(30, $maxScrollTop = value));
  component_subscribe($$self, maxScrollLeft, (value) => $$invalidate(29, $maxScrollLeft = value));
  component_subscribe($$self, bounds, (value) => $$invalidate(28, $bounds = value));
  component_subscribe($$self, menu, (value) => $$invalidate(32, $menu = value));
  component_subscribe($$self, focusedCellAPI, (value) => $$invalidate(33, $focusedCellAPI = value));
  component_subscribe($$self, scrollTop, (value) => $$invalidate(20, $scrollTop = value));
  component_subscribe($$self, scrollLeft, (value) => $$invalidate(21, $scrollLeft = value));
  let { scrollVertically = false } = $$props;
  let { scrollHorizontally = false } = $$props;
  let { attachHandlers = false } = $$props;
  let { ref } = $$props;
  let initialTouchX;
  let initialTouchY;
  const generateStyle = (scrollLeft2, scrollTop2, rowHeight2) => {
    const offsetX = scrollHorizontally ? -1 * scrollLeft2 : 0;
    const offsetY = scrollVertically ? -1 * (scrollTop2 % rowHeight2) : 0;
    return `transform: translate(${offsetX}px, ${offsetY}px);`;
  };
  const handleWheel = (e) => {
    e.preventDefault();
    updateScroll(e.deltaX, e.deltaY, e.clientY);
    $focusedCellAPI == null ? void 0 : $focusedCellAPI.blur();
    if ($menu.visible) {
      menu.actions.close();
    }
  };
  const handleTouchStart = (e) => {
    var _a;
    if (!((_a = e.touches) == null ? void 0 : _a[0]))
      return;
    initialTouchX = e.touches[0].clientX;
    initialTouchY = e.touches[0].clientY;
  };
  const handleTouchMove = (e) => {
    var _a;
    if (!((_a = e.touches) == null ? void 0 : _a[0]))
      return;
    e.preventDefault();
    const deltaX = initialTouchX - e.touches[0].clientX;
    const deltaY = initialTouchY - e.touches[0].clientY;
    updateScroll(deltaX, deltaY);
    initialTouchX = e.touches[0].clientX;
    initialTouchY = e.touches[0].clientY;
    if ($menu.visible) {
      menu.actions.close();
    }
  };
  const updateScroll = domDebounce((deltaX, deltaY, clientY) => {
    const { top, left } = $scroll;
    let newScrollTop = top + deltaY;
    newScrollTop = Math.max(0, Math.min(newScrollTop, $maxScrollTop));
    let newScrollLeft = left + deltaX;
    newScrollLeft = Math.max(0, Math.min(newScrollLeft, $maxScrollLeft));
    scroll.set({
      left: scrollHorizontally ? newScrollLeft : left,
      top: scrollVertically ? newScrollTop : top
    });
    if (clientY != null) {
      const y = clientY - $bounds.top + newScrollTop % $rowHeight;
      const hoveredRow = $renderedRows[Math.floor(y / $rowHeight)];
      hoveredRowId.set(hoveredRow == null ? void 0 : hoveredRow._id);
    }
  });
  function div0_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      ref = $$value;
      $$invalidate(0, ref);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("scrollVertically" in $$props2)
      $$invalidate(17, scrollVertically = $$props2.scrollVertically);
    if ("scrollHorizontally" in $$props2)
      $$invalidate(18, scrollHorizontally = $$props2.scrollHorizontally);
    if ("attachHandlers" in $$props2)
      $$invalidate(1, attachHandlers = $$props2.attachHandlers);
    if ("ref" in $$props2)
      $$invalidate(0, ref = $$props2.ref);
    if ("$$scope" in $$props2)
      $$invalidate(22, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*$scrollLeft, $scrollTop, $rowHeight*/
    3670016) {
      $$invalidate(2, style = generateStyle($scrollLeft, $scrollTop, $rowHeight));
    }
  };
  return [
    ref,
    attachHandlers,
    style,
    rowHeight,
    scroll,
    ui,
    renderedRows,
    maxScrollTop,
    maxScrollLeft,
    bounds,
    menu,
    focusedCellAPI,
    scrollTop,
    scrollLeft,
    handleWheel,
    handleTouchStart,
    handleTouchMove,
    scrollVertically,
    scrollHorizontally,
    $rowHeight,
    $scrollTop,
    $scrollLeft,
    $$scope,
    slots,
    div0_binding
  ];
}
class GridScrollWrapper extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance$l,
      create_fragment$l,
      safe_not_equal,
      {
        scrollVertically: 17,
        scrollHorizontally: 18,
        attachHandlers: 1,
        ref: 0
      },
      null,
      [-1, -1]
    );
  }
}
function create_if_block_1$9(ctx) {
  let div;
  let t;
  return {
    c() {
      div = element("div");
      t = text(
        /*error*/
        ctx[4]
      );
      attr(div, "class", "label svelte-om663h");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*error*/
      16)
        set_data(
          t,
          /*error*/
          ctx2[4]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block$e(ctx) {
  let div;
  let t_value = (
    /*selectedUser*/
    ctx[3].label + ""
  );
  let t;
  return {
    c() {
      div = element("div");
      t = text(t_value);
      attr(div, "class", "label svelte-om663h");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*selectedUser*/
      8 && t_value !== (t_value = /*selectedUser*/
      ctx2[3].label + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_fragment$k(ctx) {
  let div;
  let t0;
  let t1;
  let current;
  let mounted;
  let dispose;
  let if_block0 = (
    /*error*/
    ctx[4] && create_if_block_1$9(ctx)
  );
  const default_slot_template = (
    /*#slots*/
    ctx[15].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[14],
    null
  );
  let if_block1 = (
    /*selectedUser*/
    ctx[3] && !/*focused*/
    ctx[0] && create_if_block$e(ctx)
  );
  return {
    c() {
      div = element("div");
      if (if_block0)
        if_block0.c();
      t0 = space();
      if (default_slot)
        default_slot.c();
      t1 = space();
      if (if_block1)
        if_block1.c();
      attr(div, "class", "cell svelte-om663h");
      attr(
        div,
        "style",
        /*style*/
        ctx[11]
      );
      toggle_class(
        div,
        "selected",
        /*selected*/
        ctx[1]
      );
      toggle_class(
        div,
        "highlighted",
        /*highlighted*/
        ctx[2]
      );
      toggle_class(
        div,
        "focused",
        /*focused*/
        ctx[0]
      );
      toggle_class(
        div,
        "error",
        /*error*/
        ctx[4]
      );
      toggle_class(
        div,
        "center",
        /*center*/
        ctx[8]
      );
      toggle_class(
        div,
        "readonly",
        /*readonly*/
        ctx[9]
      );
      toggle_class(
        div,
        "hidden",
        /*hidden*/
        ctx[10]
      );
      toggle_class(
        div,
        "default-height",
        /*defaultHeight*/
        ctx[7]
      );
      toggle_class(
        div,
        "selected-other",
        /*selectedUser*/
        ctx[3] != null
      );
      toggle_class(
        div,
        "alt",
        /*rowIdx*/
        ctx[5] % 2 === 1
      );
      toggle_class(
        div,
        "top",
        /*topRow*/
        ctx[6]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block0)
        if_block0.m(div, null);
      append(div, t0);
      if (default_slot) {
        default_slot.m(div, null);
      }
      append(div, t1);
      if (if_block1)
        if_block1.m(div, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            div,
            "focus",
            /*focus_handler*/
            ctx[16]
          ),
          listen(
            div,
            "mousedown",
            /*mousedown_handler*/
            ctx[17]
          ),
          listen(
            div,
            "mouseup",
            /*mouseup_handler*/
            ctx[18]
          ),
          listen(
            div,
            "click",
            /*click_handler*/
            ctx[19]
          ),
          listen(
            div,
            "contextmenu",
            /*contextmenu_handler*/
            ctx[20]
          ),
          listen(
            div,
            "touchstart",
            /*touchstart_handler*/
            ctx[21],
            { passive: true }
          ),
          listen(
            div,
            "touchend",
            /*touchend_handler*/
            ctx[22]
          ),
          listen(
            div,
            "touchcancel",
            /*touchcancel_handler*/
            ctx[23]
          ),
          listen(
            div,
            "mouseenter",
            /*mouseenter_handler*/
            ctx[24]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (
        /*error*/
        ctx2[4]
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
        } else {
          if_block0 = create_if_block_1$9(ctx2);
          if_block0.c();
          if_block0.m(div, t0);
        }
      } else if (if_block0) {
        if_block0.d(1);
        if_block0 = null;
      }
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        16384)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[14],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[14]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[14],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (
        /*selectedUser*/
        ctx2[3] && !/*focused*/
        ctx2[0]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
        } else {
          if_block1 = create_if_block$e(ctx2);
          if_block1.c();
          if_block1.m(div, null);
        }
      } else if (if_block1) {
        if_block1.d(1);
        if_block1 = null;
      }
      if (!current || dirty & /*style*/
      2048) {
        attr(
          div,
          "style",
          /*style*/
          ctx2[11]
        );
      }
      if (!current || dirty & /*selected*/
      2) {
        toggle_class(
          div,
          "selected",
          /*selected*/
          ctx2[1]
        );
      }
      if (!current || dirty & /*highlighted*/
      4) {
        toggle_class(
          div,
          "highlighted",
          /*highlighted*/
          ctx2[2]
        );
      }
      if (!current || dirty & /*focused*/
      1) {
        toggle_class(
          div,
          "focused",
          /*focused*/
          ctx2[0]
        );
      }
      if (!current || dirty & /*error*/
      16) {
        toggle_class(
          div,
          "error",
          /*error*/
          ctx2[4]
        );
      }
      if (!current || dirty & /*center*/
      256) {
        toggle_class(
          div,
          "center",
          /*center*/
          ctx2[8]
        );
      }
      if (!current || dirty & /*readonly*/
      512) {
        toggle_class(
          div,
          "readonly",
          /*readonly*/
          ctx2[9]
        );
      }
      if (!current || dirty & /*hidden*/
      1024) {
        toggle_class(
          div,
          "hidden",
          /*hidden*/
          ctx2[10]
        );
      }
      if (!current || dirty & /*defaultHeight*/
      128) {
        toggle_class(
          div,
          "default-height",
          /*defaultHeight*/
          ctx2[7]
        );
      }
      if (!current || dirty & /*selectedUser*/
      8) {
        toggle_class(
          div,
          "selected-other",
          /*selectedUser*/
          ctx2[3] != null
        );
      }
      if (!current || dirty & /*rowIdx*/
      32) {
        toggle_class(
          div,
          "alt",
          /*rowIdx*/
          ctx2[5] % 2 === 1
        );
      }
      if (!current || dirty & /*topRow*/
      64) {
        toggle_class(
          div,
          "top",
          /*topRow*/
          ctx2[6]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block0)
        if_block0.d();
      if (default_slot)
        default_slot.d(detaching);
      if (if_block1)
        if_block1.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance$k($$self, $$props, $$invalidate) {
  let style;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { focused = false } = $$props;
  let { selected = false } = $$props;
  let { highlighted = false } = $$props;
  let { width = "" } = $$props;
  let { selectedUser = null } = $$props;
  let { error = null } = $$props;
  let { rowIdx } = $$props;
  let { topRow = false } = $$props;
  let { defaultHeight = false } = $$props;
  let { center = false } = $$props;
  let { readonly = false } = $$props;
  let { hidden = false } = $$props;
  let { metadata = null } = $$props;
  const getStyle = (width2, selectedUser2, metadata2) => {
    let style2;
    if (width2 === "auto" || width2 === "100%") {
      style2 = `width: ${width2};`;
    } else {
      style2 = `flex: 0 0 ${width2}px;`;
    }
    if (selectedUser2) {
      style2 += `--user-color :${selectedUser2.color};`;
    }
    if (metadata2 == null ? void 0 : metadata2.backgroundColor) {
      style2 += `--cell-background: ${metadata2.backgroundColor};`;
    }
    if (metadata2 == null ? void 0 : metadata2.textColor) {
      style2 += `--cell-font-color: ${metadata2.textColor};`;
    }
    return style2;
  };
  function focus_handler(event) {
    bubble.call(this, $$self, event);
  }
  function mousedown_handler(event) {
    bubble.call(this, $$self, event);
  }
  function mouseup_handler(event) {
    bubble.call(this, $$self, event);
  }
  function click_handler(event) {
    bubble.call(this, $$self, event);
  }
  function contextmenu_handler(event) {
    bubble.call(this, $$self, event);
  }
  function touchstart_handler(event) {
    bubble.call(this, $$self, event);
  }
  function touchend_handler(event) {
    bubble.call(this, $$self, event);
  }
  function touchcancel_handler(event) {
    bubble.call(this, $$self, event);
  }
  function mouseenter_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("focused" in $$props2)
      $$invalidate(0, focused = $$props2.focused);
    if ("selected" in $$props2)
      $$invalidate(1, selected = $$props2.selected);
    if ("highlighted" in $$props2)
      $$invalidate(2, highlighted = $$props2.highlighted);
    if ("width" in $$props2)
      $$invalidate(12, width = $$props2.width);
    if ("selectedUser" in $$props2)
      $$invalidate(3, selectedUser = $$props2.selectedUser);
    if ("error" in $$props2)
      $$invalidate(4, error = $$props2.error);
    if ("rowIdx" in $$props2)
      $$invalidate(5, rowIdx = $$props2.rowIdx);
    if ("topRow" in $$props2)
      $$invalidate(6, topRow = $$props2.topRow);
    if ("defaultHeight" in $$props2)
      $$invalidate(7, defaultHeight = $$props2.defaultHeight);
    if ("center" in $$props2)
      $$invalidate(8, center = $$props2.center);
    if ("readonly" in $$props2)
      $$invalidate(9, readonly = $$props2.readonly);
    if ("hidden" in $$props2)
      $$invalidate(10, hidden = $$props2.hidden);
    if ("metadata" in $$props2)
      $$invalidate(13, metadata = $$props2.metadata);
    if ("$$scope" in $$props2)
      $$invalidate(14, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*width, selectedUser, metadata*/
    12296) {
      $$invalidate(11, style = getStyle(width, selectedUser, metadata));
    }
  };
  return [
    focused,
    selected,
    highlighted,
    selectedUser,
    error,
    rowIdx,
    topRow,
    defaultHeight,
    center,
    readonly,
    hidden,
    style,
    width,
    metadata,
    $$scope,
    slots,
    focus_handler,
    mousedown_handler,
    mouseup_handler,
    click_handler,
    contextmenu_handler,
    touchstart_handler,
    touchend_handler,
    touchcancel_handler,
    mouseenter_handler
  ];
}
class GridCell extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$k, create_fragment$k, safe_not_equal, {
      focused: 0,
      selected: 1,
      highlighted: 2,
      width: 12,
      selectedUser: 3,
      error: 4,
      rowIdx: 5,
      topRow: 6,
      defaultHeight: 7,
      center: 8,
      readonly: 9,
      hidden: 10,
      metadata: 13
    });
  }
}
function create_default_slot$b(ctx) {
  let switch_instance;
  let updating_api;
  let t;
  let current;
  function switch_instance_api_binding(value) {
    ctx[33](value);
  }
  var switch_value = (
    /*renderer*/
    ctx[18]
  );
  function switch_props(ctx2, dirty) {
    let switch_instance_props = {
      value: (
        /*value*/
        ctx2[13]
      ),
      schema: (
        /*column*/
        ctx2[6].schema
      ),
      onChange: (
        /*cellAPI*/
        ctx2[24].setValue
      ),
      focused: (
        /*focused*/
        ctx2[4]
      ),
      readonly: (
        /*readonly*/
        ctx2[14]
      ),
      contentLines: (
        /*contentLines*/
        ctx2[9]
      )
    };
    if (
      /*api*/
      ctx2[12] !== void 0
    ) {
      switch_instance_props.api = /*api*/
      ctx2[12];
    }
    return { props: switch_instance_props };
  }
  if (switch_value) {
    switch_instance = construct_svelte_component(switch_value, switch_props(ctx));
    binding_callbacks.push(() => bind(switch_instance, "api", switch_instance_api_binding));
  }
  const default_slot_template = (
    /*#slots*/
    ctx[32].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[35],
    null
  );
  return {
    c() {
      if (switch_instance)
        create_component(switch_instance.$$.fragment);
      t = space();
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (switch_instance)
        mount_component(switch_instance, target, anchor);
      insert(target, t, anchor);
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*renderer*/
      262144 && switch_value !== (switch_value = /*renderer*/
      ctx2[18])) {
        if (switch_instance) {
          group_outros();
          const old_component = switch_instance;
          transition_out(old_component.$$.fragment, 1, 0, () => {
            destroy_component(old_component, 1);
          });
          check_outros();
        }
        if (switch_value) {
          switch_instance = construct_svelte_component(switch_value, switch_props(ctx2));
          binding_callbacks.push(() => bind(switch_instance, "api", switch_instance_api_binding));
          create_component(switch_instance.$$.fragment);
          transition_in(switch_instance.$$.fragment, 1);
          mount_component(switch_instance, t.parentNode, t);
        } else {
          switch_instance = null;
        }
      } else if (switch_value) {
        const switch_instance_changes = {};
        if (dirty[0] & /*value*/
        8192)
          switch_instance_changes.value = /*value*/
          ctx2[13];
        if (dirty[0] & /*column*/
        64)
          switch_instance_changes.schema = /*column*/
          ctx2[6].schema;
        if (dirty[0] & /*focused*/
        16)
          switch_instance_changes.focused = /*focused*/
          ctx2[4];
        if (dirty[0] & /*readonly*/
        16384)
          switch_instance_changes.readonly = /*readonly*/
          ctx2[14];
        if (dirty[0] & /*contentLines*/
        512)
          switch_instance_changes.contentLines = /*contentLines*/
          ctx2[9];
        if (!updating_api && dirty[0] & /*api*/
        4096) {
          updating_api = true;
          switch_instance_changes.api = /*api*/
          ctx2[12];
          add_flush_callback(() => updating_api = false);
        }
        switch_instance.$set(switch_instance_changes);
      }
      if (default_slot) {
        if (default_slot.p && (!current || dirty[1] & /*$$scope*/
        16)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[35],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[35]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[35],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      if (switch_instance)
        transition_in(switch_instance.$$.fragment, local);
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      if (switch_instance)
        transition_out(switch_instance.$$.fragment, local);
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      if (switch_instance)
        destroy_component(switch_instance, detaching);
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_fragment$j(ctx) {
  var _a, _b;
  let gridcell;
  let current;
  gridcell = new GridCell({
    props: {
      highlighted: (
        /*highlighted*/
        ctx[0]
      ),
      rowIdx: (
        /*rowIdx*/
        ctx[2]
      ),
      topRow: (
        /*topRow*/
        ctx[3]
      ),
      focused: (
        /*focused*/
        ctx[4]
      ),
      selectedUser: (
        /*selectedUser*/
        ctx[5]
      ),
      readonly: (
        /*readonly*/
        ctx[14]
      ),
      hidden: (
        /*hidden*/
        ctx[10]
      ),
      selected: (
        /*rowSelected*/
        ctx[1] || /*cellSelected*/
        ctx[11]
      ),
      error: (
        /*$error*/
        ctx[19]
      ),
      width: (
        /*column*/
        ctx[6].width
      ),
      metadata: {
        .../*row*/
        (_a = ctx[7].__metadata) == null ? void 0 : _a.row,
        .../*row*/
        (_b = ctx[7].__metadata) == null ? void 0 : _b.cell[
          /*column*/
          ctx[6].name
        ]
      },
      $$slots: { default: [create_default_slot$b] },
      $$scope: { ctx }
    }
  });
  gridcell.$on(
    "contextmenu",
    /*contextmenu_handler*/
    ctx[34]
  );
  gridcell.$on(
    "mousedown",
    /*startSelection*/
    ctx[25]
  );
  gridcell.$on("mouseenter", function() {
    if (is_function(
      /*updateSelectionCallback*/
      ctx[16]
    ))
      ctx[16].apply(this, arguments);
  });
  gridcell.$on("mouseup", function() {
    if (is_function(
      /*stopSelectionCallback*/
      ctx[15]
    ))
      ctx[15].apply(this, arguments);
  });
  gridcell.$on(
    "click",
    /*handleClick*/
    ctx[26]
  );
  return {
    c() {
      create_component(gridcell.$$.fragment);
    },
    m(target, anchor) {
      mount_component(gridcell, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      var _a2, _b2;
      ctx = new_ctx;
      const gridcell_changes = {};
      if (dirty[0] & /*highlighted*/
      1)
        gridcell_changes.highlighted = /*highlighted*/
        ctx[0];
      if (dirty[0] & /*rowIdx*/
      4)
        gridcell_changes.rowIdx = /*rowIdx*/
        ctx[2];
      if (dirty[0] & /*topRow*/
      8)
        gridcell_changes.topRow = /*topRow*/
        ctx[3];
      if (dirty[0] & /*focused*/
      16)
        gridcell_changes.focused = /*focused*/
        ctx[4];
      if (dirty[0] & /*selectedUser*/
      32)
        gridcell_changes.selectedUser = /*selectedUser*/
        ctx[5];
      if (dirty[0] & /*readonly*/
      16384)
        gridcell_changes.readonly = /*readonly*/
        ctx[14];
      if (dirty[0] & /*hidden*/
      1024)
        gridcell_changes.hidden = /*hidden*/
        ctx[10];
      if (dirty[0] & /*rowSelected, cellSelected*/
      2050)
        gridcell_changes.selected = /*rowSelected*/
        ctx[1] || /*cellSelected*/
        ctx[11];
      if (dirty[0] & /*$error*/
      524288)
        gridcell_changes.error = /*$error*/
        ctx[19];
      if (dirty[0] & /*column*/
      64)
        gridcell_changes.width = /*column*/
        ctx[6].width;
      if (dirty[0] & /*row, column*/
      192)
        gridcell_changes.metadata = {
          .../*row*/
          (_a2 = ctx[7].__metadata) == null ? void 0 : _a2.row,
          .../*row*/
          (_b2 = ctx[7].__metadata) == null ? void 0 : _b2.cell[
            /*column*/
            ctx[6].name
          ]
        };
      if (dirty[0] & /*renderer, value, column, focused, readonly, contentLines, api*/
      291408 | dirty[1] & /*$$scope*/
      16) {
        gridcell_changes.$$scope = { dirty, ctx };
      }
      gridcell.$set(gridcell_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(gridcell.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(gridcell.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(gridcell, detaching);
    }
  };
}
function instance$j($$self, $$props, $$invalidate) {
  let hasCustomFormat;
  let renderer;
  let value;
  let error;
  let readonly;
  let updateSelectionCallback;
  let stopSelectionCallback;
  let $selectedCellCount;
  let $focusedCellId;
  let $config;
  let $error, $$unsubscribe_error = noop, $$subscribe_error = () => ($$unsubscribe_error(), $$unsubscribe_error = subscribe(error, ($$value) => $$invalidate(19, $error = $$value)), error);
  $$self.$$.on_destroy.push(() => $$unsubscribe_error());
  let { $$slots: slots = {}, $$scope } = $$props;
  const { rows, columns, focusedCellId, focusedCellAPI, menu, config, validation, selectedCells, selectedCellCount } = getContext("grid");
  component_subscribe($$self, focusedCellId, (value2) => $$invalidate(37, $focusedCellId = value2));
  component_subscribe($$self, config, (value2) => $$invalidate(31, $config = value2));
  component_subscribe($$self, selectedCellCount, (value2) => $$invalidate(36, $selectedCellCount = value2));
  let { highlighted } = $$props;
  let { rowFocused } = $$props;
  let { rowSelected } = $$props;
  let { rowIdx } = $$props;
  let { topRow = false } = $$props;
  let { focused } = $$props;
  let { selectedUser } = $$props;
  let { column } = $$props;
  let { row } = $$props;
  let { cellId } = $$props;
  let { updateValue = rows.actions.updateValue } = $$props;
  let { contentLines = 1 } = $$props;
  let { hidden = false } = $$props;
  let { isSelectingCells = false } = $$props;
  let { cellSelected = false } = $$props;
  const emptyError = writable(null);
  let api;
  const getErrorStore = (selected, cellId2) => {
    if (!selected) {
      return emptyError;
    }
    return derived(validation, ($validation) => $validation[cellId2]);
  };
  const cellAPI = {
    focus: () => {
      var _a;
      return (_a = api == null ? void 0 : api.focus) == null ? void 0 : _a.call(api);
    },
    blur: () => {
      var _a;
      return (_a = api == null ? void 0 : api.blur) == null ? void 0 : _a.call(api);
    },
    isActive: () => {
      var _a;
      return ((_a = api == null ? void 0 : api.isActive) == null ? void 0 : _a.call(api)) ?? false;
    },
    onKeyDown: (...params) => {
      var _a;
      return (_a = api == null ? void 0 : api.onKeyDown) == null ? void 0 : _a.call(api, ...params);
    },
    isReadonly: () => readonly,
    getType: () => column.schema.type,
    getValue: () => value,
    setValue: (value2, options = { apply: true }) => {
      validation.actions.setError(cellId, null);
      updateValue({
        rowId: row._id,
        column: column.name,
        value: value2,
        apply: options == null ? void 0 : options.apply
      });
    }
  };
  const startSelection = (e) => {
    if (e.button !== 0 || e.shiftKey) {
      return;
    }
    selectedCells.actions.startSelecting(cellId);
  };
  const updateSelection = (e) => {
    if (e.buttons !== 1) {
      selectedCells.actions.stopSelecting();
      return;
    }
    selectedCells.actions.updateTarget(cellId);
  };
  const stopSelection = () => {
    selectedCells.actions.stopSelecting();
  };
  const handleClick = (e) => {
    if (e.shiftKey && $focusedCellId) {
      selectedCells.actions.selectRange($focusedCellId, cellId);
    } else if (e.shiftKey && $selectedCellCount) {
      selectedCells.actions.updateTarget(cellId);
    } else {
      focusedCellId.set(cellId);
    }
  };
  function switch_instance_api_binding(value2) {
    api = value2;
    $$invalidate(12, api);
  }
  const contextmenu_handler = (e) => menu.actions.open(cellId, e);
  $$self.$$set = ($$props2) => {
    if ("highlighted" in $$props2)
      $$invalidate(0, highlighted = $$props2.highlighted);
    if ("rowFocused" in $$props2)
      $$invalidate(27, rowFocused = $$props2.rowFocused);
    if ("rowSelected" in $$props2)
      $$invalidate(1, rowSelected = $$props2.rowSelected);
    if ("rowIdx" in $$props2)
      $$invalidate(2, rowIdx = $$props2.rowIdx);
    if ("topRow" in $$props2)
      $$invalidate(3, topRow = $$props2.topRow);
    if ("focused" in $$props2)
      $$invalidate(4, focused = $$props2.focused);
    if ("selectedUser" in $$props2)
      $$invalidate(5, selectedUser = $$props2.selectedUser);
    if ("column" in $$props2)
      $$invalidate(6, column = $$props2.column);
    if ("row" in $$props2)
      $$invalidate(7, row = $$props2.row);
    if ("cellId" in $$props2)
      $$invalidate(8, cellId = $$props2.cellId);
    if ("updateValue" in $$props2)
      $$invalidate(28, updateValue = $$props2.updateValue);
    if ("contentLines" in $$props2)
      $$invalidate(9, contentLines = $$props2.contentLines);
    if ("hidden" in $$props2)
      $$invalidate(10, hidden = $$props2.hidden);
    if ("isSelectingCells" in $$props2)
      $$invalidate(29, isSelectingCells = $$props2.isSelectingCells);
    if ("cellSelected" in $$props2)
      $$invalidate(11, cellSelected = $$props2.cellSelected);
    if ("$$scope" in $$props2)
      $$invalidate(35, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    var _a;
    if ($$self.$$.dirty[0] & /*column, row*/
    192) {
      $$invalidate(30, hasCustomFormat = column.format && !row._isNewRow);
    }
    if ($$self.$$.dirty[0] & /*hasCustomFormat, column*/
    1073741888) {
      $$invalidate(18, renderer = hasCustomFormat ? TextCell : getCellRenderer(column));
    }
    if ($$self.$$.dirty[0] & /*hasCustomFormat, row, column*/
    1073742016) {
      $$invalidate(13, value = hasCustomFormat ? (_a = row.__formatted) == null ? void 0 : _a[column.name] : row[column.name]);
    }
    if ($$self.$$.dirty[0] & /*rowFocused, cellId*/
    134217984) {
      $$subscribe_error($$invalidate(17, error = getErrorStore(rowFocused, cellId)));
    }
    if ($$self.$$.dirty[0] & /*hasCustomFormat, column, row*/
    1073742016 | $$self.$$.dirty[1] & /*$config*/
    1) {
      $$invalidate(14, readonly = hasCustomFormat || columns.actions.isReadonly(column) || !$config.canEditRows && !row._isNewRow);
    }
    if ($$self.$$.dirty[0] & /*focused*/
    16) {
      {
        if (focused) {
          focusedCellAPI.set(cellAPI);
        }
      }
    }
    if ($$self.$$.dirty[0] & /*isSelectingCells*/
    536870912) {
      $$invalidate(16, updateSelectionCallback = isSelectingCells ? updateSelection : null);
    }
    if ($$self.$$.dirty[0] & /*isSelectingCells*/
    536870912) {
      $$invalidate(15, stopSelectionCallback = isSelectingCells ? stopSelection : null);
    }
  };
  return [
    highlighted,
    rowSelected,
    rowIdx,
    topRow,
    focused,
    selectedUser,
    column,
    row,
    cellId,
    contentLines,
    hidden,
    cellSelected,
    api,
    value,
    readonly,
    stopSelectionCallback,
    updateSelectionCallback,
    error,
    renderer,
    $error,
    focusedCellId,
    menu,
    config,
    selectedCellCount,
    cellAPI,
    startSelection,
    handleClick,
    rowFocused,
    updateValue,
    isSelectingCells,
    hasCustomFormat,
    $config,
    slots,
    switch_instance_api_binding,
    contextmenu_handler,
    $$scope
  ];
}
class DataCell extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance$j,
      create_fragment$j,
      safe_not_equal,
      {
        highlighted: 0,
        rowFocused: 27,
        rowSelected: 1,
        rowIdx: 2,
        topRow: 3,
        focused: 4,
        selectedUser: 5,
        column: 6,
        row: 7,
        cellId: 8,
        updateValue: 28,
        contentLines: 9,
        hidden: 10,
        isSelectingCells: 29,
        cellSelected: 11
      },
      null,
      [-1, -1]
    );
  }
}
function get_each_context$8(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[44] = list[i];
  const constants_0 = getCellID(
    /*row*/
    child_ctx[0]._id,
    /*column*/
    child_ctx[44].name
  );
  child_ctx[45] = constants_0;
  return child_ctx;
}
function create_each_block$8(ctx) {
  let datacell;
  let current;
  datacell = new DataCell({
    props: {
      cellId: (
        /*cellId*/
        ctx[45]
      ),
      column: (
        /*column*/
        ctx[44]
      ),
      row: (
        /*row*/
        ctx[0]
      ),
      rowFocused: (
        /*rowFocused*/
        ctx[7]
      ),
      rowSelected: (
        /*rowSelected*/
        ctx[9]
      ),
      cellSelected: (
        /*$selectedCellMap*/
        ctx[12][
          /*cellId*/
          ctx[45]
        ]
      ),
      highlighted: (
        /*rowHovered*/
        ctx[8] || /*rowFocused*/
        ctx[7] || /*reorderSource*/
        ctx[6] === /*column*/
        ctx[44].name
      ),
      rowIdx: (
        /*row*/
        ctx[0].__idx
      ),
      topRow: (
        /*top*/
        ctx[1]
      ),
      focused: (
        /*$focusedCellId*/
        ctx[13] === /*cellId*/
        ctx[45]
      ),
      selectedUser: (
        /*$userCellMap*/
        ctx[14][
          /*cellId*/
          ctx[45]
        ]
      ),
      width: (
        /*column*/
        ctx[44].width
      ),
      contentLines: (
        /*$contentLines*/
        ctx[15]
      ),
      hidden: !/*$columnRenderMap*/
      ctx[16][
        /*column*/
        ctx[44].name
      ],
      isSelectingCells: (
        /*$isSelectingCells*/
        ctx[3]
      )
    }
  });
  return {
    c() {
      create_component(datacell.$$.fragment);
    },
    m(target, anchor) {
      mount_component(datacell, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const datacell_changes = {};
      if (dirty[0] & /*row, $scrollableColumns*/
      2049)
        datacell_changes.cellId = /*cellId*/
        ctx2[45];
      if (dirty[0] & /*$scrollableColumns*/
      2048)
        datacell_changes.column = /*column*/
        ctx2[44];
      if (dirty[0] & /*row*/
      1)
        datacell_changes.row = /*row*/
        ctx2[0];
      if (dirty[0] & /*rowFocused*/
      128)
        datacell_changes.rowFocused = /*rowFocused*/
        ctx2[7];
      if (dirty[0] & /*rowSelected*/
      512)
        datacell_changes.rowSelected = /*rowSelected*/
        ctx2[9];
      if (dirty[0] & /*$selectedCellMap, row, $scrollableColumns*/
      6145)
        datacell_changes.cellSelected = /*$selectedCellMap*/
        ctx2[12][
          /*cellId*/
          ctx2[45]
        ];
      if (dirty[0] & /*rowHovered, rowFocused, reorderSource, $scrollableColumns*/
      2496)
        datacell_changes.highlighted = /*rowHovered*/
        ctx2[8] || /*rowFocused*/
        ctx2[7] || /*reorderSource*/
        ctx2[6] === /*column*/
        ctx2[44].name;
      if (dirty[0] & /*row*/
      1)
        datacell_changes.rowIdx = /*row*/
        ctx2[0].__idx;
      if (dirty[0] & /*top*/
      2)
        datacell_changes.topRow = /*top*/
        ctx2[1];
      if (dirty[0] & /*$focusedCellId, row, $scrollableColumns*/
      10241)
        datacell_changes.focused = /*$focusedCellId*/
        ctx2[13] === /*cellId*/
        ctx2[45];
      if (dirty[0] & /*$userCellMap, row, $scrollableColumns*/
      18433)
        datacell_changes.selectedUser = /*$userCellMap*/
        ctx2[14][
          /*cellId*/
          ctx2[45]
        ];
      if (dirty[0] & /*$scrollableColumns*/
      2048)
        datacell_changes.width = /*column*/
        ctx2[44].width;
      if (dirty[0] & /*$contentLines*/
      32768)
        datacell_changes.contentLines = /*$contentLines*/
        ctx2[15];
      if (dirty[0] & /*$columnRenderMap, $scrollableColumns*/
      67584)
        datacell_changes.hidden = !/*$columnRenderMap*/
        ctx2[16][
          /*column*/
          ctx2[44].name
        ];
      if (dirty[0] & /*$isSelectingCells*/
      8)
        datacell_changes.isSelectingCells = /*$isSelectingCells*/
        ctx2[3];
      datacell.$set(datacell_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(datacell.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(datacell.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(datacell, detaching);
    }
  };
}
function create_if_block$d(ctx) {
  let gridcell;
  let current;
  gridcell = new GridCell({
    props: {
      width: (
        /*$buttonColumnWidth*/
        ctx[2]
      ),
      selected: (
        /*rowSelected*/
        ctx[9]
      ),
      highlighted: (
        /*rowHovered*/
        ctx[8] || /*rowFocused*/
        ctx[7]
      ),
      rowIdx: (
        /*row*/
        ctx[0].__idx
      )
    }
  });
  return {
    c() {
      create_component(gridcell.$$.fragment);
    },
    m(target, anchor) {
      mount_component(gridcell, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const gridcell_changes = {};
      if (dirty[0] & /*$buttonColumnWidth*/
      4)
        gridcell_changes.width = /*$buttonColumnWidth*/
        ctx2[2];
      if (dirty[0] & /*rowSelected*/
      512)
        gridcell_changes.selected = /*rowSelected*/
        ctx2[9];
      if (dirty[0] & /*rowHovered, rowFocused*/
      384)
        gridcell_changes.highlighted = /*rowHovered*/
        ctx2[8] || /*rowFocused*/
        ctx2[7];
      if (dirty[0] & /*row*/
      1)
        gridcell_changes.rowIdx = /*row*/
        ctx2[0].__idx;
      gridcell.$set(gridcell_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(gridcell.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(gridcell.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(gridcell, detaching);
    }
  };
}
function create_fragment$i(ctx) {
  let div;
  let t;
  let current;
  let mounted;
  let dispose;
  let each_value = ensure_array_like(
    /*$scrollableColumns*/
    ctx[11]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$8(get_each_context$8(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  let if_block = (
    /*needsButtonSpacer*/
    ctx[5] && create_if_block$d(ctx)
  );
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t = space();
      if (if_block)
        if_block.c();
      attr(div, "class", "row svelte-1507qm8");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      append(div, t);
      if (if_block)
        if_block.m(div, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            div,
            "focus",
            /*focus_handler*/
            ctx[40]
          ),
          listen(div, "mouseenter", function() {
            if (is_function(
              /*$isDragging*/
              ctx[10] ? null : (
                /*mouseenter_handler*/
                ctx[41]
              )
            ))
              /*$isDragging*/
              (ctx[10] ? null : (
                /*mouseenter_handler*/
                ctx[41]
              )).apply(this, arguments);
          }),
          listen(div, "mouseleave", function() {
            if (is_function(
              /*$isDragging*/
              ctx[10] ? null : (
                /*mouseleave_handler*/
                ctx[42]
              )
            ))
              /*$isDragging*/
              (ctx[10] ? null : (
                /*mouseleave_handler*/
                ctx[42]
              )).apply(this, arguments);
          }),
          listen(
            div,
            "click",
            /*click_handler*/
            ctx[43]
          )
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty[0] & /*row, $scrollableColumns, rowFocused, rowSelected, $selectedCellMap, rowHovered, reorderSource, top, $focusedCellId, $userCellMap, $contentLines, $columnRenderMap, $isSelectingCells*/
      129995) {
        each_value = ensure_array_like(
          /*$scrollableColumns*/
          ctx[11]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$8(ctx, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$8(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div, t);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      if (
        /*needsButtonSpacer*/
        ctx[5]
      ) {
        if (if_block) {
          if_block.p(ctx, dirty);
          if (dirty[0] & /*needsButtonSpacer*/
          32) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$d(ctx);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      transition_in(if_block);
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
      if (if_block)
        if_block.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance$i($$self, $$props, $$invalidate) {
  let rowSelected;
  let rowHovered;
  let rowFocused;
  let reorderSource;
  let hasButtons;
  let needsButtonSpacer;
  let $buttonColumnWidth;
  let $props;
  let $reorder;
  let $focusedRow;
  let $isSelectingCells;
  let $selectedCellCount;
  let $hoveredRowId;
  let $selectedRows;
  let $isDragging;
  let $scrollableColumns;
  let $selectedCellMap;
  let $focusedCellId;
  let $userCellMap;
  let $contentLines;
  let $columnRenderMap;
  let { row } = $$props;
  let { top = false } = $$props;
  const { focusedCellId, reorder, selectedRows, scrollableColumns, hoveredRowId, focusedRow, contentLines, isDragging, dispatch, rows, columnRenderMap, userCellMap, isSelectingCells, selectedCellMap, selectedCellCount, props, buttonColumnWidth } = getContext("grid");
  component_subscribe($$self, focusedCellId, (value) => $$invalidate(13, $focusedCellId = value));
  component_subscribe($$self, reorder, (value) => $$invalidate(36, $reorder = value));
  component_subscribe($$self, selectedRows, (value) => $$invalidate(39, $selectedRows = value));
  component_subscribe($$self, scrollableColumns, (value) => $$invalidate(11, $scrollableColumns = value));
  component_subscribe($$self, hoveredRowId, (value) => $$invalidate(4, $hoveredRowId = value));
  component_subscribe($$self, focusedRow, (value) => $$invalidate(37, $focusedRow = value));
  component_subscribe($$self, contentLines, (value) => $$invalidate(15, $contentLines = value));
  component_subscribe($$self, isDragging, (value) => $$invalidate(10, $isDragging = value));
  component_subscribe($$self, columnRenderMap, (value) => $$invalidate(16, $columnRenderMap = value));
  component_subscribe($$self, userCellMap, (value) => $$invalidate(14, $userCellMap = value));
  component_subscribe($$self, isSelectingCells, (value) => $$invalidate(3, $isSelectingCells = value));
  component_subscribe($$self, selectedCellMap, (value) => $$invalidate(12, $selectedCellMap = value));
  component_subscribe($$self, selectedCellCount, (value) => $$invalidate(38, $selectedCellCount = value));
  component_subscribe($$self, props, (value) => $$invalidate(35, $props = value));
  component_subscribe($$self, buttonColumnWidth, (value) => $$invalidate(2, $buttonColumnWidth = value));
  function focus_handler(event) {
    bubble.call(this, $$self, event);
  }
  const mouseenter_handler = () => set_store_value(hoveredRowId, $hoveredRowId = row._id, $hoveredRowId);
  const mouseleave_handler = () => set_store_value(hoveredRowId, $hoveredRowId = null, $hoveredRowId);
  const click_handler = () => dispatch("rowclick", rows.actions.cleanRow(row));
  $$self.$$set = ($$props2) => {
    if ("row" in $$props2)
      $$invalidate(0, row = $$props2.row);
    if ("top" in $$props2)
      $$invalidate(1, top = $$props2.top);
  };
  $$self.$$.update = () => {
    var _a;
    if ($$self.$$.dirty[0] & /*row*/
    1 | $$self.$$.dirty[1] & /*$selectedRows*/
    256) {
      $$invalidate(9, rowSelected = !!$selectedRows[row._id]);
    }
    if ($$self.$$.dirty[0] & /*$hoveredRowId, row, $isSelectingCells*/
    25 | $$self.$$.dirty[1] & /*$selectedCellCount*/
    128) {
      $$invalidate(8, rowHovered = $hoveredRowId === row._id && (!$selectedCellCount || !$isSelectingCells));
    }
    if ($$self.$$.dirty[0] & /*row*/
    1 | $$self.$$.dirty[1] & /*$focusedRow*/
    64) {
      $$invalidate(7, rowFocused = ($focusedRow == null ? void 0 : $focusedRow._id) === row._id);
    }
    if ($$self.$$.dirty[1] & /*$reorder*/
    32) {
      $$invalidate(6, reorderSource = $reorder.sourceColumn);
    }
    if ($$self.$$.dirty[1] & /*$props*/
    16) {
      $$invalidate(34, hasButtons = ((_a = $props == null ? void 0 : $props.buttons) == null ? void 0 : _a.length) > 0);
    }
    if ($$self.$$.dirty[0] & /*$buttonColumnWidth*/
    4 | $$self.$$.dirty[1] & /*hasButtons*/
    8) {
      $$invalidate(5, needsButtonSpacer = hasButtons && $buttonColumnWidth > 0);
    }
  };
  return [
    row,
    top,
    $buttonColumnWidth,
    $isSelectingCells,
    $hoveredRowId,
    needsButtonSpacer,
    reorderSource,
    rowFocused,
    rowHovered,
    rowSelected,
    $isDragging,
    $scrollableColumns,
    $selectedCellMap,
    $focusedCellId,
    $userCellMap,
    $contentLines,
    $columnRenderMap,
    focusedCellId,
    reorder,
    selectedRows,
    scrollableColumns,
    hoveredRowId,
    focusedRow,
    contentLines,
    isDragging,
    dispatch,
    rows,
    columnRenderMap,
    userCellMap,
    isSelectingCells,
    selectedCellMap,
    selectedCellCount,
    props,
    buttonColumnWidth,
    hasButtons,
    $props,
    $reorder,
    $focusedRow,
    $selectedCellCount,
    $selectedRows,
    focus_handler,
    mouseenter_handler,
    mouseleave_handler,
    click_handler
  ];
}
class GridRow extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$i, create_fragment$i, safe_not_equal, { row: 0, top: 1 }, null, [-1, -1]);
  }
}
function get_each_context$7(ctx, list, i) {
  var _a;
  const child_ctx = ctx.slice();
  child_ctx[49] = list[i];
  const constants_0 = !!/*$selectedRows*/
  child_ctx[7][
    /*row*/
    child_ctx[49]._id
  ];
  child_ctx[50] = constants_0;
  const constants_1 = (
    /*$hoveredRowId*/
    child_ctx[5] === /*row*/
    child_ctx[49]._id
  );
  child_ctx[51] = constants_1;
  const constants_2 = (
    /*$focusedRow*/
    ((_a = child_ctx[8]) == null ? void 0 : _a._id) === /*row*/
    child_ctx[49]._id
  );
  child_ctx[52] = constants_2;
  const constants_3 = (
    /*getButtonsForRow*/
    child_ctx[28](
      /*buttons*/
      child_ctx[4],
      /*row*/
      child_ctx[49]
    )
  );
  child_ctx[53] = constants_3;
  return child_ctx;
}
function get_each_context_1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[56] = list[i];
  return child_ctx;
}
function create_else_block_1$2(ctx) {
  let t;
  let if_block_anchor;
  let current;
  let each_value_1 = ensure_array_like(
    /*rowButtons*/
    ctx[53]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value_1.length; i += 1) {
    each_blocks[i] = create_each_block_1(get_each_context_1(ctx, each_value_1, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  let if_block = (
    /*rowButtons*/
    ctx[53].length === 0 && create_if_block_3$5()
  );
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*getButtonsForRow, buttons, $renderedRows, handleClick*/
      805306448) {
        each_value_1 = ensure_array_like(
          /*rowButtons*/
          ctx2[53]
        );
        let i;
        for (i = 0; i < each_value_1.length; i += 1) {
          const child_ctx = get_each_context_1(ctx2, each_value_1, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block_1(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(t.parentNode, t);
          }
        }
        group_outros();
        for (i = each_value_1.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      if (
        /*rowButtons*/
        ctx2[53].length === 0
      ) {
        if (if_block)
          ;
        else {
          if_block = create_if_block_3$5();
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value_1.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      destroy_each(each_blocks, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block_1$8(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block_2$6, create_else_block$3];
  const if_blocks = [];
  function select_block_type_1(ctx2, dirty) {
    if (
      /*rowButtons*/
      ctx2[53].length > 0
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type_1(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_1(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_if_block_4$3(ctx) {
  let i;
  let i_class_value;
  return {
    c() {
      i = element("i");
      attr(i, "class", i_class_value = /*button*/
      ctx[56].icon + " S svelte-1oqghfp");
    },
    m(target, anchor) {
      insert(target, i, anchor);
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*buttons, $renderedRows*/
      80 && i_class_value !== (i_class_value = /*button*/
      ctx2[56].icon + " S svelte-1oqghfp")) {
        attr(i, "class", i_class_value);
      }
    },
    d(detaching) {
      if (detaching) {
        detach(i);
      }
    }
  };
}
function create_default_slot_2$5(ctx) {
  let t0;
  let t1_value = (
    /*button*/
    (ctx[56].text || "Button") + ""
  );
  let t1;
  let if_block = (
    /*button*/
    ctx[56].icon && create_if_block_4$3(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      t0 = space();
      t1 = text(t1_value);
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, t0, anchor);
      insert(target, t1, anchor);
    },
    p(ctx2, dirty) {
      if (
        /*button*/
        ctx2[56].icon
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block_4$3(ctx2);
          if_block.c();
          if_block.m(t0.parentNode, t0);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (dirty[0] & /*buttons, $renderedRows*/
      80 && t1_value !== (t1_value = /*button*/
      (ctx2[56].text || "Button") + ""))
        set_data(t1, t1_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_each_block_1(ctx) {
  let button_1;
  let current;
  function click_handler() {
    return (
      /*click_handler*/
      ctx[38](
        /*button*/
        ctx[56],
        /*row*/
        ctx[49]
      )
    );
  }
  button_1 = new Button({
    props: {
      newStyles: true,
      size: "S",
      cta: (
        /*button*/
        ctx[56].type === "cta"
      ),
      primary: (
        /*button*/
        ctx[56].type === "primary"
      ),
      secondary: (
        /*button*/
        ctx[56].type === "secondary"
      ),
      warning: (
        /*button*/
        ctx[56].type === "warning"
      ),
      overBackground: (
        /*button*/
        ctx[56].type === "overBackground"
      ),
      $$slots: { default: [create_default_slot_2$5] },
      $$scope: { ctx }
    }
  });
  button_1.$on("click", click_handler);
  return {
    c() {
      create_component(button_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(button_1, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const button_1_changes = {};
      if (dirty[0] & /*buttons, $renderedRows*/
      80)
        button_1_changes.cta = /*button*/
        ctx[56].type === "cta";
      if (dirty[0] & /*buttons, $renderedRows*/
      80)
        button_1_changes.primary = /*button*/
        ctx[56].type === "primary";
      if (dirty[0] & /*buttons, $renderedRows*/
      80)
        button_1_changes.secondary = /*button*/
        ctx[56].type === "secondary";
      if (dirty[0] & /*buttons, $renderedRows*/
      80)
        button_1_changes.warning = /*button*/
        ctx[56].type === "warning";
      if (dirty[0] & /*buttons, $renderedRows*/
      80)
        button_1_changes.overBackground = /*button*/
        ctx[56].type === "overBackground";
      if (dirty[0] & /*buttons, $renderedRows*/
      80 | dirty[1] & /*$$scope*/
      268435456) {
        button_1_changes.$$scope = { dirty, ctx };
      }
      button_1.$set(button_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(button_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(button_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(button_1, detaching);
    }
  };
}
function create_if_block_3$5(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      attr(div, "class", "button-placeholder svelte-1oqghfp");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_else_block$3(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      attr(div, "class", "button-placeholder-collapsed svelte-1oqghfp");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block_2$6(ctx) {
  let collapsedbuttongroup;
  let current;
  function mouseenter_handler() {
    return (
      /*mouseenter_handler*/
      ctx[37](
        /*row*/
        ctx[49]
      )
    );
  }
  collapsedbuttongroup = new CollapsedButtonGroup({
    props: {
      buttons: (
        /*makeCollapsedButtons*/
        ctx[30](
          /*rowButtons*/
          ctx[53],
          /*row*/
          ctx[49]
        )
      ),
      text: (
        /*$props*/
        ctx[1].buttonsCollapsedText || "Action"
      ),
      align: "right",
      offset: 5,
      size: "S",
      animate: false
    }
  });
  collapsedbuttongroup.$on("mouseenter", mouseenter_handler);
  return {
    c() {
      create_component(collapsedbuttongroup.$$.fragment);
    },
    m(target, anchor) {
      mount_component(collapsedbuttongroup, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const collapsedbuttongroup_changes = {};
      if (dirty[0] & /*buttons, $renderedRows*/
      80)
        collapsedbuttongroup_changes.buttons = /*makeCollapsedButtons*/
        ctx[30](
          /*rowButtons*/
          ctx[53],
          /*row*/
          ctx[49]
        );
      if (dirty[0] & /*$props*/
      2)
        collapsedbuttongroup_changes.text = /*$props*/
        ctx[1].buttonsCollapsedText || "Action";
      collapsedbuttongroup.$set(collapsedbuttongroup_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(collapsedbuttongroup.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(collapsedbuttongroup.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(collapsedbuttongroup, detaching);
    }
  };
}
function create_default_slot_1$5(ctx) {
  let div;
  let current_block_type_index;
  let if_block;
  let current;
  const if_block_creators = [create_if_block_1$8, create_else_block_1$2];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*$props*/
      ctx2[1].buttonsCollapsed
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      div = element("div");
      if_block.c();
      attr(div, "class", "buttons svelte-1oqghfp");
      toggle_class(
        div,
        "offset",
        /*$showVScrollbar*/
        ctx[10] && /*$showHScrollbar*/
        ctx[11]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div, null);
      }
      if (!current || dirty[0] & /*$showVScrollbar, $showHScrollbar*/
      3072) {
        toggle_class(
          div,
          "offset",
          /*$showVScrollbar*/
          ctx2[10] && /*$showHScrollbar*/
          ctx2[11]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
    }
  };
}
function create_each_block$7(ctx) {
  var _a;
  let div;
  let gridcell;
  let current;
  let mounted;
  let dispose;
  gridcell = new GridCell({
    props: {
      width: "100%",
      rowIdx: (
        /*row*/
        ctx[49].__idx
      ),
      selected: (
        /*rowSelected*/
        ctx[50]
      ),
      highlighted: (
        /*rowHovered*/
        ctx[51] || /*rowFocused*/
        ctx[52]
      ),
      metadata: (
        /*row*/
        (_a = ctx[49].__metadata) == null ? void 0 : _a.row
      ),
      $$slots: { default: [create_default_slot_1$5] },
      $$scope: { ctx }
    }
  });
  function mouseenter_handler_1() {
    return (
      /*mouseenter_handler_1*/
      ctx[39](
        /*row*/
        ctx[49]
      )
    );
  }
  return {
    c() {
      div = element("div");
      create_component(gridcell.$$.fragment);
      attr(div, "class", "row svelte-1oqghfp");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(gridcell, div, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(div, "mouseenter", function() {
            if (is_function(
              /*$isDragging*/
              ctx[9] ? null : mouseenter_handler_1
            ))
              /*$isDragging*/
              (ctx[9] ? null : mouseenter_handler_1).apply(this, arguments);
          }),
          listen(div, "mouseleave", function() {
            if (is_function(
              /*$isDragging*/
              ctx[9] ? null : (
                /*mouseleave_handler*/
                ctx[40]
              )
            ))
              /*$isDragging*/
              (ctx[9] ? null : (
                /*mouseleave_handler*/
                ctx[40]
              )).apply(this, arguments);
          })
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      var _a2;
      ctx = new_ctx;
      const gridcell_changes = {};
      if (dirty[0] & /*$renderedRows*/
      64)
        gridcell_changes.rowIdx = /*row*/
        ctx[49].__idx;
      if (dirty[0] & /*$selectedRows, $renderedRows*/
      192)
        gridcell_changes.selected = /*rowSelected*/
        ctx[50];
      if (dirty[0] & /*$hoveredRowId, $renderedRows, $focusedRow*/
      352)
        gridcell_changes.highlighted = /*rowHovered*/
        ctx[51] || /*rowFocused*/
        ctx[52];
      if (dirty[0] & /*$renderedRows*/
      64)
        gridcell_changes.metadata = /*row*/
        (_a2 = ctx[49].__metadata) == null ? void 0 : _a2.row;
      if (dirty[0] & /*$showVScrollbar, $showHScrollbar, buttons, $renderedRows, $props, $hoveredRowId*/
      3186 | dirty[1] & /*$$scope*/
      268435456) {
        gridcell_changes.$$scope = { dirty, ctx };
      }
      gridcell.$set(gridcell_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(gridcell.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(gridcell.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(gridcell);
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_if_block$c(ctx) {
  let div;
  let gridcell;
  let current;
  let mounted;
  let dispose;
  gridcell = new GridCell({
    props: {
      width: "100%",
      highlighted: (
        /*$hoveredRowId*/
        ctx[5] === BlankRowID
      )
    }
  });
  gridcell.$on(
    "click",
    /*click_handler_1*/
    ctx[41]
  );
  return {
    c() {
      div = element("div");
      create_component(gridcell.$$.fragment);
      attr(div, "class", "row blank svelte-1oqghfp");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(gridcell, div, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(div, "mouseenter", function() {
            if (is_function(
              /*$isDragging*/
              ctx[9] ? null : (
                /*mouseenter_handler_2*/
                ctx[42]
              )
            ))
              /*$isDragging*/
              (ctx[9] ? null : (
                /*mouseenter_handler_2*/
                ctx[42]
              )).apply(this, arguments);
          }),
          listen(div, "mouseleave", function() {
            if (is_function(
              /*$isDragging*/
              ctx[9] ? null : (
                /*mouseleave_handler_1*/
                ctx[43]
              )
            ))
              /*$isDragging*/
              (ctx[9] ? null : (
                /*mouseleave_handler_1*/
                ctx[43]
              )).apply(this, arguments);
          })
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const gridcell_changes = {};
      if (dirty[0] & /*$hoveredRowId*/
      32)
        gridcell_changes.highlighted = /*$hoveredRowId*/
        ctx[5] === BlankRowID;
      gridcell.$set(gridcell_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(gridcell.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(gridcell.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(gridcell);
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_default_slot$a(ctx) {
  let t;
  let if_block_anchor;
  let current;
  let each_value = ensure_array_like(
    /*$renderedRows*/
    ctx[6]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$7(get_each_context$7(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  let if_block = (
    /*$config*/
    ctx[12].canAddRows && create_if_block$c(ctx)
  );
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*$isDragging, $hoveredRowId, $renderedRows, $selectedRows, $focusedRow, $showVScrollbar, $showHScrollbar, makeCollapsedButtons, getButtonsForRow, buttons, $props, handleClick*/
      1879052274) {
        each_value = ensure_array_like(
          /*$renderedRows*/
          ctx2[6]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$7(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$7(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(t.parentNode, t);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      if (
        /*$config*/
        ctx2[12].canAddRows
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*$config*/
          4096) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$c(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      transition_in(if_block);
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      destroy_each(each_blocks, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment$h(ctx) {
  let div1;
  let div0;
  let gridscrollwrapper;
  let updating_ref;
  let current;
  let mounted;
  let dispose;
  function gridscrollwrapper_ref_binding(value) {
    ctx[44](value);
  }
  let gridscrollwrapper_props = {
    scrollVertically: true,
    attachHandlers: true,
    $$slots: { default: [create_default_slot$a] },
    $$scope: { ctx }
  };
  if (
    /*container*/
    ctx[2] !== void 0
  ) {
    gridscrollwrapper_props.ref = /*container*/
    ctx[2];
  }
  gridscrollwrapper = new GridScrollWrapper({ props: gridscrollwrapper_props });
  binding_callbacks.push(() => bind(gridscrollwrapper, "ref", gridscrollwrapper_ref_binding));
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      create_component(gridscrollwrapper.$$.fragment);
      attr(div0, "class", "content svelte-1oqghfp");
      attr(div1, "class", "button-column svelte-1oqghfp");
      set_style(
        div1,
        "left",
        /*left*/
        ctx[3] + "px"
      );
      toggle_class(
        div1,
        "hidden",
        /*$buttonColumnWidth*/
        ctx[0] === 0
      );
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      mount_component(gridscrollwrapper, div0, null);
      current = true;
      if (!mounted) {
        dispose = listen(
          div0,
          "mouseleave",
          /*mouseleave_handler_2*/
          ctx[45]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      const gridscrollwrapper_changes = {};
      if (dirty[0] & /*$isDragging, $hoveredRowId, $config, $renderedRows, $selectedRows, $focusedRow, $showVScrollbar, $showHScrollbar, buttons, $props*/
      8178 | dirty[1] & /*$$scope*/
      268435456) {
        gridscrollwrapper_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_ref && dirty[0] & /*container*/
      4) {
        updating_ref = true;
        gridscrollwrapper_changes.ref = /*container*/
        ctx2[2];
        add_flush_callback(() => updating_ref = false);
      }
      gridscrollwrapper.$set(gridscrollwrapper_changes);
      if (!current || dirty[0] & /*left*/
      8) {
        set_style(
          div1,
          "left",
          /*left*/
          ctx2[3] + "px"
        );
      }
      if (!current || dirty[0] & /*$buttonColumnWidth*/
      1) {
        toggle_class(
          div1,
          "hidden",
          /*$buttonColumnWidth*/
          ctx2[0] === 0
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(gridscrollwrapper.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(gridscrollwrapper.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      destroy_component(gridscrollwrapper);
      mounted = false;
      dispose();
    }
  };
}
function instance$h($$self, $$props, $$invalidate) {
  let buttons;
  let columnsWidth;
  let columnEnd;
  let gridEnd;
  let left;
  let $metadata;
  let $buttonColumnWidth;
  let $width;
  let $scrollLeft;
  let $scrollableColumns;
  let $props;
  let $hoveredRowId;
  let $renderedRows;
  let $selectedRows;
  let $focusedRow;
  let $isDragging;
  let $showVScrollbar;
  let $showHScrollbar;
  let $config;
  const { renderedRows, hoveredRowId, props, width, rows, focusedRow, selectedRows, scrollableColumns, scrollLeft, isDragging, buttonColumnWidth, showVScrollbar, showHScrollbar, dispatch, config, metadata } = getContext("grid");
  component_subscribe($$self, renderedRows, (value) => $$invalidate(6, $renderedRows = value));
  component_subscribe($$self, hoveredRowId, (value) => $$invalidate(5, $hoveredRowId = value));
  component_subscribe($$self, props, (value) => $$invalidate(1, $props = value));
  component_subscribe($$self, width, (value) => $$invalidate(34, $width = value));
  component_subscribe($$self, focusedRow, (value) => $$invalidate(8, $focusedRow = value));
  component_subscribe($$self, selectedRows, (value) => $$invalidate(7, $selectedRows = value));
  component_subscribe($$self, scrollableColumns, (value) => $$invalidate(36, $scrollableColumns = value));
  component_subscribe($$self, scrollLeft, (value) => $$invalidate(35, $scrollLeft = value));
  component_subscribe($$self, isDragging, (value) => $$invalidate(9, $isDragging = value));
  component_subscribe($$self, buttonColumnWidth, (value) => $$invalidate(0, $buttonColumnWidth = value));
  component_subscribe($$self, showVScrollbar, (value) => $$invalidate(10, $showVScrollbar = value));
  component_subscribe($$self, showHScrollbar, (value) => $$invalidate(11, $showHScrollbar = value));
  component_subscribe($$self, config, (value) => $$invalidate(12, $config = value));
  component_subscribe($$self, metadata, (value) => $$invalidate(46, $metadata = value));
  let container;
  const getButtons = ({ buttons: buttons2, buttonsCollapsed }) => {
    let gridButtons = buttons2 || [];
    if (!buttonsCollapsed) {
      return gridButtons.slice(0, 3);
    }
    return gridButtons;
  };
  const getButtonsForRow = (buttons2, row) => {
    var _a;
    if (!buttons2 || !row)
      return buttons2;
    const rowMetadata = ((_a = $metadata == null ? void 0 : $metadata[row._id]) == null ? void 0 : _a.button) || {};
    return buttons2.map((button, index) => {
      const buttonMetadata = rowMetadata[index];
      if (!buttonMetadata)
        return button;
      if (buttonMetadata.hidden)
        return null;
      return { ...button, ...buttonMetadata };
    }).filter((button) => button !== null);
  };
  const handleClick = async (button, row) => {
    var _a;
    await ((_a = button.onClick) == null ? void 0 : _a.call(button, rows.actions.cleanRow(row)));
    await rows.actions.refreshRow(row._id);
  };
  const makeCollapsedButtons = (buttons2, row) => {
    return buttons2.map((button) => ({
      ...button,
      onClick: () => handleClick(button, row)
    }));
  };
  onMount(() => {
    const observer = new ResizeObserver((entries) => {
      var _a, _b;
      const width2 = ((_b = (_a = entries == null ? void 0 : entries[0]) == null ? void 0 : _a.contentRect) == null ? void 0 : _b.width) ?? 0;
      buttonColumnWidth.set(width2 - 1);
    });
    observer.observe(container);
  });
  const mouseenter_handler = (row) => set_store_value(hoveredRowId, $hoveredRowId = row._id, $hoveredRowId);
  const click_handler = (button, row) => handleClick(button, row);
  const mouseenter_handler_1 = (row) => set_store_value(hoveredRowId, $hoveredRowId = row._id, $hoveredRowId);
  const mouseleave_handler = () => set_store_value(hoveredRowId, $hoveredRowId = null, $hoveredRowId);
  const click_handler_1 = () => dispatch("add-row-inline");
  const mouseenter_handler_2 = () => set_store_value(hoveredRowId, $hoveredRowId = BlankRowID, $hoveredRowId);
  const mouseleave_handler_1 = () => set_store_value(hoveredRowId, $hoveredRowId = null, $hoveredRowId);
  function gridscrollwrapper_ref_binding(value) {
    container = value;
    $$invalidate(2, container);
  }
  const mouseleave_handler_2 = () => set_store_value(hoveredRowId, $hoveredRowId = null, $hoveredRowId);
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*$props*/
    2) {
      $$invalidate(4, buttons = getButtons($props));
    }
    if ($$self.$$.dirty[1] & /*$scrollableColumns*/
    32) {
      $$invalidate(33, columnsWidth = $scrollableColumns.reduce((total, col) => total += col.width, 0));
    }
    if ($$self.$$.dirty[1] & /*columnsWidth, $scrollLeft*/
    20) {
      $$invalidate(32, columnEnd = columnsWidth - $scrollLeft - 1);
    }
    if ($$self.$$.dirty[0] & /*$buttonColumnWidth*/
    1 | $$self.$$.dirty[1] & /*$width*/
    8) {
      $$invalidate(31, gridEnd = $width - $buttonColumnWidth - 1);
    }
    if ($$self.$$.dirty[1] & /*columnEnd, gridEnd*/
    3) {
      $$invalidate(3, left = Math.min(columnEnd, gridEnd));
    }
  };
  return [
    $buttonColumnWidth,
    $props,
    container,
    left,
    buttons,
    $hoveredRowId,
    $renderedRows,
    $selectedRows,
    $focusedRow,
    $isDragging,
    $showVScrollbar,
    $showHScrollbar,
    $config,
    renderedRows,
    hoveredRowId,
    props,
    width,
    focusedRow,
    selectedRows,
    scrollableColumns,
    scrollLeft,
    isDragging,
    buttonColumnWidth,
    showVScrollbar,
    showHScrollbar,
    dispatch,
    config,
    metadata,
    getButtonsForRow,
    handleClick,
    makeCollapsedButtons,
    gridEnd,
    columnEnd,
    columnsWidth,
    $width,
    $scrollLeft,
    $scrollableColumns,
    mouseenter_handler,
    click_handler,
    mouseenter_handler_1,
    mouseleave_handler,
    click_handler_1,
    mouseenter_handler_2,
    mouseleave_handler_1,
    gridscrollwrapper_ref_binding,
    mouseleave_handler_2
  ];
}
class ButtonColumn extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$h, create_fragment$h, safe_not_equal, {}, null, [-1, -1]);
  }
}
function get_each_context$6(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[21] = list[i];
  child_ctx[23] = i;
  return child_ctx;
}
function create_each_block$6(ctx) {
  let gridrow;
  let current;
  gridrow = new GridRow({
    props: {
      row: (
        /*row*/
        ctx[21]
      ),
      top: (
        /*idx*/
        ctx[23] === 0
      )
    }
  });
  return {
    c() {
      create_component(gridrow.$$.fragment);
    },
    m(target, anchor) {
      mount_component(gridrow, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const gridrow_changes = {};
      if (dirty & /*$renderedRows*/
      4)
        gridrow_changes.row = /*row*/
        ctx2[21];
      gridrow.$set(gridrow_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(gridrow.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(gridrow.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(gridrow, detaching);
    }
  };
}
function create_if_block_1$7(ctx) {
  let div;
  let gridcell;
  let current;
  let mounted;
  let dispose;
  gridcell = new GridCell({
    props: {
      width: (
        /*columnsWidth*/
        ctx[1]
      ),
      highlighted: (
        /*$hoveredRowId*/
        ctx[5] === BlankRowID
      )
    }
  });
  gridcell.$on(
    "click",
    /*click_handler*/
    ctx[15]
  );
  return {
    c() {
      div = element("div");
      create_component(gridcell.$$.fragment);
      attr(div, "class", "row blank svelte-17lftvb");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(gridcell, div, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(div, "mouseenter", function() {
            if (is_function(
              /*$isDragging*/
              ctx[4] ? null : (
                /*mouseenter_handler*/
                ctx[16]
              )
            ))
              /*$isDragging*/
              (ctx[4] ? null : (
                /*mouseenter_handler*/
                ctx[16]
              )).apply(this, arguments);
          }),
          listen(div, "mouseleave", function() {
            if (is_function(
              /*$isDragging*/
              ctx[4] ? null : (
                /*mouseleave_handler*/
                ctx[17]
              )
            ))
              /*$isDragging*/
              (ctx[4] ? null : (
                /*mouseleave_handler*/
                ctx[17]
              )).apply(this, arguments);
          })
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const gridcell_changes = {};
      if (dirty & /*columnsWidth*/
      2)
        gridcell_changes.width = /*columnsWidth*/
        ctx[1];
      if (dirty & /*$hoveredRowId*/
      32)
        gridcell_changes.highlighted = /*$hoveredRowId*/
        ctx[5] === BlankRowID;
      gridcell.$set(gridcell_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(gridcell.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(gridcell.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(gridcell);
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_default_slot$9(ctx) {
  let t;
  let if_block_anchor;
  let current;
  let each_value = ensure_array_like(
    /*$renderedRows*/
    ctx[2]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$6(get_each_context$6(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  let if_block = (
    /*$config*/
    ctx[3].canAddRows && create_if_block_1$7(ctx)
  );
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*$renderedRows*/
      4) {
        each_value = ensure_array_like(
          /*$renderedRows*/
          ctx2[2]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$6(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$6(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(t.parentNode, t);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      if (
        /*$config*/
        ctx2[3].canAddRows
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*$config*/
          8) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_1$7(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      transition_in(if_block);
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      destroy_each(each_blocks, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block$b(ctx) {
  let buttoncolumn;
  let current;
  buttoncolumn = new ButtonColumn({});
  return {
    c() {
      create_component(buttoncolumn.$$.fragment);
    },
    m(target, anchor) {
      mount_component(buttoncolumn, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(buttoncolumn.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(buttoncolumn.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(buttoncolumn, detaching);
    }
  };
}
function create_fragment$g(ctx) {
  var _a;
  let div;
  let gridscrollwrapper;
  let t;
  let current;
  gridscrollwrapper = new GridScrollWrapper({
    props: {
      scrollHorizontally: true,
      scrollVertically: true,
      attachHandlers: true,
      $$slots: { default: [create_default_slot$9] },
      $$scope: { ctx }
    }
  });
  let if_block = (
    /*$props*/
    ((_a = ctx[6].buttons) == null ? void 0 : _a.length) && create_if_block$b()
  );
  return {
    c() {
      div = element("div");
      create_component(gridscrollwrapper.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      attr(div, "class", "grid-body svelte-17lftvb");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(gridscrollwrapper, div, null);
      append(div, t);
      if (if_block)
        if_block.m(div, null);
      ctx[18](div);
      current = true;
    },
    p(ctx2, [dirty]) {
      var _a2;
      const gridscrollwrapper_changes = {};
      if (dirty & /*$$scope, $isDragging, $hoveredRowId, columnsWidth, $config, $renderedRows*/
      16777278) {
        gridscrollwrapper_changes.$$scope = { dirty, ctx: ctx2 };
      }
      gridscrollwrapper.$set(gridscrollwrapper_changes);
      if (
        /*$props*/
        (_a2 = ctx2[6].buttons) == null ? void 0 : _a2.length
      ) {
        if (if_block) {
          if (dirty & /*$props*/
          64) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$b();
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(gridscrollwrapper.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(gridscrollwrapper.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(gridscrollwrapper);
      if (if_block)
        if_block.d();
      ctx[18](null);
    }
  };
}
function instance$g($$self, $$props, $$invalidate) {
  let columnsWidth;
  let $scrollableColumns;
  let $renderedRows;
  let $config;
  let $isDragging;
  let $hoveredRowId;
  let $props;
  const { bounds, renderedRows, scrollableColumns, hoveredRowId, dispatch, isDragging, config, props } = getContext("grid");
  component_subscribe($$self, renderedRows, (value) => $$invalidate(2, $renderedRows = value));
  component_subscribe($$self, scrollableColumns, (value) => $$invalidate(14, $scrollableColumns = value));
  component_subscribe($$self, hoveredRowId, (value) => $$invalidate(5, $hoveredRowId = value));
  component_subscribe($$self, isDragging, (value) => $$invalidate(4, $isDragging = value));
  component_subscribe($$self, config, (value) => $$invalidate(3, $config = value));
  component_subscribe($$self, props, (value) => $$invalidate(6, $props = value));
  let body;
  const updateBounds = () => {
    bounds.set(body.getBoundingClientRect());
  };
  onMount(() => {
    const resizeObserver = new ResizeObserver(updateBounds);
    resizeObserver.observe(body);
    window.addEventListener("wheel", updateBounds, true);
    return () => {
      resizeObserver.disconnect();
      window.removeEventListener("wheel", updateBounds, true);
    };
  });
  const click_handler = () => dispatch("add-row-inline");
  const mouseenter_handler = () => set_store_value(hoveredRowId, $hoveredRowId = BlankRowID, $hoveredRowId);
  const mouseleave_handler = () => set_store_value(hoveredRowId, $hoveredRowId = null, $hoveredRowId);
  function div_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      body = $$value;
      $$invalidate(0, body);
    });
  }
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$scrollableColumns*/
    16384) {
      $$invalidate(1, columnsWidth = $scrollableColumns.reduce((total, col) => total += col.width, 0));
    }
  };
  return [
    body,
    columnsWidth,
    $renderedRows,
    $config,
    $isDragging,
    $hoveredRowId,
    $props,
    renderedRows,
    scrollableColumns,
    hoveredRowId,
    dispatch,
    isDragging,
    config,
    props,
    $scrollableColumns,
    click_handler,
    mouseenter_handler,
    mouseleave_handler,
    div_binding
  ];
}
class GridBody extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$g, create_fragment$g, safe_not_equal, {});
  }
}
function get_each_context$5(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[12] = list[i];
  return child_ctx;
}
function create_if_block$a(ctx) {
  let each_1_anchor;
  let each_value = ensure_array_like(
    /*$visibleColumns*/
    ctx[1]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$5(get_each_context$5(ctx, each_value, i));
  }
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*getStyle, $visibleColumns, $scrollLeft, $resize, resize*/
      286) {
        each_value = ensure_array_like(
          /*$visibleColumns*/
          ctx2[1]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$5(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$5(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_each_block$5(ctx) {
  let div1;
  let div0;
  let t;
  let div1_style_value;
  let mounted;
  let dispose;
  function mousedown_handler(...args) {
    return (
      /*mousedown_handler*/
      ctx[9](
        /*column*/
        ctx[12],
        ...args
      )
    );
  }
  function touchstart_handler(...args) {
    return (
      /*touchstart_handler*/
      ctx[10](
        /*column*/
        ctx[12],
        ...args
      )
    );
  }
  function dblclick_handler() {
    return (
      /*dblclick_handler*/
      ctx[11](
        /*column*/
        ctx[12]
      )
    );
  }
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      t = space();
      attr(div0, "class", "resize-indicator svelte-be62xg");
      attr(div1, "class", "resize-slider svelte-be62xg");
      attr(div1, "style", div1_style_value = /*getStyle*/
      ctx[8](
        /*column*/
        ctx[12],
        /*$scrollLeft*/
        ctx[3]
      ));
      toggle_class(
        div1,
        "visible",
        /*$resize*/
        ctx[2].column === /*column*/
        ctx[12].name
      );
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      append(div1, t);
      if (!mounted) {
        dispose = [
          listen(div1, "mousedown", mousedown_handler),
          listen(div1, "touchstart", touchstart_handler),
          listen(div1, "dblclick", dblclick_handler)
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*$visibleColumns, $scrollLeft*/
      10 && div1_style_value !== (div1_style_value = /*getStyle*/
      ctx[8](
        /*column*/
        ctx[12],
        /*$scrollLeft*/
        ctx[3]
      ))) {
        attr(div1, "style", div1_style_value);
      }
      if (dirty & /*$resize, $visibleColumns*/
      6) {
        toggle_class(
          div1,
          "visible",
          /*$resize*/
          ctx[2].column === /*column*/
          ctx[12].name
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_fragment$f(ctx) {
  let if_block_anchor;
  let if_block = !/*$isReordering*/
  ctx[0] && create_if_block$a(ctx);
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
    },
    p(ctx2, [dirty]) {
      if (!/*$isReordering*/
      ctx2[0]) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block$a(ctx2);
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance$f($$self, $$props, $$invalidate) {
  let $isReordering;
  let $visibleColumns;
  let $resize;
  let $scrollLeft;
  const { resize, visibleColumns, isReordering, scrollLeft } = getContext("grid");
  component_subscribe($$self, resize, (value) => $$invalidate(2, $resize = value));
  component_subscribe($$self, visibleColumns, (value) => $$invalidate(1, $visibleColumns = value));
  component_subscribe($$self, isReordering, (value) => $$invalidate(0, $isReordering = value));
  component_subscribe($$self, scrollLeft, (value) => $$invalidate(3, $scrollLeft = value));
  const getStyle = (column, scrollLeft2) => {
    let left = column.__left + column.width;
    if (!column.primaryDisplay) {
      left -= scrollLeft2;
    }
    return `left:${left}px;`;
  };
  const mousedown_handler = (column, e) => resize.actions.startResizing(column, e);
  const touchstart_handler = (column, e) => resize.actions.startResizing(column, e);
  const dblclick_handler = (column) => resize.actions.resetSize(column);
  return [
    $isReordering,
    $visibleColumns,
    $resize,
    $scrollLeft,
    resize,
    visibleColumns,
    isReordering,
    scrollLeft,
    getStyle,
    mousedown_handler,
    touchstart_handler,
    dblclick_handler
  ];
}
class ResizeOverlay extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$f, create_fragment$f, safe_not_equal, {});
  }
}
function create_if_block$9(ctx) {
  let div;
  let gridscrollwrapper;
  let current;
  gridscrollwrapper = new GridScrollWrapper({
    props: {
      scrollVertically: true,
      $$slots: { default: [create_default_slot$8] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div = element("div");
      create_component(gridscrollwrapper.$$.fragment);
      attr(div, "class", "reorder-wrapper svelte-1e4eaad");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(gridscrollwrapper, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const gridscrollwrapper_changes = {};
      if (dirty & /*$$scope, style*/
      2097154) {
        gridscrollwrapper_changes.$$scope = { dirty, ctx: ctx2 };
      }
      gridscrollwrapper.$set(gridscrollwrapper_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(gridscrollwrapper.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(gridscrollwrapper.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(gridscrollwrapper);
    }
  };
}
function create_default_slot$8(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      attr(div, "class", "reorder-overlay svelte-1e4eaad");
      attr(
        div,
        "style",
        /*style*/
        ctx[1]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*style*/
      2) {
        attr(
          div,
          "style",
          /*style*/
          ctx2[1]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_fragment$e(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*visible*/
    ctx[0] && create_if_block$9(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (
        /*visible*/
        ctx2[0]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*visible*/
          1) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$9(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance$e($$self, $$props, $$invalidate) {
  let targetColumn;
  let insertAfter;
  let left;
  let height;
  let style;
  let visible;
  let $stickyWidth;
  let $isReordering;
  let $renderedRows;
  let $rowHeight;
  let $scrollLeft;
  let $reorder;
  let $columnLookupMap;
  const { isReordering, reorder, columnLookupMap, rowHeight, renderedRows, scrollLeft, stickyWidth } = getContext("grid");
  component_subscribe($$self, isReordering, (value) => $$invalidate(14, $isReordering = value));
  component_subscribe($$self, reorder, (value) => $$invalidate(18, $reorder = value));
  component_subscribe($$self, columnLookupMap, (value) => $$invalidate(19, $columnLookupMap = value));
  component_subscribe($$self, rowHeight, (value) => $$invalidate(16, $rowHeight = value));
  component_subscribe($$self, renderedRows, (value) => $$invalidate(15, $renderedRows = value));
  component_subscribe($$self, scrollLeft, (value) => $$invalidate(17, $scrollLeft = value));
  component_subscribe($$self, stickyWidth, (value) => $$invalidate(13, $stickyWidth = value));
  const getLeft = (targetColumn2, insertAfter2, scrollLeft2) => {
    if (!targetColumn2) {
      return 0;
    }
    let left2 = targetColumn2.__left - scrollLeft2;
    if (insertAfter2) {
      left2 += targetColumn2.width;
    }
    return left2;
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$columnLookupMap, $reorder*/
    786432) {
      $$invalidate(12, targetColumn = $columnLookupMap[$reorder.targetColumn]);
    }
    if ($$self.$$.dirty & /*$reorder*/
    262144) {
      $$invalidate(11, insertAfter = $reorder.insertAfter);
    }
    if ($$self.$$.dirty & /*targetColumn, insertAfter, $scrollLeft*/
    137216) {
      $$invalidate(9, left = getLeft(targetColumn, insertAfter, $scrollLeft));
    }
    if ($$self.$$.dirty & /*$rowHeight, $renderedRows*/
    98304) {
      $$invalidate(10, height = $rowHeight * $renderedRows.length + DefaultRowHeight);
    }
    if ($$self.$$.dirty & /*left, height*/
    1536) {
      $$invalidate(1, style = `left:${left}px; height:${height}px;`);
    }
    if ($$self.$$.dirty & /*$isReordering, left, $stickyWidth*/
    25088) {
      $$invalidate(0, visible = $isReordering && left >= $stickyWidth);
    }
  };
  return [
    visible,
    style,
    isReordering,
    reorder,
    columnLookupMap,
    rowHeight,
    renderedRows,
    scrollLeft,
    stickyWidth,
    left,
    height,
    insertAfter,
    targetColumn,
    $stickyWidth,
    $isReordering,
    $renderedRows,
    $rowHeight,
    $scrollLeft,
    $reorder,
    $columnLookupMap
  ];
}
class ReorderOverlay extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$e, create_fragment$e, safe_not_equal, {});
  }
}
function create_fragment$d(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      attr(div, "class", "grid-popover-container svelte-ws1j1t");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
class PopoverOverlay extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, null, create_fragment$d, safe_not_equal, {});
  }
}
function create_if_block$8(ctx) {
  let gridpopover;
  let current;
  gridpopover = new GridPopover({
    props: {
      anchor: (
        /*anchor*/
        ctx[2]
      ),
      align: (
        /*$scrollableColumns*/
        ctx[1].length ? "right" : "left"
      ),
      maxHeight: null,
      resizable: true,
      minWidth: 360,
      $$slots: { default: [create_default_slot$7] },
      $$scope: { ctx }
    }
  });
  gridpopover.$on(
    "close",
    /*close*/
    ctx[8]
  );
  return {
    c() {
      create_component(gridpopover.$$.fragment);
    },
    m(target, anchor) {
      mount_component(gridpopover, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const gridpopover_changes = {};
      if (dirty & /*anchor*/
      4)
        gridpopover_changes.anchor = /*anchor*/
        ctx2[2];
      if (dirty & /*$scrollableColumns*/
      2)
        gridpopover_changes.align = /*$scrollableColumns*/
        ctx2[1].length ? "right" : "left";
      if (dirty & /*$$scope*/
      32768) {
        gridpopover_changes.$$scope = { dirty, ctx: ctx2 };
      }
      gridpopover.$set(gridpopover_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(gridpopover.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(gridpopover.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(gridpopover, detaching);
    }
  };
}
function create_default_slot$7(ctx) {
  let div;
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[13].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[15],
    null
  );
  return {
    c() {
      div = element("div");
      if (default_slot)
        default_slot.c();
      attr(div, "class", "content svelte-13f8h1i");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (default_slot) {
        default_slot.m(div, null);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        32768)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[15],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[15]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[15],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_fragment$c(ctx) {
  let div;
  let icon;
  let t;
  let if_block_anchor;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({ props: { name: "plus" } });
  let if_block = (
    /*isOpen*/
    ctx[0] && create_if_block$8(ctx)
  );
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
      attr(div, "id", "add-column-button");
      attr(div, "class", "add svelte-13f8h1i");
      set_style(
        div,
        "left",
        /*left*/
        ctx[3] + "px"
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      ctx[14](div);
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
      if (!mounted) {
        dispose = listen(
          div,
          "click",
          /*open*/
          ctx[7]
        );
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (!current || dirty & /*left*/
      8) {
        set_style(
          div,
          "left",
          /*left*/
          ctx2[3] + "px"
        );
      }
      if (
        /*isOpen*/
        ctx2[0]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*isOpen*/
          1) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$8(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
        detach(t);
        detach(if_block_anchor);
      }
      destroy_component(icon);
      ctx[14](null);
      if (if_block)
        if_block.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance$d($$self, $$props, $$invalidate) {
  let columnsWidth;
  let end;
  let left;
  let $width;
  let $scrollLeft;
  let $scrollableColumns;
  let { $$slots: slots = {}, $$scope } = $$props;
  const { scrollableColumns, scrollLeft, width, subscribe: subscribe2, ui, keyboardBlocked } = getContext("grid");
  component_subscribe($$self, scrollableColumns, (value) => $$invalidate(1, $scrollableColumns = value));
  component_subscribe($$self, scrollLeft, (value) => $$invalidate(12, $scrollLeft = value));
  component_subscribe($$self, width, (value) => $$invalidate(11, $width = value));
  let anchor;
  let isOpen = false;
  const open = () => {
    ui.actions.blur();
    $$invalidate(0, isOpen = true);
  };
  const close = () => {
    $$invalidate(0, isOpen = false);
  };
  onMount(() => subscribe2("close-edit-column", close));
  function div_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      anchor = $$value;
      $$invalidate(2, anchor);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("$$scope" in $$props2)
      $$invalidate(15, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$scrollableColumns*/
    2) {
      $$invalidate(10, columnsWidth = $scrollableColumns.reduce((total, col) => total += col.width, 0));
    }
    if ($$self.$$.dirty & /*columnsWidth, $scrollLeft*/
    5120) {
      $$invalidate(9, end = columnsWidth - 1 - $scrollLeft);
    }
    if ($$self.$$.dirty & /*$width, end*/
    2560) {
      $$invalidate(3, left = Math.min($width - 40, end));
    }
    if ($$self.$$.dirty & /*isOpen*/
    1) {
      keyboardBlocked.set(isOpen);
    }
  };
  return [
    isOpen,
    $scrollableColumns,
    anchor,
    left,
    scrollableColumns,
    scrollLeft,
    width,
    open,
    close,
    end,
    columnsWidth,
    $width,
    $scrollLeft,
    slots,
    div_binding,
    $$scope
  ];
}
class NewColumnButton extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$d, create_fragment$c, safe_not_equal, {});
  }
}
function create_default_slot$6(ctx) {
  let t0;
  let t1_value = (
    /*column*/
    ctx[0].schema.name + ""
  );
  let t1;
  let t2;
  let inlinealert;
  let t3;
  let input;
  let updating_value;
  let current;
  inlinealert = new InlineAlert({
    props: {
      type: "error",
      header: "Are you sure?",
      message: "This will leave bindings which utilised the user relationship column in a state where they will need to be updated to use the new column instead."
    }
  });
  function input_value_binding(value) {
    ctx[5](value);
  }
  let input_props = {
    label: "New column name",
    error: (
      /*error*/
      ctx[2]
    )
  };
  if (
    /*newColumnName*/
    ctx[1] !== void 0
  ) {
    input_props.value = /*newColumnName*/
    ctx[1];
  }
  input = new Input({ props: input_props });
  binding_callbacks.push(() => bind(input, "value", input_value_binding));
  return {
    c() {
      t0 = text('This operation will kick off a migration of the column "');
      t1 = text(t1_value);
      t2 = text('"\n  to a new column, with the name provided - this operation may take a moment to\n  complete.\n\n  ');
      create_component(inlinealert.$$.fragment);
      t3 = space();
      create_component(input.$$.fragment);
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      insert(target, t2, anchor);
      mount_component(inlinealert, target, anchor);
      insert(target, t3, anchor);
      mount_component(input, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if ((!current || dirty & /*column*/
      1) && t1_value !== (t1_value = /*column*/
      ctx2[0].schema.name + ""))
        set_data(t1, t1_value);
      const input_changes = {};
      if (dirty & /*error*/
      4)
        input_changes.error = /*error*/
        ctx2[2];
      if (!updating_value && dirty & /*newColumnName*/
      2) {
        updating_value = true;
        input_changes.value = /*newColumnName*/
        ctx2[1];
        add_flush_callback(() => updating_value = false);
      }
      input.$set(input_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(inlinealert.$$.fragment, local);
      transition_in(input.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(inlinealert.$$.fragment, local);
      transition_out(input.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
        detach(t3);
      }
      destroy_component(inlinealert, detaching);
      destroy_component(input, detaching);
    }
  };
}
function create_fragment$b(ctx) {
  let modalcontent;
  let current;
  modalcontent = new ModalContent({
    props: {
      title: "Migrate column",
      confirmText: "Continue",
      cancelText: "Cancel",
      onConfirm: (
        /*migrateUserColumn*/
        ctx[4]
      ),
      disabled: (
        /*error*/
        ctx[2] !== void 0
      ),
      size: "M",
      $$slots: { default: [create_default_slot$6] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(modalcontent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(modalcontent, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const modalcontent_changes = {};
      if (dirty & /*error*/
      4)
        modalcontent_changes.disabled = /*error*/
        ctx2[2] !== void 0;
      if (dirty & /*$$scope, error, newColumnName, column*/
      1031) {
        modalcontent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modalcontent.$set(modalcontent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(modalcontent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(modalcontent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(modalcontent, detaching);
    }
  };
}
function instance$c($$self, $$props, $$invalidate) {
  let error;
  let $definition;
  const { API, definition, rows } = getContext("grid");
  component_subscribe($$self, definition, (value) => $$invalidate(6, $definition = value));
  let { column } = $$props;
  let newColumnName = `${column.schema.name} migrated`;
  const checkNewColumnName = (newColumnName2) => {
    if (newColumnName2 === "") {
      return "Column name can't be empty.";
    }
    if (newColumnName2 in $definition.schema) {
      return "New column name can't be the same as an existing column name.";
    }
    if (newColumnName2.match(ValidColumnNameRegex) === null) {
      return "Illegal character; must be alpha-numeric.";
    }
  };
  const migrateUserColumn = async () => {
    try {
      await API.migrateColumn($definition._id, column.schema.name, newColumnName);
      notifications.success("Column migrated");
    } catch (e) {
      notifications.error(`Failed to migrate: ${e.message}`);
    }
    await rows.actions.refreshData();
  };
  function input_value_binding(value) {
    newColumnName = value;
    $$invalidate(1, newColumnName);
  }
  $$self.$$set = ($$props2) => {
    if ("column" in $$props2)
      $$invalidate(0, column = $$props2.column);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*newColumnName*/
    2) {
      $$invalidate(2, error = checkNewColumnName(newColumnName));
    }
  };
  return [
    column,
    newColumnName,
    error,
    definition,
    migrateUserColumn,
    input_value_binding
  ];
}
class MigrationModal extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$c, create_fragment$b, safe_not_equal, { column: 0 });
  }
}
function create_default_slot_12$1(ctx) {
  let migrationmodal;
  let current;
  migrationmodal = new MigrationModal({ props: { column: (
    /*column*/
    ctx[0]
  ) } });
  return {
    c() {
      create_component(migrationmodal.$$.fragment);
    },
    m(target, anchor) {
      mount_component(migrationmodal, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const migrationmodal_changes = {};
      if (dirty[0] & /*column*/
      1)
        migrationmodal_changes.column = /*column*/
        ctx2[0];
      migrationmodal.$set(migrationmodal_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(migrationmodal.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(migrationmodal.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(migrationmodal, detaching);
    }
  };
}
function create_if_block_8(ctx) {
  let input_1;
  let mounted;
  let dispose;
  return {
    c() {
      input_1 = element("input");
      attr(input_1, "type", "text");
      attr(input_1, "data-grid-ignore", "");
      attr(input_1, "class", "svelte-1l2zxuu");
    },
    m(target, anchor) {
      insert(target, input_1, anchor);
      ctx[50](input_1);
      set_input_value(
        input_1,
        /*searchValue*/
        ctx[3]
      );
      if (!mounted) {
        dispose = [
          listen(
            input_1,
            "input",
            /*input_1_input_handler*/
            ctx[51]
          ),
          listen(
            input_1,
            "blur",
            /*onBlurInput*/
            ctx[44]
          ),
          listen(
            input_1,
            "click",
            /*click_handler*/
            ctx[52]
          ),
          listen(
            input_1,
            "keydown",
            /*onInputKeyDown*/
            ctx[42]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*searchValue*/
      8 && input_1.value !== /*searchValue*/
      ctx2[3]) {
        set_input_value(
          input_1,
          /*searchValue*/
          ctx2[3]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(input_1);
      }
      ctx[50](null);
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_if_block_7$2(ctx) {
  let div;
  let icon;
  let current;
  icon = new Icon({
    props: {
      name: getColumnIcon(
        /*column*/
        ctx[0]
      ),
      size: "M",
      color: "var(--spectrum-global-color-gray-600)",
      hoverable: true,
      hoverColor: "var(--spectrum-global-color-gray-800)"
    }
  });
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      attr(div, "class", "column-icon svelte-1l2zxuu");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const icon_changes = {};
      if (dirty[0] & /*column*/
      1)
        icon_changes.name = getColumnIcon(
          /*column*/
          ctx2[0]
        );
      icon.$set(icon_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
    }
  };
}
function create_else_block_1$1(ctx) {
  let t;
  let div;
  let icon;
  let current;
  let mounted;
  let dispose;
  let if_block = (
    /*sortedBy*/
    ctx[16] && create_if_block_6$2(ctx)
  );
  icon = new Icon({
    props: {
      hoverable: true,
      size: "S",
      name: "dots-three-vertical"
    }
  });
  return {
    c() {
      if (if_block)
        if_block.c();
      t = space();
      div = element("div");
      create_component(icon.$$.fragment);
      attr(div, "class", "more-icon svelte-1l2zxuu");
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, t, anchor);
      insert(target, div, anchor);
      mount_component(icon, div, null);
      current = true;
      if (!mounted) {
        dispose = listen(
          div,
          "click",
          /*click_handler_1*/
          ctx[53]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (
        /*sortedBy*/
        ctx2[16]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*sortedBy*/
          65536) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_6$2(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(t.parentNode, t);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(div);
      }
      if (if_block)
        if_block.d(detaching);
      destroy_component(icon);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block_5$2(ctx) {
  let div;
  let icon;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({
    props: { hoverable: true, size: "S", name: "x" }
  });
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      attr(div, "class", "clear-icon svelte-1l2zxuu");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      current = true;
      if (!mounted) {
        dispose = listen(
          div,
          "click",
          /*stopSearching*/
          ctx[43]
        );
        mounted = true;
      }
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block_6$2(ctx) {
  let div;
  let icon;
  let current;
  icon = new Icon({
    props: {
      hoverable: true,
      size: "S",
      name: (
        /*$sort*/
        ctx[5].order === SortOrder.DESCENDING ? "sort-descending" : "sort-ascending"
      )
    }
  });
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      attr(div, "class", "sort-indicator svelte-1l2zxuu");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const icon_changes = {};
      if (dirty[0] & /*$sort*/
      32)
        icon_changes.name = /*$sort*/
        ctx2[5].order === SortOrder.DESCENDING ? "sort-descending" : "sort-ascending";
      icon.$set(icon_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
    }
  };
}
function create_default_slot_11$1(ctx) {
  let t0;
  let t1;
  let div0;
  let icon;
  let t2;
  let div1;
  let t3_value = (
    /*column*/
    ctx[0].label + ""
  );
  let t3;
  let t4;
  let current_block_type_index;
  let if_block2;
  let if_block2_anchor;
  let current;
  let mounted;
  let dispose;
  let if_block0 = (
    /*searching*/
    ctx[10] && create_if_block_8(ctx)
  );
  let if_block1 = !/*$config*/
  ctx[4].quiet && create_if_block_7$2(ctx);
  icon = new Icon({
    props: {
      hoverable: true,
      size: "S",
      name: "magnifying-glass"
    }
  });
  const if_block_creators = [create_if_block_5$2, create_else_block_1$1];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*searching*/
      ctx2[10]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block2 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if (if_block0)
        if_block0.c();
      t0 = space();
      if (if_block1)
        if_block1.c();
      t1 = space();
      div0 = element("div");
      create_component(icon.$$.fragment);
      t2 = space();
      div1 = element("div");
      t3 = text(t3_value);
      t4 = space();
      if_block2.c();
      if_block2_anchor = empty();
      attr(div0, "class", "search-icon svelte-1l2zxuu");
      attr(div1, "class", "name svelte-1l2zxuu");
    },
    m(target, anchor) {
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t0, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, t1, anchor);
      insert(target, div0, anchor);
      mount_component(icon, div0, null);
      insert(target, t2, anchor);
      insert(target, div1, anchor);
      append(div1, t3);
      insert(target, t4, anchor);
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block2_anchor, anchor);
      current = true;
      if (!mounted) {
        dispose = listen(
          div0,
          "click",
          /*startSearching*/
          ctx[41]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (
        /*searching*/
        ctx2[10]
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
        } else {
          if_block0 = create_if_block_8(ctx2);
          if_block0.c();
          if_block0.m(t0.parentNode, t0);
        }
      } else if (if_block0) {
        if_block0.d(1);
        if_block0 = null;
      }
      if (!/*$config*/
      ctx2[4].quiet) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty[0] & /*$config*/
          16) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_7$2(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(t1.parentNode, t1);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if ((!current || dirty[0] & /*column*/
      1) && t3_value !== (t3_value = /*column*/
      ctx2[0].label + ""))
        set_data(t3, t3_value);
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block2 = if_blocks[current_block_type_index];
        if (!if_block2) {
          if_block2 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block2.c();
        } else {
          if_block2.p(ctx2, dirty);
        }
        transition_in(if_block2, 1);
        if_block2.m(if_block2_anchor.parentNode, if_block2_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block1);
      transition_in(icon.$$.fragment, local);
      transition_in(if_block2);
      current = true;
    },
    o(local) {
      transition_out(if_block1);
      transition_out(icon.$$.fragment, local);
      transition_out(if_block2);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(div0);
        detach(t2);
        detach(div1);
        detach(t4);
        detach(if_block2_anchor);
      }
      if (if_block0)
        if_block0.d(detaching);
      if (if_block1)
        if_block1.d(detaching);
      destroy_component(icon);
      if_blocks[current_block_type_index].d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block$7(ctx) {
  let gridpopover;
  let current;
  gridpopover = new GridPopover({
    props: {
      anchor: (
        /*anchor*/
        ctx[6]
      ),
      align: "left",
      maxHeight: null,
      resizable: true,
      $$slots: { default: [create_default_slot$5] },
      $$scope: { ctx }
    }
  });
  gridpopover.$on(
    "close",
    /*close*/
    ctx[28]
  );
  return {
    c() {
      create_component(gridpopover.$$.fragment);
    },
    m(target, anchor) {
      mount_component(gridpopover, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const gridpopover_changes = {};
      if (dirty[0] & /*anchor*/
      64)
        gridpopover_changes.anchor = /*anchor*/
        ctx2[6];
      if (dirty[0] & /*editIsOpen, $config, column, canMoveRight, canMoveLeft, $sort, sortingLabels, editable*/
      59569 | dirty[1] & /*$$scope*/
      16777216) {
        gridpopover_changes.$$scope = { dirty, ctx: ctx2 };
      }
      gridpopover.$set(gridpopover_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(gridpopover.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(gridpopover.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(gridpopover, detaching);
    }
  };
}
function create_else_block$2(ctx) {
  let menu;
  let current;
  menu = new Menu$1({
    props: {
      $$slots: { default: [create_default_slot_1$4] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(menu.$$.fragment);
    },
    m(target, anchor) {
      mount_component(menu, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const menu_changes = {};
      if (dirty[0] & /*$config, column, canMoveRight, canMoveLeft, $sort, sortingLabels, editable*/
      59441 | dirty[1] & /*$$scope*/
      16777216) {
        menu_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menu.$set(menu_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(menu.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(menu.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(menu, detaching);
    }
  };
}
function create_if_block_1$6(ctx) {
  let div;
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[48].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[55],
    null
  );
  return {
    c() {
      div = element("div");
      if (default_slot)
        default_slot.c();
      attr(div, "class", "content svelte-1l2zxuu");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (default_slot) {
        default_slot.m(div, null);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty[1] & /*$$scope*/
        16777216)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[55],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[55]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[55],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_if_block_4$2(ctx) {
  let menuitem0;
  let t0;
  let menuitem1;
  let t1;
  let menuitem2;
  let current;
  menuitem0 = new Item({
    props: {
      icon: "pencil",
      disabled: !/*editable*/
      ctx[11],
      $$slots: { default: [create_default_slot_10$1] },
      $$scope: { ctx }
    }
  });
  menuitem0.$on(
    "click",
    /*editColumn*/
    ctx[29]
  );
  menuitem1 = new Item({
    props: {
      icon: "copy",
      $$slots: { default: [create_default_slot_9$1] },
      $$scope: { ctx }
    }
  });
  menuitem1.$on(
    "click",
    /*duplicateColumn*/
    ctx[39]
  );
  menuitem2 = new Item({
    props: {
      icon: "tag",
      disabled: !/*$config*/
      ctx[4].canEditColumns || /*column*/
      ctx[0].primaryDisplay || !canBeDisplayColumn(
        /*column*/
        ctx[0].schema
      ),
      $$slots: { default: [create_default_slot_8$1] },
      $$scope: { ctx }
    }
  });
  menuitem2.$on(
    "click",
    /*makeDisplayColumn*/
    ctx[37]
  );
  return {
    c() {
      create_component(menuitem0.$$.fragment);
      t0 = space();
      create_component(menuitem1.$$.fragment);
      t1 = space();
      create_component(menuitem2.$$.fragment);
    },
    m(target, anchor) {
      mount_component(menuitem0, target, anchor);
      insert(target, t0, anchor);
      mount_component(menuitem1, target, anchor);
      insert(target, t1, anchor);
      mount_component(menuitem2, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const menuitem0_changes = {};
      if (dirty[0] & /*editable*/
      2048)
        menuitem0_changes.disabled = !/*editable*/
        ctx2[11];
      if (dirty[1] & /*$$scope*/
      16777216) {
        menuitem0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem0.$set(menuitem0_changes);
      const menuitem1_changes = {};
      if (dirty[1] & /*$$scope*/
      16777216) {
        menuitem1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem1.$set(menuitem1_changes);
      const menuitem2_changes = {};
      if (dirty[0] & /*$config, column*/
      17)
        menuitem2_changes.disabled = !/*$config*/
        ctx2[4].canEditColumns || /*column*/
        ctx2[0].primaryDisplay || !canBeDisplayColumn(
          /*column*/
          ctx2[0].schema
        );
      if (dirty[1] & /*$$scope*/
      16777216) {
        menuitem2_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem2.$set(menuitem2_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(menuitem0.$$.fragment, local);
      transition_in(menuitem1.$$.fragment, local);
      transition_in(menuitem2.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(menuitem0.$$.fragment, local);
      transition_out(menuitem1.$$.fragment, local);
      transition_out(menuitem2.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
      destroy_component(menuitem0, detaching);
      destroy_component(menuitem1, detaching);
      destroy_component(menuitem2, detaching);
    }
  };
}
function create_default_slot_10$1(ctx) {
  let t;
  return {
    c() {
      t = text("Edit column");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_9$1(ctx) {
  let t;
  return {
    c() {
      t = text("Duplicate column");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_8$1(ctx) {
  let t;
  return {
    c() {
      t = text("Use as display column");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_7$1(ctx) {
  let t0;
  let t1_value = (
    /*sortingLabels*/
    ctx[13].ascending + ""
  );
  let t1;
  return {
    c() {
      t0 = text("Sort ");
      t1 = text(t1_value);
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*sortingLabels*/
      8192 && t1_value !== (t1_value = /*sortingLabels*/
      ctx2[13].ascending + ""))
        set_data(t1, t1_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
    }
  };
}
function create_default_slot_6$2(ctx) {
  let t0;
  let t1_value = (
    /*sortingLabels*/
    ctx[13].descending + ""
  );
  let t1;
  return {
    c() {
      t0 = text("Sort ");
      t1 = text(t1_value);
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*sortingLabels*/
      8192 && t1_value !== (t1_value = /*sortingLabels*/
      ctx2[13].descending + ""))
        set_data(t1, t1_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
    }
  };
}
function create_if_block_2$5(ctx) {
  let menuitem0;
  let t0;
  let menuitem1;
  let t1;
  let menuitem2;
  let t2;
  let if_block_anchor;
  let current;
  menuitem0 = new Item({
    props: {
      disabled: !/*canMoveLeft*/
      ctx[15],
      icon: "caret-left",
      $$slots: { default: [create_default_slot_5$2] },
      $$scope: { ctx }
    }
  });
  menuitem0.$on(
    "click",
    /*moveLeft*/
    ctx[35]
  );
  menuitem1 = new Item({
    props: {
      disabled: !/*canMoveRight*/
      ctx[14],
      icon: "caret-right",
      $$slots: { default: [create_default_slot_4$2] },
      $$scope: { ctx }
    }
  });
  menuitem1.$on(
    "click",
    /*moveRight*/
    ctx[36]
  );
  menuitem2 = new Item({
    props: {
      disabled: !/*$config*/
      ctx[4].canEditColumns || /*column*/
      ctx[0].primaryDisplay || !/*$config*/
      ctx[4].canHideColumns,
      icon: "eye-slash",
      $$slots: { default: [create_default_slot_3$4] },
      $$scope: { ctx }
    }
  });
  menuitem2.$on(
    "click",
    /*hideColumn*/
    ctx[38]
  );
  let if_block = (
    /*$config*/
    ctx[4].canEditColumns && /*column*/
    ctx[0].schema.type === "link" && /*column*/
    ctx[0].schema.tableId === TableNames.USERS && !/*column*/
    ctx[0].schema.autocolumn && create_if_block_3$4(ctx)
  );
  return {
    c() {
      create_component(menuitem0.$$.fragment);
      t0 = space();
      create_component(menuitem1.$$.fragment);
      t1 = space();
      create_component(menuitem2.$$.fragment);
      t2 = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      mount_component(menuitem0, target, anchor);
      insert(target, t0, anchor);
      mount_component(menuitem1, target, anchor);
      insert(target, t1, anchor);
      mount_component(menuitem2, target, anchor);
      insert(target, t2, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const menuitem0_changes = {};
      if (dirty[0] & /*canMoveLeft*/
      32768)
        menuitem0_changes.disabled = !/*canMoveLeft*/
        ctx2[15];
      if (dirty[1] & /*$$scope*/
      16777216) {
        menuitem0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem0.$set(menuitem0_changes);
      const menuitem1_changes = {};
      if (dirty[0] & /*canMoveRight*/
      16384)
        menuitem1_changes.disabled = !/*canMoveRight*/
        ctx2[14];
      if (dirty[1] & /*$$scope*/
      16777216) {
        menuitem1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem1.$set(menuitem1_changes);
      const menuitem2_changes = {};
      if (dirty[0] & /*$config, column*/
      17)
        menuitem2_changes.disabled = !/*$config*/
        ctx2[4].canEditColumns || /*column*/
        ctx2[0].primaryDisplay || !/*$config*/
        ctx2[4].canHideColumns;
      if (dirty[1] & /*$$scope*/
      16777216) {
        menuitem2_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem2.$set(menuitem2_changes);
      if (
        /*$config*/
        ctx2[4].canEditColumns && /*column*/
        ctx2[0].schema.type === "link" && /*column*/
        ctx2[0].schema.tableId === TableNames.USERS && !/*column*/
        ctx2[0].schema.autocolumn
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*$config, column*/
          17) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_3$4(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(menuitem0.$$.fragment, local);
      transition_in(menuitem1.$$.fragment, local);
      transition_in(menuitem2.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(menuitem0.$$.fragment, local);
      transition_out(menuitem1.$$.fragment, local);
      transition_out(menuitem2.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
        detach(if_block_anchor);
      }
      destroy_component(menuitem0, detaching);
      destroy_component(menuitem1, detaching);
      destroy_component(menuitem2, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_default_slot_5$2(ctx) {
  let t;
  return {
    c() {
      t = text("Move left");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_4$2(ctx) {
  let t;
  return {
    c() {
      t = text("Move right");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_3$4(ctx) {
  let t;
  return {
    c() {
      t = text("Hide column");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_3$4(ctx) {
  let menuitem;
  let current;
  menuitem = new Item({
    props: {
      icon: "user",
      $$slots: { default: [create_default_slot_2$4] },
      $$scope: { ctx }
    }
  });
  menuitem.$on(
    "click",
    /*openMigrationModal*/
    ctx[40]
  );
  return {
    c() {
      create_component(menuitem.$$.fragment);
    },
    m(target, anchor) {
      mount_component(menuitem, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const menuitem_changes = {};
      if (dirty[1] & /*$$scope*/
      16777216) {
        menuitem_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem.$set(menuitem_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(menuitem.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(menuitem.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(menuitem, detaching);
    }
  };
}
function create_default_slot_2$4(ctx) {
  let t;
  return {
    c() {
      t = text("Migrate to user column");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_1$4(ctx) {
  let t0;
  let menuitem0;
  let t1;
  let menuitem1;
  let t2;
  let if_block1_anchor;
  let current;
  let if_block0 = (
    /*$config*/
    ctx[4].canEditColumns && create_if_block_4$2(ctx)
  );
  menuitem0 = new Item({
    props: {
      icon: "sort-ascending",
      disabled: !canBeSortColumn(
        /*column*/
        ctx[0].schema
      ) || /*column*/
      ctx[0].name === /*$sort*/
      ctx[5].column && /*$sort*/
      ctx[5].order === SortOrder.ASCENDING,
      $$slots: { default: [create_default_slot_7$1] },
      $$scope: { ctx }
    }
  });
  menuitem0.$on(
    "click",
    /*sortAscending*/
    ctx[33]
  );
  menuitem1 = new Item({
    props: {
      icon: "sort-descending",
      disabled: !canBeSortColumn(
        /*column*/
        ctx[0].schema
      ) || /*column*/
      ctx[0].name === /*$sort*/
      ctx[5].column && /*$sort*/
      ctx[5].order === SortOrder.DESCENDING,
      $$slots: { default: [create_default_slot_6$2] },
      $$scope: { ctx }
    }
  });
  menuitem1.$on(
    "click",
    /*sortDescending*/
    ctx[34]
  );
  let if_block1 = (
    /*$config*/
    ctx[4].canEditColumns && create_if_block_2$5(ctx)
  );
  return {
    c() {
      if (if_block0)
        if_block0.c();
      t0 = space();
      create_component(menuitem0.$$.fragment);
      t1 = space();
      create_component(menuitem1.$$.fragment);
      t2 = space();
      if (if_block1)
        if_block1.c();
      if_block1_anchor = empty();
    },
    m(target, anchor) {
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t0, anchor);
      mount_component(menuitem0, target, anchor);
      insert(target, t1, anchor);
      mount_component(menuitem1, target, anchor);
      insert(target, t2, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, if_block1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*$config*/
        ctx2[4].canEditColumns
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty[0] & /*$config*/
          16) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_4$2(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(t0.parentNode, t0);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      const menuitem0_changes = {};
      if (dirty[0] & /*column, $sort*/
      33)
        menuitem0_changes.disabled = !canBeSortColumn(
          /*column*/
          ctx2[0].schema
        ) || /*column*/
        ctx2[0].name === /*$sort*/
        ctx2[5].column && /*$sort*/
        ctx2[5].order === SortOrder.ASCENDING;
      if (dirty[0] & /*sortingLabels*/
      8192 | dirty[1] & /*$$scope*/
      16777216) {
        menuitem0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem0.$set(menuitem0_changes);
      const menuitem1_changes = {};
      if (dirty[0] & /*column, $sort*/
      33)
        menuitem1_changes.disabled = !canBeSortColumn(
          /*column*/
          ctx2[0].schema
        ) || /*column*/
        ctx2[0].name === /*$sort*/
        ctx2[5].column && /*$sort*/
        ctx2[5].order === SortOrder.DESCENDING;
      if (dirty[0] & /*sortingLabels*/
      8192 | dirty[1] & /*$$scope*/
      16777216) {
        menuitem1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem1.$set(menuitem1_changes);
      if (
        /*$config*/
        ctx2[4].canEditColumns
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty[0] & /*$config*/
          16) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_2$5(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(if_block1_anchor.parentNode, if_block1_anchor);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(menuitem0.$$.fragment, local);
      transition_in(menuitem1.$$.fragment, local);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(menuitem0.$$.fragment, local);
      transition_out(menuitem1.$$.fragment, local);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
        detach(if_block1_anchor);
      }
      if (if_block0)
        if_block0.d(detaching);
      destroy_component(menuitem0, detaching);
      destroy_component(menuitem1, detaching);
      if (if_block1)
        if_block1.d(detaching);
    }
  };
}
function create_default_slot$5(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block_1$6, create_else_block$2];
  const if_blocks = [];
  function select_block_type_1(ctx2, dirty) {
    if (
      /*editIsOpen*/
      ctx2[7]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type_1(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_1(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_fragment$a(ctx) {
  let modal;
  let t0;
  let div;
  let gridcell;
  let t1;
  let if_block_anchor;
  let current;
  let mounted;
  let dispose;
  let modal_props = {
    $$slots: { default: [create_default_slot_12$1] },
    $$scope: { ctx }
  };
  modal = new Modal({ props: modal_props });
  ctx[49](modal);
  gridcell = new GridCell({
    props: {
      width: (
        /*column*/
        ctx[0].width
      ),
      left: (
        /*column*/
        ctx[0].__left
      ),
      defaultHeight: true,
      center: true,
      $$slots: { default: [create_default_slot_11$1] },
      $$scope: { ctx }
    }
  });
  gridcell.$on(
    "mousedown",
    /*onMouseDown*/
    ctx[30]
  );
  gridcell.$on(
    "mouseup",
    /*onMouseUp*/
    ctx[31]
  );
  gridcell.$on(
    "touchstart",
    /*onMouseDown*/
    ctx[30]
  );
  gridcell.$on(
    "touchend",
    /*onMouseUp*/
    ctx[31]
  );
  gridcell.$on(
    "touchcancel",
    /*onMouseUp*/
    ctx[31]
  );
  gridcell.$on(
    "contextmenu",
    /*onContextMenu*/
    ctx[32]
  );
  let if_block = (
    /*open*/
    ctx[2] && create_if_block$7(ctx)
  );
  return {
    c() {
      create_component(modal.$$.fragment);
      t0 = space();
      div = element("div");
      create_component(gridcell.$$.fragment);
      t1 = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
      attr(div, "class", "header-cell svelte-1l2zxuu");
      set_style(div, "flex", "0 0 " + /*column*/
      ctx[0].width + "px");
      toggle_class(
        div,
        "open",
        /*open*/
        ctx[2]
      );
      toggle_class(
        div,
        "searchable",
        /*searchable*/
        ctx[12]
      );
      toggle_class(
        div,
        "searching",
        /*searching*/
        ctx[10]
      );
      toggle_class(
        div,
        "disabled",
        /*$isReordering*/
        ctx[17] || /*$isResizing*/
        ctx[18]
      );
      toggle_class(
        div,
        "sticky",
        /*idx*/
        ctx[1] === "sticky"
      );
    },
    m(target, anchor) {
      mount_component(modal, target, anchor);
      insert(target, t0, anchor);
      insert(target, div, anchor);
      mount_component(gridcell, div, null);
      ctx[54](div);
      insert(target, t1, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
      if (!mounted) {
        dispose = listen(
          div,
          "dblclick",
          /*handleDoubleClick*/
          ctx[45]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      const modal_changes = {};
      if (dirty[0] & /*column*/
      1 | dirty[1] & /*$$scope*/
      16777216) {
        modal_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modal.$set(modal_changes);
      const gridcell_changes = {};
      if (dirty[0] & /*column*/
      1)
        gridcell_changes.width = /*column*/
        ctx2[0].width;
      if (dirty[0] & /*column*/
      1)
        gridcell_changes.left = /*column*/
        ctx2[0].__left;
      if (dirty[0] & /*searching, open, $sort, sortedBy, column, $config, input, searchValue*/
      67133 | dirty[1] & /*$$scope*/
      16777216) {
        gridcell_changes.$$scope = { dirty, ctx: ctx2 };
      }
      gridcell.$set(gridcell_changes);
      if (!current || dirty[0] & /*column*/
      1) {
        set_style(div, "flex", "0 0 " + /*column*/
        ctx2[0].width + "px");
      }
      if (!current || dirty[0] & /*open*/
      4) {
        toggle_class(
          div,
          "open",
          /*open*/
          ctx2[2]
        );
      }
      if (!current || dirty[0] & /*searchable*/
      4096) {
        toggle_class(
          div,
          "searchable",
          /*searchable*/
          ctx2[12]
        );
      }
      if (!current || dirty[0] & /*searching*/
      1024) {
        toggle_class(
          div,
          "searching",
          /*searching*/
          ctx2[10]
        );
      }
      if (!current || dirty[0] & /*$isReordering, $isResizing*/
      393216) {
        toggle_class(
          div,
          "disabled",
          /*$isReordering*/
          ctx2[17] || /*$isResizing*/
          ctx2[18]
        );
      }
      if (!current || dirty[0] & /*idx*/
      2) {
        toggle_class(
          div,
          "sticky",
          /*idx*/
          ctx2[1] === "sticky"
        );
      }
      if (
        /*open*/
        ctx2[2]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*open*/
          4) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$7(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(modal.$$.fragment, local);
      transition_in(gridcell.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(modal.$$.fragment, local);
      transition_out(gridcell.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(div);
        detach(t1);
        detach(if_block_anchor);
      }
      ctx[49](null);
      destroy_component(modal, detaching);
      destroy_component(gridcell);
      ctx[54](null);
      if (if_block)
        if_block.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance$b($$self, $$props, $$invalidate) {
  let sortedBy;
  let canMoveLeft;
  let canMoveRight;
  let sortingLabels;
  let searchable;
  let searching;
  let orderable;
  let editable;
  let $focusedCellId;
  let $schema;
  let $definition;
  let $inlineFilters;
  let $config;
  let $scrollableColumns;
  let $sort;
  let $isReordering;
  let $isResizing;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { column } = $$props;
  let { idx } = $$props;
  const { reorder, isReordering, isResizing, sort, scrollableColumns, dispatch, subscribe: subscribe2, config, ui, definition, datasource, schema, focusedCellId, filter, inlineFilters, keyboardBlocked } = getContext("grid");
  component_subscribe($$self, isReordering, (value) => $$invalidate(17, $isReordering = value));
  component_subscribe($$self, isResizing, (value) => $$invalidate(18, $isResizing = value));
  component_subscribe($$self, sort, (value) => $$invalidate(5, $sort = value));
  component_subscribe($$self, scrollableColumns, (value) => $$invalidate(47, $scrollableColumns = value));
  component_subscribe($$self, config, (value) => $$invalidate(4, $config = value));
  component_subscribe($$self, definition, (value) => $$invalidate(59, $definition = value));
  component_subscribe($$self, schema, (value) => $$invalidate(58, $schema = value));
  component_subscribe($$self, focusedCellId, (value) => $$invalidate(57, $focusedCellId = value));
  component_subscribe($$self, inlineFilters, (value) => $$invalidate(60, $inlineFilters = value));
  const searchableTypes = [
    FieldType.STRING,
    FieldType.OPTIONS,
    FieldType.NUMBER,
    FieldType.BIGINT,
    FieldType.ARRAY,
    FieldType.LONGFORM
  ];
  let anchor;
  let open = false;
  let editIsOpen = false;
  let timeout;
  let migrationModal;
  let searchValue;
  let input;
  const close = () => {
    $$invalidate(2, open = false);
    $$invalidate(7, editIsOpen = false);
  };
  const getSortingLabels = (column2) => {
    var _a;
    if (column2.calculationType) {
      return {
        ascending: "low-high",
        descending: "high-low"
      };
    }
    switch ((_a = column2 == null ? void 0 : column2.schema) == null ? void 0 : _a.type) {
      case FieldType.NUMBER:
      case FieldType.BIGINT:
        return {
          ascending: "low-high",
          descending: "high-low"
        };
      case FieldType.DATETIME:
        return {
          ascending: "old-new",
          descending: "new-old"
        };
      default:
        return { ascending: "A-Z", descending: "Z-A" };
    }
  };
  const resetSearchValue = (name) => {
    var _a;
    $$invalidate(3, searchValue = (_a = $inlineFilters == null ? void 0 : $inlineFilters.find((x) => x.id === `inline-${name}`)) == null ? void 0 : _a.value);
  };
  const isColumnSearchable = (col) => {
    const { type, formulaType } = col.schema;
    return searchableTypes.includes(type) || type === FieldType.FORMULA && formulaType === FormulaType.STATIC || type === FieldType.AI;
  };
  const editColumn = async () => {
    $$invalidate(7, editIsOpen = true);
    await tick();
    dispatch("edit-column", column.schema);
  };
  const onMouseDown = (e) => {
    var _a;
    ui.actions.blur();
    if ((((_a = e.touches) == null ? void 0 : _a.length) || e.button === 0) && orderable) {
      timeout = setTimeout(
        () => {
          reorder.actions.startReordering(column.name, e);
        },
        200
      );
    }
  };
  const onMouseUp = () => {
    if (timeout) {
      clearTimeout(timeout);
      timeout = null;
    }
  };
  const onContextMenu = (e) => {
    e.preventDefault();
    setTimeout(
      () => {
        ui.actions.blur();
        $$invalidate(2, open = !open);
      },
      10
    );
  };
  const sortAscending = () => {
    sort.set({
      column: column.name,
      order: SortOrder.ASCENDING
    });
    $$invalidate(2, open = false);
  };
  const sortDescending = () => {
    sort.set({
      column: column.name,
      order: SortOrder.DESCENDING
    });
    $$invalidate(2, open = false);
  };
  const moveLeft = () => {
    reorder.actions.moveColumnLeft(column.name);
    $$invalidate(2, open = false);
  };
  const moveRight = () => {
    reorder.actions.moveColumnRight(column.name);
    $$invalidate(2, open = false);
  };
  const makeDisplayColumn = () => {
    datasource.actions.changePrimaryDisplay(column.name);
    $$invalidate(2, open = false);
  };
  const hideColumn = () => {
    const { related } = column;
    const mutation = { visible: false };
    if (!related) {
      datasource.actions.addSchemaMutation(column.name, mutation);
    } else {
      datasource.actions.addSubSchemaMutation(related.subField, related.field, mutation);
    }
    datasource.actions.saveSchemaMutations();
    $$invalidate(2, open = false);
  };
  const duplicateColumn = async () => {
    $$invalidate(2, open = false);
    let newName = `${column.name} copy`;
    let attempts = 2;
    while ($schema[newName]) {
      newName = `${column.name} copy ${attempts++}`;
    }
    const existingColumnDefinition = $schema[column.name];
    await datasource.actions.saveDefinition({
      ...$definition,
      schema: {
        ...$schema,
        [newName]: {
          ...existingColumnDefinition,
          name: newName,
          schema: { ...existingColumnDefinition.schema }
        }
      }
    });
  };
  const openMigrationModal = () => {
    migrationModal.show();
    $$invalidate(2, open = false);
  };
  const startSearching = async () => {
    set_store_value(focusedCellId, $focusedCellId = null, $focusedCellId);
    $$invalidate(3, searchValue = "");
    await tick();
    input == null ? void 0 : input.focus();
  };
  const onInputKeyDown = (e) => {
    if (e.key === "Enter") {
      updateFilter();
    } else if (e.key === "Escape") {
      input == null ? void 0 : input.blur();
    }
  };
  const stopSearching = () => {
    $$invalidate(3, searchValue = null);
    updateFilter();
  };
  const onBlurInput = () => {
    if (searchValue === "") {
      $$invalidate(3, searchValue = null);
    }
    updateFilter();
  };
  const updateFilter = () => {
    filter.actions.addInlineFilter(column, searchValue);
  };
  const debouncedUpdateFilter = debounce(updateFilter, 250);
  const handleDoubleClick = () => {
    if (!editable || searching) {
      return;
    }
    $$invalidate(2, open = true);
    editColumn();
  };
  onMount(() => subscribe2("close-edit-column", close));
  function modal_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      migrationModal = $$value;
      $$invalidate(8, migrationModal);
    });
  }
  function input_1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      input = $$value;
      $$invalidate(9, input);
    });
  }
  function input_1_input_handler() {
    searchValue = this.value;
    $$invalidate(3, searchValue);
  }
  const click_handler = () => focusedCellId.set(null);
  const click_handler_1 = () => $$invalidate(2, open = true);
  function div_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      anchor = $$value;
      $$invalidate(6, anchor);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("column" in $$props2)
      $$invalidate(0, column = $$props2.column);
    if ("idx" in $$props2)
      $$invalidate(1, idx = $$props2.idx);
    if ("$$scope" in $$props2)
      $$invalidate(55, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*column, $sort*/
    33) {
      $$invalidate(16, sortedBy = column.name === $sort.column);
    }
    if ($$self.$$.dirty[0] & /*column*/
    1) {
      $$invalidate(46, orderable = !column.primaryDisplay);
    }
    if ($$self.$$.dirty[0] & /*idx*/
    2 | $$self.$$.dirty[1] & /*orderable*/
    32768) {
      $$invalidate(15, canMoveLeft = orderable && idx > 0);
    }
    if ($$self.$$.dirty[0] & /*idx*/
    2 | $$self.$$.dirty[1] & /*orderable, $scrollableColumns*/
    98304) {
      $$invalidate(14, canMoveRight = orderable && idx < $scrollableColumns.length - 1);
    }
    if ($$self.$$.dirty[0] & /*column*/
    1) {
      $$invalidate(13, sortingLabels = getSortingLabels(column));
    }
    if ($$self.$$.dirty[0] & /*column*/
    1) {
      $$invalidate(12, searchable = isColumnSearchable(column));
    }
    if ($$self.$$.dirty[0] & /*column*/
    1) {
      resetSearchValue(column.name);
    }
    if ($$self.$$.dirty[0] & /*searchValue*/
    8) {
      $$invalidate(10, searching = searchValue != null);
    }
    if ($$self.$$.dirty[0] & /*searchValue*/
    8) {
      debouncedUpdateFilter(searchValue);
    }
    if ($$self.$$.dirty[0] & /*$config, column*/
    17) {
      $$invalidate(11, editable = $config.canEditColumns && !column.schema.disabled);
    }
    if ($$self.$$.dirty[0] & /*open*/
    4) {
      keyboardBlocked.set(open);
    }
  };
  return [
    column,
    idx,
    open,
    searchValue,
    $config,
    $sort,
    anchor,
    editIsOpen,
    migrationModal,
    input,
    searching,
    editable,
    searchable,
    sortingLabels,
    canMoveRight,
    canMoveLeft,
    sortedBy,
    $isReordering,
    $isResizing,
    isReordering,
    isResizing,
    sort,
    scrollableColumns,
    config,
    definition,
    schema,
    focusedCellId,
    inlineFilters,
    close,
    editColumn,
    onMouseDown,
    onMouseUp,
    onContextMenu,
    sortAscending,
    sortDescending,
    moveLeft,
    moveRight,
    makeDisplayColumn,
    hideColumn,
    duplicateColumn,
    openMigrationModal,
    startSearching,
    onInputKeyDown,
    stopSearching,
    onBlurInput,
    handleDoubleClick,
    orderable,
    $scrollableColumns,
    slots,
    modal_binding,
    input_1_binding,
    input_1_input_handler,
    click_handler,
    click_handler_1,
    div_binding,
    $$scope
  ];
}
class HeaderCell extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$b, create_fragment$a, safe_not_equal, { column: 0, idx: 1 }, null, [-1, -1, -1]);
  }
}
const get_add_column_slot_changes$1 = (dirty) => ({});
const get_add_column_slot_context$1 = (ctx) => ({});
function get_each_context$4(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[12] = list[i];
  child_ctx[14] = i;
  return child_ctx;
}
const get_edit_column_slot_changes$2 = (dirty) => ({});
const get_edit_column_slot_context$2 = (ctx) => ({});
function create_default_slot_3$3(ctx) {
  let t;
  let current;
  const edit_column_slot_template = (
    /*#slots*/
    ctx[10]["edit-column"]
  );
  const edit_column_slot = create_slot(
    edit_column_slot_template,
    ctx,
    /*$$scope*/
    ctx[11],
    get_edit_column_slot_context$2
  );
  return {
    c() {
      if (edit_column_slot)
        edit_column_slot.c();
      t = space();
    },
    m(target, anchor) {
      if (edit_column_slot) {
        edit_column_slot.m(target, anchor);
      }
      insert(target, t, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (edit_column_slot) {
        if (edit_column_slot.p && (!current || dirty & /*$$scope*/
        2048)) {
          update_slot_base(
            edit_column_slot,
            edit_column_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[11],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[11]
            ) : get_slot_changes(
              edit_column_slot_template,
              /*$$scope*/
              ctx2[11],
              dirty,
              get_edit_column_slot_changes$2
            ),
            get_edit_column_slot_context$2
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(edit_column_slot, local);
      current = true;
    },
    o(local) {
      transition_out(edit_column_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      if (edit_column_slot)
        edit_column_slot.d(detaching);
    }
  };
}
function create_each_block$4(ctx) {
  let headercell;
  let current;
  headercell = new HeaderCell({
    props: {
      column: (
        /*column*/
        ctx[12]
      ),
      idx: (
        /*idx*/
        ctx[14]
      ),
      $$slots: { default: [create_default_slot_3$3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(headercell.$$.fragment);
    },
    m(target, anchor) {
      mount_component(headercell, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const headercell_changes = {};
      if (dirty & /*$scrollableColumns*/
      1)
        headercell_changes.column = /*column*/
        ctx2[12];
      if (dirty & /*$$scope*/
      2048) {
        headercell_changes.$$scope = { dirty, ctx: ctx2 };
      }
      headercell.$set(headercell_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(headercell.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(headercell.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(headercell, detaching);
    }
  };
}
function create_default_slot_2$3(ctx) {
  let div;
  let current;
  let each_value = ensure_array_like(
    /*$scrollableColumns*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$4(get_each_context$4(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "row svelte-1rne7xg");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*$scrollableColumns, $$scope*/
      2049) {
        each_value = ensure_array_like(
          /*$scrollableColumns*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$4(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$4(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div, null);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_if_block$6(ctx) {
  let previous_key = (
    /*$datasource*/
    ctx[2]
  );
  let key_block_anchor;
  let current;
  let key_block = create_key_block$1(ctx);
  return {
    c() {
      key_block.c();
      key_block_anchor = empty();
    },
    m(target, anchor) {
      key_block.m(target, anchor);
      insert(target, key_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*$datasource*/
      4 && safe_not_equal(previous_key, previous_key = /*$datasource*/
      ctx2[2])) {
        group_outros();
        transition_out(key_block, 1, 1, noop);
        check_outros();
        key_block = create_key_block$1(ctx2);
        key_block.c();
        transition_in(key_block, 1);
        key_block.m(key_block_anchor.parentNode, key_block_anchor);
      } else {
        key_block.p(ctx2, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(key_block);
      current = true;
    },
    o(local) {
      transition_out(key_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(key_block_anchor);
      }
      key_block.d(detaching);
    }
  };
}
function create_default_slot_1$3(ctx) {
  let current;
  const add_column_slot_template = (
    /*#slots*/
    ctx[10]["add-column"]
  );
  const add_column_slot = create_slot(
    add_column_slot_template,
    ctx,
    /*$$scope*/
    ctx[11],
    get_add_column_slot_context$1
  );
  return {
    c() {
      if (add_column_slot)
        add_column_slot.c();
    },
    m(target, anchor) {
      if (add_column_slot) {
        add_column_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (add_column_slot) {
        if (add_column_slot.p && (!current || dirty & /*$$scope*/
        2048)) {
          update_slot_base(
            add_column_slot,
            add_column_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[11],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[11]
            ) : get_slot_changes(
              add_column_slot_template,
              /*$$scope*/
              ctx2[11],
              dirty,
              get_add_column_slot_changes$1
            ),
            get_add_column_slot_context$1
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(add_column_slot, local);
      current = true;
    },
    o(local) {
      transition_out(add_column_slot, local);
      current = false;
    },
    d(detaching) {
      if (add_column_slot)
        add_column_slot.d(detaching);
    }
  };
}
function create_default_slot$4(ctx) {
  let newcolumnbutton;
  let current;
  newcolumnbutton = new NewColumnButton({
    props: {
      $$slots: { default: [create_default_slot_1$3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(newcolumnbutton.$$.fragment);
    },
    m(target, anchor) {
      mount_component(newcolumnbutton, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const newcolumnbutton_changes = {};
      if (dirty & /*$$scope*/
      2048) {
        newcolumnbutton_changes.$$scope = { dirty, ctx: ctx2 };
      }
      newcolumnbutton.$set(newcolumnbutton_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(newcolumnbutton.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(newcolumnbutton.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(newcolumnbutton, detaching);
    }
  };
}
function create_key_block$1(ctx) {
  let temptooltip;
  let current;
  temptooltip = new TempTooltip({
    props: {
      text: "Click here to create your first column",
      type: TooltipType.Info,
      condition: !/*$hasNonAutoColumn*/
      ctx[3] && !/*$loading*/
      ctx[4],
      $$slots: { default: [create_default_slot$4] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(temptooltip.$$.fragment);
    },
    m(target, anchor) {
      mount_component(temptooltip, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const temptooltip_changes = {};
      if (dirty & /*$hasNonAutoColumn, $loading*/
      24)
        temptooltip_changes.condition = !/*$hasNonAutoColumn*/
        ctx2[3] && !/*$loading*/
        ctx2[4];
      if (dirty & /*$$scope*/
      2048) {
        temptooltip_changes.$$scope = { dirty, ctx: ctx2 };
      }
      temptooltip.$set(temptooltip_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(temptooltip.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(temptooltip.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(temptooltip, detaching);
    }
  };
}
function create_fragment$9(ctx) {
  let div;
  let gridscrollwrapper;
  let t;
  let current;
  gridscrollwrapper = new GridScrollWrapper({
    props: {
      scrollHorizontally: true,
      $$slots: { default: [create_default_slot_2$3] },
      $$scope: { ctx }
    }
  });
  let if_block = (
    /*$config*/
    ctx[1].canEditColumns && create_if_block$6(ctx)
  );
  return {
    c() {
      div = element("div");
      create_component(gridscrollwrapper.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      attr(div, "class", "header svelte-1rne7xg");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(gridscrollwrapper, div, null);
      append(div, t);
      if (if_block)
        if_block.m(div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      const gridscrollwrapper_changes = {};
      if (dirty & /*$$scope, $scrollableColumns*/
      2049) {
        gridscrollwrapper_changes.$$scope = { dirty, ctx: ctx2 };
      }
      gridscrollwrapper.$set(gridscrollwrapper_changes);
      if (
        /*$config*/
        ctx2[1].canEditColumns
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*$config*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$6(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(gridscrollwrapper.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(gridscrollwrapper.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(gridscrollwrapper);
      if (if_block)
        if_block.d();
    }
  };
}
function instance$a($$self, $$props, $$invalidate) {
  let $scrollableColumns;
  let $config;
  let $datasource;
  let $hasNonAutoColumn;
  let $loading;
  let { $$slots: slots = {}, $$scope } = $$props;
  const { scrollableColumns, config, hasNonAutoColumn, datasource, loading } = getContext("grid");
  component_subscribe($$self, scrollableColumns, (value) => $$invalidate(0, $scrollableColumns = value));
  component_subscribe($$self, config, (value) => $$invalidate(1, $config = value));
  component_subscribe($$self, hasNonAutoColumn, (value) => $$invalidate(3, $hasNonAutoColumn = value));
  component_subscribe($$self, datasource, (value) => $$invalidate(2, $datasource = value));
  component_subscribe($$self, loading, (value) => $$invalidate(4, $loading = value));
  $$self.$$set = ($$props2) => {
    if ("$$scope" in $$props2)
      $$invalidate(11, $$scope = $$props2.$$scope);
  };
  return [
    $scrollableColumns,
    $config,
    $datasource,
    $hasNonAutoColumn,
    $loading,
    scrollableColumns,
    config,
    hasNonAutoColumn,
    datasource,
    loading,
    slots,
    $$scope
  ];
}
class HeaderRow extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$a, create_fragment$9, safe_not_equal, {});
  }
}
function create_if_block_1$5(ctx) {
  let div;
  let mounted;
  let dispose;
  return {
    c() {
      div = element("div");
      attr(div, "class", "v-scrollbar svelte-sio5lm");
      set_style(
        div,
        "top",
        /*barTop*/
        ctx[5] + "px"
      );
      set_style(
        div,
        "height",
        /*barHeight*/
        ctx[3] + "px"
      );
      toggle_class(
        div,
        "dragging",
        /*isDraggingV*/
        ctx[0]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (!mounted) {
        dispose = [
          listen(
            div,
            "mousedown",
            /*startVDragging*/
            ctx[20]
          ),
          listen(
            div,
            "touchstart",
            /*startVDragging*/
            ctx[20]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*barTop*/
      32) {
        set_style(
          div,
          "top",
          /*barTop*/
          ctx2[5] + "px"
        );
      }
      if (dirty[0] & /*barHeight*/
      8) {
        set_style(
          div,
          "height",
          /*barHeight*/
          ctx2[3] + "px"
        );
      }
      if (dirty[0] & /*isDraggingV*/
      1) {
        toggle_class(
          div,
          "dragging",
          /*isDraggingV*/
          ctx2[0]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_if_block$5(ctx) {
  let div;
  let mounted;
  let dispose;
  return {
    c() {
      div = element("div");
      attr(div, "class", "h-scrollbar svelte-sio5lm");
      set_style(
        div,
        "left",
        /*barLeft*/
        ctx[4] + "px"
      );
      set_style(
        div,
        "width",
        /*barWidth*/
        ctx[2] + "px"
      );
      toggle_class(
        div,
        "dragging",
        /*isDraggingH*/
        ctx[1]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (!mounted) {
        dispose = [
          listen(
            div,
            "mousedown",
            /*startHDragging*/
            ctx[21]
          ),
          listen(
            div,
            "touchstart",
            /*startHDragging*/
            ctx[21]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*barLeft*/
      16) {
        set_style(
          div,
          "left",
          /*barLeft*/
          ctx2[4] + "px"
        );
      }
      if (dirty[0] & /*barWidth*/
      4) {
        set_style(
          div,
          "width",
          /*barWidth*/
          ctx2[2] + "px"
        );
      }
      if (dirty[0] & /*isDraggingH*/
      2) {
        toggle_class(
          div,
          "dragging",
          /*isDraggingH*/
          ctx2[1]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_fragment$8(ctx) {
  let t;
  let if_block1_anchor;
  let if_block0 = (
    /*$showVScrollbar*/
    ctx[6] && create_if_block_1$5(ctx)
  );
  let if_block1 = (
    /*$showHScrollbar*/
    ctx[7] && create_if_block$5(ctx)
  );
  return {
    c() {
      if (if_block0)
        if_block0.c();
      t = space();
      if (if_block1)
        if_block1.c();
      if_block1_anchor = empty();
    },
    m(target, anchor) {
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, if_block1_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (
        /*$showVScrollbar*/
        ctx2[6]
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
        } else {
          if_block0 = create_if_block_1$5(ctx2);
          if_block0.c();
          if_block0.m(t.parentNode, t);
        }
      } else if (if_block0) {
        if_block0.d(1);
        if_block0 = null;
      }
      if (
        /*$showHScrollbar*/
        ctx2[7]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
        } else {
          if_block1 = create_if_block$5(ctx2);
          if_block1.c();
          if_block1.m(if_block1_anchor.parentNode, if_block1_anchor);
        }
      } else if (if_block1) {
        if_block1.d(1);
        if_block1 = null;
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block1_anchor);
      }
      if (if_block0)
        if_block0.d(detaching);
      if (if_block1)
        if_block1.d(detaching);
    }
  };
}
function instance$9($$self, $$props, $$invalidate) {
  let renderHeight;
  let barHeight;
  let availHeight;
  let barTop;
  let renderWidth;
  let barWidth;
  let availWidth;
  let barLeft;
  let $maxScrollLeft;
  let $scrollLeft;
  let $maxScrollTop;
  let $scrollTop;
  let $focusedCellAPI;
  let $menu;
  let $contentWidth;
  let $screenWidth;
  let $contentHeight;
  let $height;
  let $showVScrollbar;
  let $showHScrollbar;
  const { scroll, contentHeight, maxScrollTop, contentWidth, maxScrollLeft, screenWidth, showHScrollbar, showVScrollbar, scrollLeft, scrollTop, height, isDragging, menu, focusedCellAPI } = getContext("grid");
  component_subscribe($$self, contentHeight, (value) => $$invalidate(32, $contentHeight = value));
  component_subscribe($$self, maxScrollTop, (value) => $$invalidate(28, $maxScrollTop = value));
  component_subscribe($$self, contentWidth, (value) => $$invalidate(30, $contentWidth = value));
  component_subscribe($$self, maxScrollLeft, (value) => $$invalidate(26, $maxScrollLeft = value));
  component_subscribe($$self, screenWidth, (value) => $$invalidate(31, $screenWidth = value));
  component_subscribe($$self, showHScrollbar, (value) => $$invalidate(7, $showHScrollbar = value));
  component_subscribe($$self, showVScrollbar, (value) => $$invalidate(6, $showVScrollbar = value));
  component_subscribe($$self, scrollLeft, (value) => $$invalidate(27, $scrollLeft = value));
  component_subscribe($$self, scrollTop, (value) => $$invalidate(29, $scrollTop = value));
  component_subscribe($$self, height, (value) => $$invalidate(33, $height = value));
  component_subscribe($$self, menu, (value) => $$invalidate(37, $menu = value));
  component_subscribe($$self, focusedCellAPI, (value) => $$invalidate(36, $focusedCellAPI = value));
  let initialMouse;
  let initialScroll;
  let isDraggingV = false;
  let isDraggingH = false;
  const closePopovers = () => {
    if ($menu.visible) {
      menu.actions.close();
    }
    $focusedCellAPI == null ? void 0 : $focusedCellAPI.blur();
  };
  const startVDragging = (e) => {
    e.preventDefault();
    initialMouse = parseEventLocation(e).y;
    initialScroll = $scrollTop;
    document.addEventListener("mousemove", moveVDragging);
    document.addEventListener("touchmove", moveVDragging);
    document.addEventListener("mouseup", stopVDragging);
    document.addEventListener("touchend", stopVDragging);
    $$invalidate(0, isDraggingV = true);
    closePopovers();
  };
  const moveVDragging = domDebounce((e) => {
    const delta = parseEventLocation(e).y - initialMouse;
    const weight = delta / availHeight;
    const newScrollTop = initialScroll + weight * $maxScrollTop;
    scroll.update((state) => ({
      ...state,
      top: Math.max(0, Math.min(newScrollTop, $maxScrollTop))
    }));
  });
  const stopVDragging = () => {
    document.removeEventListener("mousemove", moveVDragging);
    document.removeEventListener("touchmove", moveVDragging);
    document.removeEventListener("mouseup", stopVDragging);
    document.removeEventListener("touchend", stopVDragging);
    $$invalidate(0, isDraggingV = false);
  };
  const startHDragging = (e) => {
    e.preventDefault();
    initialMouse = parseEventLocation(e).x;
    initialScroll = $scrollLeft;
    document.addEventListener("mousemove", moveHDragging);
    document.addEventListener("touchmove", moveHDragging);
    document.addEventListener("mouseup", stopHDragging);
    document.addEventListener("touchend", stopHDragging);
    $$invalidate(1, isDraggingH = true);
    closePopovers();
  };
  const moveHDragging = domDebounce((e) => {
    const delta = parseEventLocation(e).x - initialMouse;
    const weight = delta / availWidth;
    const newScrollLeft = initialScroll + weight * $maxScrollLeft;
    scroll.update((state) => ({
      ...state,
      left: Math.max(0, Math.min(newScrollLeft, $maxScrollLeft))
    }));
  });
  const stopHDragging = () => {
    document.removeEventListener("mousemove", moveHDragging);
    document.removeEventListener("touchmove", moveHDragging);
    document.removeEventListener("mouseup", stopHDragging);
    document.removeEventListener("touchend", stopHDragging);
    $$invalidate(1, isDraggingH = false);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*isDraggingV, isDraggingH*/
    3) {
      isDragging.set(isDraggingV || isDraggingH);
    }
    if ($$self.$$.dirty[1] & /*$height*/
    4) {
      $$invalidate(25, renderHeight = $height - 2 * ScrollBarSize);
    }
    if ($$self.$$.dirty[0] & /*renderHeight*/
    33554432 | $$self.$$.dirty[1] & /*$height, $contentHeight*/
    6) {
      $$invalidate(3, barHeight = Math.max(50, $height / $contentHeight * renderHeight));
    }
    if ($$self.$$.dirty[0] & /*renderHeight, barHeight*/
    33554440) {
      $$invalidate(23, availHeight = renderHeight - barHeight);
    }
    if ($$self.$$.dirty[0] & /*availHeight, $scrollTop, $maxScrollTop*/
    813694976) {
      $$invalidate(5, barTop = ScrollBarSize + DefaultRowHeight + availHeight * ($scrollTop / $maxScrollTop));
    }
    if ($$self.$$.dirty[1] & /*$screenWidth*/
    1) {
      $$invalidate(24, renderWidth = $screenWidth - 2 * ScrollBarSize);
    }
    if ($$self.$$.dirty[0] & /*$contentWidth, renderWidth*/
    1090519040 | $$self.$$.dirty[1] & /*$screenWidth*/
    1) {
      $$invalidate(2, barWidth = Math.max(50, $screenWidth / $contentWidth * renderWidth));
    }
    if ($$self.$$.dirty[0] & /*renderWidth, barWidth*/
    16777220) {
      $$invalidate(22, availWidth = renderWidth - barWidth);
    }
    if ($$self.$$.dirty[0] & /*availWidth, $scrollLeft, $maxScrollLeft*/
    205520896) {
      $$invalidate(4, barLeft = ScrollBarSize + availWidth * ($scrollLeft / $maxScrollLeft));
    }
  };
  return [
    isDraggingV,
    isDraggingH,
    barWidth,
    barHeight,
    barLeft,
    barTop,
    $showVScrollbar,
    $showHScrollbar,
    contentHeight,
    maxScrollTop,
    contentWidth,
    maxScrollLeft,
    screenWidth,
    showHScrollbar,
    showVScrollbar,
    scrollLeft,
    scrollTop,
    height,
    menu,
    focusedCellAPI,
    startVDragging,
    startHDragging,
    availWidth,
    availHeight,
    renderWidth,
    renderHeight,
    $maxScrollLeft,
    $scrollLeft,
    $maxScrollTop,
    $scrollTop,
    $contentWidth,
    $screenWidth,
    $contentHeight,
    $height
  ];
}
class ScrollOverlay extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$9, create_fragment$8, safe_not_equal, {}, null, [-1, -1]);
  }
}
function create_if_block$4(ctx) {
  let previous_key = (
    /*style*/
    ctx[4]
  );
  let key_block_anchor;
  let current;
  let key_block = create_key_block(ctx);
  return {
    c() {
      key_block.c();
      key_block_anchor = empty();
    },
    m(target, anchor) {
      key_block.m(target, anchor);
      insert(target, key_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*style*/
      16 && safe_not_equal(previous_key, previous_key = /*style*/
      ctx2[4])) {
        group_outros();
        transition_out(key_block, 1, 1, noop);
        check_outros();
        key_block = create_key_block(ctx2);
        key_block.c();
        transition_in(key_block, 1);
        key_block.m(key_block_anchor.parentNode, key_block_anchor);
      } else {
        key_block.p(ctx2, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(key_block);
      current = true;
    },
    o(local) {
      transition_out(key_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(key_block_anchor);
      }
      key_block.d(detaching);
    }
  };
}
function create_else_block$1(ctx) {
  var _a, _b;
  let menuitem0;
  let t0;
  let menuitem1;
  let t1;
  let menuitem2;
  let t2;
  let menuitem3;
  let t3;
  let menuitem4;
  let t4;
  let menuitem5;
  let t5;
  let menuitem6;
  let t6;
  let if_block_anchor;
  let current;
  menuitem0 = new Item({
    props: {
      icon: "copy",
      disabled: !/*$copyAllowed*/
      ctx[8],
      $$slots: { default: [create_default_slot_14] },
      $$scope: { ctx }
    }
  });
  menuitem0.$on(
    "click",
    /*click_handler_5*/
    ctx[36]
  );
  menuitem0.$on(
    "click",
    /*menu*/
    ctx[13].actions.close
  );
  menuitem1 = new Item({
    props: {
      icon: "clipboard-text",
      disabled: !/*$pasteAllowed*/
      ctx[9],
      $$slots: { default: [create_default_slot_13] },
      $$scope: { ctx }
    }
  });
  menuitem1.$on(
    "click",
    /*click_handler_6*/
    ctx[37]
  );
  menuitem1.$on(
    "click",
    /*menu*/
    ctx[13].actions.close
  );
  menuitem2 = new Item({
    props: {
      icon: "arrows-out-simple",
      disabled: (
        /*isNewRow*/
        ctx[3] || !/*$config*/
        ctx[6].canEditRows || !/*$config*/
        ctx[6].canExpandRows
      ),
      $$slots: { default: [create_default_slot_12] },
      $$scope: { ctx }
    }
  });
  menuitem2.$on(
    "click",
    /*click_handler_7*/
    ctx[38]
  );
  menuitem2.$on(
    "click",
    /*menu*/
    ctx[13].actions.close
  );
  menuitem3 = new Item({
    props: {
      icon: "copy",
      disabled: (
        /*isNewRow*/
        ctx[3] || !/*$focusedRow*/
        ((_a = ctx[5]) == null ? void 0 : _a._id) || !/*$hasBudibaseIdentifiers*/
        ctx[11]
      ),
      $$slots: { default: [create_default_slot_11] },
      $$scope: { ctx }
    }
  });
  menuitem3.$on(
    "click",
    /*click_handler_8*/
    ctx[39]
  );
  menuitem3.$on(
    "click",
    /*menu*/
    ctx[13].actions.close
  );
  menuitem4 = new Item({
    props: {
      icon: "copy",
      disabled: (
        /*isNewRow*/
        ctx[3] || !/*$focusedRow*/
        ((_b = ctx[5]) == null ? void 0 : _b._rev) || !/*$hasBudibaseIdentifiers*/
        ctx[11]
      ),
      $$slots: { default: [create_default_slot_10] },
      $$scope: { ctx }
    }
  });
  menuitem4.$on(
    "click",
    /*click_handler_9*/
    ctx[40]
  );
  menuitem4.$on(
    "click",
    /*menu*/
    ctx[13].actions.close
  );
  menuitem5 = new Item({
    props: {
      icon: "copy",
      disabled: (
        /*isNewRow*/
        ctx[3] || !/*$config*/
        ctx[6].canAddRows
      ),
      $$slots: { default: [create_default_slot_9] },
      $$scope: { ctx }
    }
  });
  menuitem5.$on(
    "click",
    /*duplicateRow*/
    ctx[25]
  );
  menuitem6 = new Item({
    props: {
      icon: "trash",
      disabled: (
        /*isNewRow*/
        ctx[3] || !/*$config*/
        ctx[6].canDeleteRows
      ),
      $$slots: { default: [create_default_slot_8] },
      $$scope: { ctx }
    }
  });
  menuitem6.$on(
    "click",
    /*deleteRow*/
    ctx[24]
  );
  let if_block = (
    /*$config*/
    ctx[6].aiEnabled && create_if_block_3$3(ctx)
  );
  return {
    c() {
      create_component(menuitem0.$$.fragment);
      t0 = space();
      create_component(menuitem1.$$.fragment);
      t1 = space();
      create_component(menuitem2.$$.fragment);
      t2 = space();
      create_component(menuitem3.$$.fragment);
      t3 = space();
      create_component(menuitem4.$$.fragment);
      t4 = space();
      create_component(menuitem5.$$.fragment);
      t5 = space();
      create_component(menuitem6.$$.fragment);
      t6 = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      mount_component(menuitem0, target, anchor);
      insert(target, t0, anchor);
      mount_component(menuitem1, target, anchor);
      insert(target, t1, anchor);
      mount_component(menuitem2, target, anchor);
      insert(target, t2, anchor);
      mount_component(menuitem3, target, anchor);
      insert(target, t3, anchor);
      mount_component(menuitem4, target, anchor);
      insert(target, t4, anchor);
      mount_component(menuitem5, target, anchor);
      insert(target, t5, anchor);
      mount_component(menuitem6, target, anchor);
      insert(target, t6, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2, _b2;
      const menuitem0_changes = {};
      if (dirty[0] & /*$copyAllowed*/
      256)
        menuitem0_changes.disabled = !/*$copyAllowed*/
        ctx2[8];
      if (dirty[1] & /*$$scope*/
      16384) {
        menuitem0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem0.$set(menuitem0_changes);
      const menuitem1_changes = {};
      if (dirty[0] & /*$pasteAllowed*/
      512)
        menuitem1_changes.disabled = !/*$pasteAllowed*/
        ctx2[9];
      if (dirty[1] & /*$$scope*/
      16384) {
        menuitem1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem1.$set(menuitem1_changes);
      const menuitem2_changes = {};
      if (dirty[0] & /*isNewRow, $config*/
      72)
        menuitem2_changes.disabled = /*isNewRow*/
        ctx2[3] || !/*$config*/
        ctx2[6].canEditRows || !/*$config*/
        ctx2[6].canExpandRows;
      if (dirty[1] & /*$$scope*/
      16384) {
        menuitem2_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem2.$set(menuitem2_changes);
      const menuitem3_changes = {};
      if (dirty[0] & /*isNewRow, $focusedRow, $hasBudibaseIdentifiers*/
      2088)
        menuitem3_changes.disabled = /*isNewRow*/
        ctx2[3] || !/*$focusedRow*/
        ((_a2 = ctx2[5]) == null ? void 0 : _a2._id) || !/*$hasBudibaseIdentifiers*/
        ctx2[11];
      if (dirty[1] & /*$$scope*/
      16384) {
        menuitem3_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem3.$set(menuitem3_changes);
      const menuitem4_changes = {};
      if (dirty[0] & /*isNewRow, $focusedRow, $hasBudibaseIdentifiers*/
      2088)
        menuitem4_changes.disabled = /*isNewRow*/
        ctx2[3] || !/*$focusedRow*/
        ((_b2 = ctx2[5]) == null ? void 0 : _b2._rev) || !/*$hasBudibaseIdentifiers*/
        ctx2[11];
      if (dirty[1] & /*$$scope*/
      16384) {
        menuitem4_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem4.$set(menuitem4_changes);
      const menuitem5_changes = {};
      if (dirty[0] & /*isNewRow, $config*/
      72)
        menuitem5_changes.disabled = /*isNewRow*/
        ctx2[3] || !/*$config*/
        ctx2[6].canAddRows;
      if (dirty[1] & /*$$scope*/
      16384) {
        menuitem5_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem5.$set(menuitem5_changes);
      const menuitem6_changes = {};
      if (dirty[0] & /*isNewRow, $config*/
      72)
        menuitem6_changes.disabled = /*isNewRow*/
        ctx2[3] || !/*$config*/
        ctx2[6].canDeleteRows;
      if (dirty[1] & /*$$scope*/
      16384) {
        menuitem6_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem6.$set(menuitem6_changes);
      if (
        /*$config*/
        ctx2[6].aiEnabled
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*$config*/
          64) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_3$3(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(menuitem0.$$.fragment, local);
      transition_in(menuitem1.$$.fragment, local);
      transition_in(menuitem2.$$.fragment, local);
      transition_in(menuitem3.$$.fragment, local);
      transition_in(menuitem4.$$.fragment, local);
      transition_in(menuitem5.$$.fragment, local);
      transition_in(menuitem6.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(menuitem0.$$.fragment, local);
      transition_out(menuitem1.$$.fragment, local);
      transition_out(menuitem2.$$.fragment, local);
      transition_out(menuitem3.$$.fragment, local);
      transition_out(menuitem4.$$.fragment, local);
      transition_out(menuitem5.$$.fragment, local);
      transition_out(menuitem6.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
        detach(t3);
        detach(t4);
        detach(t5);
        detach(t6);
        detach(if_block_anchor);
      }
      destroy_component(menuitem0, detaching);
      destroy_component(menuitem1, detaching);
      destroy_component(menuitem2, detaching);
      destroy_component(menuitem3, detaching);
      destroy_component(menuitem4, detaching);
      destroy_component(menuitem5, detaching);
      destroy_component(menuitem6, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block_2$4(ctx) {
  let menuitem0;
  let t0;
  let menuitem1;
  let t1;
  let menuitem2;
  let current;
  menuitem0 = new Item({
    props: {
      icon: "copy",
      disabled: !/*$copyAllowed*/
      ctx[8],
      $$slots: { default: [create_default_slot_6$1] },
      $$scope: { ctx }
    }
  });
  menuitem0.$on(
    "click",
    /*click_handler_2*/
    ctx[33]
  );
  menuitem0.$on(
    "click",
    /*menu*/
    ctx[13].actions.close
  );
  menuitem1 = new Item({
    props: {
      icon: "clipboard-text",
      disabled: !/*$pasteAllowed*/
      ctx[9],
      $$slots: { default: [create_default_slot_5$1] },
      $$scope: { ctx }
    }
  });
  menuitem1.$on(
    "click",
    /*click_handler_3*/
    ctx[34]
  );
  menuitem1.$on(
    "click",
    /*menu*/
    ctx[13].actions.close
  );
  menuitem2 = new Item({
    props: {
      icon: "trash",
      disabled: !/*$config*/
      ctx[6].canEditRows,
      $$slots: { default: [create_default_slot_4$1] },
      $$scope: { ctx }
    }
  });
  menuitem2.$on(
    "click",
    /*click_handler_4*/
    ctx[35]
  );
  return {
    c() {
      create_component(menuitem0.$$.fragment);
      t0 = space();
      create_component(menuitem1.$$.fragment);
      t1 = space();
      create_component(menuitem2.$$.fragment);
    },
    m(target, anchor) {
      mount_component(menuitem0, target, anchor);
      insert(target, t0, anchor);
      mount_component(menuitem1, target, anchor);
      insert(target, t1, anchor);
      mount_component(menuitem2, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const menuitem0_changes = {};
      if (dirty[0] & /*$copyAllowed*/
      256)
        menuitem0_changes.disabled = !/*$copyAllowed*/
        ctx2[8];
      if (dirty[1] & /*$$scope*/
      16384) {
        menuitem0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem0.$set(menuitem0_changes);
      const menuitem1_changes = {};
      if (dirty[0] & /*$pasteAllowed*/
      512)
        menuitem1_changes.disabled = !/*$pasteAllowed*/
        ctx2[9];
      if (dirty[1] & /*$$scope*/
      16384) {
        menuitem1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem1.$set(menuitem1_changes);
      const menuitem2_changes = {};
      if (dirty[0] & /*$config*/
      64)
        menuitem2_changes.disabled = !/*$config*/
        ctx2[6].canEditRows;
      if (dirty[0] & /*$selectedCellCount*/
      1024 | dirty[1] & /*$$scope*/
      16384) {
        menuitem2_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem2.$set(menuitem2_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(menuitem0.$$.fragment, local);
      transition_in(menuitem1.$$.fragment, local);
      transition_in(menuitem2.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(menuitem0.$$.fragment, local);
      transition_out(menuitem1.$$.fragment, local);
      transition_out(menuitem2.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
      destroy_component(menuitem0, detaching);
      destroy_component(menuitem1, detaching);
      destroy_component(menuitem2, detaching);
    }
  };
}
function create_if_block_1$4(ctx) {
  let menuitem0;
  let t;
  let menuitem1;
  let current;
  menuitem0 = new Item({
    props: {
      icon: "copy",
      disabled: !/*$config*/
      ctx[6].canAddRows || /*$selectedRowCount*/
      ctx[7] > 50,
      $$slots: { default: [create_default_slot_3$2] },
      $$scope: { ctx }
    }
  });
  menuitem0.$on(
    "click",
    /*click_handler*/
    ctx[31]
  );
  menuitem0.$on(
    "click",
    /*menu*/
    ctx[13].actions.close
  );
  menuitem1 = new Item({
    props: {
      icon: "trash",
      disabled: !/*$config*/
      ctx[6].canDeleteRows,
      $$slots: { default: [create_default_slot_2$2] },
      $$scope: { ctx }
    }
  });
  menuitem1.$on(
    "click",
    /*click_handler_1*/
    ctx[32]
  );
  menuitem1.$on(
    "click",
    /*menu*/
    ctx[13].actions.close
  );
  return {
    c() {
      create_component(menuitem0.$$.fragment);
      t = space();
      create_component(menuitem1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(menuitem0, target, anchor);
      insert(target, t, anchor);
      mount_component(menuitem1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const menuitem0_changes = {};
      if (dirty[0] & /*$config, $selectedRowCount*/
      192)
        menuitem0_changes.disabled = !/*$config*/
        ctx2[6].canAddRows || /*$selectedRowCount*/
        ctx2[7] > 50;
      if (dirty[0] & /*$selectedRowCount*/
      128 | dirty[1] & /*$$scope*/
      16384) {
        menuitem0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem0.$set(menuitem0_changes);
      const menuitem1_changes = {};
      if (dirty[0] & /*$config*/
      64)
        menuitem1_changes.disabled = !/*$config*/
        ctx2[6].canDeleteRows;
      if (dirty[0] & /*$selectedRowCount*/
      128 | dirty[1] & /*$$scope*/
      16384) {
        menuitem1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem1.$set(menuitem1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(menuitem0.$$.fragment, local);
      transition_in(menuitem1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(menuitem0.$$.fragment, local);
      transition_out(menuitem1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(menuitem0, detaching);
      destroy_component(menuitem1, detaching);
    }
  };
}
function create_default_slot_14(ctx) {
  let t;
  return {
    c() {
      t = text("Copy");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_13(ctx) {
  let t;
  return {
    c() {
      t = text("Paste");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_12(ctx) {
  let t;
  return {
    c() {
      t = text("Edit row in modal");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_11(ctx) {
  let t;
  return {
    c() {
      t = text("Copy row _id");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_10(ctx) {
  let t;
  return {
    c() {
      t = text("Copy row _rev");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_9(ctx) {
  let t;
  return {
    c() {
      t = text("Duplicate row");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_8(ctx) {
  let t;
  return {
    c() {
      t = text("Delete row");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_3$3(ctx) {
  let menuitem;
  let current;
  menuitem = new Item({
    props: {
      icon: "magic-wand",
      disabled: (
        /*isNewRow*/
        ctx[3] || !/*hasAIColumns*/
        ctx[2]
      ),
      $$slots: { default: [create_default_slot_7] },
      $$scope: { ctx }
    }
  });
  menuitem.$on(
    "click",
    /*generateAIColumns*/
    ctx[27]
  );
  return {
    c() {
      create_component(menuitem.$$.fragment);
    },
    m(target, anchor) {
      mount_component(menuitem, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const menuitem_changes = {};
      if (dirty[0] & /*isNewRow, hasAIColumns*/
      12)
        menuitem_changes.disabled = /*isNewRow*/
        ctx2[3] || !/*hasAIColumns*/
        ctx2[2];
      if (dirty[1] & /*$$scope*/
      16384) {
        menuitem_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menuitem.$set(menuitem_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(menuitem.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(menuitem.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(menuitem, detaching);
    }
  };
}
function create_default_slot_7(ctx) {
  let t;
  return {
    c() {
      t = text("Generate AI Columns");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_6$1(ctx) {
  let t;
  return {
    c() {
      t = text("Copy");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_5$1(ctx) {
  let t;
  return {
    c() {
      t = text("Paste");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_4$1(ctx) {
  let t0;
  let t1;
  let t2;
  return {
    c() {
      t0 = text("Delete ");
      t1 = text(
        /*$selectedCellCount*/
        ctx[10]
      );
      t2 = text(" cells");
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      insert(target, t2, anchor);
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*$selectedCellCount*/
      1024)
        set_data(
          t1,
          /*$selectedCellCount*/
          ctx2[10]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
      }
    }
  };
}
function create_default_slot_3$2(ctx) {
  let t0;
  let t1;
  let t2;
  return {
    c() {
      t0 = text("Duplicate ");
      t1 = text(
        /*$selectedRowCount*/
        ctx[7]
      );
      t2 = text(" rows");
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      insert(target, t2, anchor);
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*$selectedRowCount*/
      128)
        set_data(
          t1,
          /*$selectedRowCount*/
          ctx2[7]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
      }
    }
  };
}
function create_default_slot_2$2(ctx) {
  let t0;
  let t1;
  let t2;
  return {
    c() {
      t0 = text("Delete ");
      t1 = text(
        /*$selectedRowCount*/
        ctx[7]
      );
      t2 = text(" rows");
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      insert(target, t2, anchor);
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*$selectedRowCount*/
      128)
        set_data(
          t1,
          /*$selectedRowCount*/
          ctx2[7]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
      }
    }
  };
}
function create_default_slot_1$2(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block_1$4, create_if_block_2$4, create_else_block$1];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*$menu*/
      ctx2[0].multiRowMode
    )
      return 0;
    if (
      /*$menu*/
      ctx2[0].multiCellMode
    )
      return 1;
    return 2;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_default_slot$3(ctx) {
  let menu_1;
  let current;
  menu_1 = new Menu$1({
    props: {
      $$slots: { default: [create_default_slot_1$2] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(menu_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(menu_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const menu_1_changes = {};
      if (dirty[0] & /*$config, $selectedRowCount, $menu, $selectedCellCount, $pasteAllowed, $copyAllowed, isNewRow, hasAIColumns, $focusedRow, $hasBudibaseIdentifiers*/
      4077 | dirty[1] & /*$$scope*/
      16384) {
        menu_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      menu_1.$set(menu_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(menu_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(menu_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(menu_1, detaching);
    }
  };
}
function create_key_block(ctx) {
  let gridpopover;
  let current;
  gridpopover = new GridPopover({
    props: {
      anchor: (
        /*anchor*/
        ctx[1]
      ),
      maxHeight: null,
      $$slots: { default: [create_default_slot$3] },
      $$scope: { ctx }
    }
  });
  gridpopover.$on(
    "close",
    /*menu*/
    ctx[13].actions.close
  );
  return {
    c() {
      create_component(gridpopover.$$.fragment);
    },
    m(target, anchor) {
      mount_component(gridpopover, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const gridpopover_changes = {};
      if (dirty[0] & /*anchor*/
      2)
        gridpopover_changes.anchor = /*anchor*/
        ctx2[1];
      if (dirty[0] & /*$config, $selectedRowCount, $menu, $selectedCellCount, $pasteAllowed, $copyAllowed, isNewRow, hasAIColumns, $focusedRow, $hasBudibaseIdentifiers*/
      4077 | dirty[1] & /*$$scope*/
      16384) {
        gridpopover_changes.$$scope = { dirty, ctx: ctx2 };
      }
      gridpopover.$set(gridpopover_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(gridpopover.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(gridpopover.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(gridpopover, detaching);
    }
  };
}
function create_fragment$7(ctx) {
  let div;
  let t;
  let if_block_anchor;
  let current;
  let if_block = (
    /*$menu*/
    ctx[0].visible && create_if_block$4(ctx)
  );
  return {
    c() {
      div = element("div");
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
      attr(
        div,
        "style",
        /*style*/
        ctx[4]
      );
      attr(div, "class", "menu-anchor svelte-825iyj");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      ctx[30](div);
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (!current || dirty[0] & /*style*/
      16) {
        attr(
          div,
          "style",
          /*style*/
          ctx2[4]
        );
      }
      if (
        /*$menu*/
        ctx2[0].visible
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*$menu*/
          1) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$4(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
        detach(t);
        detach(if_block_anchor);
      }
      ctx[30](null);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance$8($$self, $$props, $$invalidate) {
  let style;
  let isNewRow;
  let hasAIColumns;
  let $notifications;
  let $focusedRowId;
  let $visibleColumns;
  let $focusedRow;
  let $menu;
  let $config;
  let $selectedRowCount;
  let $copyAllowed;
  let $pasteAllowed;
  let $selectedCellCount;
  let $hasBudibaseIdentifiers;
  const { focusedRow, menu, rows, config, dispatch, focusedRowId, notifications: notifications2, hasBudibaseIdentifiers, selectedRowCount, copyAllowed, pasteAllowed, selectedCellCount, visibleColumns, selectedCells } = getContext("grid");
  component_subscribe($$self, focusedRow, (value) => $$invalidate(5, $focusedRow = value));
  component_subscribe($$self, menu, (value) => $$invalidate(0, $menu = value));
  component_subscribe($$self, config, (value) => $$invalidate(6, $config = value));
  component_subscribe($$self, focusedRowId, (value) => $$invalidate(28, $focusedRowId = value));
  component_subscribe($$self, notifications2, (value) => $$invalidate(41, $notifications = value));
  component_subscribe($$self, hasBudibaseIdentifiers, (value) => $$invalidate(11, $hasBudibaseIdentifiers = value));
  component_subscribe($$self, selectedRowCount, (value) => $$invalidate(7, $selectedRowCount = value));
  component_subscribe($$self, copyAllowed, (value) => $$invalidate(8, $copyAllowed = value));
  component_subscribe($$self, pasteAllowed, (value) => $$invalidate(9, $pasteAllowed = value));
  component_subscribe($$self, selectedCellCount, (value) => $$invalidate(10, $selectedCellCount = value));
  component_subscribe($$self, visibleColumns, (value) => $$invalidate(29, $visibleColumns = value));
  let anchor;
  const makeStyle = (menu2) => {
    return `left:${menu2.left}px; top:${menu2.top}px;`;
  };
  const deleteRow = () => {
    menu.actions.close();
    rows.actions.deleteRows([$focusedRow]);
    $notifications.success("Deleted 1 row");
  };
  const duplicateRow = async () => {
    menu.actions.close();
    const newRow = await rows.actions.duplicateRow($focusedRow);
    if (newRow) {
      const firstCol = $visibleColumns[0];
      const lastCol = $visibleColumns[$visibleColumns.length - 1];
      const startCellId = getCellID(newRow._id, firstCol.name);
      const endCellId = getCellID(newRow._id, lastCol.name);
      selectedCells.actions.selectRange(startCellId, endCellId);
    }
  };
  const copyToClipboard$1 = async (value) => {
    await copyToClipboard(value);
    $notifications.success("Copied to clipboard");
  };
  const generateAIColumns = async () => {
    menu.actions.close();
    await rows.actions.applyRowChanges({ rowId: $focusedRowId });
    $notifications.success("Generated AI columns");
  };
  function div_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      anchor = $$value;
      $$invalidate(1, anchor);
    });
  }
  const click_handler = () => dispatch("request-bulk-duplicate");
  const click_handler_1 = () => dispatch("request-bulk-delete");
  const click_handler_2 = () => dispatch("copy");
  const click_handler_3 = () => dispatch("paste");
  const click_handler_4 = () => dispatch("request-bulk-delete");
  const click_handler_5 = () => dispatch("copy");
  const click_handler_6 = () => dispatch("paste");
  const click_handler_7 = () => dispatch("edit-row", $focusedRow);
  const click_handler_8 = () => copyToClipboard$1($focusedRow == null ? void 0 : $focusedRow._id);
  const click_handler_9 = () => copyToClipboard$1($focusedRow == null ? void 0 : $focusedRow._rev);
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*$menu*/
    1) {
      $$invalidate(4, style = makeStyle($menu));
    }
    if ($$self.$$.dirty[0] & /*$focusedRowId*/
    268435456) {
      $$invalidate(3, isNewRow = $focusedRowId === NewRowID);
    }
    if ($$self.$$.dirty[0] & /*$visibleColumns*/
    536870912) {
      $$invalidate(2, hasAIColumns = $visibleColumns.some((col) => col.schema.type === FieldType.AI));
    }
  };
  return [
    $menu,
    anchor,
    hasAIColumns,
    isNewRow,
    style,
    $focusedRow,
    $config,
    $selectedRowCount,
    $copyAllowed,
    $pasteAllowed,
    $selectedCellCount,
    $hasBudibaseIdentifiers,
    focusedRow,
    menu,
    config,
    dispatch,
    focusedRowId,
    notifications2,
    hasBudibaseIdentifiers,
    selectedRowCount,
    copyAllowed,
    pasteAllowed,
    selectedCellCount,
    visibleColumns,
    deleteRow,
    duplicateRow,
    copyToClipboard$1,
    generateAIColumns,
    $focusedRowId,
    $visibleColumns,
    div_binding,
    click_handler,
    click_handler_1,
    click_handler_2,
    click_handler_3,
    click_handler_4,
    click_handler_5,
    click_handler_6,
    click_handler_7,
    click_handler_8,
    click_handler_9
  ];
}
class MenuOverlay extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$8, create_fragment$7, safe_not_equal, {}, null, [-1, -1]);
  }
}
function create_else_block_1(ctx) {
  let div;
  let checkbox;
  let t;
  let if_block_anchor;
  let current;
  let mounted;
  let dispose;
  checkbox = new Checkbox_1({
    props: {
      value: (
        /*rowSelected*/
        ctx[3]
      ),
      disabled: (
        /*disabled*/
        ctx[7]
      )
    }
  });
  let if_block = !/*disableNumber*/
  ctx[5] && create_if_block_2$3(ctx);
  return {
    c() {
      div = element("div");
      create_component(checkbox.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
      attr(div, "class", "checkbox svelte-g7itl0");
      toggle_class(
        div,
        "visible",
        /*disableNumber*/
        ctx[5] || /*rowSelected*/
        ctx[3] || /*rowHovered*/
        ctx[2] || /*rowFocused*/
        ctx[1]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(checkbox, div, null);
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
      if (!mounted) {
        dispose = listen(
          div,
          "click",
          /*select*/
          ctx[10]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      const checkbox_changes = {};
      if (dirty & /*rowSelected*/
      8)
        checkbox_changes.value = /*rowSelected*/
        ctx2[3];
      if (dirty & /*disabled*/
      128)
        checkbox_changes.disabled = /*disabled*/
        ctx2[7];
      checkbox.$set(checkbox_changes);
      if (!current || dirty & /*disableNumber, rowSelected, rowHovered, rowFocused*/
      46) {
        toggle_class(
          div,
          "visible",
          /*disableNumber*/
          ctx2[5] || /*rowSelected*/
          ctx2[3] || /*rowHovered*/
          ctx2[2] || /*rowFocused*/
          ctx2[1]
        );
      }
      if (!/*disableNumber*/
      ctx2[5]) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block_2$3(ctx2);
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(checkbox.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(checkbox.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
        detach(t);
        detach(if_block_anchor);
      }
      destroy_component(checkbox);
      if (if_block)
        if_block.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block_1$3(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[14].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[15],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        32768)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[15],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[15]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[15],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_if_block_2$3(ctx) {
  let div;
  let t_value = (
    /*row*/
    ctx[0].__idx + 1 + ""
  );
  let t;
  return {
    c() {
      div = element("div");
      t = text(t_value);
      attr(div, "class", "number svelte-g7itl0");
      toggle_class(div, "visible", !/*rowSelected*/
      (ctx[3] || /*rowHovered*/
      ctx[2] || /*rowFocused*/
      ctx[1]));
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*row*/
      1 && t_value !== (t_value = /*row*/
      ctx2[0].__idx + 1 + ""))
        set_data(t, t_value);
      if (dirty & /*rowSelected, rowHovered, rowFocused*/
      14) {
        toggle_class(div, "visible", !/*rowSelected*/
        (ctx2[3] || /*rowHovered*/
        ctx2[2] || /*rowFocused*/
        ctx2[1]));
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_else_block(ctx) {
  let div;
  let icon;
  let current;
  icon = new Icon({
    props: {
      size: "S",
      name: "arrows-out-simple",
      hoverable: true
    }
  });
  icon.$on(
    "click",
    /*expand*/
    ctx[12]
  );
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      attr(div, "class", "expand svelte-g7itl0");
      toggle_class(
        div,
        "visible",
        /*$config*/
        ctx[8].canExpandRows && /*expandable*/
        ctx[4]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (!current || dirty & /*$config, expandable*/
      272) {
        toggle_class(
          div,
          "visible",
          /*$config*/
          ctx2[8].canExpandRows && /*expandable*/
          ctx2[4]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
    }
  };
}
function create_if_block$3(ctx) {
  let div;
  let icon;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({
    props: {
      name: "trash",
      size: "S",
      color: "var(--spectrum-global-color-red-400)"
    }
  });
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      attr(div, "class", "delete svelte-g7itl0");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      current = true;
      if (!mounted) {
        dispose = listen(
          div,
          "click",
          /*bulkDelete*/
          ctx[11]
        );
        mounted = true;
      }
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
      mounted = false;
      dispose();
    }
  };
}
function create_default_slot$2(ctx) {
  let div;
  let current_block_type_index;
  let if_block0;
  let t;
  let current_block_type_index_1;
  let if_block1;
  let current;
  const if_block_creators = [create_if_block_1$3, create_else_block_1];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*$$slots*/
      ctx2[13].default
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block0 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  const if_block_creators_1 = [create_if_block$3, create_else_block];
  const if_blocks_1 = [];
  function select_block_type_1(ctx2, dirty) {
    if (
      /*rowSelected*/
      ctx2[3] && /*$config*/
      ctx2[8].canDeleteRows
    )
      return 0;
    return 1;
  }
  current_block_type_index_1 = select_block_type_1(ctx);
  if_block1 = if_blocks_1[current_block_type_index_1] = if_block_creators_1[current_block_type_index_1](ctx);
  return {
    c() {
      div = element("div");
      if_block0.c();
      t = space();
      if_block1.c();
      attr(div, "class", "gutter svelte-g7itl0");
      toggle_class(
        div,
        "selectable",
        /*$config*/
        ctx[8].canSelectRows
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      append(div, t);
      if_blocks_1[current_block_type_index_1].m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block0 = if_blocks[current_block_type_index];
        if (!if_block0) {
          if_block0 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block0.c();
        } else {
          if_block0.p(ctx2, dirty);
        }
        transition_in(if_block0, 1);
        if_block0.m(div, t);
      }
      let previous_block_index_1 = current_block_type_index_1;
      current_block_type_index_1 = select_block_type_1(ctx2);
      if (current_block_type_index_1 === previous_block_index_1) {
        if_blocks_1[current_block_type_index_1].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks_1[previous_block_index_1], 1, 1, () => {
          if_blocks_1[previous_block_index_1] = null;
        });
        check_outros();
        if_block1 = if_blocks_1[current_block_type_index_1];
        if (!if_block1) {
          if_block1 = if_blocks_1[current_block_type_index_1] = if_block_creators_1[current_block_type_index_1](ctx2);
          if_block1.c();
        } else {
          if_block1.p(ctx2, dirty);
        }
        transition_in(if_block1, 1);
        if_block1.m(div, null);
      }
      if (!current || dirty & /*$config*/
      256) {
        toggle_class(
          div,
          "selectable",
          /*$config*/
          ctx2[8].canSelectRows
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
      if_blocks_1[current_block_type_index_1].d();
    }
  };
}
function create_fragment$6(ctx) {
  var _a, _b, _c;
  let gridcell;
  let current;
  gridcell = new GridCell({
    props: {
      width: GutterWidth,
      highlighted: (
        /*rowFocused*/
        ctx[1] || /*rowHovered*/
        ctx[2]
      ),
      selected: (
        /*rowSelected*/
        ctx[3]
      ),
      defaultHeight: (
        /*defaultHeight*/
        ctx[6]
      ),
      rowIdx: (
        /*row*/
        (_a = ctx[0]) == null ? void 0 : _a.__idx
      ),
      metadata: (
        /*row*/
        (_c = (_b = ctx[0]) == null ? void 0 : _b.__metadata) == null ? void 0 : _c.row
      ),
      $$slots: { default: [create_default_slot$2] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(gridcell.$$.fragment);
    },
    m(target, anchor) {
      mount_component(gridcell, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      var _a2, _b2, _c2;
      const gridcell_changes = {};
      if (dirty & /*rowFocused, rowHovered*/
      6)
        gridcell_changes.highlighted = /*rowFocused*/
        ctx2[1] || /*rowHovered*/
        ctx2[2];
      if (dirty & /*rowSelected*/
      8)
        gridcell_changes.selected = /*rowSelected*/
        ctx2[3];
      if (dirty & /*defaultHeight*/
      64)
        gridcell_changes.defaultHeight = /*defaultHeight*/
        ctx2[6];
      if (dirty & /*row*/
      1)
        gridcell_changes.rowIdx = /*row*/
        (_a2 = ctx2[0]) == null ? void 0 : _a2.__idx;
      if (dirty & /*row*/
      1)
        gridcell_changes.metadata = /*row*/
        (_c2 = (_b2 = ctx2[0]) == null ? void 0 : _b2.__metadata) == null ? void 0 : _c2.row;
      if (dirty & /*$$scope, $config, rowSelected, expandable, $$slots, rowHovered, rowFocused, row, disableNumber, disabled*/
      41407) {
        gridcell_changes.$$scope = { dirty, ctx: ctx2 };
      }
      gridcell.$set(gridcell_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(gridcell.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(gridcell.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(gridcell, detaching);
    }
  };
}
function instance$7($$self, $$props, $$invalidate) {
  let $config;
  let { $$slots: slots = {}, $$scope } = $$props;
  const $$slots = compute_slots(slots);
  let { row } = $$props;
  let { rowFocused = false } = $$props;
  let { rowHovered = false } = $$props;
  let { rowSelected = false } = $$props;
  let { expandable = false } = $$props;
  let { disableNumber = false } = $$props;
  let { defaultHeight = false } = $$props;
  let { disabled = false } = $$props;
  const { config, dispatch, selectedRows } = getContext("grid");
  component_subscribe($$self, config, (value) => $$invalidate(8, $config = value));
  const svelteDispatch = createEventDispatcher();
  const select = (e) => {
    e.stopPropagation();
    svelteDispatch("select");
    const id = row == null ? void 0 : row._id;
    if (id) {
      if (e.shiftKey) {
        if (rowSelected) {
          e.preventDefault();
        } else {
          selectedRows.actions.bulkSelectRows(id);
        }
      } else {
        selectedRows.actions.toggleRow(id);
      }
    }
  };
  const bulkDelete = (e) => {
    e.stopPropagation();
    dispatch("request-bulk-delete");
  };
  const expand = (e) => {
    e.stopPropagation();
    svelteDispatch("expand");
  };
  $$self.$$set = ($$props2) => {
    if ("row" in $$props2)
      $$invalidate(0, row = $$props2.row);
    if ("rowFocused" in $$props2)
      $$invalidate(1, rowFocused = $$props2.rowFocused);
    if ("rowHovered" in $$props2)
      $$invalidate(2, rowHovered = $$props2.rowHovered);
    if ("rowSelected" in $$props2)
      $$invalidate(3, rowSelected = $$props2.rowSelected);
    if ("expandable" in $$props2)
      $$invalidate(4, expandable = $$props2.expandable);
    if ("disableNumber" in $$props2)
      $$invalidate(5, disableNumber = $$props2.disableNumber);
    if ("defaultHeight" in $$props2)
      $$invalidate(6, defaultHeight = $$props2.defaultHeight);
    if ("disabled" in $$props2)
      $$invalidate(7, disabled = $$props2.disabled);
    if ("$$scope" in $$props2)
      $$invalidate(15, $$scope = $$props2.$$scope);
  };
  return [
    row,
    rowFocused,
    rowHovered,
    rowSelected,
    expandable,
    disableNumber,
    defaultHeight,
    disabled,
    $config,
    config,
    select,
    bulkDelete,
    expand,
    $$slots,
    slots,
    $$scope
  ];
}
class GutterCell extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$7, create_fragment$6, safe_not_equal, {
      row: 0,
      rowFocused: 1,
      rowHovered: 2,
      rowSelected: 3,
      expandable: 4,
      disableNumber: 5,
      defaultHeight: 6,
      disabled: 7
    });
  }
}
function get_each_context$3(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[5] = list[i];
  return child_ctx;
}
function create_each_block$3(ctx) {
  let div;
  let t0_value = (
    /*key*/
    ctx[5] + ""
  );
  let t0;
  let t1;
  return {
    c() {
      div = element("div");
      t0 = text(t0_value);
      t1 = space();
      attr(div, "class", "key svelte-uhg3e3");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t0);
      append(div, t1);
    },
    p(ctx2, dirty) {
      if (dirty & /*parsedKeys*/
      4 && t0_value !== (t0_value = /*key*/
      ctx2[5] + ""))
        set_data(t0, t0_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_fragment$5(ctx) {
  let div;
  let each_value = ensure_array_like(
    /*parsedKeys*/
    ctx[2]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$3(get_each_context$3(ctx, each_value, i));
  }
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "keys svelte-uhg3e3");
      toggle_class(
        div,
        "padded",
        /*padded*/
        ctx[0]
      );
      toggle_class(
        div,
        "overlay",
        /*overlay*/
        ctx[1]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & /*parsedKeys*/
      4) {
        each_value = ensure_array_like(
          /*parsedKeys*/
          ctx2[2]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$3(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$3(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
      if (dirty & /*padded*/
      1) {
        toggle_class(
          div,
          "padded",
          /*padded*/
          ctx2[0]
        );
      }
      if (dirty & /*overlay*/
      2) {
        toggle_class(
          div,
          "overlay",
          /*overlay*/
          ctx2[1]
        );
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function instance$6($$self, $$props, $$invalidate) {
  let parsedKeys;
  let { keybind } = $$props;
  let { padded = false } = $$props;
  let { overlay = false } = $$props;
  const parseKeys = (keybind2) => {
    return keybind2 == null ? void 0 : keybind2.split("+").map((key) => {
      if (key.toLowerCase() === "ctrl") {
        return navigator.platform.startsWith("Mac") ? "⌘" : key;
      } else if (key.toLowerCase() === "enter") {
        return "↵";
      }
      return key;
    });
  };
  $$self.$$set = ($$props2) => {
    if ("keybind" in $$props2)
      $$invalidate(3, keybind = $$props2.keybind);
    if ("padded" in $$props2)
      $$invalidate(0, padded = $$props2.padded);
    if ("overlay" in $$props2)
      $$invalidate(1, overlay = $$props2.overlay);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*keybind*/
    8) {
      $$invalidate(2, parsedKeys = parseKeys(keybind));
    }
  };
  return [padded, overlay, parsedKeys, keybind];
}
class KeyboardShortcut extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$6, create_fragment$5, safe_not_equal, { keybind: 3, padded: 0, overlay: 1 });
  }
}
function get_each_context$2(ctx, list, i) {
  var _a, _b;
  const child_ctx = ctx.slice();
  child_ctx[43] = list[i];
  child_ctx[49] = i;
  const constants_0 = !!/*$selectedRows*/
  child_ctx[0][
    /*row*/
    child_ctx[43]._id
  ];
  child_ctx[44] = constants_0;
  const constants_1 = (
    /*$hoveredRowId*/
    child_ctx[7] === /*row*/
    child_ctx[43]._id && (!/*$selectedCellCount*/
    child_ctx[8] || !/*$isSelectingCells*/
    child_ctx[9])
  );
  child_ctx[45] = constants_1;
  const constants_2 = (
    /*$focusedRow*/
    ((_a = child_ctx[10]) == null ? void 0 : _a._id) === /*row*/
    child_ctx[43]._id
  );
  child_ctx[46] = constants_2;
  const constants_3 = getCellID(
    /*row*/
    child_ctx[43]._id,
    /*$displayColumn*/
    (_b = child_ctx[1]) == null ? void 0 : _b.name
  );
  child_ctx[47] = constants_3;
  return child_ctx;
}
const get_edit_column_slot_changes$1 = (dirty) => ({});
const get_edit_column_slot_context$1 = (ctx) => ({});
function create_if_block_3$2(ctx) {
  let headercell;
  let current;
  headercell = new HeaderCell({
    props: {
      column: (
        /*$displayColumn*/
        ctx[1]
      ),
      orderable: false,
      idx: "sticky",
      $$slots: { default: [create_default_slot_3$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(headercell.$$.fragment);
    },
    m(target, anchor) {
      mount_component(headercell, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const headercell_changes = {};
      if (dirty[0] & /*$displayColumn*/
      2)
        headercell_changes.column = /*$displayColumn*/
        ctx2[1];
      if (dirty[1] & /*$$scope*/
      2048) {
        headercell_changes.$$scope = { dirty, ctx: ctx2 };
      }
      headercell.$set(headercell_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(headercell.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(headercell.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(headercell, detaching);
    }
  };
}
function create_default_slot_3$1(ctx) {
  let current;
  const edit_column_slot_template = (
    /*#slots*/
    ctx[35]["edit-column"]
  );
  const edit_column_slot = create_slot(
    edit_column_slot_template,
    ctx,
    /*$$scope*/
    ctx[42],
    get_edit_column_slot_context$1
  );
  return {
    c() {
      if (edit_column_slot)
        edit_column_slot.c();
    },
    m(target, anchor) {
      if (edit_column_slot) {
        edit_column_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (edit_column_slot) {
        if (edit_column_slot.p && (!current || dirty[1] & /*$$scope*/
        2048)) {
          update_slot_base(
            edit_column_slot,
            edit_column_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[42],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[42]
            ) : get_slot_changes(
              edit_column_slot_template,
              /*$$scope*/
              ctx2[42],
              dirty,
              get_edit_column_slot_changes$1
            ),
            get_edit_column_slot_context$1
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(edit_column_slot, local);
      current = true;
    },
    o(local) {
      transition_out(edit_column_slot, local);
      current = false;
    },
    d(detaching) {
      if (edit_column_slot)
        edit_column_slot.d(detaching);
    }
  };
}
function create_if_block_2$2(ctx) {
  let datacell;
  let current;
  datacell = new DataCell({
    props: {
      row: (
        /*row*/
        ctx[43]
      ),
      cellId: (
        /*cellId*/
        ctx[47]
      ),
      rowFocused: (
        /*rowFocused*/
        ctx[46]
      ),
      rowSelected: (
        /*rowSelected*/
        ctx[44]
      ),
      cellSelected: (
        /*$selectedCellMap*/
        ctx[12][
          /*cellId*/
          ctx[47]
        ]
      ),
      highlighted: (
        /*rowHovered*/
        ctx[45] || /*rowFocused*/
        ctx[46]
      ),
      rowIdx: (
        /*row*/
        ctx[43].__idx
      ),
      topRow: (
        /*idx*/
        ctx[49] === 0
      ),
      focused: (
        /*$focusedCellId*/
        ctx[13] === /*cellId*/
        ctx[47]
      ),
      selectedUser: (
        /*$userCellMap*/
        ctx[14][
          /*cellId*/
          ctx[47]
        ]
      ),
      width: (
        /*$displayColumn*/
        ctx[1].width
      ),
      column: (
        /*$displayColumn*/
        ctx[1]
      ),
      contentLines: (
        /*$contentLines*/
        ctx[15]
      ),
      isSelectingCells: (
        /*$isSelectingCells*/
        ctx[9]
      )
    }
  });
  return {
    c() {
      create_component(datacell.$$.fragment);
    },
    m(target, anchor) {
      mount_component(datacell, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const datacell_changes = {};
      if (dirty[0] & /*$renderedRows*/
      64)
        datacell_changes.row = /*row*/
        ctx2[43];
      if (dirty[0] & /*$renderedRows, $displayColumn*/
      66)
        datacell_changes.cellId = /*cellId*/
        ctx2[47];
      if (dirty[0] & /*$focusedRow, $renderedRows*/
      1088)
        datacell_changes.rowFocused = /*rowFocused*/
        ctx2[46];
      if (dirty[0] & /*$selectedRows, $renderedRows*/
      65)
        datacell_changes.rowSelected = /*rowSelected*/
        ctx2[44];
      if (dirty[0] & /*$selectedCellMap, $renderedRows, $displayColumn*/
      4162)
        datacell_changes.cellSelected = /*$selectedCellMap*/
        ctx2[12][
          /*cellId*/
          ctx2[47]
        ];
      if (dirty[0] & /*$hoveredRowId, $renderedRows, $selectedCellCount, $isSelectingCells, $focusedRow*/
      1984)
        datacell_changes.highlighted = /*rowHovered*/
        ctx2[45] || /*rowFocused*/
        ctx2[46];
      if (dirty[0] & /*$renderedRows*/
      64)
        datacell_changes.rowIdx = /*row*/
        ctx2[43].__idx;
      if (dirty[0] & /*$focusedCellId, $renderedRows, $displayColumn*/
      8258)
        datacell_changes.focused = /*$focusedCellId*/
        ctx2[13] === /*cellId*/
        ctx2[47];
      if (dirty[0] & /*$userCellMap, $renderedRows, $displayColumn*/
      16450)
        datacell_changes.selectedUser = /*$userCellMap*/
        ctx2[14][
          /*cellId*/
          ctx2[47]
        ];
      if (dirty[0] & /*$displayColumn*/
      2)
        datacell_changes.width = /*$displayColumn*/
        ctx2[1].width;
      if (dirty[0] & /*$displayColumn*/
      2)
        datacell_changes.column = /*$displayColumn*/
        ctx2[1];
      if (dirty[0] & /*$contentLines*/
      32768)
        datacell_changes.contentLines = /*$contentLines*/
        ctx2[15];
      if (dirty[0] & /*$isSelectingCells*/
      512)
        datacell_changes.isSelectingCells = /*$isSelectingCells*/
        ctx2[9];
      datacell.$set(datacell_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(datacell.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(datacell.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(datacell, detaching);
    }
  };
}
function create_each_block$2(ctx) {
  let div;
  let guttercell;
  let t;
  let current;
  let mounted;
  let dispose;
  guttercell = new GutterCell({
    props: {
      row: (
        /*row*/
        ctx[43]
      ),
      rowFocused: (
        /*rowFocused*/
        ctx[46]
      ),
      rowHovered: (
        /*rowHovered*/
        ctx[45]
      ),
      rowSelected: (
        /*rowSelected*/
        ctx[44]
      )
    }
  });
  let if_block = (
    /*$displayColumn*/
    ctx[1] && create_if_block_2$2(ctx)
  );
  function mouseenter_handler() {
    return (
      /*mouseenter_handler*/
      ctx[36](
        /*row*/
        ctx[43]
      )
    );
  }
  function click_handler() {
    return (
      /*click_handler*/
      ctx[38](
        /*row*/
        ctx[43]
      )
    );
  }
  return {
    c() {
      div = element("div");
      create_component(guttercell.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      attr(div, "class", "row svelte-15yu3r0");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(guttercell, div, null);
      append(div, t);
      if (if_block)
        if_block.m(div, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(div, "mouseenter", function() {
            if (is_function(
              /*$isDragging*/
              ctx[11] ? null : mouseenter_handler
            ))
              /*$isDragging*/
              (ctx[11] ? null : mouseenter_handler).apply(this, arguments);
          }),
          listen(div, "mouseleave", function() {
            if (is_function(
              /*$isDragging*/
              ctx[11] ? null : (
                /*mouseleave_handler*/
                ctx[37]
              )
            ))
              /*$isDragging*/
              (ctx[11] ? null : (
                /*mouseleave_handler*/
                ctx[37]
              )).apply(this, arguments);
          }),
          listen(div, "click", click_handler)
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const guttercell_changes = {};
      if (dirty[0] & /*$renderedRows*/
      64)
        guttercell_changes.row = /*row*/
        ctx[43];
      if (dirty[0] & /*$focusedRow, $renderedRows*/
      1088)
        guttercell_changes.rowFocused = /*rowFocused*/
        ctx[46];
      if (dirty[0] & /*$hoveredRowId, $renderedRows, $selectedCellCount, $isSelectingCells*/
      960)
        guttercell_changes.rowHovered = /*rowHovered*/
        ctx[45];
      if (dirty[0] & /*$selectedRows, $renderedRows*/
      65)
        guttercell_changes.rowSelected = /*rowSelected*/
        ctx[44];
      guttercell.$set(guttercell_changes);
      if (
        /*$displayColumn*/
        ctx[1]
      ) {
        if (if_block) {
          if_block.p(ctx, dirty);
          if (dirty[0] & /*$displayColumn*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_2$2(ctx);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(guttercell.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(guttercell.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(guttercell);
      if (if_block)
        if_block.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_if_block$2(ctx) {
  let div;
  let guttercell;
  let t;
  let current;
  let mounted;
  let dispose;
  guttercell = new GutterCell({
    props: {
      rowHovered: (
        /*$hoveredRowId*/
        ctx[7] === BlankRowID
      ),
      $$slots: { default: [create_default_slot_2$1] },
      $$scope: { ctx }
    }
  });
  let if_block = (
    /*$displayColumn*/
    ctx[1] && create_if_block_1$2(ctx)
  );
  return {
    c() {
      div = element("div");
      create_component(guttercell.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      attr(div, "class", "row blank svelte-15yu3r0");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(guttercell, div, null);
      append(div, t);
      if (if_block)
        if_block.m(div, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(div, "mouseenter", function() {
            if (is_function(
              /*$isDragging*/
              ctx[11] ? null : (
                /*mouseenter_handler_1*/
                ctx[39]
              )
            ))
              /*$isDragging*/
              (ctx[11] ? null : (
                /*mouseenter_handler_1*/
                ctx[39]
              )).apply(this, arguments);
          }),
          listen(div, "mouseleave", function() {
            if (is_function(
              /*$isDragging*/
              ctx[11] ? null : (
                /*mouseleave_handler_1*/
                ctx[40]
              )
            ))
              /*$isDragging*/
              (ctx[11] ? null : (
                /*mouseleave_handler_1*/
                ctx[40]
              )).apply(this, arguments);
          }),
          listen(
            div,
            "click",
            /*click_handler_1*/
            ctx[41]
          )
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const guttercell_changes = {};
      if (dirty[0] & /*$hoveredRowId*/
      128)
        guttercell_changes.rowHovered = /*$hoveredRowId*/
        ctx[7] === BlankRowID;
      if (dirty[1] & /*$$scope*/
      2048) {
        guttercell_changes.$$scope = { dirty, ctx };
      }
      guttercell.$set(guttercell_changes);
      if (
        /*$displayColumn*/
        ctx[1]
      ) {
        if (if_block) {
          if_block.p(ctx, dirty);
          if (dirty[0] & /*$displayColumn*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_1$2(ctx);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(guttercell.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(guttercell.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(guttercell);
      if (if_block)
        if_block.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_default_slot_2$1(ctx) {
  let icon;
  let current;
  icon = new Icon({
    props: {
      name: "plus",
      color: "var(--spectrum-global-color-gray-500)"
    }
  });
  return {
    c() {
      create_component(icon.$$.fragment);
    },
    m(target, anchor) {
      mount_component(icon, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(icon, detaching);
    }
  };
}
function create_if_block_1$2(ctx) {
  let gridcell;
  let current;
  gridcell = new GridCell({
    props: {
      width: (
        /*$displayColumn*/
        ctx[1].width
      ),
      highlighted: (
        /*$hoveredRowId*/
        ctx[7] === BlankRowID
      ),
      $$slots: { default: [create_default_slot_1$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(gridcell.$$.fragment);
    },
    m(target, anchor) {
      mount_component(gridcell, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const gridcell_changes = {};
      if (dirty[0] & /*$displayColumn*/
      2)
        gridcell_changes.width = /*$displayColumn*/
        ctx2[1].width;
      if (dirty[0] & /*$hoveredRowId*/
      128)
        gridcell_changes.highlighted = /*$hoveredRowId*/
        ctx2[7] === BlankRowID;
      if (dirty[1] & /*$$scope*/
      2048) {
        gridcell_changes.$$scope = { dirty, ctx: ctx2 };
      }
      gridcell.$set(gridcell_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(gridcell.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(gridcell.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(gridcell, detaching);
    }
  };
}
function create_default_slot_1$1(ctx) {
  let keyboardshortcut;
  let current;
  keyboardshortcut = new KeyboardShortcut({
    props: { padded: true, keybind: "Ctrl+Enter" }
  });
  return {
    c() {
      create_component(keyboardshortcut.$$.fragment);
    },
    m(target, anchor) {
      mount_component(keyboardshortcut, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(keyboardshortcut.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(keyboardshortcut.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(keyboardshortcut, detaching);
    }
  };
}
function create_default_slot$1(ctx) {
  let t;
  let if_block_anchor;
  let current;
  let each_value = ensure_array_like(
    /*$renderedRows*/
    ctx[6]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$2(get_each_context$2(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  let if_block = (
    /*$config*/
    ctx[16].canAddRows && create_if_block$2(ctx)
  );
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*$isDragging, $hoveredRowId, $renderedRows, dispatch, rows, $displayColumn, $focusedRow, $selectedRows, $selectedCellMap, $selectedCellCount, $isSelectingCells, $focusedCellId, $userCellMap, $contentLines*/
      268632003) {
        each_value = ensure_array_like(
          /*$renderedRows*/
          ctx2[6]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$2(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$2(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(t.parentNode, t);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      if (
        /*$config*/
        ctx2[16].canAddRows
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*$config*/
          65536) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$2(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      transition_in(if_block);
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      destroy_each(each_blocks, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment$4(ctx) {
  let div1;
  let div0;
  let guttercell;
  let t0;
  let t1;
  let gridscrollwrapper;
  let current;
  guttercell = new GutterCell({
    props: {
      disableNumber: true,
      defaultHeight: true,
      rowSelected: (
        /*selectedRowCount*/
        ctx[3] && /*selectedRowCount*/
        ctx[3] === /*rowCount*/
        ctx[2]
      ),
      disabled: !/*$renderedRows*/
      ctx[6].length
    }
  });
  guttercell.$on(
    "select",
    /*selectAll*/
    ctx[33]
  );
  let if_block = (
    /*$displayColumn*/
    ctx[1] && create_if_block_3$2(ctx)
  );
  gridscrollwrapper = new GridScrollWrapper({
    props: {
      scrollVertically: true,
      attachHandlers: true,
      $$slots: { default: [create_default_slot$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      create_component(guttercell.$$.fragment);
      t0 = space();
      if (if_block)
        if_block.c();
      t1 = space();
      create_component(gridscrollwrapper.$$.fragment);
      attr(div0, "class", "header row svelte-15yu3r0");
      attr(div1, "class", "sticky-column svelte-15yu3r0");
      set_style(div1, "flex", "0 0 " + /*width*/
      ctx[4] + "px");
      toggle_class(
        div1,
        "scrolled",
        /*$scrollLeft*/
        ctx[5] > 0
      );
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      mount_component(guttercell, div0, null);
      append(div0, t0);
      if (if_block)
        if_block.m(div0, null);
      append(div1, t1);
      mount_component(gridscrollwrapper, div1, null);
      current = true;
    },
    p(ctx2, dirty) {
      const guttercell_changes = {};
      if (dirty[0] & /*selectedRowCount, rowCount*/
      12)
        guttercell_changes.rowSelected = /*selectedRowCount*/
        ctx2[3] && /*selectedRowCount*/
        ctx2[3] === /*rowCount*/
        ctx2[2];
      if (dirty[0] & /*$renderedRows*/
      64)
        guttercell_changes.disabled = !/*$renderedRows*/
        ctx2[6].length;
      guttercell.$set(guttercell_changes);
      if (
        /*$displayColumn*/
        ctx2[1]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*$displayColumn*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_3$2(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div0, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      const gridscrollwrapper_changes = {};
      if (dirty[0] & /*$isDragging, $hoveredRowId, $displayColumn, $config, $renderedRows, $focusedRow, $selectedRows, $selectedCellMap, $selectedCellCount, $isSelectingCells, $focusedCellId, $userCellMap, $contentLines*/
      131011 | dirty[1] & /*$$scope*/
      2048) {
        gridscrollwrapper_changes.$$scope = { dirty, ctx: ctx2 };
      }
      gridscrollwrapper.$set(gridscrollwrapper_changes);
      if (!current || dirty[0] & /*width*/
      16) {
        set_style(div1, "flex", "0 0 " + /*width*/
        ctx2[4] + "px");
      }
      if (!current || dirty[0] & /*$scrollLeft*/
      32) {
        toggle_class(
          div1,
          "scrolled",
          /*$scrollLeft*/
          ctx2[5] > 0
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(guttercell.$$.fragment, local);
      transition_in(if_block);
      transition_in(gridscrollwrapper.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(guttercell.$$.fragment, local);
      transition_out(if_block);
      transition_out(gridscrollwrapper.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      destroy_component(guttercell);
      if (if_block)
        if_block.d();
      destroy_component(gridscrollwrapper);
    }
  };
}
function instance$5($$self, $$props, $$invalidate) {
  let rowCount;
  let selectedRowCount;
  let width;
  let $selectedRows;
  let $rows;
  let $displayColumn;
  let $scrollLeft;
  let $renderedRows;
  let $hoveredRowId;
  let $selectedCellCount;
  let $isSelectingCells;
  let $focusedRow;
  let $isDragging;
  let $selectedCellMap;
  let $focusedCellId;
  let $userCellMap;
  let $contentLines;
  let $config;
  let { $$slots: slots = {}, $$scope } = $$props;
  const { rows, selectedRows, displayColumn, renderedRows, focusedCellId, hoveredRowId, config, selectedCellMap, userCellMap, focusedRow, scrollLeft, dispatch, contentLines, isDragging, isSelectingCells, selectedCellCount } = getContext("grid");
  component_subscribe($$self, rows, (value) => $$invalidate(34, $rows = value));
  component_subscribe($$self, selectedRows, (value) => $$invalidate(0, $selectedRows = value));
  component_subscribe($$self, displayColumn, (value) => $$invalidate(1, $displayColumn = value));
  component_subscribe($$self, renderedRows, (value) => $$invalidate(6, $renderedRows = value));
  component_subscribe($$self, focusedCellId, (value) => $$invalidate(13, $focusedCellId = value));
  component_subscribe($$self, hoveredRowId, (value) => $$invalidate(7, $hoveredRowId = value));
  component_subscribe($$self, config, (value) => $$invalidate(16, $config = value));
  component_subscribe($$self, selectedCellMap, (value) => $$invalidate(12, $selectedCellMap = value));
  component_subscribe($$self, userCellMap, (value) => $$invalidate(14, $userCellMap = value));
  component_subscribe($$self, focusedRow, (value) => $$invalidate(10, $focusedRow = value));
  component_subscribe($$self, scrollLeft, (value) => $$invalidate(5, $scrollLeft = value));
  component_subscribe($$self, contentLines, (value) => $$invalidate(15, $contentLines = value));
  component_subscribe($$self, isDragging, (value) => $$invalidate(11, $isDragging = value));
  component_subscribe($$self, isSelectingCells, (value) => $$invalidate(9, $isSelectingCells = value));
  component_subscribe($$self, selectedCellCount, (value) => $$invalidate(8, $selectedCellCount = value));
  const selectAll = () => {
    const allSelected = selectedRowCount === rowCount;
    if (allSelected) {
      set_store_value(selectedRows, $selectedRows = {}, $selectedRows);
    } else {
      let allRows = {};
      $rows.forEach((row) => {
        allRows[row._id] = true;
      });
      set_store_value(selectedRows, $selectedRows = allRows, $selectedRows);
    }
  };
  const mouseenter_handler = (row) => set_store_value(hoveredRowId, $hoveredRowId = row._id, $hoveredRowId);
  const mouseleave_handler = () => set_store_value(hoveredRowId, $hoveredRowId = null, $hoveredRowId);
  const click_handler = (row) => dispatch("rowclick", rows.actions.cleanRow(row));
  const mouseenter_handler_1 = () => set_store_value(hoveredRowId, $hoveredRowId = BlankRowID, $hoveredRowId);
  const mouseleave_handler_1 = () => set_store_value(hoveredRowId, $hoveredRowId = null, $hoveredRowId);
  const click_handler_1 = () => dispatch("add-row-inline");
  $$self.$$set = ($$props2) => {
    if ("$$scope" in $$props2)
      $$invalidate(42, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[1] & /*$rows*/
    8) {
      $$invalidate(2, rowCount = $rows.length);
    }
    if ($$self.$$.dirty[0] & /*$selectedRows*/
    1) {
      $$invalidate(3, selectedRowCount = Object.values($selectedRows).length);
    }
    if ($$self.$$.dirty[0] & /*$displayColumn*/
    2) {
      $$invalidate(4, width = GutterWidth + (($displayColumn == null ? void 0 : $displayColumn.width) || 0));
    }
  };
  return [
    $selectedRows,
    $displayColumn,
    rowCount,
    selectedRowCount,
    width,
    $scrollLeft,
    $renderedRows,
    $hoveredRowId,
    $selectedCellCount,
    $isSelectingCells,
    $focusedRow,
    $isDragging,
    $selectedCellMap,
    $focusedCellId,
    $userCellMap,
    $contentLines,
    $config,
    rows,
    selectedRows,
    displayColumn,
    renderedRows,
    focusedCellId,
    hoveredRowId,
    config,
    selectedCellMap,
    userCellMap,
    focusedRow,
    scrollLeft,
    dispatch,
    contentLines,
    isDragging,
    isSelectingCells,
    selectedCellCount,
    selectAll,
    $rows,
    slots,
    mouseenter_handler,
    mouseleave_handler,
    click_handler,
    mouseenter_handler_1,
    mouseleave_handler_1,
    click_handler_1,
    $$scope
  ];
}
class StickyColumn extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$5, create_fragment$4, safe_not_equal, {}, null, [-1, -1]);
  }
}
function get_each_context$1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[4] = list[i];
  return child_ctx;
}
function create_each_block$1(ctx) {
  let useravatar;
  let current;
  useravatar = new UserAvatar({ props: { user: (
    /*user*/
    ctx[4]
  ) } });
  return {
    c() {
      create_component(useravatar.$$.fragment);
    },
    m(target, anchor) {
      mount_component(useravatar, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const useravatar_changes = {};
      if (dirty & /*uniqueUsers*/
      1)
        useravatar_changes.user = /*user*/
        ctx2[4];
      useravatar.$set(useravatar_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(useravatar.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(useravatar.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(useravatar, detaching);
    }
  };
}
function create_fragment$3(ctx) {
  let div;
  let current;
  let each_value = ensure_array_like(
    /*uniqueUsers*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$1(get_each_context$1(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "users svelte-1ex8wrg");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      current = true;
    },
    p(ctx2, [dirty]) {
      if (dirty & /*uniqueUsers*/
      1) {
        each_value = ensure_array_like(
          /*uniqueUsers*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$1(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$1(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div, null);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function instance$4($$self, $$props, $$invalidate) {
  let uniqueUsers;
  let $users;
  const { users } = getContext("grid");
  component_subscribe($$self, users, (value) => $$invalidate(2, $users = value));
  const unique = (users2) => {
    let uniqueUsers2 = {};
    users2 == null ? void 0 : users2.forEach((user) => {
      uniqueUsers2[user.email] = user;
    });
    return Object.values(uniqueUsers2);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$users*/
    4) {
      $$invalidate(0, uniqueUsers = unique($users));
    }
  };
  return [uniqueUsers, users, $users];
}
class UserAvatars extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$4, create_fragment$3, safe_not_equal, {});
  }
}
function instance$3($$self, $$props, $$invalidate) {
  let $focusedCellAPI;
  let $selectedCellCount;
  let $rows;
  let $rowLookupMap;
  let $cellSelection;
  let $focusedCellId;
  let $focusedRowId;
  let $visibleColumns;
  let $columnLookupMap;
  let $config;
  let $selectedRowCount;
  let $keyboardBlocked;
  let $gridFocused;
  const { rows, focusedCellId, visibleColumns, rowLookupMap, focusedCellAPI, dispatch, selectedRowCount, config, menu, gridFocused, keyboardBlocked, selectedCellCount, selectedCells, cellSelection, columnLookupMap, focusedRowId } = getContext("grid");
  component_subscribe($$self, rows, (value) => $$invalidate(15, $rows = value));
  component_subscribe($$self, focusedCellId, (value) => $$invalidate(18, $focusedCellId = value));
  component_subscribe($$self, visibleColumns, (value) => $$invalidate(20, $visibleColumns = value));
  component_subscribe($$self, rowLookupMap, (value) => $$invalidate(16, $rowLookupMap = value));
  component_subscribe($$self, focusedCellAPI, (value) => $$invalidate(13, $focusedCellAPI = value));
  component_subscribe($$self, selectedRowCount, (value) => $$invalidate(23, $selectedRowCount = value));
  component_subscribe($$self, config, (value) => $$invalidate(22, $config = value));
  component_subscribe($$self, gridFocused, (value) => $$invalidate(25, $gridFocused = value));
  component_subscribe($$self, keyboardBlocked, (value) => $$invalidate(24, $keyboardBlocked = value));
  component_subscribe($$self, selectedCellCount, (value) => $$invalidate(14, $selectedCellCount = value));
  component_subscribe($$self, cellSelection, (value) => $$invalidate(17, $cellSelection = value));
  component_subscribe($$self, columnLookupMap, (value) => $$invalidate(21, $columnLookupMap = value));
  component_subscribe($$self, focusedRowId, (value) => $$invalidate(19, $focusedRowId = value));
  const ignoredOriginSelectors = [
    ".spectrum-Modal",
    ".date-time-popover",
    "#builder-side-panel-container",
    "[data-grid-ignore]"
  ];
  const handleKeyDown = (e) => {
    var _a, _b, _c;
    if (!$gridFocused || $keyboardBlocked) {
      return;
    }
    if ((_a = e.target) == null ? void 0 : _a.closest) {
      for (let selector of ignoredOriginSelectors) {
        if (e.target.closest(selector)) {
          return;
        }
      }
    }
    const handle = (fn) => {
      e.preventDefault();
      fn();
    };
    if (e.metaKey || e.ctrlKey) {
      switch (e.key) {
        case "c":
          return handle(() => dispatch("copy"));
        case "v":
          return dispatch("paste");
        case "Enter":
          return handle(() => {
            if ($config.canAddRows) {
              dispatch("add-row-inline");
            }
          });
      }
    }
    if ($selectedCellCount) {
      switch (e.key) {
        case "Escape":
          return handle(selectedCells.actions.clear);
        case "Delete":
        case "Backspace":
          return handle(() => dispatch("request-bulk-delete"));
      }
    }
    if (!$focusedCellId) {
      if (e.key === "Tab" || ((_b = e.key) == null ? void 0 : _b.startsWith("Arrow"))) {
        handle(focusFirstCell);
      } else if (e.key === "Delete" || e.key === "Backspace") {
        handle(() => {
          if ($selectedRowCount && $config.canDeleteRows) {
            dispatch("request-bulk-delete");
          }
        });
      }
      return;
    }
    const api = $focusedCellAPI;
    if (e.key === "Escape") {
      return handle(() => {
        if (api == null ? void 0 : api.isActive()) {
          setTimeout(api == null ? void 0 : api.blur, 10);
        } else {
          set_store_value(focusedCellId, $focusedCellId = null, $focusedCellId);
        }
        menu.actions.close();
      });
    } else if (e.key === "Tab") {
      return handle(() => {
        var _a2;
        (_a2 = api == null ? void 0 : api.blur) == null ? void 0 : _a2.call(api);
        changeFocusedColumn(1);
      });
    }
    if (!(api == null ? void 0 : api.isReadonly())) {
      const handled = (_c = api == null ? void 0 : api.onKeyDown) == null ? void 0 : _c.call(api, e);
      if (handled) {
        return;
      }
    }
    if (e.metaKey || e.ctrlKey)
      ;
    else {
      switch (e.key) {
        case "ArrowLeft":
          return handle(
            () => changeFocusedColumn(-1, e.shiftKey)
          );
        case "ArrowRight":
          return handle(() => changeFocusedColumn(1, e.shiftKey));
        case "ArrowUp":
          return handle(() => changeFocusedRow(-1, e.shiftKey));
        case "ArrowDown":
          return handle(() => changeFocusedRow(1, e.shiftKey));
        case "Delete":
        case "Backspace":
          return handle(() => {
            if ($selectedRowCount && $config.canDeleteRows) {
              dispatch("request-bulk-delete");
            } else {
              deleteSelectedCell();
            }
          });
        case "Enter":
          return handle(focusCell);
        default:
          return handle(() => startEnteringValue(e.key, e.which));
      }
    }
  };
  const focusFirstCell = () => {
    const firstRow = $rows[0];
    if (!firstRow) {
      return;
    }
    const firstColumn = $visibleColumns[0];
    if (!firstColumn) {
      return;
    }
    focusedCellId.set(getCellID(firstRow._id, firstColumn.name));
  };
  const changeFocusedColumn = (delta, shiftKey) => {
    let sourceCellId = $focusedCellId;
    if (shiftKey && $selectedCellCount) {
      sourceCellId = $cellSelection.targetCellId;
    }
    if (!sourceCellId) {
      return;
    }
    const { rowId, field } = parseCellID(sourceCellId);
    const colIdx = $columnLookupMap[field].__idx;
    const nextColumn = $visibleColumns[colIdx + delta];
    if (!nextColumn) {
      return;
    }
    const targetCellId = getCellID(rowId, nextColumn.name);
    if (shiftKey) {
      if ($selectedCellCount) {
        selectedCells.actions.updateTarget(targetCellId);
        if (!$selectedCellCount) {
          focusedCellId.set(targetCellId);
        }
      } else {
        selectedCells.actions.selectRange(sourceCellId, targetCellId);
      }
    } else {
      focusedCellId.set(targetCellId);
    }
  };
  const changeFocusedRow = (delta, shiftKey) => {
    if ($focusedRowId === NewRowID) {
      return;
    }
    let sourceCellId = $focusedCellId;
    if (shiftKey && $selectedCellCount) {
      sourceCellId = $cellSelection.targetCellId;
    }
    if (!sourceCellId) {
      return;
    }
    const { rowId, field } = parseCellID(sourceCellId);
    const rowIdx = $rowLookupMap[rowId].__idx;
    const newRow = $rows[rowIdx + delta];
    if (!newRow) {
      return;
    }
    const targetCellId = getCellID(newRow._id, field);
    if (shiftKey) {
      if ($selectedCellCount) {
        selectedCells.actions.updateTarget(targetCellId);
        if (!$selectedCellCount) {
          focusedCellId.set(targetCellId);
        }
      } else {
        selectedCells.actions.selectRange(sourceCellId, targetCellId);
      }
    } else {
      focusedCellId.set(targetCellId);
    }
  };
  const deleteSelectedCell = debounce(
    () => {
      if ($focusedCellAPI == null ? void 0 : $focusedCellAPI.isReadonly()) {
        return;
      }
      $focusedCellAPI.setValue(null);
    },
    100
  );
  const focusCell = () => {
    var _a;
    if ($focusedCellAPI == null ? void 0 : $focusedCellAPI.isReadonly()) {
      return;
    }
    (_a = $focusedCellAPI == null ? void 0 : $focusedCellAPI.focus) == null ? void 0 : _a.call($focusedCellAPI);
  };
  const keyCodeIsNumber = (keyCode) => keyCode >= 48 && keyCode <= 57;
  const keyCodeIsLetter = (keyCode) => keyCode >= 65 && keyCode <= 90;
  const startEnteringValue = (key, keyCode) => {
    if ($focusedCellAPI && !$focusedCellAPI.isReadonly()) {
      const type = $focusedCellAPI.getType();
      if (type === "number" && keyCodeIsNumber(keyCode)) {
        $focusedCellAPI.setValue(parseInt(key), { apply: false });
        $focusedCellAPI.focus();
      } else if (["string", "barcodeqr", "longform"].includes(type) && (keyCodeIsLetter(keyCode) || keyCodeIsNumber(keyCode))) {
        $focusedCellAPI.setValue(key, { apply: false });
        $focusedCellAPI.focus();
      }
    }
  };
  onMount(() => {
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  });
  return [
    rows,
    focusedCellId,
    visibleColumns,
    rowLookupMap,
    focusedCellAPI,
    selectedRowCount,
    config,
    gridFocused,
    keyboardBlocked,
    selectedCellCount,
    cellSelection,
    columnLookupMap,
    focusedRowId
  ];
}
class KeyboardManager extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$3, null, safe_not_equal, {}, null, [-1, -1]);
  }
}
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[64] = list[i];
  const constants_0 = getCellID(
    NewRowID,
    /*column*/
    child_ctx[64].name
  );
  child_ctx[65] = constants_0;
  return child_ctx;
}
function get_if_ctx(ctx) {
  const child_ctx = ctx.slice();
  const constants_0 = getCellID(
    NewRowID,
    /*$displayColumn*/
    child_ctx[1].name
  );
  child_ctx[65] = constants_0;
  return child_ctx;
}
function create_if_block_7$1(ctx) {
  let div;
  let icon;
  let div_transition;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({ props: { name: "plus", size: "S" } });
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      attr(div, "class", "new-row-fab svelte-8ib1kg");
      toggle_class(div, "offset", !/*$displayColumn*/
      ctx[1]);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      current = true;
      if (!mounted) {
        dispose = listen(
          div,
          "click",
          /*click_handler*/
          ctx[54]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (!current || dirty[0] & /*$displayColumn*/
      2) {
        toggle_class(div, "offset", !/*$displayColumn*/
        ctx2[1]);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div_transition)
            div_transition = create_bidirectional_transition(div, fade, { duration: 130 }, true);
          div_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      if (local) {
        if (!div_transition)
          div_transition = create_bidirectional_transition(div, fade, { duration: 130 }, false);
        div_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
      if (detaching && div_transition)
        div_transition.end();
      mounted = false;
      dispose();
    }
  };
}
function create_default_slot_6(ctx) {
  let if_block_anchor;
  let current;
  let if_block = !/*visible*/
  ctx[2] && !/*selectedRowCount*/
  ctx[7] && /*$config*/
  ctx[14].canAddRows && create_if_block_7$1(ctx);
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (!/*visible*/
      ctx2[2] && !/*selectedRowCount*/
      ctx2[7] && /*$config*/
      ctx2[14].canAddRows) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*visible, selectedRowCount, $config*/
          16516) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_7$1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block$1(ctx) {
  let div6;
  let div0;
  let div0_transition;
  let t0;
  let div1;
  let div1_transition;
  let t1;
  let div3;
  let div2;
  let guttercell;
  let t2;
  let div3_transition;
  let t3;
  let div4;
  let gridscrollwrapper;
  let div4_transition;
  let t4;
  let div5;
  let button0;
  let t5;
  let button1;
  let div5_transition;
  let current;
  guttercell = new GutterCell({
    props: {
      expandable: true,
      rowHovered: true,
      $$slots: { default: [create_default_slot_5] },
      $$scope: { ctx }
    }
  });
  guttercell.$on(
    "expand",
    /*addViaModal*/
    ctx[42]
  );
  let if_block = (
    /*$displayColumn*/
    ctx[1] && create_if_block_3$1(get_if_ctx(ctx))
  );
  gridscrollwrapper = new GridScrollWrapper({
    props: {
      scrollHorizontally: true,
      attachHandlers: true,
      $$slots: { default: [create_default_slot_2] },
      $$scope: { ctx }
    }
  });
  button0 = new Button({
    props: {
      size: "M",
      cta: true,
      disabled: (
        /*isAdding*/
        ctx[3]
      ),
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  button0.$on(
    "click",
    /*addRow*/
    ctx[39]
  );
  button1 = new Button({
    props: {
      size: "M",
      secondary: true,
      newStyles: true,
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  button1.$on(
    "click",
    /*clear*/
    ctx[40]
  );
  return {
    c() {
      div6 = element("div");
      div0 = element("div");
      t0 = space();
      div1 = element("div");
      t1 = space();
      div3 = element("div");
      div2 = element("div");
      create_component(guttercell.$$.fragment);
      t2 = space();
      if (if_block)
        if_block.c();
      t3 = space();
      div4 = element("div");
      create_component(gridscrollwrapper.$$.fragment);
      t4 = space();
      div5 = element("div");
      create_component(button0.$$.fragment);
      t5 = space();
      create_component(button1.$$.fragment);
      attr(div0, "class", "underlay sticky svelte-8ib1kg");
      attr(div1, "class", "underlay svelte-8ib1kg");
      attr(div2, "class", "row svelte-8ib1kg");
      attr(div3, "class", "sticky-column svelte-8ib1kg");
      attr(div4, "class", "normal-columns svelte-8ib1kg");
      attr(div5, "class", "buttons svelte-8ib1kg");
      toggle_class(
        div5,
        "flip",
        /*flipButtons*/
        ctx[5]
      );
      attr(div6, "class", "new-row svelte-8ib1kg");
      set_style(
        div6,
        "--offset",
        /*offset*/
        ctx[0] + "px"
      );
      set_style(
        div6,
        "--sticky-width",
        /*width*/
        ctx[8] + "px"
      );
      toggle_class(
        div6,
        "floating",
        /*offset*/
        ctx[0] > 0
      );
    },
    m(target, anchor) {
      insert(target, div6, anchor);
      append(div6, div0);
      append(div6, t0);
      append(div6, div1);
      append(div6, t1);
      append(div6, div3);
      append(div3, div2);
      mount_component(guttercell, div2, null);
      append(div2, t2);
      if (if_block)
        if_block.m(div2, null);
      append(div6, t3);
      append(div6, div4);
      mount_component(gridscrollwrapper, div4, null);
      append(div6, t4);
      append(div6, div5);
      mount_component(button0, div5, null);
      append(div5, t5);
      mount_component(button1, div5, null);
      current = true;
    },
    p(ctx2, dirty) {
      const guttercell_changes = {};
      if (dirty[0] & /*isAdding*/
      8 | dirty[2] & /*$$scope*/
      64) {
        guttercell_changes.$$scope = { dirty, ctx: ctx2 };
      }
      guttercell.$set(guttercell_changes);
      if (
        /*$displayColumn*/
        ctx2[1]
      ) {
        if (if_block) {
          if_block.p(get_if_ctx(ctx2), dirty);
          if (dirty[0] & /*$displayColumn*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_3$1(get_if_ctx(ctx2));
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div2, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      const gridscrollwrapper_changes = {};
      if (dirty[0] & /*$scrollableColumns, newRow, $focusedCellId, offset, $columnRenderMap, isAdding*/
      98841 | dirty[2] & /*$$scope*/
      64) {
        gridscrollwrapper_changes.$$scope = { dirty, ctx: ctx2 };
      }
      gridscrollwrapper.$set(gridscrollwrapper_changes);
      const button0_changes = {};
      if (dirty[0] & /*isAdding*/
      8)
        button0_changes.disabled = /*isAdding*/
        ctx2[3];
      if (dirty[2] & /*$$scope*/
      64) {
        button0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button0.$set(button0_changes);
      const button1_changes = {};
      if (dirty[2] & /*$$scope*/
      64) {
        button1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button1.$set(button1_changes);
      if (!current || dirty[0] & /*flipButtons*/
      32) {
        toggle_class(
          div5,
          "flip",
          /*flipButtons*/
          ctx2[5]
        );
      }
      if (!current || dirty[0] & /*offset*/
      1) {
        set_style(
          div6,
          "--offset",
          /*offset*/
          ctx2[0] + "px"
        );
      }
      if (!current || dirty[0] & /*width*/
      256) {
        set_style(
          div6,
          "--sticky-width",
          /*width*/
          ctx2[8] + "px"
        );
      }
      if (!current || dirty[0] & /*offset*/
      1) {
        toggle_class(
          div6,
          "floating",
          /*offset*/
          ctx2[0] > 0
        );
      }
    },
    i(local) {
      if (current)
        return;
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div0_transition)
            div0_transition = create_bidirectional_transition(div0, fade, { duration: 130 }, true);
          div0_transition.run(1);
        });
      }
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div1_transition)
            div1_transition = create_bidirectional_transition(div1, fade, { duration: 130 }, true);
          div1_transition.run(1);
        });
      }
      transition_in(guttercell.$$.fragment, local);
      transition_in(if_block);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div3_transition)
            div3_transition = create_bidirectional_transition(div3, fade, { duration: 130 }, true);
          div3_transition.run(1);
        });
      }
      transition_in(gridscrollwrapper.$$.fragment, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div4_transition)
            div4_transition = create_bidirectional_transition(div4, fade, { duration: 130 }, true);
          div4_transition.run(1);
        });
      }
      transition_in(button0.$$.fragment, local);
      transition_in(button1.$$.fragment, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div5_transition)
            div5_transition = create_bidirectional_transition(div5, fade, { duration: 130 }, true);
          div5_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      if (local) {
        if (!div0_transition)
          div0_transition = create_bidirectional_transition(div0, fade, { duration: 130 }, false);
        div0_transition.run(0);
      }
      if (local) {
        if (!div1_transition)
          div1_transition = create_bidirectional_transition(div1, fade, { duration: 130 }, false);
        div1_transition.run(0);
      }
      transition_out(guttercell.$$.fragment, local);
      transition_out(if_block);
      if (local) {
        if (!div3_transition)
          div3_transition = create_bidirectional_transition(div3, fade, { duration: 130 }, false);
        div3_transition.run(0);
      }
      transition_out(gridscrollwrapper.$$.fragment, local);
      if (local) {
        if (!div4_transition)
          div4_transition = create_bidirectional_transition(div4, fade, { duration: 130 }, false);
        div4_transition.run(0);
      }
      transition_out(button0.$$.fragment, local);
      transition_out(button1.$$.fragment, local);
      if (local) {
        if (!div5_transition)
          div5_transition = create_bidirectional_transition(div5, fade, { duration: 130 }, false);
        div5_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div6);
      }
      if (detaching && div0_transition)
        div0_transition.end();
      if (detaching && div1_transition)
        div1_transition.end();
      destroy_component(guttercell);
      if (if_block)
        if_block.d();
      if (detaching && div3_transition)
        div3_transition.end();
      destroy_component(gridscrollwrapper);
      if (detaching && div4_transition)
        div4_transition.end();
      destroy_component(button0);
      destroy_component(button1);
      if (detaching && div5_transition)
        div5_transition.end();
    }
  };
}
function create_if_block_6$1(ctx) {
  let div;
  let div_intro;
  return {
    c() {
      div = element("div");
      attr(div, "class", "loading-overlay svelte-8ib1kg");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    i(local) {
      if (local) {
        if (!div_intro) {
          add_render_callback(() => {
            div_intro = create_in_transition(div, fade, { duration: 130 });
            div_intro.start();
          });
        }
      }
    },
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_default_slot_5(ctx) {
  let icon;
  let t;
  let if_block_anchor;
  let current;
  icon = new Icon({
    props: {
      name: "plus",
      color: "var(--spectrum-global-color-gray-500)"
    }
  });
  let if_block = (
    /*isAdding*/
    ctx[3] && create_if_block_6$1()
  );
  return {
    c() {
      create_component(icon.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      mount_component(icon, target, anchor);
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*isAdding*/
        ctx2[3]
      ) {
        if (if_block) {
          if (dirty[0] & /*isAdding*/
          8) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_6$1();
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      destroy_component(icon, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block_3$1(ctx) {
  let datacell;
  let current;
  datacell = new DataCell({
    props: {
      cellId: (
        /*cellId*/
        ctx[65]
      ),
      rowFocused: true,
      column: (
        /*$displayColumn*/
        ctx[1]
      ),
      row: (
        /*newRow*/
        ctx[4]
      ),
      focused: (
        /*$focusedCellId*/
        ctx[9] === /*cellId*/
        ctx[65]
      ),
      width: (
        /*$displayColumn*/
        ctx[1].width
      ),
      updateValue: (
        /*updateValue*/
        ctx[41]
      ),
      topRow: (
        /*offset*/
        ctx[0] === 0
      ),
      $$slots: { default: [create_default_slot_4] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(datacell.$$.fragment);
    },
    m(target, anchor) {
      mount_component(datacell, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const datacell_changes = {};
      if (dirty[0] & /*$displayColumn*/
      2)
        datacell_changes.cellId = /*cellId*/
        ctx2[65];
      if (dirty[0] & /*$displayColumn*/
      2)
        datacell_changes.column = /*$displayColumn*/
        ctx2[1];
      if (dirty[0] & /*newRow*/
      16)
        datacell_changes.row = /*newRow*/
        ctx2[4];
      if (dirty[0] & /*$focusedCellId, $displayColumn*/
      514)
        datacell_changes.focused = /*$focusedCellId*/
        ctx2[9] === /*cellId*/
        ctx2[65];
      if (dirty[0] & /*$displayColumn*/
      2)
        datacell_changes.width = /*$displayColumn*/
        ctx2[1].width;
      if (dirty[0] & /*offset*/
      1)
        datacell_changes.topRow = /*offset*/
        ctx2[0] === 0;
      if (dirty[0] & /*isAdding, $displayColumn*/
      10 | dirty[2] & /*$$scope*/
      64) {
        datacell_changes.$$scope = { dirty, ctx: ctx2 };
      }
      datacell.$set(datacell_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(datacell.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(datacell.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(datacell, detaching);
    }
  };
}
function create_if_block_5$1(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      div.textContent = "Can't edit auto column";
      attr(div, "class", "readonly-overlay svelte-8ib1kg");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block_4$1(ctx) {
  let div;
  let div_intro;
  return {
    c() {
      div = element("div");
      attr(div, "class", "loading-overlay svelte-8ib1kg");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    i(local) {
      if (local) {
        if (!div_intro) {
          add_render_callback(() => {
            div_intro = create_in_transition(div, fade, { duration: 130 });
            div_intro.start();
          });
        }
      }
    },
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_default_slot_4(ctx) {
  var _a, _b;
  let t;
  let if_block1_anchor;
  let if_block0 = (
    /*$displayColumn*/
    ((_b = (_a = ctx[1]) == null ? void 0 : _a.schema) == null ? void 0 : _b.autocolumn) && create_if_block_5$1()
  );
  let if_block1 = (
    /*isAdding*/
    ctx[3] && create_if_block_4$1()
  );
  return {
    c() {
      if (if_block0)
        if_block0.c();
      t = space();
      if (if_block1)
        if_block1.c();
      if_block1_anchor = empty();
    },
    m(target, anchor) {
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, if_block1_anchor, anchor);
    },
    p(ctx2, dirty) {
      var _a2, _b2;
      if (
        /*$displayColumn*/
        (_b2 = (_a2 = ctx2[1]) == null ? void 0 : _a2.schema) == null ? void 0 : _b2.autocolumn
      ) {
        if (if_block0)
          ;
        else {
          if_block0 = create_if_block_5$1();
          if_block0.c();
          if_block0.m(t.parentNode, t);
        }
      } else if (if_block0) {
        if_block0.d(1);
        if_block0 = null;
      }
      if (
        /*isAdding*/
        ctx2[3]
      ) {
        if (if_block1) {
          if (dirty[0] & /*isAdding*/
          8) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_4$1();
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(if_block1_anchor.parentNode, if_block1_anchor);
        }
      } else if (if_block1) {
        if_block1.d(1);
        if_block1 = null;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block1_anchor);
      }
      if (if_block0)
        if_block0.d(detaching);
      if (if_block1)
        if_block1.d(detaching);
    }
  };
}
function create_if_block_2$1(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      div.textContent = "Can't edit auto column";
      attr(div, "class", "readonly-overlay svelte-8ib1kg");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block_1$1(ctx) {
  let div;
  let div_intro;
  return {
    c() {
      div = element("div");
      attr(div, "class", "loading-overlay svelte-8ib1kg");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    i(local) {
      if (local) {
        if (!div_intro) {
          add_render_callback(() => {
            div_intro = create_in_transition(div, fade, { duration: 130 });
            div_intro.start();
          });
        }
      }
    },
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_default_slot_3(ctx) {
  var _a, _b;
  let t0;
  let t1;
  let if_block0 = (
    /*column*/
    ((_b = (_a = ctx[64]) == null ? void 0 : _a.schema) == null ? void 0 : _b.autocolumn) && create_if_block_2$1()
  );
  let if_block1 = (
    /*isAdding*/
    ctx[3] && create_if_block_1$1()
  );
  return {
    c() {
      if (if_block0)
        if_block0.c();
      t0 = space();
      if (if_block1)
        if_block1.c();
      t1 = space();
    },
    m(target, anchor) {
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t0, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, t1, anchor);
    },
    p(ctx2, dirty) {
      var _a2, _b2;
      if (
        /*column*/
        (_b2 = (_a2 = ctx2[64]) == null ? void 0 : _a2.schema) == null ? void 0 : _b2.autocolumn
      ) {
        if (if_block0)
          ;
        else {
          if_block0 = create_if_block_2$1();
          if_block0.c();
          if_block0.m(t0.parentNode, t0);
        }
      } else if (if_block0) {
        if_block0.d(1);
        if_block0 = null;
      }
      if (
        /*isAdding*/
        ctx2[3]
      ) {
        if (if_block1) {
          if (dirty[0] & /*isAdding*/
          8) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_1$1();
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(t1.parentNode, t1);
        }
      } else if (if_block1) {
        if_block1.d(1);
        if_block1 = null;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
      if (if_block0)
        if_block0.d(detaching);
      if (if_block1)
        if_block1.d(detaching);
    }
  };
}
function create_each_block(ctx) {
  let datacell;
  let current;
  datacell = new DataCell({
    props: {
      cellId: (
        /*cellId*/
        ctx[65]
      ),
      column: (
        /*column*/
        ctx[64]
      ),
      updateValue: (
        /*updateValue*/
        ctx[41]
      ),
      rowFocused: true,
      row: (
        /*newRow*/
        ctx[4]
      ),
      focused: (
        /*$focusedCellId*/
        ctx[9] === /*cellId*/
        ctx[65]
      ),
      width: (
        /*column*/
        ctx[64].width
      ),
      topRow: (
        /*offset*/
        ctx[0] === 0
      ),
      hidden: !/*$columnRenderMap*/
      ctx[16][
        /*column*/
        ctx[64].name
      ],
      $$slots: { default: [create_default_slot_3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(datacell.$$.fragment);
    },
    m(target, anchor) {
      mount_component(datacell, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const datacell_changes = {};
      if (dirty[0] & /*$scrollableColumns*/
      32768)
        datacell_changes.cellId = /*cellId*/
        ctx2[65];
      if (dirty[0] & /*$scrollableColumns*/
      32768)
        datacell_changes.column = /*column*/
        ctx2[64];
      if (dirty[0] & /*newRow*/
      16)
        datacell_changes.row = /*newRow*/
        ctx2[4];
      if (dirty[0] & /*$focusedCellId, $scrollableColumns*/
      33280)
        datacell_changes.focused = /*$focusedCellId*/
        ctx2[9] === /*cellId*/
        ctx2[65];
      if (dirty[0] & /*$scrollableColumns*/
      32768)
        datacell_changes.width = /*column*/
        ctx2[64].width;
      if (dirty[0] & /*offset*/
      1)
        datacell_changes.topRow = /*offset*/
        ctx2[0] === 0;
      if (dirty[0] & /*$columnRenderMap, $scrollableColumns*/
      98304)
        datacell_changes.hidden = !/*$columnRenderMap*/
        ctx2[16][
          /*column*/
          ctx2[64].name
        ];
      if (dirty[0] & /*isAdding, $scrollableColumns*/
      32776 | dirty[2] & /*$$scope*/
      64) {
        datacell_changes.$$scope = { dirty, ctx: ctx2 };
      }
      datacell.$set(datacell_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(datacell.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(datacell.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(datacell, detaching);
    }
  };
}
function create_default_slot_2(ctx) {
  let div;
  let current;
  let each_value = ensure_array_like(
    /*$scrollableColumns*/
    ctx[15]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "row svelte-8ib1kg");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*$scrollableColumns, newRow, $focusedCellId, offset, $columnRenderMap, isAdding*/
      98841 | dirty[1] & /*updateValue*/
      1024) {
        each_value = ensure_array_like(
          /*$scrollableColumns*/
          ctx2[15]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div, null);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let div;
  let t;
  let keyboardshortcut;
  let current;
  keyboardshortcut = new KeyboardShortcut({
    props: { overlay: true, keybind: "Ctrl+Enter" }
  });
  return {
    c() {
      div = element("div");
      t = text("Save\n          ");
      create_component(keyboardshortcut.$$.fragment);
      attr(div, "class", "button-with-keys svelte-8ib1kg");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
      mount_component(keyboardshortcut, div, null);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(keyboardshortcut.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(keyboardshortcut.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(keyboardshortcut);
    }
  };
}
function create_default_slot(ctx) {
  let div;
  let t;
  let keyboardshortcut;
  let current;
  keyboardshortcut = new KeyboardShortcut({ props: { keybind: "Esc" } });
  return {
    c() {
      div = element("div");
      t = text("Cancel\n          ");
      create_component(keyboardshortcut.$$.fragment);
      attr(div, "class", "button-with-keys svelte-8ib1kg");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
      mount_component(keyboardshortcut, div, null);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(keyboardshortcut.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(keyboardshortcut.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(keyboardshortcut);
    }
  };
}
function create_fragment$2(ctx) {
  var _a, _b;
  let temptooltip;
  let t;
  let if_block_anchor;
  let current;
  temptooltip = new TempTooltip({
    props: {
      text: "Click here to create your first row",
      condition: (
        /*hasNoRows*/
        ctx[6] && /*$loaded*/
        ctx[10] && !/*$filter*/
        ((_a = ctx[11]) == null ? void 0 : _a.length) && !/*$inlineFilters*/
        ((_b = ctx[12]) == null ? void 0 : _b.length) && !/*$refreshing*/
        ctx[13]
      ),
      type: TooltipType.Info,
      $$slots: { default: [create_default_slot_6] },
      $$scope: { ctx }
    }
  });
  let if_block = (
    /*visible*/
    ctx[2] && create_if_block$1(ctx)
  );
  return {
    c() {
      create_component(temptooltip.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      mount_component(temptooltip, target, anchor);
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2, _b2;
      const temptooltip_changes = {};
      if (dirty[0] & /*hasNoRows, $loaded, $filter, $inlineFilters, $refreshing*/
      15424)
        temptooltip_changes.condition = /*hasNoRows*/
        ctx2[6] && /*$loaded*/
        ctx2[10] && !/*$filter*/
        ((_a2 = ctx2[11]) == null ? void 0 : _a2.length) && !/*$inlineFilters*/
        ((_b2 = ctx2[12]) == null ? void 0 : _b2.length) && !/*$refreshing*/
        ctx2[13];
      if (dirty[0] & /*$displayColumn, visible, selectedRowCount, $config*/
      16518 | dirty[2] & /*$$scope*/
      64) {
        temptooltip_changes.$$scope = { dirty, ctx: ctx2 };
      }
      temptooltip.$set(temptooltip_changes);
      if (
        /*visible*/
        ctx2[2]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*visible*/
          4) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(temptooltip.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(temptooltip.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      destroy_component(temptooltip, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance$2($$self, $$props, $$invalidate) {
  let firstColumn;
  let width;
  let selectedRowCount;
  let hasNoRows;
  let renderedRowCount;
  let spaceBelow;
  let flipButtons;
  let $focusedCellAPI;
  let $focusedCellId;
  let $hoveredRowId;
  let $maxScrollTop;
  let $hasNextPage;
  let $rowHeight;
  let $height;
  let $scrollTop;
  let $renderedRows;
  let $rows;
  let $selectedRows;
  let $datasource;
  let $displayColumn;
  let $visibleColumns;
  let $loaded;
  let $filter;
  let $inlineFilters;
  let $refreshing;
  let $config;
  let $scrollableColumns;
  let $columnRenderMap;
  const { hoveredRowId, focusedCellId, displayColumn, scroll, dispatch, rows, focusedCellAPI, datasource, subscribe: subscribe2, renderedRows, scrollableColumns, rowHeight, hasNextPage, maxScrollTop, selectedRows, loaded, refreshing, config, filter, inlineFilters, columnRenderMap, visibleColumns, scrollTop, height } = getContext("grid");
  component_subscribe($$self, hoveredRowId, (value) => $$invalidate(57, $hoveredRowId = value));
  component_subscribe($$self, focusedCellId, (value) => $$invalidate(9, $focusedCellId = value));
  component_subscribe($$self, displayColumn, (value) => $$invalidate(1, $displayColumn = value));
  component_subscribe($$self, rows, (value) => $$invalidate(50, $rows = value));
  component_subscribe($$self, focusedCellAPI, (value) => $$invalidate(56, $focusedCellAPI = value));
  component_subscribe($$self, datasource, (value) => $$invalidate(52, $datasource = value));
  component_subscribe($$self, renderedRows, (value) => $$invalidate(49, $renderedRows = value));
  component_subscribe($$self, scrollableColumns, (value) => $$invalidate(15, $scrollableColumns = value));
  component_subscribe($$self, rowHeight, (value) => $$invalidate(46, $rowHeight = value));
  component_subscribe($$self, hasNextPage, (value) => $$invalidate(45, $hasNextPage = value));
  component_subscribe($$self, maxScrollTop, (value) => $$invalidate(58, $maxScrollTop = value));
  component_subscribe($$self, selectedRows, (value) => $$invalidate(51, $selectedRows = value));
  component_subscribe($$self, loaded, (value) => $$invalidate(10, $loaded = value));
  component_subscribe($$self, refreshing, (value) => $$invalidate(13, $refreshing = value));
  component_subscribe($$self, config, (value) => $$invalidate(14, $config = value));
  component_subscribe($$self, filter, (value) => $$invalidate(11, $filter = value));
  component_subscribe($$self, inlineFilters, (value) => $$invalidate(12, $inlineFilters = value));
  component_subscribe($$self, columnRenderMap, (value) => $$invalidate(16, $columnRenderMap = value));
  component_subscribe($$self, visibleColumns, (value) => $$invalidate(53, $visibleColumns = value));
  component_subscribe($$self, scrollTop, (value) => $$invalidate(48, $scrollTop = value));
  component_subscribe($$self, height, (value) => $$invalidate(47, $height = value));
  let visible = false;
  let isAdding = false;
  let newRow;
  let offset = 0;
  const getOffset = (hasNextPage2, rowCount, rowHeight2, scrollTop2) => {
    if (hasNextPage2) {
      return 0;
    }
    $$invalidate(0, offset = rowCount * rowHeight2 - scrollTop2 % rowHeight2);
    if (rowCount !== 0) {
      $$invalidate(0, offset -= 1);
    }
    return offset;
  };
  const addRow = async () => {
    $$invalidate(3, isAdding = true);
    set_store_value(focusedCellId, $focusedCellId = null, $focusedCellId);
    await tick();
    const newRowIndex = offset ? void 0 : 0;
    let rowToCreate = { ...newRow };
    delete rowToCreate._isNewRow;
    const savedRow = await rows.actions.addRow({ row: rowToCreate, idx: newRowIndex });
    if (savedRow) {
      clear();
      if (firstColumn) {
        set_store_value(focusedCellId, $focusedCellId = getCellID(savedRow._id, firstColumn.name), $focusedCellId);
      }
    }
    $$invalidate(3, isAdding = false);
  };
  const clear = () => {
    $$invalidate(3, isAdding = false);
    $$invalidate(2, visible = false);
    set_store_value(focusedCellId, $focusedCellId = null, $focusedCellId);
    set_store_value(hoveredRowId, $hoveredRowId = null, $hoveredRowId);
    document.removeEventListener("keydown", handleKeyPress);
  };
  const startAdding = async () => {
    if (visible && !isAdding) {
      await addRow();
      return;
    }
    if (visible || !firstColumn) {
      return;
    }
    if (!$hasNextPage) {
      scroll.update((state) => ({ ...state, top: $maxScrollTop }));
    }
    $$invalidate(4, newRow = { _isNewRow: true });
    $$invalidate(2, visible = true);
    set_store_value(hoveredRowId, $hoveredRowId = NewRowID, $hoveredRowId);
    if (firstColumn) {
      set_store_value(focusedCellId, $focusedCellId = getCellID(NewRowID, firstColumn.name), $focusedCellId);
    }
    document.addEventListener("keydown", handleKeyPress);
  };
  const updateValue = ({ column, value }) => {
    $$invalidate(4, newRow[column] = value, newRow);
  };
  const addViaModal = () => {
    clear();
    dispatch("add-row");
  };
  const handleKeyPress = (e) => {
    if (!visible) {
      return;
    }
    if (e.key === "Escape") {
      if (!($focusedCellAPI == null ? void 0 : $focusedCellAPI.isActive())) {
        e.preventDefault();
        clear();
      }
    }
  };
  onMount(() => subscribe2("add-row-inline", startAdding));
  onDestroy(() => {
    document.removeEventListener("keydown", handleKeyPress);
  });
  const click_handler = () => dispatch("add-row-inline");
  $$self.$$.update = () => {
    if ($$self.$$.dirty[1] & /*$visibleColumns*/
    4194304) {
      firstColumn = $visibleColumns[0];
    }
    if ($$self.$$.dirty[0] & /*$displayColumn*/
    2) {
      $$invalidate(8, width = GutterWidth + (($displayColumn == null ? void 0 : $displayColumn.width) || 0));
    }
    if ($$self.$$.dirty[1] & /*$datasource*/
    2097152) {
      $$invalidate(2, visible = false);
    }
    if ($$self.$$.dirty[1] & /*$selectedRows*/
    1048576) {
      $$invalidate(7, selectedRowCount = Object.values($selectedRows).length);
    }
    if ($$self.$$.dirty[1] & /*$rows*/
    524288) {
      $$invalidate(6, hasNoRows = !$rows.length);
    }
    if ($$self.$$.dirty[1] & /*$renderedRows*/
    262144) {
      $$invalidate(44, renderedRowCount = $renderedRows.length);
    }
    if ($$self.$$.dirty[1] & /*$hasNextPage, renderedRowCount, $rowHeight, $scrollTop*/
    188416) {
      $$invalidate(0, offset = getOffset($hasNextPage, renderedRowCount, $rowHeight, $scrollTop));
    }
    if ($$self.$$.dirty[0] & /*offset*/
    1 | $$self.$$.dirty[1] & /*$height, $rowHeight*/
    98304) {
      $$invalidate(43, spaceBelow = $height - offset - $rowHeight);
    }
    if ($$self.$$.dirty[1] & /*spaceBelow*/
    4096) {
      $$invalidate(5, flipButtons = spaceBelow < 36 + DefaultRowHeight);
    }
  };
  return [
    offset,
    $displayColumn,
    visible,
    isAdding,
    newRow,
    flipButtons,
    hasNoRows,
    selectedRowCount,
    width,
    $focusedCellId,
    $loaded,
    $filter,
    $inlineFilters,
    $refreshing,
    $config,
    $scrollableColumns,
    $columnRenderMap,
    hoveredRowId,
    focusedCellId,
    displayColumn,
    dispatch,
    rows,
    focusedCellAPI,
    datasource,
    renderedRows,
    scrollableColumns,
    rowHeight,
    hasNextPage,
    maxScrollTop,
    selectedRows,
    loaded,
    refreshing,
    config,
    filter,
    inlineFilters,
    columnRenderMap,
    visibleColumns,
    scrollTop,
    height,
    addRow,
    clear,
    updateValue,
    addViaModal,
    spaceBelow,
    renderedRowCount,
    $hasNextPage,
    $rowHeight,
    $height,
    $scrollTop,
    $renderedRows,
    $rows,
    $selectedRows,
    $datasource,
    $visibleColumns,
    click_handler
  ];
}
class NewRow extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$2, create_fragment$2, safe_not_equal, {}, null, [-1, -1, -1]);
  }
}
const createGridWebsocket = (context) => {
  const { rows, datasource, users, focusedCellId, definition, API } = context;
  const socket = createWebsocket("/socket/grid");
  const connectToDatasource = (datasource2) => {
    if (!socket.connected) {
      return;
    }
    const appId = API.getAppID();
    socket.emit(
      GridSocketEvent.SelectDatasource,
      {
        datasource: datasource2,
        appId
      },
      ({ users: gridUsers }) => {
        users.set(gridUsers);
      }
    );
  };
  socket.on("connect", () => {
    connectToDatasource(get_store_value(datasource));
  });
  socket.on("connect_error", (err) => {
    console.error("Failed to connect to grid websocket:", err.message);
  });
  socket.onOther(SocketEvent.UserUpdate, ({ user }) => {
    users.actions.updateUser(user);
  });
  socket.onOther(SocketEvent.UserDisconnect, ({ sessionId }) => {
    users.actions.removeUser(sessionId);
  });
  socket.onOther(GridSocketEvent.RowChange, async ({ id, row }) => {
    if (id) {
      rows.actions.replaceRow(id, row);
    } else if (row.id) {
      await rows.actions.refreshRow(row.id);
    }
  });
  socket.onOther(
    GridSocketEvent.DatasourceChange,
    ({ datasource: newDatasource }) => {
      if (newDatasource) {
        definition.set(newDatasource);
      }
    }
  );
  socket.on(
    GridSocketEvent.DatasourceChange,
    ({ datasource: newDatasource }) => {
      var _a;
      if ((newDatasource == null ? void 0 : newDatasource.name) !== ((_a = get_store_value(definition)) == null ? void 0 : _a.name)) {
        definition.set(newDatasource);
      }
    }
  );
  datasource.subscribe(connectToDatasource);
  focusedCellId.subscribe(($focusedCellId) => {
    socket.emit(GridSocketEvent.SelectCell, { cellId: $focusedCellId });
  });
  return () => socket == null ? void 0 : socket.disconnect();
};
const get_add_column_slot_changes = (dirty) => ({});
const get_add_column_slot_context = (ctx) => ({});
const get_edit_column_slot_changes_1 = (dirty) => ({});
const get_edit_column_slot_context_1 = (ctx) => ({});
const get_edit_column_slot_changes = (dirty) => ({});
const get_edit_column_slot_context = (ctx) => ({});
const get_controls_right_slot_changes = (dirty) => ({});
const get_controls_right_slot_context = (ctx) => ({});
const get_controls_slot_changes = (dirty) => ({});
const get_controls_slot_context = (ctx) => ({});
function create_if_block_6(ctx) {
  let div2;
  let div0;
  let t0;
  let div1;
  let t1;
  let current;
  const controls_slot_template = (
    /*#slots*/
    ctx[52].controls
  );
  const controls_slot = create_slot(
    controls_slot_template,
    ctx,
    /*$$scope*/
    ctx[55],
    get_controls_slot_context
  );
  const controls_right_slot_template = (
    /*#slots*/
    ctx[52]["controls-right"]
  );
  const controls_right_slot = create_slot(
    controls_right_slot_template,
    ctx,
    /*$$scope*/
    ctx[55],
    get_controls_right_slot_context
  );
  let if_block = (
    /*showAvatars*/
    ctx[2] && create_if_block_7()
  );
  return {
    c() {
      div2 = element("div");
      div0 = element("div");
      if (controls_slot)
        controls_slot.c();
      t0 = space();
      div1 = element("div");
      if (controls_right_slot)
        controls_right_slot.c();
      t1 = space();
      if (if_block)
        if_block.c();
      attr(div0, "class", "controls-left svelte-fdk5zl");
      attr(div1, "class", "controls-right svelte-fdk5zl");
      attr(div2, "class", "controls svelte-fdk5zl");
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, div0);
      if (controls_slot) {
        controls_slot.m(div0, null);
      }
      append(div2, t0);
      append(div2, div1);
      if (controls_right_slot) {
        controls_right_slot.m(div1, null);
      }
      append(div1, t1);
      if (if_block)
        if_block.m(div1, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (controls_slot) {
        if (controls_slot.p && (!current || dirty[1] & /*$$scope*/
        16777216)) {
          update_slot_base(
            controls_slot,
            controls_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[55],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[55]
            ) : get_slot_changes(
              controls_slot_template,
              /*$$scope*/
              ctx2[55],
              dirty,
              get_controls_slot_changes
            ),
            get_controls_slot_context
          );
        }
      }
      if (controls_right_slot) {
        if (controls_right_slot.p && (!current || dirty[1] & /*$$scope*/
        16777216)) {
          update_slot_base(
            controls_right_slot,
            controls_right_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[55],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[55]
            ) : get_slot_changes(
              controls_right_slot_template,
              /*$$scope*/
              ctx2[55],
              dirty,
              get_controls_right_slot_changes
            ),
            get_controls_right_slot_context
          );
        }
      }
      if (
        /*showAvatars*/
        ctx2[2]
      ) {
        if (if_block) {
          if (dirty[0] & /*showAvatars*/
          4) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_7();
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div1, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(controls_slot, local);
      transition_in(controls_right_slot, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(controls_slot, local);
      transition_out(controls_right_slot, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div2);
      }
      if (controls_slot)
        controls_slot.d(detaching);
      if (controls_right_slot)
        controls_right_slot.d(detaching);
      if (if_block)
        if_block.d();
    }
  };
}
function create_if_block_7(ctx) {
  let useravatars;
  let current;
  useravatars = new UserAvatars({});
  return {
    c() {
      create_component(useravatars.$$.fragment);
    },
    m(target, anchor) {
      mount_component(useravatars, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(useravatars.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(useravatars.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(useravatars, detaching);
    }
  };
}
function create_if_block_4(ctx) {
  let div3;
  let div2;
  let stickycolumn;
  let t0;
  let div0;
  let headerrow;
  let t1;
  let gridbody;
  let t2;
  let t3;
  let div1;
  let resizeoverlay;
  let t4;
  let reorderoverlay;
  let t5;
  let scrolloverlay;
  let t6;
  let menuoverlay;
  let t7;
  let popoveroverlay;
  let current;
  let mounted;
  let dispose;
  stickycolumn = new StickyColumn({
    props: {
      $$slots: {
        "edit-column": [create_edit_column_slot_1]
      },
      $$scope: { ctx }
    }
  });
  headerrow = new HeaderRow({
    props: {
      $$slots: {
        "edit-column": [create_edit_column_slot],
        "add-column": [create_add_column_slot]
      },
      $$scope: { ctx }
    }
  });
  gridbody = new GridBody({});
  let if_block = (
    /*$config*/
    ctx[10].canAddRows && create_if_block_5()
  );
  resizeoverlay = new ResizeOverlay({});
  reorderoverlay = new ReorderOverlay({});
  scrolloverlay = new ScrollOverlay({});
  menuoverlay = new MenuOverlay({});
  popoveroverlay = new PopoverOverlay({});
  return {
    c() {
      div3 = element("div");
      div2 = element("div");
      create_component(stickycolumn.$$.fragment);
      t0 = space();
      div0 = element("div");
      create_component(headerrow.$$.fragment);
      t1 = space();
      create_component(gridbody.$$.fragment);
      t2 = space();
      if (if_block)
        if_block.c();
      t3 = space();
      div1 = element("div");
      create_component(resizeoverlay.$$.fragment);
      t4 = space();
      create_component(reorderoverlay.$$.fragment);
      t5 = space();
      create_component(scrolloverlay.$$.fragment);
      t6 = space();
      create_component(menuoverlay.$$.fragment);
      t7 = space();
      create_component(popoveroverlay.$$.fragment);
      attr(div0, "class", "grid-data-content svelte-fdk5zl");
      attr(div1, "class", "overlays svelte-fdk5zl");
      attr(div2, "class", "grid-data-inner svelte-fdk5zl");
      attr(div3, "class", "grid-data-outer svelte-fdk5zl");
    },
    m(target, anchor) {
      insert(target, div3, anchor);
      append(div3, div2);
      mount_component(stickycolumn, div2, null);
      append(div2, t0);
      append(div2, div0);
      mount_component(headerrow, div0, null);
      append(div0, t1);
      mount_component(gridbody, div0, null);
      append(div2, t2);
      if (if_block)
        if_block.m(div2, null);
      append(div2, t3);
      append(div2, div1);
      mount_component(resizeoverlay, div1, null);
      append(div1, t4);
      mount_component(reorderoverlay, div1, null);
      append(div1, t5);
      mount_component(scrolloverlay, div1, null);
      append(div1, t6);
      mount_component(menuoverlay, div1, null);
      append(div1, t7);
      mount_component(popoveroverlay, div1, null);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(clickOutside.call(
          null,
          div3,
          /*ui*/
          ctx[16].actions.blur
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      const stickycolumn_changes = {};
      if (dirty[1] & /*$$scope*/
      16777216) {
        stickycolumn_changes.$$scope = { dirty, ctx: ctx2 };
      }
      stickycolumn.$set(stickycolumn_changes);
      const headerrow_changes = {};
      if (dirty[1] & /*$$scope*/
      16777216) {
        headerrow_changes.$$scope = { dirty, ctx: ctx2 };
      }
      headerrow.$set(headerrow_changes);
      if (
        /*$config*/
        ctx2[10].canAddRows
      ) {
        if (if_block) {
          if (dirty[0] & /*$config*/
          1024) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_5();
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div2, t3);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(stickycolumn.$$.fragment, local);
      transition_in(headerrow.$$.fragment, local);
      transition_in(gridbody.$$.fragment, local);
      transition_in(if_block);
      transition_in(resizeoverlay.$$.fragment, local);
      transition_in(reorderoverlay.$$.fragment, local);
      transition_in(scrolloverlay.$$.fragment, local);
      transition_in(menuoverlay.$$.fragment, local);
      transition_in(popoveroverlay.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(stickycolumn.$$.fragment, local);
      transition_out(headerrow.$$.fragment, local);
      transition_out(gridbody.$$.fragment, local);
      transition_out(if_block);
      transition_out(resizeoverlay.$$.fragment, local);
      transition_out(reorderoverlay.$$.fragment, local);
      transition_out(scrolloverlay.$$.fragment, local);
      transition_out(menuoverlay.$$.fragment, local);
      transition_out(popoveroverlay.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div3);
      }
      destroy_component(stickycolumn);
      destroy_component(headerrow);
      destroy_component(gridbody);
      if (if_block)
        if_block.d();
      destroy_component(resizeoverlay);
      destroy_component(reorderoverlay);
      destroy_component(scrolloverlay);
      destroy_component(menuoverlay);
      destroy_component(popoveroverlay);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block_3(ctx) {
  let div2;
  let div0;
  let t1;
  let div1;
  let t2;
  return {
    c() {
      div2 = element("div");
      div0 = element("div");
      div0.textContent = "There was a problem loading your grid";
      t1 = space();
      div1 = element("div");
      t2 = text(
        /*$error*/
        ctx[8]
      );
      attr(div0, "class", "grid-error-title svelte-fdk5zl");
      attr(div1, "class", "grid-error-subtitle svelte-fdk5zl");
      attr(div2, "class", "grid-error svelte-fdk5zl");
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, div0);
      append(div2, t1);
      append(div2, div1);
      append(div1, t2);
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*$error*/
      256)
        set_data(
          t2,
          /*$error*/
          ctx2[8]
        );
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div2);
      }
    }
  };
}
function create_edit_column_slot_1(ctx) {
  let current;
  const edit_column_slot_template = (
    /*#slots*/
    ctx[52]["edit-column"]
  );
  const edit_column_slot = create_slot(
    edit_column_slot_template,
    ctx,
    /*$$scope*/
    ctx[55],
    get_edit_column_slot_context
  );
  return {
    c() {
      if (edit_column_slot)
        edit_column_slot.c();
    },
    m(target, anchor) {
      if (edit_column_slot) {
        edit_column_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (edit_column_slot) {
        if (edit_column_slot.p && (!current || dirty[1] & /*$$scope*/
        16777216)) {
          update_slot_base(
            edit_column_slot,
            edit_column_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[55],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[55]
            ) : get_slot_changes(
              edit_column_slot_template,
              /*$$scope*/
              ctx2[55],
              dirty,
              get_edit_column_slot_changes
            ),
            get_edit_column_slot_context
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(edit_column_slot, local);
      current = true;
    },
    o(local) {
      transition_out(edit_column_slot, local);
      current = false;
    },
    d(detaching) {
      if (edit_column_slot)
        edit_column_slot.d(detaching);
    }
  };
}
function create_add_column_slot(ctx) {
  let current;
  const add_column_slot_template = (
    /*#slots*/
    ctx[52]["add-column"]
  );
  const add_column_slot = create_slot(
    add_column_slot_template,
    ctx,
    /*$$scope*/
    ctx[55],
    get_add_column_slot_context
  );
  return {
    c() {
      if (add_column_slot)
        add_column_slot.c();
    },
    m(target, anchor) {
      if (add_column_slot) {
        add_column_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (add_column_slot) {
        if (add_column_slot.p && (!current || dirty[1] & /*$$scope*/
        16777216)) {
          update_slot_base(
            add_column_slot,
            add_column_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[55],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[55]
            ) : get_slot_changes(
              add_column_slot_template,
              /*$$scope*/
              ctx2[55],
              dirty,
              get_add_column_slot_changes
            ),
            get_add_column_slot_context
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(add_column_slot, local);
      current = true;
    },
    o(local) {
      transition_out(add_column_slot, local);
      current = false;
    },
    d(detaching) {
      if (add_column_slot)
        add_column_slot.d(detaching);
    }
  };
}
function create_edit_column_slot(ctx) {
  let current;
  const edit_column_slot_template = (
    /*#slots*/
    ctx[52]["edit-column"]
  );
  const edit_column_slot = create_slot(
    edit_column_slot_template,
    ctx,
    /*$$scope*/
    ctx[55],
    get_edit_column_slot_context_1
  );
  return {
    c() {
      if (edit_column_slot)
        edit_column_slot.c();
    },
    m(target, anchor) {
      if (edit_column_slot) {
        edit_column_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (edit_column_slot) {
        if (edit_column_slot.p && (!current || dirty[1] & /*$$scope*/
        16777216)) {
          update_slot_base(
            edit_column_slot,
            edit_column_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[55],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[55]
            ) : get_slot_changes(
              edit_column_slot_template,
              /*$$scope*/
              ctx2[55],
              dirty,
              get_edit_column_slot_changes_1
            ),
            get_edit_column_slot_context_1
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(edit_column_slot, local);
      current = true;
    },
    o(local) {
      transition_out(edit_column_slot, local);
      current = false;
    },
    d(detaching) {
      if (edit_column_slot)
        edit_column_slot.d(detaching);
    }
  };
}
function create_if_block_5(ctx) {
  let newrow;
  let current;
  newrow = new NewRow({});
  return {
    c() {
      create_component(newrow.$$.fragment);
    },
    m(target, anchor) {
      mount_component(newrow, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(newrow.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(newrow.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(newrow, detaching);
    }
  };
}
function create_if_block_2(ctx) {
  let div;
  let progresscircle;
  let div_intro;
  let current;
  progresscircle = new ProgressCircle({});
  return {
    c() {
      div = element("div");
      create_component(progresscircle.$$.fragment);
      attr(div, "class", "grid-loading svelte-fdk5zl");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(progresscircle, div, null);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(progresscircle.$$.fragment, local);
      if (local) {
        if (!div_intro) {
          add_render_callback(() => {
            div_intro = create_in_transition(div, fade, { duration: 130 });
            div_intro.start();
          });
        }
      }
      current = true;
    },
    o(local) {
      transition_out(progresscircle.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(progresscircle);
    }
  };
}
function create_if_block_1(ctx) {
  let bulkduplicationhandler;
  let current;
  bulkduplicationhandler = new BulkDuplicationHandler({});
  return {
    c() {
      create_component(bulkduplicationhandler.$$.fragment);
    },
    m(target, anchor) {
      mount_component(bulkduplicationhandler, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(bulkduplicationhandler.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(bulkduplicationhandler.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(bulkduplicationhandler, detaching);
    }
  };
}
function create_if_block(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[52].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[55],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty[1] & /*$$scope*/
        16777216)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[55],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[55]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[55],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_fragment$1(ctx) {
  let div;
  let t0;
  let current_block_type_index;
  let if_block1;
  let t1;
  let t2;
  let t3;
  let bulkdeletehandler;
  let t4;
  let clipboardhandler;
  let t5;
  let keyboardmanager;
  let t6;
  let current;
  let mounted;
  let dispose;
  let if_block0 = (
    /*$$slots*/
    ctx[25].controls && create_if_block_6(ctx)
  );
  const if_block_creators = [create_if_block_3, create_if_block_4];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*$error*/
      ctx2[8]
    )
      return 0;
    if (
      /*$loaded*/
      ctx2[9]
    )
      return 1;
    return -1;
  }
  if (~(current_block_type_index = select_block_type(ctx))) {
    if_block1 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  }
  let if_block2 = (
    /*$loading*/
    ctx[11] && !/*$error*/
    ctx[8] && create_if_block_2()
  );
  let if_block3 = (
    /*$config*/
    ctx[10].canAddRows && create_if_block_1()
  );
  bulkdeletehandler = new BulkDeleteHandler({});
  clipboardhandler = new ClipboardHandler({});
  keyboardmanager = new KeyboardManager({});
  let if_block4 = (
    /*$loaded*/
    ctx[9] && create_if_block(ctx)
  );
  return {
    c() {
      div = element("div");
      if (if_block0)
        if_block0.c();
      t0 = space();
      if (if_block1)
        if_block1.c();
      t1 = space();
      if (if_block2)
        if_block2.c();
      t2 = space();
      if (if_block3)
        if_block3.c();
      t3 = space();
      create_component(bulkdeletehandler.$$.fragment);
      t4 = space();
      create_component(clipboardhandler.$$.fragment);
      t5 = space();
      create_component(keyboardmanager.$$.fragment);
      t6 = space();
      if (if_block4)
        if_block4.c();
      attr(div, "class", "grid svelte-fdk5zl");
      attr(
        div,
        "id",
        /*gridID*/
        ctx[12]
      );
      set_style(
        div,
        "--row-height",
        /*$rowHeight*/
        ctx[5] + "px"
      );
      set_style(div, "--default-row-height", DefaultRowHeight + "px");
      set_style(div, "--gutter-width", GutterWidth + "px");
      set_style(div, "--max-cell-render-overflow", MaxCellRenderOverflow + "px");
      set_style(
        div,
        "--content-lines",
        /*$contentLines*/
        ctx[6]
      );
      set_style(
        div,
        "--min-height",
        /*$minHeight*/
        ctx[7] + "px"
      );
      set_style(div, "--controls-height", ControlsHeight + "px");
      set_style(div, "--scroll-bar-size", ScrollBarSize + "px");
      toggle_class(
        div,
        "is-resizing",
        /*$isResizing*/
        ctx[3]
      );
      toggle_class(
        div,
        "is-reordering",
        /*$isReordering*/
        ctx[4]
      );
      toggle_class(
        div,
        "stripe",
        /*stripeRows*/
        ctx[0]
      );
      toggle_class(
        div,
        "quiet",
        /*quiet*/
        ctx[1]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block0)
        if_block0.m(div, null);
      append(div, t0);
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].m(div, null);
      }
      append(div, t1);
      if (if_block2)
        if_block2.m(div, null);
      append(div, t2);
      if (if_block3)
        if_block3.m(div, null);
      append(div, t3);
      mount_component(bulkdeletehandler, div, null);
      append(div, t4);
      mount_component(clipboardhandler, div, null);
      append(div, t5);
      mount_component(keyboardmanager, div, null);
      append(div, t6);
      if (if_block4)
        if_block4.m(div, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            div,
            "mouseenter",
            /*mouseenter_handler*/
            ctx[53]
          ),
          listen(
            div,
            "mouseleave",
            /*mouseleave_handler*/
            ctx[54]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (
        /*$$slots*/
        ctx2[25].controls
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty[0] & /*$$slots*/
          33554432) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_6(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(div, t0);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if (~current_block_type_index) {
          if_blocks[current_block_type_index].p(ctx2, dirty);
        }
      } else {
        if (if_block1) {
          group_outros();
          transition_out(if_blocks[previous_block_index], 1, 1, () => {
            if_blocks[previous_block_index] = null;
          });
          check_outros();
        }
        if (~current_block_type_index) {
          if_block1 = if_blocks[current_block_type_index];
          if (!if_block1) {
            if_block1 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
            if_block1.c();
          } else {
            if_block1.p(ctx2, dirty);
          }
          transition_in(if_block1, 1);
          if_block1.m(div, t1);
        } else {
          if_block1 = null;
        }
      }
      if (
        /*$loading*/
        ctx2[11] && !/*$error*/
        ctx2[8]
      ) {
        if (if_block2) {
          if (dirty[0] & /*$loading, $error*/
          2304) {
            transition_in(if_block2, 1);
          }
        } else {
          if_block2 = create_if_block_2();
          if_block2.c();
          transition_in(if_block2, 1);
          if_block2.m(div, t2);
        }
      } else if (if_block2) {
        group_outros();
        transition_out(if_block2, 1, 1, () => {
          if_block2 = null;
        });
        check_outros();
      }
      if (
        /*$config*/
        ctx2[10].canAddRows
      ) {
        if (if_block3) {
          if (dirty[0] & /*$config*/
          1024) {
            transition_in(if_block3, 1);
          }
        } else {
          if_block3 = create_if_block_1();
          if_block3.c();
          transition_in(if_block3, 1);
          if_block3.m(div, t3);
        }
      } else if (if_block3) {
        group_outros();
        transition_out(if_block3, 1, 1, () => {
          if_block3 = null;
        });
        check_outros();
      }
      if (
        /*$loaded*/
        ctx2[9]
      ) {
        if (if_block4) {
          if_block4.p(ctx2, dirty);
          if (dirty[0] & /*$loaded*/
          512) {
            transition_in(if_block4, 1);
          }
        } else {
          if_block4 = create_if_block(ctx2);
          if_block4.c();
          transition_in(if_block4, 1);
          if_block4.m(div, null);
        }
      } else if (if_block4) {
        group_outros();
        transition_out(if_block4, 1, 1, () => {
          if_block4 = null;
        });
        check_outros();
      }
      if (!current || dirty[0] & /*$rowHeight*/
      32) {
        set_style(
          div,
          "--row-height",
          /*$rowHeight*/
          ctx2[5] + "px"
        );
      }
      if (!current || dirty[0] & /*$contentLines*/
      64) {
        set_style(
          div,
          "--content-lines",
          /*$contentLines*/
          ctx2[6]
        );
      }
      if (!current || dirty[0] & /*$minHeight*/
      128) {
        set_style(
          div,
          "--min-height",
          /*$minHeight*/
          ctx2[7] + "px"
        );
      }
      if (!current || dirty[0] & /*$isResizing*/
      8) {
        toggle_class(
          div,
          "is-resizing",
          /*$isResizing*/
          ctx2[3]
        );
      }
      if (!current || dirty[0] & /*$isReordering*/
      16) {
        toggle_class(
          div,
          "is-reordering",
          /*$isReordering*/
          ctx2[4]
        );
      }
      if (!current || dirty[0] & /*stripeRows*/
      1) {
        toggle_class(
          div,
          "stripe",
          /*stripeRows*/
          ctx2[0]
        );
      }
      if (!current || dirty[0] & /*quiet*/
      2) {
        toggle_class(
          div,
          "quiet",
          /*quiet*/
          ctx2[1]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      transition_in(if_block2);
      transition_in(if_block3);
      transition_in(bulkdeletehandler.$$.fragment, local);
      transition_in(clipboardhandler.$$.fragment, local);
      transition_in(keyboardmanager.$$.fragment, local);
      transition_in(if_block4);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      transition_out(if_block2);
      transition_out(if_block3);
      transition_out(bulkdeletehandler.$$.fragment, local);
      transition_out(clipboardhandler.$$.fragment, local);
      transition_out(keyboardmanager.$$.fragment, local);
      transition_out(if_block4);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block0)
        if_block0.d();
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].d();
      }
      if (if_block2)
        if_block2.d();
      if (if_block3)
        if_block3.d();
      destroy_component(bulkdeletehandler);
      destroy_component(clipboardhandler);
      destroy_component(keyboardmanager);
      if (if_block4)
        if_block4.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let $definitionMissing;
  let $isResizing;
  let $isReordering;
  let $rowHeight;
  let $contentLines;
  let $minHeight;
  let $error;
  let $loaded;
  let $config;
  let $loading;
  let { $$slots: slots = {}, $$scope } = $$props;
  const $$slots = compute_slots(slots);
  let { API = null } = $$props;
  let { datasource = null } = $$props;
  let { schemaOverrides = null } = $$props;
  let { canAddRows = true } = $$props;
  let { canExpandRows = true } = $$props;
  let { canEditRows = true } = $$props;
  let { canDeleteRows = true } = $$props;
  let { canEditColumns = true } = $$props;
  let { canSaveSchema = true } = $$props;
  let { stripeRows = false } = $$props;
  let { quiet = false } = $$props;
  let { collaboration = true } = $$props;
  let { showAvatars = true } = $$props;
  let { initialFilter = null } = $$props;
  let { initialSortColumn = null } = $$props;
  let { initialSortOrder = null } = $$props;
  let { fixedRowHeight = null } = $$props;
  let { notifySuccess = null } = $$props;
  let { notifyError = null } = $$props;
  let { buttons = null } = $$props;
  let { buttonsCollapsed = false } = $$props;
  let { buttonsCollapsedText = null } = $$props;
  let { darkMode = false } = $$props;
  let { isCloud = null } = $$props;
  let { aiEnabled = false } = $$props;
  let { canHideColumns = true } = $$props;
  let { externalClipboard = void 0 } = $$props;
  const gridID = `grid-${Math.random().toString().slice(2)}`;
  const props = writable($$props);
  let context = attachStores({
    API: API || createAPIClient(),
    Constants,
    gridID,
    props,
    ...createEventManagers()
  });
  const { config, isResizing, isReordering, ui, loaded, loading, rowHeight, contentLines, gridFocused, error, definitionMissing, dispatch } = context;
  component_subscribe($$self, config, (value) => $$invalidate(10, $config = value));
  component_subscribe($$self, isResizing, (value) => $$invalidate(3, $isResizing = value));
  component_subscribe($$self, isReordering, (value) => $$invalidate(4, $isReordering = value));
  component_subscribe($$self, loaded, (value) => $$invalidate(9, $loaded = value));
  component_subscribe($$self, loading, (value) => $$invalidate(11, $loading = value));
  component_subscribe($$self, rowHeight, (value) => $$invalidate(5, $rowHeight = value));
  component_subscribe($$self, contentLines, (value) => $$invalidate(6, $contentLines = value));
  component_subscribe($$self, error, (value) => $$invalidate(8, $error = value));
  component_subscribe($$self, definitionMissing, (value) => $$invalidate(51, $definitionMissing = value));
  const minHeight = derived(rowHeight, ($height) => {
    const heightForControls = $$slots.controls ? ControlsHeight : 0;
    return VPadding + SmallRowHeight + $height + heightForControls;
  });
  component_subscribe($$self, minHeight, (value) => $$invalidate(7, $minHeight = value));
  context = { ...context, minHeight };
  setContext("grid", context);
  const getContext2 = () => context;
  onMount(() => {
    if (collaboration) {
      return createGridWebsocket(context);
    }
  });
  const mouseenter_handler = () => gridFocused.set(true);
  const mouseleave_handler = () => gridFocused.set(false);
  $$self.$$set = ($$new_props) => {
    $$invalidate(59, $$props = assign(assign({}, $$props), exclude_internal_props($$new_props)));
    if ("API" in $$new_props)
      $$invalidate(26, API = $$new_props.API);
    if ("datasource" in $$new_props)
      $$invalidate(27, datasource = $$new_props.datasource);
    if ("schemaOverrides" in $$new_props)
      $$invalidate(28, schemaOverrides = $$new_props.schemaOverrides);
    if ("canAddRows" in $$new_props)
      $$invalidate(29, canAddRows = $$new_props.canAddRows);
    if ("canExpandRows" in $$new_props)
      $$invalidate(30, canExpandRows = $$new_props.canExpandRows);
    if ("canEditRows" in $$new_props)
      $$invalidate(31, canEditRows = $$new_props.canEditRows);
    if ("canDeleteRows" in $$new_props)
      $$invalidate(32, canDeleteRows = $$new_props.canDeleteRows);
    if ("canEditColumns" in $$new_props)
      $$invalidate(33, canEditColumns = $$new_props.canEditColumns);
    if ("canSaveSchema" in $$new_props)
      $$invalidate(34, canSaveSchema = $$new_props.canSaveSchema);
    if ("stripeRows" in $$new_props)
      $$invalidate(0, stripeRows = $$new_props.stripeRows);
    if ("quiet" in $$new_props)
      $$invalidate(1, quiet = $$new_props.quiet);
    if ("collaboration" in $$new_props)
      $$invalidate(35, collaboration = $$new_props.collaboration);
    if ("showAvatars" in $$new_props)
      $$invalidate(2, showAvatars = $$new_props.showAvatars);
    if ("initialFilter" in $$new_props)
      $$invalidate(36, initialFilter = $$new_props.initialFilter);
    if ("initialSortColumn" in $$new_props)
      $$invalidate(37, initialSortColumn = $$new_props.initialSortColumn);
    if ("initialSortOrder" in $$new_props)
      $$invalidate(38, initialSortOrder = $$new_props.initialSortOrder);
    if ("fixedRowHeight" in $$new_props)
      $$invalidate(39, fixedRowHeight = $$new_props.fixedRowHeight);
    if ("notifySuccess" in $$new_props)
      $$invalidate(40, notifySuccess = $$new_props.notifySuccess);
    if ("notifyError" in $$new_props)
      $$invalidate(41, notifyError = $$new_props.notifyError);
    if ("buttons" in $$new_props)
      $$invalidate(42, buttons = $$new_props.buttons);
    if ("buttonsCollapsed" in $$new_props)
      $$invalidate(43, buttonsCollapsed = $$new_props.buttonsCollapsed);
    if ("buttonsCollapsedText" in $$new_props)
      $$invalidate(44, buttonsCollapsedText = $$new_props.buttonsCollapsedText);
    if ("darkMode" in $$new_props)
      $$invalidate(45, darkMode = $$new_props.darkMode);
    if ("isCloud" in $$new_props)
      $$invalidate(46, isCloud = $$new_props.isCloud);
    if ("aiEnabled" in $$new_props)
      $$invalidate(47, aiEnabled = $$new_props.aiEnabled);
    if ("canHideColumns" in $$new_props)
      $$invalidate(48, canHideColumns = $$new_props.canHideColumns);
    if ("externalClipboard" in $$new_props)
      $$invalidate(49, externalClipboard = $$new_props.externalClipboard);
    if ("$$scope" in $$new_props)
      $$invalidate(55, $$scope = $$new_props.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*datasource, schemaOverrides, canAddRows, canExpandRows, stripeRows, quiet, showAvatars*/
    2013265927 | $$self.$$.dirty[1] & /*canEditRows, canDeleteRows, canEditColumns, canSaveSchema, collaboration, initialFilter, initialSortColumn, initialSortOrder, fixedRowHeight, notifySuccess, notifyError, buttons, buttonsCollapsed, buttonsCollapsedText, darkMode, isCloud, aiEnabled, canHideColumns, externalClipboard*/
    524287) {
      props.set({
        datasource,
        schemaOverrides,
        canAddRows,
        canExpandRows,
        canEditRows,
        canDeleteRows,
        canEditColumns,
        canSaveSchema,
        stripeRows,
        quiet,
        collaboration,
        showAvatars,
        initialFilter,
        initialSortColumn,
        initialSortOrder,
        fixedRowHeight,
        notifySuccess,
        notifyError,
        buttons,
        buttonsCollapsed,
        buttonsCollapsedText,
        darkMode,
        isCloud,
        aiEnabled,
        canHideColumns,
        externalClipboard
      });
    }
    if ($$self.$$.dirty[0] & /*datasource*/
    134217728 | $$self.$$.dirty[1] & /*$definitionMissing*/
    1048576) {
      if ($definitionMissing) {
        dispatch("definitionMissing", { datasource });
      }
    }
  };
  $$props = exclude_internal_props($$props);
  return [
    stripeRows,
    quiet,
    showAvatars,
    $isResizing,
    $isReordering,
    $rowHeight,
    $contentLines,
    $minHeight,
    $error,
    $loaded,
    $config,
    $loading,
    gridID,
    config,
    isResizing,
    isReordering,
    ui,
    loaded,
    loading,
    rowHeight,
    contentLines,
    gridFocused,
    error,
    definitionMissing,
    minHeight,
    $$slots,
    API,
    datasource,
    schemaOverrides,
    canAddRows,
    canExpandRows,
    canEditRows,
    canDeleteRows,
    canEditColumns,
    canSaveSchema,
    collaboration,
    initialFilter,
    initialSortColumn,
    initialSortOrder,
    fixedRowHeight,
    notifySuccess,
    notifyError,
    buttons,
    buttonsCollapsed,
    buttonsCollapsedText,
    darkMode,
    isCloud,
    aiEnabled,
    canHideColumns,
    externalClipboard,
    getContext2,
    $definitionMissing,
    slots,
    mouseenter_handler,
    mouseleave_handler,
    $$scope
  ];
}
class Grid extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance$1,
      create_fragment$1,
      safe_not_equal,
      {
        API: 26,
        datasource: 27,
        schemaOverrides: 28,
        canAddRows: 29,
        canExpandRows: 30,
        canEditRows: 31,
        canDeleteRows: 32,
        canEditColumns: 33,
        canSaveSchema: 34,
        stripeRows: 0,
        quiet: 1,
        collaboration: 35,
        showAvatars: 2,
        initialFilter: 36,
        initialSortColumn: 37,
        initialSortOrder: 38,
        fixedRowHeight: 39,
        notifySuccess: 40,
        notifyError: 41,
        buttons: 42,
        buttonsCollapsed: 43,
        buttonsCollapsedText: 44,
        darkMode: 45,
        isCloud: 46,
        aiEnabled: 47,
        canHideColumns: 48,
        externalClipboard: 49,
        getContext: 50
      },
      null,
      [-1, -1]
    );
  }
  get getContext() {
    return this.$$.ctx[50];
  }
}
const GridBlock_svelte_svelte_type_style_lang = "";
function create_fragment(ctx) {
  let div;
  let grid_1;
  let styleable_action;
  let t;
  let provider;
  let current;
  let mounted;
  let dispose;
  let grid_1_props = {
    datasource: (
      /*table*/
      ctx[0]
    ),
    API: (
      /*API*/
      ctx[29]
    ),
    stripeRows: (
      /*stripeRows*/
      ctx[4]
    ),
    quiet: (
      /*quiet*/
      ctx[5]
    ),
    darkMode: (
      /*darkMode*/
      ctx[21]
    ),
    initialFilter: (
      /*extendedFilter*/
      ctx[13]
    ),
    initialSortColumn: (
      /*initialSortColumn*/
      ctx[6]
    ),
    initialSortOrder: (
      /*initialSortOrder*/
      ctx[7]
    ),
    fixedRowHeight: (
      /*fixedRowHeight*/
      ctx[8]
    ),
    schemaOverrides: (
      /*schemaOverrides*/
      ctx[19]
    ),
    canAddRows: (
      /*allowAddRows*/
      ctx[1]
    ),
    canEditRows: (
      /*allowEditRows*/
      ctx[2]
    ),
    canDeleteRows: (
      /*allowDeleteRows*/
      ctx[3]
    ),
    canEditColumns: false,
    canExpandRows: false,
    canSaveSchema: false,
    notifySuccess: (
      /*notificationStore*/
      ctx[31].actions.success
    ),
    notifyError: (
      /*notificationStore*/
      ctx[31].actions.error
    ),
    buttons: (
      /*enrichedButtons*/
      ctx[20]
    ),
    buttonsCollapsed: (
      /*buttonsCollapsed*/
      ctx[10]
    ),
    buttonsCollapsedText: (
      /*buttonsCollapsedText*/
      ctx[11]
    ),
    isCloud: (
      /*$environmentStore*/
      ctx[23].cloud
    ),
    aiEnabled: (
      /*$featuresStore*/
      ctx[24].aiEnabled
    )
  };
  grid_1 = new Grid({ props: grid_1_props });
  ctx[46](grid_1);
  grid_1.$on(
    "rowclick",
    /*rowclick_handler*/
    ctx[47]
  );
  provider = new /*Provider*/
  ctx[32]({
    props: {
      data: (
        /*data*/
        ctx[15]
      ),
      actions: (
        /*actions*/
        ctx[14]
      )
    }
  });
  return {
    c() {
      div = element("div");
      create_component(grid_1.$$.fragment);
      t = space();
      create_component(provider.$$.fragment);
      attr(div, "class", "svelte-1yk90l6");
      toggle_class(
        div,
        "in-builder",
        /*$builderStore*/
        ctx[22].inBuilder
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(grid_1, div, null);
      insert(target, t, anchor);
      mount_component(provider, target, anchor);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[28].call(
          null,
          div,
          /*styles*/
          ctx[17]
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      const grid_1_changes = {};
      if (dirty[0] & /*table*/
      1)
        grid_1_changes.datasource = /*table*/
        ctx2[0];
      if (dirty[0] & /*stripeRows*/
      16)
        grid_1_changes.stripeRows = /*stripeRows*/
        ctx2[4];
      if (dirty[0] & /*quiet*/
      32)
        grid_1_changes.quiet = /*quiet*/
        ctx2[5];
      if (dirty[0] & /*darkMode*/
      2097152)
        grid_1_changes.darkMode = /*darkMode*/
        ctx2[21];
      if (dirty[0] & /*extendedFilter*/
      8192)
        grid_1_changes.initialFilter = /*extendedFilter*/
        ctx2[13];
      if (dirty[0] & /*initialSortColumn*/
      64)
        grid_1_changes.initialSortColumn = /*initialSortColumn*/
        ctx2[6];
      if (dirty[0] & /*initialSortOrder*/
      128)
        grid_1_changes.initialSortOrder = /*initialSortOrder*/
        ctx2[7];
      if (dirty[0] & /*fixedRowHeight*/
      256)
        grid_1_changes.fixedRowHeight = /*fixedRowHeight*/
        ctx2[8];
      if (dirty[0] & /*schemaOverrides*/
      524288)
        grid_1_changes.schemaOverrides = /*schemaOverrides*/
        ctx2[19];
      if (dirty[0] & /*allowAddRows*/
      2)
        grid_1_changes.canAddRows = /*allowAddRows*/
        ctx2[1];
      if (dirty[0] & /*allowEditRows*/
      4)
        grid_1_changes.canEditRows = /*allowEditRows*/
        ctx2[2];
      if (dirty[0] & /*allowDeleteRows*/
      8)
        grid_1_changes.canDeleteRows = /*allowDeleteRows*/
        ctx2[3];
      if (dirty[0] & /*enrichedButtons*/
      1048576)
        grid_1_changes.buttons = /*enrichedButtons*/
        ctx2[20];
      if (dirty[0] & /*buttonsCollapsed*/
      1024)
        grid_1_changes.buttonsCollapsed = /*buttonsCollapsed*/
        ctx2[10];
      if (dirty[0] & /*buttonsCollapsedText*/
      2048)
        grid_1_changes.buttonsCollapsedText = /*buttonsCollapsedText*/
        ctx2[11];
      if (dirty[0] & /*$environmentStore*/
      8388608)
        grid_1_changes.isCloud = /*$environmentStore*/
        ctx2[23].cloud;
      if (dirty[0] & /*$featuresStore*/
      16777216)
        grid_1_changes.aiEnabled = /*$featuresStore*/
        ctx2[24].aiEnabled;
      grid_1.$set(grid_1_changes);
      if (styleable_action && is_function(styleable_action.update) && dirty[0] & /*styles*/
      131072)
        styleable_action.update.call(
          null,
          /*styles*/
          ctx2[17]
        );
      if (!current || dirty[0] & /*$builderStore*/
      4194304) {
        toggle_class(
          div,
          "in-builder",
          /*$builderStore*/
          ctx2[22].inBuilder
        );
      }
      const provider_changes = {};
      if (dirty[0] & /*data*/
      32768)
        provider_changes.data = /*data*/
        ctx2[15];
      if (dirty[0] & /*actions*/
      16384)
        provider_changes.actions = /*actions*/
        ctx2[14];
      provider.$set(provider_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(grid_1.$$.fragment, local);
      transition_in(provider.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(grid_1.$$.fragment, local);
      transition_out(provider.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
        detach(t);
      }
      ctx[46](null);
      destroy_component(grid_1);
      destroy_component(provider, detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let id;
  let currentTheme;
  let darkMode;
  let parsedColumns;
  let enrichedButtons;
  let schemaOverrides;
  let selectedRows;
  let styles;
  let rowMap;
  let data;
  let actions;
  let extendedFilter;
  let $rowMap, $$unsubscribe_rowMap = noop, $$subscribe_rowMap = () => ($$unsubscribe_rowMap(), $$unsubscribe_rowMap = subscribe(rowMap, ($$value) => $$invalidate(42, $rowMap = $$value)), rowMap);
  let $component;
  let $selectedRows, $$unsubscribe_selectedRows = noop, $$subscribe_selectedRows = () => ($$unsubscribe_selectedRows(), $$unsubscribe_selectedRows = subscribe(selectedRows, ($$value) => $$invalidate(44, $selectedRows = $$value)), selectedRows);
  let $context;
  let $builderStore;
  let $environmentStore;
  let $featuresStore;
  component_subscribe($$self, featuresStore, ($$value) => $$invalidate(24, $featuresStore = $$value));
  $$self.$$.on_destroy.push(() => $$unsubscribe_rowMap());
  $$self.$$.on_destroy.push(() => $$unsubscribe_selectedRows());
  let { table } = $$props;
  let { allowAddRows = true } = $$props;
  let { allowEditRows = true } = $$props;
  let { allowDeleteRows = true } = $$props;
  let { stripeRows = false } = $$props;
  let { quiet = false } = $$props;
  let { initialFilter = null } = $$props;
  let { initialSortColumn = null } = $$props;
  let { initialSortOrder = null } = $$props;
  let { fixedRowHeight = null } = $$props;
  let { columns = null } = $$props;
  let { onRowClick = null } = $$props;
  let { buttons = null } = $$props;
  let { buttonsCollapsed = false } = $$props;
  let { buttonsCollapsedText = null } = $$props;
  const context = getContext("context");
  component_subscribe($$self, context, (value) => $$invalidate(45, $context = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(43, $component = value));
  const { environmentStore } = getContext("sdk");
  component_subscribe($$self, environmentStore, (value) => $$invalidate(23, $environmentStore = value));
  const { styleable, API, builderStore, notificationStore, enrichButtonActions, ActionTypes, createContextStore, Provider, generateGoldenSample } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(22, $builderStore = value));
  let grid;
  let gridContext;
  let minHeight = 0;
  let filterExtensions = {};
  const addFilterExtension = (componentId, extension) => {
    if (!componentId || !extension) {
      return;
    }
    $$invalidate(39, filterExtensions = {
      ...filterExtensions,
      [componentId]: extension
    });
  };
  const removeFilterExtension = (componentId) => {
    if (!componentId) {
      return;
    }
    const { [componentId]: removed, ...rest } = filterExtensions;
    $$invalidate(39, filterExtensions = { ...rest });
  };
  const extendFilter = (initialFilter2, extensions) => {
    if (!Object.keys(extensions || {}).length) {
      return initialFilter2;
    }
    return {
      groups: (initialFilter2 ? [initialFilter2] : []).concat(Object.values(extensions)),
      logicalOperator: UILogicalOperator.ALL,
      onEmptyFilter: EmptyFilterOption.RETURN_NONE
    };
  };
  const getAdditionalDataContext = () => {
    const gridContext2 = grid == null ? void 0 : grid.getContext();
    const rows = get_store_value(gridContext2 == null ? void 0 : gridContext2.rows) || [];
    const clean = (gridContext2 == null ? void 0 : gridContext2.rows.actions.cleanRow) || ((x) => x);
    const cleaned = rows.map(clean);
    const goldenRow = generateGoldenSample(cleaned);
    return {
      // Not sure what this one is for...
      [id]: goldenRow,
      // For row conditions context
      row: goldenRow,
      // For button action context
      eventContext: { row: goldenRow }
    };
  };
  const getParsedColumns = (columns2) => {
    if (!(columns2 == null ? void 0 : columns2.length)) {
      return [];
    }
    if (columns2[0].active !== void 0) {
      return columns2;
    }
    return columns2.map((column) => ({
      label: column.displayName || column.name,
      field: column.name,
      active: true
    }));
  };
  const getSchemaOverrides = (columns2, context2) => {
    let overrides = {};
    columns2.forEach((column, idx) => {
      var _a;
      overrides[column.field] = {
        displayName: column.label,
        order: idx,
        visible: !!column.active,
        conditions: enrichConditions(column.conditions, context2),
        format: createFormatter(column),
        // Small hack to ensure we react to all changes, as our
        // memoization cannot compare differences in functions
        rand: ((_a = column.conditions) == null ? void 0 : _a.length) ? Math.random() : null
      };
      if (column.width) {
        overrides[column.field].width = column.width;
      }
    });
    return overrides;
  };
  const enrichConditions = (conditions, context2) => {
    return conditions == null ? void 0 : conditions.map((condition) => {
      return {
        ...condition,
        referenceValue: processStringSync(condition.referenceValue || "", context2),
        newValue: processStringSync(condition.newValue || "", context2)
      };
    });
  };
  const createFormatter = (column) => {
    if (typeof column.format !== "string" || !column.format.trim().length) {
      return null;
    }
    return (row) => processStringSync(column.format, { [id]: row });
  };
  const enrichButtons = (buttons2) => {
    if (!(buttons2 == null ? void 0 : buttons2.length)) {
      return null;
    }
    return buttons2.map((settings) => {
      const id2 = get_store_value(component).id;
      return {
        size: "M",
        text: settings.text,
        type: settings.type,
        icon: settings.icon,
        getRowConditions: (row) => enrichConditions(settings.conditions, { [id2]: row }),
        conditions: settings.conditions,
        onClick: async (row) => {
          const gridContext2 = createContextStore(context);
          gridContext2.actions.provideData(id2, row);
          const fn = enrichButtonActions(settings.onClick, get_store_value(gridContext2));
          return await (fn == null ? void 0 : fn({ row }));
        }
      };
    });
  };
  const deriveSelectedRows = (gridContext2) => {
    if (!gridContext2) {
      return readable([]);
    }
    return derived([gridContext2.selectedRows, gridContext2.rowLookupMap], ([$selectedRows2, $rowLookupMap]) => {
      return Object.entries($selectedRows2 || {}).filter(([_, selected]) => selected).map(([rowId]) => {
        return gridContext2.rows.actions.cleanRow($rowLookupMap[rowId]);
      });
    });
  };
  const patchStyles = (styles2, minHeight2) => {
    return {
      ...styles2,
      normal: {
        ...styles2 == null ? void 0 : styles2.normal,
        "min-height": `${minHeight2}px`
      }
    };
  };
  onMount(() => {
    $$invalidate(37, gridContext = grid.getContext());
    gridContext.minHeight.subscribe(($height) => $$invalidate(38, minHeight = $height));
  });
  function grid_1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      grid = $$value;
      $$invalidate(12, grid);
    });
  }
  const rowclick_handler = (e) => onRowClick == null ? void 0 : onRowClick({ row: e.detail });
  $$self.$$set = ($$props2) => {
    if ("table" in $$props2)
      $$invalidate(0, table = $$props2.table);
    if ("allowAddRows" in $$props2)
      $$invalidate(1, allowAddRows = $$props2.allowAddRows);
    if ("allowEditRows" in $$props2)
      $$invalidate(2, allowEditRows = $$props2.allowEditRows);
    if ("allowDeleteRows" in $$props2)
      $$invalidate(3, allowDeleteRows = $$props2.allowDeleteRows);
    if ("stripeRows" in $$props2)
      $$invalidate(4, stripeRows = $$props2.stripeRows);
    if ("quiet" in $$props2)
      $$invalidate(5, quiet = $$props2.quiet);
    if ("initialFilter" in $$props2)
      $$invalidate(33, initialFilter = $$props2.initialFilter);
    if ("initialSortColumn" in $$props2)
      $$invalidate(6, initialSortColumn = $$props2.initialSortColumn);
    if ("initialSortOrder" in $$props2)
      $$invalidate(7, initialSortOrder = $$props2.initialSortOrder);
    if ("fixedRowHeight" in $$props2)
      $$invalidate(8, fixedRowHeight = $$props2.fixedRowHeight);
    if ("columns" in $$props2)
      $$invalidate(34, columns = $$props2.columns);
    if ("onRowClick" in $$props2)
      $$invalidate(9, onRowClick = $$props2.onRowClick);
    if ("buttons" in $$props2)
      $$invalidate(35, buttons = $$props2.buttons);
    if ("buttonsCollapsed" in $$props2)
      $$invalidate(10, buttonsCollapsed = $$props2.buttonsCollapsed);
    if ("buttonsCollapsedText" in $$props2)
      $$invalidate(11, buttonsCollapsedText = $$props2.buttonsCollapsedText);
  };
  $$self.$$.update = () => {
    var _a;
    if ($$self.$$.dirty[1] & /*$component*/
    4096) {
      id = $component.id;
    }
    if ($$self.$$.dirty[1] & /*$context*/
    16384) {
      $$invalidate(41, currentTheme = (_a = $context == null ? void 0 : $context.device) == null ? void 0 : _a.theme);
    }
    if ($$self.$$.dirty[1] & /*currentTheme*/
    1024) {
      $$invalidate(21, darkMode = !(currentTheme == null ? void 0 : currentTheme.includes("light")));
    }
    if ($$self.$$.dirty[1] & /*columns*/
    8) {
      $$invalidate(40, parsedColumns = getParsedColumns(columns));
    }
    if ($$self.$$.dirty[1] & /*buttons*/
    16) {
      $$invalidate(20, enrichedButtons = enrichButtons(buttons));
    }
    if ($$self.$$.dirty[1] & /*parsedColumns, $context*/
    16896) {
      $$invalidate(19, schemaOverrides = getSchemaOverrides(parsedColumns, $context));
    }
    if ($$self.$$.dirty[1] & /*gridContext*/
    64) {
      $$subscribe_selectedRows($$invalidate(18, selectedRows = deriveSelectedRows(gridContext)));
    }
    if ($$self.$$.dirty[1] & /*$component, minHeight*/
    4224) {
      $$invalidate(17, styles = patchStyles($component.styles, minHeight));
    }
    if ($$self.$$.dirty[1] & /*gridContext*/
    64) {
      $$subscribe_rowMap($$invalidate(16, rowMap = gridContext == null ? void 0 : gridContext.rowLookupMap));
    }
    if ($$self.$$.dirty[0] & /*table*/
    1 | $$self.$$.dirty[1] & /*$selectedRows, $component, $rowMap*/
    14336) {
      $$invalidate(15, data = {
        selectedRows: $selectedRows,
        embeddedData: {
          dataSource: table,
          componentId: $component.id,
          loaded: !!$rowMap
        }
      });
    }
    if ($$self.$$.dirty[0] & /*table*/
    1 | $$self.$$.dirty[1] & /*gridContext*/
    64) {
      $$invalidate(14, actions = [
        {
          type: ActionTypes.RefreshDatasource,
          callback: () => gridContext == null ? void 0 : gridContext.rows.actions.refreshData(),
          metadata: { dataSource: table }
        },
        {
          type: ActionTypes.AddDataProviderFilterExtension,
          callback: addFilterExtension
        },
        {
          type: ActionTypes.ClearRowSelection,
          callback: () => {
            var _a2, _b;
            return (_b = (_a2 = gridContext == null ? void 0 : gridContext.selectedRows) == null ? void 0 : _a2.set) == null ? void 0 : _b.call(_a2, {});
          }
        },
        {
          type: ActionTypes.RemoveDataProviderFilterExtension,
          callback: removeFilterExtension
        }
      ]);
    }
    if ($$self.$$.dirty[1] & /*initialFilter, filterExtensions*/
    260) {
      $$invalidate(13, extendedFilter = extendFilter(initialFilter, filterExtensions));
    }
  };
  return [
    table,
    allowAddRows,
    allowEditRows,
    allowDeleteRows,
    stripeRows,
    quiet,
    initialSortColumn,
    initialSortOrder,
    fixedRowHeight,
    onRowClick,
    buttonsCollapsed,
    buttonsCollapsedText,
    grid,
    extendedFilter,
    actions,
    data,
    rowMap,
    styles,
    selectedRows,
    schemaOverrides,
    enrichedButtons,
    darkMode,
    $builderStore,
    $environmentStore,
    $featuresStore,
    context,
    component,
    environmentStore,
    styleable,
    API,
    builderStore,
    notificationStore,
    Provider,
    initialFilter,
    columns,
    buttons,
    getAdditionalDataContext,
    gridContext,
    minHeight,
    filterExtensions,
    parsedColumns,
    currentTheme,
    $rowMap,
    $component,
    $selectedRows,
    $context,
    grid_1_binding,
    rowclick_handler
  ];
}
class GridBlock extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        table: 0,
        allowAddRows: 1,
        allowEditRows: 2,
        allowDeleteRows: 3,
        stripeRows: 4,
        quiet: 5,
        initialFilter: 33,
        initialSortColumn: 6,
        initialSortOrder: 7,
        fixedRowHeight: 8,
        columns: 34,
        onRowClick: 9,
        buttons: 35,
        buttonsCollapsed: 10,
        buttonsCollapsedText: 11,
        getAdditionalDataContext: 36
      },
      null,
      [-1, -1, -1]
    );
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[36];
  }
}
export {
  GridBlock as default
};
