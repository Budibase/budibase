import { S as SvelteComponent, i as init, s as safe_not_equal, F as create_slot, e as element, a as space, b as attr, d as toggle_class, f as insert, g as append, l as listen, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, k as transition_in, n as transition_out, o as detach, r as run_all, Y as createEventDispatcher, V as bubble, W as binding_callbacks } from "./index-a0738cd3.js";
function create_fragment(ctx) {
  let div;
  let textarea_1;
  let textarea_1_placeholder_value;
  let textarea_1_style_value;
  let textarea_1_value_value;
  let t;
  let div_style_value;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[20].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[19],
    null
  );
  return {
    c() {
      div = element("div");
      textarea_1 = element("textarea");
      t = space();
      if (default_slot)
        default_slot.c();
      attr(textarea_1, "placeholder", textarea_1_placeholder_value = /*placeholder*/
      ctx[1] || "");
      attr(textarea_1, "class", "spectrum-Textfield-input svelte-1kmb9uq");
      attr(textarea_1, "style", textarea_1_style_value = /*align*/
      ctx[5] ? `text-align: ${/*align*/
      ctx[5]}` : "");
      textarea_1.disabled = /*disabled*/
      ctx[2];
      textarea_1.readOnly = /*readonly*/
      ctx[3];
      attr(
        textarea_1,
        "id",
        /*id*/
        ctx[4]
      );
      textarea_1.value = textarea_1_value_value = /*value*/
      ctx[0] || "";
      attr(div, "style", div_style_value = `${/*heightString*/
      ctx[9]}${/*minHeightString*/
      ctx[8]}`);
      attr(div, "class", "spectrum-Textfield spectrum-Textfield--multiline svelte-1kmb9uq");
      toggle_class(
        div,
        "is-disabled",
        /*disabled*/
        ctx[2]
      );
      toggle_class(
        div,
        "is-focused",
        /*isFocused*/
        ctx[6]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, textarea_1);
      ctx[23](textarea_1);
      append(div, t);
      if (default_slot) {
        default_slot.m(div, null);
      }
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            textarea_1,
            "input",
            /*onChange*/
            ctx[11]
          ),
          listen(
            textarea_1,
            "focus",
            /*focus_handler*/
            ctx[24]
          ),
          listen(
            textarea_1,
            "blur",
            /*onBlur*/
            ctx[10]
          ),
          listen(
            textarea_1,
            "blur",
            /*blur_handler*/
            ctx[21]
          ),
          listen(
            textarea_1,
            "keypress",
            /*keypress_handler*/
            ctx[22]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (!current || dirty & /*placeholder*/
      2 && textarea_1_placeholder_value !== (textarea_1_placeholder_value = /*placeholder*/
      ctx2[1] || "")) {
        attr(textarea_1, "placeholder", textarea_1_placeholder_value);
      }
      if (!current || dirty & /*align*/
      32 && textarea_1_style_value !== (textarea_1_style_value = /*align*/
      ctx2[5] ? `text-align: ${/*align*/
      ctx2[5]}` : "")) {
        attr(textarea_1, "style", textarea_1_style_value);
      }
      if (!current || dirty & /*disabled*/
      4) {
        textarea_1.disabled = /*disabled*/
        ctx2[2];
      }
      if (!current || dirty & /*readonly*/
      8) {
        textarea_1.readOnly = /*readonly*/
        ctx2[3];
      }
      if (!current || dirty & /*id*/
      16) {
        attr(
          textarea_1,
          "id",
          /*id*/
          ctx2[4]
        );
      }
      if (!current || dirty & /*value*/
      1 && textarea_1_value_value !== (textarea_1_value_value = /*value*/
      ctx2[0] || "")) {
        textarea_1.value = textarea_1_value_value;
      }
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        524288)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[19],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[19]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[19],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*heightString, minHeightString*/
      768 && div_style_value !== (div_style_value = `${/*heightString*/
      ctx2[9]}${/*minHeightString*/
      ctx2[8]}`)) {
        attr(div, "style", div_style_value);
      }
      if (!current || dirty & /*disabled*/
      4) {
        toggle_class(
          div,
          "is-disabled",
          /*disabled*/
          ctx2[2]
        );
      }
      if (!current || dirty & /*isFocused*/
      64) {
        toggle_class(
          div,
          "is-focused",
          /*isFocused*/
          ctx2[6]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      ctx[23](null);
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let heightString;
  let minHeightString;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { value = "" } = $$props;
  let { placeholder = void 0 } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { id = void 0 } = $$props;
  let { height = void 0 } = $$props;
  let { minHeight = void 0 } = $$props;
  let { align = null } = $$props;
  let { updateOnChange = false } = $$props;
  const getCaretPosition = () => ({
    start: textarea.selectionStart,
    end: textarea.selectionEnd
  });
  const dispatch = createEventDispatcher();
  let isFocused = false;
  let textarea;
  let scrollable = false;
  function focus() {
    textarea.focus();
  }
  function contents() {
    return textarea.value;
  }
  const onBlur = () => {
    $$invalidate(6, isFocused = false);
    updateValue();
  };
  const onChange = () => {
    $$invalidate(18, scrollable = textarea.clientHeight < textarea.scrollHeight);
    if (!updateOnChange) {
      return;
    }
    updateValue();
  };
  const updateValue = () => {
    if (readonly || disabled) {
      return;
    }
    dispatch("change", textarea.value);
  };
  const getStyleString = (attribute, value2) => {
    if (value2 == null) {
      return "";
    }
    if (typeof value2 !== "number" || isNaN(value2)) {
      return `${attribute}:${value2};`;
    }
    return `${attribute}:${value2}px;`;
  };
  function blur_handler(event) {
    bubble.call(this, $$self, event);
  }
  function keypress_handler(event) {
    bubble.call(this, $$self, event);
  }
  function textarea_1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      textarea = $$value;
      $$invalidate(7, textarea);
    });
  }
  const focus_handler = () => $$invalidate(6, isFocused = true);
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("placeholder" in $$props2)
      $$invalidate(1, placeholder = $$props2.placeholder);
    if ("disabled" in $$props2)
      $$invalidate(2, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(3, readonly = $$props2.readonly);
    if ("id" in $$props2)
      $$invalidate(4, id = $$props2.id);
    if ("height" in $$props2)
      $$invalidate(12, height = $$props2.height);
    if ("minHeight" in $$props2)
      $$invalidate(13, minHeight = $$props2.minHeight);
    if ("align" in $$props2)
      $$invalidate(5, align = $$props2.align);
    if ("updateOnChange" in $$props2)
      $$invalidate(14, updateOnChange = $$props2.updateOnChange);
    if ("$$scope" in $$props2)
      $$invalidate(19, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*height*/
    4096) {
      $$invalidate(9, heightString = getStyleString("height", height));
    }
    if ($$self.$$.dirty & /*minHeight*/
    8192) {
      $$invalidate(8, minHeightString = getStyleString("min-height", minHeight));
    }
    if ($$self.$$.dirty & /*scrollable*/
    262144) {
      dispatch("scrollable", scrollable);
    }
  };
  return [
    value,
    placeholder,
    disabled,
    readonly,
    id,
    align,
    isFocused,
    textarea,
    minHeightString,
    heightString,
    onBlur,
    onChange,
    height,
    minHeight,
    updateOnChange,
    getCaretPosition,
    focus,
    contents,
    scrollable,
    $$scope,
    slots,
    blur_handler,
    keypress_handler,
    textarea_1_binding,
    focus_handler
  ];
}
class TextArea extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      value: 0,
      placeholder: 1,
      disabled: 2,
      readonly: 3,
      id: 4,
      height: 12,
      minHeight: 13,
      align: 5,
      updateOnChange: 14,
      getCaretPosition: 15,
      focus: 16,
      contents: 17
    });
  }
  get getCaretPosition() {
    return this.$$.ctx[15];
  }
  get focus() {
    return this.$$.ctx[16];
  }
  get contents() {
    return this.$$.ctx[17];
  }
}
export {
  TextArea as T
};
