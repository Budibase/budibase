import { aK as FieldType } from "./index-a0738cd3.js";
const allowDisplayColumnByType = {
  [FieldType.STRING]: true,
  [FieldType.LONGFORM]: true,
  [FieldType.OPTIONS]: true,
  [FieldType.NUMBER]: true,
  [FieldType.DATETIME]: true,
  [FieldType.FORMULA]: true,
  [FieldType.AI]: true,
  [FieldType.AUTO]: true,
  [FieldType.INTERNAL]: true,
  [FieldType.BARCODEQR]: true,
  [FieldType.BIGINT]: true,
  [FieldType.BOOLEAN]: false,
  [FieldType.ARRAY]: false,
  [FieldType.ATTACHMENTS]: false,
  [FieldType.ATTACHMENT_SINGLE]: false,
  [FieldType.SIGNATURE_SINGLE]: false,
  [FieldType.LINK]: false,
  [FieldType.JSON]: false,
  [FieldType.BB_REFERENCE]: false,
  [FieldType.BB_REFERENCE_SINGLE]: false
};
const allowSortColumnByType = {
  [FieldType.STRING]: true,
  [FieldType.LONGFORM]: true,
  [FieldType.OPTIONS]: true,
  [FieldType.NUMBER]: true,
  [FieldType.DATETIME]: true,
  [FieldType.AUTO]: true,
  [FieldType.INTERNAL]: true,
  [FieldType.BARCODEQR]: true,
  [FieldType.BIGINT]: true,
  [FieldType.BOOLEAN]: true,
  [FieldType.JSON]: false,
  [FieldType.FORMULA]: false,
  [FieldType.AI]: false,
  [FieldType.ATTACHMENTS]: false,
  [FieldType.ATTACHMENT_SINGLE]: false,
  [FieldType.SIGNATURE_SINGLE]: false,
  [FieldType.ARRAY]: false,
  [FieldType.LINK]: false,
  [FieldType.BB_REFERENCE]: false,
  [FieldType.BB_REFERENCE_SINGLE]: false
};
({
  [FieldType.NUMBER]: true,
  [FieldType.JSON]: true,
  [FieldType.DATETIME]: true,
  [FieldType.LONGFORM]: true,
  [FieldType.STRING]: true,
  [FieldType.OPTIONS]: true,
  [FieldType.ARRAY]: true,
  [FieldType.BIGINT]: true,
  [FieldType.BOOLEAN]: true,
  [FieldType.AUTO]: false,
  [FieldType.INTERNAL]: false,
  [FieldType.BARCODEQR]: false,
  [FieldType.FORMULA]: false,
  [FieldType.AI]: false,
  [FieldType.ATTACHMENTS]: false,
  [FieldType.ATTACHMENT_SINGLE]: false,
  [FieldType.SIGNATURE_SINGLE]: false,
  [FieldType.LINK]: false,
  [FieldType.BB_REFERENCE]: true,
  [FieldType.BB_REFERENCE_SINGLE]: true
});
function canBeDisplayColumn$1(type) {
  return !!allowDisplayColumnByType[type];
}
function canBeSortColumn$1(type) {
  return !!allowSortColumnByType[type];
}
function canBeDisplayColumn(column) {
  if (!canBeDisplayColumn$1(column.type)) {
    return false;
  }
  if (column.related) {
    return false;
  }
  return true;
}
function canBeSortColumn(column) {
  if (column.calculationType) {
    return true;
  }
  if (!canBeSortColumn$1(column.type)) {
    return false;
  }
  if (column.related) {
    return false;
  }
  return true;
}
export {
  canBeDisplayColumn as a,
  canBeSortColumn as c
};
