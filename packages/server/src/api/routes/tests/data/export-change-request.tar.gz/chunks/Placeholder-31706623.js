import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, B as noop, o as detach, u as getContext, v as component_subscribe, e as element, t as text, b as attr, g as append, j as set_data } from "./index-a0738cd3.js";
const Placeholder_svelte_svelte_type_style_lang = "";
function create_if_block(ctx) {
  var _a;
  let div;
  let t_value = (
    /*text*/
    (ctx[0] || /*block*/
    ((_a = ctx[5]) == null ? void 0 : _a.name) || /*$component*/
    ctx[2].name || "Placeholder") + ""
  );
  let t;
  return {
    c() {
      div = element("div");
      t = text(t_value);
      attr(div, "class", "svelte-16hk7sb");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
    },
    p(ctx2, dirty) {
      var _a2;
      if (dirty & /*text, $component*/
      5 && t_value !== (t_value = /*text*/
      (ctx2[0] || /*block*/
      ((_a2 = ctx2[5]) == null ? void 0 : _a2.name) || /*$component*/
      ctx2[2].name || "Placeholder") + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_fragment(ctx) {
  let if_block_anchor;
  let if_block = (
    /*$builderStore*/
    ctx[1].inBuilder && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
    },
    p(ctx2, [dirty]) {
      if (
        /*$builderStore*/
        ctx2[1].inBuilder
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $builderStore;
  let $component;
  const { builderStore } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(1, $builderStore = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(2, $component = value));
  const block = getContext("block");
  let { text: text2 = void 0 } = $$props;
  $$self.$$set = ($$props2) => {
    if ("text" in $$props2)
      $$invalidate(0, text2 = $$props2.text);
  };
  return [text2, $builderStore, $component, builderStore, component, block];
}
class Placeholder extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { text: 0 });
  }
}
export {
  Placeholder as default
};
