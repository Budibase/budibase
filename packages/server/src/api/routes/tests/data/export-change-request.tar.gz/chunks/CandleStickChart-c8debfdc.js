import { S as SvelteComponent, i as init, s as safe_not_equal, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component } from "./index-a0738cd3.js";
import { A as ApexChart, f as formatters } from "./ApexChart-39eab0fb.js";
function create_fragment(ctx) {
  let apexchart;
  let current;
  apexchart = new ApexChart({ props: { options: (
    /*options*/
    ctx[0]
  ) } });
  return {
    c() {
      create_component(apexchart.$$.fragment);
    },
    m(target, anchor) {
      mount_component(apexchart, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const apexchart_changes = {};
      if (dirty & /*options*/
      1)
        apexchart_changes.options = /*options*/
        ctx2[0];
      apexchart.$set(apexchart_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(apexchart.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(apexchart.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(apexchart, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let series;
  let options;
  let { title } = $$props;
  let { dataProvider } = $$props;
  let { dateColumn } = $$props;
  let { openColumn } = $$props;
  let { highColumn } = $$props;
  let { lowColumn } = $$props;
  let { closeColumn } = $$props;
  let { xAxisLabel } = $$props;
  let { yAxisLabel } = $$props;
  let { height } = $$props;
  let { width } = $$props;
  let { animate } = $$props;
  let { yAxisUnits } = $$props;
  let { onClick } = $$props;
  function handleCandlestickClick(candlestick) {
    onClick == null ? void 0 : onClick({ candlestick });
  }
  const getValueAsUnixTime = (dataprovider, dateColumn2, row) => {
    var _a, _b;
    const value = row[dateColumn2];
    if (((_b = (_a = dataProvider == null ? void 0 : dataProvider.schema) == null ? void 0 : _a[dateColumn2]) == null ? void 0 : _b.type) === "datetime") {
      return Date.parse(value);
    }
    if (typeof value === "number") {
      return value;
    }
    const isString = typeof value === "string";
    if (isString && value.includes("-")) {
      const unixTime = Date.parse(value);
      if (isNaN(unixTime)) {
        return null;
      }
      return unixTime;
    }
    if (isString) {
      const unixTime = parseInt(value, 10);
      if (isNaN(unixTime)) {
        return null;
      }
      return unixTime;
    }
    return null;
  };
  const getSeries = (dataProvider2, dateColumn2, openColumn2, highColumn2, lowColumn2, closeColumn2) => {
    const rows = dataProvider2.rows ?? [];
    return [
      {
        data: rows.map((row) => {
          const open = parseFloat(row[openColumn2]);
          const high = parseFloat(row[highColumn2]);
          const low = parseFloat(row[lowColumn2]);
          const close = parseFloat(row[closeColumn2]);
          return [
            getValueAsUnixTime(dataProvider2, dateColumn2, row),
            isNaN(open) ? 0 : open,
            isNaN(high) ? 0 : high,
            isNaN(low) ? 0 : low,
            isNaN(close) ? 0 : close
          ];
        })
      }
    ];
  };
  $$self.$$set = ($$props2) => {
    if ("title" in $$props2)
      $$invalidate(1, title = $$props2.title);
    if ("dataProvider" in $$props2)
      $$invalidate(2, dataProvider = $$props2.dataProvider);
    if ("dateColumn" in $$props2)
      $$invalidate(3, dateColumn = $$props2.dateColumn);
    if ("openColumn" in $$props2)
      $$invalidate(4, openColumn = $$props2.openColumn);
    if ("highColumn" in $$props2)
      $$invalidate(5, highColumn = $$props2.highColumn);
    if ("lowColumn" in $$props2)
      $$invalidate(6, lowColumn = $$props2.lowColumn);
    if ("closeColumn" in $$props2)
      $$invalidate(7, closeColumn = $$props2.closeColumn);
    if ("xAxisLabel" in $$props2)
      $$invalidate(8, xAxisLabel = $$props2.xAxisLabel);
    if ("yAxisLabel" in $$props2)
      $$invalidate(9, yAxisLabel = $$props2.yAxisLabel);
    if ("height" in $$props2)
      $$invalidate(10, height = $$props2.height);
    if ("width" in $$props2)
      $$invalidate(11, width = $$props2.width);
    if ("animate" in $$props2)
      $$invalidate(12, animate = $$props2.animate);
    if ("yAxisUnits" in $$props2)
      $$invalidate(13, yAxisUnits = $$props2.yAxisUnits);
    if ("onClick" in $$props2)
      $$invalidate(14, onClick = $$props2.onClick);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*dataProvider, dateColumn, openColumn, highColumn, lowColumn, closeColumn*/
    252) {
      $$invalidate(15, series = getSeries(dataProvider, dateColumn, openColumn, highColumn, lowColumn, closeColumn));
    }
    if ($$self.$$.dirty & /*series, title, height, width, animate, dataProvider, xAxisLabel, yAxisUnits, yAxisLabel*/
    48902) {
      $$invalidate(0, options = {
        series,
        title: { text: title },
        chart: {
          height: height == null || height === "" ? "auto" : height,
          width: width == null || width === "" ? "100%" : width,
          type: "candlestick",
          animations: { enabled: animate },
          toolbar: { show: false },
          zoom: { enabled: false },
          events: {
            // Clicking on a Candlestick
            dataPointSelection(event, chartContext, opts) {
              const candlelstickIndex = opts.dataPointIndex;
              const row = dataProvider.rows[candlelstickIndex];
              handleCandlestickClick(row);
            }
          }
        },
        xaxis: {
          tooltip: { formatter: formatters["Datetime"] },
          type: "datetime",
          title: { text: xAxisLabel }
        },
        yaxis: {
          labels: { formatter: formatters[yAxisUnits] },
          title: { text: yAxisLabel }
        }
      });
    }
  };
  return [
    options,
    title,
    dataProvider,
    dateColumn,
    openColumn,
    highColumn,
    lowColumn,
    closeColumn,
    xAxisLabel,
    yAxisLabel,
    height,
    width,
    animate,
    yAxisUnits,
    onClick,
    series
  ];
}
class CandleStickChart extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      title: 1,
      dataProvider: 2,
      dateColumn: 3,
      openColumn: 4,
      highColumn: 5,
      lowColumn: 6,
      closeColumn: 7,
      xAxisLabel: 8,
      yAxisLabel: 9,
      height: 10,
      width: 11,
      animate: 12,
      yAxisUnits: 13,
      onClick: 14
    });
  }
}
export {
  CandleStickChart as default
};
