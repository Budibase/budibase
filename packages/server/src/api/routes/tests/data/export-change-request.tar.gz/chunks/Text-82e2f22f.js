import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, c as create_component, b as attr, f as insert, m as mount_component, q as action_destroyer, h as is_function, k as transition_in, n as transition_out, o as detach, p as destroy_component, u as getContext, v as component_subscribe } from "./index-a0738cd3.js";
import { M as MarkdownViewer } from "./MarkdownViewer-7a4fbc38.js";
const Text_svelte_svelte_type_style_lang = "";
function create_fragment(ctx) {
  let div;
  let markdownviewer;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  markdownviewer = new MarkdownViewer({ props: { value: (
    /*safeText*/
    ctx[0]
  ) } });
  return {
    c() {
      div = element("div");
      create_component(markdownviewer.$$.fragment);
      attr(div, "class", "svelte-rl4qpz");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(markdownviewer, div, null);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[3].call(
          null,
          div,
          /*styles*/
          ctx[1]
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      const markdownviewer_changes = {};
      if (dirty & /*safeText*/
      1)
        markdownviewer_changes.value = /*safeText*/
        ctx2[0];
      markdownviewer.$set(markdownviewer_changes);
      if (styleable_action && is_function(styleable_action.update) && dirty & /*styles*/
      2)
        styleable_action.update.call(
          null,
          /*styles*/
          ctx2[1]
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(markdownviewer.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(markdownviewer.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(markdownviewer);
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let styles;
  let safeText;
  let $component;
  let { text = "" } = $$props;
  let { color = void 0 } = $$props;
  let { align = "left" } = $$props;
  let { size = "14px" } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(8, $component = value));
  const { styleable } = getContext("sdk");
  const enrichStyles = (styles2, colorStyle, alignStyle, size2) => {
    let additions = {
      "text-align": alignStyle,
      "font-size": size2 || "14px"
    };
    if (colorStyle) {
      additions.color = colorStyle;
    }
    return {
      ...styles2,
      normal: { ...styles2.normal, ...additions }
    };
  };
  const stringify = (text2) => {
    if (text2 == null) {
      return "";
    }
    if (typeof text2 !== "string") {
      try {
        return JSON.stringify(text2);
      } catch (e) {
        return "";
      }
    }
    return text2;
  };
  $$self.$$set = ($$props2) => {
    if ("text" in $$props2)
      $$invalidate(4, text = $$props2.text);
    if ("color" in $$props2)
      $$invalidate(5, color = $$props2.color);
    if ("align" in $$props2)
      $$invalidate(6, align = $$props2.align);
    if ("size" in $$props2)
      $$invalidate(7, size = $$props2.size);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$component, color, align, size*/
    480) {
      $$invalidate(1, styles = enrichStyles($component.styles, color, align, size));
    }
    if ($$self.$$.dirty & /*text*/
    16) {
      $$invalidate(0, safeText = stringify(text));
    }
  };
  return [safeText, styles, component, styleable, text, color, align, size, $component];
}
class Text extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { text: 4, color: 5, align: 6, size: 7 });
  }
}
export {
  Text as default
};
