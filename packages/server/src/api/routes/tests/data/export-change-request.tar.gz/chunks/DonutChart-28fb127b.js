import { S as SvelteComponent, i as init, s as safe_not_equal, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component } from "./index-a0738cd3.js";
import { A as ApexChart, p as parsePalette, f as formatters } from "./ApexChart-39eab0fb.js";
function create_fragment(ctx) {
  let apexchart;
  let current;
  apexchart = new ApexChart({ props: { options: (
    /*options*/
    ctx[0]
  ) } });
  return {
    c() {
      create_component(apexchart.$$.fragment);
    },
    m(target, anchor) {
      mount_component(apexchart, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const apexchart_changes = {};
      if (dirty & /*options*/
      1)
        apexchart_changes.options = /*options*/
        ctx2[0];
      apexchart.$set(apexchart_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(apexchart.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(apexchart.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(apexchart, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let labelType;
  let series;
  let labels;
  let options;
  let { title } = $$props;
  let { dataProvider } = $$props;
  let { labelColumn } = $$props;
  let { valueColumn } = $$props;
  let { height } = $$props;
  let { width } = $$props;
  let { animate } = $$props;
  let { dataLabels } = $$props;
  let { legend } = $$props;
  let { palette } = $$props;
  let { c1, c2, c3, c4, c5 } = $$props;
  let { onClick } = $$props;
  function handleSegmentClick(segment, index, percentage) {
    onClick == null ? void 0 : onClick({ segment, index, percentage });
  }
  const getSeries = (dataProvider2, valueColumn2) => {
    const rows = dataProvider2.rows ?? [];
    return rows.map((row) => {
      var _a, _b;
      const value = row == null ? void 0 : row[valueColumn2];
      if (((_b = (_a = dataProvider2 == null ? void 0 : dataProvider2.schema) == null ? void 0 : _a[valueColumn2]) == null ? void 0 : _b.type) === "datetime" && value) {
        return Date.parse(value);
      }
      const numValue = parseFloat(value);
      if (isNaN(numValue)) {
        return 0;
      }
      return numValue;
    });
  };
  const getLabels = (dataProvider2, labelColumn2, labelType2) => {
    const rows = dataProvider2.rows ?? [];
    return rows.map((row) => {
      const value = row == null ? void 0 : row[labelColumn2];
      if (!["string", "number", "boolean"].includes(typeof value)) {
        return "";
      } else if (labelType2 === "datetime") {
        return formatters["Datetime"](value);
      }
      return value;
    });
  };
  $$self.$$set = ($$props2) => {
    if ("title" in $$props2)
      $$invalidate(1, title = $$props2.title);
    if ("dataProvider" in $$props2)
      $$invalidate(2, dataProvider = $$props2.dataProvider);
    if ("labelColumn" in $$props2)
      $$invalidate(3, labelColumn = $$props2.labelColumn);
    if ("valueColumn" in $$props2)
      $$invalidate(4, valueColumn = $$props2.valueColumn);
    if ("height" in $$props2)
      $$invalidate(5, height = $$props2.height);
    if ("width" in $$props2)
      $$invalidate(6, width = $$props2.width);
    if ("animate" in $$props2)
      $$invalidate(7, animate = $$props2.animate);
    if ("dataLabels" in $$props2)
      $$invalidate(8, dataLabels = $$props2.dataLabels);
    if ("legend" in $$props2)
      $$invalidate(9, legend = $$props2.legend);
    if ("palette" in $$props2)
      $$invalidate(10, palette = $$props2.palette);
    if ("c1" in $$props2)
      $$invalidate(11, c1 = $$props2.c1);
    if ("c2" in $$props2)
      $$invalidate(12, c2 = $$props2.c2);
    if ("c3" in $$props2)
      $$invalidate(13, c3 = $$props2.c3);
    if ("c4" in $$props2)
      $$invalidate(14, c4 = $$props2.c4);
    if ("c5" in $$props2)
      $$invalidate(15, c5 = $$props2.c5);
    if ("onClick" in $$props2)
      $$invalidate(16, onClick = $$props2.onClick);
  };
  $$self.$$.update = () => {
    var _a, _b;
    if ($$self.$$.dirty & /*dataProvider, labelColumn*/
    12) {
      $$invalidate(19, labelType = ((_b = (_a = dataProvider == null ? void 0 : dataProvider.schema) == null ? void 0 : _a[labelColumn]) == null ? void 0 : _b.type) === "datetime" ? "datetime" : "category");
    }
    if ($$self.$$.dirty & /*dataProvider, valueColumn*/
    20) {
      $$invalidate(18, series = getSeries(dataProvider, valueColumn));
    }
    if ($$self.$$.dirty & /*dataProvider, labelColumn, labelType*/
    524300) {
      $$invalidate(17, labels = getLabels(dataProvider, labelColumn, labelType));
    }
    if ($$self.$$.dirty & /*series, labels, palette, c1, c2, c3, c4, c5, legend, title, dataLabels, height, width, animate, dataProvider, valueColumn*/
    458742) {
      $$invalidate(0, options = {
        series,
        labels,
        colors: palette === "Custom" ? [c1, c2, c3, c4, c5] : [],
        theme: { palette: parsePalette(palette) },
        legend: {
          show: legend,
          position: "right",
          horizontalAlign: "right",
          showForSingleSeries: true,
          showForNullSeries: true,
          showForZeroSeries: true
        },
        title: { text: title },
        dataLabels: { enabled: dataLabels },
        chart: {
          height: height == null || height === "" ? "auto" : height,
          width: width == null || width === "" ? "100%" : width,
          type: "donut",
          animations: { enabled: animate },
          toolbar: { show: false },
          zoom: { enabled: false },
          events: {
            // Clicking on a slice of the donut
            dataPointSelection(event, chartContext, opts) {
              const segmentIndex = opts.dataPointIndex;
              const row = dataProvider.rows[segmentIndex];
              const rowValues = dataProvider.rows.map((row2) => {
                return row2[valueColumn];
              });
              const initialValue = 0;
              const total = rowValues.reduce((accumulator, currentValue) => accumulator + currentValue, initialValue);
              const percentage = (row[valueColumn] / total * 100).toFixed(1);
              handleSegmentClick(row, segmentIndex + 1, percentage);
            }
          }
        }
      });
    }
  };
  return [
    options,
    title,
    dataProvider,
    labelColumn,
    valueColumn,
    height,
    width,
    animate,
    dataLabels,
    legend,
    palette,
    c1,
    c2,
    c3,
    c4,
    c5,
    onClick,
    labels,
    series,
    labelType
  ];
}
class DonutChart extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      title: 1,
      dataProvider: 2,
      labelColumn: 3,
      valueColumn: 4,
      height: 5,
      width: 6,
      animate: 7,
      dataLabels: 8,
      legend: 9,
      palette: 10,
      c1: 11,
      c2: 12,
      c3: 13,
      c4: 14,
      c5: 15,
      onClick: 16
    });
  }
}
export {
  DonutChart as default
};
