import { S as SvelteComponent, i as init, s as safe_not_equal, W as binding_callbacks, a0 as bind, c as create_component, m as mount_component, a1 as add_flush_callback, k as transition_in, n as transition_out, p as destroy_component, aK as FieldType, u as getContext, v as component_subscribe, y as empty, f as insert, z as group_outros, A as check_outros, o as detach, cp as Dropzone } from "./index-a0738cd3.js";
import { F as Field } from "./Field-026e9b04.js";
import "./Placeholder-31706623.js";
import "./InnerForm-c723d600.js";
function create_if_block(ctx) {
  let coredropzone;
  let current;
  coredropzone = new Dropzone({
    props: {
      value: (
        /*fieldApiMapper*/
        ctx[14].get(
          /*fieldState*/
          ctx[16].value
        )
      ),
      disabled: (
        /*fieldState*/
        ctx[16].disabled || /*fieldState*/
        ctx[16].readonly
      ),
      error: (
        /*fieldState*/
        ctx[16].error
      ),
      processFiles: (
        /*processFiles*/
        ctx[22]
      ),
      handleFileTooLarge: (
        /*$environmentStore*/
        ctx[18].cloud ? (
          /*handleFileTooLarge*/
          ctx[20]
        ) : null
      ),
      handleTooManyFiles: (
        /*handleTooManyFiles*/
        ctx[21]
      ),
      maximum: (
        /*maximum*/
        ctx[7]
      ),
      extensions: (
        /*extensions*/
        ctx[6]
      ),
      compact: (
        /*compact*/
        ctx[4]
      ),
      titleText: (
        /*titleText*/
        ctx[10]
      ),
      clickText: (
        /*clickText*/
        ctx[11]
      ),
      addText: (
        /*addText*/
        ctx[12]
      )
    }
  });
  coredropzone.$on(
    "change",
    /*handleChange*/
    ctx[23]
  );
  return {
    c() {
      create_component(coredropzone.$$.fragment);
    },
    m(target, anchor) {
      mount_component(coredropzone, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const coredropzone_changes = {};
      if (dirty & /*fieldApiMapper, fieldState*/
      81920)
        coredropzone_changes.value = /*fieldApiMapper*/
        ctx2[14].get(
          /*fieldState*/
          ctx2[16].value
        );
      if (dirty & /*fieldState*/
      65536)
        coredropzone_changes.disabled = /*fieldState*/
        ctx2[16].disabled || /*fieldState*/
        ctx2[16].readonly;
      if (dirty & /*fieldState*/
      65536)
        coredropzone_changes.error = /*fieldState*/
        ctx2[16].error;
      if (dirty & /*$environmentStore*/
      262144)
        coredropzone_changes.handleFileTooLarge = /*$environmentStore*/
        ctx2[18].cloud ? (
          /*handleFileTooLarge*/
          ctx2[20]
        ) : null;
      if (dirty & /*maximum*/
      128)
        coredropzone_changes.maximum = /*maximum*/
        ctx2[7];
      if (dirty & /*extensions*/
      64)
        coredropzone_changes.extensions = /*extensions*/
        ctx2[6];
      if (dirty & /*compact*/
      16)
        coredropzone_changes.compact = /*compact*/
        ctx2[4];
      if (dirty & /*titleText*/
      1024)
        coredropzone_changes.titleText = /*titleText*/
        ctx2[10];
      if (dirty & /*clickText*/
      2048)
        coredropzone_changes.clickText = /*clickText*/
        ctx2[11];
      if (dirty & /*addText*/
      4096)
        coredropzone_changes.addText = /*addText*/
        ctx2[12];
      coredropzone.$set(coredropzone_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(coredropzone.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(coredropzone.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(coredropzone, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*fieldState*/
    ctx[16] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*fieldState*/
        ctx2[16]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*fieldState*/
          65536) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let current;
  function field_1_fieldState_binding(value) {
    ctx[25](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[26](value);
  }
  let field_1_props = {
    label: (
      /*label*/
      ctx[1]
    ),
    field: (
      /*field*/
      ctx[0]
    ),
    disabled: (
      /*disabled*/
      ctx[2]
    ),
    readonly: (
      /*readonly*/
      ctx[3]
    ),
    validation: (
      /*validation*/
      ctx[5]
    ),
    span: (
      /*span*/
      ctx[8]
    ),
    helpText: (
      /*helpText*/
      ctx[9]
    ),
    type: (
      /*type*/
      ctx[13]
    ),
    defaultValue: (
      /*defaultValue*/
      ctx[15]
    ),
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*fieldState*/
    ctx[16] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[16];
  }
  if (
    /*fieldApi*/
    ctx[17] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[17];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  return {
    c() {
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const field_1_changes = {};
      if (dirty & /*label*/
      2)
        field_1_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*field*/
      1)
        field_1_changes.field = /*field*/
        ctx2[0];
      if (dirty & /*disabled*/
      4)
        field_1_changes.disabled = /*disabled*/
        ctx2[2];
      if (dirty & /*readonly*/
      8)
        field_1_changes.readonly = /*readonly*/
        ctx2[3];
      if (dirty & /*validation*/
      32)
        field_1_changes.validation = /*validation*/
        ctx2[5];
      if (dirty & /*span*/
      256)
        field_1_changes.span = /*span*/
        ctx2[8];
      if (dirty & /*helpText*/
      512)
        field_1_changes.helpText = /*helpText*/
        ctx2[9];
      if (dirty & /*type*/
      8192)
        field_1_changes.type = /*type*/
        ctx2[13];
      if (dirty & /*defaultValue*/
      32768)
        field_1_changes.defaultValue = /*defaultValue*/
        ctx2[15];
      if (dirty & /*$$scope, fieldApiMapper, fieldState, $environmentStore, maximum, extensions, compact, titleText, clickText, addText*/
      1074093264) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty & /*fieldState*/
      65536) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[16];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty & /*fieldApi*/
      131072) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[17];
        add_flush_callback(() => updating_fieldApi = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field_1, detaching);
    }
  };
}
const BYTES_IN_MB = 1e6;
function instance($$self, $$props, $$invalidate) {
  let $environmentStore;
  let { field } = $$props;
  let { label } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { compact = false } = $$props;
  let { validation } = $$props;
  let { extensions } = $$props;
  let { onChange } = $$props;
  let { maximum = void 0 } = $$props;
  let { span } = $$props;
  let { helpText = null } = $$props;
  let { titleText } = $$props;
  let { clickText } = $$props;
  let { addText } = $$props;
  let { type = FieldType.ATTACHMENTS } = $$props;
  let { fieldApiMapper = { get: (value) => value, set: (value) => value } } = $$props;
  let { defaultValue = [] } = $$props;
  let fieldState;
  let fieldApi;
  const { API, notificationStore, environmentStore } = getContext("sdk");
  component_subscribe($$self, environmentStore, (value) => $$invalidate(18, $environmentStore = value));
  const formContext = getContext("form");
  const handleFileTooLarge = (fileSizeLimit) => {
    notificationStore.actions.warning(`Files cannot exceed ${fileSizeLimit / BYTES_IN_MB} MB. Please try again with smaller files.`);
  };
  const handleTooManyFiles = (fileLimit) => {
    notificationStore.actions.warning(`Please select a maximum of ${fileLimit} files.`);
  };
  const processFiles = async (fileList) => {
    var _a, _b;
    let data = new FormData();
    for (let i = 0; i < fileList.length; i++) {
      data.append("file", fileList[i]);
    }
    try {
      let sourceId = (_a = formContext == null ? void 0 : formContext.dataSource) == null ? void 0 : _a.tableId;
      if (((_b = formContext == null ? void 0 : formContext.dataSource) == null ? void 0 : _b.type) === "viewV2") {
        sourceId = formContext.dataSource.id;
      }
      return await API.uploadAttachment(sourceId, data);
    } catch (error) {
      return [];
    }
  };
  const handleChange = (e) => {
    const value = fieldApiMapper.set(e.detail);
    const changed = fieldApi.setValue(value);
    if (onChange && changed) {
      onChange({ value });
    }
  };
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(16, fieldState);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(17, fieldApi);
  }
  $$self.$$set = ($$props2) => {
    if ("field" in $$props2)
      $$invalidate(0, field = $$props2.field);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("disabled" in $$props2)
      $$invalidate(2, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(3, readonly = $$props2.readonly);
    if ("compact" in $$props2)
      $$invalidate(4, compact = $$props2.compact);
    if ("validation" in $$props2)
      $$invalidate(5, validation = $$props2.validation);
    if ("extensions" in $$props2)
      $$invalidate(6, extensions = $$props2.extensions);
    if ("onChange" in $$props2)
      $$invalidate(24, onChange = $$props2.onChange);
    if ("maximum" in $$props2)
      $$invalidate(7, maximum = $$props2.maximum);
    if ("span" in $$props2)
      $$invalidate(8, span = $$props2.span);
    if ("helpText" in $$props2)
      $$invalidate(9, helpText = $$props2.helpText);
    if ("titleText" in $$props2)
      $$invalidate(10, titleText = $$props2.titleText);
    if ("clickText" in $$props2)
      $$invalidate(11, clickText = $$props2.clickText);
    if ("addText" in $$props2)
      $$invalidate(12, addText = $$props2.addText);
    if ("type" in $$props2)
      $$invalidate(13, type = $$props2.type);
    if ("fieldApiMapper" in $$props2)
      $$invalidate(14, fieldApiMapper = $$props2.fieldApiMapper);
    if ("defaultValue" in $$props2)
      $$invalidate(15, defaultValue = $$props2.defaultValue);
  };
  return [
    field,
    label,
    disabled,
    readonly,
    compact,
    validation,
    extensions,
    maximum,
    span,
    helpText,
    titleText,
    clickText,
    addText,
    type,
    fieldApiMapper,
    defaultValue,
    fieldState,
    fieldApi,
    $environmentStore,
    environmentStore,
    handleFileTooLarge,
    handleTooManyFiles,
    processFiles,
    handleChange,
    onChange,
    field_1_fieldState_binding,
    field_1_fieldApi_binding
  ];
}
class AttachmentField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      field: 0,
      label: 1,
      disabled: 2,
      readonly: 3,
      compact: 4,
      validation: 5,
      extensions: 6,
      onChange: 24,
      maximum: 7,
      span: 8,
      helpText: 9,
      titleText: 10,
      clickText: 11,
      addText: 12,
      type: 13,
      fieldApiMapper: 14,
      defaultValue: 15
    });
  }
}
export {
  AttachmentField as default
};
