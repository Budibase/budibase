import { S as SvelteComponent, i as init, s as safe_not_equal, ac as Modal, e as element, a as space, c as create_component, b as attr, f as insert, g as append, m as mount_component, k as transition_in, z as group_outros, n as transition_out, A as check_outros, o as detach, p as destroy_component, Y as createEventDispatcher, t as text, j as set_data, a7 as Input, W as binding_callbacks, a0 as bind, a1 as add_flush_callback, cr as StatusLight, ce as ActionButton, a4 as ModalContent, I as Icon, y as empty, ap as Button, B as noop } from "./index-a0738cd3.js";
import { F as Field } from "./Field-026e9b04.js";
import "./Placeholder-31706623.js";
import "./InnerForm-c723d600.js";
const CodeScanner_svelte_svelte_type_style_lang = "";
function create_if_block_7(ctx) {
  let div;
  let show_if;
  let current_block_type_index;
  let if_block;
  let t0;
  let t1;
  let current;
  const if_block_creators = [create_if_block_8, create_else_block_2];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    var _a;
    if (dirty[0] & /*validator, value*/
    17)
      show_if = null;
    if (show_if == null)
      show_if = !!/*validator*/
      ((_a = ctx2[4]) == null ? void 0 : _a.call(
        ctx2,
        /*value*/
        ctx2[0]
      ));
    if (show_if)
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx, [-1, -1]);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      div = element("div");
      if_block.c();
      t0 = space();
      t1 = text(
        /*value*/
        ctx[0]
      );
      attr(div, "class", "scanner-value field-display svelte-1jyd4la");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      append(div, t0);
      append(div, t1);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2, dirty);
      if (current_block_type_index !== previous_block_index) {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        }
        transition_in(if_block, 1);
        if_block.m(div, t0);
      }
      if (!current || dirty[0] & /*value*/
      1)
        set_data(
          t1,
          /*value*/
          ctx2[0]
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
    }
  };
}
function create_else_block_2(ctx) {
  let statuslight;
  let current;
  statuslight = new StatusLight({ props: { positive: true } });
  return {
    c() {
      create_component(statuslight.$$.fragment);
    },
    m(target, anchor) {
      mount_component(statuslight, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(statuslight.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(statuslight.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(statuslight, detaching);
    }
  };
}
function create_if_block_8(ctx) {
  let statuslight;
  let current;
  statuslight = new StatusLight({ props: { negative: true } });
  return {
    c() {
      create_component(statuslight.$$.fragment);
    },
    m(target, anchor) {
      mount_component(statuslight, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(statuslight.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(statuslight.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(statuslight, detaching);
    }
  };
}
function create_if_block_6(ctx) {
  let div;
  let input;
  let updating_value;
  let current;
  function input_value_binding(value) {
    ctx[19](value);
  }
  let input_props = { updateOnChange: false };
  if (
    /*value*/
    ctx[0] !== void 0
  ) {
    input_props.value = /*value*/
    ctx[0];
  }
  input = new Input({ props: input_props });
  binding_callbacks.push(() => bind(input, "value", input_value_binding));
  input.$on(
    "change",
    /*change_handler*/
    ctx[20]
  );
  return {
    c() {
      div = element("div");
      create_component(input.$$.fragment);
      attr(div, "class", "manual-input svelte-1jyd4la");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(input, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const input_changes = {};
      if (!updating_value && dirty[0] & /*value*/
      1) {
        updating_value = true;
        input_changes.value = /*value*/
        ctx2[0];
        add_flush_callback(() => updating_value = false);
      }
      input.$set(input_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(input.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(input.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(input);
    }
  };
}
function create_else_block_1(ctx) {
  let actionbutton;
  let current;
  actionbutton = new ActionButton({
    props: {
      icon: "camera",
      disabled: (
        /*disabled*/
        ctx[1]
      ),
      $$slots: { default: [create_default_slot_5] },
      $$scope: { ctx }
    }
  });
  actionbutton.$on(
    "click",
    /*click_handler_1*/
    ctx[22]
  );
  return {
    c() {
      create_component(actionbutton.$$.fragment);
    },
    m(target, anchor) {
      mount_component(actionbutton, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const actionbutton_changes = {};
      if (dirty[0] & /*disabled*/
      2)
        actionbutton_changes.disabled = /*disabled*/
        ctx2[1];
      if (dirty[0] & /*scanButtonText*/
      8 | dirty[1] & /*$$scope*/
      32) {
        actionbutton_changes.$$scope = { dirty, ctx: ctx2 };
      }
      actionbutton.$set(actionbutton_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(actionbutton.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(actionbutton.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(actionbutton, detaching);
    }
  };
}
function create_if_block_5(ctx) {
  let actionbutton;
  let current;
  actionbutton = new ActionButton({
    props: {
      disabled: (
        /*disabled*/
        ctx[1]
      ),
      $$slots: { default: [create_default_slot_4] },
      $$scope: { ctx }
    }
  });
  actionbutton.$on(
    "click",
    /*click_handler*/
    ctx[21]
  );
  return {
    c() {
      create_component(actionbutton.$$.fragment);
    },
    m(target, anchor) {
      mount_component(actionbutton, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const actionbutton_changes = {};
      if (dirty[0] & /*disabled*/
      2)
        actionbutton_changes.disabled = /*disabled*/
        ctx2[1];
      if (dirty[1] & /*$$scope*/
      32) {
        actionbutton_changes.$$scope = { dirty, ctx: ctx2 };
      }
      actionbutton.$set(actionbutton_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(actionbutton.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(actionbutton.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(actionbutton, detaching);
    }
  };
}
function create_default_slot_5(ctx) {
  let t;
  return {
    c() {
      t = text(
        /*scanButtonText*/
        ctx[3]
      );
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*scanButtonText*/
      8)
        set_data(
          t,
          /*scanButtonText*/
          ctx2[3]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_4(ctx) {
  let t;
  return {
    c() {
      t = text("Clear");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_4(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      div.textContent = "Your camera is disabled.";
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block_1(ctx) {
  let div;
  let show_if;
  let show_if_1;
  let current_block_type_index;
  let if_block;
  let current;
  const if_block_creators = [create_if_block_2, create_if_block_3, create_else_block];
  const if_blocks = [];
  function select_block_type_2(ctx2, dirty) {
    var _a, _b;
    if (dirty[0] & /*value, validator*/
    17)
      show_if = null;
    if (dirty[0] & /*value, validator*/
    17)
      show_if_1 = null;
    if (show_if == null)
      show_if = !!/*value*/
      (ctx2[0] && !/*validator*/
      ((_a = ctx2[4]) == null ? void 0 : _a.call(
        ctx2,
        /*value*/
        ctx2[0]
      )));
    if (show_if)
      return 0;
    if (show_if_1 == null)
      show_if_1 = !!/*value*/
      (ctx2[0] && /*validator*/
      ((_b = ctx2[4]) == null ? void 0 : _b.call(
        ctx2,
        /*value*/
        ctx2[0]
      )));
    if (show_if_1)
      return 1;
    return 2;
  }
  current_block_type_index = select_block_type_2(ctx, [-1, -1]);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      div = element("div");
      if_block.c();
      attr(div, "class", "code-wrap");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_2(ctx2, dirty);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div, null);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
    }
  };
}
function create_else_block(ctx) {
  let div;
  let statuslight;
  let t;
  let current;
  statuslight = new StatusLight({ props: { neutral: true } });
  return {
    c() {
      div = element("div");
      create_component(statuslight.$$.fragment);
      t = text("\n              Searching for code...");
      attr(div, "class", "scanner-value svelte-1jyd4la");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(statuslight, div, null);
      append(div, t);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(statuslight.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(statuslight.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(statuslight);
    }
  };
}
function create_if_block_3(ctx) {
  let div;
  let statuslight;
  let t0;
  let t1;
  let current;
  statuslight = new StatusLight({ props: { negative: true } });
  return {
    c() {
      div = element("div");
      create_component(statuslight.$$.fragment);
      t0 = space();
      t1 = text(
        /*value*/
        ctx[0]
      );
      attr(div, "class", "scanner-value svelte-1jyd4la");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(statuslight, div, null);
      append(div, t0);
      append(div, t1);
      current = true;
    },
    p(ctx2, dirty) {
      if (!current || dirty[0] & /*value*/
      1)
        set_data(
          t1,
          /*value*/
          ctx2[0]
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(statuslight.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(statuslight.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(statuslight);
    }
  };
}
function create_if_block_2(ctx) {
  let div;
  let statuslight;
  let t0;
  let t1;
  let current;
  statuslight = new StatusLight({ props: { positive: true } });
  return {
    c() {
      div = element("div");
      create_component(statuslight.$$.fragment);
      t0 = space();
      t1 = text(
        /*value*/
        ctx[0]
      );
      attr(div, "class", "scanner-value svelte-1jyd4la");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(statuslight, div, null);
      append(div, t0);
      append(div, t1);
      current = true;
    },
    p(ctx2, dirty) {
      if (!current || dirty[0] & /*value*/
      1)
        set_data(
          t1,
          /*value*/
          ctx2[0]
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(statuslight.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(statuslight.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(statuslight);
    }
  };
}
function create_default_slot_3(ctx) {
  let div1;
  let div0;
  let icon;
  let t0;
  let t1;
  let if_block1_anchor;
  let current;
  icon = new Icon({ props: { size: "XXL", name: "camera" } });
  let if_block0 = (
    /*cameraEnabled*/
    ctx[6] === false && create_if_block_4()
  );
  let if_block1 = (
    /*cameraEnabled*/
    ctx[6] === true && create_if_block_1(ctx)
  );
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      create_component(icon.$$.fragment);
      t0 = space();
      if (if_block0)
        if_block0.c();
      t1 = space();
      if (if_block1)
        if_block1.c();
      if_block1_anchor = empty();
      attr(div0, "class", "camera-placeholder svelte-1jyd4la");
      attr(div1, "id", "reader");
      attr(div1, "class", "container svelte-1jyd4la");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      mount_component(icon, div0, null);
      append(div0, t0);
      if (if_block0)
        if_block0.m(div0, null);
      ctx[25](div1);
      insert(target, t1, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, if_block1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*cameraEnabled*/
        ctx2[6] === false
      ) {
        if (if_block0)
          ;
        else {
          if_block0 = create_if_block_4();
          if_block0.c();
          if_block0.m(div0, null);
        }
      } else if (if_block0) {
        if_block0.d(1);
        if_block0 = null;
      }
      if (
        /*cameraEnabled*/
        ctx2[6] === true
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty[0] & /*cameraEnabled*/
          64) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_1(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(if_block1_anchor.parentNode, if_block1_anchor);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
        detach(t1);
        detach(if_block1_anchor);
      }
      destroy_component(icon);
      if (if_block0)
        if_block0.d();
      ctx[25](null);
      if (if_block1)
        if_block1.d(detaching);
    }
  };
}
function create_if_block$1(ctx) {
  let button;
  let current;
  button = new Button({
    props: {
      group: true,
      secondary: true,
      newStyles: true,
      $$slots: { default: [create_default_slot_2] },
      $$scope: { ctx }
    }
  });
  button.$on(
    "click",
    /*click_handler_2*/
    ctx[23]
  );
  return {
    c() {
      create_component(button.$$.fragment);
    },
    m(target, anchor) {
      mount_component(button, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const button_changes = {};
      if (dirty[1] & /*$$scope*/
      32) {
        button_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button.$set(button_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(button.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(button.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(button, detaching);
    }
  };
}
function create_default_slot_2(ctx) {
  let t;
  return {
    c() {
      t = text("Enter manually");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_1(ctx) {
  let t;
  return {
    c() {
      t = text("Confirm");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_footer_slot(ctx) {
  let div1;
  let div0;
  let t;
  let button;
  let current;
  let if_block = (
    /*allowManualEntry*/
    ctx[2] && !/*manualMode*/
    ctx[8] && create_if_block$1(ctx)
  );
  button = new Button({
    props: {
      group: true,
      cta: true,
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  button.$on(
    "click",
    /*click_handler_3*/
    ctx[24]
  );
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      if (if_block)
        if_block.c();
      t = space();
      create_component(button.$$.fragment);
      attr(div0, "class", "footer-buttons svelte-1jyd4la");
      attr(div1, "slot", "footer");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      if (if_block)
        if_block.m(div0, null);
      append(div0, t);
      mount_component(button, div0, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*allowManualEntry*/
        ctx2[2] && !/*manualMode*/
        ctx2[8]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*allowManualEntry, manualMode*/
          260) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div0, t);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      const button_changes = {};
      if (dirty[1] & /*$$scope*/
      32) {
        button_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button.$set(button_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      transition_in(button.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      transition_out(button.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if (if_block)
        if_block.d();
      destroy_component(button);
    }
  };
}
function create_default_slot$1(ctx) {
  let modalcontent;
  let current;
  modalcontent = new ModalContent({
    props: {
      title: (
        /*scanButtonText*/
        ctx[3]
      ),
      showConfirmButton: false,
      showCancelButton: false,
      $$slots: {
        footer: [create_footer_slot],
        default: [create_default_slot_3]
      },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(modalcontent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(modalcontent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const modalcontent_changes = {};
      if (dirty[0] & /*scanButtonText*/
      8)
        modalcontent_changes.title = /*scanButtonText*/
        ctx2[3];
      if (dirty[0] & /*camModal, manualMode, allowManualEntry, value, validator, cameraEnabled, videoEle*/
      501 | dirty[1] & /*$$scope*/
      32) {
        modalcontent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modalcontent.$set(modalcontent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(modalcontent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(modalcontent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(modalcontent, detaching);
    }
  };
}
function create_fragment$1(ctx) {
  let div0;
  let t0;
  let t1;
  let current_block_type_index;
  let if_block2;
  let t2;
  let div1;
  let modal;
  let current;
  let if_block0 = (
    /*value*/
    ctx[0] && !/*manualMode*/
    ctx[8] && create_if_block_7(ctx)
  );
  let if_block1 = (
    /*allowManualEntry*/
    ctx[2] && /*manualMode*/
    ctx[8] && create_if_block_6(ctx)
  );
  const if_block_creators = [create_if_block_5, create_else_block_1];
  const if_blocks = [];
  function select_block_type_1(ctx2, dirty) {
    if (
      /*value*/
      ctx2[0]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type_1(ctx);
  if_block2 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  let modal_props = {
    $$slots: { default: [create_default_slot$1] },
    $$scope: { ctx }
  };
  modal = new Modal({ props: modal_props });
  ctx[26](modal);
  modal.$on(
    "hide",
    /*hideReaderModal*/
    ctx[11]
  );
  return {
    c() {
      div0 = element("div");
      if (if_block0)
        if_block0.c();
      t0 = space();
      if (if_block1)
        if_block1.c();
      t1 = space();
      if_block2.c();
      t2 = space();
      div1 = element("div");
      create_component(modal.$$.fragment);
      attr(div0, "class", "scanner-video-wrapper");
      attr(div1, "class", "modal-wrap");
    },
    m(target, anchor) {
      insert(target, div0, anchor);
      if (if_block0)
        if_block0.m(div0, null);
      append(div0, t0);
      if (if_block1)
        if_block1.m(div0, null);
      append(div0, t1);
      if_blocks[current_block_type_index].m(div0, null);
      insert(target, t2, anchor);
      insert(target, div1, anchor);
      mount_component(modal, div1, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*value*/
        ctx2[0] && !/*manualMode*/
        ctx2[8]
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty[0] & /*value, manualMode*/
          257) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_7(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(div0, t0);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (
        /*allowManualEntry*/
        ctx2[2] && /*manualMode*/
        ctx2[8]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty[0] & /*allowManualEntry, manualMode*/
          260) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_6(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div0, t1);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_1(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block2 = if_blocks[current_block_type_index];
        if (!if_block2) {
          if_block2 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block2.c();
        } else {
          if_block2.p(ctx2, dirty);
        }
        transition_in(if_block2, 1);
        if_block2.m(div0, null);
      }
      const modal_changes = {};
      if (dirty[0] & /*scanButtonText, camModal, manualMode, allowManualEntry, value, validator, cameraEnabled, videoEle*/
      509 | dirty[1] & /*$$scope*/
      32) {
        modal_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modal.$set(modal_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      transition_in(if_block2);
      transition_in(modal.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      transition_out(if_block2);
      transition_out(modal.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div0);
        detach(t2);
        detach(div1);
      }
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
      if_blocks[current_block_type_index].d();
      ctx[26](null);
      destroy_component(modal);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let { value } = $$props;
  let { disabled = false } = $$props;
  let { allowManualEntry = false } = $$props;
  let { autoConfirm = false } = $$props;
  let { scanButtonText = "Scan code" } = $$props;
  let { beepOnScan = false } = $$props;
  let { beepFrequency = 2637 } = $$props;
  let { customFrequency = 1046 } = $$props;
  let { preferredCamera = "environment" } = $$props;
  let { defaultZoom = 1 } = $$props;
  let { validator } = $$props;
  const dispatch = createEventDispatcher();
  let videoEle;
  let camModal;
  let manualMode = false;
  let cameraEnabled;
  let cameraStarted = false;
  let html5QrCode;
  let cameraSetting = { facingMode: preferredCamera };
  let cameraConfig = {
    fps: 25,
    qrbox: { width: 250, height: 250 }
  };
  const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  const onScanSuccess = (decodedText) => {
    if (value != decodedText) {
      if (beepOnScan) {
        beep();
      }
      dispatch("change", decodedText);
      if (autoConfirm && !(validator == null ? void 0 : validator(decodedText))) {
        camModal == null ? void 0 : camModal.hide();
      }
    }
  };
  const initReader = async () => {
    if (html5QrCode) {
      html5QrCode.stop();
    }
    const { Html5Qrcode } = await import("./index-445f15a6.js");
    html5QrCode = new Html5Qrcode("reader");
    return new Promise((resolve) => {
      html5QrCode.start(cameraSetting, cameraConfig, onScanSuccess).then(() => {
        if (defaultZoom > 1) {
          const cameraOptions = html5QrCode.getRunningTrackCameraCapabilities();
          const zoom = cameraOptions.zoomFeature();
          if (zoom.isSupported()) {
            zoom.apply(defaultZoom);
          }
        }
        resolve({ initialised: true });
      }).catch((err) => {
        console.error("There was a problem scanning the image", err);
        resolve({ initialised: false });
      });
    });
  };
  const checkCamera = async () => {
    const { Html5Qrcode } = await import("./index-445f15a6.js");
    return new Promise((resolve) => {
      Html5Qrcode.getCameras().then((devices) => {
        if (devices && devices.length) {
          resolve({ enabled: true });
        }
      }).catch((e) => {
        console.error(e);
        resolve({ enabled: false });
      });
    });
  };
  const start = async () => {
    const status = await initReader();
    $$invalidate(18, cameraStarted = status.initialised);
  };
  const showReaderModal = async () => {
    camModal.show();
    const camStatus = await checkCamera();
    $$invalidate(6, cameraEnabled = camStatus.enabled);
  };
  const hideReaderModal = async () => {
    $$invalidate(6, cameraEnabled = void 0);
    $$invalidate(18, cameraStarted = false);
    if (html5QrCode) {
      await html5QrCode.stop();
      html5QrCode = void 0;
    }
    camModal.hide();
  };
  const beep = () => {
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    const frequency = beepFrequency === "custom" ? customFrequency : beepFrequency;
    oscillator.frequency.value = frequency;
    oscillator.type = "square";
    const duration = 420;
    const endTime = audioCtx.currentTime + duration / 1e3;
    gainNode.gain.setValueAtTime(1, audioCtx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(1e-3, endTime);
    oscillator.start();
    oscillator.stop(endTime);
  };
  function input_value_binding(value$1) {
    value = value$1;
    $$invalidate(0, value);
  }
  const change_handler = () => {
    dispatch("change", value);
  };
  const click_handler = () => {
    dispatch("change", "");
  };
  const click_handler_1 = () => {
    showReaderModal();
  };
  const click_handler_2 = () => {
    $$invalidate(8, manualMode = true);
    camModal.hide();
  };
  const click_handler_3 = () => {
    camModal.hide();
  };
  function div1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      videoEle = $$value;
      $$invalidate(5, videoEle);
    });
  }
  function modal_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      camModal = $$value;
      $$invalidate(7, camModal);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("disabled" in $$props2)
      $$invalidate(1, disabled = $$props2.disabled);
    if ("allowManualEntry" in $$props2)
      $$invalidate(2, allowManualEntry = $$props2.allowManualEntry);
    if ("autoConfirm" in $$props2)
      $$invalidate(12, autoConfirm = $$props2.autoConfirm);
    if ("scanButtonText" in $$props2)
      $$invalidate(3, scanButtonText = $$props2.scanButtonText);
    if ("beepOnScan" in $$props2)
      $$invalidate(13, beepOnScan = $$props2.beepOnScan);
    if ("beepFrequency" in $$props2)
      $$invalidate(14, beepFrequency = $$props2.beepFrequency);
    if ("customFrequency" in $$props2)
      $$invalidate(15, customFrequency = $$props2.customFrequency);
    if ("preferredCamera" in $$props2)
      $$invalidate(16, preferredCamera = $$props2.preferredCamera);
    if ("defaultZoom" in $$props2)
      $$invalidate(17, defaultZoom = $$props2.defaultZoom);
    if ("validator" in $$props2)
      $$invalidate(4, validator = $$props2.validator);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*cameraEnabled, videoEle, cameraStarted*/
    262240) {
      if (cameraEnabled && videoEle && !cameraStarted) {
        start();
      }
    }
  };
  return [
    value,
    disabled,
    allowManualEntry,
    scanButtonText,
    validator,
    videoEle,
    cameraEnabled,
    camModal,
    manualMode,
    dispatch,
    showReaderModal,
    hideReaderModal,
    autoConfirm,
    beepOnScan,
    beepFrequency,
    customFrequency,
    preferredCamera,
    defaultZoom,
    cameraStarted,
    input_value_binding,
    change_handler,
    click_handler,
    click_handler_1,
    click_handler_2,
    click_handler_3,
    div1_binding,
    modal_binding
  ];
}
class CodeScanner extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance$1,
      create_fragment$1,
      safe_not_equal,
      {
        value: 0,
        disabled: 1,
        allowManualEntry: 2,
        autoConfirm: 12,
        scanButtonText: 3,
        beepOnScan: 13,
        beepFrequency: 14,
        customFrequency: 15,
        preferredCamera: 16,
        defaultZoom: 17,
        validator: 4
      },
      null,
      [-1, -1]
    );
  }
}
function create_if_block(ctx) {
  let codescanner;
  let current;
  codescanner = new CodeScanner({
    props: {
      value: (
        /*fieldState*/
        ctx[15].value
      ),
      disabled: (
        /*fieldState*/
        ctx[15].disabled || /*fieldState*/
        ctx[15].readonly
      ),
      allowManualEntry: (
        /*allowManualEntry*/
        ctx[7]
      ),
      autoConfirm: (
        /*autoConfirm*/
        ctx[8]
      ),
      scanButtonText: (
        /*scanText*/
        ctx[17]
      ),
      beepOnScan: (
        /*beepOnScan*/
        ctx[9]
      ),
      beepFrequency: (
        /*beepFrequency*/
        ctx[10]
      ),
      customFrequency: (
        /*customFrequency*/
        ctx[11]
      ),
      preferredCamera: (
        /*preferredCamera*/
        ctx[12]
      ),
      defaultZoom: (
        /*defaultZoom*/
        ctx[13]
      ),
      validator: (
        /*fieldState*/
        ctx[15].validator
      )
    }
  });
  codescanner.$on(
    "change",
    /*handleUpdate*/
    ctx[18]
  );
  return {
    c() {
      create_component(codescanner.$$.fragment);
    },
    m(target, anchor) {
      mount_component(codescanner, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const codescanner_changes = {};
      if (dirty & /*fieldState*/
      32768)
        codescanner_changes.value = /*fieldState*/
        ctx2[15].value;
      if (dirty & /*fieldState*/
      32768)
        codescanner_changes.disabled = /*fieldState*/
        ctx2[15].disabled || /*fieldState*/
        ctx2[15].readonly;
      if (dirty & /*allowManualEntry*/
      128)
        codescanner_changes.allowManualEntry = /*allowManualEntry*/
        ctx2[7];
      if (dirty & /*autoConfirm*/
      256)
        codescanner_changes.autoConfirm = /*autoConfirm*/
        ctx2[8];
      if (dirty & /*scanText*/
      131072)
        codescanner_changes.scanButtonText = /*scanText*/
        ctx2[17];
      if (dirty & /*beepOnScan*/
      512)
        codescanner_changes.beepOnScan = /*beepOnScan*/
        ctx2[9];
      if (dirty & /*beepFrequency*/
      1024)
        codescanner_changes.beepFrequency = /*beepFrequency*/
        ctx2[10];
      if (dirty & /*customFrequency*/
      2048)
        codescanner_changes.customFrequency = /*customFrequency*/
        ctx2[11];
      if (dirty & /*preferredCamera*/
      4096)
        codescanner_changes.preferredCamera = /*preferredCamera*/
        ctx2[12];
      if (dirty & /*defaultZoom*/
      8192)
        codescanner_changes.defaultZoom = /*defaultZoom*/
        ctx2[13];
      if (dirty & /*fieldState*/
      32768)
        codescanner_changes.validator = /*fieldState*/
        ctx2[15].validator;
      codescanner.$set(codescanner_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(codescanner.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(codescanner.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(codescanner, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*fieldState*/
    ctx[15] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*fieldState*/
        ctx2[15]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*fieldState*/
          32768) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let current;
  function field_1_fieldState_binding(value) {
    ctx[21](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[22](value);
  }
  let field_1_props = {
    label: (
      /*label*/
      ctx[1]
    ),
    field: (
      /*field*/
      ctx[0]
    ),
    disabled: (
      /*disabled*/
      ctx[3]
    ),
    readonly: (
      /*readonly*/
      ctx[4]
    ),
    validation: (
      /*validation*/
      ctx[5]
    ),
    defaultValue: (
      /*defaultValue*/
      ctx[6]
    ),
    type: (
      /*type*/
      ctx[2]
    ),
    helpText: (
      /*helpText*/
      ctx[14]
    ),
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*fieldState*/
    ctx[15] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[15];
  }
  if (
    /*fieldApi*/
    ctx[16] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[16];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  return {
    c() {
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const field_1_changes = {};
      if (dirty & /*label*/
      2)
        field_1_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*field*/
      1)
        field_1_changes.field = /*field*/
        ctx2[0];
      if (dirty & /*disabled*/
      8)
        field_1_changes.disabled = /*disabled*/
        ctx2[3];
      if (dirty & /*readonly*/
      16)
        field_1_changes.readonly = /*readonly*/
        ctx2[4];
      if (dirty & /*validation*/
      32)
        field_1_changes.validation = /*validation*/
        ctx2[5];
      if (dirty & /*defaultValue*/
      64)
        field_1_changes.defaultValue = /*defaultValue*/
        ctx2[6];
      if (dirty & /*type*/
      4)
        field_1_changes.type = /*type*/
        ctx2[2];
      if (dirty & /*helpText*/
      16384)
        field_1_changes.helpText = /*helpText*/
        ctx2[14];
      if (dirty & /*$$scope, fieldState, allowManualEntry, autoConfirm, scanText, beepOnScan, beepFrequency, customFrequency, preferredCamera, defaultZoom*/
      8568704) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty & /*fieldState*/
      32768) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[15];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty & /*fieldApi*/
      65536) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[16];
        add_flush_callback(() => updating_fieldApi = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field_1, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let scanText;
  let { field } = $$props;
  let { label } = $$props;
  let { type = "barcodeqr" } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { validation } = $$props;
  let { defaultValue = "" } = $$props;
  let { onChange } = $$props;
  let { allowManualEntry } = $$props;
  let { autoConfirm } = $$props;
  let { scanButtonText } = $$props;
  let { beepOnScan } = $$props;
  let { beepFrequency } = $$props;
  let { customFrequency } = $$props;
  let { preferredCamera } = $$props;
  let { defaultZoom } = $$props;
  let { helpText = null } = $$props;
  let fieldState;
  let fieldApi;
  const handleUpdate = (e) => {
    const changed = fieldApi.setValue(e.detail);
    if (onChange && changed) {
      onChange({ value: e.detail });
    }
  };
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(15, fieldState);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(16, fieldApi);
  }
  $$self.$$set = ($$props2) => {
    if ("field" in $$props2)
      $$invalidate(0, field = $$props2.field);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("type" in $$props2)
      $$invalidate(2, type = $$props2.type);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(4, readonly = $$props2.readonly);
    if ("validation" in $$props2)
      $$invalidate(5, validation = $$props2.validation);
    if ("defaultValue" in $$props2)
      $$invalidate(6, defaultValue = $$props2.defaultValue);
    if ("onChange" in $$props2)
      $$invalidate(19, onChange = $$props2.onChange);
    if ("allowManualEntry" in $$props2)
      $$invalidate(7, allowManualEntry = $$props2.allowManualEntry);
    if ("autoConfirm" in $$props2)
      $$invalidate(8, autoConfirm = $$props2.autoConfirm);
    if ("scanButtonText" in $$props2)
      $$invalidate(20, scanButtonText = $$props2.scanButtonText);
    if ("beepOnScan" in $$props2)
      $$invalidate(9, beepOnScan = $$props2.beepOnScan);
    if ("beepFrequency" in $$props2)
      $$invalidate(10, beepFrequency = $$props2.beepFrequency);
    if ("customFrequency" in $$props2)
      $$invalidate(11, customFrequency = $$props2.customFrequency);
    if ("preferredCamera" in $$props2)
      $$invalidate(12, preferredCamera = $$props2.preferredCamera);
    if ("defaultZoom" in $$props2)
      $$invalidate(13, defaultZoom = $$props2.defaultZoom);
    if ("helpText" in $$props2)
      $$invalidate(14, helpText = $$props2.helpText);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*scanButtonText*/
    1048576) {
      $$invalidate(17, scanText = scanButtonText || "Scan code");
    }
  };
  return [
    field,
    label,
    type,
    disabled,
    readonly,
    validation,
    defaultValue,
    allowManualEntry,
    autoConfirm,
    beepOnScan,
    beepFrequency,
    customFrequency,
    preferredCamera,
    defaultZoom,
    helpText,
    fieldState,
    fieldApi,
    scanText,
    handleUpdate,
    onChange,
    scanButtonText,
    field_1_fieldState_binding,
    field_1_fieldApi_binding
  ];
}
class CodeScannerField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      field: 0,
      label: 1,
      type: 2,
      disabled: 3,
      readonly: 4,
      validation: 5,
      defaultValue: 6,
      onChange: 19,
      allowManualEntry: 7,
      autoConfirm: 8,
      scanButtonText: 20,
      beepOnScan: 9,
      beepFrequency: 10,
      customFrequency: 11,
      preferredCamera: 12,
      defaultZoom: 13,
      helpText: 14
    });
  }
}
export {
  CodeScannerField as default
};
