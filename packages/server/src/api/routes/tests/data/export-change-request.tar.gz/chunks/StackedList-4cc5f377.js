import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, a as space, t as text, b as attr, f as insert, g as append, q as action_destroyer, j as set_data, h as is_function, B as noop, o as detach, r as run_all, u as getContext, v as component_subscribe, ae as src_url_equal } from "./index-a0738cd3.js";
const StackedList_svelte_svelte_type_style_lang = "";
function create_if_block(ctx) {
  let div;
  let img;
  let img_src_value;
  return {
    c() {
      div = element("div");
      img = element("img");
      attr(img, "class", "image svelte-scr5w");
      if (!src_url_equal(img.src, img_src_value = /*imageUrl*/
      ctx[0]))
        attr(img, "src", img_src_value);
      attr(img, "alt", "");
      attr(div, "class", "image-block svelte-scr5w");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, img);
    },
    p(ctx2, dirty) {
      if (dirty & /*imageUrl*/
      1 && !src_url_equal(img.src, img_src_value = /*imageUrl*/
      ctx2[0])) {
        attr(img, "src", img_src_value);
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_fragment(ctx) {
  let div4;
  let a;
  let div3;
  let t0;
  let div2;
  let div0;
  let t1;
  let t2;
  let div1;
  let t3;
  let styleable_action;
  let mounted;
  let dispose;
  let if_block = (
    /*showImage*/
    ctx[4] && create_if_block(ctx)
  );
  return {
    c() {
      div4 = element("div");
      a = element("a");
      div3 = element("div");
      if (if_block)
        if_block.c();
      t0 = space();
      div2 = element("div");
      div0 = element("div");
      t1 = text(
        /*heading*/
        ctx[1]
      );
      t2 = space();
      div1 = element("div");
      t3 = text(
        /*subheading*/
        ctx[2]
      );
      attr(div0, "class", "heading svelte-scr5w");
      attr(div1, "class", "subheading svelte-scr5w");
      attr(div2, "class", "content svelte-scr5w");
      attr(div3, "class", "stackedlist svelte-scr5w");
      attr(
        a,
        "href",
        /*destinationUrl*/
        ctx[3]
      );
      attr(a, "class", "svelte-scr5w");
      attr(div4, "class", "container svelte-scr5w");
    },
    m(target, anchor) {
      insert(target, div4, anchor);
      append(div4, a);
      append(a, div3);
      if (if_block)
        if_block.m(div3, null);
      append(div3, t0);
      append(div3, div2);
      append(div2, div0);
      append(div0, t1);
      append(div2, t2);
      append(div2, div1);
      append(div1, t3);
      if (!mounted) {
        dispose = [
          action_destroyer(
            /*linkable*/
            ctx[7].call(null, a)
          ),
          action_destroyer(styleable_action = /*styleable*/
          ctx[6].call(
            null,
            div4,
            /*$component*/
            ctx[5].styles
          ))
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (
        /*showImage*/
        ctx2[4]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          if_block.m(div3, t0);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (dirty & /*heading*/
      2)
        set_data(
          t1,
          /*heading*/
          ctx2[1]
        );
      if (dirty & /*subheading*/
      4)
        set_data(
          t3,
          /*subheading*/
          ctx2[2]
        );
      if (dirty & /*destinationUrl*/
      8) {
        attr(
          a,
          "href",
          /*destinationUrl*/
          ctx2[3]
        );
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      32)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[5].styles
        );
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div4);
      }
      if (if_block)
        if_block.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let showImage;
  let $component;
  const { styleable, linkable } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(5, $component = value));
  let { imageUrl = "" } = $$props;
  let { heading = "" } = $$props;
  let { subheading = "" } = $$props;
  let { destinationUrl = "/" } = $$props;
  $$self.$$set = ($$props2) => {
    if ("imageUrl" in $$props2)
      $$invalidate(0, imageUrl = $$props2.imageUrl);
    if ("heading" in $$props2)
      $$invalidate(1, heading = $$props2.heading);
    if ("subheading" in $$props2)
      $$invalidate(2, subheading = $$props2.subheading);
    if ("destinationUrl" in $$props2)
      $$invalidate(3, destinationUrl = $$props2.destinationUrl);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*imageUrl*/
    1) {
      $$invalidate(4, showImage = !!imageUrl);
    }
  };
  return [
    imageUrl,
    heading,
    subheading,
    destinationUrl,
    showImage,
    $component,
    styleable,
    linkable,
    component
  ];
}
class StackedList extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      imageUrl: 0,
      heading: 1,
      subheading: 2,
      destinationUrl: 3
    });
  }
}
export {
  StackedList as default
};
