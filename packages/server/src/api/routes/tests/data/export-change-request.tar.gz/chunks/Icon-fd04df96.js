import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, z as group_outros, n as transition_out, A as check_outros, k as transition_in, o as detach, u as getContext, v as component_subscribe, e as element, c as create_component, m as mount_component, q as action_destroyer, h as is_function, p as destroy_component, b as attr, d as toggle_class, l as listen, B as noop, r as run_all } from "./index-a0738cd3.js";
import Placeholder from "./Placeholder-31706623.js";
import { l as loadPhosphorIconWeight } from "./phosphorIconLoader-f5abc73c.js";
const Icon_svelte_svelte_type_style_lang = "";
function create_if_block_1(ctx) {
  let div;
  let placeholder;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  placeholder = new Placeholder({});
  return {
    c() {
      div = element("div");
      create_component(placeholder.$$.fragment);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(placeholder, div, null);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[6].call(
          null,
          div,
          /*styles*/
          ctx[3]
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (styleable_action && is_function(styleable_action.update) && dirty & /*styles*/
      8)
        styleable_action.update.call(
          null,
          /*styles*/
          ctx2[3]
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(placeholder.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(placeholder.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(placeholder);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block(ctx) {
  let i;
  let i_class_value;
  let styleable_action;
  let mounted;
  let dispose;
  return {
    c() {
      i = element("i");
      attr(i, "class", i_class_value = /*iconClass*/
      ctx[4] + " " + /*size*/
      ctx[1] + " svelte-1ghy1wa");
      toggle_class(
        i,
        "hoverable",
        /*onClick*/
        ctx[2] != null
      );
    },
    m(target, anchor) {
      insert(target, i, anchor);
      if (!mounted) {
        dispose = [
          action_destroyer(styleable_action = /*styleable*/
          ctx[6].call(
            null,
            i,
            /*styles*/
            ctx[3]
          )),
          listen(i, "click", function() {
            if (is_function(
              /*onClick*/
              ctx[2]
            ))
              ctx[2].apply(this, arguments);
          })
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*iconClass, size*/
      18 && i_class_value !== (i_class_value = /*iconClass*/
      ctx[4] + " " + /*size*/
      ctx[1] + " svelte-1ghy1wa")) {
        attr(i, "class", i_class_value);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*styles*/
      8)
        styleable_action.update.call(
          null,
          /*styles*/
          ctx[3]
        );
      if (dirty & /*iconClass, size, onClick*/
      22) {
        toggle_class(
          i,
          "hoverable",
          /*onClick*/
          ctx[2] != null
        );
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(i);
      }
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_fragment(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block, create_if_block_1];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*icon*/
      ctx2[0]
    )
      return 0;
    if (
      /*$builderStore*/
      ctx2[5].inBuilder
    )
      return 1;
    return -1;
  }
  if (~(current_block_type_index = select_block_type(ctx))) {
    if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  }
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].m(target, anchor);
      }
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if (~current_block_type_index) {
          if_blocks[current_block_type_index].p(ctx2, dirty);
        }
      } else {
        if (if_block) {
          group_outros();
          transition_out(if_blocks[previous_block_index], 1, 1, () => {
            if_blocks[previous_block_index] = null;
          });
          check_outros();
        }
        if (~current_block_type_index) {
          if_block = if_blocks[current_block_type_index];
          if (!if_block) {
            if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
            if_block.c();
          } else {
            if_block.p(ctx2, dirty);
          }
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        } else {
          if_block = null;
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].d(detaching);
      }
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let isLegacyIcon;
  let isPhosphorIcon;
  let iconClass;
  let styles;
  let $component;
  let $builderStore;
  const { styleable, builderStore } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(5, $builderStore = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(12, $component = value));
  let { icon } = $$props;
  let { size } = $$props;
  let { color } = $$props;
  let { onClick } = $$props;
  $$self.$$set = ($$props2) => {
    if ("icon" in $$props2)
      $$invalidate(0, icon = $$props2.icon);
    if ("size" in $$props2)
      $$invalidate(1, size = $$props2.size);
    if ("color" in $$props2)
      $$invalidate(9, color = $$props2.color);
    if ("onClick" in $$props2)
      $$invalidate(2, onClick = $$props2.onClick);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*icon*/
    1) {
      $$invalidate(11, isLegacyIcon = icon && (icon.startsWith("ri-") || icon.includes("remix")));
    }
    if ($$self.$$.dirty & /*icon, isLegacyIcon*/
    2049) {
      $$invalidate(10, isPhosphorIcon = icon && !isLegacyIcon);
    }
    if ($$self.$$.dirty & /*isPhosphorIcon*/
    1024) {
      if (isPhosphorIcon) {
        loadPhosphorIconWeight("regular");
      }
    }
    if ($$self.$$.dirty & /*isPhosphorIcon, icon*/
    1025) {
      $$invalidate(4, iconClass = isPhosphorIcon ? (() => {
        const iconName = icon.replace(/^ph-/, "");
        return `ph ph-${iconName}`;
      })() : icon);
    }
    if ($$self.$$.dirty & /*$component, color*/
    4608) {
      $$invalidate(3, styles = {
        ...$component.styles,
        normal: {
          ...$component.styles.normal,
          color: color || "var(--spectrum-global-color-gray-900)"
        }
      });
    }
  };
  return [
    icon,
    size,
    onClick,
    styles,
    iconClass,
    $builderStore,
    styleable,
    builderStore,
    component,
    color,
    isPhosphorIcon,
    isLegacyIcon,
    $component
  ];
}
class Icon extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { icon: 0, size: 1, color: 9, onClick: 2 });
  }
}
export {
  Icon as default
};
