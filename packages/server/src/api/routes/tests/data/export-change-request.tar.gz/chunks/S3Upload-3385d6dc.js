import { S as SvelteComponent, i as init, s as safe_not_equal, W as binding_callbacks, a0 as bind, c as create_component, m as mount_component, a1 as add_flush_callback, k as transition_in, n as transition_out, p as destroy_component, v as component_subscribe, ab as builderStore, u as getContext, U as onMount, w as onDestroy, e as element, a as space, b as attr, d as toggle_class, f as insert, g as append, z as group_outros, A as check_outros, o as detach, bv as processStringSync, bD as cloneDeep, cp as Dropzone, P as ProgressCircle } from "./index-a0738cd3.js";
import { F as Field } from "./Field-026e9b04.js";
import "./Placeholder-31706623.js";
import "./InnerForm-c723d600.js";
const S3Upload_svelte_svelte_type_style_lang = "";
function create_if_block_1(ctx) {
  let coredropzone;
  let current;
  coredropzone = new Dropzone({
    props: {
      value: (
        /*localFiles*/
        ctx[6]
      ),
      disabled: (
        /*loading*/
        ctx[7] || /*fieldState*/
        ctx[4].disabled
      ),
      error: (
        /*fieldState*/
        ctx[4].error
      ),
      processFiles: (
        /*processFiles*/
        ctx[13]
      ),
      handleFileTooLarge: (
        /*handleFileTooLarge*/
        ctx[12]
      ),
      maximum: 1,
      fileSizeLimit: (
        /*MaxFileSize*/
        ctx[11]
      )
    }
  });
  coredropzone.$on(
    "change",
    /*handleChange*/
    ctx[14]
  );
  return {
    c() {
      create_component(coredropzone.$$.fragment);
    },
    m(target, anchor) {
      mount_component(coredropzone, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const coredropzone_changes = {};
      if (dirty & /*localFiles*/
      64)
        coredropzone_changes.value = /*localFiles*/
        ctx2[6];
      if (dirty & /*loading, fieldState*/
      144)
        coredropzone_changes.disabled = /*loading*/
        ctx2[7] || /*fieldState*/
        ctx2[4].disabled;
      if (dirty & /*fieldState*/
      16)
        coredropzone_changes.error = /*fieldState*/
        ctx2[4].error;
      coredropzone.$set(coredropzone_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(coredropzone.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(coredropzone.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(coredropzone, detaching);
    }
  };
}
function create_if_block(ctx) {
  let div0;
  let t;
  let div1;
  let progresscircle;
  let current;
  progresscircle = new ProgressCircle({});
  return {
    c() {
      div0 = element("div");
      t = space();
      div1 = element("div");
      create_component(progresscircle.$$.fragment);
      attr(div0, "class", "overlay svelte-1f67xpj");
      attr(div1, "class", "loading svelte-1f67xpj");
    },
    m(target, anchor) {
      insert(target, div0, anchor);
      insert(target, t, anchor);
      insert(target, div1, anchor);
      mount_component(progresscircle, div1, null);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(progresscircle.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(progresscircle.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div0);
        detach(t);
        detach(div1);
      }
      destroy_component(progresscircle);
    }
  };
}
function create_default_slot(ctx) {
  let div;
  let t;
  let current;
  let if_block0 = (
    /*fieldState*/
    ctx[4] && create_if_block_1(ctx)
  );
  let if_block1 = (
    /*loading*/
    ctx[7] && create_if_block()
  );
  return {
    c() {
      div = element("div");
      if (if_block0)
        if_block0.c();
      t = space();
      if (if_block1)
        if_block1.c();
      attr(div, "class", "content svelte-1f67xpj");
      toggle_class(
        div,
        "builder",
        /*$builderStore*/
        ctx[8].inBuilder
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block0)
        if_block0.m(div, null);
      append(div, t);
      if (if_block1)
        if_block1.m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*fieldState*/
        ctx2[4]
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty & /*fieldState*/
          16) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_1(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(div, t);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (
        /*loading*/
        ctx2[7]
      ) {
        if (if_block1) {
          if (dirty & /*loading*/
          128) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block();
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div, null);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if (!current || dirty & /*$builderStore*/
      256) {
        toggle_class(
          div,
          "builder",
          /*$builderStore*/
          ctx2[8].inBuilder
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
    }
  };
}
function create_fragment(ctx) {
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let current;
  function field_1_fieldState_binding(value) {
    ctx[19](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[20](value);
  }
  let field_1_props = {
    label: (
      /*label*/
      ctx[1]
    ),
    field: (
      /*field*/
      ctx[0]
    ),
    disabled: (
      /*disabled*/
      ctx[2]
    ),
    validation: (
      /*validation*/
      ctx[3]
    ),
    type: "s3upload",
    defaultValue: [],
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*fieldState*/
    ctx[4] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[4];
  }
  if (
    /*fieldApi*/
    ctx[5] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[5];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  return {
    c() {
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const field_1_changes = {};
      if (dirty & /*label*/
      2)
        field_1_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*field*/
      1)
        field_1_changes.field = /*field*/
        ctx2[0];
      if (dirty & /*disabled*/
      4)
        field_1_changes.disabled = /*disabled*/
        ctx2[2];
      if (dirty & /*validation*/
      8)
        field_1_changes.validation = /*validation*/
        ctx2[3];
      if (dirty & /*$$scope, $builderStore, loading, localFiles, fieldState*/
      268435920) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty & /*fieldState*/
      16) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[4];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty & /*fieldApi*/
      32) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[5];
        add_flush_callback(() => updating_fieldApi = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field_1, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $component;
  let $context;
  let $builderStore;
  component_subscribe($$self, builderStore, ($$value) => $$invalidate(8, $builderStore = $$value));
  let { datasourceId } = $$props;
  let { bucket } = $$props;
  let { key } = $$props;
  let { field } = $$props;
  let { label } = $$props;
  let { disabled = false } = $$props;
  let { validation } = $$props;
  let { onChange } = $$props;
  const context = getContext("context");
  component_subscribe($$self, context, (value) => $$invalidate(23, $context = value));
  let fieldState;
  let fieldApi;
  let localFiles = [];
  const { API, notificationStore, uploadStore } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(22, $component = value));
  const MaxFileSize = 1e9 * 5;
  let data;
  let loading = false;
  const handleFileTooLarge = () => {
    notificationStore.actions.warning("Files cannot exceed 5GB. Please try again with a smaller file.");
  };
  const processFiles = async (fileList) => {
    if ($builderStore.inBuilder) {
      return [];
    }
    return await new Promise((resolve) => {
      var _a;
      if (!(fileList == null ? void 0 : fileList.length)) {
        return [];
      }
      data = fileList[0];
      if (!((_a = data.type) == null ? void 0 : _a.startsWith("image"))) {
        resolve([{ name: data.name, type: data.type }]);
      }
      const reader = new FileReader();
      reader.addEventListener(
        "load",
        () => {
          resolve([
            {
              url: reader.result,
              name: data.name,
              type: data.type
            }
          ]);
        },
        false
      );
      reader.readAsDataURL(fileList[0]);
    });
  };
  const upload = async () => {
    const processedFileKey = processStringSync(key, $context);
    $$invalidate(7, loading = true);
    try {
      const res = await API.externalUpload(datasourceId, bucket, processedFileKey, data);
      notificationStore.actions.success("File uploaded successfully");
      $$invalidate(7, loading = false);
      return res;
    } catch (error) {
      notificationStore.actions.error(`Error uploading file: ${(error == null ? void 0 : error.message) || error}`);
      $$invalidate(7, loading = false);
    }
  };
  const handleChange = (e) => {
    $$invalidate(6, localFiles = e.detail);
    let files = cloneDeep(e.detail) || [];
    files.forEach((file) => {
      var _a;
      if ((_a = file.type) == null ? void 0 : _a.startsWith("image")) {
        delete file.url;
      }
    });
    const changed = fieldApi.setValue(files);
    if (onChange && changed) {
      onChange({ value: files });
    }
  };
  onMount(() => {
    uploadStore.actions.registerFileUpload($component.id, upload);
  });
  onDestroy(() => {
    uploadStore.actions.unregisterFileUpload($component.id);
  });
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(4, fieldState);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(5, fieldApi);
  }
  $$self.$$set = ($$props2) => {
    if ("datasourceId" in $$props2)
      $$invalidate(15, datasourceId = $$props2.datasourceId);
    if ("bucket" in $$props2)
      $$invalidate(16, bucket = $$props2.bucket);
    if ("key" in $$props2)
      $$invalidate(17, key = $$props2.key);
    if ("field" in $$props2)
      $$invalidate(0, field = $$props2.field);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("disabled" in $$props2)
      $$invalidate(2, disabled = $$props2.disabled);
    if ("validation" in $$props2)
      $$invalidate(3, validation = $$props2.validation);
    if ("onChange" in $$props2)
      $$invalidate(18, onChange = $$props2.onChange);
  };
  $$self.$$.update = () => {
    var _a;
    if ($$self.$$.dirty & /*fieldState*/
    16) {
      {
        if (!((_a = fieldState == null ? void 0 : fieldState.value) == null ? void 0 : _a.length)) {
          $$invalidate(6, localFiles = []);
        }
      }
    }
  };
  return [
    field,
    label,
    disabled,
    validation,
    fieldState,
    fieldApi,
    localFiles,
    loading,
    $builderStore,
    context,
    component,
    MaxFileSize,
    handleFileTooLarge,
    processFiles,
    handleChange,
    datasourceId,
    bucket,
    key,
    onChange,
    field_1_fieldState_binding,
    field_1_fieldApi_binding
  ];
}
class S3Upload extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      datasourceId: 15,
      bucket: 16,
      key: 17,
      field: 0,
      label: 1,
      disabled: 2,
      validation: 3,
      onChange: 18
    });
  }
}
export {
  S3Upload as default
};
