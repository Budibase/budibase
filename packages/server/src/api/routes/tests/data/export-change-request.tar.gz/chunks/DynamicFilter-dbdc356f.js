import { S as SvelteComponent, i as init, s as safe_not_equal, I as Icon, $ as Popover, bC as PopoverAlignment, e as element, a as space, c as create_component, b as attr, d as toggle_class, f as insert, g as append, m as mount_component, l as listen, k as transition_in, n as transition_out, o as detach, p as destroy_component, r as run_all, Y as createEventDispatcher, q as action_destroyer, af as clickOutside, z as group_outros, A as check_outros, h as is_function, W as binding_callbacks, N as ensure_array_like, y as empty, O as destroy_each, t as text, j as set_data, bB as Field, V as bubble, a0 as bind, a1 as add_flush_callback, v as component_subscribe, au as compute_slots, cc as shortid, X as setContext, w as onDestroy, cd as Portal, ap as Button, F as create_slot, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, Q as add_render_callback, R as create_bidirectional_transition, a3 as writable, ce as ActionButton, az as get_store_value, B as noop, b9 as construct_svelte_component, bp as createAPIClient, D as fetchData, an as Select_1, C as subscribe, cf as isJSBinding, cg as Constants, a7 as Input, ch as findHBSBlocks, aK as FieldType, a$ as ArrayOperator, ci as Layout, aJ as capitalise, u as getContext, c4 as processSearchFilters, bD as cloneDeep, bO as getValidOperatorsForType, aZ as UILogicalOperator, E as EmptyFilterOption, cj as FilterOperator, a5 as Body, x as buildQuery, ac as Modal, ck as BannedSearchTypes, cl as parseFilter, a4 as ModalContent } from "./index-a0738cd3.js";
import { D as DatePicker_1 } from "./DatePicker-7555af0b.js";
import { M as Multiselect } from "./Multiselect-7c6c2576.js";
import Button$1 from "./Button-55cd96fd.js";
import "./DatePicker-1e1fb6b9.js";
import "./phosphorIconLoader-f5abc73c.js";
function get_each_context$1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[22] = list[i];
  return child_ctx;
}
function create_if_block$5(ctx) {
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(
    /*options*/
    ctx[5]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$1(get_each_context$1(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*getOptionValue, options, value, onPick, getOptionLabel*/
      8417) {
        each_value = ensure_array_like(
          /*options*/
          ctx2[5]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$1(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$1(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_each_block$1(ctx) {
  let li;
  let span;
  let t0_value = (
    /*getOptionLabel*/
    ctx[6](
      /*option*/
      ctx[22]
    ) + ""
  );
  let t0;
  let t1;
  let div;
  let icon;
  let t2;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({ props: { name: "check", size: "S" } });
  function click_handler_1() {
    return (
      /*click_handler_1*/
      ctx[18](
        /*option*/
        ctx[22]
      )
    );
  }
  return {
    c() {
      li = element("li");
      span = element("span");
      t0 = text(t0_value);
      t1 = space();
      div = element("div");
      create_component(icon.$$.fragment);
      t2 = space();
      attr(span, "class", "spectrum-Menu-itemLabel svelte-g074q3");
      attr(div, "class", "check svelte-g074q3");
      attr(li, "class", "spectrum-Menu-item svelte-g074q3");
      attr(li, "role", "option");
      attr(li, "aria-selected", "true");
      attr(li, "tabindex", "0");
      toggle_class(
        li,
        "is-selected",
        /*getOptionValue*/
        ctx[7](
          /*option*/
          ctx[22]
        ) === /*value*/
        ctx[0]
      );
    },
    m(target, anchor) {
      insert(target, li, anchor);
      append(li, span);
      append(span, t0);
      append(li, t1);
      append(li, div);
      mount_component(icon, div, null);
      append(li, t2);
      current = true;
      if (!mounted) {
        dispose = listen(li, "click", click_handler_1);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if ((!current || dirty & /*getOptionLabel, options*/
      96) && t0_value !== (t0_value = /*getOptionLabel*/
      ctx[6](
        /*option*/
        ctx[22]
      ) + ""))
        set_data(t0, t0_value);
      if (!current || dirty & /*getOptionValue, options, value*/
      161) {
        toggle_class(
          li,
          "is-selected",
          /*getOptionValue*/
          ctx[7](
            /*option*/
            ctx[22]
          ) === /*value*/
          ctx[0]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(li);
      }
      destroy_component(icon);
      mounted = false;
      dispose();
    }
  };
}
function create_default_slot$7(ctx) {
  let div;
  let ul;
  let show_if = (
    /*options*/
    ctx[5] && Array.isArray(
      /*options*/
      ctx[5]
    )
  );
  let clickOutside_action;
  let current;
  let mounted;
  let dispose;
  let if_block = show_if && create_if_block$5(ctx);
  return {
    c() {
      div = element("div");
      ul = element("ul");
      if (if_block)
        if_block.c();
      attr(ul, "class", "spectrum-Menu");
      attr(ul, "role", "listbox");
      attr(div, "class", "popover-content svelte-g074q3");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, ul);
      if (if_block)
        if_block.m(ul, null);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(clickOutside_action = clickOutside.call(
          null,
          div,
          /*clickOutside_function*/
          ctx[19]
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty & /*options*/
      32)
        show_if = /*options*/
        ctx2[5] && Array.isArray(
          /*options*/
          ctx2[5]
        );
      if (show_if) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*options*/
          32) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$5(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(ul, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (clickOutside_action && is_function(clickOutside_action.update) && dirty & /*open*/
      256)
        clickOutside_action.update.call(
          null,
          /*clickOutside_function*/
          ctx2[19]
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block)
        if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function create_fragment$8(ctx) {
  let div1;
  let div0;
  let input;
  let input_value_value;
  let input_placeholder_value;
  let t0;
  let button;
  let icon;
  let t1;
  let popover;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({ props: { name: "caret-down", size: "S" } });
  popover = new Popover({
    props: {
      anchor: (
        /*anchor*/
        ctx[10]
      ),
      open: (
        /*open*/
        ctx[8]
      ),
      align: PopoverAlignment.Left,
      useAnchorWidth: true,
      $$slots: { default: [create_default_slot$7] },
      $$scope: { ctx }
    }
  });
  popover.$on(
    "close",
    /*close_handler*/
    ctx[20]
  );
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      input = element("input");
      t0 = space();
      button = element("button");
      create_component(icon.$$.fragment);
      t1 = space();
      create_component(popover.$$.fragment);
      attr(
        input,
        "id",
        /*id*/
        ctx[1]
      );
      attr(input, "type", "text");
      input.value = input_value_value = /*value*/
      ctx[0] || "";
      attr(input, "placeholder", input_placeholder_value = /*placeholder*/
      ctx[2] || "");
      input.disabled = /*disabled*/
      ctx[3];
      input.readOnly = /*readonly*/
      ctx[4];
      attr(input, "class", "spectrum-Textfield-input spectrum-InputGroup-input svelte-g074q3");
      attr(div0, "class", "spectrum-Textfield spectrum-InputGroup-textfield svelte-g074q3");
      toggle_class(
        div0,
        "is-disabled",
        /*disabled*/
        ctx[3]
      );
      toggle_class(
        div0,
        "is-focused",
        /*open*/
        ctx[8] || /*focus*/
        ctx[9]
      );
      attr(button, "class", "spectrum-Picker spectrum-Picker--sizeM spectrum-InputGroup-button");
      attr(button, "tabindex", "-1");
      attr(button, "aria-haspopup", "true");
      button.disabled = /*disabled*/
      ctx[3];
      attr(div1, "class", "spectrum-InputGroup svelte-g074q3");
      toggle_class(
        div1,
        "is-focused",
        /*open*/
        ctx[8] || /*focus*/
        ctx[9]
      );
      toggle_class(
        div1,
        "is-disabled",
        /*disabled*/
        ctx[3]
      );
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      append(div0, input);
      append(div1, t0);
      append(div1, button);
      mount_component(icon, button, null);
      ctx[17](div1);
      insert(target, t1, anchor);
      mount_component(popover, target, anchor);
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            input,
            "focus",
            /*focus_handler*/
            ctx[14]
          ),
          listen(
            input,
            "blur",
            /*blur_handler*/
            ctx[15]
          ),
          listen(
            input,
            "change",
            /*onType*/
            ctx[12]
          ),
          listen(
            button,
            "click",
            /*click_handler*/
            ctx[16]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (!current || dirty & /*id*/
      2) {
        attr(
          input,
          "id",
          /*id*/
          ctx2[1]
        );
      }
      if (!current || dirty & /*value*/
      1 && input_value_value !== (input_value_value = /*value*/
      ctx2[0] || "") && input.value !== input_value_value) {
        input.value = input_value_value;
      }
      if (!current || dirty & /*placeholder*/
      4 && input_placeholder_value !== (input_placeholder_value = /*placeholder*/
      ctx2[2] || "")) {
        attr(input, "placeholder", input_placeholder_value);
      }
      if (!current || dirty & /*disabled*/
      8) {
        input.disabled = /*disabled*/
        ctx2[3];
      }
      if (!current || dirty & /*readonly*/
      16) {
        input.readOnly = /*readonly*/
        ctx2[4];
      }
      if (!current || dirty & /*disabled*/
      8) {
        toggle_class(
          div0,
          "is-disabled",
          /*disabled*/
          ctx2[3]
        );
      }
      if (!current || dirty & /*open, focus*/
      768) {
        toggle_class(
          div0,
          "is-focused",
          /*open*/
          ctx2[8] || /*focus*/
          ctx2[9]
        );
      }
      if (!current || dirty & /*disabled*/
      8) {
        button.disabled = /*disabled*/
        ctx2[3];
      }
      if (!current || dirty & /*open, focus*/
      768) {
        toggle_class(
          div1,
          "is-focused",
          /*open*/
          ctx2[8] || /*focus*/
          ctx2[9]
        );
      }
      if (!current || dirty & /*disabled*/
      8) {
        toggle_class(
          div1,
          "is-disabled",
          /*disabled*/
          ctx2[3]
        );
      }
      const popover_changes = {};
      if (dirty & /*anchor*/
      1024)
        popover_changes.anchor = /*anchor*/
        ctx2[10];
      if (dirty & /*open*/
      256)
        popover_changes.open = /*open*/
        ctx2[8];
      if (dirty & /*$$scope, open, options, getOptionValue, value, getOptionLabel*/
      33554913) {
        popover_changes.$$scope = { dirty, ctx: ctx2 };
      }
      popover.$set(popover_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      transition_in(popover.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      transition_out(popover.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
        detach(t1);
      }
      destroy_component(icon);
      ctx[17](null);
      destroy_component(popover, detaching);
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance$8($$self, $$props, $$invalidate) {
  let { value = void 0 } = $$props;
  let { id = void 0 } = $$props;
  let { placeholder = "Choose an option or type" } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { options = [] } = $$props;
  let { getOptionLabel = (option) => `${option}` } = $$props;
  let { getOptionValue = (option) => `${option}` } = $$props;
  const dispatch = createEventDispatcher();
  let open = false;
  let focus = false;
  let anchor;
  const selectOption = (value2) => {
    dispatch("change", value2);
    $$invalidate(8, open = false);
  };
  const onType = (e) => {
    const value2 = e.currentTarget.value;
    dispatch("type", value2);
    selectOption(value2);
  };
  const onPick = (value2) => {
    dispatch("pick", value2);
    selectOption(value2);
  };
  const focus_handler = () => $$invalidate(9, focus = true);
  const blur_handler = () => {
    $$invalidate(9, focus = false);
    dispatch("blur");
  };
  const click_handler = () => $$invalidate(8, open = !open);
  function div1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      anchor = $$value;
      $$invalidate(10, anchor);
    });
  }
  const click_handler_1 = (option) => onPick(getOptionValue(option));
  const clickOutside_function = () => {
    $$invalidate(8, open = false);
  };
  const close_handler = () => $$invalidate(8, open = false);
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("id" in $$props2)
      $$invalidate(1, id = $$props2.id);
    if ("placeholder" in $$props2)
      $$invalidate(2, placeholder = $$props2.placeholder);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(4, readonly = $$props2.readonly);
    if ("options" in $$props2)
      $$invalidate(5, options = $$props2.options);
    if ("getOptionLabel" in $$props2)
      $$invalidate(6, getOptionLabel = $$props2.getOptionLabel);
    if ("getOptionValue" in $$props2)
      $$invalidate(7, getOptionValue = $$props2.getOptionValue);
  };
  return [
    value,
    id,
    placeholder,
    disabled,
    readonly,
    options,
    getOptionLabel,
    getOptionValue,
    open,
    focus,
    anchor,
    dispatch,
    onType,
    onPick,
    focus_handler,
    blur_handler,
    click_handler,
    div1_binding,
    click_handler_1,
    clickOutside_function,
    close_handler
  ];
}
class Combobox extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$8, create_fragment$8, safe_not_equal, {
      value: 0,
      id: 1,
      placeholder: 2,
      disabled: 3,
      readonly: 4,
      options: 5,
      getOptionLabel: 6,
      getOptionValue: 7
    });
  }
}
function create_default_slot$6(ctx) {
  let combobox;
  let current;
  combobox = new Combobox({
    props: {
      error: (
        /*error*/
        ctx[5]
      ),
      disabled: (
        /*disabled*/
        ctx[2]
      ),
      value: (
        /*value*/
        ctx[0]
      ),
      options: (
        /*options*/
        ctx[7]
      ),
      placeholder: (
        /*placeholder*/
        ctx[6]
      ),
      readonly: (
        /*readonly*/
        ctx[3]
      ),
      getOptionLabel: (
        /*getOptionLabel*/
        ctx[9]
      ),
      getOptionValue: (
        /*getOptionValue*/
        ctx[10]
      )
    }
  });
  combobox.$on(
    "change",
    /*onChange*/
    ctx[11]
  );
  combobox.$on(
    "pick",
    /*pick_handler*/
    ctx[12]
  );
  combobox.$on(
    "type",
    /*type_handler*/
    ctx[13]
  );
  combobox.$on(
    "blur",
    /*blur_handler*/
    ctx[14]
  );
  return {
    c() {
      create_component(combobox.$$.fragment);
    },
    m(target, anchor) {
      mount_component(combobox, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const combobox_changes = {};
      if (dirty & /*error*/
      32)
        combobox_changes.error = /*error*/
        ctx2[5];
      if (dirty & /*disabled*/
      4)
        combobox_changes.disabled = /*disabled*/
        ctx2[2];
      if (dirty & /*value*/
      1)
        combobox_changes.value = /*value*/
        ctx2[0];
      if (dirty & /*options*/
      128)
        combobox_changes.options = /*options*/
        ctx2[7];
      if (dirty & /*placeholder*/
      64)
        combobox_changes.placeholder = /*placeholder*/
        ctx2[6];
      if (dirty & /*readonly*/
      8)
        combobox_changes.readonly = /*readonly*/
        ctx2[3];
      if (dirty & /*getOptionLabel*/
      512)
        combobox_changes.getOptionLabel = /*getOptionLabel*/
        ctx2[9];
      if (dirty & /*getOptionValue*/
      1024)
        combobox_changes.getOptionValue = /*getOptionValue*/
        ctx2[10];
      combobox.$set(combobox_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(combobox.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(combobox.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(combobox, detaching);
    }
  };
}
function create_fragment$7(ctx) {
  let field;
  let current;
  field = new Field({
    props: {
      helpText: (
        /*helpText*/
        ctx[8]
      ),
      label: (
        /*label*/
        ctx[1]
      ),
      labelPosition: (
        /*labelPosition*/
        ctx[4]
      ),
      error: (
        /*error*/
        ctx[5]
      ),
      $$slots: { default: [create_default_slot$6] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(field.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const field_changes = {};
      if (dirty & /*helpText*/
      256)
        field_changes.helpText = /*helpText*/
        ctx2[8];
      if (dirty & /*label*/
      2)
        field_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*labelPosition*/
      16)
        field_changes.labelPosition = /*labelPosition*/
        ctx2[4];
      if (dirty & /*error*/
      32)
        field_changes.error = /*error*/
        ctx2[5];
      if (dirty & /*$$scope, error, disabled, value, options, placeholder, readonly, getOptionLabel, getOptionValue*/
      132845) {
        field_changes.$$scope = { dirty, ctx: ctx2 };
      }
      field.$set(field_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field, detaching);
    }
  };
}
function instance$7($$self, $$props, $$invalidate) {
  let { value = null } = $$props;
  let { label = void 0 } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { labelPosition = "above" } = $$props;
  let { error = null } = $$props;
  let { placeholder = "Choose an option or type" } = $$props;
  let { options = [] } = $$props;
  let { helpText = null } = $$props;
  let { getOptionLabel = (option) => extractProperty(option, "label") } = $$props;
  let { getOptionValue = (option) => extractProperty(option, "value") } = $$props;
  const dispatch = createEventDispatcher();
  const onChange = (e) => {
    $$invalidate(0, value = e.detail);
    dispatch("change", e.detail);
  };
  const extractProperty = (value2, property) => {
    if (value2 && typeof value2 === "object") {
      return value2[property];
    }
    return value2;
  };
  function pick_handler(event) {
    bubble.call(this, $$self, event);
  }
  function type_handler(event) {
    bubble.call(this, $$self, event);
  }
  function blur_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("disabled" in $$props2)
      $$invalidate(2, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(3, readonly = $$props2.readonly);
    if ("labelPosition" in $$props2)
      $$invalidate(4, labelPosition = $$props2.labelPosition);
    if ("error" in $$props2)
      $$invalidate(5, error = $$props2.error);
    if ("placeholder" in $$props2)
      $$invalidate(6, placeholder = $$props2.placeholder);
    if ("options" in $$props2)
      $$invalidate(7, options = $$props2.options);
    if ("helpText" in $$props2)
      $$invalidate(8, helpText = $$props2.helpText);
    if ("getOptionLabel" in $$props2)
      $$invalidate(9, getOptionLabel = $$props2.getOptionLabel);
    if ("getOptionValue" in $$props2)
      $$invalidate(10, getOptionValue = $$props2.getOptionValue);
  };
  return [
    value,
    label,
    disabled,
    readonly,
    labelPosition,
    error,
    placeholder,
    options,
    helpText,
    getOptionLabel,
    getOptionValue,
    onChange,
    pick_handler,
    type_handler,
    blur_handler
  ];
}
class Combobox_1 extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$7, create_fragment$7, safe_not_equal, {
      value: 0,
      label: 1,
      disabled: 2,
      readonly: 3,
      labelPosition: 4,
      error: 5,
      placeholder: 6,
      options: 7,
      helpText: 8,
      getOptionLabel: 9,
      getOptionValue: 10
    });
  }
}
function create_default_slot$5(ctx) {
  let multiselect;
  let updating_value;
  let updating_searchTerm;
  let current;
  function multiselect_value_binding(value) {
    ctx[20](value);
  }
  function multiselect_searchTerm_binding(value) {
    ctx[21](value);
  }
  let multiselect_props = {
    disabled: (
      /*disabled*/
      ctx[2]
    ),
    readonly: (
      /*readonly*/
      ctx[3]
    ),
    options: (
      /*options*/
      ctx[7]
    ),
    placeholder: (
      /*placeholder*/
      ctx[6]
    ),
    sort: (
      /*sort*/
      ctx[10]
    ),
    getOptionLabel: (
      /*getOptionLabel*/
      ctx[8]
    ),
    getOptionValue: (
      /*getOptionValue*/
      ctx[9]
    ),
    autoWidth: (
      /*autoWidth*/
      ctx[11]
    ),
    autocomplete: (
      /*autocomplete*/
      ctx[12]
    ),
    customPopoverHeight: (
      /*customPopoverHeight*/
      ctx[13]
    ),
    onOptionMouseenter: (
      /*onOptionMouseenter*/
      ctx[15]
    ),
    onOptionMouseleave: (
      /*onOptionMouseleave*/
      ctx[16]
    )
  };
  if (
    /*arrayValue*/
    ctx[17] !== void 0
  ) {
    multiselect_props.value = /*arrayValue*/
    ctx[17];
  }
  if (
    /*searchTerm*/
    ctx[0] !== void 0
  ) {
    multiselect_props.searchTerm = /*searchTerm*/
    ctx[0];
  }
  multiselect = new Multiselect({ props: multiselect_props });
  binding_callbacks.push(() => bind(multiselect, "value", multiselect_value_binding));
  binding_callbacks.push(() => bind(multiselect, "searchTerm", multiselect_searchTerm_binding));
  multiselect.$on(
    "change",
    /*onChange*/
    ctx[18]
  );
  multiselect.$on(
    "click",
    /*click_handler*/
    ctx[22]
  );
  return {
    c() {
      create_component(multiselect.$$.fragment);
    },
    m(target, anchor) {
      mount_component(multiselect, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const multiselect_changes = {};
      if (dirty & /*disabled*/
      4)
        multiselect_changes.disabled = /*disabled*/
        ctx2[2];
      if (dirty & /*readonly*/
      8)
        multiselect_changes.readonly = /*readonly*/
        ctx2[3];
      if (dirty & /*options*/
      128)
        multiselect_changes.options = /*options*/
        ctx2[7];
      if (dirty & /*placeholder*/
      64)
        multiselect_changes.placeholder = /*placeholder*/
        ctx2[6];
      if (dirty & /*sort*/
      1024)
        multiselect_changes.sort = /*sort*/
        ctx2[10];
      if (dirty & /*getOptionLabel*/
      256)
        multiselect_changes.getOptionLabel = /*getOptionLabel*/
        ctx2[8];
      if (dirty & /*getOptionValue*/
      512)
        multiselect_changes.getOptionValue = /*getOptionValue*/
        ctx2[9];
      if (dirty & /*autoWidth*/
      2048)
        multiselect_changes.autoWidth = /*autoWidth*/
        ctx2[11];
      if (dirty & /*autocomplete*/
      4096)
        multiselect_changes.autocomplete = /*autocomplete*/
        ctx2[12];
      if (dirty & /*customPopoverHeight*/
      8192)
        multiselect_changes.customPopoverHeight = /*customPopoverHeight*/
        ctx2[13];
      if (dirty & /*onOptionMouseenter*/
      32768)
        multiselect_changes.onOptionMouseenter = /*onOptionMouseenter*/
        ctx2[15];
      if (dirty & /*onOptionMouseleave*/
      65536)
        multiselect_changes.onOptionMouseleave = /*onOptionMouseleave*/
        ctx2[16];
      if (!updating_value && dirty & /*arrayValue*/
      131072) {
        updating_value = true;
        multiselect_changes.value = /*arrayValue*/
        ctx2[17];
        add_flush_callback(() => updating_value = false);
      }
      if (!updating_searchTerm && dirty & /*searchTerm*/
      1) {
        updating_searchTerm = true;
        multiselect_changes.searchTerm = /*searchTerm*/
        ctx2[0];
        add_flush_callback(() => updating_searchTerm = false);
      }
      multiselect.$set(multiselect_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(multiselect.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(multiselect.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(multiselect, detaching);
    }
  };
}
function create_fragment$6(ctx) {
  let field;
  let current;
  field = new Field({
    props: {
      helpText: (
        /*helpText*/
        ctx[14]
      ),
      label: (
        /*label*/
        ctx[1]
      ),
      labelPosition: (
        /*labelPosition*/
        ctx[4]
      ),
      error: (
        /*error*/
        ctx[5]
      ),
      $$slots: { default: [create_default_slot$5] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(field.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const field_changes = {};
      if (dirty & /*helpText*/
      16384)
        field_changes.helpText = /*helpText*/
        ctx2[14];
      if (dirty & /*label*/
      2)
        field_changes.label = /*label*/
        ctx2[1];
      if (dirty & /*labelPosition*/
      16)
        field_changes.labelPosition = /*labelPosition*/
        ctx2[4];
      if (dirty & /*error*/
      32)
        field_changes.error = /*error*/
        ctx2[5];
      if (dirty & /*$$scope, disabled, readonly, options, placeholder, sort, getOptionLabel, getOptionValue, autoWidth, autocomplete, customPopoverHeight, onOptionMouseenter, onOptionMouseleave, arrayValue, searchTerm*/
      17022925) {
        field_changes.$$scope = { dirty, ctx: ctx2 };
      }
      field.$set(field_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field, detaching);
    }
  };
}
function instance$6($$self, $$props, $$invalidate) {
  let arrayValue;
  let { value = [] } = $$props;
  let { label = void 0 } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { labelPosition = "above" } = $$props;
  let { error = void 0 } = $$props;
  let { placeholder = void 0 } = $$props;
  let { options = [] } = $$props;
  let { getOptionLabel = (option) => option } = $$props;
  let { getOptionValue = (option) => option } = $$props;
  let { sort = false } = $$props;
  let { autoWidth = false } = $$props;
  let { autocomplete = false } = $$props;
  let { searchTerm = void 0 } = $$props;
  let { customPopoverHeight = void 0 } = $$props;
  let { helpText = void 0 } = $$props;
  let { onOptionMouseenter = () => {
  } } = $$props;
  let { onOptionMouseleave = () => {
  } } = $$props;
  const dispatch = createEventDispatcher();
  const onChange = (e) => {
    $$invalidate(19, value = e.detail);
    dispatch("change", e.detail);
  };
  function multiselect_value_binding(value$1) {
    arrayValue = value$1;
    $$invalidate(17, arrayValue), $$invalidate(19, value);
  }
  function multiselect_searchTerm_binding(value2) {
    searchTerm = value2;
    $$invalidate(0, searchTerm);
  }
  function click_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(19, value = $$props2.value);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("disabled" in $$props2)
      $$invalidate(2, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(3, readonly = $$props2.readonly);
    if ("labelPosition" in $$props2)
      $$invalidate(4, labelPosition = $$props2.labelPosition);
    if ("error" in $$props2)
      $$invalidate(5, error = $$props2.error);
    if ("placeholder" in $$props2)
      $$invalidate(6, placeholder = $$props2.placeholder);
    if ("options" in $$props2)
      $$invalidate(7, options = $$props2.options);
    if ("getOptionLabel" in $$props2)
      $$invalidate(8, getOptionLabel = $$props2.getOptionLabel);
    if ("getOptionValue" in $$props2)
      $$invalidate(9, getOptionValue = $$props2.getOptionValue);
    if ("sort" in $$props2)
      $$invalidate(10, sort = $$props2.sort);
    if ("autoWidth" in $$props2)
      $$invalidate(11, autoWidth = $$props2.autoWidth);
    if ("autocomplete" in $$props2)
      $$invalidate(12, autocomplete = $$props2.autocomplete);
    if ("searchTerm" in $$props2)
      $$invalidate(0, searchTerm = $$props2.searchTerm);
    if ("customPopoverHeight" in $$props2)
      $$invalidate(13, customPopoverHeight = $$props2.customPopoverHeight);
    if ("helpText" in $$props2)
      $$invalidate(14, helpText = $$props2.helpText);
    if ("onOptionMouseenter" in $$props2)
      $$invalidate(15, onOptionMouseenter = $$props2.onOptionMouseenter);
    if ("onOptionMouseleave" in $$props2)
      $$invalidate(16, onOptionMouseleave = $$props2.onOptionMouseleave);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*value*/
    524288) {
      $$invalidate(17, arrayValue = value && !Array.isArray(value) ? [value] : value);
    }
  };
  return [
    searchTerm,
    label,
    disabled,
    readonly,
    labelPosition,
    error,
    placeholder,
    options,
    getOptionLabel,
    getOptionValue,
    sort,
    autoWidth,
    autocomplete,
    customPopoverHeight,
    helpText,
    onOptionMouseenter,
    onOptionMouseleave,
    arrayValue,
    onChange,
    value,
    multiselect_value_binding,
    multiselect_searchTerm_binding,
    click_handler
  ];
}
class Multiselect_1 extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$6, create_fragment$6, safe_not_equal, {
      value: 19,
      label: 1,
      disabled: 2,
      readonly: 3,
      labelPosition: 4,
      error: 5,
      placeholder: 6,
      options: 7,
      getOptionLabel: 8,
      getOptionValue: 9,
      sort: 10,
      autoWidth: 11,
      autocomplete: 12,
      searchTerm: 0,
      customPopoverHeight: 13,
      helpText: 14,
      onOptionMouseenter: 15,
      onOptionMouseleave: 16
    });
  }
}
const get_body_slot_changes = (dirty) => ({});
const get_body_slot_context = (ctx) => ({});
const get_buttons_slot_changes = (dirty) => ({});
const get_buttons_slot_context = (ctx) => ({});
const get_title_slot_changes = (dirty) => ({});
const get_title_slot_context = (ctx) => ({});
function create_if_block$4(ctx) {
  let portal;
  let current;
  portal = new Portal({
    props: {
      target: ".modal-container",
      $$slots: { default: [create_default_slot$4] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(portal.$$.fragment);
    },
    m(target, anchor) {
      mount_component(portal, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const portal_changes = {};
      if (dirty & /*$$scope, style, depth, $modal, $resizable, $$slots, title*/
      131693) {
        portal_changes.$$scope = { dirty, ctx: ctx2 };
      }
      portal.$set(portal_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(portal.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(portal.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(portal, detaching);
    }
  };
}
function create_else_block$2(ctx) {
  let div;
  let t_value = (
    /*title*/
    (ctx[0] || "Bindings") + ""
  );
  let t;
  return {
    c() {
      div = element("div");
      t = text(t_value);
      attr(div, "class", "text svelte-c271o1");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*title*/
      1 && t_value !== (t_value = /*title*/
      (ctx2[0] || "Bindings") + ""))
        set_data(t, t_value);
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block_2$2(ctx) {
  let current;
  const title_slot_template = (
    /*#slots*/
    ctx[15].title
  );
  const title_slot = create_slot(
    title_slot_template,
    ctx,
    /*$$scope*/
    ctx[17],
    get_title_slot_context
  );
  return {
    c() {
      if (title_slot)
        title_slot.c();
    },
    m(target, anchor) {
      if (title_slot) {
        title_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (title_slot) {
        if (title_slot.p && (!current || dirty & /*$$scope*/
        131072)) {
          update_slot_base(
            title_slot,
            title_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[17],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[17]
            ) : get_slot_changes(
              title_slot_template,
              /*$$scope*/
              ctx2[17],
              dirty,
              get_title_slot_changes
            ),
            get_title_slot_context
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(title_slot, local);
      current = true;
    },
    o(local) {
      transition_out(title_slot, local);
      current = false;
    },
    d(detaching) {
      if (title_slot)
        title_slot.d(detaching);
    }
  };
}
function create_default_slot_2$1(ctx) {
  let t;
  return {
    c() {
      t = text("Cancel");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_1$2(ctx) {
  let actionbutton;
  let current;
  actionbutton = new ActionButton({
    props: {
      size: "M",
      quiet: true,
      selected: (
        /*$modal*/
        ctx[3]
      ),
      $$slots: { default: [create_default_slot_1$2] },
      $$scope: { ctx }
    }
  });
  actionbutton.$on(
    "click",
    /*click_handler*/
    ctx[16]
  );
  return {
    c() {
      create_component(actionbutton.$$.fragment);
    },
    m(target, anchor) {
      mount_component(actionbutton, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const actionbutton_changes = {};
      if (dirty & /*$modal*/
      8)
        actionbutton_changes.selected = /*$modal*/
        ctx2[3];
      if (dirty & /*$$scope, $modal*/
      131080) {
        actionbutton_changes.$$scope = { dirty, ctx: ctx2 };
      }
      actionbutton.$set(actionbutton_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(actionbutton.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(actionbutton.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(actionbutton, detaching);
    }
  };
}
function create_default_slot_1$2(ctx) {
  let icon;
  let current;
  icon = new Icon({
    props: {
      name: (
        /*$modal*/
        ctx[3] ? "arrows-in-simple" : "arrows-out-simple"
      ),
      size: "S"
    }
  });
  return {
    c() {
      create_component(icon.$$.fragment);
    },
    m(target, anchor) {
      mount_component(icon, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const icon_changes = {};
      if (dirty & /*$modal*/
      8)
        icon_changes.name = /*$modal*/
        ctx2[3] ? "arrows-in-simple" : "arrows-out-simple";
      icon.$set(icon_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(icon, detaching);
    }
  };
}
function create_default_slot$4(ctx) {
  let div4;
  let div0;
  let div0_transition;
  let t0;
  let div3;
  let header;
  let current_block_type_index;
  let if_block0;
  let t1;
  let div1;
  let button;
  let t2;
  let t3;
  let t4;
  let t5;
  let div2;
  let div3_transition;
  let current;
  const if_block_creators = [create_if_block_2$2, create_else_block$2];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*$$slots*/
      ctx2[9].title
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block0 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  button = new Button({
    props: {
      secondary: true,
      quiet: true,
      $$slots: { default: [create_default_slot_2$1] },
      $$scope: { ctx }
    }
  });
  button.$on(
    "click",
    /*hide*/
    ctx[1]
  );
  const buttons_slot_template = (
    /*#slots*/
    ctx[15].buttons
  );
  const buttons_slot = create_slot(
    buttons_slot_template,
    ctx,
    /*$$scope*/
    ctx[17],
    get_buttons_slot_context
  );
  let if_block1 = (
    /*$resizable*/
    ctx[6] && create_if_block_1$2(ctx)
  );
  const body_slot_template = (
    /*#slots*/
    ctx[15].body
  );
  const body_slot = create_slot(
    body_slot_template,
    ctx,
    /*$$scope*/
    ctx[17],
    get_body_slot_context
  );
  return {
    c() {
      div4 = element("div");
      div0 = element("div");
      t0 = space();
      div3 = element("div");
      header = element("header");
      if_block0.c();
      t1 = space();
      div1 = element("div");
      create_component(button.$$.fragment);
      t2 = space();
      if (buttons_slot)
        buttons_slot.c();
      t3 = space();
      if (if_block1)
        if_block1.c();
      t4 = space();
      if (body_slot)
        body_slot.c();
      t5 = space();
      div2 = element("div");
      attr(div0, "class", "underlay svelte-c271o1");
      toggle_class(div0, "hidden", !/*$modal*/
      ctx[3]);
      attr(div1, "class", "buttons svelte-c271o1");
      attr(header, "class", "svelte-c271o1");
      attr(div2, "class", "overlay svelte-c271o1");
      toggle_class(
        div2,
        "hidden",
        /*$modal*/
        ctx[3] || /*depth*/
        ctx[2] === 0
      );
      attr(div3, "class", "drawer svelte-c271o1");
      attr(
        div3,
        "style",
        /*style*/
        ctx[5]
      );
      toggle_class(
        div3,
        "stacked",
        /*depth*/
        ctx[2] > 0
      );
      toggle_class(
        div3,
        "modal",
        /*$modal*/
        ctx[3]
      );
      attr(div4, "class", "drawer-wrapper");
    },
    m(target, anchor) {
      insert(target, div4, anchor);
      append(div4, div0);
      append(div4, t0);
      append(div4, div3);
      append(div3, header);
      if_blocks[current_block_type_index].m(header, null);
      append(header, t1);
      append(header, div1);
      mount_component(button, div1, null);
      append(div1, t2);
      if (buttons_slot) {
        buttons_slot.m(div1, null);
      }
      append(div1, t3);
      if (if_block1)
        if_block1.m(div1, null);
      append(div3, t4);
      if (body_slot) {
        body_slot.m(div3, null);
      }
      append(div3, t5);
      append(div3, div2);
      current = true;
    },
    p(ctx2, dirty) {
      if (!current || dirty & /*$modal*/
      8) {
        toggle_class(div0, "hidden", !/*$modal*/
        ctx2[3]);
      }
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block0 = if_blocks[current_block_type_index];
        if (!if_block0) {
          if_block0 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block0.c();
        } else {
          if_block0.p(ctx2, dirty);
        }
        transition_in(if_block0, 1);
        if_block0.m(header, t1);
      }
      const button_changes = {};
      if (dirty & /*$$scope*/
      131072) {
        button_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button.$set(button_changes);
      if (buttons_slot) {
        if (buttons_slot.p && (!current || dirty & /*$$scope*/
        131072)) {
          update_slot_base(
            buttons_slot,
            buttons_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[17],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[17]
            ) : get_slot_changes(
              buttons_slot_template,
              /*$$scope*/
              ctx2[17],
              dirty,
              get_buttons_slot_changes
            ),
            get_buttons_slot_context
          );
        }
      }
      if (
        /*$resizable*/
        ctx2[6]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty & /*$resizable*/
          64) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_1$2(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div1, null);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if (body_slot) {
        if (body_slot.p && (!current || dirty & /*$$scope*/
        131072)) {
          update_slot_base(
            body_slot,
            body_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[17],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[17]
            ) : get_slot_changes(
              body_slot_template,
              /*$$scope*/
              ctx2[17],
              dirty,
              get_body_slot_changes
            ),
            get_body_slot_context
          );
        }
      }
      if (!current || dirty & /*$modal, depth*/
      12) {
        toggle_class(
          div2,
          "hidden",
          /*$modal*/
          ctx2[3] || /*depth*/
          ctx2[2] === 0
        );
      }
      if (!current || dirty & /*style*/
      32) {
        attr(
          div3,
          "style",
          /*style*/
          ctx2[5]
        );
      }
      if (!current || dirty & /*depth*/
      4) {
        toggle_class(
          div3,
          "stacked",
          /*depth*/
          ctx2[2] > 0
        );
      }
      if (!current || dirty & /*$modal*/
      8) {
        toggle_class(
          div3,
          "modal",
          /*$modal*/
          ctx2[3]
        );
      }
    },
    i(local) {
      if (current)
        return;
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div0_transition)
            div0_transition = create_bidirectional_transition(
              div0,
              /*drawerFade*/
              ctx[8],
              {},
              true
            );
          div0_transition.run(1);
        });
      }
      transition_in(if_block0);
      transition_in(button.$$.fragment, local);
      transition_in(buttons_slot, local);
      transition_in(if_block1);
      transition_in(body_slot, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div3_transition)
            div3_transition = create_bidirectional_transition(
              div3,
              /*drawerSlide*/
              ctx[7],
              {},
              true
            );
          div3_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      if (local) {
        if (!div0_transition)
          div0_transition = create_bidirectional_transition(
            div0,
            /*drawerFade*/
            ctx[8],
            {},
            false
          );
        div0_transition.run(0);
      }
      transition_out(if_block0);
      transition_out(button.$$.fragment, local);
      transition_out(buttons_slot, local);
      transition_out(if_block1);
      transition_out(body_slot, local);
      if (local) {
        if (!div3_transition)
          div3_transition = create_bidirectional_transition(
            div3,
            /*drawerSlide*/
            ctx[7],
            {},
            false
          );
        div3_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div4);
      }
      if (detaching && div0_transition)
        div0_transition.end();
      if_blocks[current_block_type_index].d();
      destroy_component(button);
      if (buttons_slot)
        buttons_slot.d(detaching);
      if (if_block1)
        if_block1.d();
      if (body_slot)
        body_slot.d(detaching);
      if (detaching && div3_transition)
        div3_transition.end();
    }
  };
}
function create_fragment$5(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*visible*/
    ctx[4] && create_if_block$4(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (
        /*visible*/
        ctx2[4]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*visible*/
          16) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$4(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
const drawerContainer = "drawer-container";
const openDrawers = writable([]);
const modal = writable(false);
const resizable = writable(true);
const drawerLeft = writable(null);
const drawerWidth = writable(null);
let observer;
const observe = () => {
  const target = document.getElementsByClassName(drawerContainer)[0];
  if (observer || !target) {
    return;
  }
  observer = new ResizeObserver((entries) => {
    if (!(entries == null ? void 0 : entries[0])) {
      return;
    }
    const bounds2 = entries[0].target.getBoundingClientRect();
    drawerLeft.set(bounds2.left);
    drawerWidth.set(bounds2.width);
  });
  observer.observe(target);
  const bounds = target.getBoundingClientRect();
  drawerLeft.set(bounds.left);
  drawerWidth.set(bounds.width);
};
const unobserve = () => {
  if (get_store_value(openDrawers).length) {
    return;
  }
  observer == null ? void 0 : observer.disconnect();
  observer = null;
  modal.set(false);
  resizable.set(true);
  drawerLeft.set(null);
  drawerWidth.set(null);
};
const spacing = 11;
function instance$5($$self, $$props, $$invalidate) {
  let depth;
  let style;
  let $modal;
  let $drawerWidth;
  let $drawerLeft;
  let $openDrawers;
  let $resizable;
  component_subscribe($$self, modal, ($$value) => $$invalidate(3, $modal = $$value));
  component_subscribe($$self, drawerWidth, ($$value) => $$invalidate(12, $drawerWidth = $$value));
  component_subscribe($$self, drawerLeft, ($$value) => $$invalidate(13, $drawerLeft = $$value));
  component_subscribe($$self, openDrawers, ($$value) => $$invalidate(14, $openDrawers = $$value));
  component_subscribe($$self, resizable, ($$value) => $$invalidate(6, $resizable = $$value));
  let { $$slots: slots = {}, $$scope } = $$props;
  const $$slots = compute_slots(slots);
  let { title = "" } = $$props;
  let { forceModal = false } = $$props;
  const dispatch = createEventDispatcher();
  let visible = false;
  let drawerId = shortid.generate();
  const getStyle = (depth2, left, width, modal2) => {
    let style2 = `
      --scale-factor: ${getScaleFactor(depth2)};
      --spacing: ${spacing}px;
    `;
    if (modal2 || left == null || width == null) {
      return style2;
    }
    return `
      ${style2}
      left: ${left + spacing}px;
      width: ${width - 2 * spacing}px;
    `;
  };
  function show() {
    if (visible) {
      return;
    }
    if (forceModal) {
      modal.set(true);
      resizable.set(false);
    }
    observe();
    $$invalidate(4, visible = true);
    dispatch("drawerShow", drawerId);
    openDrawers.update((state) => [...state, drawerId]);
  }
  function hide() {
    if (!visible) {
      return;
    }
    $$invalidate(4, visible = false);
    dispatch("drawerHide", drawerId);
    openDrawers.update((state) => state.filter((id) => id !== drawerId));
    unobserve();
  }
  setContext("drawer", { hide, show, modal, resizable });
  const easeInOutQuad = (x) => {
    return x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2;
  };
  const drawerSlide = () => {
    return {
      duration: 260,
      css: (t) => {
        const f = easeInOutQuad(t);
        const yOffset = (1 - f) * 200;
        return `
          transform: translateY(calc(${yOffset}px - 800px * (1 - var(--scale-factor))));
          opacity: ${f};
        `;
      }
    };
  };
  const drawerFade = () => {
    return {
      duration: 260,
      css: (t) => {
        return `opacity: ${easeInOutQuad(t)};`;
      }
    };
  };
  const getScaleFactor = (depth2) => {
    const lim = 1 - 1 / (depth2 * depth2 + 1);
    return 1 - lim * 0.1;
  };
  onDestroy(() => {
    if (visible) {
      hide();
    }
  });
  const click_handler = () => modal.set(!$modal);
  $$self.$$set = ($$props2) => {
    if ("title" in $$props2)
      $$invalidate(0, title = $$props2.title);
    if ("forceModal" in $$props2)
      $$invalidate(10, forceModal = $$props2.forceModal);
    if ("$$scope" in $$props2)
      $$invalidate(17, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$openDrawers*/
    16384) {
      $$invalidate(2, depth = $openDrawers.length - $openDrawers.indexOf(drawerId) - 1);
    }
    if ($$self.$$.dirty & /*depth, $drawerLeft, $drawerWidth, $modal*/
    12300) {
      $$invalidate(5, style = getStyle(depth, $drawerLeft, $drawerWidth, $modal));
    }
  };
  return [
    title,
    hide,
    depth,
    $modal,
    visible,
    style,
    $resizable,
    drawerSlide,
    drawerFade,
    $$slots,
    forceModal,
    show,
    $drawerWidth,
    $drawerLeft,
    $openDrawers,
    slots,
    click_handler,
    $$scope
  ];
}
class Drawer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$5, create_fragment$5, safe_not_equal, {
      title: 0,
      forceModal: 10,
      show: 11,
      hide: 1
    });
  }
  get show() {
    return this.$$.ctx[11];
  }
  get hide() {
    return this.$$.ctx[1];
  }
}
function create_fragment$4(ctx) {
  let div;
  let switch_instance;
  let current;
  var switch_value = (
    /*component*/
    ctx[2]
  );
  function switch_props(ctx2, dirty) {
    return {
      props: {
        value: (
          /*value*/
          ctx2[0]
        ),
        autocomplete: true,
        options: (
          /*options*/
          ctx2[3]
        ),
        getOptionLabel: func$1,
        getOptionValue: func_1$1,
        disabled: (
          /*disabled*/
          ctx2[1]
        )
      }
    };
  }
  if (switch_value) {
    switch_instance = construct_svelte_component(switch_value, switch_props(ctx));
    switch_instance.$on(
      "change",
      /*change_handler*/
      ctx[8]
    );
  }
  return {
    c() {
      div = element("div");
      if (switch_instance)
        create_component(switch_instance.$$.fragment);
      attr(div, "class", "user-control");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (switch_instance)
        mount_component(switch_instance, div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (dirty & /*component*/
      4 && switch_value !== (switch_value = /*component*/
      ctx2[2])) {
        if (switch_instance) {
          group_outros();
          const old_component = switch_instance;
          transition_out(old_component.$$.fragment, 1, 0, () => {
            destroy_component(old_component, 1);
          });
          check_outros();
        }
        if (switch_value) {
          switch_instance = construct_svelte_component(switch_value, switch_props(ctx2));
          switch_instance.$on(
            "change",
            /*change_handler*/
            ctx2[8]
          );
          create_component(switch_instance.$$.fragment);
          transition_in(switch_instance.$$.fragment, 1);
          mount_component(switch_instance, div, null);
        } else {
          switch_instance = null;
        }
      } else if (switch_value) {
        const switch_instance_changes = {};
        if (dirty & /*value*/
        1)
          switch_instance_changes.value = /*value*/
          ctx2[0];
        if (dirty & /*options*/
        8)
          switch_instance_changes.options = /*options*/
          ctx2[3];
        if (dirty & /*disabled*/
        2)
          switch_instance_changes.disabled = /*disabled*/
          ctx2[1];
        switch_instance.$set(switch_instance_changes);
      }
    },
    i(local) {
      if (current)
        return;
      if (switch_instance)
        transition_in(switch_instance.$$.fragment, local);
      current = true;
    },
    o(local) {
      if (switch_instance)
        transition_out(switch_instance.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (switch_instance)
        destroy_component(switch_instance);
    }
  };
}
const func$1 = (option) => option.email;
const func_1$1 = (option) => option._id;
function instance$4($$self, $$props, $$invalidate) {
  let fetch;
  let options;
  let component;
  let $fetch, $$unsubscribe_fetch = noop, $$subscribe_fetch = () => ($$unsubscribe_fetch(), $$unsubscribe_fetch = subscribe(fetch, ($$value) => $$invalidate(7, $fetch = $$value)), fetch);
  $$self.$$.on_destroy.push(() => $$unsubscribe_fetch());
  let { API = createAPIClient() } = $$props;
  let { value = null } = $$props;
  let { disabled } = $$props;
  let { multiselect = false } = $$props;
  function change_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("API" in $$props2)
      $$invalidate(5, API = $$props2.API);
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("disabled" in $$props2)
      $$invalidate(1, disabled = $$props2.disabled);
    if ("multiselect" in $$props2)
      $$invalidate(6, multiselect = $$props2.multiselect);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*API*/
    32) {
      $$subscribe_fetch($$invalidate(4, fetch = fetchData({
        API,
        datasource: { type: "user" },
        options: { limit: 100 }
      })));
    }
    if ($$self.$$.dirty & /*$fetch*/
    128) {
      $$invalidate(3, options = $fetch.rows);
    }
    if ($$self.$$.dirty & /*multiselect*/
    64) {
      $$invalidate(2, component = multiselect ? Multiselect_1 : Select_1);
    }
  };
  return [
    value,
    disabled,
    component,
    options,
    fetch,
    API,
    multiselect,
    $fetch,
    change_handler
  ];
}
class FilterUsers extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$4, create_fragment$4, safe_not_equal, {
      API: 5,
      value: 0,
      disabled: 1,
      multiselect: 6
    });
  }
}
function create_default_slot$3(ctx) {
  let t;
  return {
    c() {
      t = text("Confirm");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_buttons_slot$1(ctx) {
  let button;
  let current;
  button = new Button({
    props: {
      cta: true,
      slot: "buttons",
      $$slots: { default: [create_default_slot$3] },
      $$scope: { ctx }
    }
  });
  button.$on(
    "click",
    /*click_handler*/
    ctx[23]
  );
  return {
    c() {
      create_component(button.$$.fragment);
    },
    m(target, anchor) {
      mount_component(button, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const button_changes = {};
      if (dirty[1] & /*$$scope*/
      32) {
        button_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button.$set(button_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(button.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(button.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(button, detaching);
    }
  };
}
function create_body_slot$1(ctx) {
  let switch_instance;
  let switch_instance_anchor;
  let current;
  var switch_value = (
    /*panel*/
    ctx[4]
  );
  function switch_props(ctx2, dirty) {
    return {
      props: {
        slot: "body",
        value: (
          /*drawerValue*/
          ctx2[9]
        ),
        allowJS: true,
        allowHelpers: true,
        allowHBS: true,
        bindings: (
          /*bindings*/
          ctx2[2]
        ),
        context: (
          /*evaluationContext*/
          ctx2[6]
        )
      }
    };
  }
  if (switch_value) {
    switch_instance = construct_svelte_component(switch_value, switch_props(ctx));
    switch_instance.$on(
      "change",
      /*drawerOnChange*/
      ctx[16]
    );
  }
  return {
    c() {
      if (switch_instance)
        create_component(switch_instance.$$.fragment);
      switch_instance_anchor = empty();
    },
    m(target, anchor) {
      if (switch_instance)
        mount_component(switch_instance, target, anchor);
      insert(target, switch_instance_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*panel*/
      16 && switch_value !== (switch_value = /*panel*/
      ctx2[4])) {
        if (switch_instance) {
          group_outros();
          const old_component = switch_instance;
          transition_out(old_component.$$.fragment, 1, 0, () => {
            destroy_component(old_component, 1);
          });
          check_outros();
        }
        if (switch_value) {
          switch_instance = construct_svelte_component(switch_value, switch_props(ctx2));
          switch_instance.$on(
            "change",
            /*drawerOnChange*/
            ctx2[16]
          );
          create_component(switch_instance.$$.fragment);
          transition_in(switch_instance.$$.fragment, 1);
          mount_component(switch_instance, switch_instance_anchor.parentNode, switch_instance_anchor);
        } else {
          switch_instance = null;
        }
      } else if (switch_value) {
        const switch_instance_changes = {};
        if (dirty[0] & /*drawerValue*/
        512)
          switch_instance_changes.value = /*drawerValue*/
          ctx2[9];
        if (dirty[0] & /*bindings*/
        4)
          switch_instance_changes.bindings = /*bindings*/
          ctx2[2];
        if (dirty[0] & /*evaluationContext*/
        64)
          switch_instance_changes.context = /*evaluationContext*/
          ctx2[6];
        switch_instance.$set(switch_instance_changes);
      }
    },
    i(local) {
      if (current)
        return;
      if (switch_instance)
        transition_in(switch_instance.$$.fragment, local);
      current = true;
    },
    o(local) {
      if (switch_instance)
        transition_out(switch_instance.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(switch_instance_anchor);
      }
      if (switch_instance)
        destroy_component(switch_instance, detaching);
    }
  };
}
function create_else_block$1(ctx) {
  let div;
  let show_if;
  let show_if_1;
  let current_block_type_index;
  let if_block;
  let current;
  const if_block_creators = [
    create_if_block_2$1,
    create_if_block_3$1,
    create_if_block_4$1,
    create_if_block_5$1,
    create_if_block_6,
    create_if_block_7,
    create_else_block_1$1
  ];
  const if_blocks = [];
  function select_block_type_1(ctx2, dirty) {
    if (dirty[0] & /*filter*/
    1)
      show_if = null;
    if (dirty[0] & /*filter*/
    1)
      show_if_1 = null;
    if (show_if == null)
      show_if = !![
        FieldType.STRING,
        FieldType.LONGFORM,
        FieldType.NUMBER,
        FieldType.BIGINT,
        FieldType.FORMULA,
        FieldType.AI,
        FieldType.BARCODEQR
      ].includes(
        /*filter*/
        ctx2[0].type
      );
    if (show_if)
      return 0;
    if (
      /*filter*/
      ctx2[0].type === FieldType.ARRAY || /*filter*/
      ctx2[0].type === FieldType.OPTIONS && /*filter*/
      ctx2[0].operator === ArrayOperator.ONE_OF
    )
      return 1;
    if (
      /*filter*/
      ctx2[0].type === FieldType.OPTIONS
    )
      return 2;
    if (
      /*filter*/
      ctx2[0].type === FieldType.BOOLEAN
    )
      return 3;
    if (
      /*filter*/
      ctx2[0].type === FieldType.DATETIME
    )
      return 4;
    if (show_if_1 == null)
      show_if_1 = !![FieldType.BB_REFERENCE, FieldType.BB_REFERENCE_SINGLE].includes(
        /*filter*/
        ctx2[0].type
      );
    if (show_if_1)
      return 5;
    return 6;
  }
  current_block_type_index = select_block_type_1(ctx, [-1, -1]);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      div = element("div");
      if_block.c();
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_1(ctx2, dirty);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div, null);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
    }
  };
}
function create_if_block_1$1(ctx) {
  let input;
  let current;
  input = new Input({
    props: {
      disabled: (
        /*filter*/
        ctx[0].noValue
      ),
      readonly: (
        /*isJS*/
        ctx[11]
      ),
      value: (
        /*isJS*/
        ctx[11] ? "(JavaScript function)" : (
          /*readableValue*/
          ctx[8]
        )
      )
    }
  });
  input.$on(
    "change",
    /*onChange*/
    ctx[17]
  );
  return {
    c() {
      create_component(input.$$.fragment);
    },
    m(target, anchor) {
      mount_component(input, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const input_changes = {};
      if (dirty[0] & /*filter*/
      1)
        input_changes.disabled = /*filter*/
        ctx2[0].noValue;
      if (dirty[0] & /*isJS*/
      2048)
        input_changes.readonly = /*isJS*/
        ctx2[11];
      if (dirty[0] & /*isJS, readableValue*/
      2304)
        input_changes.value = /*isJS*/
        ctx2[11] ? "(JavaScript function)" : (
          /*readableValue*/
          ctx2[8]
        );
      input.$set(input_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(input.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(input.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(input, detaching);
    }
  };
}
function create_else_block_1$1(ctx) {
  let input;
  let current;
  input = new Input({ props: { disabled: true } });
  return {
    c() {
      create_component(input.$$.fragment);
    },
    m(target, anchor) {
      mount_component(input, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(input.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(input.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(input, detaching);
    }
  };
}
function create_if_block_7(ctx) {
  let filterusers;
  let current;
  filterusers = new FilterUsers({
    props: {
      multiselect: [
        /*OperatorOptions*/
        ctx[12].In.value,
        /*OperatorOptions*/
        ctx[12].ContainsAny.value
      ].includes(
        /*filter*/
        ctx[0].operator
      ),
      disabled: (
        /*filter*/
        ctx[0].noValue
      ),
      value: (
        /*readableValue*/
        ctx[8]
      )
    }
  });
  filterusers.$on(
    "change",
    /*onChange*/
    ctx[17]
  );
  return {
    c() {
      create_component(filterusers.$$.fragment);
    },
    m(target, anchor) {
      mount_component(filterusers, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const filterusers_changes = {};
      if (dirty[0] & /*filter*/
      1)
        filterusers_changes.multiselect = [
          /*OperatorOptions*/
          ctx2[12].In.value,
          /*OperatorOptions*/
          ctx2[12].ContainsAny.value
        ].includes(
          /*filter*/
          ctx2[0].operator
        );
      if (dirty[0] & /*filter*/
      1)
        filterusers_changes.disabled = /*filter*/
        ctx2[0].noValue;
      if (dirty[0] & /*readableValue*/
      256)
        filterusers_changes.value = /*readableValue*/
        ctx2[8];
      filterusers.$set(filterusers_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(filterusers.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(filterusers.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(filterusers, detaching);
    }
  };
}
function create_if_block_6(ctx) {
  var _a, _b;
  let datepicker;
  let current;
  datepicker = new DatePicker_1({
    props: {
      disabled: (
        /*filter*/
        ctx[0].noValue
      ),
      enableTime: !/*getSchema*/
      ((_a = ctx[15](
        /*filter*/
        ctx[0]
      )) == null ? void 0 : _a.dateOnly),
      timeOnly: (
        /*getSchema*/
        (_b = ctx[15](
          /*filter*/
          ctx[0]
        )) == null ? void 0 : _b.timeOnly
      ),
      value: (
        /*readableValue*/
        ctx[8]
      )
    }
  });
  datepicker.$on(
    "change",
    /*onChange*/
    ctx[17]
  );
  return {
    c() {
      create_component(datepicker.$$.fragment);
    },
    m(target, anchor) {
      mount_component(datepicker, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2, _b2;
      const datepicker_changes = {};
      if (dirty[0] & /*filter*/
      1)
        datepicker_changes.disabled = /*filter*/
        ctx2[0].noValue;
      if (dirty[0] & /*filter*/
      1)
        datepicker_changes.enableTime = !/*getSchema*/
        ((_a2 = ctx2[15](
          /*filter*/
          ctx2[0]
        )) == null ? void 0 : _a2.dateOnly);
      if (dirty[0] & /*filter*/
      1)
        datepicker_changes.timeOnly = /*getSchema*/
        (_b2 = ctx2[15](
          /*filter*/
          ctx2[0]
        )) == null ? void 0 : _b2.timeOnly;
      if (dirty[0] & /*readableValue*/
      256)
        datepicker_changes.value = /*readableValue*/
        ctx2[8];
      datepicker.$set(datepicker_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(datepicker.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(datepicker.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(datepicker, detaching);
    }
  };
}
function create_if_block_5$1(ctx) {
  let combobox;
  let current;
  combobox = new Combobox_1({
    props: {
      disabled: (
        /*filter*/
        ctx[0].noValue
      ),
      options: [{ label: "True", value: "true" }, { label: "False", value: "false" }],
      value: (
        /*readableValue*/
        ctx[8]
      )
    }
  });
  combobox.$on(
    "change",
    /*onChange*/
    ctx[17]
  );
  return {
    c() {
      create_component(combobox.$$.fragment);
    },
    m(target, anchor) {
      mount_component(combobox, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const combobox_changes = {};
      if (dirty[0] & /*filter*/
      1)
        combobox_changes.disabled = /*filter*/
        ctx2[0].noValue;
      if (dirty[0] & /*readableValue*/
      256)
        combobox_changes.value = /*readableValue*/
        ctx2[8];
      combobox.$set(combobox_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(combobox.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(combobox.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(combobox, detaching);
    }
  };
}
function create_if_block_4$1(ctx) {
  let combobox;
  let current;
  combobox = new Combobox_1({
    props: {
      disabled: (
        /*filter*/
        ctx[0].noValue
      ),
      options: (
        /*getFieldOptions*/
        ctx[14](
          /*filter*/
          ctx[0].field
        )
      ),
      value: (
        /*readableValue*/
        ctx[8]
      )
    }
  });
  combobox.$on(
    "change",
    /*onChange*/
    ctx[17]
  );
  return {
    c() {
      create_component(combobox.$$.fragment);
    },
    m(target, anchor) {
      mount_component(combobox, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const combobox_changes = {};
      if (dirty[0] & /*filter*/
      1)
        combobox_changes.disabled = /*filter*/
        ctx2[0].noValue;
      if (dirty[0] & /*filter*/
      1)
        combobox_changes.options = /*getFieldOptions*/
        ctx2[14](
          /*filter*/
          ctx2[0].field
        );
      if (dirty[0] & /*readableValue*/
      256)
        combobox_changes.value = /*readableValue*/
        ctx2[8];
      combobox.$set(combobox_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(combobox.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(combobox.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(combobox, detaching);
    }
  };
}
function create_if_block_3$1(ctx) {
  let multiselect;
  let current;
  multiselect = new Multiselect_1({
    props: {
      disabled: (
        /*filter*/
        ctx[0].noValue
      ),
      options: (
        /*getFieldOptions*/
        ctx[14](
          /*filter*/
          ctx[0].field
        )
      ),
      value: (
        /*readableValue*/
        ctx[8]
      )
    }
  });
  multiselect.$on(
    "change",
    /*onChange*/
    ctx[17]
  );
  return {
    c() {
      create_component(multiselect.$$.fragment);
    },
    m(target, anchor) {
      mount_component(multiselect, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const multiselect_changes = {};
      if (dirty[0] & /*filter*/
      1)
        multiselect_changes.disabled = /*filter*/
        ctx2[0].noValue;
      if (dirty[0] & /*filter*/
      1)
        multiselect_changes.options = /*getFieldOptions*/
        ctx2[14](
          /*filter*/
          ctx2[0].field
        );
      if (dirty[0] & /*readableValue*/
      256)
        multiselect_changes.value = /*readableValue*/
        ctx2[8];
      multiselect.$set(multiselect_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(multiselect.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(multiselect.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(multiselect, detaching);
    }
  };
}
function create_if_block_2$1(ctx) {
  let input;
  let current;
  input = new Input({
    props: {
      disabled: (
        /*filter*/
        ctx[0].noValue
      ),
      value: (
        /*readableValue*/
        ctx[8]
      )
    }
  });
  input.$on(
    "change",
    /*onChange*/
    ctx[17]
  );
  return {
    c() {
      create_component(input.$$.fragment);
    },
    m(target, anchor) {
      mount_component(input, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const input_changes = {};
      if (dirty[0] & /*filter*/
      1)
        input_changes.disabled = /*filter*/
        ctx2[0].noValue;
      if (dirty[0] & /*readableValue*/
      256)
        input_changes.value = /*readableValue*/
        ctx2[8];
      input.$set(input_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(input.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(input.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(input, detaching);
    }
  };
}
function create_if_block$3(ctx) {
  let div;
  let icon;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({
    props: {
      size: "S",
      weight: "fill",
      name: "lightning"
    }
  });
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      attr(div, "class", "icon svelte-u5a0ap");
      toggle_class(
        div,
        "binding",
        /*filter*/
        ctx[0].valueType === "Binding"
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      current = true;
      if (!mounted) {
        dispose = listen(
          div,
          "click",
          /*click_handler_1*/
          ctx[27]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (!current || dirty[0] & /*filter*/
      1) {
        toggle_class(
          div,
          "binding",
          /*filter*/
          ctx2[0].valueType === "Binding"
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
      mounted = false;
      dispose();
    }
  };
}
function create_fragment$3(ctx) {
  let div3;
  let drawer;
  let t0;
  let div2;
  let div0;
  let current_block_type_index;
  let if_block0;
  let t1;
  let div1;
  let current;
  let drawer_props = {
    title: (
      /*drawerTitle*/
      ctx[5] || /*filter*/
      ctx[0].field
    ),
    forceModal: true,
    $$slots: {
      body: [create_body_slot$1],
      buttons: [create_buttons_slot$1]
    },
    $$scope: { ctx }
  };
  drawer = new Drawer({ props: drawer_props });
  ctx[24](drawer);
  drawer.$on(
    "drawerHide",
    /*drawerHide_handler*/
    ctx[25]
  );
  drawer.$on(
    "drawerShow",
    /*drawerShow_handler*/
    ctx[26]
  );
  const if_block_creators = [create_if_block_1$1, create_else_block$1];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*filter*/
      ctx2[0].valueType === /*FilterValueType*/
      ctx2[13].BINDING
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block0 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  let if_block1 = !/*disabled*/
  ctx[1] && /*allowBindings*/
  ctx[3] && !/*filter*/
  ctx[0].noValue && create_if_block$3(ctx);
  return {
    c() {
      div3 = element("div");
      create_component(drawer.$$.fragment);
      t0 = space();
      div2 = element("div");
      div0 = element("div");
      if_block0.c();
      t1 = space();
      div1 = element("div");
      if (if_block1)
        if_block1.c();
      attr(div0, "class", "field svelte-u5a0ap");
      attr(div1, "class", "binding-control svelte-u5a0ap");
      attr(div2, "class", "field-wrap svelte-u5a0ap");
      toggle_class(
        div2,
        "bindings",
        /*allowBindings*/
        ctx[3]
      );
      toggle_class(
        div2,
        "valid",
        /*fieldIsValid*/
        ctx[10]
      );
    },
    m(target, anchor) {
      insert(target, div3, anchor);
      mount_component(drawer, div3, null);
      append(div3, t0);
      append(div3, div2);
      append(div2, div0);
      if_blocks[current_block_type_index].m(div0, null);
      append(div2, t1);
      append(div2, div1);
      if (if_block1)
        if_block1.m(div1, null);
      current = true;
    },
    p(ctx2, dirty) {
      const drawer_changes = {};
      if (dirty[0] & /*drawerTitle, filter*/
      33)
        drawer_changes.title = /*drawerTitle*/
        ctx2[5] || /*filter*/
        ctx2[0].field;
      if (dirty[0] & /*panel, drawerValue, bindings, evaluationContext, bindingDrawer*/
      724 | dirty[1] & /*$$scope*/
      32) {
        drawer_changes.$$scope = { dirty, ctx: ctx2 };
      }
      drawer.$set(drawer_changes);
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block0 = if_blocks[current_block_type_index];
        if (!if_block0) {
          if_block0 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block0.c();
        } else {
          if_block0.p(ctx2, dirty);
        }
        transition_in(if_block0, 1);
        if_block0.m(div0, null);
      }
      if (!/*disabled*/
      ctx2[1] && /*allowBindings*/
      ctx2[3] && !/*filter*/
      ctx2[0].noValue) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty[0] & /*disabled, allowBindings, filter*/
          11) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block$3(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div1, null);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if (!current || dirty[0] & /*allowBindings*/
      8) {
        toggle_class(
          div2,
          "bindings",
          /*allowBindings*/
          ctx2[3]
        );
      }
      if (!current || dirty[0] & /*fieldIsValid*/
      1024) {
        toggle_class(
          div2,
          "valid",
          /*fieldIsValid*/
          ctx2[10]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(drawer.$$.fragment, local);
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(drawer.$$.fragment, local);
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div3);
      }
      ctx[24](null);
      destroy_component(drawer);
      if_blocks[current_block_type_index].d();
      if (if_block1)
        if_block1.d();
    }
  };
}
function instance$3($$self, $$props, $$invalidate) {
  let fieldValue;
  let readableValue;
  let drawerValue;
  let isJS;
  let fieldIsValid;
  let { filter } = $$props;
  let { disabled = false } = $$props;
  let { bindings = [] } = $$props;
  let { allowBindings = false } = $$props;
  let { schemaFields } = $$props;
  let { panel } = $$props;
  let { drawerTitle } = $$props;
  let { toReadable } = $$props;
  let { toRuntime } = $$props;
  let { evaluationContext = {} } = $$props;
  const dispatch = createEventDispatcher();
  const { OperatorOptions, FilterValueType } = Constants;
  let bindingDrawer;
  const getFieldOptions = (field) => {
    var _a;
    const schema = schemaFields.find((x) => x.name === field);
    return ((_a = schema == null ? void 0 : schema.constraints) == null ? void 0 : _a.inclusion) || [];
  };
  const getSchema = (filter2) => {
    return schemaFields.find((field) => field.name === filter2.field);
  };
  const drawerOnChange = (e) => {
    $$invalidate(9, drawerValue = e.detail);
  };
  const onChange = (e) => {
    $$invalidate(22, fieldValue = e.detail);
    dispatch("change", {
      value: toRuntime ? toRuntime(bindings, fieldValue) : fieldValue
    });
  };
  const onConfirmBinding = () => {
    dispatch("change", {
      value: toRuntime ? toRuntime(bindings, drawerValue) : drawerValue,
      valueType: drawerValue ? FilterValueType.BINDING : FilterValueType.VALUE
    });
  };
  const isValidDate = (value) => {
    return !value || !isNaN(new Date(value).valueOf());
  };
  const hasValidOptions = (value) => {
    let links = [];
    if (Array.isArray(value)) {
      links = value;
    } else if (value && typeof value === "string") {
      links = value.split(",");
    } else {
      return !value;
    }
    return links.every((link) => {
      var _a, _b, _c;
      return (_c = (_b = (_a = getSchema(filter)) == null ? void 0 : _a.constraints) == null ? void 0 : _b.inclusion) == null ? void 0 : _c.includes(link);
    });
  };
  const isValidBoolean = (value) => {
    return value === "false" || value === "true" || value == "";
  };
  const hasValidLinks = (value) => {
    let links = [];
    if (Array.isArray(value)) {
      links = value;
    } else if (value && typeof value === "string") {
      links = value.split(",");
    } else {
      return !value;
    }
    return links.every((link) => link.startsWith("ro_"));
  };
  const validationMap = {
    date: isValidDate,
    datetime: isValidDate,
    bb_reference: hasValidLinks,
    bb_reference_single: hasValidLinks,
    array: hasValidOptions,
    longform: (value) => !isJSBinding(value),
    options: (value) => {
      var _a;
      return !isJSBinding(value) && !((_a = findHBSBlocks(value)) == null ? void 0 : _a.length);
    },
    boolean: isValidBoolean
  };
  const isValid = (value) => {
    const validate = validationMap[filter.type];
    return validate ? validate(value) : true;
  };
  const toDrawerValue = (fieldValue2) => {
    if (filter.valueType == FilterValueType.VALUE) {
      return "";
    }
    return Array.isArray(fieldValue2) ? fieldValue2.join(",") : readableValue;
  };
  const click_handler = () => {
    onConfirmBinding();
    bindingDrawer.hide();
  };
  function drawer_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      bindingDrawer = $$value;
      $$invalidate(7, bindingDrawer);
    });
  }
  function drawerHide_handler(event) {
    bubble.call(this, $$self, event);
  }
  function drawerShow_handler(event) {
    bubble.call(this, $$self, event);
  }
  const click_handler_1 = () => {
    bindingDrawer.show();
  };
  $$self.$$set = ($$props2) => {
    if ("filter" in $$props2)
      $$invalidate(0, filter = $$props2.filter);
    if ("disabled" in $$props2)
      $$invalidate(1, disabled = $$props2.disabled);
    if ("bindings" in $$props2)
      $$invalidate(2, bindings = $$props2.bindings);
    if ("allowBindings" in $$props2)
      $$invalidate(3, allowBindings = $$props2.allowBindings);
    if ("schemaFields" in $$props2)
      $$invalidate(19, schemaFields = $$props2.schemaFields);
    if ("panel" in $$props2)
      $$invalidate(4, panel = $$props2.panel);
    if ("drawerTitle" in $$props2)
      $$invalidate(5, drawerTitle = $$props2.drawerTitle);
    if ("toReadable" in $$props2)
      $$invalidate(20, toReadable = $$props2.toReadable);
    if ("toRuntime" in $$props2)
      $$invalidate(21, toRuntime = $$props2.toRuntime);
    if ("evaluationContext" in $$props2)
      $$invalidate(6, evaluationContext = $$props2.evaluationContext);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*filter*/
    1) {
      $$invalidate(22, fieldValue = filter == null ? void 0 : filter.value);
    }
    if ($$self.$$.dirty[0] & /*toReadable, bindings, fieldValue*/
    5242884) {
      $$invalidate(8, readableValue = toReadable ? toReadable(bindings, fieldValue) : fieldValue);
    }
    if ($$self.$$.dirty[0] & /*fieldValue*/
    4194304) {
      $$invalidate(9, drawerValue = toDrawerValue(fieldValue));
    }
    if ($$self.$$.dirty[0] & /*fieldValue*/
    4194304) {
      $$invalidate(11, isJS = isJSBinding(fieldValue));
    }
    if ($$self.$$.dirty[0] & /*fieldValue*/
    4194304) {
      $$invalidate(10, fieldIsValid = isValid(fieldValue));
    }
  };
  return [
    filter,
    disabled,
    bindings,
    allowBindings,
    panel,
    drawerTitle,
    evaluationContext,
    bindingDrawer,
    readableValue,
    drawerValue,
    fieldIsValid,
    isJS,
    OperatorOptions,
    FilterValueType,
    getFieldOptions,
    getSchema,
    drawerOnChange,
    onChange,
    onConfirmBinding,
    schemaFields,
    toReadable,
    toRuntime,
    fieldValue,
    click_handler,
    drawer_binding,
    drawerHide_handler,
    drawerShow_handler,
    click_handler_1
  ];
}
class FilterField extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance$3,
      create_fragment$3,
      safe_not_equal,
      {
        filter: 0,
        disabled: 1,
        bindings: 2,
        allowBindings: 3,
        schemaFields: 19,
        panel: 4,
        drawerTitle: 5,
        toReadable: 20,
        toRuntime: 21,
        evaluationContext: 6
      },
      null,
      [-1, -1]
    );
  }
}
function create_default_slot$2(ctx) {
  let t;
  return {
    c() {
      t = text("Confirm");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_buttons_slot(ctx) {
  let button;
  let current;
  button = new Button({
    props: {
      cta: true,
      slot: "buttons",
      $$slots: { default: [create_default_slot$2] },
      $$scope: { ctx }
    }
  });
  button.$on(
    "click",
    /*click_handler*/
    ctx[16]
  );
  return {
    c() {
      create_component(button.$$.fragment);
    },
    m(target, anchor) {
      mount_component(button, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const button_changes = {};
      if (dirty & /*$$scope*/
      8388608) {
        button_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button.$set(button_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(button.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(button.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(button, detaching);
    }
  };
}
function create_body_slot(ctx) {
  let switch_instance;
  let switch_instance_anchor;
  let current;
  var switch_value = (
    /*panel*/
    ctx[3]
  );
  function switch_props(ctx2, dirty) {
    return {
      props: {
        slot: "body",
        value: (
          /*drawerValue*/
          ctx2[8]
        ),
        allowJS: true,
        allowHelpers: true,
        allowHBS: true,
        bindings: (
          /*bindings*/
          ctx2[2]
        ),
        context: (
          /*evaluationContext*/
          ctx2[5]
        )
      }
    };
  }
  if (switch_value) {
    switch_instance = construct_svelte_component(switch_value, switch_props(ctx));
    switch_instance.$on(
      "change",
      /*drawerOnChange*/
      ctx[10]
    );
  }
  return {
    c() {
      if (switch_instance)
        create_component(switch_instance.$$.fragment);
      switch_instance_anchor = empty();
    },
    m(target, anchor) {
      if (switch_instance)
        mount_component(switch_instance, target, anchor);
      insert(target, switch_instance_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*panel*/
      8 && switch_value !== (switch_value = /*panel*/
      ctx2[3])) {
        if (switch_instance) {
          group_outros();
          const old_component = switch_instance;
          transition_out(old_component.$$.fragment, 1, 0, () => {
            destroy_component(old_component, 1);
          });
          check_outros();
        }
        if (switch_value) {
          switch_instance = construct_svelte_component(switch_value, switch_props(ctx2));
          switch_instance.$on(
            "change",
            /*drawerOnChange*/
            ctx2[10]
          );
          create_component(switch_instance.$$.fragment);
          transition_in(switch_instance.$$.fragment, 1);
          mount_component(switch_instance, switch_instance_anchor.parentNode, switch_instance_anchor);
        } else {
          switch_instance = null;
        }
      } else if (switch_value) {
        const switch_instance_changes = {};
        if (dirty & /*drawerValue*/
        256)
          switch_instance_changes.value = /*drawerValue*/
          ctx2[8];
        if (dirty & /*bindings*/
        4)
          switch_instance_changes.bindings = /*bindings*/
          ctx2[2];
        if (dirty & /*evaluationContext*/
        32)
          switch_instance_changes.context = /*evaluationContext*/
          ctx2[5];
        switch_instance.$set(switch_instance_changes);
      }
    },
    i(local) {
      if (current)
        return;
      if (switch_instance)
        transition_in(switch_instance.$$.fragment, local);
      current = true;
    },
    o(local) {
      if (switch_instance)
        transition_out(switch_instance.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(switch_instance_anchor);
      }
      if (switch_instance)
        destroy_component(switch_instance, detaching);
    }
  };
}
function create_if_block$2(ctx) {
  let div;
  let icon;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({
    props: {
      size: "S",
      weight: "fill",
      name: "lightning"
    }
  });
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      attr(div, "class", "icon binding svelte-eaqops");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      current = true;
      if (!mounted) {
        dispose = listen(
          div,
          "click",
          /*click_handler_1*/
          ctx[20]
        );
        mounted = true;
      }
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
      mounted = false;
      dispose();
    }
  };
}
function create_fragment$2(ctx) {
  let div3;
  let drawer;
  let t0;
  let div2;
  let div0;
  let input;
  let t1;
  let div1;
  let current;
  let drawer_props = {
    title: (
      /*drawerTitle*/
      ctx[4] || ""
    ),
    forceModal: true,
    $$slots: {
      body: [create_body_slot],
      buttons: [create_buttons_slot]
    },
    $$scope: { ctx }
  };
  drawer = new Drawer({ props: drawer_props });
  ctx[17](drawer);
  drawer.$on(
    "drawerHide",
    /*drawerHide_handler*/
    ctx[18]
  );
  drawer.$on(
    "drawerShow",
    /*drawerShow_handler*/
    ctx[19]
  );
  input = new Input({
    props: {
      disabled: (
        /*filter*/
        ctx[0].noValue
      ),
      readonly: (
        /*isJS*/
        ctx[9]
      ),
      value: (
        /*isJS*/
        ctx[9] ? "(JavaScript function)" : (
          /*readableValue*/
          ctx[7]
        )
      )
    }
  });
  input.$on(
    "change",
    /*onChange*/
    ctx[11]
  );
  let if_block = !/*disabled*/
  ctx[1] && create_if_block$2(ctx);
  return {
    c() {
      div3 = element("div");
      create_component(drawer.$$.fragment);
      t0 = space();
      div2 = element("div");
      div0 = element("div");
      create_component(input.$$.fragment);
      t1 = space();
      div1 = element("div");
      if (if_block)
        if_block.c();
      attr(div0, "class", "field svelte-eaqops");
      attr(div1, "class", "binding-control svelte-eaqops");
      attr(div2, "class", "field-wrap svelte-eaqops");
      toggle_class(div2, "bindings", true);
    },
    m(target, anchor) {
      insert(target, div3, anchor);
      mount_component(drawer, div3, null);
      append(div3, t0);
      append(div3, div2);
      append(div2, div0);
      mount_component(input, div0, null);
      append(div2, t1);
      append(div2, div1);
      if (if_block)
        if_block.m(div1, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      const drawer_changes = {};
      if (dirty & /*drawerTitle*/
      16)
        drawer_changes.title = /*drawerTitle*/
        ctx2[4] || "";
      if (dirty & /*$$scope, panel, drawerValue, bindings, evaluationContext, bindingDrawer*/
      8388972) {
        drawer_changes.$$scope = { dirty, ctx: ctx2 };
      }
      drawer.$set(drawer_changes);
      const input_changes = {};
      if (dirty & /*filter*/
      1)
        input_changes.disabled = /*filter*/
        ctx2[0].noValue;
      if (dirty & /*isJS*/
      512)
        input_changes.readonly = /*isJS*/
        ctx2[9];
      if (dirty & /*isJS, readableValue*/
      640)
        input_changes.value = /*isJS*/
        ctx2[9] ? "(JavaScript function)" : (
          /*readableValue*/
          ctx2[7]
        );
      input.$set(input_changes);
      if (!/*disabled*/
      ctx2[1]) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*disabled*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$2(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div1, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(drawer.$$.fragment, local);
      transition_in(input.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(drawer.$$.fragment, local);
      transition_out(input.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div3);
      }
      ctx[17](null);
      destroy_component(drawer);
      destroy_component(input);
      if (if_block)
        if_block.d();
    }
  };
}
function instance$2($$self, $$props, $$invalidate) {
  let readableValue;
  let drawerValue;
  let isJS;
  let { filter } = $$props;
  let { disabled = false } = $$props;
  let { bindings = [] } = $$props;
  let { panel } = $$props;
  let { drawerTitle } = $$props;
  let { toReadable } = $$props;
  let { toRuntime } = $$props;
  let { evaluationContext = {} } = $$props;
  const dispatch = createEventDispatcher();
  let bindingDrawer;
  let fieldValue;
  const drawerOnChange = (e) => {
    $$invalidate(8, drawerValue = e.detail);
  };
  const onChange = (e) => {
    $$invalidate(15, fieldValue = e.detail);
    dispatch("change", {
      field: toRuntime ? toRuntime(bindings, fieldValue) : fieldValue
    });
  };
  const onConfirmBinding = () => {
    dispatch("change", {
      field: toRuntime ? toRuntime(bindings, drawerValue) : drawerValue
    });
  };
  const toDrawerValue = (fieldValue2) => {
    return Array.isArray(fieldValue2) ? fieldValue2.join(",") : readableValue;
  };
  const click_handler = () => {
    onConfirmBinding();
    bindingDrawer.hide();
  };
  function drawer_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      bindingDrawer = $$value;
      $$invalidate(6, bindingDrawer);
    });
  }
  function drawerHide_handler(event) {
    bubble.call(this, $$self, event);
  }
  function drawerShow_handler(event) {
    bubble.call(this, $$self, event);
  }
  const click_handler_1 = () => {
    bindingDrawer.show();
  };
  $$self.$$set = ($$props2) => {
    if ("filter" in $$props2)
      $$invalidate(0, filter = $$props2.filter);
    if ("disabled" in $$props2)
      $$invalidate(1, disabled = $$props2.disabled);
    if ("bindings" in $$props2)
      $$invalidate(2, bindings = $$props2.bindings);
    if ("panel" in $$props2)
      $$invalidate(3, panel = $$props2.panel);
    if ("drawerTitle" in $$props2)
      $$invalidate(4, drawerTitle = $$props2.drawerTitle);
    if ("toReadable" in $$props2)
      $$invalidate(13, toReadable = $$props2.toReadable);
    if ("toRuntime" in $$props2)
      $$invalidate(14, toRuntime = $$props2.toRuntime);
    if ("evaluationContext" in $$props2)
      $$invalidate(5, evaluationContext = $$props2.evaluationContext);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*filter*/
    1) {
      $$invalidate(15, fieldValue = filter == null ? void 0 : filter.field);
    }
    if ($$self.$$.dirty & /*toReadable, bindings, fieldValue*/
    40964) {
      $$invalidate(7, readableValue = toReadable ? toReadable(bindings, fieldValue) : fieldValue);
    }
    if ($$self.$$.dirty & /*fieldValue*/
    32768) {
      $$invalidate(8, drawerValue = toDrawerValue(fieldValue));
    }
    if ($$self.$$.dirty & /*fieldValue*/
    32768) {
      $$invalidate(9, isJS = isJSBinding(fieldValue));
    }
  };
  return [
    filter,
    disabled,
    bindings,
    panel,
    drawerTitle,
    evaluationContext,
    bindingDrawer,
    readableValue,
    drawerValue,
    isJS,
    drawerOnChange,
    onChange,
    onConfirmBinding,
    toReadable,
    toRuntime,
    fieldValue,
    click_handler,
    drawer_binding,
    drawerHide_handler,
    drawerShow_handler,
    click_handler_1
  ];
}
class ConditionField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$2, create_fragment$2, safe_not_equal, {
      filter: 0,
      disabled: 1,
      bindings: 2,
      panel: 3,
      drawerTitle: 4,
      toReadable: 13,
      toRuntime: 14,
      evaluationContext: 5
    });
  }
}
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[52] = list[i];
  child_ctx[54] = i;
  return child_ctx;
}
function get_each_context_1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[55] = list[i];
  child_ctx[57] = i;
  return child_ctx;
}
const get_filtering_hero_content_slot_changes = (dirty) => ({});
const get_filtering_hero_content_slot_context = (ctx) => ({});
function create_else_block_1(ctx) {
  let body;
  let current;
  body = new Body({
    props: {
      size: "S",
      $$slots: { default: [create_default_slot_3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(body.$$.fragment);
    },
    m(target, anchor) {
      mount_component(body, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const body_changes = {};
      if (dirty[1] & /*$$scope*/
      256) {
        body_changes.$$scope = { dirty, ctx: ctx2 };
      }
      body.$set(body_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(body.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(body.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(body, detaching);
    }
  };
}
function create_if_block$1(ctx) {
  var _a, _b, _c, _d;
  let t0;
  let t1;
  let t2;
  let div;
  let layout;
  let current;
  const filtering_hero_content_slot_template = (
    /*#slots*/
    ctx[27]["filtering-hero-content"]
  );
  const filtering_hero_content_slot = create_slot(
    filtering_hero_content_slot_template,
    ctx,
    /*$$scope*/
    ctx[39],
    get_filtering_hero_content_slot_context
  );
  let if_block0 = (
    /*editableFilters*/
    ((_b = (_a = ctx[11]) == null ? void 0 : _a.groups) == null ? void 0 : _b.length) && create_if_block_5(ctx)
  );
  let if_block1 = (
    /*editableFilters*/
    ((_d = (_c = ctx[11]) == null ? void 0 : _c.groups) == null ? void 0 : _d.length) && create_if_block_3(ctx)
  );
  layout = new Layout({
    props: {
      noPadding: true,
      $$slots: { default: [create_default_slot_1$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      if (filtering_hero_content_slot)
        filtering_hero_content_slot.c();
      t0 = space();
      if (if_block0)
        if_block0.c();
      t1 = space();
      if (if_block1)
        if_block1.c();
      t2 = space();
      div = element("div");
      create_component(layout.$$.fragment);
      attr(div, "class", "filters-footer svelte-lrj6l");
    },
    m(target, anchor) {
      if (filtering_hero_content_slot) {
        filtering_hero_content_slot.m(target, anchor);
      }
      insert(target, t0, anchor);
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t1, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, t2, anchor);
      insert(target, div, anchor);
      mount_component(layout, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2, _b2, _c2, _d2;
      if (filtering_hero_content_slot) {
        if (filtering_hero_content_slot.p && (!current || dirty[1] & /*$$scope*/
        256)) {
          update_slot_base(
            filtering_hero_content_slot,
            filtering_hero_content_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[39],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[39]
            ) : get_slot_changes(
              filtering_hero_content_slot_template,
              /*$$scope*/
              ctx2[39],
              dirty,
              get_filtering_hero_content_slot_changes
            ),
            get_filtering_hero_content_slot_context
          );
        }
      }
      if (
        /*editableFilters*/
        (_b2 = (_a2 = ctx2[11]) == null ? void 0 : _a2.groups) == null ? void 0 : _b2.length
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty[0] & /*editableFilters*/
          2048) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_5(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(t1.parentNode, t1);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (
        /*editableFilters*/
        (_d2 = (_c2 = ctx2[11]) == null ? void 0 : _c2.groups) == null ? void 0 : _d2.length
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty[0] & /*editableFilters*/
          2048) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_3(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(t2.parentNode, t2);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      const layout_changes = {};
      if (dirty[0] & /*docsURL, builderType, editableFilters, behaviourFilters, allowOnEmpty*/
      2106 | dirty[1] & /*$$scope*/
      256) {
        layout_changes.$$scope = { dirty, ctx: ctx2 };
      }
      layout.$set(layout_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(filtering_hero_content_slot, local);
      transition_in(if_block0);
      transition_in(if_block1);
      transition_in(layout.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(filtering_hero_content_slot, local);
      transition_out(if_block0);
      transition_out(if_block1);
      transition_out(layout.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
        detach(div);
      }
      if (filtering_hero_content_slot)
        filtering_hero_content_slot.d(detaching);
      if (if_block0)
        if_block0.d(detaching);
      if (if_block1)
        if_block1.d(detaching);
      destroy_component(layout);
    }
  };
}
function create_default_slot_3(ctx) {
  let t;
  return {
    c() {
      t = text("None of the table column can be used for filtering.");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_5(ctx) {
  var _a;
  let div;
  let span0;
  let t0;
  let t1;
  let span1;
  let select;
  let t2;
  let span2;
  let t3;
  let t4;
  let t5;
  let current;
  select = new Select_1({
    props: {
      value: (
        /*editableFilters*/
        (_a = ctx[11]) == null ? void 0 : _a.logicalOperator
      ),
      options: (
        /*filterOperatorOptions*/
        ctx[15]
      ),
      getOptionLabel: func,
      getOptionValue: func_1,
      placeholder: false
    }
  });
  select.$on(
    "change",
    /*change_handler*/
    ctx[28]
  );
  return {
    c() {
      div = element("div");
      span0 = element("span");
      t0 = text(
        /*prefix*/
        ctx[13]
      );
      t1 = space();
      span1 = element("span");
      create_component(select.$$.fragment);
      t2 = space();
      span2 = element("span");
      t3 = text("of the following ");
      t4 = text(
        /*builderType*/
        ctx[4]
      );
      t5 = text(" groups:");
      attr(span1, "class", "operator-picker svelte-lrj6l");
      attr(div, "class", "global-filter-header svelte-lrj6l");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, span0);
      append(span0, t0);
      append(div, t1);
      append(div, span1);
      mount_component(select, span1, null);
      append(div, t2);
      append(div, span2);
      append(span2, t3);
      append(span2, t4);
      append(span2, t5);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      if (!current || dirty[0] & /*prefix*/
      8192)
        set_data(
          t0,
          /*prefix*/
          ctx2[13]
        );
      const select_changes = {};
      if (dirty[0] & /*editableFilters*/
      2048)
        select_changes.value = /*editableFilters*/
        (_a2 = ctx2[11]) == null ? void 0 : _a2.logicalOperator;
      select.$set(select_changes);
      if (!current || dirty[0] & /*builderType*/
      16)
        set_data(
          t4,
          /*builderType*/
          ctx2[4]
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(select.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(select.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(select);
    }
  };
}
function create_if_block_3(ctx) {
  var _a;
  let div;
  let current;
  let each_value = ensure_array_like(
    /*editableFilters*/
    (_a = ctx[11]) == null ? void 0 : _a.groups
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "filter-groups svelte-lrj6l");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      if (dirty[0] & /*editableFilters, handleFilterChange, builderType, allowBindings, schemaFields, bindings, panel, toReadable, toRuntime, evaluationContext, onFilterFieldUpdate, getValidOperatorsForType, onOperatorChange, fieldOptions, onFieldChange, filterOperatorOptions, getGroupPrefix*/
      16555989) {
        each_value = ensure_array_like(
          /*editableFilters*/
          (_a2 = ctx2[11]) == null ? void 0 : _a2.groups
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div, null);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_else_block(ctx) {
  let conditionfield;
  let current;
  function change_handler_3(...args) {
    return (
      /*change_handler_3*/
      ctx[33](
        /*filter*/
        ctx[55],
        /*groupIdx*/
        ctx[54],
        /*filterIdx*/
        ctx[57],
        ...args
      )
    );
  }
  conditionfield = new ConditionField({
    props: {
      placeholder: "Value",
      filter: (
        /*filter*/
        ctx[55]
      ),
      drawerTitle: "Edit Binding",
      bindings: (
        /*bindings*/
        ctx[6]
      ),
      panel: (
        /*panel*/
        ctx[7]
      ),
      toReadable: (
        /*toReadable*/
        ctx[8]
      ),
      toRuntime: (
        /*toRuntime*/
        ctx[9]
      ),
      evaluationContext: (
        /*evaluationContext*/
        ctx[10]
      )
    }
  });
  conditionfield.$on("change", change_handler_3);
  return {
    c() {
      create_component(conditionfield.$$.fragment);
    },
    m(target, anchor) {
      mount_component(conditionfield, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const conditionfield_changes = {};
      if (dirty[0] & /*editableFilters*/
      2048)
        conditionfield_changes.filter = /*filter*/
        ctx[55];
      if (dirty[0] & /*bindings*/
      64)
        conditionfield_changes.bindings = /*bindings*/
        ctx[6];
      if (dirty[0] & /*panel*/
      128)
        conditionfield_changes.panel = /*panel*/
        ctx[7];
      if (dirty[0] & /*toReadable*/
      256)
        conditionfield_changes.toReadable = /*toReadable*/
        ctx[8];
      if (dirty[0] & /*toRuntime*/
      512)
        conditionfield_changes.toRuntime = /*toRuntime*/
        ctx[9];
      if (dirty[0] & /*evaluationContext*/
      1024)
        conditionfield_changes.evaluationContext = /*evaluationContext*/
        ctx[10];
      conditionfield.$set(conditionfield_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(conditionfield.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(conditionfield.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(conditionfield, detaching);
    }
  };
}
function create_if_block_4(ctx) {
  let select;
  let current;
  function change_handler_2(...args) {
    return (
      /*change_handler_2*/
      ctx[32](
        /*filter*/
        ctx[55],
        /*groupIdx*/
        ctx[54],
        /*filterIdx*/
        ctx[57],
        ...args
      )
    );
  }
  select = new Select_1({
    props: {
      value: (
        /*filter*/
        ctx[55].field
      ),
      options: (
        /*fieldOptions*/
        ctx[12]
      ),
      placeholder: "Column"
    }
  });
  select.$on("change", change_handler_2);
  return {
    c() {
      create_component(select.$$.fragment);
    },
    m(target, anchor) {
      mount_component(select, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const select_changes = {};
      if (dirty[0] & /*editableFilters*/
      2048)
        select_changes.value = /*filter*/
        ctx[55].field;
      if (dirty[0] & /*fieldOptions*/
      4096)
        select_changes.options = /*fieldOptions*/
        ctx[12];
      select.$set(select_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(select.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(select.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(select, detaching);
    }
  };
}
function create_each_block_1(ctx) {
  let div;
  let current_block_type_index;
  let if_block;
  let t0;
  let select;
  let t1;
  let filterfield;
  let t2;
  let actionbutton;
  let t3;
  let current;
  const if_block_creators = [create_if_block_4, create_else_block];
  const if_blocks = [];
  function select_block_type_1(ctx2, dirty) {
    if (
      /*builderType*/
      ctx2[4] === "filter"
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type_1(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  function change_handler_4(...args) {
    return (
      /*change_handler_4*/
      ctx[34](
        /*filter*/
        ctx[55],
        /*groupIdx*/
        ctx[54],
        /*filterIdx*/
        ctx[57],
        ...args
      )
    );
  }
  select = new Select_1({
    props: {
      value: (
        /*filter*/
        ctx[55].operator
      ),
      disabled: !/*filter*/
      ctx[55].field && /*builderType*/
      ctx[4] === "filter",
      options: (
        /*getValidOperatorsForType*/
        ctx[20](
          /*filter*/
          ctx[55]
        )
      ),
      placeholder: false
    }
  });
  select.$on("change", change_handler_4);
  function change_handler_5(...args) {
    return (
      /*change_handler_5*/
      ctx[35](
        /*filter*/
        ctx[55],
        /*groupIdx*/
        ctx[54],
        /*filterIdx*/
        ctx[57],
        ...args
      )
    );
  }
  filterfield = new FilterField({
    props: {
      placeholder: "Value",
      disabled: !/*filter*/
      ctx[55].field && /*builderType*/
      ctx[4] === "filter",
      drawerTitle: (
        /*builderType*/
        ctx[4] === "condition" ? "Edit binding" : null
      ),
      allowBindings: (
        /*allowBindings*/
        ctx[2]
      ),
      filter: {
        .../*filter*/
        ctx[55],
        .../*builderType*/
        ctx[4] === "condition" ? { type: FieldType.STRING } : {}
      },
      schemaFields: (
        /*schemaFields*/
        ctx[0]
      ),
      bindings: (
        /*bindings*/
        ctx[6]
      ),
      panel: (
        /*panel*/
        ctx[7]
      ),
      toReadable: (
        /*toReadable*/
        ctx[8]
      ),
      toRuntime: (
        /*toRuntime*/
        ctx[9]
      ),
      evaluationContext: (
        /*evaluationContext*/
        ctx[10]
      )
    }
  });
  filterfield.$on("change", change_handler_5);
  function click_handler_2() {
    return (
      /*click_handler_2*/
      ctx[36](
        /*groupIdx*/
        ctx[54],
        /*filterIdx*/
        ctx[57]
      )
    );
  }
  actionbutton = new ActionButton({ props: { size: "M", icon: "trash" } });
  actionbutton.$on("click", click_handler_2);
  return {
    c() {
      div = element("div");
      if_block.c();
      t0 = space();
      create_component(select.$$.fragment);
      t1 = space();
      create_component(filterfield.$$.fragment);
      t2 = space();
      create_component(actionbutton.$$.fragment);
      t3 = space();
      attr(div, "class", "filter svelte-lrj6l");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      append(div, t0);
      mount_component(select, div, null);
      append(div, t1);
      mount_component(filterfield, div, null);
      append(div, t2);
      mount_component(actionbutton, div, null);
      append(div, t3);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_1(ctx);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
          if_block.c();
        } else {
          if_block.p(ctx, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div, t0);
      }
      const select_changes = {};
      if (dirty[0] & /*editableFilters*/
      2048)
        select_changes.value = /*filter*/
        ctx[55].operator;
      if (dirty[0] & /*editableFilters, builderType*/
      2064)
        select_changes.disabled = !/*filter*/
        ctx[55].field && /*builderType*/
        ctx[4] === "filter";
      if (dirty[0] & /*editableFilters*/
      2048)
        select_changes.options = /*getValidOperatorsForType*/
        ctx[20](
          /*filter*/
          ctx[55]
        );
      select.$set(select_changes);
      const filterfield_changes = {};
      if (dirty[0] & /*editableFilters, builderType*/
      2064)
        filterfield_changes.disabled = !/*filter*/
        ctx[55].field && /*builderType*/
        ctx[4] === "filter";
      if (dirty[0] & /*builderType*/
      16)
        filterfield_changes.drawerTitle = /*builderType*/
        ctx[4] === "condition" ? "Edit binding" : null;
      if (dirty[0] & /*allowBindings*/
      4)
        filterfield_changes.allowBindings = /*allowBindings*/
        ctx[2];
      if (dirty[0] & /*editableFilters, builderType*/
      2064)
        filterfield_changes.filter = {
          .../*filter*/
          ctx[55],
          .../*builderType*/
          ctx[4] === "condition" ? { type: FieldType.STRING } : {}
        };
      if (dirty[0] & /*schemaFields*/
      1)
        filterfield_changes.schemaFields = /*schemaFields*/
        ctx[0];
      if (dirty[0] & /*bindings*/
      64)
        filterfield_changes.bindings = /*bindings*/
        ctx[6];
      if (dirty[0] & /*panel*/
      128)
        filterfield_changes.panel = /*panel*/
        ctx[7];
      if (dirty[0] & /*toReadable*/
      256)
        filterfield_changes.toReadable = /*toReadable*/
        ctx[8];
      if (dirty[0] & /*toRuntime*/
      512)
        filterfield_changes.toRuntime = /*toRuntime*/
        ctx[9];
      if (dirty[0] & /*evaluationContext*/
      1024)
        filterfield_changes.evaluationContext = /*evaluationContext*/
        ctx[10];
      filterfield.$set(filterfield_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      transition_in(select.$$.fragment, local);
      transition_in(filterfield.$$.fragment, local);
      transition_in(actionbutton.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      transition_out(select.$$.fragment, local);
      transition_out(filterfield.$$.fragment, local);
      transition_out(actionbutton.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
      destroy_component(select);
      destroy_component(filterfield);
      destroy_component(actionbutton);
    }
  };
}
function create_each_block(ctx) {
  var _a;
  let div4;
  let div2;
  let div0;
  let span0;
  let t0_value = (
    /*getGroupPrefix*/
    ctx[21](
      /*groupIdx*/
      ctx[54],
      /*editableFilters*/
      ctx[11].logicalOperator
    ) + ""
  );
  let t0;
  let t1;
  let span1;
  let select;
  let t2;
  let span2;
  let t3;
  let t4;
  let t5;
  let t6;
  let div1;
  let icon0;
  let t7;
  let icon1;
  let t8;
  let div3;
  let t9;
  let current;
  function change_handler_1(...args) {
    return (
      /*change_handler_1*/
      ctx[29](
        /*groupIdx*/
        ctx[54],
        ...args
      )
    );
  }
  select = new Select_1({
    props: {
      value: (
        /*group*/
        (_a = ctx[52]) == null ? void 0 : _a.logicalOperator
      ),
      options: (
        /*filterOperatorOptions*/
        ctx[15]
      ),
      getOptionLabel: func_2,
      getOptionValue: func_3,
      placeholder: false
    }
  });
  select.$on("change", change_handler_1);
  function click_handler() {
    return (
      /*click_handler*/
      ctx[30](
        /*groupIdx*/
        ctx[54]
      )
    );
  }
  icon0 = new Icon({
    props: {
      name: "plus",
      hoverable: true,
      hoverColor: "var(--ink)"
    }
  });
  icon0.$on("click", click_handler);
  function click_handler_1() {
    return (
      /*click_handler_1*/
      ctx[31](
        /*groupIdx*/
        ctx[54]
      )
    );
  }
  icon1 = new Icon({
    props: {
      name: "trash",
      hoverable: true,
      hoverColor: "var(--ink)"
    }
  });
  icon1.$on("click", click_handler_1);
  let each_value_1 = ensure_array_like(
    /*group*/
    ctx[52].filters
  );
  let each_blocks = [];
  for (let i = 0; i < each_value_1.length; i += 1) {
    each_blocks[i] = create_each_block_1(get_each_context_1(ctx, each_value_1, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      div4 = element("div");
      div2 = element("div");
      div0 = element("div");
      span0 = element("span");
      t0 = text(t0_value);
      t1 = space();
      span1 = element("span");
      create_component(select.$$.fragment);
      t2 = space();
      span2 = element("span");
      t3 = text("of the following ");
      t4 = text(
        /*builderType*/
        ctx[4]
      );
      t5 = text("s are matched:");
      t6 = space();
      div1 = element("div");
      create_component(icon0.$$.fragment);
      t7 = space();
      create_component(icon1.$$.fragment);
      t8 = space();
      div3 = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t9 = space();
      attr(span1, "class", "operator-picker svelte-lrj6l");
      attr(div0, "class", "group-options svelte-lrj6l");
      attr(div1, "class", "group-actions svelte-lrj6l");
      attr(div2, "class", "group-header svelte-lrj6l");
      attr(div3, "class", "filters svelte-lrj6l");
      attr(div4, "class", "group svelte-lrj6l");
    },
    m(target, anchor) {
      insert(target, div4, anchor);
      append(div4, div2);
      append(div2, div0);
      append(div0, span0);
      append(span0, t0);
      append(div0, t1);
      append(div0, span1);
      mount_component(select, span1, null);
      append(div0, t2);
      append(div0, span2);
      append(span2, t3);
      append(span2, t4);
      append(span2, t5);
      append(div2, t6);
      append(div2, div1);
      mount_component(icon0, div1, null);
      append(div1, t7);
      mount_component(icon1, div1, null);
      append(div4, t8);
      append(div4, div3);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div3, null);
        }
      }
      append(div4, t9);
      current = true;
    },
    p(new_ctx, dirty) {
      var _a2;
      ctx = new_ctx;
      if ((!current || dirty[0] & /*editableFilters*/
      2048) && t0_value !== (t0_value = /*getGroupPrefix*/
      ctx[21](
        /*groupIdx*/
        ctx[54],
        /*editableFilters*/
        ctx[11].logicalOperator
      ) + ""))
        set_data(t0, t0_value);
      const select_changes = {};
      if (dirty[0] & /*editableFilters*/
      2048)
        select_changes.value = /*group*/
        (_a2 = ctx[52]) == null ? void 0 : _a2.logicalOperator;
      select.$set(select_changes);
      if (!current || dirty[0] & /*builderType*/
      16)
        set_data(
          t4,
          /*builderType*/
          ctx[4]
        );
      if (dirty[0] & /*handleFilterChange, editableFilters, builderType, allowBindings, schemaFields, bindings, panel, toReadable, toRuntime, evaluationContext, onFilterFieldUpdate, getValidOperatorsForType, onOperatorChange, fieldOptions, onFieldChange*/
      14426069) {
        each_value_1 = ensure_array_like(
          /*group*/
          ctx[52].filters
        );
        let i;
        for (i = 0; i < each_value_1.length; i += 1) {
          const child_ctx = get_each_context_1(ctx, each_value_1, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block_1(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div3, null);
          }
        }
        group_outros();
        for (i = each_value_1.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(select.$$.fragment, local);
      transition_in(icon0.$$.fragment, local);
      transition_in(icon1.$$.fragment, local);
      for (let i = 0; i < each_value_1.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      transition_out(select.$$.fragment, local);
      transition_out(icon0.$$.fragment, local);
      transition_out(icon1.$$.fragment, local);
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div4);
      }
      destroy_component(select);
      destroy_component(icon0);
      destroy_component(icon1);
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_if_block_2(ctx) {
  var _a;
  let div;
  let span0;
  let t1;
  let span1;
  let select;
  let t2;
  let span2;
  let t3;
  let t4;
  let t5;
  let current;
  select = new Select_1({
    props: {
      value: (
        /*editableFilters*/
        (_a = ctx[11]) == null ? void 0 : _a.onEmptyFilter
      ),
      options: (
        /*onEmptyOptions*/
        ctx[16]
      ),
      getOptionLabel: func_4,
      getOptionValue: func_5,
      placeholder: false
    }
  });
  select.$on(
    "change",
    /*change_handler_6*/
    ctx[37]
  );
  return {
    c() {
      div = element("div");
      span0 = element("span");
      span0.textContent = "Return";
      t1 = space();
      span1 = element("span");
      create_component(select.$$.fragment);
      t2 = space();
      span2 = element("span");
      t3 = text("when all ");
      t4 = text(
        /*builderType*/
        ctx[4]
      );
      t5 = text("s are empty");
      attr(span1, "class", "empty-filter-picker svelte-lrj6l");
      attr(div, "class", "empty-filter svelte-lrj6l");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, span0);
      append(div, t1);
      append(div, span1);
      mount_component(select, span1, null);
      append(div, t2);
      append(div, span2);
      append(span2, t3);
      append(span2, t4);
      append(span2, t5);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      const select_changes = {};
      if (dirty[0] & /*editableFilters*/
      2048)
        select_changes.value = /*editableFilters*/
        (_a2 = ctx2[11]) == null ? void 0 : _a2.onEmptyFilter;
      select.$set(select_changes);
      if (!current || dirty[0] & /*builderType*/
      16)
        set_data(
          t4,
          /*builderType*/
          ctx2[4]
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(select.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(select.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(select);
    }
  };
}
function create_default_slot_2(ctx) {
  let t0;
  let t1;
  let t2;
  return {
    c() {
      t0 = text("Add ");
      t1 = text(
        /*builderType*/
        ctx[4]
      );
      t2 = text(" group");
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      insert(target, t2, anchor);
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*builderType*/
      16)
        set_data(
          t1,
          /*builderType*/
          ctx2[4]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
      }
    }
  };
}
function create_if_block_1(ctx) {
  let a;
  let icon;
  let current;
  icon = new Icon({
    props: {
      name: "question",
      color: "var(--spectrum-global-color-gray-600)"
    }
  });
  return {
    c() {
      a = element("a");
      create_component(icon.$$.fragment);
      attr(
        a,
        "href",
        /*docsURL*/
        ctx[5]
      );
      attr(a, "target", "_blank");
    },
    m(target, anchor) {
      insert(target, a, anchor);
      mount_component(icon, a, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (!current || dirty[0] & /*docsURL*/
      32) {
        attr(
          a,
          "href",
          /*docsURL*/
          ctx2[5]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(a);
      }
      destroy_component(icon);
    }
  };
}
function create_default_slot_1$1(ctx) {
  var _a, _b;
  let t0;
  let div;
  let button;
  let t1;
  let current;
  let if_block0 = (
    /*behaviourFilters*/
    ctx[1] && /*allowOnEmpty*/
    ctx[3] && /*editableFilters*/
    ((_b = (_a = ctx[11]) == null ? void 0 : _a.groups) == null ? void 0 : _b.length) && create_if_block_2(ctx)
  );
  button = new Button({
    props: {
      icon: "plus-circle",
      size: "M",
      secondary: true,
      $$slots: { default: [create_default_slot_2] },
      $$scope: { ctx }
    }
  });
  button.$on(
    "click",
    /*click_handler_3*/
    ctx[38]
  );
  let if_block1 = (
    /*docsURL*/
    ctx[5] && create_if_block_1(ctx)
  );
  return {
    c() {
      if (if_block0)
        if_block0.c();
      t0 = space();
      div = element("div");
      create_component(button.$$.fragment);
      t1 = space();
      if (if_block1)
        if_block1.c();
      attr(div, "class", "add-group svelte-lrj6l");
    },
    m(target, anchor) {
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t0, anchor);
      insert(target, div, anchor);
      mount_component(button, div, null);
      append(div, t1);
      if (if_block1)
        if_block1.m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2, _b2;
      if (
        /*behaviourFilters*/
        ctx2[1] && /*allowOnEmpty*/
        ctx2[3] && /*editableFilters*/
        ((_b2 = (_a2 = ctx2[11]) == null ? void 0 : _a2.groups) == null ? void 0 : _b2.length)
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty[0] & /*behaviourFilters, allowOnEmpty, editableFilters*/
          2058) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_2(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(t0.parentNode, t0);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      const button_changes = {};
      if (dirty[0] & /*builderType*/
      16 | dirty[1] & /*$$scope*/
      256) {
        button_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button.$set(button_changes);
      if (
        /*docsURL*/
        ctx2[5]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty[0] & /*docsURL*/
          32) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_1(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div, null);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(button.$$.fragment, local);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(button.$$.fragment, local);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(div);
      }
      if (if_block0)
        if_block0.d(detaching);
      destroy_component(button);
      if (if_block1)
        if_block1.d();
    }
  };
}
function create_default_slot$1(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block$1, create_else_block_1];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    var _a;
    if (
      /*fieldOptions*/
      (_a = ctx2[12]) == null ? void 0 : _a.length
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_fragment$1(ctx) {
  let div;
  let layout;
  let current;
  layout = new Layout({
    props: {
      noPadding: true,
      $$slots: { default: [create_default_slot$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      var _a, _b;
      div = element("div");
      create_component(layout.$$.fragment);
      attr(div, "class", "container svelte-lrj6l");
      toggle_class(
        div,
        "mobile",
        /*$context*/
        (_b = (_a = ctx[14]) == null ? void 0 : _a.device) == null ? void 0 : _b.mobile
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(layout, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      var _a, _b;
      const layout_changes = {};
      if (dirty[0] & /*docsURL, builderType, editableFilters, behaviourFilters, allowOnEmpty, allowBindings, schemaFields, bindings, panel, toReadable, toRuntime, evaluationContext, fieldOptions, prefix*/
      16383 | dirty[1] & /*$$scope*/
      256) {
        layout_changes.$$scope = { dirty, ctx: ctx2 };
      }
      layout.$set(layout_changes);
      if (!current || dirty[0] & /*$context*/
      16384) {
        toggle_class(
          div,
          "mobile",
          /*$context*/
          (_b = (_a = ctx2[14]) == null ? void 0 : _a.device) == null ? void 0 : _b.mobile
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(layout.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(layout.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(layout);
    }
  };
}
const func = (opt) => opt.label;
const func_1 = (opt) => opt.value;
const func_2 = (opt) => opt.label;
const func_3 = (opt) => opt.value;
const func_4 = (opt) => opt.label;
const func_5 = (opt) => opt.value;
function instance$1($$self, $$props, $$invalidate) {
  let editableFilters;
  let prefix;
  let fieldOptions;
  let $context;
  let { $$slots: slots = {}, $$scope } = $$props;
  const dispatch = createEventDispatcher();
  const { OperatorOptions, DEFAULT_BB_DATASOURCE_ID, FilterOperator: FilterOperator$1, OnEmptyFilter, FilterValueType } = Constants;
  let { schemaFields } = $$props;
  let { filters } = $$props;
  let { tables = [] } = $$props;
  let { datasource } = $$props;
  let { behaviourFilters = false } = $$props;
  let { allowBindings = false } = $$props;
  let { allowOnEmpty = true } = $$props;
  let { builderType = "filter" } = $$props;
  let { docsURL = "https://docs.budibase.com/docs/searchfilter-data" } = $$props;
  let { bindings } = $$props;
  let { panel } = $$props;
  let { toReadable } = $$props;
  let { toRuntime } = $$props;
  let { evaluationContext = {} } = $$props;
  const migrateFilters = (filters2) => {
    if (Array.isArray(filters2)) {
      return processSearchFilters(filters2);
    }
    return cloneDeep(filters2);
  };
  const filterOperatorOptions = Object.values(FilterOperator$1).map((entry) => {
    return {
      value: entry,
      label: capitalise(entry)
    };
  });
  const onEmptyLabelling = {
    [OnEmptyFilter.RETURN_ALL]: "All rows",
    [OnEmptyFilter.RETURN_NONE]: "No rows"
  };
  const onEmptyOptions = Object.values(OnEmptyFilter).map((entry) => {
    return {
      value: entry,
      label: onEmptyLabelling[entry]
    };
  });
  const context = getContext("context");
  component_subscribe($$self, context, (value) => $$invalidate(14, $context = value));
  const onFieldChange = (filter) => {
    const previousType = filter.type;
    sanitizeTypes(filter);
    sanitizeOperator(filter);
    sanitizeValue(filter, previousType);
  };
  const onOperatorChange = (filter) => {
    sanitizeOperator(filter);
    sanitizeValue(filter, filter.type);
  };
  const getSchema = (filter) => {
    return schemaFields.find((field) => field.name === filter.field);
  };
  const getValidOperatorsForType$1 = (filter) => {
    if (builderType === "condition") {
      return [OperatorOptions.Equals, OperatorOptions.NotEquals];
    }
    if (!(filter == null ? void 0 : filter.field) && !(filter == null ? void 0 : filter.name)) {
      return [];
    }
    return getValidOperatorsForType(filter, filter.field || filter.name, datasource);
  };
  const sanitizeTypes = (filter) => {
    var _a;
    const fieldSchema = schemaFields.find((x) => x.name === filter.field);
    filter.type = fieldSchema == null ? void 0 : fieldSchema.type;
    filter.subtype = fieldSchema == null ? void 0 : fieldSchema.subtype;
    filter.formulaType = fieldSchema == null ? void 0 : fieldSchema.formulaType;
    filter.constraints = fieldSchema == null ? void 0 : fieldSchema.constraints;
    filter.externalType = (_a = getSchema(filter)) == null ? void 0 : _a.externalType;
  };
  const sanitizeOperator = (filter) => {
    const operators = getValidOperatorsForType$1(filter).map((x) => x.value);
    if (!operators.includes(filter.operator)) {
      filter.operator = operators[0] ?? OperatorOptions.Equals.value;
    }
    const noValueOptions = [OperatorOptions.Empty.value, OperatorOptions.NotEmpty.value];
    filter.noValue = noValueOptions.includes(filter.operator);
  };
  const sanitizeValue = (filter, previousType) => {
    if (filter.noValue) {
      filter.value = null;
      return;
    }
    if (Array.isArray(filter.value)) {
      if (filter.valueType !== "Value" || filter.type !== FieldType.ARRAY) {
        filter.value = null;
      }
    } else if (filter.type === FieldType.ARRAY && filter.valueType === "Value") {
      filter.value = [];
    } else if (previousType !== filter.type && (previousType === FieldType.BB_REFERENCE || filter.type === FieldType.BB_REFERENCE)) {
      filter.value = filter.type === FieldType.ARRAY ? [] : null;
    }
  };
  const getGroupPrefix = (groupIdx) => {
    if (groupIdx == 0) {
      return "When";
    }
    const operatorMapping = {
      [FilterOperator$1.ANY]: "or",
      [FilterOperator$1.ALL]: "and"
    };
    return operatorMapping[editableFilters.logicalOperator];
  };
  const onFilterFieldUpdate = (filter, groupIdx, filterIdx) => {
    const updated = cloneDeep(filter);
    handleFilterChange({
      groupIdx,
      filterIdx,
      filter: { ...updated }
    });
  };
  const handleFilterChange = (req) => {
    var _a, _b, _c;
    const { groupIdx, filterIdx, filter, group, addFilter, addGroup, deleteGroup, deleteFilter, logicalOperator, onEmptyFilter } = req;
    let editable = cloneDeep(editableFilters);
    let targetGroup = (_a = editable == null ? void 0 : editable.groups) == null ? void 0 : _a[groupIdx];
    let targetFilter = (_b = targetGroup == null ? void 0 : targetGroup.filters) == null ? void 0 : _b[filterIdx];
    if (targetFilter) {
      if (deleteFilter) {
        targetGroup.filters.splice(filterIdx, 1);
        if (targetGroup.filters.length === 0) {
          editable.groups.splice(groupIdx, 1);
        }
      } else if (filter) {
        targetGroup.filters[filterIdx] = filter;
      }
    } else if (targetGroup) {
      if (deleteGroup) {
        editable.groups.splice(groupIdx, 1);
      } else if (addFilter) {
        targetGroup.filters.push({
          valueType: FilterValueType.VALUE,
          ...builderType === "condition" ? {
            operator: OperatorOptions.Equals.value,
            type: FieldType.STRING
          } : {}
        });
      } else if (group) {
        editable.groups[groupIdx] = { ...targetGroup, ...group };
      }
    } else if (addGroup) {
      if (!((_c = editable == null ? void 0 : editable.groups) == null ? void 0 : _c.length)) {
        editable = {
          logicalOperator: UILogicalOperator.ALL,
          onEmptyFilter: EmptyFilterOption.RETURN_NONE,
          groups: []
        };
      }
      editable.groups.push({
        logicalOperator: FilterOperator.ANY,
        filters: [
          {
            valueType: FilterValueType.VALUE,
            ...builderType === "condition" ? { operator: OperatorOptions.Equals.value } : {}
          }
        ]
      });
    } else if (logicalOperator) {
      editable = { ...editable, logicalOperator };
    } else if (onEmptyFilter) {
      editable = { ...editable, onEmptyFilter };
    }
    editable = editable.groups.length ? editable : null;
    dispatch("change", editable);
  };
  const change_handler = (e) => {
    handleFilterChange({ logicalOperator: e.detail });
  };
  const change_handler_1 = (groupIdx, e) => {
    handleFilterChange({
      groupIdx,
      group: { logicalOperator: e.detail }
    });
  };
  const click_handler = (groupIdx) => {
    handleFilterChange({ groupIdx, addFilter: true });
  };
  const click_handler_1 = (groupIdx) => {
    handleFilterChange({ groupIdx, deleteGroup: true });
  };
  const change_handler_2 = (filter, groupIdx, filterIdx, e) => {
    const updated = { ...filter, field: e.detail };
    onFieldChange(updated);
    onFilterFieldUpdate(updated, groupIdx, filterIdx);
  };
  const change_handler_3 = (filter, groupIdx, filterIdx, e) => {
    const updated = { ...filter, field: e.detail.field };
    onFilterFieldUpdate(updated, groupIdx, filterIdx);
  };
  const change_handler_4 = (filter, groupIdx, filterIdx, e) => {
    const updated = { ...filter, operator: e.detail };
    onOperatorChange(updated);
    onFilterFieldUpdate(updated, groupIdx, filterIdx);
  };
  const change_handler_5 = (filter, groupIdx, filterIdx, e) => {
    onFilterFieldUpdate({ ...filter, ...e.detail }, groupIdx, filterIdx);
  };
  const click_handler_2 = (groupIdx, filterIdx) => {
    handleFilterChange({ groupIdx, filterIdx, deleteFilter: true });
  };
  const change_handler_6 = (e) => {
    handleFilterChange({ onEmptyFilter: e.detail });
  };
  const click_handler_3 = () => {
    handleFilterChange({ addGroup: true });
  };
  $$self.$$set = ($$props2) => {
    if ("schemaFields" in $$props2)
      $$invalidate(0, schemaFields = $$props2.schemaFields);
    if ("filters" in $$props2)
      $$invalidate(24, filters = $$props2.filters);
    if ("tables" in $$props2)
      $$invalidate(25, tables = $$props2.tables);
    if ("datasource" in $$props2)
      $$invalidate(26, datasource = $$props2.datasource);
    if ("behaviourFilters" in $$props2)
      $$invalidate(1, behaviourFilters = $$props2.behaviourFilters);
    if ("allowBindings" in $$props2)
      $$invalidate(2, allowBindings = $$props2.allowBindings);
    if ("allowOnEmpty" in $$props2)
      $$invalidate(3, allowOnEmpty = $$props2.allowOnEmpty);
    if ("builderType" in $$props2)
      $$invalidate(4, builderType = $$props2.builderType);
    if ("docsURL" in $$props2)
      $$invalidate(5, docsURL = $$props2.docsURL);
    if ("bindings" in $$props2)
      $$invalidate(6, bindings = $$props2.bindings);
    if ("panel" in $$props2)
      $$invalidate(7, panel = $$props2.panel);
    if ("toReadable" in $$props2)
      $$invalidate(8, toReadable = $$props2.toReadable);
    if ("toRuntime" in $$props2)
      $$invalidate(9, toRuntime = $$props2.toRuntime);
    if ("evaluationContext" in $$props2)
      $$invalidate(10, evaluationContext = $$props2.evaluationContext);
    if ("$$scope" in $$props2)
      $$invalidate(39, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*filters*/
    16777216) {
      $$invalidate(11, editableFilters = migrateFilters(filters));
    }
    if ($$self.$$.dirty[0] & /*tables, datasource, schemaFields*/
    100663297) {
      {
        if (tables.find((table) => table._id === (datasource == null ? void 0 : datasource.tableId) && table.sourceId === DEFAULT_BB_DATASOURCE_ID) && !schemaFields.some((field) => field.name === "_id")) {
          $$invalidate(0, schemaFields = [...schemaFields, { name: "_id", type: "string" }]);
        }
      }
    }
    if ($$self.$$.dirty[0] & /*builderType*/
    16) {
      $$invalidate(13, prefix = builderType === "filter" ? "Show data which matches" : "Run branch when matching");
    }
    if ($$self.$$.dirty[0] & /*schemaFields*/
    1) {
      $$invalidate(12, fieldOptions = (schemaFields || []).filter((field) => !field.calculationType).map((field) => ({
        label: field.displayName || field.name,
        value: field.name
      })));
    }
  };
  return [
    schemaFields,
    behaviourFilters,
    allowBindings,
    allowOnEmpty,
    builderType,
    docsURL,
    bindings,
    panel,
    toReadable,
    toRuntime,
    evaluationContext,
    editableFilters,
    fieldOptions,
    prefix,
    $context,
    filterOperatorOptions,
    onEmptyOptions,
    context,
    onFieldChange,
    onOperatorChange,
    getValidOperatorsForType$1,
    getGroupPrefix,
    onFilterFieldUpdate,
    handleFilterChange,
    filters,
    tables,
    datasource,
    slots,
    change_handler,
    change_handler_1,
    click_handler,
    click_handler_1,
    change_handler_2,
    change_handler_3,
    change_handler_4,
    change_handler_5,
    click_handler_2,
    change_handler_6,
    click_handler_3,
    $$scope
  ];
}
class CoreFilterBuilder extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance$1,
      create_fragment$1,
      safe_not_equal,
      {
        schemaFields: 0,
        filters: 24,
        tables: 25,
        datasource: 26,
        behaviourFilters: 1,
        allowBindings: 2,
        allowOnEmpty: 3,
        builderType: 4,
        docsURL: 5,
        bindings: 6,
        panel: 7,
        toReadable: 8,
        toRuntime: 9,
        evaluationContext: 10
      },
      null,
      [-1, -1]
    );
  }
}
function create_if_block(ctx) {
  var _a, _b;
  let button;
  let t;
  let modal_1;
  let current;
  button = new Button$1({
    props: {
      onClick: (
        /*openEditor*/
        ctx[8]
      ),
      icon: "ri-filter-3-line",
      text: "Filter",
      size: (
        /*size*/
        ctx[0]
      ),
      type: "secondary",
      quiet: true,
      active: (
        /*filters*/
        ((_b = (_a = ctx[1]) == null ? void 0 : _a.groups) == null ? void 0 : _b.length) > 0
      )
    }
  });
  let modal_1_props = {
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  modal_1 = new Modal({ props: modal_1_props });
  ctx[19](modal_1);
  return {
    c() {
      create_component(button.$$.fragment);
      t = space();
      create_component(modal_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(button, target, anchor);
      insert(target, t, anchor);
      mount_component(modal_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2, _b2;
      const button_changes = {};
      if (dirty & /*size*/
      1)
        button_changes.size = /*size*/
        ctx2[0];
      if (dirty & /*filters*/
      2)
        button_changes.active = /*filters*/
        ((_b2 = (_a2 = ctx2[1]) == null ? void 0 : _a2.groups) == null ? void 0 : _b2.length) > 0;
      button.$set(button_changes);
      const modal_1_changes = {};
      if (dirty & /*$$scope, editableFilters, schemaFields, datasource*/
      134217812) {
        modal_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modal_1.$set(modal_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(button.$$.fragment, local);
      transition_in(modal_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(button.$$.fragment, local);
      transition_out(modal_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(button, detaching);
      ctx[19](null);
      destroy_component(modal_1, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let corefilterbuilder;
  let current;
  corefilterbuilder = new CoreFilterBuilder({
    props: {
      filters: (
        /*editableFilters*/
        ctx[4]
      ),
      schemaFields: (
        /*schemaFields*/
        ctx[6]
      ),
      datasource: (
        /*datasource*/
        ctx[2]
      ),
      filtersLabel: null
    }
  });
  corefilterbuilder.$on(
    "change",
    /*change_handler*/
    ctx[18]
  );
  return {
    c() {
      create_component(corefilterbuilder.$$.fragment);
    },
    m(target, anchor) {
      mount_component(corefilterbuilder, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const corefilterbuilder_changes = {};
      if (dirty & /*editableFilters*/
      16)
        corefilterbuilder_changes.filters = /*editableFilters*/
        ctx2[4];
      if (dirty & /*schemaFields*/
      64)
        corefilterbuilder_changes.schemaFields = /*schemaFields*/
        ctx2[6];
      if (dirty & /*datasource*/
      4)
        corefilterbuilder_changes.datasource = /*datasource*/
        ctx2[2];
      corefilterbuilder.$set(corefilterbuilder_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(corefilterbuilder.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(corefilterbuilder.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(corefilterbuilder, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let modalcontent;
  let current;
  modalcontent = new ModalContent({
    props: {
      title: "Edit filters",
      size: "XL",
      onConfirm: (
        /*updateQuery*/
        ctx[9]
      ),
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(modalcontent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(modalcontent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const modalcontent_changes = {};
      if (dirty & /*$$scope, editableFilters, schemaFields, datasource*/
      134217812) {
        modalcontent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      modalcontent.$set(modalcontent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(modalcontent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(modalcontent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(modalcontent, detaching);
    }
  };
}
function create_fragment(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*schemaLoaded*/
    ctx[5] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (
        /*schemaLoaded*/
        ctx2[5]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*schemaLoaded*/
          32) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let dataProviderId;
  let datasource;
  let isDSPlus;
  let addExtension;
  let removeExtension;
  let schemaFields;
  let filterCount;
  let $component;
  let { dataProvider } = $$props;
  let { allowedFields } = $$props;
  let { size = "M" } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(17, $component = value));
  const { builderStore, ActionTypes, getAction, fetchDatasourceSchema } = getContext("sdk");
  let modal2;
  let editableFilters;
  let filters;
  let schemaLoaded = false, schema;
  async function fetchSchema(datasource2) {
    if (datasource2) {
      $$invalidate(12, schema = await fetchDatasourceSchema(datasource2, { enrichRelationships: true }));
    }
    $$invalidate(5, schemaLoaded = true);
  }
  function getSchemaFields(schema2, allowedFields2) {
    if (!schemaLoaded) {
      return {};
    }
    let clonedSchema = {};
    if (!(allowedFields2 == null ? void 0 : allowedFields2.length)) {
      clonedSchema = schema2 || {};
    } else {
      allowedFields2 == null ? void 0 : allowedFields2.forEach((field) => {
        if (schema2 == null ? void 0 : schema2[field.name]) {
          clonedSchema[field.name] = schema2[field.name];
          clonedSchema[field.name].displayName = field.displayName;
        } else if (schema2 == null ? void 0 : schema2[field]) {
          clonedSchema[field] = schema2[field];
        }
      });
    }
    return Object.values(clonedSchema || {}).filter((field) => !BannedSearchTypes.includes(field.type)).concat(isDSPlus ? [{ name: "_id", type: "string" }] : []);
  }
  const openEditor = () => {
    if (get_store_value(builderStore).inBuilder) {
      return;
    }
    $$invalidate(4, editableFilters = filters ? cloneDeep(filters) : null);
    modal2.show();
  };
  const updateQuery = () => {
    $$invalidate(1, filters = parseFilter(editableFilters));
  };
  onDestroy(() => {
    removeExtension == null ? void 0 : removeExtension($component.id);
  });
  const change_handler = (e) => {
    $$invalidate(4, editableFilters = e.detail);
  };
  function modal_1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      modal2 = $$value;
      $$invalidate(3, modal2);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("dataProvider" in $$props2)
      $$invalidate(10, dataProvider = $$props2.dataProvider);
    if ("allowedFields" in $$props2)
      $$invalidate(11, allowedFields = $$props2.allowedFields);
    if ("size" in $$props2)
      $$invalidate(0, size = $$props2.size);
  };
  $$self.$$.update = () => {
    var _a;
    if ($$self.$$.dirty & /*dataProvider*/
    1024) {
      $$invalidate(16, dataProviderId = dataProvider == null ? void 0 : dataProvider.id);
    }
    if ($$self.$$.dirty & /*dataProvider*/
    1024) {
      $$invalidate(2, datasource = dataProvider == null ? void 0 : dataProvider.datasource);
    }
    if ($$self.$$.dirty & /*datasource*/
    4) {
      isDSPlus = ["table", "link", "viewV2"].includes(datasource == null ? void 0 : datasource.type);
    }
    if ($$self.$$.dirty & /*dataProviderId*/
    65536) {
      $$invalidate(14, addExtension = getAction(dataProviderId, ActionTypes.AddDataProviderQueryExtension));
    }
    if ($$self.$$.dirty & /*dataProviderId*/
    65536) {
      $$invalidate(13, removeExtension = getAction(dataProviderId, ActionTypes.RemoveDataProviderQueryExtension));
    }
    if ($$self.$$.dirty & /*datasource*/
    4) {
      fetchSchema(datasource);
    }
    if ($$self.$$.dirty & /*schema, allowedFields*/
    6144) {
      $$invalidate(6, schemaFields = getSchemaFields(schema, allowedFields));
    }
    if ($$self.$$.dirty & /*filters*/
    2) {
      $$invalidate(15, filterCount = (_a = filters == null ? void 0 : filters.groups) == null ? void 0 : _a.reduce(
        (acc, group) => {
          var _a2;
          acc += ((_a2 = group == null ? void 0 : group.filters) == null ? void 0 : _a2.length) || 0;
          return acc;
        },
        0
      ));
    }
    if ($$self.$$.dirty & /*filterCount, filters, addExtension, $component, removeExtension*/
    188418) {
      {
        if (filterCount) {
          const queryExtension = buildQuery(filters);
          delete queryExtension.onEmptyFilter;
          addExtension == null ? void 0 : addExtension($component.id, queryExtension);
        } else {
          removeExtension == null ? void 0 : removeExtension($component.id);
        }
      }
    }
  };
  return [
    size,
    filters,
    datasource,
    modal2,
    editableFilters,
    schemaLoaded,
    schemaFields,
    component,
    openEditor,
    updateQuery,
    dataProvider,
    allowedFields,
    schema,
    removeExtension,
    addExtension,
    filterCount,
    dataProviderId,
    $component,
    change_handler,
    modal_1_binding
  ];
}
class DynamicFilter extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      dataProvider: 10,
      allowedFields: 11,
      size: 0
    });
  }
}
export {
  DynamicFilter as default
};
