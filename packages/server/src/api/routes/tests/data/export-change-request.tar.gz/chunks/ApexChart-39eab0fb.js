import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, z as group_outros, n as transition_out, B as noop, A as check_outros, k as transition_in, o as detach, u as getContext, v as component_subscribe, e as element, a as space, b as attr, d as toggle_class, q as action_destroyer, h as is_function, W as binding_callbacks, I as Icon, c as create_component, t as text, m as mount_component, g as append, p as destroy_component } from "./index-a0738cd3.js";
const formatters = {
  ["Default"]: (val) => val,
  ["Thousands"]: (val) => `${Math.round(val / 1e3)}K`,
  ["Millions"]: (val) => `${Math.round(val / 1e6)}M`,
  ["Datetime"]: (val) => new Date(val).toLocaleString()
};
const parsePalette = (paletteName) => {
  if (paletteName === "Custom") {
    return null;
  }
  const [_, number] = paletteName.split(" ");
  return `palette${number}`;
};
const cloneDeep = (value) => {
  const typesToNaiveCopy = ["string", "boolean", "number", "function", "symbol"];
  if (value === null) {
    return null;
  }
  if (value === void 0) {
    return void 0;
  }
  if (typesToNaiveCopy.includes(typeof value)) {
    return value;
  }
  if (Array.isArray(value)) {
    return value.map((element2) => cloneDeep(element2));
  }
  if (typeof value === "object" && value.constructor.name === "Object") {
    const cloneObject = {};
    Object.entries(value).forEach(([key, childValue]) => {
      cloneObject[key] = cloneDeep(childValue);
    });
    return cloneObject;
  }
  throw `Unsupported value: "${value}" of type: "${typeof value}"`;
};
const ApexChart_svelte_svelte_type_style_lang = "";
function create_if_block(ctx) {
  let div;
  let icon;
  let t;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  icon = new Icon({
    props: {
      name: "warning",
      color: "var(--spectrum-global-color-static-red-600)"
    }
  });
  return {
    c() {
      div = element("div");
      create_component(icon.$$.fragment);
      t = text("\n      Add rows to your data source to start using your component");
      attr(div, "class", "component-placeholder svelte-sniduo");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon, div, null);
      append(div, t);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[5].call(null, div, {
          .../*$component*/
          ctx[3].styles,
          normal: {},
          custom: null,
          empty: true
        }));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      8)
        styleable_action.update.call(null, {
          .../*$component*/
          ctx2[3].styles,
          normal: {},
          custom: null,
          empty: true
        });
    },
    i(local) {
      if (current)
        return;
      transition_in(icon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon);
      mounted = false;
      dispose();
    }
  };
}
function create_key_block(ctx) {
  let div;
  let styleable_action;
  let t;
  let if_block_anchor;
  let current;
  let mounted;
  let dispose;
  let if_block = (
    /*$builderStore*/
    ctx[4].inBuilder && /*noData*/
    ctx[2] && create_if_block(ctx)
  );
  return {
    c() {
      div = element("div");
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
      attr(div, "class", "svelte-sniduo");
      toggle_class(
        div,
        "hide",
        /*noData*/
        ctx[2]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      ctx[9](div);
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[5].call(
          null,
          div,
          /*$component*/
          ctx[3].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      8)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[3].styles
        );
      if (!current || dirty & /*noData*/
      4) {
        toggle_class(
          div,
          "hide",
          /*noData*/
          ctx2[2]
        );
      }
      if (
        /*$builderStore*/
        ctx2[4].inBuilder && /*noData*/
        ctx2[2]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*$builderStore, noData*/
          20) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
        detach(t);
        detach(if_block_anchor);
      }
      ctx[9](null);
      if (if_block)
        if_block.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function create_fragment(ctx) {
  var _a;
  let previous_key = (
    /*optionsCopy*/
    (_a = ctx[1]) == null ? void 0 : _a.customColor
  );
  let key_block_anchor;
  let current;
  let key_block = create_key_block(ctx);
  return {
    c() {
      key_block.c();
      key_block_anchor = empty();
    },
    m(target, anchor) {
      key_block.m(target, anchor);
      insert(target, key_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      var _a2;
      if (dirty & /*optionsCopy*/
      2 && safe_not_equal(previous_key, previous_key = /*optionsCopy*/
      (_a2 = ctx2[1]) == null ? void 0 : _a2.customColor)) {
        group_outros();
        transition_out(key_block, 1, 1, noop);
        check_outros();
        key_block = create_key_block(ctx2);
        key_block.c();
        transition_in(key_block, 1);
        key_block.m(key_block_anchor.parentNode, key_block_anchor);
      } else {
        key_block.p(ctx2, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(key_block);
      current = true;
    },
    o(local) {
      transition_out(key_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(key_block_anchor);
      }
      key_block.d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let optionsCopy;
  let noData;
  let $component;
  let $builderStore;
  const { styleable, builderStore } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(4, $builderStore = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(3, $component = value));
  let { options } = $$props;
  let chartElement;
  let chart;
  let currentType = null;
  const updateChart = async (newOptions) => {
    var _a;
    if (((_a = newOptions == null ? void 0 : newOptions.xaxis) == null ? void 0 : _a.type) && newOptions.xaxis.type !== currentType) {
      await renderChart(chartElement);
    } else {
      await (chart == null ? void 0 : chart.updateOptions(newOptions));
    }
  };
  const renderChart = async (newChartElement) => {
    var _a;
    try {
      await (chart == null ? void 0 : chart.destroy());
      const { default: ApexCharts } = await import("./apexcharts.common-4a420431.js").then((n) => n.a);
      chart = new ApexCharts(newChartElement, optionsCopy);
      currentType = (_a = optionsCopy == null ? void 0 : optionsCopy.xaxis) == null ? void 0 : _a.type;
      await chart.render();
    } catch (e) {
      if (e.message !== "Cannot read properties of undefined (reading 'parentNode')") {
        throw e;
      }
    }
  };
  function div_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      chartElement = $$value;
      $$invalidate(0, chartElement);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("options" in $$props2)
      $$invalidate(8, options = $$props2.options);
  };
  $$self.$$.update = () => {
    var _a;
    if ($$self.$$.dirty & /*options*/
    256) {
      $$invalidate(1, optionsCopy = cloneDeep(options));
    }
    if ($$self.$$.dirty & /*optionsCopy*/
    2) {
      $$invalidate(2, noData = optionsCopy == null || ((_a = optionsCopy == null ? void 0 : optionsCopy.series) == null ? void 0 : _a.length) === 0);
    }
    if ($$self.$$.dirty & /*chartElement, noData*/
    5) {
      renderChart(chartElement);
    }
    if ($$self.$$.dirty & /*optionsCopy*/
    2) {
      updateChart(optionsCopy);
    }
  };
  return [
    chartElement,
    optionsCopy,
    noData,
    $component,
    $builderStore,
    styleable,
    builderStore,
    component,
    options,
    div_binding
  ];
}
class ApexChart extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { options: 8 });
  }
}
export {
  ApexChart as A,
  formatters as f,
  parsePalette as p
};
