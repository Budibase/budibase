import { S as SvelteComponent, i as init, s as safe_not_equal, K as Block, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component, bU as shortid, u as getContext, M as BlockComponent, az as get_store_value, bV as makePropSafe, W as binding_callbacks, a0 as bind, a as space, f as insert, a1 as add_flush_callback, o as detach, B as noop } from "./index-a0738cd3.js";
function create_default_slot_6(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "stringfield",
      props: {
        placeholder: "Search...",
        field: `${/*stateKey*/
        ctx[13]}-search`,
        onChange: [
          {
            parameters: {
              key: `${/*stateKey*/
              ctx[13]}-search`,
              type: "set",
              persist: null,
              value: `{{ ${makePropSafe("eventContext")}.${makePropSafe("value")} }}`
            },
            "##eventHandlerType": "Update State",
            id: 0
          }
        ]
      }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_5(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "spectrumcard",
      context: "repeater",
      props: {
        title: (
          /*cardTitle*/
          ctx[2]
        ),
        subtitle: (
          /*cardSubtitle*/
          ctx[3]
        ),
        description: (
          /*cardDescription*/
          ctx[4]
        ),
        imageURL: (
          /*cardImageURL*/
          ctx[5]
        ),
        horizontal: true,
        buttonOnClick: [
          {
            parameters: {
              key: (
                /*stateKey*/
                ctx[13]
              ),
              type: "set",
              persist: null,
              value: `{{ ${makePropSafe(
                /*listRepeaterId*/
                ctx[12]
              )}.${makePropSafe("_id")} }}`
            },
            "##eventHandlerType": "Update State",
            id: 0
          }
        ]
      },
      styles: { normal: { width: "auto" } }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*cardTitle, cardSubtitle, cardDescription, cardImageURL, listRepeaterId*/
      4156)
        blockcomponent_changes.props = {
          title: (
            /*cardTitle*/
            ctx2[2]
          ),
          subtitle: (
            /*cardSubtitle*/
            ctx2[3]
          ),
          description: (
            /*cardDescription*/
            ctx2[4]
          ),
          imageURL: (
            /*cardImageURL*/
            ctx2[5]
          ),
          horizontal: true,
          buttonOnClick: [
            {
              parameters: {
                key: (
                  /*stateKey*/
                  ctx2[13]
                ),
                type: "set",
                persist: null,
                value: `{{ ${makePropSafe(
                  /*listRepeaterId*/
                  ctx2[12]
                )}.${makePropSafe("_id")} }}`
              },
              "##eventHandlerType": "Update State",
              id: 0
            }
          ]
        };
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_4(ctx) {
  let blockcomponent0;
  let t;
  let blockcomponent1;
  let updating_id;
  let current;
  blockcomponent0 = new BlockComponent({
    props: {
      type: "form",
      order: 0,
      styles: { normal: { "margin-bottom": "12px" } },
      $$slots: { default: [create_default_slot_6] },
      $$scope: { ctx }
    }
  });
  function blockcomponent1_id_binding(value) {
    ctx[15](value);
  }
  let blockcomponent1_props = {
    type: "repeater",
    order: 1,
    context: "repeater",
    props: {
      dataProvider: `{{ literal ${makePropSafe(
        /*listDataProviderId*/
        ctx[11]
      )} }}`,
      direction: "column",
      gap: "S",
      noRowsMessage: (
        /*noRowsMessage*/
        ctx[9] || "No data"
      )
    },
    $$slots: { default: [create_default_slot_5] },
    $$scope: { ctx }
  };
  if (
    /*listRepeaterId*/
    ctx[12] !== void 0
  ) {
    blockcomponent1_props.id = /*listRepeaterId*/
    ctx[12];
  }
  blockcomponent1 = new BlockComponent({ props: blockcomponent1_props });
  binding_callbacks.push(() => bind(blockcomponent1, "id", blockcomponent1_id_binding));
  return {
    c() {
      create_component(blockcomponent0.$$.fragment);
      t = space();
      create_component(blockcomponent1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent0, target, anchor);
      insert(target, t, anchor);
      mount_component(blockcomponent1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent0_changes = {};
      if (dirty & /*$$scope*/
      524288) {
        blockcomponent0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent0.$set(blockcomponent0_changes);
      const blockcomponent1_changes = {};
      if (dirty & /*listDataProviderId, noRowsMessage*/
      2560)
        blockcomponent1_changes.props = {
          dataProvider: `{{ literal ${makePropSafe(
            /*listDataProviderId*/
            ctx2[11]
          )} }}`,
          direction: "column",
          gap: "S",
          noRowsMessage: (
            /*noRowsMessage*/
            ctx2[9] || "No data"
          )
        };
      if (dirty & /*$$scope, cardTitle, cardSubtitle, cardDescription, cardImageURL, listRepeaterId*/
      528444) {
        blockcomponent1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_id && dirty & /*listRepeaterId*/
      4096) {
        updating_id = true;
        blockcomponent1_changes.id = /*listRepeaterId*/
        ctx2[12];
        add_flush_callback(() => updating_id = false);
      }
      blockcomponent1.$set(blockcomponent1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent0.$$.fragment, local);
      transition_in(blockcomponent1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent0.$$.fragment, local);
      transition_out(blockcomponent1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(blockcomponent0, detaching);
      destroy_component(blockcomponent1, detaching);
    }
  };
}
function create_default_slot_3(ctx) {
  let blockcomponent0;
  let t;
  let blockcomponent1;
  let current;
  blockcomponent0 = new BlockComponent({
    props: {
      type: "icon",
      order: 0,
      props: {
        icon: "ri-list-check-2",
        size: "ri-2x",
        color: "var(--spectrum-global-color-gray-700)"
      },
      styles: { normal: { "margin-bottom": "12px" } }
    }
  });
  blockcomponent1 = new BlockComponent({
    props: {
      type: "textv2",
      order: 1,
      props: {
        text: "Select a row to view its fields",
        color: "var(--spectrum-global-color-gray-700)"
      }
    }
  });
  return {
    c() {
      create_component(blockcomponent0.$$.fragment);
      t = space();
      create_component(blockcomponent1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent0, target, anchor);
      insert(target, t, anchor);
      mount_component(blockcomponent1, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent0.$$.fragment, local);
      transition_in(blockcomponent1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent0.$$.fragment, local);
      transition_out(blockcomponent1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(blockcomponent0, detaching);
      destroy_component(blockcomponent1, detaching);
    }
  };
}
function create_default_slot_2(ctx) {
  let blockcomponent0;
  let t;
  let blockcomponent1;
  let current;
  blockcomponent0 = new BlockComponent({
    props: {
      type: "button",
      order: 0,
      props: {
        text: "← Back",
        onClick: [
          {
            parameters: {
              key: (
                /*stateKey*/
                ctx[13]
              ),
              type: "set",
              persist: null,
              value: ""
            },
            "##eventHandlerType": "Update State",
            id: 0
          }
        ]
      },
      styles: {
        custom: `
            align-self: flex-end;
            margin-bottom: 16px;
            {{#if (not ${makePropSafe("device")}.${makePropSafe("mobile")}) }}
              display: none;
            {{/if}}
            `
      }
    }
  });
  blockcomponent1 = new BlockComponent({
    props: {
      type: "formblock",
      order: 1,
      props: {
        showSaveButton: true,
        dataSource: (
          /*dataSource*/
          ctx[0]
        ),
        actionType: "Update",
        rowId: `{{ ${makePropSafe("state")}.${makePropSafe(
          /*stateKey*/
          ctx[13]
        )} }}`,
        fields: (
          /*detailFields*/
          ctx[7]
        ),
        title: (
          /*detailTitle*/
          ctx[8]
        )
      }
    }
  });
  return {
    c() {
      create_component(blockcomponent0.$$.fragment);
      t = space();
      create_component(blockcomponent1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent0, target, anchor);
      insert(target, t, anchor);
      mount_component(blockcomponent1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent1_changes = {};
      if (dirty & /*dataSource, detailFields, detailTitle*/
      385)
        blockcomponent1_changes.props = {
          showSaveButton: true,
          dataSource: (
            /*dataSource*/
            ctx2[0]
          ),
          actionType: "Update",
          rowId: `{{ ${makePropSafe("state")}.${makePropSafe(
            /*stateKey*/
            ctx2[13]
          )} }}`,
          fields: (
            /*detailFields*/
            ctx2[7]
          ),
          title: (
            /*detailTitle*/
            ctx2[8]
          )
        };
      blockcomponent1.$set(blockcomponent1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent0.$$.fragment, local);
      transition_in(blockcomponent1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent0.$$.fragment, local);
      transition_out(blockcomponent1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(blockcomponent0, detaching);
      destroy_component(blockcomponent1, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let blockcomponent0;
  let updating_id;
  let t0;
  let blockcomponent1;
  let t1;
  let blockcomponent2;
  let current;
  function blockcomponent0_id_binding(value) {
    ctx[16](value);
  }
  let blockcomponent0_props = {
    type: "dataprovider",
    order: 0,
    props: {
      dataSource: (
        /*dataSource*/
        ctx[0]
      ),
      paginate: true,
      limit: 10,
      filter: [
        {
          id: 0,
          field: (
            /*cardSearchField*/
            ctx[6]
          ),
          operator: "fuzzy",
          type: "string",
          value: `{{ ${makePropSafe("state")}.${makePropSafe(
            /*stateKey*/
            ctx[13] + "-search"
          )} }}`,
          valueType: "Binding",
          noValue: false
        }
      ],
      autoRefresh: (
        /*autoRefresh*/
        ctx[10]
      )
    },
    styles: {
      custom: `
          flex: 3;
          overflow: scroll;
          {{#if (and ${makePropSafe("state")}.${makePropSafe(
        /*stateKey*/
        ctx[13]
      )} ${makePropSafe("device")}.${makePropSafe("mobile")}) }}
            display: none;
          {{/if}}
        `
    },
    $$slots: { default: [create_default_slot_4] },
    $$scope: { ctx }
  };
  if (
    /*listDataProviderId*/
    ctx[11] !== void 0
  ) {
    blockcomponent0_props.id = /*listDataProviderId*/
    ctx[11];
  }
  blockcomponent0 = new BlockComponent({ props: blockcomponent0_props });
  binding_callbacks.push(() => bind(blockcomponent0, "id", blockcomponent0_id_binding));
  blockcomponent1 = new BlockComponent({
    props: {
      type: "container",
      order: 1,
      props: {
        hAlign: "center",
        vAlign: "middle",
        size: "grow",
        direction: "column"
      },
      styles: {
        custom: `
          padding: 20px;
          background-color: var(--spectrum-global-color-gray-50));
          border: 1px solid var(--spectrum-global-color-gray-300);
          border-radius: 4px;
          flex: 4;
          {{#if (or ${makePropSafe("state")}.${makePropSafe(
          /*stateKey*/
          ctx[13]
        )} ${makePropSafe("device")}.${makePropSafe("mobile")}) }}
            display: none;
          {{/if}}
          `
      },
      $$slots: { default: [create_default_slot_3] },
      $$scope: { ctx }
    }
  });
  blockcomponent2 = new BlockComponent({
    props: {
      type: "container",
      order: 2,
      props: {
        hAlign: "center",
        vAlign: "top",
        size: "grow",
        direction: "column"
      },
      styles: {
        custom: `
          background-color: var(--spectrum-global-color-gray-50));
          border: 1px solid var(--spectrum-global-color-gray-300);
          border-radius: 4px;
          padding: 20px;
          overflow-y: scroll;
          flex: 4;
          {{#if (isFalsey ${makePropSafe("state")}.${makePropSafe(
          /*stateKey*/
          ctx[13]
        )}) }}
            display: none;
          {{/if}}
          `
      },
      $$slots: { default: [create_default_slot_2] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent0.$$.fragment);
      t0 = space();
      create_component(blockcomponent1.$$.fragment);
      t1 = space();
      create_component(blockcomponent2.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent0, target, anchor);
      insert(target, t0, anchor);
      mount_component(blockcomponent1, target, anchor);
      insert(target, t1, anchor);
      mount_component(blockcomponent2, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent0_changes = {};
      if (dirty & /*dataSource, cardSearchField, autoRefresh*/
      1089)
        blockcomponent0_changes.props = {
          dataSource: (
            /*dataSource*/
            ctx2[0]
          ),
          paginate: true,
          limit: 10,
          filter: [
            {
              id: 0,
              field: (
                /*cardSearchField*/
                ctx2[6]
              ),
              operator: "fuzzy",
              type: "string",
              value: `{{ ${makePropSafe("state")}.${makePropSafe(
                /*stateKey*/
                ctx2[13] + "-search"
              )} }}`,
              valueType: "Binding",
              noValue: false
            }
          ],
          autoRefresh: (
            /*autoRefresh*/
            ctx2[10]
          )
        };
      if (dirty & /*$$scope, listDataProviderId, noRowsMessage, listRepeaterId, cardTitle, cardSubtitle, cardDescription, cardImageURL*/
      531004) {
        blockcomponent0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_id && dirty & /*listDataProviderId*/
      2048) {
        updating_id = true;
        blockcomponent0_changes.id = /*listDataProviderId*/
        ctx2[11];
        add_flush_callback(() => updating_id = false);
      }
      blockcomponent0.$set(blockcomponent0_changes);
      const blockcomponent1_changes = {};
      if (dirty & /*$$scope*/
      524288) {
        blockcomponent1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent1.$set(blockcomponent1_changes);
      const blockcomponent2_changes = {};
      if (dirty & /*$$scope, dataSource, detailFields, detailTitle*/
      524673) {
        blockcomponent2_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent2.$set(blockcomponent2_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent0.$$.fragment, local);
      transition_in(blockcomponent1.$$.fragment, local);
      transition_in(blockcomponent2.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent0.$$.fragment, local);
      transition_out(blockcomponent1.$$.fragment, local);
      transition_out(blockcomponent2.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
      destroy_component(blockcomponent0, detaching);
      destroy_component(blockcomponent1, detaching);
      destroy_component(blockcomponent2, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "container",
      props: { direction: "row", gap: "M" },
      styles: {
        custom: `
        height: ${/*height*/
        ctx[1]} !important;
      `
      },
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*height*/
      2)
        blockcomponent_changes.styles = {
          custom: `
        height: ${/*height*/
          ctx2[1]} !important;
      `
        };
      if (dirty & /*$$scope, dataSource, detailFields, detailTitle, cardSearchField, autoRefresh, listDataProviderId, noRowsMessage, listRepeaterId, cardTitle, cardSubtitle, cardDescription, cardImageURL*/
      532477) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_fragment(ctx) {
  let block;
  let current;
  block = new Block({
    props: {
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(block.$$.fragment);
    },
    m(target, anchor) {
      mount_component(block, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const block_changes = {};
      if (dirty & /*$$scope, height, dataSource, detailFields, detailTitle, cardSearchField, autoRefresh, listDataProviderId, noRowsMessage, listRepeaterId, cardTitle, cardSubtitle, cardDescription, cardImageURL*/
      532479) {
        block_changes.$$scope = { dirty, ctx: ctx2 };
      }
      block.$set(block_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(block.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(block.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(block, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { dataSource } = $$props;
  let { height } = $$props;
  let { cardTitle } = $$props;
  let { cardSubtitle } = $$props;
  let { cardDescription } = $$props;
  let { cardImageURL } = $$props;
  let { cardSearchField } = $$props;
  let { detailFields } = $$props;
  let { detailTitle } = $$props;
  let { noRowsMessage } = $$props;
  let { autoRefresh } = $$props;
  const stateKey = shortid.generate();
  const context = getContext("context");
  const { generateGoldenSample } = getContext("sdk");
  let listDataProviderId;
  let listRepeaterId;
  const getAdditionalDataContext = () => {
    var _a;
    const rows = ((_a = get_store_value(context)[listDataProviderId]) == null ? void 0 : _a.rows) || [];
    const goldenRow = generateGoldenSample(rows);
    return { [listRepeaterId]: goldenRow };
  };
  function blockcomponent1_id_binding(value) {
    listRepeaterId = value;
    $$invalidate(12, listRepeaterId);
  }
  function blockcomponent0_id_binding(value) {
    listDataProviderId = value;
    $$invalidate(11, listDataProviderId);
  }
  $$self.$$set = ($$props2) => {
    if ("dataSource" in $$props2)
      $$invalidate(0, dataSource = $$props2.dataSource);
    if ("height" in $$props2)
      $$invalidate(1, height = $$props2.height);
    if ("cardTitle" in $$props2)
      $$invalidate(2, cardTitle = $$props2.cardTitle);
    if ("cardSubtitle" in $$props2)
      $$invalidate(3, cardSubtitle = $$props2.cardSubtitle);
    if ("cardDescription" in $$props2)
      $$invalidate(4, cardDescription = $$props2.cardDescription);
    if ("cardImageURL" in $$props2)
      $$invalidate(5, cardImageURL = $$props2.cardImageURL);
    if ("cardSearchField" in $$props2)
      $$invalidate(6, cardSearchField = $$props2.cardSearchField);
    if ("detailFields" in $$props2)
      $$invalidate(7, detailFields = $$props2.detailFields);
    if ("detailTitle" in $$props2)
      $$invalidate(8, detailTitle = $$props2.detailTitle);
    if ("noRowsMessage" in $$props2)
      $$invalidate(9, noRowsMessage = $$props2.noRowsMessage);
    if ("autoRefresh" in $$props2)
      $$invalidate(10, autoRefresh = $$props2.autoRefresh);
  };
  return [
    dataSource,
    height,
    cardTitle,
    cardSubtitle,
    cardDescription,
    cardImageURL,
    cardSearchField,
    detailFields,
    detailTitle,
    noRowsMessage,
    autoRefresh,
    listDataProviderId,
    listRepeaterId,
    stateKey,
    getAdditionalDataContext,
    blockcomponent1_id_binding,
    blockcomponent0_id_binding
  ];
}
class RowExplorer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      dataSource: 0,
      height: 1,
      cardTitle: 2,
      cardSubtitle: 3,
      cardDescription: 4,
      cardImageURL: 5,
      cardSearchField: 6,
      detailFields: 7,
      detailTitle: 8,
      noRowsMessage: 9,
      autoRefresh: 10,
      getAdditionalDataContext: 14
    });
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[14];
  }
}
export {
  RowExplorer as default
};
