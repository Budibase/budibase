import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, B as noop, o as detach, u as getContext, v as component_subscribe, W as binding_callbacks, e as element, t as text, b as attr, d as toggle_class, g as append, q as action_destroyer, l as listen, h as is_function, ak as set_data_contenteditable, r as run_all, j as set_data } from "./index-a0738cd3.js";
const Link_svelte_svelte_type_style_lang = "";
function create_if_block_1(ctx) {
  let if_block_anchor;
  function select_block_type_1(ctx2, dirty) {
    if (
      /*externalLink*/
      ctx2[7] || /*openInNewTab*/
      ctx2[0]
    )
      return create_if_block_2;
    return create_else_block;
  }
  let current_block_type = select_block_type_1(ctx);
  let if_block = current_block_type(ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (current_block_type === (current_block_type = select_block_type_1(ctx2)) && if_block) {
        if_block.p(ctx2, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx2);
        if (if_block) {
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      }
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_block.d(detaching);
    }
  };
}
function create_if_block(ctx) {
  let div;
  let t;
  let div_class_value;
  let styleable_action;
  let mounted;
  let dispose;
  return {
    c() {
      div = element("div");
      t = text(
        /*componentText*/
        ctx[13]
      );
      attr(div, "contenteditable", "");
      attr(div, "class", div_class_value = "align--" + /*align*/
      (ctx[1] || "left") + " size--" + /*size*/
      (ctx[5] || "M") + " svelte-1dqdd23");
      toggle_class(
        div,
        "bold",
        /*bold*/
        ctx[2]
      );
      toggle_class(
        div,
        "italic",
        /*italic*/
        ctx[3]
      );
      toggle_class(
        div,
        "underline",
        /*underline*/
        ctx[4]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
      ctx[25](div);
      if (!mounted) {
        dispose = [
          action_destroyer(styleable_action = /*styleable*/
          ctx[17].call(
            null,
            div,
            /*styles*/
            ctx[11]
          )),
          listen(div, "blur", function() {
            if (is_function(
              /*$component*/
              ctx[8].editing ? (
                /*updateText*/
                ctx[21]
              ) : null
            ))
              /*$component*/
              (ctx[8].editing ? (
                /*updateText*/
                ctx[21]
              ) : null).apply(this, arguments);
          }),
          listen(
            div,
            "input",
            /*input_handler*/
            ctx[26]
          )
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty[0] & /*componentText*/
      8192)
        set_data_contenteditable(
          t,
          /*componentText*/
          ctx[13]
        );
      if (dirty[0] & /*align, size*/
      34 && div_class_value !== (div_class_value = "align--" + /*align*/
      (ctx[1] || "left") + " size--" + /*size*/
      (ctx[5] || "M") + " svelte-1dqdd23")) {
        attr(div, "class", div_class_value);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty[0] & /*styles*/
      2048)
        styleable_action.update.call(
          null,
          /*styles*/
          ctx[11]
        );
      if (dirty[0] & /*align, size, bold*/
      38) {
        toggle_class(
          div,
          "bold",
          /*bold*/
          ctx[2]
        );
      }
      if (dirty[0] & /*align, size, italic*/
      42) {
        toggle_class(
          div,
          "italic",
          /*italic*/
          ctx[3]
        );
      }
      if (dirty[0] & /*align, size, underline*/
      50) {
        toggle_class(
          div,
          "underline",
          /*underline*/
          ctx[4]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      ctx[25](null);
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_else_block(ctx) {
  let previous_key = (
    /*sanitizedUrl*/
    ctx[12]
  );
  let key_block_anchor;
  let key_block = create_key_block(ctx);
  return {
    c() {
      key_block.c();
      key_block_anchor = empty();
    },
    m(target, anchor) {
      key_block.m(target, anchor);
      insert(target, key_block_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*sanitizedUrl*/
      4096 && safe_not_equal(previous_key, previous_key = /*sanitizedUrl*/
      ctx2[12])) {
        key_block.d(1);
        key_block = create_key_block(ctx2);
        key_block.c();
        key_block.m(key_block_anchor.parentNode, key_block_anchor);
      } else {
        key_block.p(ctx2, dirty);
      }
    },
    d(detaching) {
      if (detaching) {
        detach(key_block_anchor);
      }
      key_block.d(detaching);
    }
  };
}
function create_if_block_2(ctx) {
  let a;
  let t;
  let a_class_value;
  let styleable_action;
  let mounted;
  let dispose;
  return {
    c() {
      a = element("a");
      t = text(
        /*componentText*/
        ctx[13]
      );
      attr(
        a,
        "target",
        /*target*/
        ctx[15]
      );
      attr(
        a,
        "href",
        /*sanitizedUrl*/
        ctx[12]
      );
      attr(a, "class", a_class_value = "align--" + /*align*/
      (ctx[1] || "left") + " size--" + /*size*/
      (ctx[5] || "M") + " svelte-1dqdd23");
      toggle_class(
        a,
        "placeholder",
        /*placeholder*/
        ctx[14]
      );
      toggle_class(
        a,
        "bold",
        /*bold*/
        ctx[2]
      );
      toggle_class(
        a,
        "italic",
        /*italic*/
        ctx[3]
      );
      toggle_class(
        a,
        "underline",
        /*underline*/
        ctx[4]
      );
    },
    m(target, anchor) {
      insert(target, a, anchor);
      append(a, t);
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[17].call(
          null,
          a,
          /*styles*/
          ctx[11]
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*componentText*/
      8192)
        set_data(
          t,
          /*componentText*/
          ctx2[13]
        );
      if (dirty[0] & /*target*/
      32768) {
        attr(
          a,
          "target",
          /*target*/
          ctx2[15]
        );
      }
      if (dirty[0] & /*sanitizedUrl*/
      4096) {
        attr(
          a,
          "href",
          /*sanitizedUrl*/
          ctx2[12]
        );
      }
      if (dirty[0] & /*align, size*/
      34 && a_class_value !== (a_class_value = "align--" + /*align*/
      (ctx2[1] || "left") + " size--" + /*size*/
      (ctx2[5] || "M") + " svelte-1dqdd23")) {
        attr(a, "class", a_class_value);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty[0] & /*styles*/
      2048)
        styleable_action.update.call(
          null,
          /*styles*/
          ctx2[11]
        );
      if (dirty[0] & /*align, size, placeholder*/
      16418) {
        toggle_class(
          a,
          "placeholder",
          /*placeholder*/
          ctx2[14]
        );
      }
      if (dirty[0] & /*align, size, bold*/
      38) {
        toggle_class(
          a,
          "bold",
          /*bold*/
          ctx2[2]
        );
      }
      if (dirty[0] & /*align, size, italic*/
      42) {
        toggle_class(
          a,
          "italic",
          /*italic*/
          ctx2[3]
        );
      }
      if (dirty[0] & /*align, size, underline*/
      50) {
        toggle_class(
          a,
          "underline",
          /*underline*/
          ctx2[4]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(a);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_key_block(ctx) {
  let a;
  let t;
  let a_class_value;
  let styleable_action;
  let mounted;
  let dispose;
  return {
    c() {
      a = element("a");
      t = text(
        /*componentText*/
        ctx[13]
      );
      attr(
        a,
        "href",
        /*sanitizedUrl*/
        ctx[12]
      );
      attr(a, "class", a_class_value = "align--" + /*align*/
      (ctx[1] || "left") + " size--" + /*size*/
      (ctx[5] || "M") + " svelte-1dqdd23");
      toggle_class(
        a,
        "placeholder",
        /*placeholder*/
        ctx[14]
      );
      toggle_class(
        a,
        "bold",
        /*bold*/
        ctx[2]
      );
      toggle_class(
        a,
        "italic",
        /*italic*/
        ctx[3]
      );
      toggle_class(
        a,
        "underline",
        /*underline*/
        ctx[4]
      );
    },
    m(target, anchor) {
      insert(target, a, anchor);
      append(a, t);
      if (!mounted) {
        dispose = [
          action_destroyer(
            /*linkable*/
            ctx[16].call(null, a)
          ),
          action_destroyer(styleable_action = /*styleable*/
          ctx[17].call(
            null,
            a,
            /*styles*/
            ctx[11]
          )),
          listen(
            a,
            "click",
            /*handleUrlChange*/
            ctx[20]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*componentText*/
      8192)
        set_data(
          t,
          /*componentText*/
          ctx2[13]
        );
      if (dirty[0] & /*sanitizedUrl*/
      4096) {
        attr(
          a,
          "href",
          /*sanitizedUrl*/
          ctx2[12]
        );
      }
      if (dirty[0] & /*align, size*/
      34 && a_class_value !== (a_class_value = "align--" + /*align*/
      (ctx2[1] || "left") + " size--" + /*size*/
      (ctx2[5] || "M") + " svelte-1dqdd23")) {
        attr(a, "class", a_class_value);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty[0] & /*styles*/
      2048)
        styleable_action.update.call(
          null,
          /*styles*/
          ctx2[11]
        );
      if (dirty[0] & /*align, size, placeholder*/
      16418) {
        toggle_class(
          a,
          "placeholder",
          /*placeholder*/
          ctx2[14]
        );
      }
      if (dirty[0] & /*align, size, bold*/
      38) {
        toggle_class(
          a,
          "bold",
          /*bold*/
          ctx2[2]
        );
      }
      if (dirty[0] & /*align, size, italic*/
      42) {
        toggle_class(
          a,
          "italic",
          /*italic*/
          ctx2[3]
        );
      }
      if (dirty[0] & /*align, size, underline*/
      50) {
        toggle_class(
          a,
          "underline",
          /*underline*/
          ctx2[4]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(a);
      }
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_fragment(ctx) {
  let if_block_anchor;
  function select_block_type(ctx2, dirty) {
    if (
      /*$component*/
      ctx2[8].editing
    )
      return create_if_block;
    if (
      /*$builderStore*/
      ctx2[9].inBuilder || /*componentText*/
      ctx2[13]
    )
      return create_if_block_1;
  }
  let current_block_type = select_block_type(ctx);
  let if_block = current_block_type && current_block_type(ctx);
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (current_block_type === (current_block_type = select_block_type(ctx2)) && if_block) {
        if_block.p(ctx2, dirty);
      } else {
        if (if_block)
          if_block.d(1);
        if_block = current_block_type && current_block_type(ctx2);
        if (if_block) {
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block) {
        if_block.d(detaching);
      }
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let externalLink;
  let target;
  let placeholder;
  let componentText;
  let sanitizedUrl;
  let styles;
  let $component;
  let $builderStore;
  const { linkable, styleable, builderStore, sidePanelStore, modalStore } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(9, $builderStore = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(8, $component = value));
  let { url } = $$props;
  let { text: text2 } = $$props;
  let { openInNewTab } = $$props;
  let { color } = $$props;
  let { align } = $$props;
  let { bold } = $$props;
  let { italic } = $$props;
  let { underline } = $$props;
  let { size } = $$props;
  let node;
  let touched = false;
  const handleUrlChange = () => {
    sidePanelStore.actions.close();
    modalStore.actions.close();
  };
  const getSanitizedUrl = (url2, externalLink2, newTab) => {
    if (!url2) {
      return externalLink2 || newTab ? "#/" : "/";
    }
    if (externalLink2) {
      return url2;
    }
    if (openInNewTab) {
      return `#${url2}`;
    }
    return url2;
  };
  const getComponentText = (text3, builderState, componentState) => {
    if (!builderState.inBuilder || componentState.editing) {
      return text3 || "";
    }
    return text3 || componentState.name || "Placeholder text";
  };
  const enrichStyles = (styles2, color2) => {
    if (!color2) {
      return styles2;
    }
    return {
      ...styles2,
      normal: { ...styles2 == null ? void 0 : styles2.normal, color: color2 }
    };
  };
  const updateText = (e) => {
    if (touched) {
      builderStore.actions.updateProp("text", e.target.textContent);
    }
    $$invalidate(10, touched = false);
  };
  function div_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      node = $$value;
      $$invalidate(6, node);
    });
  }
  const input_handler = () => $$invalidate(10, touched = true);
  $$self.$$set = ($$props2) => {
    if ("url" in $$props2)
      $$invalidate(22, url = $$props2.url);
    if ("text" in $$props2)
      $$invalidate(23, text2 = $$props2.text);
    if ("openInNewTab" in $$props2)
      $$invalidate(0, openInNewTab = $$props2.openInNewTab);
    if ("color" in $$props2)
      $$invalidate(24, color = $$props2.color);
    if ("align" in $$props2)
      $$invalidate(1, align = $$props2.align);
    if ("bold" in $$props2)
      $$invalidate(2, bold = $$props2.bold);
    if ("italic" in $$props2)
      $$invalidate(3, italic = $$props2.italic);
    if ("underline" in $$props2)
      $$invalidate(4, underline = $$props2.underline);
    if ("size" in $$props2)
      $$invalidate(5, size = $$props2.size);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*$component, node*/
    320) {
      $component.editing && (node == null ? void 0 : node.focus());
    }
    if ($$self.$$.dirty[0] & /*url*/
    4194304) {
      $$invalidate(7, externalLink = url && typeof url === "string" && !url.startsWith("/"));
    }
    if ($$self.$$.dirty[0] & /*openInNewTab*/
    1) {
      $$invalidate(15, target = openInNewTab ? "_blank" : "_self");
    }
    if ($$self.$$.dirty[0] & /*$builderStore, text*/
    8389120) {
      $$invalidate(14, placeholder = $builderStore.inBuilder && !text2);
    }
    if ($$self.$$.dirty[0] & /*text, $builderStore, $component*/
    8389376) {
      $$invalidate(13, componentText = getComponentText(text2, $builderStore, $component));
    }
    if ($$self.$$.dirty[0] & /*url, externalLink, openInNewTab*/
    4194433) {
      $$invalidate(12, sanitizedUrl = getSanitizedUrl(url, externalLink, openInNewTab));
    }
    if ($$self.$$.dirty[0] & /*$component, color*/
    16777472) {
      $$invalidate(11, styles = enrichStyles($component.styles, color));
    }
  };
  return [
    openInNewTab,
    align,
    bold,
    italic,
    underline,
    size,
    node,
    externalLink,
    $component,
    $builderStore,
    touched,
    styles,
    sanitizedUrl,
    componentText,
    placeholder,
    target,
    linkable,
    styleable,
    builderStore,
    component,
    handleUrlChange,
    updateText,
    url,
    text2,
    color,
    div_binding,
    input_handler
  ];
}
class Link extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        url: 22,
        text: 23,
        openInNewTab: 0,
        color: 24,
        align: 1,
        bold: 2,
        italic: 3,
        underline: 4,
        size: 5
      },
      null,
      [-1, -1]
    );
  }
}
export {
  Link as default
};
