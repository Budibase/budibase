import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, z as group_outros, n as transition_out, A as check_outros, k as transition_in, o as detach, u as getContext, v as component_subscribe, X as setContext, B as noop, C as subscribe, a3 as writable, F as create_slot, e as element, q as action_destroyer, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, h as is_function, c as create_component, m as mount_component, p as destroy_component } from "./index-a0738cd3.js";
import Placeholder from "./Placeholder-31706623.js";
function create_if_block_1(ctx) {
  let div;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[13].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[12],
    null
  );
  return {
    c() {
      div = element("div");
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (default_slot) {
        default_slot.m(div, null);
      }
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[4].call(
          null,
          div,
          /*$component*/
          ctx[1].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        4096)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[12],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[12]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[12],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      2)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[1].styles
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block(ctx) {
  let placeholder;
  let current;
  placeholder = new Placeholder({
    props: {
      text: "Form steps need to be wrapped in a form"
    }
  });
  return {
    c() {
      create_component(placeholder.$$.fragment);
    },
    m(target, anchor) {
      mount_component(placeholder, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(placeholder.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(placeholder.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(placeholder, detaching);
    }
  };
}
function create_fragment(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block, create_if_block_1];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (!/*formContext*/
    ctx2[8])
      return 0;
    if (
      /*step*/
      ctx2[0] === /*currentStep*/
      ctx2[2]
    )
      return 1;
    return -1;
  }
  if (~(current_block_type_index = select_block_type(ctx))) {
    if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  }
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].m(target, anchor);
      }
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if (~current_block_type_index) {
          if_blocks[current_block_type_index].p(ctx2, dirty);
        }
      } else {
        if (if_block) {
          group_outros();
          transition_out(if_blocks[previous_block_index], 1, 1, () => {
            if_blocks[previous_block_index] = null;
          });
          check_outros();
        }
        if (~current_block_type_index) {
          if_block = if_blocks[current_block_type_index];
          if (!if_block) {
            if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
            if_block.c();
          } else {
            if_block.p(ctx2, dirty);
          }
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        } else {
          if_block = null;
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].d(detaching);
      }
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let formState;
  let currentStep;
  let $component;
  let $componentStore;
  let $builderStore;
  let $formState, $$unsubscribe_formState = noop, $$subscribe_formState = () => ($$unsubscribe_formState(), $$unsubscribe_formState = subscribe(formState, ($$value) => $$invalidate(11, $formState = $$value)), formState);
  $$self.$$.on_destroy.push(() => $$unsubscribe_formState());
  let { $$slots: slots = {}, $$scope } = $$props;
  let { step = 1 } = $$props;
  const { styleable, builderStore, componentStore } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(10, $builderStore = value));
  component_subscribe($$self, componentStore, (value) => $$invalidate(9, $componentStore = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(1, $component = value));
  const formContext = getContext("form");
  const stepStore = writable(step || 1);
  setContext("form-step", stepStore);
  $$self.$$set = ($$props2) => {
    if ("step" in $$props2)
      $$invalidate(0, step = $$props2.step);
    if ("$$scope" in $$props2)
      $$invalidate(12, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    var _a;
    if ($$self.$$.dirty & /*step*/
    1) {
      stepStore.set(step || 1);
    }
    if ($$self.$$.dirty & /*$formState*/
    2048) {
      $$invalidate(2, currentStep = $formState == null ? void 0 : $formState.currentStep);
    }
    if ($$self.$$.dirty & /*$builderStore, $componentStore, $component, step*/
    1539) {
      {
        if (formContext && $builderStore.inBuilder && ((_a = $componentStore.selectedComponentPath) == null ? void 0 : _a.includes($component.id))) {
          formContext.formApi.setStep(step);
        }
      }
    }
  };
  $$subscribe_formState($$invalidate(3, formState = formContext == null ? void 0 : formContext.formState));
  return [
    step,
    $component,
    currentStep,
    formState,
    styleable,
    builderStore,
    componentStore,
    component,
    formContext,
    $componentStore,
    $builderStore,
    $formState,
    $$scope,
    slots
  ];
}
class FormStep extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { step: 0 });
  }
}
export {
  FormStep as default
};
