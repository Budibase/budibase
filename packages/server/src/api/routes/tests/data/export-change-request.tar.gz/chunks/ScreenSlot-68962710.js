import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, b as attr, f as insert, q as action_destroyer, h as is_function, B as noop, o as detach, u as getContext, v as component_subscribe } from "./index-a0738cd3.js";
const ScreenSlot_svelte_svelte_type_style_lang = "";
function create_fragment(ctx) {
  let div;
  let styleable_action;
  let mounted;
  let dispose;
  return {
    c() {
      div = element("div");
      div.innerHTML = `<h1 class="svelte-ku38cm">Screen Slot</h1> <span class="svelte-ku38cm">The screens that you create will be displayed inside this box.
    <br/>
    This box is just a placeholder, to show you the position of screens.</span>`;
      attr(div, "class", "svelte-ku38cm");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[1].call(null, div, {
          .../*$component*/
          ctx[0].styles,
          empty: true
        }));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      1)
        styleable_action.update.call(null, {
          .../*$component*/
          ctx2[0].styles,
          empty: true
        });
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $component;
  const { styleable } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(0, $component = value));
  return [$component, styleable, component];
}
class ScreenSlot extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {});
  }
}
export {
  ScreenSlot as default
};
