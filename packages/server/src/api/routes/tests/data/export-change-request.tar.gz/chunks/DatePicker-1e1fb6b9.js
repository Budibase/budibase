import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, a as space, b as attr, d as toggle_class, f as insert, g as append, l as listen, k as transition_in, z as group_outros, n as transition_out, A as check_outros, o as detach, bI as getDateDisplayValue, I as Icon, c as create_component, m as mount_component, p as destroy_component, V as bubble, W as binding_callbacks, a0 as bind, h as is_function, $ as Popover, a1 as add_flush_callback, bC as PopoverAlignment, U as onMount, bA as parseDate, y as empty, c3 as DatePickerPopoverContents } from "./index-a0738cd3.js";
function create_if_block_1(ctx) {
  let div;
  let icon_1;
  let current;
  icon_1 = new Icon({
    props: {
      name: "warning",
      color: "var(--spectrum-semantic-negative-color-icon)"
    }
  });
  return {
    c() {
      div = element("div");
      create_component(icon_1.$$.fragment);
      attr(div, "class", "error-icon svelte-1eqovy0");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(icon_1, div, null);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(icon_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(icon_1);
    }
  };
}
function create_if_block$1(ctx) {
  let button;
  let icon_1;
  let current;
  icon_1 = new Icon({ props: { name: (
    /*icon*/
    ctx[7]
  ) } });
  return {
    c() {
      button = element("button");
      create_component(icon_1.$$.fragment);
      attr(button, "type", "button");
      attr(button, "class", "spectrum-Picker spectrum-Picker--sizeM spectrum-InputGroup-button");
      attr(button, "tabindex", "-1");
      toggle_class(button, "is-invalid", !!/*error*/
      ctx[3]);
    },
    m(target, anchor) {
      insert(target, button, anchor);
      mount_component(icon_1, button, null);
      current = true;
    },
    p(ctx2, dirty) {
      const icon_1_changes = {};
      if (dirty & /*icon*/
      128)
        icon_1_changes.name = /*icon*/
        ctx2[7];
      icon_1.$set(icon_1_changes);
      if (!current || dirty & /*error*/
      8) {
        toggle_class(button, "is-invalid", !!/*error*/
        ctx2[3]);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      destroy_component(icon_1);
    }
  };
}
function create_fragment$1(ctx) {
  let div1;
  let div0;
  let t0;
  let input;
  let t1;
  let current;
  let mounted;
  let dispose;
  let if_block0 = !!/*error*/
  ctx[3] && create_if_block_1();
  let if_block1 = !/*disabled*/
  ctx[1] && !/*readonly*/
  ctx[2] && create_if_block$1(ctx);
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      if (if_block0)
        if_block0.c();
      t0 = space();
      input = element("input");
      t1 = space();
      if (if_block1)
        if_block1.c();
      input.disabled = /*disabled*/
      ctx[1];
      input.readOnly = /*readonly*/
      ctx[2];
      attr(input, "data-input", "");
      attr(input, "type", "text");
      attr(input, "class", "spectrum-Textfield-input spectrum-InputGroup-input svelte-1eqovy0");
      attr(
        input,
        "placeholder",
        /*placeholder*/
        ctx[5]
      );
      attr(
        input,
        "id",
        /*id*/
        ctx[6]
      );
      input.value = /*displayValue*/
      ctx[8];
      toggle_class(
        input,
        "is-disabled",
        /*disabled*/
        ctx[1]
      );
      attr(div0, "class", "spectrum-Textfield spectrum-InputGroup-textfield svelte-1eqovy0");
      toggle_class(
        div0,
        "is-disabled",
        /*disabled*/
        ctx[1]
      );
      toggle_class(div0, "is-invalid", !!/*error*/
      ctx[3]);
      attr(div1, "class", "spectrum-InputGroup spectrum-Datepicker svelte-1eqovy0");
      attr(
        div1,
        "aria-readonly",
        /*readonly*/
        ctx[2]
      );
      attr(div1, "aria-required", "false");
      attr(div1, "aria-haspopup", "true");
      toggle_class(
        div1,
        "is-disabled",
        /*disabled*/
        ctx[1] || /*readonly*/
        ctx[2]
      );
      toggle_class(div1, "is-invalid", !!/*error*/
      ctx[3]);
      toggle_class(
        div1,
        "is-focused",
        /*focused*/
        ctx[4]
      );
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      if (if_block0)
        if_block0.m(div0, null);
      append(div0, t0);
      append(div0, input);
      append(div1, t1);
      if (if_block1)
        if_block1.m(div1, null);
      ctx[13](div1);
      current = true;
      if (!mounted) {
        dispose = listen(
          div1,
          "click",
          /*click_handler*/
          ctx[12]
        );
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (!!/*error*/
      ctx2[3]) {
        if (if_block0) {
          if (dirty & /*error*/
          8) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_1();
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(div0, t0);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (!current || dirty & /*disabled*/
      2) {
        input.disabled = /*disabled*/
        ctx2[1];
      }
      if (!current || dirty & /*readonly*/
      4) {
        input.readOnly = /*readonly*/
        ctx2[2];
      }
      if (!current || dirty & /*placeholder*/
      32) {
        attr(
          input,
          "placeholder",
          /*placeholder*/
          ctx2[5]
        );
      }
      if (!current || dirty & /*id*/
      64) {
        attr(
          input,
          "id",
          /*id*/
          ctx2[6]
        );
      }
      if (!current || dirty & /*displayValue*/
      256 && input.value !== /*displayValue*/
      ctx2[8]) {
        input.value = /*displayValue*/
        ctx2[8];
      }
      if (!current || dirty & /*disabled*/
      2) {
        toggle_class(
          input,
          "is-disabled",
          /*disabled*/
          ctx2[1]
        );
      }
      if (!current || dirty & /*disabled*/
      2) {
        toggle_class(
          div0,
          "is-disabled",
          /*disabled*/
          ctx2[1]
        );
      }
      if (!current || dirty & /*error*/
      8) {
        toggle_class(div0, "is-invalid", !!/*error*/
        ctx2[3]);
      }
      if (!/*disabled*/
      ctx2[1] && !/*readonly*/
      ctx2[2]) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty & /*disabled, readonly*/
          6) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block$1(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div1, null);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if (!current || dirty & /*readonly*/
      4) {
        attr(
          div1,
          "aria-readonly",
          /*readonly*/
          ctx2[2]
        );
      }
      if (!current || dirty & /*disabled, readonly*/
      6) {
        toggle_class(
          div1,
          "is-disabled",
          /*disabled*/
          ctx2[1] || /*readonly*/
          ctx2[2]
        );
      }
      if (!current || dirty & /*error*/
      8) {
        toggle_class(div1, "is-invalid", !!/*error*/
        ctx2[3]);
      }
      if (!current || dirty & /*focused*/
      16) {
        toggle_class(
          div1,
          "is-focused",
          /*focused*/
          ctx2[4]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
      ctx[13](null);
      mounted = false;
      dispose();
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let displayValue;
  let { anchor } = $$props;
  let { disabled } = $$props;
  let { readonly } = $$props;
  let { error } = $$props;
  let { focused } = $$props;
  let { placeholder } = $$props;
  let { id } = $$props;
  let { value } = $$props;
  let { icon } = $$props;
  let { enableTime } = $$props;
  let { timeOnly } = $$props;
  function click_handler(event) {
    bubble.call(this, $$self, event);
  }
  function div1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      anchor = $$value;
      $$invalidate(0, anchor);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("anchor" in $$props2)
      $$invalidate(0, anchor = $$props2.anchor);
    if ("disabled" in $$props2)
      $$invalidate(1, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(2, readonly = $$props2.readonly);
    if ("error" in $$props2)
      $$invalidate(3, error = $$props2.error);
    if ("focused" in $$props2)
      $$invalidate(4, focused = $$props2.focused);
    if ("placeholder" in $$props2)
      $$invalidate(5, placeholder = $$props2.placeholder);
    if ("id" in $$props2)
      $$invalidate(6, id = $$props2.id);
    if ("value" in $$props2)
      $$invalidate(9, value = $$props2.value);
    if ("icon" in $$props2)
      $$invalidate(7, icon = $$props2.icon);
    if ("enableTime" in $$props2)
      $$invalidate(10, enableTime = $$props2.enableTime);
    if ("timeOnly" in $$props2)
      $$invalidate(11, timeOnly = $$props2.timeOnly);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*value, enableTime, timeOnly*/
    3584) {
      $$invalidate(8, displayValue = getDateDisplayValue(value, { enableTime, timeOnly }));
    }
  };
  return [
    anchor,
    disabled,
    readonly,
    error,
    focused,
    placeholder,
    id,
    icon,
    displayValue,
    value,
    enableTime,
    timeOnly,
    click_handler,
    div1_binding
  ];
}
class DateInput extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, {
      anchor: 0,
      disabled: 1,
      readonly: 2,
      error: 3,
      focused: 4,
      placeholder: 5,
      id: 6,
      value: 9,
      icon: 7,
      enableTime: 10,
      timeOnly: 11
    });
  }
}
function create_if_block(ctx) {
  let datepickerpopovercontents;
  let current;
  datepickerpopovercontents = new DatePickerPopoverContents({
    props: {
      useKeyboardShortcuts: (
        /*useKeyboardShortcuts*/
        ctx[8]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        ctx[7]
      ),
      enableTime: (
        /*enableTime*/
        ctx[4]
      ),
      timeOnly: (
        /*timeOnly*/
        ctx[6]
      ),
      value: (
        /*parsedValue*/
        ctx[14]
      )
    }
  });
  datepickerpopovercontents.$on(
    "change",
    /*change_handler*/
    ctx[20]
  );
  return {
    c() {
      create_component(datepickerpopovercontents.$$.fragment);
    },
    m(target, anchor) {
      mount_component(datepickerpopovercontents, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const datepickerpopovercontents_changes = {};
      if (dirty & /*useKeyboardShortcuts*/
      256)
        datepickerpopovercontents_changes.useKeyboardShortcuts = /*useKeyboardShortcuts*/
        ctx2[8];
      if (dirty & /*ignoreTimezones*/
      128)
        datepickerpopovercontents_changes.ignoreTimezones = /*ignoreTimezones*/
        ctx2[7];
      if (dirty & /*enableTime*/
      16)
        datepickerpopovercontents_changes.enableTime = /*enableTime*/
        ctx2[4];
      if (dirty & /*timeOnly*/
      64)
        datepickerpopovercontents_changes.timeOnly = /*timeOnly*/
        ctx2[6];
      if (dirty & /*parsedValue*/
      16384)
        datepickerpopovercontents_changes.value = /*parsedValue*/
        ctx2[14];
      datepickerpopovercontents.$set(datepickerpopovercontents_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(datepickerpopovercontents.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(datepickerpopovercontents.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(datepickerpopovercontents, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*isOpen*/
    ctx[11] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*isOpen*/
        ctx2[11]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*isOpen*/
          2048) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let dateinput;
  let updating_anchor;
  let t;
  let popover_1;
  let current;
  function dateinput_anchor_binding(value) {
    ctx[19](value);
  }
  let dateinput_props = {
    disabled: (
      /*disabled*/
      ctx[1]
    ),
    readonly: (
      /*readonly*/
      ctx[2]
    ),
    error: (
      /*error*/
      ctx[3]
    ),
    placeholder: (
      /*placeholder*/
      ctx[5]
    ),
    id: (
      /*id*/
      ctx[0]
    ),
    enableTime: (
      /*enableTime*/
      ctx[4]
    ),
    timeOnly: (
      /*timeOnly*/
      ctx[6]
    ),
    focused: (
      /*isOpen*/
      ctx[11]
    ),
    value: (
      /*parsedValue*/
      ctx[14]
    ),
    icon: (
      /*timeOnly*/
      ctx[6] ? "clock" : "calendar"
    )
  };
  if (
    /*anchor*/
    ctx[12] !== void 0
  ) {
    dateinput_props.anchor = /*anchor*/
    ctx[12];
  }
  dateinput = new DateInput({ props: dateinput_props });
  binding_callbacks.push(() => bind(dateinput, "anchor", dateinput_anchor_binding));
  dateinput.$on("click", function() {
    var _a, _b;
    if (is_function(
      /*popover*/
      (_a = ctx[13]) == null ? void 0 : _a.show
    ))
      (_b = ctx[13]) == null ? void 0 : _b.show.apply(this, arguments);
  });
  let popover_1_props = {
    portalTarget: (
      /*appendTo*/
      ctx[9]
    ),
    anchor: (
      /*anchor*/
      ctx[12]
    ),
    align: (
      /*align*/
      ctx[10]
    ),
    resizable: false,
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  popover_1 = new Popover({ props: popover_1_props });
  ctx[21](popover_1);
  popover_1.$on(
    "open",
    /*open_handler*/
    ctx[22]
  );
  popover_1.$on(
    "close",
    /*close_handler*/
    ctx[23]
  );
  popover_1.$on(
    "open",
    /*onOpen*/
    ctx[15]
  );
  popover_1.$on(
    "close",
    /*onClose*/
    ctx[16]
  );
  return {
    c() {
      create_component(dateinput.$$.fragment);
      t = space();
      create_component(popover_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(dateinput, target, anchor);
      insert(target, t, anchor);
      mount_component(popover_1, target, anchor);
      current = true;
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      const dateinput_changes = {};
      if (dirty & /*disabled*/
      2)
        dateinput_changes.disabled = /*disabled*/
        ctx[1];
      if (dirty & /*readonly*/
      4)
        dateinput_changes.readonly = /*readonly*/
        ctx[2];
      if (dirty & /*error*/
      8)
        dateinput_changes.error = /*error*/
        ctx[3];
      if (dirty & /*placeholder*/
      32)
        dateinput_changes.placeholder = /*placeholder*/
        ctx[5];
      if (dirty & /*id*/
      1)
        dateinput_changes.id = /*id*/
        ctx[0];
      if (dirty & /*enableTime*/
      16)
        dateinput_changes.enableTime = /*enableTime*/
        ctx[4];
      if (dirty & /*timeOnly*/
      64)
        dateinput_changes.timeOnly = /*timeOnly*/
        ctx[6];
      if (dirty & /*isOpen*/
      2048)
        dateinput_changes.focused = /*isOpen*/
        ctx[11];
      if (dirty & /*parsedValue*/
      16384)
        dateinput_changes.value = /*parsedValue*/
        ctx[14];
      if (dirty & /*timeOnly*/
      64)
        dateinput_changes.icon = /*timeOnly*/
        ctx[6] ? "clock" : "calendar";
      if (!updating_anchor && dirty & /*anchor*/
      4096) {
        updating_anchor = true;
        dateinput_changes.anchor = /*anchor*/
        ctx[12];
        add_flush_callback(() => updating_anchor = false);
      }
      dateinput.$set(dateinput_changes);
      const popover_1_changes = {};
      if (dirty & /*appendTo*/
      512)
        popover_1_changes.portalTarget = /*appendTo*/
        ctx[9];
      if (dirty & /*anchor*/
      4096)
        popover_1_changes.anchor = /*anchor*/
        ctx[12];
      if (dirty & /*align*/
      1024)
        popover_1_changes.align = /*align*/
        ctx[10];
      if (dirty & /*$$scope, useKeyboardShortcuts, ignoreTimezones, enableTime, timeOnly, parsedValue, isOpen*/
      16796112) {
        popover_1_changes.$$scope = { dirty, ctx };
      }
      popover_1.$set(popover_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(dateinput.$$.fragment, local);
      transition_in(popover_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(dateinput.$$.fragment, local);
      transition_out(popover_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(dateinput, detaching);
      ctx[21](null);
      destroy_component(popover_1, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let parsedValue;
  let { id = null } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { error = null } = $$props;
  let { enableTime = true } = $$props;
  let { value = null } = $$props;
  let { placeholder = null } = $$props;
  let { timeOnly = false } = $$props;
  let { ignoreTimezones = false } = $$props;
  let { useKeyboardShortcuts = true } = $$props;
  let { appendTo = void 0 } = $$props;
  let { api = null } = $$props;
  let { align = PopoverAlignment.Left } = $$props;
  let isOpen = false;
  let anchor;
  let popover;
  const onOpen = () => {
    $$invalidate(11, isOpen = true);
  };
  const onClose = () => {
    $$invalidate(11, isOpen = false);
  };
  onMount(() => {
    $$invalidate(17, api = {
      open: () => popover == null ? void 0 : popover.show(),
      close: () => popover == null ? void 0 : popover.hide()
    });
  });
  function dateinput_anchor_binding(value2) {
    anchor = value2;
    $$invalidate(12, anchor);
  }
  function change_handler(event) {
    bubble.call(this, $$self, event);
  }
  function popover_1_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      popover = $$value;
      $$invalidate(13, popover);
    });
  }
  function open_handler(event) {
    bubble.call(this, $$self, event);
  }
  function close_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$props2) => {
    if ("id" in $$props2)
      $$invalidate(0, id = $$props2.id);
    if ("disabled" in $$props2)
      $$invalidate(1, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(2, readonly = $$props2.readonly);
    if ("error" in $$props2)
      $$invalidate(3, error = $$props2.error);
    if ("enableTime" in $$props2)
      $$invalidate(4, enableTime = $$props2.enableTime);
    if ("value" in $$props2)
      $$invalidate(18, value = $$props2.value);
    if ("placeholder" in $$props2)
      $$invalidate(5, placeholder = $$props2.placeholder);
    if ("timeOnly" in $$props2)
      $$invalidate(6, timeOnly = $$props2.timeOnly);
    if ("ignoreTimezones" in $$props2)
      $$invalidate(7, ignoreTimezones = $$props2.ignoreTimezones);
    if ("useKeyboardShortcuts" in $$props2)
      $$invalidate(8, useKeyboardShortcuts = $$props2.useKeyboardShortcuts);
    if ("appendTo" in $$props2)
      $$invalidate(9, appendTo = $$props2.appendTo);
    if ("api" in $$props2)
      $$invalidate(17, api = $$props2.api);
    if ("align" in $$props2)
      $$invalidate(10, align = $$props2.align);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*value, enableTime*/
    262160) {
      $$invalidate(14, parsedValue = parseDate(value, { enableTime }));
    }
  };
  return [
    id,
    disabled,
    readonly,
    error,
    enableTime,
    placeholder,
    timeOnly,
    ignoreTimezones,
    useKeyboardShortcuts,
    appendTo,
    align,
    isOpen,
    anchor,
    popover,
    parsedValue,
    onOpen,
    onClose,
    api,
    value,
    dateinput_anchor_binding,
    change_handler,
    popover_1_binding,
    open_handler,
    close_handler
  ];
}
class DatePicker extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      id: 0,
      disabled: 1,
      readonly: 2,
      error: 3,
      enableTime: 4,
      value: 18,
      placeholder: 5,
      timeOnly: 6,
      ignoreTimezones: 7,
      useKeyboardShortcuts: 8,
      appendTo: 9,
      api: 17,
      align: 10
    });
  }
}
export {
  DatePicker as D
};
