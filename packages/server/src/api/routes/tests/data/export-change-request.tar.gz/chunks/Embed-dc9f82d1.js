import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, z as group_outros, n as transition_out, A as check_outros, k as transition_in, o as detach, u as getContext, v as component_subscribe, e as element, c as create_component, m as mount_component, q as action_destroyer, h as is_function, p as destroy_component, b as attr, B as noop } from "./index-a0738cd3.js";
import Placeholder from "./Placeholder-31706623.js";
const Embed_svelte_svelte_type_style_lang = "";
function create_if_block_1(ctx) {
  let div;
  let placeholder;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  placeholder = new Placeholder({});
  return {
    c() {
      div = element("div");
      create_component(placeholder.$$.fragment);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(placeholder, div, null);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[3].call(null, div, {
          .../*$component*/
          ctx[1].styles,
          empty: true
        }));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      2)
        styleable_action.update.call(null, {
          .../*$component*/
          ctx2[1].styles,
          empty: true
        });
    },
    i(local) {
      if (current)
        return;
      transition_in(placeholder.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(placeholder.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(placeholder);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block(ctx) {
  let div;
  let styleable_action;
  let mounted;
  let dispose;
  return {
    c() {
      div = element("div");
      attr(div, "class", "embed svelte-nd6hd8");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      div.innerHTML = /*embed*/
      ctx[0];
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[3].call(
          null,
          div,
          /*$component*/
          ctx[1].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty & /*embed*/
      1)
        div.innerHTML = /*embed*/
        ctx2[0];
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      2)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[1].styles
        );
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_fragment(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block, create_if_block_1];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*embed*/
      ctx2[0]
    )
      return 0;
    if (
      /*$builderStore*/
      ctx2[2].inBuilder
    )
      return 1;
    return -1;
  }
  if (~(current_block_type_index = select_block_type(ctx))) {
    if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  }
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].m(target, anchor);
      }
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if (~current_block_type_index) {
          if_blocks[current_block_type_index].p(ctx2, dirty);
        }
      } else {
        if (if_block) {
          group_outros();
          transition_out(if_blocks[previous_block_index], 1, 1, () => {
            if_blocks[previous_block_index] = null;
          });
          check_outros();
        }
        if (~current_block_type_index) {
          if_block = if_blocks[current_block_type_index];
          if (!if_block) {
            if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
            if_block.c();
          } else {
            if_block.p(ctx2, dirty);
          }
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        } else {
          if_block = null;
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].d(detaching);
      }
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $component;
  let $builderStore;
  const { styleable, builderStore } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(2, $builderStore = value));
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(1, $component = value));
  let { embed } = $$props;
  $$self.$$set = ($$props2) => {
    if ("embed" in $$props2)
      $$invalidate(0, embed = $$props2.embed);
  };
  return [embed, $component, $builderStore, styleable, builderStore, component];
}
class Embed extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { embed: 0 });
  }
}
export {
  Embed as default
};
