import { S as SvelteComponent, i as init, s as safe_not_equal, c as create_component, m as mount_component, k as transition_in, n as transition_out, p as destroy_component, u as getContext, v as component_subscribe, y as empty, f as insert, z as group_outros, A as check_outros, o as detach, e as element, t as text, b as attr, g as append, j as set_data, B as noop, N as ensure_array_like, O as destroy_each, F as create_slot, a as space, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes } from "./index-a0738cd3.js";
import Placeholder from "./Placeholder-31706623.js";
import Container from "./Container-7ddcd183.js";
const Repeater_svelte_svelte_type_style_lang = "";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[15] = list[i];
  child_ctx[17] = i;
  return child_ctx;
}
function create_if_block_2(ctx) {
  let div;
  let i;
  let t;
  return {
    c() {
      div = element("div");
      i = element("i");
      t = text(
        /*noRowsMessage*/
        ctx[0]
      );
      attr(i, "class", "ri-list-check-2 svelte-1lkne36");
      attr(div, "class", "noRows svelte-1lkne36");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, i);
      append(div, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*noRowsMessage*/
      1)
        set_data(
          t,
          /*noRowsMessage*/
          ctx2[0]
        );
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block_1(ctx) {
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(
    /*rows*/
    ctx[7]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*rows, scope, $$scope*/
      8352) {
        each_value = ensure_array_like(
          /*rows*/
          ctx2[7]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_if_block(ctx) {
  let placeholder;
  let current;
  placeholder = new Placeholder({});
  return {
    c() {
      create_component(placeholder.$$.fragment);
    },
    m(target, anchor) {
      mount_component(placeholder, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(placeholder.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(placeholder.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(placeholder, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let t;
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[12].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[13],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
      t = space();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      insert(target, t, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        8192)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[13],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[13]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[13],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_each_block(ctx) {
  let provider;
  let current;
  provider = new /*Provider*/
  ctx[9]({
    props: {
      data: {
        .../*row*/
        ctx[15],
        index: (
          /*index*/
          ctx[17]
        )
      },
      scope: (
        /*scope*/
        ctx[5]
      ),
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(provider.$$.fragment);
    },
    m(target, anchor) {
      mount_component(provider, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const provider_changes = {};
      if (dirty & /*rows*/
      128)
        provider_changes.data = {
          .../*row*/
          ctx2[15],
          index: (
            /*index*/
            ctx2[17]
          )
        };
      if (dirty & /*scope*/
      32)
        provider_changes.scope = /*scope*/
        ctx2[5];
      if (dirty & /*$$scope*/
      8192) {
        provider_changes.$$scope = { dirty, ctx: ctx2 };
      }
      provider.$set(provider_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(provider.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(provider.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(provider, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block, create_if_block_1, create_if_block_2];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*$component*/
      ctx2[8].empty
    )
      return 0;
    if (
      /*rows*/
      ctx2[7].length > 0
    )
      return 1;
    if (
      /*loaded*/
      ctx2[6] && /*noRowsMessage*/
      ctx2[0]
    )
      return 2;
    return -1;
  }
  if (~(current_block_type_index = select_block_type(ctx))) {
    if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  }
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].m(target, anchor);
      }
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if (~current_block_type_index) {
          if_blocks[current_block_type_index].p(ctx2, dirty);
        }
      } else {
        if (if_block) {
          group_outros();
          transition_out(if_blocks[previous_block_index], 1, 1, () => {
            if_blocks[previous_block_index] = null;
          });
          check_outros();
        }
        if (~current_block_type_index) {
          if_block = if_blocks[current_block_type_index];
          if (!if_block) {
            if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
            if_block.c();
          } else {
            if_block.p(ctx2, dirty);
          }
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        } else {
          if_block = null;
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].d(detaching);
      }
    }
  };
}
function create_fragment(ctx) {
  let container;
  let current;
  container = new Container({
    props: {
      direction: (
        /*direction*/
        ctx[1]
      ),
      hAlign: (
        /*hAlign*/
        ctx[2]
      ),
      vAlign: (
        /*vAlign*/
        ctx[3]
      ),
      gap: (
        /*gap*/
        ctx[4]
      ),
      wrap: true,
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(container.$$.fragment);
    },
    m(target, anchor) {
      mount_component(container, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const container_changes = {};
      if (dirty & /*direction*/
      2)
        container_changes.direction = /*direction*/
        ctx2[1];
      if (dirty & /*hAlign*/
      4)
        container_changes.hAlign = /*hAlign*/
        ctx2[2];
      if (dirty & /*vAlign*/
      8)
        container_changes.vAlign = /*vAlign*/
        ctx2[3];
      if (dirty & /*gap*/
      16)
        container_changes.gap = /*gap*/
        ctx2[4];
      if (dirty & /*$$scope, $component, rows, scope, noRowsMessage, loaded*/
      8673) {
        container_changes.$$scope = { dirty, ctx: ctx2 };
      }
      container.$set(container_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(container.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(container.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(container, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let rows;
  let loaded;
  let $component;
  let { $$slots: slots = {}, $$scope } = $$props;
  const { Provider, ContextScopes } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(8, $component = value));
  let { dataProvider } = $$props;
  let { noRowsMessage } = $$props;
  let { direction } = $$props;
  let { hAlign } = $$props;
  let { vAlign } = $$props;
  let { gap } = $$props;
  let { scope = ContextScopes.Local } = $$props;
  $$self.$$set = ($$props2) => {
    if ("dataProvider" in $$props2)
      $$invalidate(11, dataProvider = $$props2.dataProvider);
    if ("noRowsMessage" in $$props2)
      $$invalidate(0, noRowsMessage = $$props2.noRowsMessage);
    if ("direction" in $$props2)
      $$invalidate(1, direction = $$props2.direction);
    if ("hAlign" in $$props2)
      $$invalidate(2, hAlign = $$props2.hAlign);
    if ("vAlign" in $$props2)
      $$invalidate(3, vAlign = $$props2.vAlign);
    if ("gap" in $$props2)
      $$invalidate(4, gap = $$props2.gap);
    if ("scope" in $$props2)
      $$invalidate(5, scope = $$props2.scope);
    if ("$$scope" in $$props2)
      $$invalidate(13, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*dataProvider*/
    2048) {
      $$invalidate(7, rows = (dataProvider == null ? void 0 : dataProvider.rows) ?? []);
    }
    if ($$self.$$.dirty & /*dataProvider*/
    2048) {
      $$invalidate(6, loaded = (dataProvider == null ? void 0 : dataProvider.loaded) ?? true);
    }
  };
  return [
    noRowsMessage,
    direction,
    hAlign,
    vAlign,
    gap,
    scope,
    loaded,
    rows,
    $component,
    Provider,
    component,
    dataProvider,
    slots,
    $$scope
  ];
}
class Repeater extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      dataProvider: 11,
      noRowsMessage: 0,
      direction: 1,
      hAlign: 2,
      vAlign: 3,
      gap: 4,
      scope: 5
    });
  }
}
export {
  Repeater as default
};
