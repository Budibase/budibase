import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, k as transition_in, z as group_outros, n as transition_out, A as check_outros, o as detach, u as getContext, v as component_subscribe, bU as shortid, bV as makePropSafe, K as Block, c as create_component, m as mount_component, p as destroy_component, M as BlockComponent, W as binding_callbacks, a0 as bind, a1 as add_flush_callback, az as get_store_value, a as space, bW as buildFormBlockButtonConfig, N as ensure_array_like, bX as update_keyed_each, bY as outro_and_destroy_block } from "./index-a0738cd3.js";
import { e as enrichSearchColumns, a as enrichFilter } from "./blocks-37916d2a.js";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[60] = list[i];
  child_ctx[62] = i;
  return child_ctx;
}
function create_if_block(ctx) {
  let block;
  let current;
  block = new Block({
    props: {
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(block.$$.fragment);
    },
    m(target, anchor) {
      mount_component(block, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const block_changes = {};
      if (dirty[0] & /*dataSource, size, formId, newRowSidePanelId, notificationOverride, sidePanelFields, normalFields, showTitleButton, titleButtonClickBehaviour, detailsSidePanelId, sidePanelSaveLabel, detailsFormBlockId, clickBehaviour, sortColumn, primaryDisplay, sortOrder, paginate, rowCount, autoRefresh, dataProviderId, tableColumns, quiet, compact, allowSelectRows, rowClickActions, noRowsMessage, buttonClickActions, titleButtonText, enrichedSearchColumns, title*/
      2013265919 | dirty[1] & /*id, deleteLabel, editTitle, enrichedFilter*/
      15 | dirty[2] & /*$$scope*/
      2) {
        block_changes.$$scope = { dirty, ctx: ctx2 };
      }
      block.$set(block_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(block.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(block.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(block, detaching);
    }
  };
}
function create_if_block_3(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "container",
      props: {
        direction: "row",
        hAlign: "stretch",
        vAlign: "middle",
        gap: "M",
        wrap: true
      },
      styles: { normal: { "margin-bottom": "20px" } },
      order: 0,
      $$slots: { default: [create_default_slot_5] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*buttonClickActions, titleButtonText, enrichedSearchColumns, showTitleButton, title*/
      302002177 | dirty[2] & /*$$scope*/
      2) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_if_block_5(ctx) {
  let each_blocks = [];
  let each_1_lookup = /* @__PURE__ */ new Map();
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(
    /*enrichedSearchColumns*/
    ctx[25]
  );
  const get_key = (ctx2) => (
    /*column*/
    ctx2[60].name
  );
  for (let i = 0; i < each_value.length; i += 1) {
    let child_ctx = get_each_context(ctx, each_value, i);
    let key = get_key(child_ctx);
    each_1_lookup.set(key, each_blocks[i] = create_each_block(key, child_ctx));
  }
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*enrichedSearchColumns*/
      33554432) {
        each_value = ensure_array_like(
          /*enrichedSearchColumns*/
          ctx2[25]
        );
        group_outros();
        each_blocks = update_keyed_each(each_blocks, dirty, get_key, 1, ctx2, each_value, each_1_lookup, each_1_anchor.parentNode, outro_and_destroy_block, create_each_block, each_1_anchor, get_each_context);
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].d(detaching);
      }
    }
  };
}
function create_each_block(key_1, ctx) {
  let first;
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: (
        /*column*/
        ctx[60].componentType
      ),
      props: {
        field: (
          /*column*/
          ctx[60].name
        ),
        placeholder: (
          /*column*/
          ctx[60].name
        ),
        text: (
          /*column*/
          ctx[60].name
        ),
        autoWidth: true
      },
      styles: { normal: { width: "192px" } },
      order: (
        /*idx*/
        ctx[62]
      )
    }
  });
  return {
    key: key_1,
    first: null,
    c() {
      first = empty();
      create_component(blockcomponent.$$.fragment);
      this.first = first;
    },
    m(target, anchor) {
      insert(target, first, anchor);
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const blockcomponent_changes = {};
      if (dirty[0] & /*enrichedSearchColumns*/
      33554432)
        blockcomponent_changes.type = /*column*/
        ctx[60].componentType;
      if (dirty[0] & /*enrichedSearchColumns*/
      33554432)
        blockcomponent_changes.props = {
          field: (
            /*column*/
            ctx[60].name
          ),
          placeholder: (
            /*column*/
            ctx[60].name
          ),
          text: (
            /*column*/
            ctx[60].name
          ),
          autoWidth: true
        };
      if (dirty[0] & /*enrichedSearchColumns*/
      33554432)
        blockcomponent_changes.order = /*idx*/
        ctx[62];
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(first);
      }
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_if_block_4(ctx) {
  var _a;
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "button",
      props: {
        onClick: (
          /*buttonClickActions*/
          ctx[28]
        ),
        text: (
          /*titleButtonText*/
          ctx[13]
        ),
        type: "cta"
      },
      order: (
        /*enrichedSearchColumns*/
        ((_a = ctx[25]) == null ? void 0 : _a.length) ?? 0
      )
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      const blockcomponent_changes = {};
      if (dirty[0] & /*buttonClickActions, titleButtonText*/
      268443648)
        blockcomponent_changes.props = {
          onClick: (
            /*buttonClickActions*/
            ctx2[28]
          ),
          text: (
            /*titleButtonText*/
            ctx2[13]
          ),
          type: "cta"
        };
      if (dirty[0] & /*enrichedSearchColumns*/
      33554432)
        blockcomponent_changes.order = /*enrichedSearchColumns*/
        ((_a2 = ctx2[25]) == null ? void 0 : _a2.length) ?? 0;
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_6(ctx) {
  var _a;
  let t;
  let if_block1_anchor;
  let current;
  let if_block0 = (
    /*enrichedSearchColumns*/
    ((_a = ctx[25]) == null ? void 0 : _a.length) && create_if_block_5(ctx)
  );
  let if_block1 = (
    /*showTitleButton*/
    ctx[12] && create_if_block_4(ctx)
  );
  return {
    c() {
      if (if_block0)
        if_block0.c();
      t = space();
      if (if_block1)
        if_block1.c();
      if_block1_anchor = empty();
    },
    m(target, anchor) {
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, if_block1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      if (
        /*enrichedSearchColumns*/
        (_a2 = ctx2[25]) == null ? void 0 : _a2.length
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty[0] & /*enrichedSearchColumns*/
          33554432) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_5(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(t.parentNode, t);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (
        /*showTitleButton*/
        ctx2[12]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty[0] & /*showTitleButton*/
          4096) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_4(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(if_block1_anchor.parentNode, if_block1_anchor);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block1_anchor);
      }
      if (if_block0)
        if_block0.d(detaching);
      if (if_block1)
        if_block1.d(detaching);
    }
  };
}
function create_default_slot_5(ctx) {
  let blockcomponent0;
  let t;
  let blockcomponent1;
  let current;
  blockcomponent0 = new BlockComponent({
    props: {
      type: "textv2",
      props: {
        text: (
          /*title*/
          ctx[0] ? `## ${/*title*/
          ctx[0]}` : ""
        )
      },
      order: 0
    }
  });
  blockcomponent1 = new BlockComponent({
    props: {
      type: "container",
      props: {
        direction: "row",
        hAlign: "left",
        vAlign: "center",
        gap: "M",
        wrap: true
      },
      order: 1,
      $$slots: { default: [create_default_slot_6] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent0.$$.fragment);
      t = space();
      create_component(blockcomponent1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent0, target, anchor);
      insert(target, t, anchor);
      mount_component(blockcomponent1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent0_changes = {};
      if (dirty[0] & /*title*/
      1)
        blockcomponent0_changes.props = {
          text: (
            /*title*/
            ctx2[0] ? `## ${/*title*/
            ctx2[0]}` : ""
          )
        };
      blockcomponent0.$set(blockcomponent0_changes);
      const blockcomponent1_changes = {};
      if (dirty[0] & /*buttonClickActions, titleButtonText, enrichedSearchColumns, showTitleButton*/
      302002176 | dirty[2] & /*$$scope*/
      2) {
        blockcomponent1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent1.$set(blockcomponent1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent0.$$.fragment, local);
      transition_in(blockcomponent1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent0.$$.fragment, local);
      transition_out(blockcomponent1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(blockcomponent0, detaching);
      destroy_component(blockcomponent1, detaching);
    }
  };
}
function create_default_slot_4(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "table",
      context: "table",
      props: {
        dataProvider: `{{ literal ${makePropSafe(
          /*dataProviderId*/
          ctx[26]
        )} }}`,
        columns: (
          /*tableColumns*/
          ctx[5]
        ),
        rowCount: (
          /*rowCount*/
          ctx[6]
        ),
        quiet: (
          /*quiet*/
          ctx[7]
        ),
        compact: (
          /*compact*/
          ctx[8]
        ),
        allowSelectRows: (
          /*allowSelectRows*/
          ctx[10]
        ),
        size: (
          /*size*/
          ctx[9]
        ),
        onClick: (
          /*rowClickActions*/
          ctx[29]
        ),
        noRowsMessage: (
          /*noRowsMessage*/
          ctx[15] || "No rows found"
        )
      }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*dataProviderId, tableColumns, rowCount, quiet, compact, allowSelectRows, size, rowClickActions, noRowsMessage*/
      604014560)
        blockcomponent_changes.props = {
          dataProvider: `{{ literal ${makePropSafe(
            /*dataProviderId*/
            ctx2[26]
          )} }}`,
          columns: (
            /*tableColumns*/
            ctx2[5]
          ),
          rowCount: (
            /*rowCount*/
            ctx2[6]
          ),
          quiet: (
            /*quiet*/
            ctx2[7]
          ),
          compact: (
            /*compact*/
            ctx2[8]
          ),
          allowSelectRows: (
            /*allowSelectRows*/
            ctx2[10]
          ),
          size: (
            /*size*/
            ctx2[9]
          ),
          onClick: (
            /*rowClickActions*/
            ctx2[29]
          ),
          noRowsMessage: (
            /*noRowsMessage*/
            ctx2[15] || "No rows found"
          )
        };
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_if_block_2(ctx) {
  let blockcomponent;
  let updating_id;
  let current;
  function blockcomponent_id_binding_2(value) {
    ctx[49](value);
  }
  let blockcomponent_props = {
    name: "Details side panel",
    type: "sidepanel",
    context: "details-side-panel",
    order: 2,
    $$slots: { default: [create_default_slot_3] },
    $$scope: { ctx }
  };
  if (
    /*detailsSidePanelId*/
    ctx[22] !== void 0
  ) {
    blockcomponent_props.id = /*detailsSidePanelId*/
    ctx[22];
  }
  blockcomponent = new BlockComponent({ props: blockcomponent_props });
  binding_callbacks.push(() => bind(blockcomponent, "id", blockcomponent_id_binding_2));
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*dataSource, sidePanelSaveLabel, notificationOverride, sidePanelFields, normalFields, detailsFormBlockId*/
      1076297730 | dirty[1] & /*id, deleteLabel, editTitle*/
      13 | dirty[2] & /*$$scope*/
      2) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_id && dirty[0] & /*detailsSidePanelId*/
      4194304) {
        updating_id = true;
        blockcomponent_changes.id = /*detailsSidePanelId*/
        ctx2[22];
        add_flush_callback(() => updating_id = false);
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_3(ctx) {
  let blockcomponent;
  let updating_id;
  let current;
  function blockcomponent_id_binding_1(value) {
    ctx[48](value);
  }
  let blockcomponent_props = {
    name: "Details form block",
    type: "formblock",
    context: "form-edit",
    props: {
      dataSource: (
        /*dataSource*/
        ctx[1]
      ),
      buttonPosition: "top",
      buttons: buildFormBlockButtonConfig({
        _id: (
          /*id*/
          ctx[33] + "-form-edit"
        ),
        showDeleteButton: (
          /*deleteLabel*/
          ctx[34] !== ""
        ),
        showSaveButton: true,
        saveButtonLabel: (
          /*sidePanelSaveLabel*/
          ctx[17] || "Save"
        ),
        deleteButtonLabel: (
          /*deleteLabel*/
          ctx[34]
        ),
        notificationOverride: (
          /*notificationOverride*/
          ctx[18]
        ),
        actionType: "Update",
        dataSource: (
          /*dataSource*/
          ctx[1]
        )
      }),
      actionType: "Update",
      rowId: `{{ ${makePropSafe("state")}.${makePropSafe(
        /*stateKey*/
        ctx[36]
      )} }}`,
      fields: (
        /*sidePanelFields*/
        ctx[16] || /*normalFields*/
        ctx[30]
      ),
      title: (
        /*editTitle*/
        ctx[31]
      ),
      labelPosition: "left"
    }
  };
  if (
    /*detailsFormBlockId*/
    ctx[21] !== void 0
  ) {
    blockcomponent_props.id = /*detailsFormBlockId*/
    ctx[21];
  }
  blockcomponent = new BlockComponent({ props: blockcomponent_props });
  binding_callbacks.push(() => bind(blockcomponent, "id", blockcomponent_id_binding_1));
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*dataSource, sidePanelSaveLabel, notificationOverride, sidePanelFields, normalFields*/
      1074200578 | dirty[1] & /*id, deleteLabel, editTitle*/
      13)
        blockcomponent_changes.props = {
          dataSource: (
            /*dataSource*/
            ctx2[1]
          ),
          buttonPosition: "top",
          buttons: buildFormBlockButtonConfig({
            _id: (
              /*id*/
              ctx2[33] + "-form-edit"
            ),
            showDeleteButton: (
              /*deleteLabel*/
              ctx2[34] !== ""
            ),
            showSaveButton: true,
            saveButtonLabel: (
              /*sidePanelSaveLabel*/
              ctx2[17] || "Save"
            ),
            deleteButtonLabel: (
              /*deleteLabel*/
              ctx2[34]
            ),
            notificationOverride: (
              /*notificationOverride*/
              ctx2[18]
            ),
            actionType: "Update",
            dataSource: (
              /*dataSource*/
              ctx2[1]
            )
          }),
          actionType: "Update",
          rowId: `{{ ${makePropSafe("state")}.${makePropSafe(
            /*stateKey*/
            ctx2[36]
          )} }}`,
          fields: (
            /*sidePanelFields*/
            ctx2[16] || /*normalFields*/
            ctx2[30]
          ),
          title: (
            /*editTitle*/
            ctx2[31]
          ),
          labelPosition: "left"
        };
      if (!updating_id && dirty[0] & /*detailsFormBlockId*/
      2097152) {
        updating_id = true;
        blockcomponent_changes.id = /*detailsFormBlockId*/
        ctx2[21];
        add_flush_callback(() => updating_id = false);
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_if_block_1(ctx) {
  let blockcomponent;
  let updating_id;
  let current;
  function blockcomponent_id_binding_3(value) {
    ctx[50](value);
  }
  let blockcomponent_props = {
    name: "New row side panel",
    type: "sidepanel",
    context: "new-side-panel",
    order: 3,
    $$slots: { default: [create_default_slot_2] },
    $$scope: { ctx }
  };
  if (
    /*newRowSidePanelId*/
    ctx[23] !== void 0
  ) {
    blockcomponent_props.id = /*newRowSidePanelId*/
    ctx[23];
  }
  blockcomponent = new BlockComponent({ props: blockcomponent_props });
  binding_callbacks.push(() => bind(blockcomponent, "id", blockcomponent_id_binding_3));
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*dataSource, notificationOverride, sidePanelFields, normalFields*/
      1074069506 | dirty[1] & /*id*/
      4 | dirty[2] & /*$$scope*/
      2) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_id && dirty[0] & /*newRowSidePanelId*/
      8388608) {
        updating_id = true;
        blockcomponent_changes.id = /*newRowSidePanelId*/
        ctx2[23];
        add_flush_callback(() => updating_id = false);
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_2(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      name: "New row form block",
      type: "formblock",
      context: "form-new",
      props: {
        dataSource: (
          /*dataSource*/
          ctx[1]
        ),
        buttonPosition: "top",
        buttons: buildFormBlockButtonConfig({
          _id: (
            /*id*/
            ctx[33] + "-form-new"
          ),
          showDeleteButton: false,
          showSaveButton: true,
          saveButtonLabel: "Save",
          notificationOverride: (
            /*notificationOverride*/
            ctx[18]
          ),
          actionType: "Create",
          dataSource: (
            /*dataSource*/
            ctx[1]
          )
        }),
        actionType: "Create",
        fields: (
          /*sidePanelFields*/
          ctx[16] || /*normalFields*/
          ctx[30]
        ),
        title: "Create Row",
        labelPosition: "left"
      }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*dataSource, notificationOverride, sidePanelFields, normalFields*/
      1074069506 | dirty[1] & /*id*/
      4)
        blockcomponent_changes.props = {
          dataSource: (
            /*dataSource*/
            ctx2[1]
          ),
          buttonPosition: "top",
          buttons: buildFormBlockButtonConfig({
            _id: (
              /*id*/
              ctx2[33] + "-form-new"
            ),
            showDeleteButton: false,
            showSaveButton: true,
            saveButtonLabel: "Save",
            notificationOverride: (
              /*notificationOverride*/
              ctx2[18]
            ),
            actionType: "Create",
            dataSource: (
              /*dataSource*/
              ctx2[1]
            )
          }),
          actionType: "Create",
          fields: (
            /*sidePanelFields*/
            ctx2[16] || /*normalFields*/
            ctx2[30]
          ),
          title: "Create Row",
          labelPosition: "left"
        };
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  var _a;
  let t0;
  let blockcomponent;
  let updating_id;
  let t1;
  let t2;
  let if_block2_anchor;
  let current;
  let if_block0 = (
    /*title*/
    (ctx[0] || /*enrichedSearchColumns*/
    ((_a = ctx[25]) == null ? void 0 : _a.length) || /*showTitleButton*/
    ctx[12]) && create_if_block_3(ctx)
  );
  function blockcomponent_id_binding(value) {
    ctx[47](value);
  }
  let blockcomponent_props = {
    type: "dataprovider",
    props: {
      dataSource: (
        /*dataSource*/
        ctx[1]
      ),
      filter: (
        /*enrichedFilter*/
        ctx[32]
      ),
      sortColumn: (
        /*sortColumn*/
        ctx[2] || /*primaryDisplay*/
        ctx[24]
      ),
      sortOrder: (
        /*sortOrder*/
        ctx[3]
      ),
      paginate: (
        /*paginate*/
        ctx[4]
      ),
      limit: (
        /*rowCount*/
        ctx[6]
      ),
      autoRefresh: (
        /*autoRefresh*/
        ctx[19]
      )
    },
    context: "provider",
    order: 1,
    $$slots: { default: [create_default_slot_4] },
    $$scope: { ctx }
  };
  if (
    /*dataProviderId*/
    ctx[26] !== void 0
  ) {
    blockcomponent_props.id = /*dataProviderId*/
    ctx[26];
  }
  blockcomponent = new BlockComponent({ props: blockcomponent_props });
  binding_callbacks.push(() => bind(blockcomponent, "id", blockcomponent_id_binding));
  let if_block1 = (
    /*clickBehaviour*/
    ctx[11] === "details" && create_if_block_2(ctx)
  );
  let if_block2 = (
    /*showTitleButton*/
    ctx[12] && /*titleButtonClickBehaviour*/
    ctx[14] === "new" && create_if_block_1(ctx)
  );
  return {
    c() {
      if (if_block0)
        if_block0.c();
      t0 = space();
      create_component(blockcomponent.$$.fragment);
      t1 = space();
      if (if_block1)
        if_block1.c();
      t2 = space();
      if (if_block2)
        if_block2.c();
      if_block2_anchor = empty();
    },
    m(target, anchor) {
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t0, anchor);
      mount_component(blockcomponent, target, anchor);
      insert(target, t1, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, t2, anchor);
      if (if_block2)
        if_block2.m(target, anchor);
      insert(target, if_block2_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      if (
        /*title*/
        ctx2[0] || /*enrichedSearchColumns*/
        ((_a2 = ctx2[25]) == null ? void 0 : _a2.length) || /*showTitleButton*/
        ctx2[12]
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty[0] & /*title, enrichedSearchColumns, showTitleButton*/
          33558529) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_3(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(t0.parentNode, t0);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      const blockcomponent_changes = {};
      if (dirty[0] & /*dataSource, sortColumn, primaryDisplay, sortOrder, paginate, rowCount, autoRefresh*/
      17301598 | dirty[1] & /*enrichedFilter*/
      2)
        blockcomponent_changes.props = {
          dataSource: (
            /*dataSource*/
            ctx2[1]
          ),
          filter: (
            /*enrichedFilter*/
            ctx2[32]
          ),
          sortColumn: (
            /*sortColumn*/
            ctx2[2] || /*primaryDisplay*/
            ctx2[24]
          ),
          sortOrder: (
            /*sortOrder*/
            ctx2[3]
          ),
          paginate: (
            /*paginate*/
            ctx2[4]
          ),
          limit: (
            /*rowCount*/
            ctx2[6]
          ),
          autoRefresh: (
            /*autoRefresh*/
            ctx2[19]
          )
        };
      if (dirty[0] & /*dataProviderId, tableColumns, rowCount, quiet, compact, allowSelectRows, size, rowClickActions, noRowsMessage*/
      604014560 | dirty[2] & /*$$scope*/
      2) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_id && dirty[0] & /*dataProviderId*/
      67108864) {
        updating_id = true;
        blockcomponent_changes.id = /*dataProviderId*/
        ctx2[26];
        add_flush_callback(() => updating_id = false);
      }
      blockcomponent.$set(blockcomponent_changes);
      if (
        /*clickBehaviour*/
        ctx2[11] === "details"
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty[0] & /*clickBehaviour*/
          2048) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_2(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(t2.parentNode, t2);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if (
        /*showTitleButton*/
        ctx2[12] && /*titleButtonClickBehaviour*/
        ctx2[14] === "new"
      ) {
        if (if_block2) {
          if_block2.p(ctx2, dirty);
          if (dirty[0] & /*showTitleButton, titleButtonClickBehaviour*/
          20480) {
            transition_in(if_block2, 1);
          }
        } else {
          if_block2 = create_if_block_1(ctx2);
          if_block2.c();
          transition_in(if_block2, 1);
          if_block2.m(if_block2_anchor.parentNode, if_block2_anchor);
        }
      } else if (if_block2) {
        group_outros();
        transition_out(if_block2, 1, 1, () => {
          if_block2 = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(blockcomponent.$$.fragment, local);
      transition_in(if_block1);
      transition_in(if_block2);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(blockcomponent.$$.fragment, local);
      transition_out(if_block1);
      transition_out(if_block2);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
        detach(if_block2_anchor);
      }
      if (if_block0)
        if_block0.d(detaching);
      destroy_component(blockcomponent, detaching);
      if (if_block1)
        if_block1.d(detaching);
      if (if_block2)
        if_block2.d(detaching);
    }
  };
}
function create_default_slot(ctx) {
  let blockcomponent;
  let updating_id;
  let current;
  function blockcomponent_id_binding_4(value) {
    ctx[51](value);
  }
  let blockcomponent_props = {
    type: "form",
    props: {
      dataSource: (
        /*dataSource*/
        ctx[1]
      ),
      disableSchemaValidation: true,
      editAutoColumns: true,
      size: (
        /*size*/
        ctx[9]
      )
    },
    $$slots: { default: [create_default_slot_1] },
    $$scope: { ctx }
  };
  if (
    /*formId*/
    ctx[20] !== void 0
  ) {
    blockcomponent_props.id = /*formId*/
    ctx[20];
  }
  blockcomponent = new BlockComponent({ props: blockcomponent_props });
  binding_callbacks.push(() => bind(blockcomponent, "id", blockcomponent_id_binding_4));
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty[0] & /*dataSource, size*/
      514)
        blockcomponent_changes.props = {
          dataSource: (
            /*dataSource*/
            ctx2[1]
          ),
          disableSchemaValidation: true,
          editAutoColumns: true,
          size: (
            /*size*/
            ctx2[9]
          )
        };
      if (dirty[0] & /*newRowSidePanelId, dataSource, notificationOverride, sidePanelFields, normalFields, showTitleButton, titleButtonClickBehaviour, detailsSidePanelId, sidePanelSaveLabel, detailsFormBlockId, clickBehaviour, sortColumn, primaryDisplay, sortOrder, paginate, rowCount, autoRefresh, dataProviderId, tableColumns, quiet, compact, allowSelectRows, size, rowClickActions, noRowsMessage, buttonClickActions, titleButtonText, enrichedSearchColumns, title*/
      2012217343 | dirty[1] & /*id, deleteLabel, editTitle, enrichedFilter*/
      15 | dirty[2] & /*$$scope*/
      2) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_id && dirty[0] & /*formId*/
      1048576) {
        updating_id = true;
        blockcomponent_changes.id = /*formId*/
        ctx2[20];
        add_flush_callback(() => updating_id = false);
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_fragment(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*schemaLoaded*/
    ctx[27] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*schemaLoaded*/
        ctx2[27]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*schemaLoaded*/
          134217728) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let deleteLabel;
  let id;
  let isDSPlus;
  let enrichedFilter;
  let editTitle;
  let normalFields;
  let rowClickActions;
  let buttonClickActions;
  let $component;
  let { title } = $$props;
  let { dataSource } = $$props;
  let { searchColumns } = $$props;
  let { filter } = $$props;
  let { sortColumn } = $$props;
  let { sortOrder } = $$props;
  let { paginate } = $$props;
  let { tableColumns } = $$props;
  let { rowCount } = $$props;
  let { quiet } = $$props;
  let { compact } = $$props;
  let { size } = $$props;
  let { allowSelectRows } = $$props;
  let { clickBehaviour } = $$props;
  let { onClick } = $$props;
  let { showTitleButton } = $$props;
  let { titleButtonText } = $$props;
  let { titleButtonClickBehaviour } = $$props;
  let { onClickTitleButton } = $$props;
  let { noRowsMessage } = $$props;
  let { sidePanelFields } = $$props;
  let { sidePanelShowDelete } = $$props;
  let { sidePanelSaveLabel } = $$props;
  let { sidePanelDeleteLabel } = $$props;
  let { notificationOverride } = $$props;
  let { autoRefresh } = $$props;
  const { fetchDatasourceSchema, API, generateGoldenSample } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(46, $component = value));
  const context = getContext("context");
  const stateKey = `ID_${shortid.generate()}`;
  let formId;
  let dataProviderId;
  let detailsFormBlockId;
  let detailsSidePanelId;
  let newRowSidePanelId;
  let schema;
  let primaryDisplay;
  let enrichedSearchColumns;
  let schemaLoaded = false;
  const getAdditionalDataContext = () => {
    var _a;
    const rows = (_a = get_store_value(context)[dataProviderId]) == null ? void 0 : _a.rows;
    const goldenRow = generateGoldenSample(rows);
    return { eventContext: { row: goldenRow } };
  };
  const setDeleteLabel = (sidePanelDeleteLabel2) => {
    let labelText = sidePanelShowDelete === false ? "" : sidePanelDeleteLabel2;
    if ((labelText == null ? void 0 : labelText.trim()) === "") {
      return "";
    }
    return labelText || "Delete";
  };
  const fetchSchema = async (dataSource2) => {
    if ((dataSource2 == null ? void 0 : dataSource2.type) === "table") {
      const definition = await API.fetchTableDefinition(dataSource2 == null ? void 0 : dataSource2.tableId);
      $$invalidate(44, schema = definition.schema);
      $$invalidate(24, primaryDisplay = definition.primaryDisplay);
    } else if (dataSource2) {
      $$invalidate(44, schema = await fetchDatasourceSchema(dataSource2, { enrichRelationships: true }));
    }
    $$invalidate(27, schemaLoaded = true);
  };
  const getNormalFields = (schema2) => {
    if (!schema2) {
      return [];
    }
    return Object.entries(schema2).filter((entry) => {
      return !entry[1].autocolumn;
    }).map((entry) => entry[0]);
  };
  const getEditTitle = (detailsFormBlockId2, primaryDisplay2) => {
    if (!primaryDisplay2 || !detailsFormBlockId2) {
      return "Edit";
    }
    const prefix = makePropSafe(detailsFormBlockId2 + "-repeater");
    const binding = `${prefix}.${makePropSafe(primaryDisplay2)}`;
    return `{{#if ${binding}}}{{${binding}}}{{else}}Details{{/if}}`;
  };
  function blockcomponent_id_binding(value) {
    dataProviderId = value;
    $$invalidate(26, dataProviderId);
  }
  function blockcomponent_id_binding_1(value) {
    detailsFormBlockId = value;
    $$invalidate(21, detailsFormBlockId);
  }
  function blockcomponent_id_binding_2(value) {
    detailsSidePanelId = value;
    $$invalidate(22, detailsSidePanelId);
  }
  function blockcomponent_id_binding_3(value) {
    newRowSidePanelId = value;
    $$invalidate(23, newRowSidePanelId);
  }
  function blockcomponent_id_binding_4(value) {
    formId = value;
    $$invalidate(20, formId);
  }
  $$self.$$set = ($$props2) => {
    if ("title" in $$props2)
      $$invalidate(0, title = $$props2.title);
    if ("dataSource" in $$props2)
      $$invalidate(1, dataSource = $$props2.dataSource);
    if ("searchColumns" in $$props2)
      $$invalidate(37, searchColumns = $$props2.searchColumns);
    if ("filter" in $$props2)
      $$invalidate(38, filter = $$props2.filter);
    if ("sortColumn" in $$props2)
      $$invalidate(2, sortColumn = $$props2.sortColumn);
    if ("sortOrder" in $$props2)
      $$invalidate(3, sortOrder = $$props2.sortOrder);
    if ("paginate" in $$props2)
      $$invalidate(4, paginate = $$props2.paginate);
    if ("tableColumns" in $$props2)
      $$invalidate(5, tableColumns = $$props2.tableColumns);
    if ("rowCount" in $$props2)
      $$invalidate(6, rowCount = $$props2.rowCount);
    if ("quiet" in $$props2)
      $$invalidate(7, quiet = $$props2.quiet);
    if ("compact" in $$props2)
      $$invalidate(8, compact = $$props2.compact);
    if ("size" in $$props2)
      $$invalidate(9, size = $$props2.size);
    if ("allowSelectRows" in $$props2)
      $$invalidate(10, allowSelectRows = $$props2.allowSelectRows);
    if ("clickBehaviour" in $$props2)
      $$invalidate(11, clickBehaviour = $$props2.clickBehaviour);
    if ("onClick" in $$props2)
      $$invalidate(39, onClick = $$props2.onClick);
    if ("showTitleButton" in $$props2)
      $$invalidate(12, showTitleButton = $$props2.showTitleButton);
    if ("titleButtonText" in $$props2)
      $$invalidate(13, titleButtonText = $$props2.titleButtonText);
    if ("titleButtonClickBehaviour" in $$props2)
      $$invalidate(14, titleButtonClickBehaviour = $$props2.titleButtonClickBehaviour);
    if ("onClickTitleButton" in $$props2)
      $$invalidate(40, onClickTitleButton = $$props2.onClickTitleButton);
    if ("noRowsMessage" in $$props2)
      $$invalidate(15, noRowsMessage = $$props2.noRowsMessage);
    if ("sidePanelFields" in $$props2)
      $$invalidate(16, sidePanelFields = $$props2.sidePanelFields);
    if ("sidePanelShowDelete" in $$props2)
      $$invalidate(41, sidePanelShowDelete = $$props2.sidePanelShowDelete);
    if ("sidePanelSaveLabel" in $$props2)
      $$invalidate(17, sidePanelSaveLabel = $$props2.sidePanelSaveLabel);
    if ("sidePanelDeleteLabel" in $$props2)
      $$invalidate(42, sidePanelDeleteLabel = $$props2.sidePanelDeleteLabel);
    if ("notificationOverride" in $$props2)
      $$invalidate(18, notificationOverride = $$props2.notificationOverride);
    if ("autoRefresh" in $$props2)
      $$invalidate(19, autoRefresh = $$props2.autoRefresh);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[1] & /*sidePanelDeleteLabel, sidePanelShowDelete*/
    3072) {
      $$invalidate(34, deleteLabel = setDeleteLabel(sidePanelDeleteLabel));
    }
    if ($$self.$$.dirty[1] & /*$component*/
    32768) {
      $$invalidate(33, id = $component.id);
    }
    if ($$self.$$.dirty[0] & /*dataSource*/
    2) {
      $$invalidate(45, isDSPlus = (dataSource == null ? void 0 : dataSource.type) === "table" || (dataSource == null ? void 0 : dataSource.type) === "viewV2");
    }
    if ($$self.$$.dirty[0] & /*dataSource*/
    2) {
      fetchSchema(dataSource);
    }
    if ($$self.$$.dirty[1] & /*searchColumns, schema*/
    8256) {
      enrichSearchColumns(searchColumns, schema).then((val) => $$invalidate(25, enrichedSearchColumns = val));
    }
    if ($$self.$$.dirty[0] & /*enrichedSearchColumns, formId*/
    34603008 | $$self.$$.dirty[1] & /*filter*/
    128) {
      $$invalidate(32, enrichedFilter = enrichFilter(filter, enrichedSearchColumns, formId));
    }
    if ($$self.$$.dirty[0] & /*detailsFormBlockId, primaryDisplay*/
    18874368) {
      $$invalidate(31, editTitle = getEditTitle(detailsFormBlockId, primaryDisplay));
    }
    if ($$self.$$.dirty[1] & /*schema*/
    8192) {
      $$invalidate(30, normalFields = getNormalFields(schema));
    }
    if ($$self.$$.dirty[0] & /*clickBehaviour, detailsSidePanelId*/
    4196352 | $$self.$$.dirty[1] & /*isDSPlus, onClick*/
    16640) {
      $$invalidate(29, rowClickActions = clickBehaviour === "actions" || !isDSPlus ? onClick : [
        {
          id: 0,
          "##eventHandlerType": "Update State",
          parameters: {
            key: stateKey,
            type: "set",
            persist: false,
            value: `{{ ${makePropSafe("eventContext")}.${makePropSafe("row")}._id }}`
          }
        },
        {
          id: 1,
          "##eventHandlerType": "Open Side Panel",
          parameters: { id: detailsSidePanelId }
        }
      ]);
    }
    if ($$self.$$.dirty[0] & /*titleButtonClickBehaviour, newRowSidePanelId*/
    8404992 | $$self.$$.dirty[1] & /*isDSPlus, onClickTitleButton*/
    16896) {
      $$invalidate(28, buttonClickActions = titleButtonClickBehaviour === "actions" || !isDSPlus ? onClickTitleButton : [
        {
          id: 0,
          "##eventHandlerType": "Open Side Panel",
          parameters: { id: newRowSidePanelId }
        }
      ]);
    }
  };
  return [
    title,
    dataSource,
    sortColumn,
    sortOrder,
    paginate,
    tableColumns,
    rowCount,
    quiet,
    compact,
    size,
    allowSelectRows,
    clickBehaviour,
    showTitleButton,
    titleButtonText,
    titleButtonClickBehaviour,
    noRowsMessage,
    sidePanelFields,
    sidePanelSaveLabel,
    notificationOverride,
    autoRefresh,
    formId,
    detailsFormBlockId,
    detailsSidePanelId,
    newRowSidePanelId,
    primaryDisplay,
    enrichedSearchColumns,
    dataProviderId,
    schemaLoaded,
    buttonClickActions,
    rowClickActions,
    normalFields,
    editTitle,
    enrichedFilter,
    id,
    deleteLabel,
    component,
    stateKey,
    searchColumns,
    filter,
    onClick,
    onClickTitleButton,
    sidePanelShowDelete,
    sidePanelDeleteLabel,
    getAdditionalDataContext,
    schema,
    isDSPlus,
    $component,
    blockcomponent_id_binding,
    blockcomponent_id_binding_1,
    blockcomponent_id_binding_2,
    blockcomponent_id_binding_3,
    blockcomponent_id_binding_4
  ];
}
class TableBlock extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        title: 0,
        dataSource: 1,
        searchColumns: 37,
        filter: 38,
        sortColumn: 2,
        sortOrder: 3,
        paginate: 4,
        tableColumns: 5,
        rowCount: 6,
        quiet: 7,
        compact: 8,
        size: 9,
        allowSelectRows: 10,
        clickBehaviour: 11,
        onClick: 39,
        showTitleButton: 12,
        titleButtonText: 13,
        titleButtonClickBehaviour: 14,
        onClickTitleButton: 40,
        noRowsMessage: 15,
        sidePanelFields: 16,
        sidePanelShowDelete: 41,
        sidePanelSaveLabel: 17,
        sidePanelDeleteLabel: 42,
        notificationOverride: 18,
        autoRefresh: 19,
        getAdditionalDataContext: 43
      },
      null,
      [-1, -1, -1]
    );
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[43];
  }
}
export {
  TableBlock as default
};
