import { S as SvelteComponent, i as init, s as safe_not_equal, I as Icon, e as element, c as create_component, a as space, t as text, b as attr, d as toggle_class, f as insert, g as append, m as mount_component, l as listen, h as is_function, j as set_data, k as transition_in, n as transition_out, o as detach, p as destroy_component, r as run_all, q as action_destroyer, u as getContext, v as component_subscribe, w as onDestroy, x as buildQuery, y as empty, z as group_outros, A as check_outros, B as noop, C as subscribe, D as fetchData, L as LogicalOperator, E as EmptyFilterOption, F as create_slot, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, P as ProgressCircle } from "./index-a0738cd3.js";
function create_fragment$1(ctx) {
  let nav;
  let div0;
  let icon0;
  let t0;
  let span;
  let t1;
  let t2;
  let t3;
  let div1;
  let icon1;
  let current;
  let mounted;
  let dispose;
  icon0 = new Icon({ props: { name: "caret-left", size: "M" } });
  icon1 = new Icon({
    props: { name: "caret-right", size: "M" }
  });
  return {
    c() {
      nav = element("nav");
      div0 = element("div");
      create_component(icon0.$$.fragment);
      t0 = space();
      span = element("span");
      t1 = text("Page ");
      t2 = text(
        /*page*/
        ctx[0]
      );
      t3 = space();
      div1 = element("div");
      create_component(icon1.$$.fragment);
      attr(div0, "class", "spectrum-ActionButton spectrum-ActionButton--sizeM spectrum-ActionButton--quiet spectrum-Pagination-prevButton svelte-1w0vi9g");
      toggle_class(div0, "is-disabled", !/*hasPrevPage*/
      ctx[3]);
      attr(span, "class", "spectrum-Body--secondary spectrum-Pagination-counter svelte-1w0vi9g");
      attr(div1, "class", "spectrum-ActionButton spectrum-ActionButton--sizeM spectrum-ActionButton--quiet spectrum-Pagination-nextButton svelte-1w0vi9g");
      toggle_class(div1, "is-disabled", !/*hasNextPage*/
      ctx[4]);
      attr(nav, "class", "spectrum-Pagination spectrum-Pagination--explicit");
    },
    m(target, anchor) {
      insert(target, nav, anchor);
      append(nav, div0);
      mount_component(icon0, div0, null);
      append(nav, t0);
      append(nav, span);
      append(span, t1);
      append(span, t2);
      append(nav, t3);
      append(nav, div1);
      mount_component(icon1, div1, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(div0, "click", function() {
            if (is_function(
              /*hasPrevPage*/
              ctx[3] ? (
                /*goToPrevPage*/
                ctx[1]
              ) : null
            ))
              /*hasPrevPage*/
              (ctx[3] ? (
                /*goToPrevPage*/
                ctx[1]
              ) : null).apply(this, arguments);
          }),
          listen(div1, "click", function() {
            if (is_function(
              /*hasNextPage*/
              ctx[4] ? (
                /*goToNextPage*/
                ctx[2]
              ) : null
            ))
              /*hasNextPage*/
              (ctx[4] ? (
                /*goToNextPage*/
                ctx[2]
              ) : null).apply(this, arguments);
          })
        ];
        mounted = true;
      }
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      if (!current || dirty & /*hasPrevPage*/
      8) {
        toggle_class(div0, "is-disabled", !/*hasPrevPage*/
        ctx[3]);
      }
      if (!current || dirty & /*page*/
      1)
        set_data(
          t2,
          /*page*/
          ctx[0]
        );
      if (!current || dirty & /*hasNextPage*/
      16) {
        toggle_class(div1, "is-disabled", !/*hasNextPage*/
        ctx[4]);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(icon0.$$.fragment, local);
      transition_in(icon1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(icon0.$$.fragment, local);
      transition_out(icon1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(nav);
      }
      destroy_component(icon0);
      destroy_component(icon1);
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let { page } = $$props;
  let { goToPrevPage } = $$props;
  let { goToNextPage } = $$props;
  let { hasPrevPage = true } = $$props;
  let { hasNextPage = true } = $$props;
  $$self.$$set = ($$props2) => {
    if ("page" in $$props2)
      $$invalidate(0, page = $$props2.page);
    if ("goToPrevPage" in $$props2)
      $$invalidate(1, goToPrevPage = $$props2.goToPrevPage);
    if ("goToNextPage" in $$props2)
      $$invalidate(2, goToNextPage = $$props2.goToNextPage);
    if ("hasPrevPage" in $$props2)
      $$invalidate(3, hasPrevPage = $$props2.hasPrevPage);
    if ("hasNextPage" in $$props2)
      $$invalidate(4, hasNextPage = $$props2.hasNextPage);
  };
  return [page, goToPrevPage, goToNextPage, hasPrevPage, hasNextPage];
}
class Pagination extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, {
      page: 0,
      goToPrevPage: 1,
      goToNextPage: 2,
      hasPrevPage: 3,
      hasNextPage: 4
    });
  }
}
const DataProvider_svelte_svelte_type_style_lang = "";
function create_else_block(ctx) {
  let t;
  let if_block_anchor;
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[19].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[20],
    null
  );
  let if_block = (
    /*paginate*/
    ctx[0] && /*$fetch*/
    ctx[2].supportsPagination && create_if_block_1(ctx)
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        1048576)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[20],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[20]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[20],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (
        /*paginate*/
        ctx2[0] && /*$fetch*/
        ctx2[2].supportsPagination
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*paginate, $fetch*/
          5) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      if (default_slot)
        default_slot.d(detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block(ctx) {
  let div;
  let progresscircle;
  let current;
  progresscircle = new ProgressCircle({});
  return {
    c() {
      div = element("div");
      create_component(progresscircle.$$.fragment);
      attr(div, "class", "loading svelte-1w67a05");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(progresscircle, div, null);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(progresscircle.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(progresscircle.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(progresscircle);
    }
  };
}
function create_if_block_1(ctx) {
  let div;
  let pagination;
  let current;
  pagination = new Pagination({
    props: {
      page: (
        /*$fetch*/
        ctx[2].pageNumber + 1
      ),
      hasPrevPage: (
        /*$fetch*/
        ctx[2].hasPrevPage
      ),
      hasNextPage: (
        /*$fetch*/
        ctx[2].hasNextPage
      ),
      goToPrevPage: (
        /*fetch*/
        ctx[1].prevPage
      ),
      goToNextPage: (
        /*fetch*/
        ctx[1].nextPage
      )
    }
  });
  return {
    c() {
      div = element("div");
      create_component(pagination.$$.fragment);
      attr(div, "class", "pagination svelte-1w67a05");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(pagination, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const pagination_changes = {};
      if (dirty & /*$fetch*/
      4)
        pagination_changes.page = /*$fetch*/
        ctx2[2].pageNumber + 1;
      if (dirty & /*$fetch*/
      4)
        pagination_changes.hasPrevPage = /*$fetch*/
        ctx2[2].hasPrevPage;
      if (dirty & /*$fetch*/
      4)
        pagination_changes.hasNextPage = /*$fetch*/
        ctx2[2].hasNextPage;
      if (dirty & /*fetch*/
      2)
        pagination_changes.goToPrevPage = /*fetch*/
        ctx2[1].prevPage;
      if (dirty & /*fetch*/
      2)
        pagination_changes.goToNextPage = /*fetch*/
        ctx2[1].nextPage;
      pagination.$set(pagination_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(pagination.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(pagination.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(pagination);
    }
  };
}
function create_default_slot(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (!/*$fetch*/
    ctx2[2].loaded)
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let div;
  let provider;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  provider = new /*Provider*/
  ctx[7]({
    props: {
      actions: (
        /*actions*/
        ctx[5]
      ),
      data: (
        /*dataContext*/
        ctx[4]
      ),
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div = element("div");
      create_component(provider.$$.fragment);
      attr(div, "class", "container svelte-1w67a05");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(provider, div, null);
      current = true;
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[6].call(
          null,
          div,
          /*$component*/
          ctx[3].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      const provider_changes = {};
      if (dirty & /*actions*/
      32)
        provider_changes.actions = /*actions*/
        ctx2[5];
      if (dirty & /*dataContext*/
      16)
        provider_changes.data = /*dataContext*/
        ctx2[4];
      if (dirty & /*$$scope, $fetch, fetch, paginate*/
      1048583) {
        provider_changes.$$scope = { dirty, ctx: ctx2 };
      }
      provider.$set(provider_changes);
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      8)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[3].styles
        );
    },
    i(local) {
      if (current)
        return;
      transition_in(provider.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(provider.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(provider);
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let defaultQuery;
  let query;
  let fetch;
  let schema;
  let actions;
  let dataContext;
  let $fetch, $$unsubscribe_fetch = noop, $$subscribe_fetch = () => ($$unsubscribe_fetch(), $$unsubscribe_fetch = subscribe(fetch, ($$value) => $$invalidate(2, $fetch = $$value)), fetch);
  let $component;
  $$self.$$.on_destroy.push(() => $$unsubscribe_fetch());
  let { $$slots: slots = {}, $$scope } = $$props;
  let { dataSource } = $$props;
  let { filter } = $$props;
  let { sortColumn } = $$props;
  let { sortOrder } = $$props;
  let { limit } = $$props;
  let { paginate } = $$props;
  let { autoRefresh } = $$props;
  const { styleable, Provider, ActionTypes, API } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(3, $component = value));
  let interval;
  let queryExtensions = {};
  const createFetch = (datasource) => {
    return fetchData({
      API,
      datasource,
      options: {
        query,
        sortColumn,
        sortOrder,
        limit,
        paginate
      }
    });
  };
  const sanitizeSchema = (schema2) => {
    if (!schema2) {
      return schema2;
    }
    let cloned = { ...schema2 };
    Object.entries(cloned).forEach(([field, fieldSchema]) => {
      if (fieldSchema.visible === false) {
        delete cloned[field];
      }
    });
    return cloned;
  };
  const addQueryExtension = (key, extension) => {
    if (!key || !extension) {
      return;
    }
    $$invalidate(15, queryExtensions = { ...queryExtensions, [key]: extension });
  };
  const removeQueryExtension = (key) => {
    if (!key) {
      return;
    }
    const newQueryExtensions = { ...queryExtensions };
    delete newQueryExtensions[key];
    $$invalidate(15, queryExtensions = newQueryExtensions);
  };
  const extendQuery = (defaultQuery2, extensions) => {
    var _a, _b;
    if (!Object.keys(extensions).length) {
      return defaultQuery2;
    }
    const extended = {
      [LogicalOperator.AND]: {
        conditions: [
          ...defaultQuery2 ? [defaultQuery2] : [],
          ...Object.values(extensions || {})
        ]
      },
      onEmptyFilter: EmptyFilterOption.RETURN_NONE
    };
    return (((_b = (_a = extended[LogicalOperator.AND]) == null ? void 0 : _a.conditions) == null ? void 0 : _b.length) ?? 0) > 0 ? extended : {};
  };
  const setUpAutoRefresh = (autoRefresh2) => {
    clearInterval(interval);
    if (autoRefresh2) {
      interval = setInterval(fetch.refresh, Math.max(1e4, autoRefresh2 * 1e3));
    }
  };
  onDestroy(() => {
    clearInterval(interval);
  });
  $$self.$$set = ($$props2) => {
    if ("dataSource" in $$props2)
      $$invalidate(9, dataSource = $$props2.dataSource);
    if ("filter" in $$props2)
      $$invalidate(10, filter = $$props2.filter);
    if ("sortColumn" in $$props2)
      $$invalidate(11, sortColumn = $$props2.sortColumn);
    if ("sortOrder" in $$props2)
      $$invalidate(12, sortOrder = $$props2.sortOrder);
    if ("limit" in $$props2)
      $$invalidate(13, limit = $$props2.limit);
    if ("paginate" in $$props2)
      $$invalidate(0, paginate = $$props2.paginate);
    if ("autoRefresh" in $$props2)
      $$invalidate(14, autoRefresh = $$props2.autoRefresh);
    if ("$$scope" in $$props2)
      $$invalidate(20, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    var _a;
    if ($$self.$$.dirty & /*filter*/
    1024) {
      $$invalidate(18, defaultQuery = buildQuery(filter));
    }
    if ($$self.$$.dirty & /*defaultQuery, queryExtensions*/
    294912) {
      $$invalidate(16, query = extendQuery(defaultQuery, queryExtensions));
    }
    if ($$self.$$.dirty & /*dataSource*/
    512) {
      $$subscribe_fetch($$invalidate(1, fetch = createFetch(dataSource)));
    }
    if ($$self.$$.dirty & /*fetch, query, sortColumn, sortOrder, limit, paginate*/
    79875) {
      fetch.update({
        query,
        sortColumn,
        sortOrder,
        limit,
        paginate
      });
    }
    if ($$self.$$.dirty & /*$fetch*/
    4) {
      $$invalidate(17, schema = sanitizeSchema($fetch.schema));
    }
    if ($$self.$$.dirty & /*autoRefresh*/
    16384) {
      setUpAutoRefresh(autoRefresh);
    }
    if ($$self.$$.dirty & /*fetch, dataSource*/
    514) {
      $$invalidate(5, actions = [
        {
          type: ActionTypes.RefreshDatasource,
          callback: () => fetch.refresh(),
          metadata: { dataSource }
        },
        {
          type: ActionTypes.AddDataProviderQueryExtension,
          callback: addQueryExtension
        },
        {
          type: ActionTypes.RemoveDataProviderQueryExtension,
          callback: removeQueryExtension
        },
        {
          type: ActionTypes.SetDataProviderSorting,
          callback: ({ column, order }) => {
            var _a2;
            let newOptions = {};
            if (column) {
              newOptions.sortColumn = column;
            }
            if (order) {
              newOptions.sortOrder = order;
            }
            if ((_a2 = Object.keys(newOptions)) == null ? void 0 : _a2.length) {
              fetch.update(newOptions);
            }
          }
        }
      ]);
    }
    if ($$self.$$.dirty & /*$fetch, dataSource, schema, $component, limit*/
    139788) {
      $$invalidate(4, dataContext = {
        rows: $fetch.rows,
        info: $fetch.info,
        datasource: dataSource || {},
        schema,
        rowsLength: $fetch.rows.length,
        pageNumber: $fetch.pageNumber + 1,
        // Undocumented properties. These aren't supposed to be used in builder
        // bindings, but are used internally by other components
        id: $component == null ? void 0 : $component.id,
        state: { query: $fetch.query },
        limit,
        primaryDisplay: (_a = $fetch.definition) == null ? void 0 : _a.primaryDisplay,
        loaded: $fetch.loaded
      });
    }
  };
  return [
    paginate,
    fetch,
    $fetch,
    $component,
    dataContext,
    actions,
    styleable,
    Provider,
    component,
    dataSource,
    filter,
    sortColumn,
    sortOrder,
    limit,
    autoRefresh,
    queryExtensions,
    query,
    schema,
    defaultQuery,
    slots,
    $$scope
  ];
}
class DataProvider extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      dataSource: 9,
      filter: 10,
      sortColumn: 11,
      sortOrder: 12,
      limit: 13,
      paginate: 0,
      autoRefresh: 14
    });
  }
}
export {
  DataProvider as default
};
