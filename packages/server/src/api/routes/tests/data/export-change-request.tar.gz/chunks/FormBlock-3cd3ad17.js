import { S as SvelteComponent, i as init, s as safe_not_equal, y as empty, f as insert, z as group_outros, n as transition_out, A as check_outros, k as transition_in, o as detach, u as getContext, v as component_subscribe, c as create_component, m as mount_component, B as noop, p as destroy_component, M as BlockComponent, W as binding_callbacks, a0 as bind, a1 as add_flush_callback, a as space, N as ensure_array_like, e as element, b as attr, d as toggle_class, O as destroy_each, bW as buildFormBlockButtonConfig, az as get_store_value } from "./index-a0738cd3.js";
import { F as FormBlockComponent, a as FormBlockWrapper } from "./FormBlockComponent-2878d220.js";
import Placeholder from "./Placeholder-31706623.js";
const InnerFormBlock_svelte_svelte_type_style_lang = "";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[17] = list[i];
  child_ctx[19] = i;
  return child_ctx;
}
function create_else_block(ctx) {
  let placeholder;
  let current;
  placeholder = new Placeholder({
    props: {
      text: "Choose your table and add some fields to your form to get started"
    }
  });
  return {
    c() {
      create_component(placeholder.$$.fragment);
    },
    m(target, anchor) {
      mount_component(placeholder, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(placeholder.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(placeholder.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(placeholder, detaching);
    }
  };
}
function create_if_block(ctx) {
  let blockcomponent;
  let updating_id;
  let current;
  function blockcomponent_id_binding(value) {
    ctx[16](value);
  }
  let blockcomponent_props = {
    type: "form",
    props: {
      actionType: (
        /*actionType*/
        ctx[1] === "Create" ? "Create" : "Update"
      ),
      dataSource: (
        /*dataSource*/
        ctx[0]
      ),
      size: (
        /*size*/
        ctx[2]
      ),
      disabled: (
        /*disabled*/
        ctx[3]
      ),
      readonly: !/*disabled*/
      ctx[3] && /*actionType*/
      ctx[1] === "View"
    },
    styles: {
      normal: {
        width: "600px",
        "margin-left": "auto",
        "margin-right": "auto"
      }
    },
    context: "form",
    $$slots: { default: [create_default_slot$1] },
    $$scope: { ctx }
  };
  if (
    /*formId*/
    ctx[12] !== void 0
  ) {
    blockcomponent_props.id = /*formId*/
    ctx[12];
  }
  blockcomponent = new BlockComponent({ props: blockcomponent_props });
  binding_callbacks.push(() => bind(blockcomponent, "id", blockcomponent_id_binding));
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*actionType, dataSource, size, disabled*/
      15)
        blockcomponent_changes.props = {
          actionType: (
            /*actionType*/
            ctx2[1] === "Create" ? "Create" : "Update"
          ),
          dataSource: (
            /*dataSource*/
            ctx2[0]
          ),
          size: (
            /*size*/
            ctx2[2]
          ),
          disabled: (
            /*disabled*/
            ctx2[3]
          ),
          readonly: !/*disabled*/
          ctx2[3] && /*actionType*/
          ctx2[1] === "View"
        };
      if (dirty & /*$$scope, buttons, buttonsCollapsed, buttonsCollapsedText, buttonPosition, $context, fields, schema, description, title, renderHeader*/
      1077232) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_id && dirty & /*formId*/
      4096) {
        updating_id = true;
        blockcomponent_changes.id = /*formId*/
        ctx2[12];
        add_flush_callback(() => updating_id = false);
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_if_block_3(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "container",
      props: { direction: "column", gap: "S" },
      order: 0,
      $$slots: { default: [create_default_slot_3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*$$scope, buttons, buttonsCollapsed, buttonsCollapsedText, buttonPosition, title*/
      1050528) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_if_block_4(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "buttongroup",
      props: {
        buttons: (
          /*buttons*/
          ctx[7]
        ),
        collapsed: (
          /*buttonsCollapsed*/
          ctx[9]
        ),
        collapsedText: (
          /*buttonsCollapsedText*/
          ctx[10]
        )
      },
      order: 0
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*buttons, buttonsCollapsed, buttonsCollapsedText*/
      1664)
        blockcomponent_changes.props = {
          buttons: (
            /*buttons*/
            ctx2[7]
          ),
          collapsed: (
            /*buttonsCollapsed*/
            ctx2[9]
          ),
          collapsedText: (
            /*buttonsCollapsedText*/
            ctx2[10]
          )
        };
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot_4(ctx) {
  let blockcomponent;
  let t;
  let if_block_anchor;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "textv2",
      props: {
        text: (
          /*title*/
          ctx[5] ? `## ${/*title*/
          ctx[5]}` : ""
        )
      },
      order: 0
    }
  });
  let if_block = (
    /*buttonPosition*/
    ctx[8] === "top" && create_if_block_4(ctx)
  );
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*title*/
      32)
        blockcomponent_changes.props = {
          text: (
            /*title*/
            ctx2[5] ? `## ${/*title*/
            ctx2[5]}` : ""
          )
        };
      blockcomponent.$set(blockcomponent_changes);
      if (
        /*buttonPosition*/
        ctx2[8] === "top"
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*buttonPosition*/
          256) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_4(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      destroy_component(blockcomponent, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_default_slot_3(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "container",
      props: {
        direction: "row",
        hAlign: "stretch",
        vAlign: "center",
        gap: "M",
        wrap: true
      },
      order: 0,
      $$slots: { default: [create_default_slot_4] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*$$scope, buttons, buttonsCollapsed, buttonsCollapsedText, buttonPosition, title*/
      1050528) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_if_block_2(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "textv2",
      props: { text: (
        /*description*/
        ctx[6]
      ) },
      order: 1
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*description*/
      64)
        blockcomponent_changes.props = { text: (
          /*description*/
          ctx2[6]
        ) };
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_each_block(ctx) {
  let formblockcomponent;
  let current;
  formblockcomponent = new FormBlockComponent({
    props: {
      field: (
        /*field*/
        ctx[17]
      ),
      schema: (
        /*schema*/
        ctx[11]
      ),
      order: (
        /*idx*/
        ctx[19]
      )
    }
  });
  return {
    c() {
      create_component(formblockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(formblockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const formblockcomponent_changes = {};
      if (dirty & /*fields*/
      16)
        formblockcomponent_changes.field = /*field*/
        ctx2[17];
      if (dirty & /*schema*/
      2048)
        formblockcomponent_changes.schema = /*schema*/
        ctx2[11];
      formblockcomponent.$set(formblockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(formblockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(formblockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(formblockcomponent, detaching);
    }
  };
}
function create_default_slot_2(ctx) {
  let div;
  let current;
  let each_value = ensure_array_like(
    /*fields*/
    ctx[4]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "form-block fields svelte-1gdgv0g");
      toggle_class(
        div,
        "mobile",
        /*$context*/
        ctx[14].device.mobile
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*fields, schema*/
      2064) {
        each_value = ensure_array_like(
          /*fields*/
          ctx2[4]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div, null);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      if (!current || dirty & /*$context*/
      16384) {
        toggle_class(
          div,
          "mobile",
          /*$context*/
          ctx2[14].device.mobile
        );
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let t0;
  let t1;
  let blockcomponent;
  let current;
  let if_block0 = (
    /*renderHeader*/
    ctx[13] && create_if_block_3(ctx)
  );
  let if_block1 = (
    /*description*/
    ctx[6] && create_if_block_2(ctx)
  );
  blockcomponent = new BlockComponent({
    props: {
      type: "container",
      $$slots: { default: [create_default_slot_2] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      if (if_block0)
        if_block0.c();
      t0 = space();
      if (if_block1)
        if_block1.c();
      t1 = space();
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t0, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, t1, anchor);
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*renderHeader*/
        ctx2[13]
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty & /*renderHeader*/
          8192) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_3(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(t0.parentNode, t0);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (
        /*description*/
        ctx2[6]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty & /*description*/
          64) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_2(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(t1.parentNode, t1);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      const blockcomponent_changes = {};
      if (dirty & /*$$scope, $context, fields, schema*/
      1067024) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
      if (if_block0)
        if_block0.d(detaching);
      if (if_block1)
        if_block1.d(detaching);
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_if_block_1(ctx) {
  let blockcomponent;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "buttongroup",
      props: {
        buttons: (
          /*buttons*/
          ctx[7]
        ),
        collapsed: (
          /*buttonsCollapsed*/
          ctx[9]
        ),
        collapsedText: (
          /*buttonsCollapsedText*/
          ctx[10]
        )
      },
      styles: { normal: { "margin-top": "24" } },
      order: 1
    }
  });
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*buttons, buttonsCollapsed, buttonsCollapsedText*/
      1664)
        blockcomponent_changes.props = {
          buttons: (
            /*buttons*/
            ctx2[7]
          ),
          collapsed: (
            /*buttonsCollapsed*/
            ctx2[9]
          ),
          collapsedText: (
            /*buttonsCollapsedText*/
            ctx2[10]
          )
        };
      blockcomponent.$set(blockcomponent_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(blockcomponent, detaching);
    }
  };
}
function create_default_slot$1(ctx) {
  let blockcomponent;
  let t;
  let if_block_anchor;
  let current;
  blockcomponent = new BlockComponent({
    props: {
      type: "container",
      props: {
        direction: "column",
        hAlign: "stretch",
        vAlign: "top",
        gap: "M"
      },
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  let if_block = (
    /*buttonPosition*/
    ctx[8] === "bottom" && create_if_block_1(ctx)
  );
  return {
    c() {
      create_component(blockcomponent.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      mount_component(blockcomponent, target, anchor);
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const blockcomponent_changes = {};
      if (dirty & /*$$scope, $context, fields, schema, description, buttons, buttonsCollapsed, buttonsCollapsedText, buttonPosition, title, renderHeader*/
      1077232) {
        blockcomponent_changes.$$scope = { dirty, ctx: ctx2 };
      }
      blockcomponent.$set(blockcomponent_changes);
      if (
        /*buttonPosition*/
        ctx2[8] === "bottom"
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*buttonPosition*/
          256) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(blockcomponent.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(blockcomponent.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block_anchor);
      }
      destroy_component(blockcomponent, detaching);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment$1(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    var _a;
    if (
      /*fields*/
      (_a = ctx2[4]) == null ? void 0 : _a.length
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let renderHeader;
  let $context;
  let { dataSource } = $$props;
  let { actionType } = $$props;
  let { size } = $$props;
  let { disabled } = $$props;
  let { fields } = $$props;
  let { title } = $$props;
  let { description } = $$props;
  let { buttons } = $$props;
  let { buttonPosition = "bottom" } = $$props;
  let { buttonsCollapsed } = $$props;
  let { buttonsCollapsedText } = $$props;
  let { schema } = $$props;
  const context = getContext("context");
  component_subscribe($$self, context, (value) => $$invalidate(14, $context = value));
  let formId;
  function blockcomponent_id_binding(value) {
    formId = value;
    $$invalidate(12, formId);
  }
  $$self.$$set = ($$props2) => {
    if ("dataSource" in $$props2)
      $$invalidate(0, dataSource = $$props2.dataSource);
    if ("actionType" in $$props2)
      $$invalidate(1, actionType = $$props2.actionType);
    if ("size" in $$props2)
      $$invalidate(2, size = $$props2.size);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("fields" in $$props2)
      $$invalidate(4, fields = $$props2.fields);
    if ("title" in $$props2)
      $$invalidate(5, title = $$props2.title);
    if ("description" in $$props2)
      $$invalidate(6, description = $$props2.description);
    if ("buttons" in $$props2)
      $$invalidate(7, buttons = $$props2.buttons);
    if ("buttonPosition" in $$props2)
      $$invalidate(8, buttonPosition = $$props2.buttonPosition);
    if ("buttonsCollapsed" in $$props2)
      $$invalidate(9, buttonsCollapsed = $$props2.buttonsCollapsed);
    if ("buttonsCollapsedText" in $$props2)
      $$invalidate(10, buttonsCollapsedText = $$props2.buttonsCollapsedText);
    if ("schema" in $$props2)
      $$invalidate(11, schema = $$props2.schema);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*buttons, title*/
    160) {
      $$invalidate(13, renderHeader = buttons || title);
    }
  };
  return [
    dataSource,
    actionType,
    size,
    disabled,
    fields,
    title,
    description,
    buttons,
    buttonPosition,
    buttonsCollapsed,
    buttonsCollapsedText,
    schema,
    formId,
    renderHeader,
    $context,
    context,
    blockcomponent_id_binding
  ];
}
class InnerFormBlock extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, {
      dataSource: 0,
      actionType: 1,
      size: 2,
      disabled: 3,
      fields: 4,
      title: 5,
      description: 6,
      buttons: 7,
      buttonPosition: 8,
      buttonsCollapsed: 9,
      buttonsCollapsedText: 10,
      schema: 11
    });
  }
}
function create_default_slot(ctx) {
  let innerformblock;
  let current;
  innerformblock = new InnerFormBlock({
    props: {
      dataSource: (
        /*dataSource*/
        ctx[1]
      ),
      actionType: (
        /*actionType*/
        ctx[0]
      ),
      size: (
        /*size*/
        ctx[2]
      ),
      disabled: (
        /*disabled*/
        ctx[3]
      ),
      fields: (
        /*fieldsOrDefault*/
        ctx[14]
      ),
      title: (
        /*title*/
        ctx[6]
      ),
      description: (
        /*description*/
        ctx[7]
      ),
      schema: (
        /*schema*/
        ctx[12]
      ),
      buttons: (
        /*buttonsOrDefault*/
        ctx[13]
      ),
      buttonPosition: (
        /*buttons*/
        ctx[4] ? (
          /*buttonPosition*/
          ctx[5]
        ) : "top"
      ),
      buttonsCollapsed: (
        /*buttonsCollapsed*/
        ctx[10]
      ),
      buttonsCollapsedText: (
        /*buttonsCollapsedText*/
        ctx[11]
      )
    }
  });
  return {
    c() {
      create_component(innerformblock.$$.fragment);
    },
    m(target, anchor) {
      mount_component(innerformblock, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const innerformblock_changes = {};
      if (dirty[0] & /*dataSource*/
      2)
        innerformblock_changes.dataSource = /*dataSource*/
        ctx2[1];
      if (dirty[0] & /*actionType*/
      1)
        innerformblock_changes.actionType = /*actionType*/
        ctx2[0];
      if (dirty[0] & /*size*/
      4)
        innerformblock_changes.size = /*size*/
        ctx2[2];
      if (dirty[0] & /*disabled*/
      8)
        innerformblock_changes.disabled = /*disabled*/
        ctx2[3];
      if (dirty[0] & /*fieldsOrDefault*/
      16384)
        innerformblock_changes.fields = /*fieldsOrDefault*/
        ctx2[14];
      if (dirty[0] & /*title*/
      64)
        innerformblock_changes.title = /*title*/
        ctx2[6];
      if (dirty[0] & /*description*/
      128)
        innerformblock_changes.description = /*description*/
        ctx2[7];
      if (dirty[0] & /*schema*/
      4096)
        innerformblock_changes.schema = /*schema*/
        ctx2[12];
      if (dirty[0] & /*buttonsOrDefault*/
      8192)
        innerformblock_changes.buttons = /*buttonsOrDefault*/
        ctx2[13];
      if (dirty[0] & /*buttons, buttonPosition*/
      48)
        innerformblock_changes.buttonPosition = /*buttons*/
        ctx2[4] ? (
          /*buttonPosition*/
          ctx2[5]
        ) : "top";
      if (dirty[0] & /*buttonsCollapsed*/
      1024)
        innerformblock_changes.buttonsCollapsed = /*buttonsCollapsed*/
        ctx2[10];
      if (dirty[0] & /*buttonsCollapsedText*/
      2048)
        innerformblock_changes.buttonsCollapsedText = /*buttonsCollapsedText*/
        ctx2[11];
      innerformblock.$set(innerformblock_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(innerformblock.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(innerformblock.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(innerformblock, detaching);
    }
  };
}
function create_fragment(ctx) {
  let formblockwrapper;
  let current;
  formblockwrapper = new FormBlockWrapper({
    props: {
      actionType: (
        /*actionType*/
        ctx[0]
      ),
      dataSource: (
        /*dataSource*/
        ctx[1]
      ),
      rowId: (
        /*rowId*/
        ctx[8]
      ),
      noRowsMessage: (
        /*noRowsMessage*/
        ctx[9]
      ),
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(formblockwrapper.$$.fragment);
    },
    m(target, anchor) {
      mount_component(formblockwrapper, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const formblockwrapper_changes = {};
      if (dirty[0] & /*actionType*/
      1)
        formblockwrapper_changes.actionType = /*actionType*/
        ctx2[0];
      if (dirty[0] & /*dataSource*/
      2)
        formblockwrapper_changes.dataSource = /*dataSource*/
        ctx2[1];
      if (dirty[0] & /*rowId*/
      256)
        formblockwrapper_changes.rowId = /*rowId*/
        ctx2[8];
      if (dirty[0] & /*noRowsMessage*/
      512)
        formblockwrapper_changes.noRowsMessage = /*noRowsMessage*/
        ctx2[9];
      if (dirty[0] & /*dataSource, actionType, size, disabled, fieldsOrDefault, title, description, schema, buttonsOrDefault, buttons, buttonPosition, buttonsCollapsed, buttonsCollapsedText*/
      31999 | dirty[1] & /*$$scope*/
      4) {
        formblockwrapper_changes.$$scope = { dirty, ctx: ctx2 };
      }
      formblockwrapper.$set(formblockwrapper_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(formblockwrapper.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(formblockwrapper.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(formblockwrapper, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let id;
  let formattedFields;
  let fieldsOrDefault;
  let buttonsOrDefault;
  let $component;
  let { actionType } = $$props;
  let { dataSource } = $$props;
  let { size } = $$props;
  let { disabled } = $$props;
  let { fields } = $$props;
  let { buttons } = $$props;
  let { buttonPosition } = $$props;
  let { title } = $$props;
  let { description } = $$props;
  let { rowId } = $$props;
  let { actionUrl } = $$props;
  let { noRowsMessage } = $$props;
  let { notificationOverride } = $$props;
  let { buttonsCollapsed } = $$props;
  let { buttonsCollapsedText } = $$props;
  let { showDeleteButton } = $$props;
  let { showSaveButton } = $$props;
  let { saveButtonLabel } = $$props;
  let { deleteButtonLabel } = $$props;
  const { fetchDatasourceSchema, generateGoldenSample } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(26, $component = value));
  const context = getContext("context");
  let schema;
  const getAdditionalDataContext = () => {
    var _a;
    const id2 = get_store_value(component).id;
    const rows = ((_a = get_store_value(context)[`${id2}-provider`]) == null ? void 0 : _a.rows) || [];
    const goldenRow = generateGoldenSample(rows);
    return { [`${id2}-repeater`]: goldenRow };
  };
  const convertOldFieldFormat = (fields2) => {
    if (!fields2) {
      return [];
    }
    return fields2.map((field) => {
      if (typeof field === "string") {
        return { name: field, active: true };
      } else {
        return {
          ...field,
          active: typeof (field == null ? void 0 : field.active) != "boolean" ? true : field == null ? void 0 : field.active
        };
      }
    });
  };
  const getDefaultFields = (fields2, schema2) => {
    if (!schema2) {
      return [];
    }
    let defaultFields = [];
    if (!fields2 || fields2.length === 0) {
      Object.values(schema2).filter((field) => !field.autocolumn).forEach((field) => {
        defaultFields.push({ name: field.name, active: true });
      });
    }
    return [...fields2, ...defaultFields].filter((field) => field.active);
  };
  const fetchSchema = async (datasource) => {
    $$invalidate(12, schema = await fetchDatasourceSchema(datasource) || {});
  };
  $$self.$$set = ($$props2) => {
    if ("actionType" in $$props2)
      $$invalidate(0, actionType = $$props2.actionType);
    if ("dataSource" in $$props2)
      $$invalidate(1, dataSource = $$props2.dataSource);
    if ("size" in $$props2)
      $$invalidate(2, size = $$props2.size);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("fields" in $$props2)
      $$invalidate(16, fields = $$props2.fields);
    if ("buttons" in $$props2)
      $$invalidate(4, buttons = $$props2.buttons);
    if ("buttonPosition" in $$props2)
      $$invalidate(5, buttonPosition = $$props2.buttonPosition);
    if ("title" in $$props2)
      $$invalidate(6, title = $$props2.title);
    if ("description" in $$props2)
      $$invalidate(7, description = $$props2.description);
    if ("rowId" in $$props2)
      $$invalidate(8, rowId = $$props2.rowId);
    if ("actionUrl" in $$props2)
      $$invalidate(17, actionUrl = $$props2.actionUrl);
    if ("noRowsMessage" in $$props2)
      $$invalidate(9, noRowsMessage = $$props2.noRowsMessage);
    if ("notificationOverride" in $$props2)
      $$invalidate(18, notificationOverride = $$props2.notificationOverride);
    if ("buttonsCollapsed" in $$props2)
      $$invalidate(10, buttonsCollapsed = $$props2.buttonsCollapsed);
    if ("buttonsCollapsedText" in $$props2)
      $$invalidate(11, buttonsCollapsedText = $$props2.buttonsCollapsedText);
    if ("showDeleteButton" in $$props2)
      $$invalidate(19, showDeleteButton = $$props2.showDeleteButton);
    if ("showSaveButton" in $$props2)
      $$invalidate(20, showSaveButton = $$props2.showSaveButton);
    if ("saveButtonLabel" in $$props2)
      $$invalidate(21, saveButtonLabel = $$props2.saveButtonLabel);
    if ("deleteButtonLabel" in $$props2)
      $$invalidate(22, deleteButtonLabel = $$props2.deleteButtonLabel);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*dataSource*/
    2) {
      fetchSchema(dataSource);
    }
    if ($$self.$$.dirty[0] & /*$component*/
    67108864) {
      $$invalidate(24, id = $component.id);
    }
    if ($$self.$$.dirty[0] & /*fields*/
    65536) {
      $$invalidate(25, formattedFields = convertOldFieldFormat(fields));
    }
    if ($$self.$$.dirty[0] & /*formattedFields, schema*/
    33558528) {
      $$invalidate(14, fieldsOrDefault = getDefaultFields(formattedFields, schema));
    }
    if ($$self.$$.dirty[0] & /*buttons, id, showDeleteButton, showSaveButton, saveButtonLabel, deleteButtonLabel, notificationOverride, actionType, actionUrl, dataSource*/
    25034771) {
      $$invalidate(13, buttonsOrDefault = buttons || buildFormBlockButtonConfig({
        _id: id,
        showDeleteButton,
        showSaveButton,
        saveButtonLabel,
        deleteButtonLabel,
        notificationOverride,
        actionType,
        actionUrl,
        dataSource
      }));
    }
  };
  return [
    actionType,
    dataSource,
    size,
    disabled,
    buttons,
    buttonPosition,
    title,
    description,
    rowId,
    noRowsMessage,
    buttonsCollapsed,
    buttonsCollapsedText,
    schema,
    buttonsOrDefault,
    fieldsOrDefault,
    component,
    fields,
    actionUrl,
    notificationOverride,
    showDeleteButton,
    showSaveButton,
    saveButtonLabel,
    deleteButtonLabel,
    getAdditionalDataContext,
    id,
    formattedFields,
    $component
  ];
}
class FormBlock extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        actionType: 0,
        dataSource: 1,
        size: 2,
        disabled: 3,
        fields: 16,
        buttons: 4,
        buttonPosition: 5,
        title: 6,
        description: 7,
        rowId: 8,
        actionUrl: 17,
        noRowsMessage: 9,
        notificationOverride: 18,
        buttonsCollapsed: 10,
        buttonsCollapsedText: 11,
        showDeleteButton: 19,
        showSaveButton: 20,
        saveButtonLabel: 21,
        deleteButtonLabel: 22,
        getAdditionalDataContext: 23
      },
      null,
      [-1, -1]
    );
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[23];
  }
}
export {
  FormBlock as default
};
