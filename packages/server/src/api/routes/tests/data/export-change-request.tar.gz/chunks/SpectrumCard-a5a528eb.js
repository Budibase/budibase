import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, a as space, t as text, b as attr, d as toggle_class, f as insert, g as append, l as listen, q as action_destroyer, h as is_function, j as set_data, k as transition_in, z as group_outros, n as transition_out, A as check_outros, o as detach, r as run_all, u as getContext, v as component_subscribe, al as set_style, ap as Button, c as create_component, m as mount_component, p as destroy_component } from "./index-a0738cd3.js";
const indexVars = "";
const SpectrumCard_svelte_svelte_type_style_lang = "";
function create_if_block_3(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      attr(div, "class", "spectrum-Card-coverPhoto svelte-1jgsopy");
      set_style(div, "background-image", "url(" + /*imageURL*/
      ctx[3] + ")");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*imageURL*/
      8) {
        set_style(div, "background-image", "url(" + /*imageURL*/
        ctx2[3] + ")");
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block_2(ctx) {
  let div1;
  let div0;
  let t;
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      t = text(
        /*subtitle*/
        ctx[1]
      );
      attr(div0, "class", "spectrum-Card-subtitle spectrum-Detail spectrum-Detail--sizeS svelte-1jgsopy");
      attr(div1, "class", "spectrum-Card-content");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      append(div0, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*subtitle*/
      2)
        set_data(
          t,
          /*subtitle*/
          ctx2[1]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
    }
  };
}
function create_if_block_1(ctx) {
  let div;
  let t;
  return {
    c() {
      div = element("div");
      t = text(
        /*description*/
        ctx[2]
      );
      attr(div, "class", "spectrum-Card-footer svelte-1jgsopy");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*description*/
      4)
        set_data(
          t,
          /*description*/
          ctx2[2]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block(ctx) {
  let div;
  let button;
  let current;
  button = new Button({
    props: {
      secondary: true,
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  button.$on("click", function() {
    if (is_function(
      /*buttonOnClick*/
      ctx[8]
    ))
      ctx[8].apply(this, arguments);
  });
  return {
    c() {
      div = element("div");
      create_component(button.$$.fragment);
      attr(div, "class", "spectrum-Card-footer button-container svelte-1jgsopy");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(button, div, null);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const button_changes = {};
      if (dirty & /*$$scope, buttonText*/
      32896) {
        button_changes.$$scope = { dirty, ctx };
      }
      button.$set(button_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(button.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(button.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(button);
    }
  };
}
function create_default_slot(ctx) {
  let t_value = (
    /*buttonText*/
    (ctx[7] || "Click me") + ""
  );
  let t;
  return {
    c() {
      t = text(t_value);
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*buttonText*/
      128 && t_value !== (t_value = /*buttonText*/
      (ctx2[7] || "Click me") + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_fragment(ctx) {
  let div4;
  let t0;
  let div3;
  let div2;
  let div1;
  let div0;
  let t1_value = (
    /*title*/
    (ctx[0] || "Card Title") + ""
  );
  let t1;
  let t2;
  let t3;
  let t4;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  let if_block0 = (
    /*imageURL*/
    ctx[3] && create_if_block_3(ctx)
  );
  let if_block1 = (
    /*subtitle*/
    ctx[1] && create_if_block_2(ctx)
  );
  let if_block2 = (
    /*description*/
    ctx[2] && create_if_block_1(ctx)
  );
  let if_block3 = (
    /*showButton*/
    ctx[6] && create_if_block(ctx)
  );
  return {
    c() {
      div4 = element("div");
      if (if_block0)
        if_block0.c();
      t0 = space();
      div3 = element("div");
      div2 = element("div");
      div1 = element("div");
      div0 = element("div");
      t1 = text(t1_value);
      t2 = space();
      if (if_block1)
        if_block1.c();
      t3 = space();
      if (if_block2)
        if_block2.c();
      t4 = space();
      if (if_block3)
        if_block3.c();
      attr(div0, "class", "spectrum-Card-title spectrum-Heading spectrum-Heading--sizeXS svelte-1jgsopy");
      toggle_class(
        div0,
        "link",
        /*linkURL*/
        ctx[4]
      );
      attr(div1, "class", "spectrum-Card-header");
      attr(div2, "class", "spectrum-Card-body");
      attr(div3, "class", "spectrum-Card-container svelte-1jgsopy");
      attr(div4, "class", "spectrum-Card svelte-1jgsopy");
      attr(div4, "tabindex", "0");
      attr(div4, "role", "figure");
      toggle_class(
        div4,
        "horizontal",
        /*horizontal*/
        ctx[5]
      );
      toggle_class(
        div4,
        "clickable",
        /*buttonOnClick*/
        ctx[8] && !/*showButton*/
        ctx[6]
      );
    },
    m(target, anchor) {
      insert(target, div4, anchor);
      if (if_block0)
        if_block0.m(div4, null);
      append(div4, t0);
      append(div4, div3);
      append(div3, div2);
      append(div2, div1);
      append(div1, div0);
      append(div0, t1);
      append(div2, t2);
      if (if_block1)
        if_block1.m(div2, null);
      append(div3, t3);
      if (if_block2)
        if_block2.m(div3, null);
      append(div3, t4);
      if (if_block3)
        if_block3.m(div3, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            div0,
            "click",
            /*handleLink*/
            ctx[12]
          ),
          action_destroyer(styleable_action = /*styleable*/
          ctx[10].call(
            null,
            div4,
            /*$component*/
            ctx[9].styles
          )),
          listen(div4, "click", function() {
            if (is_function(
              /*showButton*/
              ctx[6] ? null : (
                /*buttonOnClick*/
                ctx[8]
              )
            ))
              /*showButton*/
              (ctx[6] ? null : (
                /*buttonOnClick*/
                ctx[8]
              )).apply(this, arguments);
          })
        ];
        mounted = true;
      }
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      if (
        /*imageURL*/
        ctx[3]
      ) {
        if (if_block0) {
          if_block0.p(ctx, dirty);
        } else {
          if_block0 = create_if_block_3(ctx);
          if_block0.c();
          if_block0.m(div4, t0);
        }
      } else if (if_block0) {
        if_block0.d(1);
        if_block0 = null;
      }
      if ((!current || dirty & /*title*/
      1) && t1_value !== (t1_value = /*title*/
      (ctx[0] || "Card Title") + ""))
        set_data(t1, t1_value);
      if (!current || dirty & /*linkURL*/
      16) {
        toggle_class(
          div0,
          "link",
          /*linkURL*/
          ctx[4]
        );
      }
      if (
        /*subtitle*/
        ctx[1]
      ) {
        if (if_block1) {
          if_block1.p(ctx, dirty);
        } else {
          if_block1 = create_if_block_2(ctx);
          if_block1.c();
          if_block1.m(div2, null);
        }
      } else if (if_block1) {
        if_block1.d(1);
        if_block1 = null;
      }
      if (
        /*description*/
        ctx[2]
      ) {
        if (if_block2) {
          if_block2.p(ctx, dirty);
        } else {
          if_block2 = create_if_block_1(ctx);
          if_block2.c();
          if_block2.m(div3, t4);
        }
      } else if (if_block2) {
        if_block2.d(1);
        if_block2 = null;
      }
      if (
        /*showButton*/
        ctx[6]
      ) {
        if (if_block3) {
          if_block3.p(ctx, dirty);
          if (dirty & /*showButton*/
          64) {
            transition_in(if_block3, 1);
          }
        } else {
          if_block3 = create_if_block(ctx);
          if_block3.c();
          transition_in(if_block3, 1);
          if_block3.m(div3, null);
        }
      } else if (if_block3) {
        group_outros();
        transition_out(if_block3, 1, 1, () => {
          if_block3 = null;
        });
        check_outros();
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      512)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx[9].styles
        );
      if (!current || dirty & /*horizontal*/
      32) {
        toggle_class(
          div4,
          "horizontal",
          /*horizontal*/
          ctx[5]
        );
      }
      if (!current || dirty & /*buttonOnClick, showButton*/
      320) {
        toggle_class(
          div4,
          "clickable",
          /*buttonOnClick*/
          ctx[8] && !/*showButton*/
          ctx[6]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block3);
      current = true;
    },
    o(local) {
      transition_out(if_block3);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div4);
      }
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
      if (if_block2)
        if_block2.d();
      if (if_block3)
        if_block3.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $component;
  let { title } = $$props;
  let { subtitle } = $$props;
  let { description } = $$props;
  let { imageURL } = $$props;
  let { linkURL } = $$props;
  let { linkPeek } = $$props;
  let { horizontal } = $$props;
  let { showButton } = $$props;
  let { buttonText } = $$props;
  let { buttonOnClick } = $$props;
  const { styleable, routeStore } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(9, $component = value));
  const handleLink = (e) => {
    if (!linkURL) {
      return false;
    }
    e.preventDefault();
    e.stopPropagation();
    routeStore.actions.navigate(linkURL, linkPeek);
  };
  $$self.$$set = ($$props2) => {
    if ("title" in $$props2)
      $$invalidate(0, title = $$props2.title);
    if ("subtitle" in $$props2)
      $$invalidate(1, subtitle = $$props2.subtitle);
    if ("description" in $$props2)
      $$invalidate(2, description = $$props2.description);
    if ("imageURL" in $$props2)
      $$invalidate(3, imageURL = $$props2.imageURL);
    if ("linkURL" in $$props2)
      $$invalidate(4, linkURL = $$props2.linkURL);
    if ("linkPeek" in $$props2)
      $$invalidate(13, linkPeek = $$props2.linkPeek);
    if ("horizontal" in $$props2)
      $$invalidate(5, horizontal = $$props2.horizontal);
    if ("showButton" in $$props2)
      $$invalidate(6, showButton = $$props2.showButton);
    if ("buttonText" in $$props2)
      $$invalidate(7, buttonText = $$props2.buttonText);
    if ("buttonOnClick" in $$props2)
      $$invalidate(8, buttonOnClick = $$props2.buttonOnClick);
  };
  return [
    title,
    subtitle,
    description,
    imageURL,
    linkURL,
    horizontal,
    showButton,
    buttonText,
    buttonOnClick,
    $component,
    styleable,
    component,
    handleLink,
    linkPeek
  ];
}
class SpectrumCard extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      title: 0,
      subtitle: 1,
      description: 2,
      imageURL: 3,
      linkURL: 4,
      linkPeek: 13,
      horizontal: 5,
      showButton: 6,
      buttonText: 7,
      buttonOnClick: 8
    });
  }
}
export {
  SpectrumCard as default
};
