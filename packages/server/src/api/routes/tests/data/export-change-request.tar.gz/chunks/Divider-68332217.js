import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, b as attr, f as insert, q as action_destroyer, h as is_function, B as noop, o as detach, u as getContext, v as component_subscribe } from "./index-a0738cd3.js";
function create_fragment(ctx) {
  let hr;
  let hr_class_value;
  let styleable_action;
  let mounted;
  let dispose;
  return {
    c() {
      hr = element("hr");
      attr(hr, "class", hr_class_value = "spectrum-Divider spectrum-Divider--" + /*vertical*/
      (ctx[1] ? "vertical" : "horizontal") + " spectrum-Dialog-divider spectrum-Divider--size" + /*size*/
      ctx[0]);
    },
    m(target, anchor) {
      insert(target, hr, anchor);
      if (!mounted) {
        dispose = action_destroyer(styleable_action = /*styleable*/
        ctx[3].call(
          null,
          hr,
          /*$component*/
          ctx[2].styles
        ));
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & /*vertical, size*/
      3 && hr_class_value !== (hr_class_value = "spectrum-Divider spectrum-Divider--" + /*vertical*/
      (ctx2[1] ? "vertical" : "horizontal") + " spectrum-Dialog-divider spectrum-Divider--size" + /*size*/
      ctx2[0])) {
        attr(hr, "class", hr_class_value);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      4)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx2[2].styles
        );
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(hr);
      }
      mounted = false;
      dispose();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $component;
  const { styleable } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(2, $component = value));
  let { size = "M" } = $$props;
  let { vertical = false } = $$props;
  $$self.$$set = ($$props2) => {
    if ("size" in $$props2)
      $$invalidate(0, size = $$props2.size);
    if ("vertical" in $$props2)
      $$invalidate(1, vertical = $$props2.vertical);
  };
  return [size, vertical, $component, styleable, component];
}
class Divider extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { size: 0, vertical: 1 });
  }
}
export {
  Divider as default
};
