import { S as SvelteComponent, i as init, s as safe_not_equal, bs as assign, c as create_component, m as mount_component, bR as get_spread_update, bS as get_spread_object, k as transition_in, n as transition_out, p as destroy_component, bt as exclude_internal_props } from "./index-a0738cd3.js";
import StringField from "./StringField-126698b8.js";
import "./Field-026e9b04.js";
import "./Placeholder-31706623.js";
import "./InnerForm-c723d600.js";
function create_fragment(ctx) {
  let stringfield;
  let current;
  const stringfield_spread_levels = [
    /*$$props*/
    ctx[0],
    { type: "password" }
  ];
  let stringfield_props = {};
  for (let i = 0; i < stringfield_spread_levels.length; i += 1) {
    stringfield_props = assign(stringfield_props, stringfield_spread_levels[i]);
  }
  stringfield = new StringField({ props: stringfield_props });
  return {
    c() {
      create_component(stringfield.$$.fragment);
    },
    m(target, anchor) {
      mount_component(stringfield, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const stringfield_changes = dirty & /*$$props*/
      1 ? get_spread_update(stringfield_spread_levels, [get_spread_object(
        /*$$props*/
        ctx2[0]
      ), stringfield_spread_levels[1]]) : {};
      stringfield.$set(stringfield_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(stringfield.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(stringfield.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(stringfield, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  $$self.$$set = ($$new_props) => {
    $$invalidate(0, $$props = assign(assign({}, $$props), exclude_internal_props($$new_props)));
  };
  $$props = exclude_internal_props($$props);
  return [$$props];
}
class PasswordField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {});
  }
}
export {
  PasswordField as default
};
