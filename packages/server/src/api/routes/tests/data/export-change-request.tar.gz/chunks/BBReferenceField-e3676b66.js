import { S as SvelteComponent, i as init, s as safe_not_equal, bs as assign, c as create_component, m as mount_component, bR as get_spread_update, bS as get_spread_object, k as transition_in, n as transition_out, p as destroy_component, aK as FieldType, bt as exclude_internal_props, V as bubble } from "./index-a0738cd3.js";
import RelationshipField from "./RelationshipField-1b2fe5d7.js";
import { c as containsUserID, g as getGlobalUserID } from "./users-c42bb877.js";
import "./Multiselect-7c6c2576.js";
import "./Field-026e9b04.js";
import "./Placeholder-31706623.js";
import "./InnerForm-c723d600.js";
function create_fragment(ctx) {
  let relationshipfield;
  let current;
  const relationshipfield_spread_levels = [
    /*allProps*/
    ctx[3],
    { type: (
      /*type*/
      ctx[0]
    ) },
    { datasourceType: "user" },
    { primaryDisplay: "email" },
    {
      defaultValue: (
        /*updatedDefaultValue*/
        ctx[4]
      )
    },
    { defaultRows: (
      /*defaultRows*/
      ctx[2]
    ) },
    { multi: (
      /*multi*/
      ctx[1]
    ) }
  ];
  let relationshipfield_props = {};
  for (let i = 0; i < relationshipfield_spread_levels.length; i += 1) {
    relationshipfield_props = assign(relationshipfield_props, relationshipfield_spread_levels[i]);
  }
  relationshipfield = new RelationshipField({ props: relationshipfield_props });
  relationshipfield.$on(
    "rows",
    /*rows_handler*/
    ctx[6]
  );
  return {
    c() {
      create_component(relationshipfield.$$.fragment);
    },
    m(target, anchor) {
      mount_component(relationshipfield, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const relationshipfield_changes = dirty & /*allProps, type, updatedDefaultValue, defaultRows, multi*/
      31 ? get_spread_update(relationshipfield_spread_levels, [
        dirty & /*allProps*/
        8 && get_spread_object(
          /*allProps*/
          ctx2[3]
        ),
        dirty & /*type*/
        1 && { type: (
          /*type*/
          ctx2[0]
        ) },
        relationshipfield_spread_levels[2],
        relationshipfield_spread_levels[3],
        dirty & /*updatedDefaultValue*/
        16 && {
          defaultValue: (
            /*updatedDefaultValue*/
            ctx2[4]
          )
        },
        dirty & /*defaultRows*/
        4 && { defaultRows: (
          /*defaultRows*/
          ctx2[2]
        ) },
        dirty & /*multi*/
        2 && { multi: (
          /*multi*/
          ctx2[1]
        ) }
      ]) : {};
      relationshipfield.$set(relationshipfield_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(relationshipfield.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(relationshipfield.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(relationshipfield, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let updatedDefaultValue;
  let allProps;
  let { defaultValue } = $$props;
  let { type = FieldType.BB_REFERENCE } = $$props;
  let { multi = void 0 } = $$props;
  let { defaultRows = [] } = $$props;
  function updateUserIDs(value) {
    if (Array.isArray(value)) {
      return value.map((val) => getGlobalUserID(val));
    } else {
      return getGlobalUserID(value);
    }
  }
  function updateReferences(value) {
    if (containsUserID(value)) {
      return updateUserIDs(value);
    }
    return value;
  }
  function rows_handler(event) {
    bubble.call(this, $$self, event);
  }
  $$self.$$set = ($$new_props) => {
    $$invalidate(9, $$props = assign(assign({}, $$props), exclude_internal_props($$new_props)));
    if ("defaultValue" in $$new_props)
      $$invalidate(5, defaultValue = $$new_props.defaultValue);
    if ("type" in $$new_props)
      $$invalidate(0, type = $$new_props.type);
    if ("multi" in $$new_props)
      $$invalidate(1, multi = $$new_props.multi);
    if ("defaultRows" in $$new_props)
      $$invalidate(2, defaultRows = $$new_props.defaultRows);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*defaultValue*/
    32) {
      $$invalidate(4, updatedDefaultValue = updateReferences(defaultValue));
    }
    $$invalidate(3, allProps = $$props);
  };
  $$props = exclude_internal_props($$props);
  return [
    type,
    multi,
    defaultRows,
    allProps,
    updatedDefaultValue,
    defaultValue,
    rows_handler
  ];
}
class BBReferenceField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      defaultValue: 5,
      type: 0,
      multi: 1,
      defaultRows: 2
    });
  }
}
export {
  BBReferenceField as default
};
