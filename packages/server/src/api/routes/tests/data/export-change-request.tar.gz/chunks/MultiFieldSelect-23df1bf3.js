import { S as SvelteComponent, i as init, s as safe_not_equal, aK as FieldType, W as binding_callbacks, a0 as bind, c as create_component, m as mount_component, a1 as add_flush_callback, k as transition_in, n as transition_out, p as destroy_component, y as empty, f as insert, z as group_outros, A as check_outros, o as detach } from "./index-a0738cd3.js";
import { C as CheckboxGroup } from "./CheckboxGroup-995bb449.js";
import { M as Multiselect } from "./Multiselect-7c6c2576.js";
import { F as Field } from "./Field-026e9b04.js";
import { g as getOptions } from "./optionsParser-a13cad91.js";
import "./Placeholder-31706623.js";
import "./InnerForm-c723d600.js";
function create_if_block(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block_1, create_if_block_2];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (!/*optionsType*/
    ctx2[7] || /*optionsType*/
    ctx2[7] === "select")
      return 0;
    if (
      /*optionsType*/
      ctx2[7] === "checkbox"
    )
      return 1;
    return -1;
  }
  if (~(current_block_type_index = select_block_type(ctx))) {
    if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  }
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].m(target, anchor);
      }
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if (~current_block_type_index) {
          if_blocks[current_block_type_index].p(ctx2, dirty);
        }
      } else {
        if (if_block) {
          group_outros();
          transition_out(if_blocks[previous_block_index], 1, 1, () => {
            if_blocks[previous_block_index] = null;
          });
          check_outros();
        }
        if (~current_block_type_index) {
          if_block = if_blocks[current_block_type_index];
          if (!if_block) {
            if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
            if_block.c();
          } else {
            if_block.p(ctx2, dirty);
          }
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        } else {
          if_block = null;
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].d(detaching);
      }
    }
  };
}
function create_if_block_2(ctx) {
  let corecheckboxgroup;
  let current;
  corecheckboxgroup = new CheckboxGroup({
    props: {
      value: (
        /*fieldState*/
        ctx[14].value || []
      ),
      disabled: (
        /*fieldState*/
        ctx[14].disabled
      ),
      readonly: (
        /*fieldState*/
        ctx[14].readonly
      ),
      options: (
        /*options*/
        ctx[16]
      ),
      direction: (
        /*direction*/
        ctx[8]
      ),
      getOptionLabel: (
        /*flatOptions*/
        ctx[18] ? func_4 : (
          /*func_5*/
          ctx[28]
        )
      ),
      getOptionValue: (
        /*flatOptions*/
        ctx[18] ? func_6 : (
          /*func_7*/
          ctx[29]
        )
      ),
      showSelectAll: (
        /*showSelectAll*/
        ctx[11]
      ),
      selectAllText: (
        /*selectAllText*/
        ctx[12]
      )
    }
  });
  corecheckboxgroup.$on(
    "change",
    /*handleChange*/
    ctx[20]
  );
  return {
    c() {
      create_component(corecheckboxgroup.$$.fragment);
    },
    m(target, anchor) {
      mount_component(corecheckboxgroup, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const corecheckboxgroup_changes = {};
      if (dirty[0] & /*fieldState*/
      16384)
        corecheckboxgroup_changes.value = /*fieldState*/
        ctx2[14].value || [];
      if (dirty[0] & /*fieldState*/
      16384)
        corecheckboxgroup_changes.disabled = /*fieldState*/
        ctx2[14].disabled;
      if (dirty[0] & /*fieldState*/
      16384)
        corecheckboxgroup_changes.readonly = /*fieldState*/
        ctx2[14].readonly;
      if (dirty[0] & /*options*/
      65536)
        corecheckboxgroup_changes.options = /*options*/
        ctx2[16];
      if (dirty[0] & /*direction*/
      256)
        corecheckboxgroup_changes.direction = /*direction*/
        ctx2[8];
      if (dirty[0] & /*flatOptions*/
      262144)
        corecheckboxgroup_changes.getOptionLabel = /*flatOptions*/
        ctx2[18] ? func_4 : (
          /*func_5*/
          ctx2[28]
        );
      if (dirty[0] & /*flatOptions*/
      262144)
        corecheckboxgroup_changes.getOptionValue = /*flatOptions*/
        ctx2[18] ? func_6 : (
          /*func_7*/
          ctx2[29]
        );
      if (dirty[0] & /*showSelectAll*/
      2048)
        corecheckboxgroup_changes.showSelectAll = /*showSelectAll*/
        ctx2[11];
      if (dirty[0] & /*selectAllText*/
      4096)
        corecheckboxgroup_changes.selectAllText = /*selectAllText*/
        ctx2[12];
      corecheckboxgroup.$set(corecheckboxgroup_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(corecheckboxgroup.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(corecheckboxgroup.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(corecheckboxgroup, detaching);
    }
  };
}
function create_if_block_1(ctx) {
  let coremultiselect;
  let current;
  coremultiselect = new Multiselect({
    props: {
      value: (
        /*fieldState*/
        ctx[14].value || []
      ),
      getOptionLabel: (
        /*flatOptions*/
        ctx[18] ? func : func_1
      ),
      getOptionValue: (
        /*flatOptions*/
        ctx[18] ? func_2 : func_3
      ),
      id: (
        /*fieldState*/
        ctx[14].fieldId
      ),
      disabled: (
        /*fieldState*/
        ctx[14].disabled
      ),
      readonly: (
        /*fieldState*/
        ctx[14].readonly
      ),
      placeholder: (
        /*placeholder*/
        ctx[2]
      ),
      options: (
        /*options*/
        ctx[16]
      ),
      autocomplete: (
        /*autocomplete*/
        ctx[6]
      ),
      showSelectAll: (
        /*showSelectAll*/
        ctx[11]
      ),
      selectAllText: (
        /*selectAllText*/
        ctx[12]
      )
    }
  });
  coremultiselect.$on(
    "change",
    /*handleChange*/
    ctx[20]
  );
  return {
    c() {
      create_component(coremultiselect.$$.fragment);
    },
    m(target, anchor) {
      mount_component(coremultiselect, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const coremultiselect_changes = {};
      if (dirty[0] & /*fieldState*/
      16384)
        coremultiselect_changes.value = /*fieldState*/
        ctx2[14].value || [];
      if (dirty[0] & /*flatOptions*/
      262144)
        coremultiselect_changes.getOptionLabel = /*flatOptions*/
        ctx2[18] ? func : func_1;
      if (dirty[0] & /*flatOptions*/
      262144)
        coremultiselect_changes.getOptionValue = /*flatOptions*/
        ctx2[18] ? func_2 : func_3;
      if (dirty[0] & /*fieldState*/
      16384)
        coremultiselect_changes.id = /*fieldState*/
        ctx2[14].fieldId;
      if (dirty[0] & /*fieldState*/
      16384)
        coremultiselect_changes.disabled = /*fieldState*/
        ctx2[14].disabled;
      if (dirty[0] & /*fieldState*/
      16384)
        coremultiselect_changes.readonly = /*fieldState*/
        ctx2[14].readonly;
      if (dirty[0] & /*placeholder*/
      4)
        coremultiselect_changes.placeholder = /*placeholder*/
        ctx2[2];
      if (dirty[0] & /*options*/
      65536)
        coremultiselect_changes.options = /*options*/
        ctx2[16];
      if (dirty[0] & /*autocomplete*/
      64)
        coremultiselect_changes.autocomplete = /*autocomplete*/
        ctx2[6];
      if (dirty[0] & /*showSelectAll*/
      2048)
        coremultiselect_changes.showSelectAll = /*showSelectAll*/
        ctx2[11];
      if (dirty[0] & /*selectAllText*/
      4096)
        coremultiselect_changes.selectAllText = /*selectAllText*/
        ctx2[12];
      coremultiselect.$set(coremultiselect_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(coremultiselect.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(coremultiselect.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(coremultiselect, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*fieldState*/
    ctx[14] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*fieldState*/
        ctx2[14]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & /*fieldState*/
          16384) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let field_1;
  let updating_fieldState;
  let updating_fieldApi;
  let updating_fieldSchema;
  let current;
  function field_1_fieldState_binding(value) {
    ctx[30](value);
  }
  function field_1_fieldApi_binding(value) {
    ctx[31](value);
  }
  function field_1_fieldSchema_binding(value) {
    ctx[32](value);
  }
  let field_1_props = {
    field: (
      /*field*/
      ctx[0]
    ),
    label: (
      /*label*/
      ctx[1]
    ),
    disabled: (
      /*disabled*/
      ctx[3]
    ),
    readonly: (
      /*readonly*/
      ctx[4]
    ),
    validation: (
      /*validation*/
      ctx[5]
    ),
    span: (
      /*span*/
      ctx[9]
    ),
    helpText: (
      /*helpText*/
      ctx[10]
    ),
    defaultValue: (
      /*expandedDefaultValue*/
      ctx[17]
    ),
    type: FieldType.ARRAY,
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*fieldState*/
    ctx[14] !== void 0
  ) {
    field_1_props.fieldState = /*fieldState*/
    ctx[14];
  }
  if (
    /*fieldApi*/
    ctx[15] !== void 0
  ) {
    field_1_props.fieldApi = /*fieldApi*/
    ctx[15];
  }
  if (
    /*fieldSchema*/
    ctx[13] !== void 0
  ) {
    field_1_props.fieldSchema = /*fieldSchema*/
    ctx[13];
  }
  field_1 = new Field({ props: field_1_props });
  binding_callbacks.push(() => bind(field_1, "fieldState", field_1_fieldState_binding));
  binding_callbacks.push(() => bind(field_1, "fieldApi", field_1_fieldApi_binding));
  binding_callbacks.push(() => bind(field_1, "fieldSchema", field_1_fieldSchema_binding));
  return {
    c() {
      create_component(field_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(field_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const field_1_changes = {};
      if (dirty[0] & /*field*/
      1)
        field_1_changes.field = /*field*/
        ctx2[0];
      if (dirty[0] & /*label*/
      2)
        field_1_changes.label = /*label*/
        ctx2[1];
      if (dirty[0] & /*disabled*/
      8)
        field_1_changes.disabled = /*disabled*/
        ctx2[3];
      if (dirty[0] & /*readonly*/
      16)
        field_1_changes.readonly = /*readonly*/
        ctx2[4];
      if (dirty[0] & /*validation*/
      32)
        field_1_changes.validation = /*validation*/
        ctx2[5];
      if (dirty[0] & /*span*/
      512)
        field_1_changes.span = /*span*/
        ctx2[9];
      if (dirty[0] & /*helpText*/
      1024)
        field_1_changes.helpText = /*helpText*/
        ctx2[10];
      if (dirty[0] & /*expandedDefaultValue*/
      131072)
        field_1_changes.defaultValue = /*expandedDefaultValue*/
        ctx2[17];
      if (dirty[0] & /*fieldState, flatOptions, placeholder, options, autocomplete, showSelectAll, selectAllText, optionsType, direction*/
      350660 | dirty[1] & /*$$scope*/
      8) {
        field_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_fieldState && dirty[0] & /*fieldState*/
      16384) {
        updating_fieldState = true;
        field_1_changes.fieldState = /*fieldState*/
        ctx2[14];
        add_flush_callback(() => updating_fieldState = false);
      }
      if (!updating_fieldApi && dirty[0] & /*fieldApi*/
      32768) {
        updating_fieldApi = true;
        field_1_changes.fieldApi = /*fieldApi*/
        ctx2[15];
        add_flush_callback(() => updating_fieldApi = false);
      }
      if (!updating_fieldSchema && dirty[0] & /*fieldSchema*/
      8192) {
        updating_fieldSchema = true;
        field_1_changes.fieldSchema = /*fieldSchema*/
        ctx2[13];
        add_flush_callback(() => updating_fieldSchema = false);
      }
      field_1.$set(field_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(field_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(field_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(field_1, detaching);
    }
  };
}
const func = (x) => x;
const func_1 = (x) => x.label;
const func_2 = (x) => x;
const func_3 = (x) => x.value;
const func_4 = (x) => x;
const func_6 = (x) => x;
function instance($$self, $$props, $$invalidate) {
  let flatOptions;
  let expandedDefaultValue;
  let options;
  let { field } = $$props;
  let { label = void 0 } = $$props;
  let { placeholder = void 0 } = $$props;
  let { disabled = false } = $$props;
  let { readonly = false } = $$props;
  let { validation = void 0 } = $$props;
  let { defaultValue = void 0 } = $$props;
  let { optionsSource = "schema" } = $$props;
  let { dataProvider = void 0 } = $$props;
  let { labelColumn = void 0 } = $$props;
  let { valueColumn = void 0 } = $$props;
  let { customOptions } = $$props;
  let { autocomplete = false } = $$props;
  let { onChange = void 0 } = $$props;
  let { optionsType = "select" } = $$props;
  let { direction = "vertical" } = $$props;
  let { span = void 0 } = $$props;
  let { helpText = void 0 } = $$props;
  let { showSelectAll = false } = $$props;
  let { selectAllText = "Select all" } = $$props;
  let fieldState;
  let fieldApi;
  let fieldSchema;
  const expand = (values) => {
    if (!values) {
      return [];
    }
    if (Array.isArray(values)) {
      return values.slice();
    }
    return values.split(",").map((value) => value.trim());
  };
  const getProp = (prop, x) => {
    return x[prop];
  };
  const handleChange = (e) => {
    const changed = fieldApi == null ? void 0 : fieldApi.setValue(e.detail);
    if (onChange && changed) {
      onChange({ value: e.detail });
    }
  };
  const func_5 = (x) => getProp("label", x);
  const func_7 = (x) => getProp("value", x);
  function field_1_fieldState_binding(value) {
    fieldState = value;
    $$invalidate(14, fieldState);
  }
  function field_1_fieldApi_binding(value) {
    fieldApi = value;
    $$invalidate(15, fieldApi);
  }
  function field_1_fieldSchema_binding(value) {
    fieldSchema = value;
    $$invalidate(13, fieldSchema);
  }
  $$self.$$set = ($$props2) => {
    if ("field" in $$props2)
      $$invalidate(0, field = $$props2.field);
    if ("label" in $$props2)
      $$invalidate(1, label = $$props2.label);
    if ("placeholder" in $$props2)
      $$invalidate(2, placeholder = $$props2.placeholder);
    if ("disabled" in $$props2)
      $$invalidate(3, disabled = $$props2.disabled);
    if ("readonly" in $$props2)
      $$invalidate(4, readonly = $$props2.readonly);
    if ("validation" in $$props2)
      $$invalidate(5, validation = $$props2.validation);
    if ("defaultValue" in $$props2)
      $$invalidate(21, defaultValue = $$props2.defaultValue);
    if ("optionsSource" in $$props2)
      $$invalidate(22, optionsSource = $$props2.optionsSource);
    if ("dataProvider" in $$props2)
      $$invalidate(23, dataProvider = $$props2.dataProvider);
    if ("labelColumn" in $$props2)
      $$invalidate(24, labelColumn = $$props2.labelColumn);
    if ("valueColumn" in $$props2)
      $$invalidate(25, valueColumn = $$props2.valueColumn);
    if ("customOptions" in $$props2)
      $$invalidate(26, customOptions = $$props2.customOptions);
    if ("autocomplete" in $$props2)
      $$invalidate(6, autocomplete = $$props2.autocomplete);
    if ("onChange" in $$props2)
      $$invalidate(27, onChange = $$props2.onChange);
    if ("optionsType" in $$props2)
      $$invalidate(7, optionsType = $$props2.optionsType);
    if ("direction" in $$props2)
      $$invalidate(8, direction = $$props2.direction);
    if ("span" in $$props2)
      $$invalidate(9, span = $$props2.span);
    if ("helpText" in $$props2)
      $$invalidate(10, helpText = $$props2.helpText);
    if ("showSelectAll" in $$props2)
      $$invalidate(11, showSelectAll = $$props2.showSelectAll);
    if ("selectAllText" in $$props2)
      $$invalidate(12, selectAllText = $$props2.selectAllText);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & /*optionsSource*/
    4194304) {
      $$invalidate(18, flatOptions = optionsSource == null || optionsSource === "schema");
    }
    if ($$self.$$.dirty[0] & /*defaultValue*/
    2097152) {
      $$invalidate(17, expandedDefaultValue = expand(defaultValue));
    }
    if ($$self.$$.dirty[0] & /*optionsSource, fieldSchema, dataProvider, labelColumn, valueColumn, customOptions*/
    130031616) {
      $$invalidate(16, options = getOptions(optionsSource, fieldSchema, dataProvider, labelColumn, valueColumn, customOptions));
    }
  };
  return [
    field,
    label,
    placeholder,
    disabled,
    readonly,
    validation,
    autocomplete,
    optionsType,
    direction,
    span,
    helpText,
    showSelectAll,
    selectAllText,
    fieldSchema,
    fieldState,
    fieldApi,
    options,
    expandedDefaultValue,
    flatOptions,
    getProp,
    handleChange,
    defaultValue,
    optionsSource,
    dataProvider,
    labelColumn,
    valueColumn,
    customOptions,
    onChange,
    func_5,
    func_7,
    field_1_fieldState_binding,
    field_1_fieldApi_binding,
    field_1_fieldSchema_binding
  ];
}
class MultiFieldSelect extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance,
      create_fragment,
      safe_not_equal,
      {
        field: 0,
        label: 1,
        placeholder: 2,
        disabled: 3,
        readonly: 4,
        validation: 5,
        defaultValue: 21,
        optionsSource: 22,
        dataProvider: 23,
        labelColumn: 24,
        valueColumn: 25,
        customOptions: 26,
        autocomplete: 6,
        onChange: 27,
        optionsType: 7,
        direction: 8,
        span: 9,
        helpText: 10,
        showSelectAll: 11,
        selectAllText: 12
      },
      null,
      [-1, -1]
    );
  }
}
export {
  MultiFieldSelect as default
};
