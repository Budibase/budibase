import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, b as attr, al as set_style, f as insert, B as noop, o as detach, c1 as marked, W as binding_callbacks } from "./index-a0738cd3.js";
function create_fragment(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      attr(div, "class", "markdown-viewer svelte-12nifb7");
      set_style(
        div,
        "height",
        /*height*/
        ctx[0]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      ctx[3](div);
    },
    p(ctx2, [dirty]) {
      if (dirty & /*height*/
      1) {
        set_style(
          div,
          "height",
          /*height*/
          ctx2[0]
        );
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      ctx[3](null);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { value = void 0 } = $$props;
  let { height = void 0 } = $$props;
  let ref;
  const updateValue = async (ref2, markdown) => {
    if (!ref2) {
      return;
    }
    if (!markdown) {
      ref2.innerHTML = "";
      return;
    }
    ref2.innerHTML = marked.parse(markdown, { async: false });
  };
  function div_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      ref = $$value;
      $$invalidate(1, ref);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(2, value = $$props2.value);
    if ("height" in $$props2)
      $$invalidate(0, height = $$props2.height);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*ref, value*/
    6) {
      updateValue(ref, value);
    }
  };
  return [height, ref, value, div_binding];
}
class MarkdownViewer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { value: 2, height: 0 });
  }
}
export {
  MarkdownViewer as M
};
