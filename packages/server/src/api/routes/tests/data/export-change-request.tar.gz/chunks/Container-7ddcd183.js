import { S as SvelteComponent, i as init, s as safe_not_equal, e as element, a as space, b as attr, bP as GridColumns, d as toggle_class, f as insert, g as append, q as action_destroyer, l as listen, h as is_function, k as transition_in, z as group_outros, n as transition_out, A as check_outros, o as detach, r as run_all, u as getContext, v as component_subscribe, aX as memo, U as onMount, bQ as GridRowHeight, N as ensure_array_like, O as destroy_each, B as noop, F as create_slot, G as update_slot_base, H as get_all_dirty_from_scope, J as get_slot_changes, a3 as writable, W as binding_callbacks, am as null_to_empty, b9 as construct_svelte_component, c as create_component, y as empty, m as mount_component, p as destroy_component, bR as get_spread_update, bS as get_spread_object, bs as assign, bt as exclude_internal_props } from "./index-a0738cd3.js";
const GridContainer_svelte_svelte_type_style_lang = "";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[31] = list[i];
  return child_ctx;
}
function get_each_context_1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[31] = list[i];
  return child_ctx;
}
function create_if_block_1(ctx) {
  let div0;
  let t;
  let div1;
  let each_value_1 = ensure_array_like({ length: (
    /*rows*/
    ctx[2]
  ) });
  let each_blocks_1 = [];
  for (let i = 0; i < each_value_1.length; i += 1) {
    each_blocks_1[i] = create_each_block_1(get_each_context_1(ctx, each_value_1, i));
  }
  let each_value = ensure_array_like({ length: GridColumns });
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  return {
    c() {
      div0 = element("div");
      for (let i = 0; i < each_blocks_1.length; i += 1) {
        each_blocks_1[i].c();
      }
      t = space();
      div1 = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div0, "class", "underlay-h svelte-ch5mko");
      attr(div1, "class", "underlay-v svelte-ch5mko");
    },
    m(target, anchor) {
      insert(target, div0, anchor);
      for (let i = 0; i < each_blocks_1.length; i += 1) {
        if (each_blocks_1[i]) {
          each_blocks_1[i].m(div0, null);
        }
      }
      insert(target, t, anchor);
      insert(target, div1, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div1, null);
        }
      }
    },
    p(ctx2, dirty) {
      if (dirty[0] & /*rows*/
      4) {
        each_value_1 = ensure_array_like({ length: (
          /*rows*/
          ctx2[2]
        ) });
        let i;
        for (i = 0; i < each_value_1.length; i += 1) {
          const child_ctx = get_each_context_1(ctx2, each_value_1, i);
          if (each_blocks_1[i]) {
            each_blocks_1[i].p(child_ctx, dirty);
          } else {
            each_blocks_1[i] = create_each_block_1();
            each_blocks_1[i].c();
            each_blocks_1[i].m(div0, null);
          }
        }
        for (; i < each_blocks_1.length; i += 1) {
          each_blocks_1[i].d(1);
        }
        each_blocks_1.length = each_value_1.length;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div0);
        detach(t);
        detach(div1);
      }
      destroy_each(each_blocks_1, detaching);
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_each_block_1(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      attr(div, "class", "placeholder-h svelte-ch5mko");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_each_block(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      attr(div, "class", "placeholder-v svelte-ch5mko");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[25].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[24],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty[0] & /*$$scope*/
        16777216)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[24],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[24]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[24],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_fragment$2(ctx) {
  let div;
  let t;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  let if_block0 = (
    /*inBuilder*/
    ctx[5] && create_if_block_1(ctx)
  );
  let if_block1 = (
    /*mounted*/
    ctx[7] && create_if_block(ctx)
  );
  return {
    c() {
      div = element("div");
      if (if_block0)
        if_block0.c();
      t = space();
      if (if_block1)
        if_block1.c();
      attr(div, "class", "grid svelte-ch5mko");
      attr(div, "data-cols", GridColumns);
      attr(
        div,
        "data-col-size",
        /*colSize*/
        ctx[1]
      );
      attr(
        div,
        "data-required-rows",
        /*requiredRows*/
        ctx[4]
      );
      toggle_class(
        div,
        "mobile",
        /*mobile*/
        ctx[3]
      );
      toggle_class(div, "clickable", !!/*onClick*/
      ctx[0]);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block0)
        if_block0.m(div, null);
      append(div, t);
      if (if_block1)
        if_block1.m(div, null);
      ctx[26](div);
      current = true;
      if (!mounted) {
        dispose = [
          action_destroyer(styleable_action = /*styleable*/
          ctx[10].call(
            null,
            div,
            /*$styles*/
            ctx[8]
          )),
          listen(div, "click", function() {
            if (is_function(
              /*onClick*/
              ctx[0]
            ))
              ctx[0].apply(this, arguments);
          })
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (
        /*inBuilder*/
        ctx[5]
      ) {
        if (if_block0) {
          if_block0.p(ctx, dirty);
        } else {
          if_block0 = create_if_block_1(ctx);
          if_block0.c();
          if_block0.m(div, t);
        }
      } else if (if_block0) {
        if_block0.d(1);
        if_block0 = null;
      }
      if (
        /*mounted*/
        ctx[7]
      ) {
        if (if_block1) {
          if_block1.p(ctx, dirty);
          if (dirty[0] & /*mounted*/
          128) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block(ctx);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div, null);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if (!current || dirty[0] & /*colSize*/
      2) {
        attr(
          div,
          "data-col-size",
          /*colSize*/
          ctx[1]
        );
      }
      if (!current || dirty[0] & /*requiredRows*/
      16) {
        attr(
          div,
          "data-required-rows",
          /*requiredRows*/
          ctx[4]
        );
      }
      if (styleable_action && is_function(styleable_action.update) && dirty[0] & /*$styles*/
      256)
        styleable_action.update.call(
          null,
          /*$styles*/
          ctx[8]
        );
      if (!current || dirty[0] & /*mobile*/
      8) {
        toggle_class(
          div,
          "mobile",
          /*mobile*/
          ctx[3]
        );
      }
      if (!current || dirty[0] & /*onClick*/
      1) {
        toggle_class(div, "clickable", !!/*onClick*/
        ctx[0]);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
      ctx[26](null);
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance$2($$self, $$props, $$invalidate) {
  let inBuilder;
  let addEmptyRows;
  let requiredRows;
  let requiredHeight;
  let availableRows;
  let rows;
  let mobile;
  let colSize;
  let $component;
  let $context;
  let $children;
  let $builderStore;
  let $styles;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { onClick } = $$props;
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(20, $component = value));
  const { styleable, builderStore } = getContext("sdk");
  component_subscribe($$self, builderStore, (value) => $$invalidate(23, $builderStore = value));
  const context = getContext("context");
  component_subscribe($$self, context, (value) => $$invalidate(21, $context = value));
  let width;
  let height;
  let ref;
  let children = writable({});
  component_subscribe($$self, children, (value) => $$invalidate(22, $children = value));
  let mounted = false;
  let styles = memo({});
  component_subscribe($$self, styles, (value) => $$invalidate(8, $styles = value));
  const calculateRequiredRows = (children2, mobile2, addEmptyRows2) => {
    const key = mobile2 ? "mobileRowEnd" : "desktopRowEnd";
    let max = 2;
    for (let id of Object.keys(children2)) {
      if (children2[id][key] > max) {
        max = children2[id][key];
      }
    }
    let requiredRows2 = max - 1;
    if (addEmptyRows2) {
      return Math.ceil((requiredRows2 + 10) / 10) * 10;
    } else {
      return requiredRows2;
    }
  };
  const storeChild = (node) => {
    children.update((state) => ({
      ...state,
      [node.dataset.id]: {
        desktopRowEnd: parseInt(node.dataset.gridDesktopRowEnd),
        mobileRowEnd: parseInt(node.dataset.gridMobileRowEnd)
      }
    }));
  };
  const removeChild = (node) => {
    children.update((state) => {
      delete state[node.dataset.id];
      return { ...state };
    });
  };
  const setupResizeObserver = (element2) => {
    const resizeObserver = new ResizeObserver((entries) => {
      if (!(entries == null ? void 0 : entries[0])) {
        return;
      }
      const element3 = entries[0].target;
      $$invalidate(15, width = element3.clientWidth);
      $$invalidate(16, height = element3.clientHeight);
    });
    resizeObserver.observe(element2);
    return resizeObserver;
  };
  onMount(() => {
    let observer;
    let resizeObserver;
    resizeObserver = setupResizeObserver(ref);
    observer = new MutationObserver((mutations) => {
      var _a, _b, _c, _d;
      for (let mutation of mutations) {
        const { target, type, addedNodes, removedNodes } = mutation;
        if (target === ref) {
          if ((_b = (_a = addedNodes[0]) == null ? void 0 : _a.classList) == null ? void 0 : _b.contains("component")) {
            storeChild(addedNodes[0]);
          } else if ((_d = (_c = removedNodes[0]) == null ? void 0 : _c.classList) == null ? void 0 : _d.contains("component")) {
            removeChild(removedNodes[0]);
          }
        } else if (type === "attributes" && target.parentNode === ref && target.classList.contains("component")) {
          storeChild(target);
        }
      }
    });
    observer.observe(ref, {
      childList: true,
      attributes: true,
      subtree: true,
      attributeFilter: ["data-grid-desktop-row-end", "data-grid-mobile-row-end"]
    });
    $$invalidate(7, mounted = true);
    return () => {
      observer == null ? void 0 : observer.disconnect();
      resizeObserver == null ? void 0 : resizeObserver.disconnect();
    };
  });
  function div_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      ref = $$value;
      $$invalidate(6, ref);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("onClick" in $$props2)
      $$invalidate(0, onClick = $$props2.onClick);
    if ("$$scope" in $$props2)
      $$invalidate(24, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    var _a, _b, _c;
    if ($$self.$$.dirty[0] & /*$builderStore*/
    8388608) {
      $$invalidate(5, inBuilder = $builderStore.inBuilder);
    }
    if ($$self.$$.dirty[0] & /*$component, inBuilder*/
    1048608) {
      $$invalidate(19, addEmptyRows = $component.isRoot && inBuilder);
    }
    if ($$self.$$.dirty[0] & /*$context*/
    2097152) {
      $$invalidate(3, mobile = $context.device.mobile);
    }
    if ($$self.$$.dirty[0] & /*$children, mobile, addEmptyRows*/
    4718600) {
      $$invalidate(4, requiredRows = calculateRequiredRows($children, mobile, addEmptyRows));
    }
    if ($$self.$$.dirty[0] & /*requiredRows*/
    16) {
      $$invalidate(17, requiredHeight = requiredRows * GridRowHeight);
    }
    if ($$self.$$.dirty[0] & /*height*/
    65536) {
      $$invalidate(18, availableRows = Math.floor(height / GridRowHeight));
    }
    if ($$self.$$.dirty[0] & /*requiredRows, availableRows*/
    262160) {
      $$invalidate(2, rows = Math.max(requiredRows, availableRows));
    }
    if ($$self.$$.dirty[0] & /*width*/
    32768) {
      $$invalidate(1, colSize = width / GridColumns);
    }
    if ($$self.$$.dirty[0] & /*$component, requiredHeight, rows, colSize*/
    1179654) {
      styles.set({
        ...$component.styles,
        normal: {
          ...(_a = $component.styles) == null ? void 0 : _a.normal,
          "--height": `${requiredHeight}px`,
          "--min-height": ((_c = (_b = $component.styles) == null ? void 0 : _b.normal) == null ? void 0 : _c.height) || 0,
          "--cols": GridColumns,
          "--rows": rows,
          "--col-size": colSize,
          "--row-size": GridRowHeight
        }
      });
    }
  };
  return [
    onClick,
    colSize,
    rows,
    mobile,
    requiredRows,
    inBuilder,
    ref,
    mounted,
    $styles,
    component,
    styleable,
    builderStore,
    context,
    children,
    styles,
    width,
    height,
    requiredHeight,
    availableRows,
    addEmptyRows,
    $component,
    $context,
    $children,
    $builderStore,
    $$scope,
    slots,
    div_binding
  ];
}
class GridContainer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$2, create_fragment$2, safe_not_equal, { onClick: 0 }, null, [-1, -1]);
  }
}
const FlexContainer_svelte_svelte_type_style_lang = "";
function create_fragment$1(ctx) {
  let div;
  let div_class_value;
  let styleable_action;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[17].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[16],
    null
  );
  return {
    c() {
      div = element("div");
      if (default_slot)
        default_slot.c();
      attr(div, "class", div_class_value = null_to_empty(
        /*classNames*/
        ctx[2]
      ) + " svelte-h3y7aq");
      toggle_class(div, "clickable", !!/*onClick*/
      ctx[1]);
      toggle_class(
        div,
        "wrap",
        /*wrap*/
        ctx[0]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (default_slot) {
        default_slot.m(div, null);
      }
      current = true;
      if (!mounted) {
        dispose = [
          action_destroyer(styleable_action = /*styleable*/
          ctx[4].call(
            null,
            div,
            /*$component*/
            ctx[3].styles
          )),
          listen(div, "click", function() {
            if (is_function(
              /*onClick*/
              ctx[1]
            ))
              ctx[1].apply(this, arguments);
          })
        ];
        mounted = true;
      }
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        65536)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx,
            /*$$scope*/
            ctx[16],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx[16]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx[16],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*classNames*/
      4 && div_class_value !== (div_class_value = null_to_empty(
        /*classNames*/
        ctx[2]
      ) + " svelte-h3y7aq")) {
        attr(div, "class", div_class_value);
      }
      if (styleable_action && is_function(styleable_action.update) && dirty & /*$component*/
      8)
        styleable_action.update.call(
          null,
          /*$component*/
          ctx[3].styles
        );
      if (!current || dirty & /*classNames, onClick*/
      6) {
        toggle_class(div, "clickable", !!/*onClick*/
        ctx[1]);
      }
      if (!current || dirty & /*classNames, wrap*/
      5) {
        toggle_class(
          div,
          "wrap",
          /*wrap*/
          ctx[0]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let directionClass;
  let hAlignClass;
  let vAlignClass;
  let sizeClass;
  let gapClass;
  let classNames;
  let $component;
  let { $$slots: slots = {}, $$scope } = $$props;
  const { styleable } = getContext("sdk");
  const component = getContext("component");
  component_subscribe($$self, component, (value) => $$invalidate(3, $component = value));
  let { direction } = $$props;
  let { hAlign } = $$props;
  let { vAlign } = $$props;
  let { size } = $$props;
  let { gap } = $$props;
  let { wrap } = $$props;
  let { onClick } = $$props;
  $$self.$$set = ($$props2) => {
    if ("direction" in $$props2)
      $$invalidate(6, direction = $$props2.direction);
    if ("hAlign" in $$props2)
      $$invalidate(7, hAlign = $$props2.hAlign);
    if ("vAlign" in $$props2)
      $$invalidate(8, vAlign = $$props2.vAlign);
    if ("size" in $$props2)
      $$invalidate(9, size = $$props2.size);
    if ("gap" in $$props2)
      $$invalidate(10, gap = $$props2.gap);
    if ("wrap" in $$props2)
      $$invalidate(0, wrap = $$props2.wrap);
    if ("onClick" in $$props2)
      $$invalidate(1, onClick = $$props2.onClick);
    if ("$$scope" in $$props2)
      $$invalidate(16, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*direction*/
    64) {
      $$invalidate(15, directionClass = direction ? `flex-container direction-${direction}` : "");
    }
    if ($$self.$$.dirty & /*hAlign*/
    128) {
      $$invalidate(14, hAlignClass = hAlign ? `hAlign-${hAlign}` : "");
    }
    if ($$self.$$.dirty & /*vAlign*/
    256) {
      $$invalidate(13, vAlignClass = vAlign ? `vAlign-${vAlign}` : "");
    }
    if ($$self.$$.dirty & /*size*/
    512) {
      $$invalidate(12, sizeClass = size ? `size-${size}` : "");
    }
    if ($$self.$$.dirty & /*gap*/
    1024) {
      $$invalidate(11, gapClass = gap ? `gap-${gap}` : "");
    }
    if ($$self.$$.dirty & /*directionClass, hAlignClass, vAlignClass, sizeClass, gapClass*/
    63488) {
      $$invalidate(2, classNames = [directionClass, hAlignClass, vAlignClass, sizeClass, gapClass].join(" "));
    }
  };
  return [
    wrap,
    onClick,
    classNames,
    $component,
    styleable,
    component,
    direction,
    hAlign,
    vAlign,
    size,
    gap,
    gapClass,
    sizeClass,
    vAlignClass,
    hAlignClass,
    directionClass,
    $$scope,
    slots
  ];
}
class FlexContainer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, {
      direction: 6,
      hAlign: 7,
      vAlign: 8,
      size: 9,
      gap: 10,
      wrap: 0,
      onClick: 1
    });
  }
}
function create_default_slot(ctx) {
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[3].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[4],
    null
  );
  return {
    c() {
      if (default_slot)
        default_slot.c();
    },
    m(target, anchor) {
      if (default_slot) {
        default_slot.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        16)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[4],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[4]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[4],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function create_fragment(ctx) {
  let switch_instance;
  let switch_instance_anchor;
  let current;
  const switch_instance_spread_levels = [
    /*$$props*/
    ctx[1]
  ];
  var switch_value = (
    /*component*/
    ctx[0]
  );
  function switch_props(ctx2, dirty) {
    let switch_instance_props = {
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx: ctx2 }
    };
    for (let i = 0; i < switch_instance_spread_levels.length; i += 1) {
      switch_instance_props = assign(switch_instance_props, switch_instance_spread_levels[i]);
    }
    if (dirty !== void 0 && dirty & /*$$props*/
    2) {
      switch_instance_props = assign(switch_instance_props, get_spread_update(switch_instance_spread_levels, [get_spread_object(
        /*$$props*/
        ctx2[1]
      )]));
    }
    return { props: switch_instance_props };
  }
  if (switch_value) {
    switch_instance = construct_svelte_component(switch_value, switch_props(ctx));
  }
  return {
    c() {
      if (switch_instance)
        create_component(switch_instance.$$.fragment);
      switch_instance_anchor = empty();
    },
    m(target, anchor) {
      if (switch_instance)
        mount_component(switch_instance, target, anchor);
      insert(target, switch_instance_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (dirty & /*component*/
      1 && switch_value !== (switch_value = /*component*/
      ctx2[0])) {
        if (switch_instance) {
          group_outros();
          const old_component = switch_instance;
          transition_out(old_component.$$.fragment, 1, 0, () => {
            destroy_component(old_component, 1);
          });
          check_outros();
        }
        if (switch_value) {
          switch_instance = construct_svelte_component(switch_value, switch_props(ctx2, dirty));
          create_component(switch_instance.$$.fragment);
          transition_in(switch_instance.$$.fragment, 1);
          mount_component(switch_instance, switch_instance_anchor.parentNode, switch_instance_anchor);
        } else {
          switch_instance = null;
        }
      } else if (switch_value) {
        const switch_instance_changes = dirty & /*$$props*/
        2 ? get_spread_update(switch_instance_spread_levels, [get_spread_object(
          /*$$props*/
          ctx2[1]
        )]) : {};
        if (dirty & /*$$scope*/
        16) {
          switch_instance_changes.$$scope = { dirty, ctx: ctx2 };
        }
        switch_instance.$set(switch_instance_changes);
      }
    },
    i(local) {
      if (current)
        return;
      if (switch_instance)
        transition_in(switch_instance.$$.fragment, local);
      current = true;
    },
    o(local) {
      if (switch_instance)
        transition_out(switch_instance.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(switch_instance_anchor);
      }
      if (switch_instance)
        destroy_component(switch_instance, detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let component;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { layout = "flex" } = $$props;
  $$self.$$set = ($$new_props) => {
    $$invalidate(1, $$props = assign(assign({}, $$props), exclude_internal_props($$new_props)));
    if ("layout" in $$new_props)
      $$invalidate(2, layout = $$new_props.layout);
    if ("$$scope" in $$new_props)
      $$invalidate(4, $$scope = $$new_props.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*layout*/
    4) {
      $$invalidate(0, component = layout === "grid" ? GridContainer : FlexContainer);
    }
  };
  $$props = exclude_internal_props($$props);
  return [component, $$props, layout, slots, $$scope];
}
class Container extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { layout: 2 });
  }
}
export {
  Container as default
};
